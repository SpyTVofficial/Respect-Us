
from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel
from typing import Dict, Any, Optional, List
from datetime import datetime
import databutton as db
from app.auth.user import get_authorized_user
import json
import asyncpg

router = APIRouter(prefix="/validation")

# Pydantic models for validation workflow
class ValidationSubmissionRequest(BaseModel):
    assessment_id: str
    assessment_title: str
    company_name: str
    template_id: int
    template_title: str
    user_id: str
    user_email: str
    user_name: str
    responses: Dict[str, Any]
    action_plan: Dict[str, str]  # high, medium, low priority actions
    overall_assessment: Dict[str, str]  # strengths, weaknesses, recommendations
    risk_score: Dict[str, Any]
    submission_notes: Optional[str] = None

class ValidationResponse(BaseModel):
    validation_id: str
    status: str  # 'submitted', 'under_review', 'validated', 'needs_revision'
    message: str

class AdminValidationRequest(BaseModel):
    validation_id: str
    admin_decision: str  # 'approve' or 'request_changes'
    admin_comments: Optional[str] = None
    modified_action_plan: Optional[Dict[str, str]] = None  # If requesting changes
    modified_overall_assessment: Optional[Dict[str, str]] = None  # If requesting changes

class AdminValidationResponse(BaseModel):
    success: bool
    message: str
    email_sent: bool

class ValidationTaskItem(BaseModel):
    validation_id: str
    assessment_title: str
    company_name: str
    template_title: str
    user_name: str
    user_email: str
    submitted_at: str
    status: str
    priority: str  # 'high', 'medium', 'low'
    risk_level: str
    risk_percentage: float

class ValidationTaskDetail(BaseModel):
    validation_id: str
    assessment_id: str
    assessment_title: str
    company_name: str
    template_id: int
    template_title: str
    user_id: str
    user_email: str
    user_name: str
    submitted_at: str
    status: str
    responses: Dict[str, Any]
    action_plan: Dict[str, str]
    overall_assessment: Dict[str, str]
    risk_score: Dict[str, Any]
    submission_notes: Optional[str]
    admin_comments: Optional[str]
    reviewed_at: Optional[str]
    reviewed_by: Optional[str]

class ValidationTasksListResponse(BaseModel):
    tasks: List[ValidationTaskItem]
    total_count: int
    pending_count: int
    completed_count: int

@router.post("/submit", response_model=ValidationResponse)
async def submit_for_validation(request: ValidationSubmissionRequest, user=Depends(get_authorized_user)):
    """
    Submit an assessment for RespectUs validation review.
    Creates a task in the admin dashboard for review.
    """
    try:
        # Generate unique validation ID
        validation_id = f"VAL_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{user.sub[:8]}"
        
        # Store validation request in database
        database_url = db.secrets.get("DATABASE_URL_DEV")
        conn = await asyncpg.connect(database_url)
        
        try:
            # Insert validation task
            await conn.execute(
                """
                INSERT INTO validation_tasks (
                    validation_id, assessment_id, assessment_title, company_name,
                    template_id, template_title, user_id, user_email, user_name,
                    submitted_at, status, responses, action_plan, overall_assessment,
                    risk_score, submission_notes
                ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16)
                """,
                validation_id, request.assessment_id, request.assessment_title, request.company_name,
                request.template_id, request.template_title, request.user_id, request.user_email,
                request.user_name, datetime.now(), 'submitted',
                json.dumps(request.responses), json.dumps(request.action_plan),
                json.dumps(request.overall_assessment), json.dumps(request.risk_score),
                request.submission_notes
            )
            
            print(f"Validation task created: {validation_id} for user {request.user_email}")
        finally:
            await conn.close()
                
        return ValidationResponse(
            validation_id=validation_id,
            status="submitted",
            message="Assessment submitted for RespectUs validation. You will be notified by email once the review is complete."
        )
        
    except Exception as e:
        print(f"Error submitting validation: {e}")
        raise HTTPException(status_code=500, detail="Failed to submit assessment for validation")

@router.get("/admin/tasks", response_model=ValidationTasksListResponse)
async def get_admin_validation_tasks(user=Depends(get_authorized_user), status: Optional[str] = None):
    """
    Get all validation tasks for admin review.
    Optionally filter by status: 'submitted', 'under_review', 'validated', 'needs_revision'
    """
    try:
        database_url = db.secrets.get("DATABASE_URL_DEV")
        conn = await asyncpg.connect(database_url)
        
        try:
            # Build query with optional status filter
            if status:
                tasks_query = """
                    SELECT validation_id, assessment_title, company_name, template_title,
                           user_name, user_email, submitted_at, status, risk_score
                    FROM validation_tasks 
                    WHERE status = $1
                    ORDER BY submitted_at DESC
                """
                tasks = await conn.fetch(tasks_query, status)
            else:
                tasks_query = """
                    SELECT validation_id, assessment_title, company_name, template_title,
                           user_name, user_email, submitted_at, status, risk_score
                    FROM validation_tasks 
                    ORDER BY submitted_at DESC
                """
                tasks = await conn.fetch(tasks_query)
            
            # Get counts
            counts = await conn.fetchrow(
                """
                SELECT 
                    COUNT(*) as total_count,
                    COUNT(*) FILTER (WHERE status IN ('submitted', 'under_review')) as pending_count,
                    COUNT(*) FILTER (WHERE status IN ('validated', 'needs_revision')) as completed_count
                FROM validation_tasks
                """
            )
        finally:
            await conn.close()
            
        # Transform tasks
        task_items = []
        for task in tasks:
            risk_data = json.loads(task['risk_score']) if task['risk_score'] else {}
            
            task_items.append(ValidationTaskItem(
                validation_id=task['validation_id'],
                assessment_title=task['assessment_title'],
                company_name=task['company_name'],
                template_title=task['template_title'],
                user_name=task['user_name'],
                user_email=task['user_email'],
                submitted_at=task['submitted_at'].isoformat() if isinstance(task['submitted_at'], datetime) else str(task['submitted_at']),
                status=task['status'],
                priority='high' if risk_data.get('riskLevel') == 'high' else 
                         'medium' if risk_data.get('riskLevel') == 'medium' else 'low',
                risk_level=risk_data.get('riskLevel', 'unknown'),
                risk_percentage=risk_data.get('percentage', 0)
            ))
        
        return ValidationTasksListResponse(
            tasks=task_items,
            total_count=counts['total_count'] or 0,
            pending_count=counts['pending_count'] or 0,
            completed_count=counts['completed_count'] or 0
        )
            
    except Exception as e:
        print(f"Error fetching validation tasks: {e}")
        raise HTTPException(status_code=500, detail="Failed to fetch validation tasks")

@router.get("/admin/task/{validation_id}", response_model=ValidationTaskDetail)
async def get_validation_task_detail(validation_id: str, user=Depends(get_authorized_user)):
    """
    Get detailed information about a specific validation task for admin review.
    """
    try:
        database_url = db.secrets.get("DATABASE_URL_DEV")
        conn = await asyncpg.connect(database_url)
        
        try:
            task = await conn.fetchrow(
                """
                SELECT * FROM validation_tasks WHERE validation_id = $1
                """,
                validation_id
            )
        finally:
            await conn.close()
            
        if not task:
            raise HTTPException(status_code=404, detail="Validation task not found")
        
        return ValidationTaskDetail(
            validation_id=task['validation_id'],
            assessment_id=task['assessment_id'],
            assessment_title=task['assessment_title'],
            company_name=task['company_name'],
            template_id=task['template_id'],
            template_title=task['template_title'],
            user_id=task['user_id'],
            user_email=task['user_email'],
            user_name=task['user_name'],
            submitted_at=task['submitted_at'].isoformat() if isinstance(task['submitted_at'], datetime) else str(task['submitted_at']),
            status=task['status'],
            responses=json.loads(task['responses']) if task['responses'] else {},
            action_plan=json.loads(task['action_plan']) if task['action_plan'] else {},
            overall_assessment=json.loads(task['overall_assessment']) if task['overall_assessment'] else {},
            risk_score=json.loads(task['risk_score']) if task['risk_score'] else {},
            submission_notes=task['submission_notes'],
            admin_comments=task['admin_comments'],
            reviewed_at=task['reviewed_at'].isoformat() if task['reviewed_at'] and isinstance(task['reviewed_at'], datetime) else (str(task['reviewed_at']) if task['reviewed_at'] else None),
            reviewed_by=task['reviewed_by']
        )
            
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error fetching validation task detail: {e}")
        raise HTTPException(status_code=500, detail="Failed to fetch validation task details")

@router.post("/admin/respond", response_model=AdminValidationResponse)
async def respond_to_validation(request: AdminValidationRequest, user=Depends(get_authorized_user)):
    """
    Admin responds to a validation request - either approve or request changes.
    Sends email notification to the user.
    """
    try:
        database_url = db.secrets.get("DATABASE_URL_DEV")
        conn = await asyncpg.connect(database_url)
        email_sent = False
        
        try:
            # Get the validation task
            task = await conn.fetchrow(
                "SELECT * FROM validation_tasks WHERE validation_id = $1",
                request.validation_id
            )
            
            if not task:
                raise HTTPException(status_code=404, detail="Validation task not found")
            
            # Determine new status
            new_status = 'validated' if request.admin_decision == 'approve' else 'needs_revision'
            
            # Update validation task
            await conn.execute(
                """
                UPDATE validation_tasks 
                SET status = $1, admin_comments = $2, reviewed_at = $3, reviewed_by = $4,
                    modified_action_plan = $5, modified_overall_assessment = $6
                WHERE validation_id = $7
                """,
                new_status, request.admin_comments, datetime.now(), 
                user.email or user.sub,
                json.dumps(request.modified_action_plan) if request.modified_action_plan else None,
                json.dumps(request.modified_overall_assessment) if request.modified_overall_assessment else None,
                request.validation_id
            )
        finally:
            await conn.close()
            
        # Send email notification
        try:
            if request.admin_decision == 'approve':
                email_subject = f"Respectus Validation Complete - {task['assessment_title']}"
                email_content = f"""
                <h2>Assessment Validation Complete</h2>
                <p>Your risk assessment "{task['assessment_title']}" for {task['company_name']} has been validated by Respectus.</p>
                
                <p><strong>Status:</strong> Approved without modifications</p>
                
                {f'<p><strong>Admin Comments:</strong></p><p>{request.admin_comments}</p>' if request.admin_comments else ''}
                
                <p>You can view the validated assessment in your Risk Assessment module.</p>
                
                <p>Best regards,<br>Respectus Compliance Team</p>
                """
            else:
                email_subject = f"Respectus Validation - Modifications Suggested - {task['assessment_title']}"
                email_content = f"""
                <h2>Assessment Validation - Modifications Suggested</h2>
                <p>Your risk assessment "{task['assessment_title']}" for {task['company_name']} has been reviewed by Respectus.</p>
                
                <p><strong>Status:</strong> Modifications suggested</p>
                
                {f'<p><strong>Admin Comments:</strong></p><p>{request.admin_comments}</p>' if request.admin_comments else ''}
                
                <p>Please review the suggested modifications in your Risk Assessment module and update your action plan accordingly.</p>
                
                <p>Best regards,<br>Respectus Compliance Team</p>
                """
            
            db.notify.email(
                to=task['user_email'],
                subject=email_subject,
                content_html=email_content,
                content_text=email_content.replace('<h2>', '').replace('</h2>', '\n').replace('<p>', '').replace('</p>', '\n').replace('<strong>', '').replace('</strong>', '').replace('<br>', '\n')
            )
            
            email_sent = True
            print(f"Validation response email sent to {task['user_email']}")
            
        except Exception as email_error:
            print(f"Failed to send validation email: {email_error}")
            email_sent = False
        
        # Log the admin action
        print(f"Admin {user.email or user.sub} {request.admin_decision}d validation {request.validation_id}")
        
        return AdminValidationResponse(
            success=True,
            message=f"Validation response sent successfully. Status updated to {new_status}.",
            email_sent=email_sent
        )
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error responding to validation: {e}")
        raise HTTPException(status_code=500, detail="Failed to respond to validation request")

@router.get("/user/status/{assessment_id}")
async def get_user_validation_status(assessment_id: str, user=Depends(get_authorized_user)):
    """
    Get validation status for a specific assessment for the current user.
    """
    try:
        database_url = db.secrets.get("DATABASE_URL_DEV")
        conn = await asyncpg.connect(database_url)
        
        try:
            validation = await conn.fetchrow(
                """
                SELECT validation_id, status, admin_comments, reviewed_at, reviewed_by,
                       modified_action_plan, modified_overall_assessment
                FROM validation_tasks 
                WHERE assessment_id = $1 AND user_id = $2
                ORDER BY submitted_at DESC
                LIMIT 1
                """,
                assessment_id, user.sub
            )
        finally:
            await conn.close()
            
        if not validation:
            return {
                "status": "none",
                "message": "No validation request found for this assessment"
            }
        
        result = {
            "validation_id": validation['validation_id'],
            "status": validation['status'],
            "admin_comments": validation['admin_comments'],
            "reviewed_at": validation['reviewed_at'],
            "reviewed_by": validation['reviewed_by']
        }
        
        # Include modifications if any
        if validation['modified_action_plan']:
            result["modified_action_plan"] = json.loads(validation['modified_action_plan'])
        if validation['modified_overall_assessment']:
            result["modified_overall_assessment"] = json.loads(validation['modified_overall_assessment'])
        
        return result
            
    except Exception as e:
        print(f"Error fetching user validation status: {e}")
        raise HTTPException(status_code=500, detail="Failed to fetch validation status")
