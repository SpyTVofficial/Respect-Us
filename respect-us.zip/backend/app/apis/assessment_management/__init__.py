

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Dict, List, Any, Optional
from datetime import datetime
import asyncpg
import json
from app.auth import AuthorizedUser
import databutton as db
from app.libs.database import get_db_connection

router = APIRouter(prefix="/assessment-management")

# Pydantic models
class AssessmentResponse(BaseModel):
    question_id: str
    section_id: str
    answer: Any  # Can be string, list, number
    notes: Optional[str] = None

class SaveAssessmentRequest(BaseModel):
    template_id: int
    company_name: str
    assessment_title: str
    responses: List[AssessmentResponse]
    status: str  # 'draft' or 'completed'
    completion_percentage: float
    section_analysis: Optional[Dict[str, Any]] = None
    overall_assessment: Optional[Dict[str, Any]] = None
    action_plan: Optional[Dict[str, Any]] = None

class SaveAssessmentResponse(BaseModel):
    success: bool
    assessment_id: str
    message: str
    saved_at: str

class LoadAssessmentResponse(BaseModel):
    assessment_id: str
    template_id: int
    company_name: str
    assessment_title: str
    responses: List[AssessmentResponse]
    status: str
    completion_percentage: float
    section_analysis: Optional[Dict[str, Any]] = None
    overall_assessment: Optional[Dict[str, Any]] = None
    action_plan: Optional[Dict[str, Any]] = None
    created_at: str
    updated_at: str

class UserAssessmentListItem(BaseModel):
    assessment_id: str
    template_id: int
    template_title: str
    company_name: str
    assessment_title: str
    status: str
    completion_percentage: float
    created_at: str
    updated_at: str

class UserAssessmentsResponse(BaseModel):
    assessments: List[UserAssessmentListItem]
    total_count: int

# Access control middleware
async def check_risk_assessment_access(user: AuthorizedUser) -> bool:
    """Check if user has access to Risk Assessment module (credit-based)"""
    # Risk Assessment is now credit-based - access is controlled per action
    # Users can access the module but will need credits for specific actions
    return True

@router.post("/save", response_model=SaveAssessmentResponse)
async def save_assessment(request: SaveAssessmentRequest, user: AuthorizedUser):
    """
    Save or update an assessment with user responses
    """
    # Check access control
    if not await check_risk_assessment_access(user):
        raise HTTPException(
            status_code=403, 
            detail="Access denied. Please purchase the Risk Assessment module to use this feature."
        )
        
    try:
        async with get_db_connection() as conn:
            # Generate assessment ID if new, or find existing
            assessment_id = f"ASS_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{user.sub[:8]}"
            
            # Check if assessment already exists (by template_id, user_id, company_name, assessment_title)
            existing_query = """
                SELECT assessment_id FROM user_assessments 
                WHERE template_id = $1 AND user_id = $2 AND company_name = $3 AND assessment_title = $4
            """
            
            existing_id = await conn.fetchval(
                existing_query, 
                request.template_id, 
                user.sub, 
                request.company_name, 
                request.assessment_title
            )
            
            if existing_id:
                assessment_id = existing_id
                # Update existing assessment
                update_query = """
                    UPDATE user_assessments SET 
                        responses = $1,
                        status = $2,
                        completion_percentage = $3,
                        section_analysis = $4,
                        overall_assessment = $5,
                        action_plan = $6,
                        updated_at = $7
                    WHERE assessment_id = $8
                """
                
                await conn.execute(
                    update_query,
                    json.dumps([resp.dict() for resp in request.responses]),
                    request.status,
                    request.completion_percentage,
                    json.dumps(request.section_analysis) if request.section_analysis else None,
                    json.dumps(request.overall_assessment) if request.overall_assessment else None,
                    json.dumps(request.action_plan) if request.action_plan else None,
                    datetime.now(),
                    assessment_id
                )
            else:
                # Insert new assessment
                insert_query = """
                    INSERT INTO user_assessments (
                        assessment_id, template_id, user_id, company_name, assessment_title,
                        responses, status, completion_percentage, section_analysis, 
                        overall_assessment, action_plan, created_at, updated_at
                    ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13)
                """
                
                now = datetime.now()
                await conn.execute(
                    insert_query,
                    assessment_id,
                    request.template_id,
                    user.sub,
                    request.company_name,
                    request.assessment_title,
                    json.dumps([resp.dict() for resp in request.responses]),
                    request.status,
                    request.completion_percentage,
                    json.dumps(request.section_analysis) if request.section_analysis else None,
                    json.dumps(request.overall_assessment) if request.overall_assessment else None,
                    json.dumps(request.action_plan) if request.action_plan else None,
                    now,
                    now
                )
        
        return SaveAssessmentResponse(
            success=True,
            assessment_id=assessment_id,
            message=f"Assessment {request.status} saved successfully",
            saved_at=datetime.now().isoformat()
        )
        
    except Exception as e:
        print(f"Error saving assessment: {e}")
        raise HTTPException(status_code=500, detail="Failed to save assessment")

@router.get("/load/{assessment_id}", response_model=LoadAssessmentResponse)
async def load_assessment(assessment_id: str, user: AuthorizedUser):
    """
    Load a specific assessment by ID
    """
    # Check access control
    if not await check_risk_assessment_access(user):
        raise HTTPException(
            status_code=403, 
            detail="Access denied. Please purchase the Risk Assessment module to use this feature."
        )
        
    try:
        async with get_db_connection() as conn:
        
            query = """
                SELECT * FROM user_assessments 
                WHERE assessment_id = $1 AND user_id = $2
            """
            
            row = await conn.fetchrow(query, assessment_id, user.sub)
        
            if not row:
                raise HTTPException(status_code=404, detail="Assessment not found")
        
            # Parse JSON fields
            responses_data = json.loads(row['responses']) if row['responses'] else []
            responses = [AssessmentResponse(**resp) for resp in responses_data]
            
            section_analysis = json.loads(row['section_analysis']) if row['section_analysis'] else None
            overall_assessment = json.loads(row['overall_assessment']) if row['overall_assessment'] else None
            action_plan = json.loads(row['action_plan']) if row['action_plan'] else None
            
            return LoadAssessmentResponse(
                assessment_id=row['assessment_id'],
                template_id=row['template_id'],
                company_name=row['company_name'],
                assessment_title=row['assessment_title'],
                responses=responses,
                status=row['status'],
                completion_percentage=row['completion_percentage'],
                section_analysis=section_analysis,
                overall_assessment=overall_assessment,
                action_plan=action_plan,
                created_at=row['created_at'].isoformat() if hasattr(row['created_at'], 'isoformat') else str(row['created_at']),
                updated_at=row['updated_at'].isoformat() if hasattr(row['updated_at'], 'isoformat') else str(row['updated_at'])
            )
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error loading assessment: {e}")
        raise HTTPException(status_code=500, detail="Failed to load assessment")

@router.get("/list", response_model=UserAssessmentsResponse)
async def list_user_assessments(user: AuthorizedUser):
    """
    List all assessments for the current user
    """
    # Check access control
    if not await check_risk_assessment_access(user):
        raise HTTPException(
            status_code=403, 
            detail="Access denied. Please purchase the Risk Assessment module to use this feature."
        )
        
    try:
        print(f"DEBUG: Loading assessments for user_id: {user.sub}")
        async with get_db_connection() as conn:
        
            query = """
                SELECT ua.assessment_id, ua.template_id, ua.company_name, ua.assessment_title,
                       ua.status, ua.completion_percentage, ua.created_at, ua.updated_at,
                       rt.title as template_title
                FROM user_assessments ua
                LEFT JOIN risk_assessment_templates rt ON ua.template_id = rt.id
                WHERE ua.user_id = $1
                ORDER BY ua.updated_at DESC
            """
            
            rows = await conn.fetch(query, user.sub)
        
            assessments = []
            for row in rows:
                assessments.append(UserAssessmentListItem(
                    assessment_id=row['assessment_id'],
                    template_id=row['template_id'],
                    template_title=row['template_title'] or 'Unknown Template',
                    company_name=row['company_name'],
                    assessment_title=row['assessment_title'],
                    status=row['status'],
                    completion_percentage=row['completion_percentage'],
                    created_at=row['created_at'].isoformat() if row['created_at'] else '',
                    updated_at=row['updated_at'].isoformat() if row['updated_at'] else ''
                ))
            
            return UserAssessmentsResponse(
                assessments=assessments,
                total_count=len(assessments)
            )
        
    except Exception as e:
        print(f"Error listing assessments: {e}")
        raise HTTPException(status_code=500, detail="Failed to list assessments")

@router.delete("/delete/{assessment_id}")
async def delete_assessment(assessment_id: str, user: AuthorizedUser):
    """
    Delete an assessment
    """
    # Check access control
    if not await check_risk_assessment_access(user):
        raise HTTPException(
            status_code=403, 
            detail="Access denied. Please purchase the Risk Assessment module to use this feature."
        )
        
    try:
        async with get_db_connection() as conn:
            query = "DELETE FROM user_assessments WHERE assessment_id = $1 AND user_id = $2"
            result = await conn.execute(query, assessment_id, user.sub)
            
            if result == "DELETE 0":
                raise HTTPException(status_code=404, detail="Assessment not found")
            
            return {"success": True, "message": "Assessment deleted successfully"}
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error deleting assessment: {e}")
        raise HTTPException(status_code=500, detail="Failed to delete assessment")
