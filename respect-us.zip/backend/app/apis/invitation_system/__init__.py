

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, EmailStr
from typing import List, Optional, Dict, Any
from app.auth import AuthorizedUser
import asyncpg
import databutton as db
from datetime import datetime, timedelta
import secrets
import json

router = APIRouter(prefix="/invitation-system")

# Database connection
async def get_db_connection():
    return await asyncpg.connect(db.secrets.get("DATABASE_URL_DEV"))

# Pydantic Models
class AcceptInvitationRequest(BaseModel):
    invitation_token: str

class ResendInvitationRequest(BaseModel):
    invitation_id: int
    custom_message: Optional[str] = None

class InvitationDetailsResponse(BaseModel):
    id: int
    company_name: str
    company_slug: str
    role_name: str
    role_description: str
    invited_by_name: Optional[str]
    invited_by_email: Optional[str]
    invited_at: str
    expires_at: str
    message: Optional[str]
    is_expired: bool
    can_accept: bool

class EmailTemplateData(BaseModel):
    to_email: str
    to_name: Optional[str]
    company_name: str
    invited_by_name: str
    invited_by_email: str
    role_name: str
    invitation_token: str
    expires_at: str
    custom_message: Optional[str]
    accept_url: str

# Helper Functions
async def send_invitation_email(template_data: EmailTemplateData):
    """Send invitation email using Databutton's email service"""
    try:
        # Create email content
        subject = f"Invitation to join {template_data.company_name} on RespectUs"
        
        html_content = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <style>
                body {{ font-family: Arial, sans-serif; line-height: 1.6; color: #333; }}
                .container {{ max-width: 600px; margin: 0 auto; padding: 20px; }}
                .header {{ background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%); color: white; padding: 30px; text-align: center; border-radius: 8px 8px 0 0; }}
                .content {{ background: #f9f9f9; padding: 30px; border-radius: 0 0 8px 8px; }}
                .btn {{ display: inline-block; background: #e94560; color: white; padding: 12px 30px; text-decoration: none; border-radius: 5px; margin: 20px 0; }}
                .btn:hover {{ background: #d63384; }}
                .footer {{ text-align: center; margin-top: 20px; color: #666; font-size: 12px; }}
                .role-badge {{ background: #0f3460; color: white; padding: 5px 10px; border-radius: 15px; font-size: 12px; }}
            </style>
        </head>
        <body>
            <div class="container">
                <div class="header">
                    <h1>🚀 You're Invited to Join {template_data.company_name}</h1>
                    <p>Welcome to RespectUs - Export Control Compliance Platform</p>
                </div>
                <div class="content">
                    <p>Hello{f" {template_data.to_name}" if template_data.to_name else ""},</p>
                    
                    <p><strong>{template_data.invited_by_name}</strong> ({template_data.invited_by_email}) has invited you to join <strong>{template_data.company_name}</strong> on RespectUs.</p>
                    
                    <p>You've been assigned the role: <span class="role-badge">{template_data.role_name}</span></p>
                    
                    {f'<div style="background: #e3f2fd; padding: 15px; border-left: 4px solid #2196f3; margin: 20px 0;"><strong>Personal Message:</strong><br>{template_data.custom_message}</div>' if template_data.custom_message else ''}
                    
                    <p>RespectUs is a comprehensive digital platform for export control compliance, featuring:</p>
                    <ul>
                        <li>📚 Knowledge Base for regulations and guidelines</li>
                        <li>🔍 Product Classification tools</li>
                        <li>🚫 Sanctions and Embargoes monitoring</li>
                        <li>👥 Customer Screening capabilities</li>
                        <li>✅ End-use Checks and Risk Assessment</li>
                        <li>📋 License Determination support</li>
                    </ul>
                    
                    <div style="text-align: center;">
                        <a href="{template_data.accept_url}" class="btn">Accept Invitation</a>
                    </div>
                    
                    <p><strong>Important:</strong> This invitation expires on {template_data.expires_at}.</p>
                    
                    <p>If you have any questions, please contact {template_data.invited_by_name} at {template_data.invited_by_email}.</p>
                </div>
                <div class="footer">
                    <p>This invitation was sent by RespectUs | Export Control Compliance Platform</p>
                    <p>If you believe this email was sent to you by mistake, please ignore it.</p>
                </div>
            </div>
        </body>
        </html>
        """
        
        text_content = f"""
        You're Invited to Join {template_data.company_name} on RespectUs
        
        Hello{f" {template_data.to_name}" if template_data.to_name else ""},
        
        {template_data.invited_by_name} ({template_data.invited_by_email}) has invited you to join {template_data.company_name} on RespectUs.
        
        You've been assigned the role: {template_data.role_name}
        
        {f'Personal Message: {template_data.custom_message}' if template_data.custom_message else ''}
        
        RespectUs is a comprehensive digital platform for export control compliance.
        
        To accept this invitation, visit: {template_data.accept_url}
        
        This invitation expires on {template_data.expires_at}.
        
        If you have any questions, please contact {template_data.invited_by_name} at {template_data.invited_by_email}.
        
        ---
        RespectUs | Export Control Compliance Platform
        """
        
        # Send email using Databutton's notification service
        db.notify.email(
            to=template_data.to_email,
            subject=subject,
            content_html=html_content,
            content_text=text_content
        )
        
        print(f"Invitation email sent successfully to {template_data.to_email}")
        return True
        
    except Exception as e:
        print(f"Error sending invitation email: {e}")
        return False

async def log_audit_action(company_id: int, user_id: str, action: str, details: Dict, conn):
    """Log an audit action"""
    await conn.execute("""
        INSERT INTO company_audit_logs (company_id, user_id, action, details, created_at)
        VALUES ($1, $2, $3, $4, $5)
    """, company_id, user_id, action, json.dumps(details), datetime.now())

# Invitation Management Endpoints
@router.get("/invitation/{invitation_token}")
async def get_invitation_details(invitation_token: str) -> InvitationDetailsResponse:
    """Get invitation details for acceptance page (public endpoint)"""
    try:
        conn = await get_db_connection()
        
        # Get invitation with company and role details
        invitation = await conn.fetchrow("""
            SELECT 
                ti.id, ti.email, ti.invited_at, ti.expires_at, ti.message, ti.status,
                c.company_name, c.company_slug,
                rd.role_name, rd.role_description,
                inviter.email as invited_by_email, inviter.name as invited_by_name
            FROM team_invitations ti
            JOIN companies c ON ti.company_id = c.id
            JOIN role_definitions rd ON ti.role_id = rd.id
            LEFT JOIN neon_auth.users_sync inviter ON ti.invited_by = inviter.id
            WHERE ti.invitation_token = $1
        """, invitation_token)
        
        if not invitation:
            raise HTTPException(status_code=404, detail="Invitation not found")
        
        await conn.close()
        
        # Check if invitation is expired
        is_expired = invitation['expires_at'] < datetime.now() or invitation['status'] != 'pending'
        can_accept = not is_expired and invitation['status'] == 'pending'
        
        return InvitationDetailsResponse(
            id=invitation['id'],
            company_name=invitation['company_name'],
            company_slug=invitation['company_slug'],
            role_name=invitation['role_name'],
            role_description=invitation['role_description'],
            invited_by_name=invitation['invited_by_name'],
            invited_by_email=invitation['invited_by_email'],
            invited_at=invitation['invited_at'].isoformat(),
            expires_at=invitation['expires_at'].isoformat(),
            message=invitation['message'],
            is_expired=is_expired,
            can_accept=can_accept
        )
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error getting invitation details: {e}")
        raise HTTPException(status_code=500, detail="Failed to get invitation details")

@router.post("/accept-invitation")
async def accept_invitation(body: AcceptInvitationRequest, user: AuthorizedUser) -> Dict[str, Any]:
    """Accept a team invitation"""
    try:
        conn = await get_db_connection()
        
        # Get invitation details
        invitation = await conn.fetchrow("""
            SELECT ti.*, c.company_name, c.max_team_members
            FROM team_invitations ti
            JOIN companies c ON ti.company_id = c.id
            WHERE ti.invitation_token = $1 AND ti.status = 'pending'
        """, body.invitation_token)
        
        if not invitation:
            raise HTTPException(status_code=404, detail="Invalid or expired invitation")
        
        # Check if invitation is expired
        if invitation['expires_at'] < datetime.now():
            # Mark as expired
            await conn.execute(
                "UPDATE team_invitations SET status = 'expired' WHERE id = $1",
                invitation['id']
            )
            raise HTTPException(status_code=400, detail="Invitation has expired")
        
        # Get user email from auth system
        user_info = await conn.fetchrow(
            "SELECT email FROM neon_auth.users_sync WHERE id = $1", user.sub
        )
        
        # Verify email matches invitation
        if not user_info or user_info['email'].lower() != invitation['email'].lower():
            raise HTTPException(status_code=403, detail="Invitation email does not match your account")
        
        # Check if user is already a member
        existing_membership = await conn.fetchval(
            "SELECT id FROM team_memberships WHERE company_id = $1 AND user_id = $2",
            invitation['company_id'], user.sub
        )
        
        if existing_membership:
            raise HTTPException(status_code=400, detail="You are already a member of this company")
        
        # Check team member limit
        current_members = await conn.fetchval(
            "SELECT COUNT(*) FROM team_memberships WHERE company_id = $1 AND status = 'active'",
            invitation['company_id']
        )
        
        if current_members >= invitation['max_team_members']:
            raise HTTPException(status_code=400, detail="Company has reached its team member limit")
        
        # Create team membership
        membership_id = await conn.fetchval("""
            INSERT INTO team_memberships 
            (company_id, user_id, role_id, status, invited_by, joined_at, created_at, updated_at)
            VALUES ($1, $2, $3, 'active', $4, $5, $6, $7)
            RETURNING id
        """, invitation['company_id'], user.sub, invitation['role_id'],
        invitation['invited_by'], datetime.now(), datetime.now(), datetime.now())
        
        # Mark invitation as accepted
        await conn.execute("""
            UPDATE team_invitations 
            SET status = 'accepted', accepted_at = $1
            WHERE id = $2
        """, datetime.now(), invitation['id'])
        
        # Log audit action
        await log_audit_action(invitation['company_id'], user.sub, "invitation_accepted", {
            "invitation_id": invitation['id'],
            "membership_id": membership_id,
            "role_id": invitation['role_id']
        }, conn)
        
        await conn.close()
        
        return {
            "success": True,
            "message": f"Successfully joined {invitation['company_name']}",
            "company_name": invitation['company_name'],
            "membership_id": membership_id
        }
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error accepting invitation: {e}")
        raise HTTPException(status_code=500, detail="Failed to accept invitation")

@router.post("/resend-invitation")
async def resend_invitation(body: ResendInvitationRequest, user: AuthorizedUser) -> Dict[str, Any]:
    """Resend a team invitation"""
    try:
        conn = await get_db_connection()
        
        # Get invitation details with permission check
        invitation = await conn.fetchrow("""
            SELECT ti.*, c.company_name, rd.role_name, rd.role_description,
                   inviter.email as invited_by_email, inviter.name as invited_by_name
            FROM team_invitations ti
            JOIN companies c ON ti.company_id = c.id
            JOIN role_definitions rd ON ti.role_id = rd.id
            LEFT JOIN neon_auth.users_sync inviter ON ti.invited_by = inviter.id
            WHERE ti.id = $1
        """, body.invitation_id)
        
        if not invitation:
            raise HTTPException(status_code=404, detail="Invitation not found")
        
        # Check if user has permission to resend
        user_role = await conn.fetchrow("""
            SELECT rd.permissions 
            FROM team_memberships tm
            JOIN role_definitions rd ON tm.role_id = rd.id
            WHERE tm.user_id = $1 AND tm.company_id = $2 AND tm.status = 'active'
        """, user.sub, invitation['company_id'])
        
        if not user_role or not user_role['permissions'].get('team_management', False):
            raise HTTPException(status_code=403, detail="Insufficient permissions")
        
        # Update invitation with new expiry and token
        new_token = secrets.token_urlsafe(32)
        new_expires_at = datetime.now() + timedelta(days=7)
        
        await conn.execute("""
            UPDATE team_invitations 
            SET invitation_token = $1, expires_at = $2, status = 'pending', message = $3
            WHERE id = $4
        """, new_token, new_expires_at, body.custom_message, body.invitation_id)
        
        # Prepare email data
        accept_url = f"https://app.respectus.com/accept-invitation?token={new_token}"
        
        email_data = EmailTemplateData(
            to_email=invitation['email'],
            to_name=None,  # We don't have the recipient's name
            company_name=invitation['company_name'],
            invited_by_name=invitation['invited_by_name'] or "Team Admin",
            invited_by_email=invitation['invited_by_email'] or "",
            role_name=invitation['role_name'],
            invitation_token=new_token,
            expires_at=new_expires_at.strftime('%B %d, %Y at %I:%M %p UTC'),
            custom_message=body.custom_message,
            accept_url=accept_url
        )
        
        # Send email
        email_sent = await send_invitation_email(email_data)
        
        # Log audit action
        await log_audit_action(invitation['company_id'], user.sub, "invitation_resent", {
            "invitation_id": body.invitation_id,
            "email": invitation['email'],
            "email_sent": email_sent
        }, conn)
        
        await conn.close()
        
        return {
            "success": True,
            "message": f"Invitation resent to {invitation['email']}",
            "email_sent": email_sent,
            "expires_at": new_expires_at.isoformat()
        }
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error resending invitation: {e}")
        raise HTTPException(status_code=500, detail="Failed to resend invitation")

@router.delete("/invitations/{invitation_id}")
async def cancel_invitation(invitation_id: int, user: AuthorizedUser) -> Dict[str, Any]:
    """Cancel a pending invitation"""
    try:
        conn = await get_db_connection()
        
        # Get invitation and check permissions
        invitation = await conn.fetchrow(
            "SELECT * FROM team_invitations WHERE id = $1", invitation_id
        )
        
        if not invitation:
            raise HTTPException(status_code=404, detail="Invitation not found")
        
        # Check permissions
        user_role = await conn.fetchrow("""
            SELECT rd.permissions 
            FROM team_memberships tm
            JOIN role_definitions rd ON tm.role_id = rd.id
            WHERE tm.user_id = $1 AND tm.company_id = $2 AND tm.status = 'active'
        """, user.sub, invitation['company_id'])
        
        if not user_role or not user_role['permissions'].get('team_management', False):
            raise HTTPException(status_code=403, detail="Insufficient permissions")
        
        # Mark invitation as declined/cancelled
        await conn.execute(
            "UPDATE team_invitations SET status = 'declined', declined_at = $1 WHERE id = $2",
            datetime.now(), invitation_id
        )
        
        # Log audit action
        await log_audit_action(invitation['company_id'], user.sub, "invitation_cancelled", {
            "invitation_id": invitation_id,
            "email": invitation['email']
        }, conn)
        
        await conn.close()
        
        return {
            "success": True,
            "message": "Invitation cancelled successfully"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error cancelling invitation: {e}")
        raise HTTPException(status_code=500, detail="Failed to cancel invitation")

@router.post("/send-invitation-email")
async def send_invitation_email_manually(
    invitation_id: int, 
    custom_message: Optional[str] = None,
    user: AuthorizedUser = None
) -> Dict[str, Any]:
    """Manually send invitation email (for testing or resending)"""
    try:
        conn = await get_db_connection()
        
        # Get invitation details
        invitation = await conn.fetchrow("""
            SELECT ti.*, c.company_name, rd.role_name, rd.role_description,
                   inviter.email as invited_by_email, inviter.name as invited_by_name
            FROM team_invitations ti
            JOIN companies c ON ti.company_id = c.id
            JOIN role_definitions rd ON ti.role_id = rd.id
            LEFT JOIN neon_auth.users_sync inviter ON ti.invited_by = inviter.id
            WHERE ti.id = $1
        """, invitation_id)
        
        if not invitation:
            raise HTTPException(status_code=404, detail="Invitation not found")
        
        # Check permissions if user provided
        if user:
            user_role = await conn.fetchrow("""
                SELECT rd.permissions 
                FROM team_memberships tm
                JOIN role_definitions rd ON tm.role_id = rd.id
                WHERE tm.user_id = $1 AND tm.company_id = $2 AND tm.status = 'active'
            """, user.sub, invitation['company_id'])
            
            if not user_role or not user_role['permissions'].get('team_management', False):
                raise HTTPException(status_code=403, detail="Insufficient permissions")
        
        # Prepare email data
        accept_url = f"https://app.respectus.com/accept-invitation?token={invitation['invitation_token']}"
        
        email_data = EmailTemplateData(
            to_email=invitation['email'],
            to_name=None,
            company_name=invitation['company_name'],
            invited_by_name=invitation['invited_by_name'] or "Team Admin",
            invited_by_email=invitation['invited_by_email'] or "",
            role_name=invitation['role_name'],
            invitation_token=invitation['invitation_token'],
            expires_at=invitation['expires_at'].strftime('%B %d, %Y at %I:%M %p UTC'),
            custom_message=custom_message or invitation['message'],
            accept_url=accept_url
        )
        
        # Send email
        email_sent = await send_invitation_email(email_data)
        
        await conn.close()
        
        return {
            "success": True,
            "email_sent": email_sent,
            "message": f"Email {'sent' if email_sent else 'failed to send'} to {invitation['email']}"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error sending invitation email: {e}")
        raise HTTPException(status_code=500, detail="Failed to send invitation email")
