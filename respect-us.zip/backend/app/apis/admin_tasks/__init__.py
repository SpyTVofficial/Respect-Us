from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Optional, List
from app.auth import AuthorizedUser
import databutton as db
import asyncpg
import json
from datetime import datetime

router = APIRouter(prefix="/admin-tasks")

class AdminTask(BaseModel):
    id: str
    title: str
    description: str
    type: str
    status: str
    submission_id: Optional[str] = None
    submitted_by: Optional[str] = None
    created_at: datetime
    updated_at: datetime

class TaskUpdateRequest(BaseModel):
    status: str
    notes: Optional[str] = None

class TaskResponse(BaseModel):
    success: bool
    message: str

@router.get("/list")
async def list_admin_tasks(user: AuthorizedUser) -> List[AdminTask]:
    """Get all admin validation tasks"""
    try:
        conn = await asyncpg.connect(db.secrets.get("DATABASE_URL_DEV"))
        try:
            tasks = await conn.fetch(
                """
                SELECT id, title, description, type, status, submission_id, submitted_by, created_at, updated_at
                FROM admin_tasks
                ORDER BY created_at DESC
                """
            )
            return [AdminTask(**dict(task)) for task in tasks]
        finally:
            await conn.close()
    except Exception as e:
        print(f"Error fetching admin tasks: {e}")
        raise HTTPException(status_code=500, detail="Failed to fetch admin tasks") from e

@router.get("/pending")
async def get_pending_tasks(user: AuthorizedUser) -> List[AdminTask]:
    """Get all pending validation tasks"""
    try:
        conn = await asyncpg.connect(db.secrets.get("DATABASE_URL_DEV"))
        try:
            tasks = await conn.fetch(
                """
                SELECT id, title, description, type, status, submission_id, submitted_by, created_at, updated_at
                FROM admin_tasks
                WHERE status = 'pending'
                ORDER BY created_at DESC
                """
            )
            return [AdminTask(**dict(task)) for task in tasks]
        finally:
            await conn.close()
    except Exception as e:
        print(f"Error fetching pending tasks: {e}")
        raise HTTPException(status_code=500, detail="Failed to fetch pending tasks") from e

@router.post("/update/{task_id}")
async def update_task(task_id: str, update_request: TaskUpdateRequest, user: AuthorizedUser) -> TaskResponse:
    """Update task status (approve/reject)"""
    try:
        conn = await asyncpg.connect(db.secrets.get("DATABASE_URL_DEV"))
        try:
            # Update task status
            await conn.execute(
                """
                UPDATE admin_tasks
                SET status = $1, updated_at = $2, reviewed_by = $3, review_notes = $4
                WHERE id = $5
                """,
                update_request.status,
                datetime.utcnow(),
                user.sub,
                update_request.notes,
                task_id
            )
            
            # Get the submission details
            task = await conn.fetchrow(
                "SELECT submission_id, type FROM admin_tasks WHERE id = $1",
                task_id
            )
            
            if task and task['submission_id']:
                # Update submission status based on task approval
                submission_status = 'approved' if update_request.status == 'approved' else 'rejected'
                await conn.execute(
                    """
                    UPDATE user_submissions
                    SET status = $1, updated_at = $2
                    WHERE id = $3
                    """,
                    submission_status,
                    datetime.utcnow(),
                    task['submission_id']
                )
                
                # If approved, move content to appropriate published table
                if update_request.status == 'approved':
                    await move_to_published_content(conn, task['submission_id'], task['type'])
            
            return TaskResponse(
                success=True,
                message=f"Task {update_request.status} successfully"
            )
        finally:
            await conn.close()
    except Exception as e:
        print(f"Error updating task: {e}")
        raise HTTPException(status_code=500, detail="Failed to update task") from e

async def move_to_published_content(conn, submission_id: str, submission_type: str):
    """Move approved content to published tables"""
    try:
        # Get submission details
        submission = await conn.fetchrow(
            "SELECT * FROM user_submissions WHERE id = $1",
            submission_id
        )
        
        if not submission:
            return
        
        if submission_type == 'blog_validation':
            # Move to blog_documents table
            metadata = json.loads(submission['metadata'] or '{}')
            await conn.execute(
                """
                INSERT INTO blog_documents (title, content, summary, tags, author_id, created_at, updated_at)
                VALUES ($1, $2, $3, $4, $5, $6, $7)
                """,
                submission['title'],
                submission['content'],
                metadata.get('summary'),
                metadata.get('tags'),
                submission['submitted_by'],
                datetime.utcnow(),
                datetime.utcnow()
            )
        elif submission_type in ['document_validation', 'case_study_validation']:
            # Move to documents table
            document_type = 'case_study' if submission_type == 'case_study_validation' else 'document'
            await conn.execute(
                """
                INSERT INTO documents (title, description, content_text, document_type, metadata, created_at, updated_at)
                VALUES ($1, $2, $3, $4, $5, $6, $7)
                """,
                submission['title'],
                submission['content'],
                submission['content'],  # Use content as content_text
                document_type,
                submission['metadata'],
                datetime.utcnow(),
                datetime.utcnow()
            )
    except Exception as e:
        print(f"Error moving content to published: {e}")
