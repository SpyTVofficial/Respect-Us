
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import List, Optional
import asyncpg
import databutton as db
from app.auth import AuthorizedUser
from app.env import Mode, mode
from datetime import datetime

router = APIRouter(prefix="/badges")

# Pydantic models for badge management
class CreateBadgeRequest(BaseModel):
    name: str
    description: Optional[str] = None
    color: str = "#3b82f6"
    category: str = "custom"
    is_active: bool = True
    sort_order: int = 0

class UpdateBadgeRequest(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    color: Optional[str] = None
    category: Optional[str] = None
    is_active: Optional[bool] = None
    sort_order: Optional[int] = None

class BadgeResponse(BaseModel):
    id: int
    name: str
    description: Optional[str]
    color: str
    category: str
    is_active: bool
    sort_order: int
    created_by: str
    created_at: datetime
    updated_at: datetime

class BadgeListResponse(BaseModel):
    badges: List[BadgeResponse]
    total: int

# Database connection helper
async def get_db_connection():
    """Get database connection"""
    database_url = db.secrets.get("DATABASE_URL_DEV")
    return await asyncpg.connect(database_url)

@router.post("/badges", response_model=BadgeResponse)
async def create_badge(request: CreateBadgeRequest, user: AuthorizedUser):
    """Create a new badge"""
    conn = await get_db_connection()
    try:
        # Check if badge name already exists
        existing = await conn.fetchrow(
            "SELECT id FROM document_badges WHERE name = $1",
            request.name
        )
        if existing:
            raise HTTPException(status_code=400, detail="Badge name already exists")
        
        # Insert new badge
        badge_id = await conn.fetchval(
            """
            INSERT INTO document_badges (name, description, color, category, is_active, sort_order, created_by)
            VALUES ($1, $2, $3, $4, $5, $6, $7)
            RETURNING id
            """,
            request.name,
            request.description,
            request.color,
            request.category,
            request.is_active,
            request.sort_order,
            user.sub
        )
        
        # Fetch the created badge
        badge = await conn.fetchrow(
            """
            SELECT id, name, description, color, category, is_active, sort_order, 
                   created_by, created_at, updated_at
            FROM document_badges WHERE id = $1
            """,
            badge_id
        )
        
        return BadgeResponse(**dict(badge))
        
    finally:
        await conn.close()

@router.get("/badges", response_model=BadgeListResponse)
async def list_badges(user: AuthorizedUser):
    """List all badges"""
    conn = await get_db_connection()
    try:
        badges = await conn.fetch(
            """
            SELECT id, name, description, color, category, is_active, sort_order,
                   created_by, created_at, updated_at
            FROM document_badges
            ORDER BY category, sort_order, name
            """
        )
        
        badge_list = [BadgeResponse(**dict(badge)) for badge in badges]
        return BadgeListResponse(badges=badge_list, total=len(badge_list))
        
    finally:
        await conn.close()

@router.get("/badges/{badge_id}", response_model=BadgeResponse)
async def get_badge(badge_id: int, user: AuthorizedUser):
    """Get a specific badge by ID"""
    conn = await get_db_connection()
    try:
        badge = await conn.fetchrow(
            """
            SELECT id, name, description, color, category, is_active, sort_order,
                   created_by, created_at, updated_at
            FROM document_badges WHERE id = $1
            """,
            badge_id
        )
        
        if not badge:
            raise HTTPException(status_code=404, detail="Badge not found")
            
        return BadgeResponse(**dict(badge))
        
    finally:
        await conn.close()

@router.put("/badges/{badge_id}", response_model=BadgeResponse)
async def update_badge(badge_id: int, request: UpdateBadgeRequest, user: AuthorizedUser):
    """Update a badge"""
    conn = await get_db_connection()
    try:
        # Check if badge exists
        existing = await conn.fetchrow(
            "SELECT id, name FROM document_badges WHERE id = $1",
            badge_id
        )
        if not existing:
            raise HTTPException(status_code=404, detail="Badge not found")
        
        # Check if new name conflicts with existing badge (if name is being updated)
        if request.name and request.name != existing['name']:
            name_conflict = await conn.fetchrow(
                "SELECT id FROM document_badges WHERE name = $1 AND id != $2",
                request.name, badge_id
            )
            if name_conflict:
                raise HTTPException(status_code=400, detail="Badge name already exists")
        
        # Build update query dynamically
        update_fields = []
        update_values = []
        param_count = 1
        
        if request.name is not None:
            update_fields.append(f"name = ${param_count}")
            update_values.append(request.name)
            param_count += 1
            
        if request.description is not None:
            update_fields.append(f"description = ${param_count}")
            update_values.append(request.description)
            param_count += 1
            
        if request.color is not None:
            update_fields.append(f"color = ${param_count}")
            update_values.append(request.color)
            param_count += 1
            
        if request.category is not None:
            update_fields.append(f"category = ${param_count}")
            update_values.append(request.category)
            param_count += 1
            
        if request.is_active is not None:
            update_fields.append(f"is_active = ${param_count}")
            update_values.append(request.is_active)
            param_count += 1
            
        if request.sort_order is not None:
            update_fields.append(f"sort_order = ${param_count}")
            update_values.append(request.sort_order)
            param_count += 1
        
        if not update_fields:
            raise HTTPException(status_code=400, detail="No fields to update")
        
        # Add updated_at and badge_id to the query
        update_fields.append(f"updated_at = ${param_count}")
        update_values.append(datetime.utcnow())
        param_count += 1
        
        update_values.append(badge_id)
        
        query = f"""
            UPDATE document_badges 
            SET {', '.join(update_fields)}
            WHERE id = ${param_count}
            RETURNING id, name, description, color, category, is_active, sort_order,
                      created_by, created_at, updated_at
        """
        
        updated_badge = await conn.fetchrow(query, *update_values)
        return BadgeResponse(**dict(updated_badge))
        
    finally:
        await conn.close()

@router.delete("/badges/{badge_id}")
async def delete_badge(badge_id: int, user: AuthorizedUser):
    """Delete a badge"""
    conn = await get_db_connection()
    try:
        # Check if badge exists
        existing = await conn.fetchrow(
            "SELECT id FROM document_badges WHERE id = $1",
            badge_id
        )
        if not existing:
            raise HTTPException(status_code=404, detail="Badge not found")
        
        # Check if badge is being used by any documents
        usage_count = await conn.fetchval(
            "SELECT COUNT(*) FROM knowledge_base_documents WHERE badge = (SELECT name FROM document_badges WHERE id = $1)",
            badge_id
        )
        
        if usage_count > 0:
            raise HTTPException(
                status_code=400, 
                detail=f"Cannot delete badge: it is currently used by {usage_count} document(s)"
            )
        
        # Delete the badge
        await conn.execute(
            "DELETE FROM document_badges WHERE id = $1",
            badge_id
        )
        
        return {"message": "Badge deleted successfully"}
        
    finally:
        await conn.close()

@router.get("/badges/categories", response_model=List[str])
async def list_badge_categories(user: AuthorizedUser):
    """List all badge categories"""
    return ["priority", "status", "type", "subject", "custom"]
