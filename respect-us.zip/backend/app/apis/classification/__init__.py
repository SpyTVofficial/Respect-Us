from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
from uuid import UUID
from datetime import datetime
import databutton as db
import asyncpg
import json
from app.env import Mode, mode
from app.auth import AuthorizedUser
from app.libs.routing_parser import parse_routing_rule

router = APIRouter(prefix="/classification")

# Database connection
async def get_db_connection():
    if mode == Mode.PROD:
        database_url = db.secrets.get("DATABASE_URL_PROD")
    else:
        database_url = db.secrets.get("DATABASE_URL_DEV")
    return await asyncpg.connect(database_url)

# Multi-Question Assessment Models (defined first to avoid forward references)
class MultiQuestionItem(BaseModel):
    """Individual question within a multi-question assessment"""
    key: str = Field(..., max_length=100, description="Unique identifier for this question within the node")
    text: str = Field(..., description="The question text")
    order: int = Field(default=0, description="Display order of the question")
    regulatory_notes: Optional[List[str]] = Field(None, description="Array of regulatory note keys for this question")

class OutcomeRule(BaseModel):
    """Rule for determining outcome based on response patterns"""
    name: str = Field(..., max_length=255, description="Name of the rule")
    description: Optional[str] = Field(None, description="Description of what this rule does")
    logic: Dict[str, Any] = Field(..., description="Logic conditions like {'yes_count': 2, 'no_count': {'max': 1}}")
    target: str = Field(..., max_length=255, description="Where to route (node_key or outcome_code)")
    target_type: str = Field(default="node", description="Type of target: 'node' or 'outcome'")
    priority: int = Field(default=0, description="Higher priority rules are evaluated first")

class MultiQuestionAssessmentRequest(BaseModel):
    """Request for answering a multi-question assessment"""
    responses: Dict[str, bool] = Field(..., description="Map of question_key to yes/no (true/false) responses")

class MultiQuestionAssessmentResponse(BaseModel):
    """Response after evaluating a multi-question assessment"""
    matched_rule: Optional[OutcomeRule] = None
    routing_target: Optional[str] = None
    routing_type: Optional[str] = None
    yes_count: int
    no_count: int
    total_questions: int

# ============================================================================
# Pydantic Models for Classification Trees
# ============================================================================

class ClassificationTreeCreate(BaseModel):
    name: str = Field(..., max_length=255)
    description: Optional[str] = None
    jurisdiction: str = Field(..., max_length=100)
    category: str = Field(..., max_length=100)
    introduction_tree_id: Optional[UUID] = None
    is_introduction_template: bool = False

class ClassificationTreeUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    jurisdiction: Optional[str] = None
    category: Optional[str] = None
    version: Optional[int] = None
    status: Optional[str] = None
    introduction_tree_id: Optional[UUID] = None
    is_introduction_template: Optional[bool] = None

class ClassificationTree(BaseModel):
    id: UUID
    name: str
    description: Optional[str]
    jurisdiction: str
    category: str
    version: int
    status: str
    created_by: Optional[str]
    created_at: datetime
    updated_at: datetime
    published_at: Optional[datetime]
    introduction_tree_id: Optional[UUID]
    is_introduction_template: bool

class TreeNodeCreate(BaseModel):
    node_key: str = Field(..., max_length=50)
    title: str = Field(..., max_length=500)
    description: Optional[str] = None
    question_text: str
    question_type: str = Field(default="multiple_choice")
    is_root: bool = False
    parent_node_id: Optional[UUID] = None
    display_order: int = 0
    notes: Optional[str]
    # Multi-question assessment fields
    multi_questions: Optional[List[MultiQuestionItem]] = Field(None, description="Questions for multi_question_assessment type")
    outcome_rules: Optional[List[OutcomeRule]] = Field(None, description="Outcome rules for multi_question_assessment type")

class TreeNodeUpdate(BaseModel):
    node_key: Optional[str] = None
    title: Optional[str] = None
    description: Optional[str] = None
    question_text: Optional[str] = None
    question_type: Optional[str] = None
    display_order: Optional[int] = None
    notes: Optional[str]
    # Multi-question assessment fields
    multi_questions: Optional[List[MultiQuestionItem]] = Field(None, description="Questions for multi_question_assessment type")
    outcome_rules: Optional[List[OutcomeRule]] = Field(None, description="Outcome rules for multi_question_assessment type")

class TreeNode(BaseModel):
    id: UUID
    tree_id: UUID
    node_key: str
    title: str
    description: Optional[str]
    question_text: str
    question_type: str
    is_root: bool
    parent_node_id: Optional[UUID]
    display_order: int
    notes: Optional[str]
    created_at: datetime
    updated_at: datetime
    # Multi-question assessment fields
    multi_questions: Optional[List[MultiQuestionItem]] = Field(None, description="Questions for multi_question_assessment type")
    outcome_rules: Optional[List[OutcomeRule]] = Field(None, description="Outcome rules for multi_question_assessment type")

class NodeOptionCreate(BaseModel):
    option_text: str
    option_value: str = Field(..., max_length=255)
    routing_rule: Optional[str] = Field(None, max_length=500)
    regulatory_notes: Optional[List[str]] = None
    display_order: int = 0
    note: Optional[str] = None

class NodeOptionUpdate(BaseModel):
    option_text: Optional[str] = None
    option_value: Optional[str] = None
    routing_rule: Optional[str] = None
    regulatory_notes: Optional[List[str]] = None
    display_order: Optional[int] = None
    note: Optional[str] = None

class NodeOption(BaseModel):
    id: UUID
    node_id: UUID
    option_text: str
    option_value: str
    routing_rule: Optional[str]
    regulatory_notes: Optional[List[str]]
    display_order: int
    note: Optional[str]
    created_at: datetime

class ClassificationOutcomeCreate(BaseModel):
    outcome_code: str = Field(..., max_length=100)
    outcome_title: str = Field(..., max_length=255)
    description: Optional[str] = None
    regulatory_basis: Optional[str] = None
    outcome_text: str
    is_controlled: Optional[bool] = False
    guidance_notes: Optional[str] = None

class ClassificationOutcomeUpdate(BaseModel):
    outcome_code: Optional[str] = Field(None, max_length=100)
    outcome_title: Optional[str] = Field(None, max_length=255)
    description: Optional[str] = None
    regulatory_basis: Optional[str] = None
    outcome_text: Optional[str] = None
    is_controlled: Optional[bool] = None
    guidance_notes: Optional[str] = None

class ClassificationOutcome(BaseModel):
    id: UUID
    tree_id: Optional[UUID] = None
    outcome_code: str
    outcome_title: str
    description: Optional[str]
    regulatory_basis: Optional[str]
    outcome_text: str
    is_controlled: Optional[bool] = False
    guidance_notes: Optional[str] = None
    created_at: datetime

class UserClassificationSubmit(BaseModel):
    tree_id: UUID
    item_name: Optional[str] = None
    item_description: Optional[str] = None
    answers: Dict[str, Any]

class UserClassification(BaseModel):
    id: UUID
    user_id: Optional[UUID]
    tree_id: UUID
    item_name: Optional[str]
    item_description: Optional[str]
    classification_path: Optional[Dict[str, Any]]
    answers: Optional[Dict[str, Any]]
    final_outcome_id: Optional[UUID]
    final_classification: Optional[str]
    confidence_level: Optional[int]
    documents_uploaded: Optional[List[str]]
    status: str
    created_at: datetime
    completed_at: Optional[datetime]

class NavigationRequest(BaseModel):
    option_id: UUID
    option_value: str

# Form Field Models for configurable initial questions
class TreeFormFieldCreate(BaseModel):
    field_key: str = Field(..., max_length=100)
    field_label: str = Field(..., max_length=255)
    field_type: str = Field(default="text")  # text, textarea, select, number, email, tel
    field_description: Optional[str] = None
    placeholder_text: Optional[str] = None
    is_required: bool = False
    display_order: int = 0
    validation_rules: Dict[str, Any] = {}
    field_options: List[str] = []  # For select fields

class TreeFormFieldUpdate(BaseModel):
    field_label: Optional[str] = None
    field_type: Optional[str] = None
    field_description: Optional[str] = None
    placeholder_text: Optional[str] = None
    is_required: Optional[bool] = None
    display_order: Optional[int] = None
    validation_rules: Optional[Dict[str, Any]] = None
    field_options: Optional[List[str]] = None

class TreeFormField(BaseModel):
    id: int
    tree_id: UUID
    field_key: str
    field_label: str
    field_type: str
    field_description: Optional[str]
    placeholder_text: Optional[str]
    is_required: bool
    display_order: int
    validation_rules: Dict[str, Any]
    field_options: List[str]
    created_at: datetime
    updated_at: datetime

# ============================================================================
# Form Field Management Endpoints
# ============================================================================

@router.get("/tree/{tree_id}/form-fields", response_model=List[TreeFormField])
async def get_tree_form_fields(
    tree_id: UUID,
    user: AuthorizedUser
) -> List[TreeFormField]:
    """Get all form fields for a classification tree"""
    conn = await get_db_connection()
    try:
        # Check if tree exists
        tree_exists = await conn.fetchval(
            "SELECT EXISTS(SELECT 1 FROM classification_trees WHERE id = $1)",
            tree_id
        )
        if not tree_exists:
            raise HTTPException(status_code=404, detail="Classification tree not found")
        
        # Get form fields
        fields = await conn.fetch("""
            SELECT id, tree_id, field_key, field_label, field_type, field_description,
                   placeholder_text, is_required, display_order, validation_rules, 
                   field_options, created_at, updated_at
            FROM classification_tree_form_fields
            WHERE tree_id = $1
            ORDER BY display_order, id
        """, tree_id)
        
        return [
            TreeFormField(
                id=field['id'],
                tree_id=field['tree_id'],
                field_key=field['field_key'],
                field_label=field['field_label'],
                field_type=field['field_type'],
                field_description=field['field_description'],
                placeholder_text=field['placeholder_text'],
                is_required=field['is_required'],
                display_order=field['display_order'],
                validation_rules=field['validation_rules'] or {},
                field_options=field['field_options'] or [],
                created_at=field['created_at'],
                updated_at=field['updated_at']
            )
            for field in fields
        ]
        
    finally:
        await conn.close()

@router.post("/tree/{tree_id}/form-fields", response_model=TreeFormField)
async def create_tree_form_field(
    tree_id: UUID,
    field_data: TreeFormFieldCreate,
    user: AuthorizedUser
) -> TreeFormField:
    """Create a new form field for a classification tree"""
    conn = await get_db_connection()
    try:
        # Check if tree exists
        tree_exists = await conn.fetchval(
            "SELECT EXISTS(SELECT 1 FROM classification_trees WHERE id = $1)",
            tree_id
        )
        if not tree_exists:
            raise HTTPException(status_code=404, detail="Classification tree not found")
        
        # Check if field_key already exists for this tree
        key_exists = await conn.fetchval(
            "SELECT EXISTS(SELECT 1 FROM classification_tree_form_fields WHERE tree_id = $1 AND field_key = $2)",
            tree_id, field_data.field_key
        )
        if key_exists:
            raise HTTPException(status_code=400, detail=f"Field key '{field_data.field_key}' already exists for this tree")
        
        # Create the form field
        field_id = await conn.fetchval("""
            INSERT INTO classification_tree_form_fields (
                tree_id, field_key, field_label, field_type, field_description,
                placeholder_text, is_required, display_order, validation_rules, field_options
            ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
            RETURNING id
        """, 
            tree_id, field_data.field_key, field_data.field_label, field_data.field_type,
            field_data.field_description, field_data.placeholder_text, field_data.is_required,
            field_data.display_order, json.dumps(field_data.validation_rules), 
            json.dumps(field_data.field_options)
        )
        
        # Get the created field
        field = await conn.fetchrow("""
            SELECT id, tree_id, field_key, field_label, field_type, field_description,
                   placeholder_text, is_required, display_order, validation_rules, 
                   field_options, created_at, updated_at
            FROM classification_tree_form_fields
            WHERE id = $1
        """, field_id)
        
        return TreeFormField(
            id=field['id'],
            tree_id=field['tree_id'],
            field_key=field['field_key'],
            field_label=field['field_label'],
            field_type=field['field_type'],
            field_description=field['field_description'],
            placeholder_text=field['placeholder_text'],
            is_required=field['is_required'],
            display_order=field['display_order'],
            validation_rules=field['validation_rules'] or {},
            field_options=field['field_options'] or [],
            created_at=field['created_at'],
            updated_at=field['updated_at']
        )
        
    finally:
        await conn.close()

@router.put("/tree/{tree_id}/form-fields/{field_id}", response_model=TreeFormField)
async def update_tree_form_field(
    tree_id: UUID,
    field_id: int,
    field_data: TreeFormFieldUpdate,
    user: AuthorizedUser
) -> TreeFormField:
    """Update a form field for a classification tree"""
    conn = await get_db_connection()
    try:
        # Check if field exists and belongs to the tree
        field_exists = await conn.fetchval(
            "SELECT EXISTS(SELECT 1 FROM classification_tree_form_fields WHERE id = $1 AND tree_id = $2)",
            field_id, tree_id
        )
        if not field_exists:
            raise HTTPException(status_code=404, detail="Form field not found")
        
        # Build update query dynamically
        update_fields = []
        params = []
        param_count = 1
        
        if field_data.field_label is not None:
            update_fields.append(f"field_label = ${param_count}")
            params.append(field_data.field_label)
            param_count += 1
            
        if field_data.field_type is not None:
            update_fields.append(f"field_type = ${param_count}")
            params.append(field_data.field_type)
            param_count += 1
            
        if field_data.field_description is not None:
            update_fields.append(f"field_description = ${param_count}")
            params.append(field_data.field_description)
            param_count += 1
            
        if field_data.placeholder_text is not None:
            update_fields.append(f"placeholder_text = ${param_count}")
            params.append(field_data.placeholder_text)
            param_count += 1
            
        if field_data.is_required is not None:
            update_fields.append(f"is_required = ${param_count}")
            params.append(field_data.is_required)
            param_count += 1
            
        if field_data.display_order is not None:
            update_fields.append(f"display_order = ${param_count}")
            params.append(field_data.display_order)
            param_count += 1
            
        if field_data.validation_rules is not None:
            update_fields.append(f"validation_rules = ${param_count}")
            params.append(json.dumps(field_data.validation_rules))
            param_count += 1
            
        if field_data.field_options is not None:
            update_fields.append(f"field_options = ${param_count}")
            params.append(json.dumps(field_data.field_options))
            param_count += 1
        
        if not update_fields:
            raise HTTPException(status_code=400, detail="No fields to update")
        
        # Add updated_at
        update_fields.append(f"updated_at = ${param_count}")
        params.append(datetime.utcnow())
        param_count += 1
        
        # Add field_id for WHERE clause
        params.append(field_id)
        
        # Execute update
        await conn.execute(f"""
            UPDATE classification_tree_form_fields 
            SET {', '.join(update_fields)}
            WHERE id = ${param_count}
        """, *params)
        
        # Get updated field
        field = await conn.fetchrow("""
            SELECT id, tree_id, field_key, field_label, field_type, field_description,
                   placeholder_text, is_required, display_order, validation_rules, 
                   field_options, created_at, updated_at
            FROM classification_tree_form_fields
            WHERE id = $1
        """, field_id)
        
        return TreeFormField(
            id=field['id'],
            tree_id=field['tree_id'],
            field_key=field['field_key'],
            field_label=field['field_label'],
            field_type=field['field_type'],
            field_description=field['field_description'],
            placeholder_text=field['placeholder_text'],
            is_required=field['is_required'],
            display_order=field['display_order'],
            validation_rules=field['validation_rules'] or {},
            field_options=field['field_options'] or [],
            created_at=field['created_at'],
            updated_at=field['updated_at']
        )
        
    finally:
        await conn.close()

@router.delete("/tree/{tree_id}/form-fields/{field_id}")
async def delete_tree_form_field(
    tree_id: UUID,
    field_id: int,
    user: AuthorizedUser
) -> Dict[str, str]:
    """Delete a form field from a classification tree"""
    conn = await get_db_connection()
    try:
        # Check if field exists and belongs to the tree
        field_exists = await conn.fetchval(
            "SELECT EXISTS(SELECT 1 FROM classification_tree_form_fields WHERE id = $1 AND tree_id = $2)",
            field_id, tree_id
        )
        if not field_exists:
            raise HTTPException(status_code=404, detail="Form field not found")
        
        # Delete the field
        await conn.execute(
            "DELETE FROM classification_tree_form_fields WHERE id = $1",
            field_id
        )
        
        return {"message": "Form field deleted successfully"}
        
    finally:
        await conn.close()

# ============================================================================
# Admin Endpoints - Classification Trees
# ============================================================================

@router.get("/admin/trees", response_model=List[ClassificationTree])
async def list_classification_trees(user: AuthorizedUser):
    """List all classification trees for admin management"""
    conn = await get_db_connection()
    try:
        rows = await conn.fetch("""
            SELECT id, name, description, jurisdiction, category, version, status,
                   created_by, created_at, updated_at, published_at, introduction_tree_id, is_introduction_template
            FROM classification_trees
            ORDER BY created_at DESC
        """)
        
        trees = []
        for row in rows:
            trees.append(ClassificationTree(
                id=row['id'],
                name=row['name'],
                description=row['description'],
                jurisdiction=row['jurisdiction'],
                category=row['category'],
                version=row['version'],
                status=row['status'],
                created_by=row['created_by'],
                created_at=row['created_at'],
                updated_at=row['updated_at'],
                published_at=row['published_at'],
                introduction_tree_id=row['introduction_tree_id'],
                is_introduction_template=row['is_introduction_template']
            ))
        
        return trees
    finally:
        await conn.close()

@router.post("/admin/trees", response_model=ClassificationTree)
async def create_classification_tree(tree_data: ClassificationTreeCreate, user: AuthorizedUser):
    """Create a new classification tree"""
    conn = await get_db_connection()
    try:
        row = await conn.fetchrow("""
            INSERT INTO classification_trees (name, description, jurisdiction, category, created_by, introduction_tree_id, is_introduction_template)
            VALUES ($1, $2, $3, $4, $5, $6, $7)
            RETURNING id, name, description, jurisdiction, category, version, status,
                      created_by, created_at, updated_at, published_at, introduction_tree_id, is_introduction_template
        """, tree_data.name, tree_data.description, tree_data.jurisdiction, 
             tree_data.category, user.sub, tree_data.introduction_tree_id, tree_data.is_introduction_template)
        
        return ClassificationTree(
            id=row['id'],
            name=row['name'],
            description=row['description'],
            jurisdiction=row['jurisdiction'],
            category=row['category'],
            version=row['version'],
            status=row['status'],
            created_by=row['created_by'],
            created_at=row['created_at'],
            updated_at=row['updated_at'],
            published_at=row['published_at'],
            introduction_tree_id=row['introduction_tree_id'],
            is_introduction_template=row['is_introduction_template']
        )
    finally:
        await conn.close()

@router.get("/admin/trees/{tree_id}", response_model=ClassificationTree)
async def get_classification_tree(tree_id: UUID, user: AuthorizedUser):
    """Get a specific classification tree"""
    conn = await get_db_connection()
    try:
        row = await conn.fetchrow("""
            SELECT id, name, description, jurisdiction, category, version, status,
                   created_by, created_at, updated_at, published_at, introduction_tree_id, is_introduction_template
            FROM classification_trees
            WHERE id = $1
        """, tree_id)
        
        if not row:
            raise HTTPException(status_code=404, detail="Classification tree not found")
        
        return ClassificationTree(
            id=row['id'],
            name=row['name'],
            description=row['description'],
            jurisdiction=row['jurisdiction'],
            category=row['category'],
            version=row['version'],
            status=row['status'],
            created_by=row['created_by'],
            created_at=row['created_at'],
            updated_at=row['updated_at'],
            published_at=row['published_at'],
            introduction_tree_id=row['introduction_tree_id'],
            is_introduction_template=row['is_introduction_template']
        )
    finally:
        await conn.close()

@router.put("/admin/trees/{tree_id}", response_model=ClassificationTree)
async def update_classification_tree(tree_id: UUID, tree_data: ClassificationTreeUpdate, user: AuthorizedUser):
    """Update a classification tree"""
    conn = await get_db_connection()
    try:
        # Build dynamic update query
        updates = []
        values = []
        param_count = 1
        
        if tree_data.name is not None:
            updates.append(f"name = ${param_count}")
            values.append(tree_data.name)
            param_count += 1
            
        if tree_data.description is not None:
            updates.append(f"description = ${param_count}")
            values.append(tree_data.description)
            param_count += 1
            
        if tree_data.jurisdiction is not None:
            updates.append(f"jurisdiction = ${param_count}")
            values.append(tree_data.jurisdiction)
            param_count += 1
            
        if tree_data.category is not None:
            updates.append(f"category = ${param_count}")
            values.append(tree_data.category)
            param_count += 1
            
        if tree_data.version is not None:
            updates.append(f"version = ${param_count}")
            values.append(tree_data.version)
            param_count += 1
            
        if tree_data.status is not None:
            updates.append(f"status = ${param_count}")
            values.append(tree_data.status)
            param_count += 1
            
        if tree_data.introduction_tree_id is not None:
            updates.append(f"introduction_tree_id = ${param_count}")
            values.append(tree_data.introduction_tree_id)
            param_count += 1
            
        if tree_data.is_introduction_template is not None:
            updates.append(f"is_introduction_template = ${param_count}")
            values.append(tree_data.is_introduction_template)
            param_count += 1
        
        updates.append(f"updated_at = ${param_count}")
        values.append(datetime.utcnow())
        param_count += 1
        
        values.append(tree_id)
        
        if not updates[:-1]:  # Exclude the updated_at update
            raise HTTPException(status_code=400, detail="No valid fields to update")
        
        query = f"""
            UPDATE classification_trees 
            SET {', '.join(updates)}
            WHERE id = ${param_count}
            RETURNING id, name, description, jurisdiction, category, version, status,
                      created_by, created_at, updated_at, published_at, introduction_tree_id, is_introduction_template
        """
        
        row = await conn.fetchrow(query, *values)
        
        if not row:
            raise HTTPException(status_code=404, detail="Classification tree not found")
        
        return ClassificationTree(
            id=row['id'],
            name=row['name'],
            description=row['description'],
            jurisdiction=row['jurisdiction'],
            category=row['category'],
            version=row['version'],
            status=row['status'],
            created_by=row['created_by'],
            created_at=row['created_at'],
            updated_at=row['updated_at'],
            published_at=row['published_at'],
            introduction_tree_id=row['introduction_tree_id'],
            is_introduction_template=row['is_introduction_template']
        )
    finally:
        await conn.close()

@router.delete("/admin/trees/{tree_id}")
async def delete_classification_tree(tree_id: UUID, user: AuthorizedUser):
    """Delete a classification tree and all its related data"""
    conn = await get_db_connection()
    try:
        # Check if tree exists
        tree = await conn.fetchrow("""
            SELECT id, name FROM classification_trees WHERE id = $1
        """, tree_id)
        
        if not tree:
            raise HTTPException(status_code=404, detail="Classification tree not found")
        
        # Delete in correct order to avoid foreign key constraints
        await conn.execute("DELETE FROM user_classifications WHERE tree_id = $1", tree_id)
        await conn.execute("DELETE FROM classification_outcomes WHERE tree_id = $1", tree_id)
        
        # Delete node options first, then nodes
        await conn.execute("""
            DELETE FROM node_options 
            WHERE node_id IN (SELECT id FROM tree_nodes WHERE tree_id = $1)
        """, tree_id)
        await conn.execute("DELETE FROM tree_nodes WHERE tree_id = $1", tree_id)
        
        # Finally delete the tree
        await conn.execute("DELETE FROM classification_trees WHERE id = $1", tree_id)
        
        return {"message": f"Classification tree '{tree['name']}' deleted successfully"}
    finally:
        await conn.close()

@router.post("/admin/trees/{tree_id}/duplicate", response_model=ClassificationTree)
async def duplicate_classification_tree(tree_id: UUID, user: AuthorizedUser):
    """Duplicate a classification tree with all its nodes and options"""
    conn = await get_db_connection()
    try:
        # Get original tree
        original_tree = await conn.fetchrow("""
            SELECT name, description, jurisdiction, category, introduction_tree_id, is_introduction_template
            FROM classification_trees WHERE id = $1
        """, tree_id)
        
        if not original_tree:
            raise HTTPException(status_code=404, detail="Classification tree not found")
        
        # Create new tree with "Copy of" prefix
        new_tree_name = f"Copy of {original_tree['name']}"
        new_tree = await conn.fetchrow("""
            INSERT INTO classification_trees (name, description, jurisdiction, category, created_by, introduction_tree_id, is_introduction_template)
            VALUES ($1, $2, $3, $4, $5, $6, $7)
            RETURNING id, name, description, jurisdiction, category, version, status,
                      created_by, created_at, updated_at, published_at, introduction_tree_id, is_introduction_template
        """, new_tree_name, original_tree['description'], original_tree['jurisdiction'], 
             original_tree['category'], user.sub, original_tree['introduction_tree_id'], original_tree['is_introduction_template'])
        
        new_tree_id = new_tree['id']
        
        # Copy all nodes
        nodes = await conn.fetch("""
            SELECT node_key, title, description, question_text, question_type, 
                   is_root, display_order
            FROM tree_nodes 
            WHERE tree_id = $1
            ORDER BY display_order
        """, tree_id)
        
        node_id_mapping = {}  # Map old node IDs to new node IDs
        
        for node in nodes:
            new_node = await conn.fetchrow("""
                INSERT INTO tree_nodes (tree_id, node_key, title, description, question_text, 
                                      question_type, is_root, display_order)
                VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
                RETURNING id
            """, new_tree_id, node['node_key'], node['title'], node['description'],
                 node['question_text'], node['question_type'], node['is_root'], node['display_order'])
            
            # Get original node ID for mapping
            original_node = await conn.fetchrow("""
                SELECT id FROM tree_nodes 
                WHERE tree_id = $1 AND node_key = $2
            """, tree_id, node['node_key'])
            
            node_id_mapping[original_node['id']] = new_node['id']
        
        # Copy all node options
        for old_node_id, new_node_id in node_id_mapping.items():
            options = await conn.fetch("""
                SELECT option_text, option_value, routing_rule, regulatory_notes, display_order
                FROM node_options 
                WHERE node_id = $1
                ORDER BY display_order
            """, old_node_id)
            
            for option in options:
                await conn.execute("""
                    INSERT INTO node_options (node_id, option_text, option_value, routing_rule, 
                                            regulatory_notes, display_order)
                    VALUES ($1, $2, $3, $4, $5, $6)
                """, new_node_id, option['option_text'], option['option_value'],
                     option['routing_rule'], option['regulatory_notes'], option['display_order'])
        
        # Copy all classification outcomes
        outcomes = await conn.fetch("""
            SELECT outcome_code, outcome_title, description, regulatory_basis, outcome_text
            FROM classification_outcomes 
            WHERE tree_id = $1
        """, tree_id)
        
        for outcome in outcomes:
            # Create unique outcome code for the copied tree
            # Extract suffix from tree name (e.g., "Copy of EU Spacecraft" -> "_copy")
            tree_suffix = "_copy" if "Copy of" in new_tree_name else ""
            new_outcome_code = f"{outcome['outcome_code']}{tree_suffix}"
            
            # If outcome code already exists, append a number
            existing_outcome = await conn.fetchrow("""
                SELECT id FROM classification_outcomes 
                WHERE outcome_code = $1
            """, new_outcome_code)
            
            counter = 1
            original_new_code = new_outcome_code
            while existing_outcome:
                new_outcome_code = f"{original_new_code}_{counter}"
                existing_outcome = await conn.fetchrow("""
                    SELECT id FROM classification_outcomes 
                    WHERE outcome_code = $1
                """, new_outcome_code)
                counter += 1
            
            await conn.execute("""
                INSERT INTO classification_outcomes (tree_id, outcome_code, outcome_title, 
                                                   description, regulatory_basis, outcome_text)
                VALUES ($1, $2, $3, $4, $5, $6)
            """, new_tree_id, new_outcome_code, outcome['outcome_title'],
                 outcome['description'], outcome['regulatory_basis'], outcome['outcome_text'])
        
        return ClassificationTree(
            id=new_tree['id'],
            name=new_tree['name'],
            description=new_tree['description'],
            jurisdiction=new_tree['jurisdiction'],
            category=new_tree['category'],
            version=new_tree['version'],
            status=new_tree['status'],
            created_by=new_tree['created_by'],
            created_at=new_tree['created_at'],
            updated_at=new_tree['updated_at'],
            published_at=new_tree['published_at'],
            introduction_tree_id=new_tree['introduction_tree_id'],
            is_introduction_template=new_tree['is_introduction_template']
        )
    finally:
        await conn.close()

# ============================================================================
# Admin Endpoints - Tree Nodes
# ============================================================================

@router.get("/admin/trees/{tree_id}/nodes", response_model=List[TreeNode])
async def list_tree_nodes(tree_id: UUID, user: AuthorizedUser):
    """List all nodes for a classification tree"""
    conn = await get_db_connection()
    try:
        query = """
            SELECT id, tree_id, node_key, title, description, question_text, question_type,
                   is_root, parent_node_id, display_order, notes, created_at, updated_at,
                   multi_questions, outcome_rules
            FROM tree_nodes 
            WHERE tree_id = $1 
            ORDER BY display_order, created_at
        """
        rows = await conn.fetch(query, tree_id)
        
        nodes = []
        for row in rows:
            # Parse stored JSON data back to objects
            multi_questions_parsed = None
            outcome_rules_parsed = None
            
            if row['multi_questions']:
                multi_questions_data = json.loads(row['multi_questions'])
                multi_questions_parsed = [MultiQuestionItem(**q) for q in multi_questions_data]
                
            if row['outcome_rules']:
                outcome_rules_data = json.loads(row['outcome_rules'])
                outcome_rules_parsed = [OutcomeRule(**r) for r in outcome_rules_data]
            
            nodes.append(TreeNode(
                id=row["id"],
                tree_id=row["tree_id"],
                node_key=row["node_key"],
                title=row["title"],
                description=row["description"],
                question_text=row["question_text"],
                question_type=row["question_type"],
                is_root=row["is_root"],
                parent_node_id=row["parent_node_id"],
                display_order=row["display_order"],
                notes=row["notes"],
                created_at=row["created_at"],
                updated_at=row["updated_at"],
                multi_questions=multi_questions_parsed,
                outcome_rules=outcome_rules_parsed
            ))
        
        return nodes
    finally:
        await conn.close()

@router.post("/admin/trees/{tree_id}/nodes", response_model=TreeNode)
async def create_tree_node(tree_id: UUID, node_data: TreeNodeCreate, user: AuthorizedUser):
    """Create a new tree node"""
    conn = await get_db_connection()
    try:
        # Verify tree exists
        tree_exists = await conn.fetchval(
            "SELECT EXISTS(SELECT 1 FROM classification_trees WHERE id = $1)", tree_id
        )
        if not tree_exists:
            raise HTTPException(status_code=404, detail="Classification tree not found")

        # Prepare multi-question assessment data
        multi_questions_json = None
        outcome_rules_json = None
        
        if node_data.multi_questions:
            multi_questions_json = json.dumps([q.dict() for q in node_data.multi_questions])
            
        if node_data.outcome_rules:
            outcome_rules_json = json.dumps([r.dict() for r in node_data.outcome_rules])

        # Insert the node
        query = """
            INSERT INTO tree_nodes (
                tree_id, node_key, title, description, question_text, question_type,
                is_root, parent_node_id, display_order, notes, multi_questions, outcome_rules
            ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
            RETURNING id, tree_id, node_key, title, description, question_text, question_type,
                      is_root, parent_node_id, display_order, notes, created_at, updated_at,
                      multi_questions, outcome_rules
        """
        
        row = await conn.fetchrow(
            query,
            tree_id,
            node_data.node_key,
            node_data.title,
            node_data.description,
            node_data.question_text,
            node_data.question_type,
            node_data.is_root,
            node_data.parent_node_id,
            node_data.display_order,
            node_data.notes,
            multi_questions_json,
            outcome_rules_json
        )

        # Parse stored JSON data back to objects
        multi_questions_parsed = None
        outcome_rules_parsed = None
        
        if row['multi_questions']:
            multi_questions_data = json.loads(row['multi_questions'])
            multi_questions_parsed = [MultiQuestionItem(**q) for q in multi_questions_data]
            
        if row['outcome_rules']:
            outcome_rules_data = json.loads(row['outcome_rules'])
            outcome_rules_parsed = [OutcomeRule(**r) for r in outcome_rules_data]

        return TreeNode(
            id=row["id"],
            tree_id=row["tree_id"],
            node_key=row["node_key"],
            title=row["title"],
            description=row["description"],
            question_text=row["question_text"],
            question_type=row["question_type"],
            is_root=row["is_root"],
            parent_node_id=row["parent_node_id"],
            display_order=row["display_order"],
            notes=row["notes"],
            created_at=row["created_at"],
            updated_at=row["updated_at"],
            multi_questions=multi_questions_parsed,
            outcome_rules=outcome_rules_parsed
        )
    except asyncpg.UniqueViolationError:
        raise HTTPException(status_code=400, detail=f"Node key '{node_data.node_key}' already exists in this tree")
    finally:
        await conn.close()

@router.put("/admin/trees/{tree_id}/nodes/{node_id}", response_model=TreeNode)
async def update_tree_node(tree_id: UUID, node_id: UUID, node_data: TreeNodeUpdate, user: AuthorizedUser):
    """Update a tree node"""
    conn = await get_db_connection()
    try:
        # Check if node exists
        node_exists = await conn.fetchval(
            "SELECT EXISTS(SELECT 1 FROM tree_nodes WHERE id = $1 AND tree_id = $2)",
            node_id, tree_id
        )
        if not node_exists:
            raise HTTPException(status_code=404, detail="Node not found")

        # Prepare multi-question assessment data
        multi_questions_json = None
        outcome_rules_json = None
        
        if node_data.multi_questions is not None:
            if node_data.multi_questions:
                multi_questions_json = json.dumps([q.dict() for q in node_data.multi_questions])
            else:
                multi_questions_json = None
                
        if node_data.outcome_rules is not None:
            if node_data.outcome_rules:
                outcome_rules_json = json.dumps([r.dict() for r in node_data.outcome_rules])
            else:
                outcome_rules_json = None

        # Build dynamic update query
        update_fields = []
        values = []
        param_count = 1
        
        if node_data.node_key is not None:
            update_fields.append(f"node_key = ${param_count}")
            values.append(node_data.node_key)
            param_count += 1
            
        if node_data.title is not None:
            update_fields.append(f"title = ${param_count}")
            values.append(node_data.title)
            param_count += 1
            
        if node_data.description is not None:
            update_fields.append(f"description = ${param_count}")
            values.append(node_data.description)
            param_count += 1
            
        if node_data.question_text is not None:
            update_fields.append(f"question_text = ${param_count}")
            values.append(node_data.question_text)
            param_count += 1
            
        if node_data.question_type is not None:
            update_fields.append(f"question_type = ${param_count}")
            values.append(node_data.question_type)
            param_count += 1
            
        if node_data.display_order is not None:
            update_fields.append(f"display_order = ${param_count}")
            values.append(node_data.display_order)
            param_count += 1
            
        if node_data.notes is not None:
            update_fields.append(f"notes = ${param_count}")
            values.append(node_data.notes)
            param_count += 1
            
        if multi_questions_json is not None:
            update_fields.append(f"multi_questions = ${param_count}")
            values.append(multi_questions_json)
            param_count += 1
            
        if outcome_rules_json is not None:
            update_fields.append(f"outcome_rules = ${param_count}")
            values.append(outcome_rules_json)
            param_count += 1

        if not update_fields:
            raise HTTPException(status_code=400, detail="No fields to update")

        # Add updated_at
        update_fields.append("updated_at = CURRENT_TIMESTAMP")
        
        # Add node_id at the end
        values.append(node_id)
        
        query = f"""
            UPDATE tree_nodes 
            SET {', '.join(update_fields)}
            WHERE id = ${param_count}
            RETURNING id, tree_id, node_key, title, description, question_text, question_type,
                      is_root, parent_node_id, display_order, notes, created_at, updated_at,
                      multi_questions, outcome_rules
        """
        
        row = await conn.fetchrow(query, *values)
        
        # Parse stored JSON data back to objects
        multi_questions_parsed = None
        outcome_rules_parsed = None
        
        if row['multi_questions']:
            multi_questions_data = json.loads(row['multi_questions'])
            multi_questions_parsed = [MultiQuestionItem(**q) for q in multi_questions_data]
            
        if row['outcome_rules']:
            outcome_rules_data = json.loads(row['outcome_rules'])
            outcome_rules_parsed = [OutcomeRule(**r) for r in outcome_rules_data]

        return TreeNode(
            id=row["id"],
            tree_id=row["tree_id"],
            node_key=row["node_key"],
            title=row["title"],
            description=row["description"],
            question_text=row["question_text"],
            question_type=row["question_type"],
            is_root=row["is_root"],
            parent_node_id=row["parent_node_id"],
            display_order=row["display_order"],
            notes=row["notes"],
            created_at=row["created_at"],
            updated_at=row["updated_at"],
            multi_questions=multi_questions_parsed,
            outcome_rules=outcome_rules_parsed
        )
    finally:
        await conn.close()

@router.delete("/admin/nodes/{node_id}")
async def delete_tree_node(node_id: UUID, user: AuthorizedUser):
    """Delete a tree node"""
    conn = await get_db_connection()
    try:
        result = await conn.execute("""
            DELETE FROM tree_nodes WHERE id = $1
        """, node_id)
        
        if result == "DELETE 0":
            raise HTTPException(status_code=404, detail="Tree node not found")
        
        return {"message": "Tree node deleted successfully"}
    finally:
        await conn.close()

# ============================================================================
# Admin Endpoints - Node Options
# ============================================================================

@router.get("/admin/nodes/{node_id}/options", response_model=List[NodeOption])
async def list_node_options(node_id: UUID, user: AuthorizedUser):
    """List all options for a tree node"""
    conn = await get_db_connection()
    try:
        rows = await conn.fetch("""
            SELECT id, node_id, option_text, option_value, routing_rule,
                   regulatory_notes, display_order, note, created_at
            FROM node_options
            WHERE node_id = $1
            ORDER BY display_order, created_at
        """, node_id)
        
        options = []
        for row in rows:
            options.append(NodeOption(
                id=row['id'],
                node_id=row['node_id'],
                option_text=row['option_text'],
                option_value=row['option_value'],
                routing_rule=row['routing_rule'],
                regulatory_notes=row['regulatory_notes'],
                display_order=row['display_order'],
                note=row['note'],
                created_at=row['created_at']
            ))
        
        return options
    finally:
        await conn.close()

@router.post("/admin/nodes/{node_id}/options", response_model=NodeOption)
async def create_node_option(node_id: UUID, option_data: NodeOptionCreate, user: AuthorizedUser):
    """Create a new node option"""
    conn = await get_db_connection()
    try:
        # Verify node exists
        node_exists = await conn.fetchval(
            "SELECT EXISTS(SELECT 1 FROM tree_nodes WHERE id = $1)", node_id
        )
        if not node_exists:
            raise HTTPException(status_code=404, detail="Tree node not found")
        
        row = await conn.fetchrow("""
            INSERT INTO node_options (node_id, option_text, option_value, routing_rule,
                                     regulatory_notes, display_order, note)
            VALUES ($1, $2, $3, $4, $5, $6, $7)
            RETURNING id, node_id, option_text, option_value, routing_rule,
                      regulatory_notes, display_order, note, created_at
        """, node_id, option_data.option_text, option_data.option_value,
             option_data.routing_rule, option_data.regulatory_notes, option_data.display_order, option_data.note)
        
        return NodeOption(
            id=row['id'],
            node_id=row['node_id'],
            option_text=row['option_text'],
            option_value=row['option_value'],
            routing_rule=row['routing_rule'],
            regulatory_notes=row['regulatory_notes'],
            display_order=row['display_order'],
            note=row['note'],
            created_at=row['created_at']
        )
    finally:
        await conn.close()

@router.delete("/admin/options/{option_id}")
async def delete_node_option(option_id: UUID, user: AuthorizedUser):
    """Delete a node option"""
    conn = await get_db_connection()
    try:
        result = await conn.execute("""
            DELETE FROM node_options WHERE id = $1
        """, option_id)
        
        if result == "DELETE 0":
            raise HTTPException(status_code=404, detail="Node option not found")
        
        return {"message": "Node option deleted successfully"}
    finally:
        await conn.close()

@router.put("/admin/options/{option_id}", response_model=NodeOption)
async def update_node_option(option_id: UUID, option_data: NodeOptionUpdate, user: AuthorizedUser):
    """Update a node option"""
    conn = await get_db_connection()
    try:
        # Build dynamic update query
        updates = []
        values = []
        param_count = 1
        
        if option_data.option_text is not None:
            updates.append(f"option_text = ${param_count}")
            values.append(option_data.option_text)
            param_count += 1
        
        if option_data.option_value is not None:
            updates.append(f"option_value = ${param_count}")
            values.append(option_data.option_value)
            param_count += 1
        
        if option_data.routing_rule is not None:
            updates.append(f"routing_rule = ${param_count}")
            values.append(option_data.routing_rule)
            param_count += 1
            
        if option_data.regulatory_notes is not None:
            updates.append(f"regulatory_notes = ${param_count}")
            values.append(option_data.regulatory_notes)
            param_count += 1
            
        if option_data.display_order is not None:
            updates.append(f"display_order = ${param_count}")
            values.append(option_data.display_order)
            param_count += 1
        
        if option_data.note is not None:
            updates.append(f"note = ${param_count}")
            values.append(option_data.note)
            param_count += 1
        
        if not updates:
            raise HTTPException(status_code=400, detail="No fields to update")
        
        # Add WHERE clause parameter
        values.append(option_id)
        where_param = f"${param_count}"
        
        query = f"""
            UPDATE node_options 
            SET {', '.join(updates)}
            WHERE id = {where_param}
            RETURNING id, node_id, option_text, option_value, routing_rule,
                      regulatory_notes, display_order, note, created_at
        """
        
        row = await conn.fetchrow(query, *values)
        
        if not row:
            raise HTTPException(status_code=404, detail="Node option not found")
        
        return NodeOption(
            id=row['id'],
            node_id=row['node_id'],
            option_text=row['option_text'],
            option_value=row['option_value'],
            routing_rule=row['routing_rule'],
            regulatory_notes=row['regulatory_notes'],
            display_order=row['display_order'],
            note=row['note'],
            created_at=row['created_at']
        )
    finally:
        await conn.close()

# ============================================================================
# Admin Endpoints - Classification Outcomes
# ============================================================================

@router.get("/admin/outcomes", response_model=List[ClassificationOutcome])
async def list_all_classification_outcomes(user: AuthorizedUser):
    """List all outcomes across all classification trees"""
    conn = await get_db_connection()
    try:
        rows = await conn.fetch("""
            SELECT id, tree_id, outcome_code, outcome_title, description,
                   regulatory_basis, outcome_text, is_controlled, guidance_notes, created_at
            FROM classification_outcomes
            ORDER BY outcome_code
        """)
        
        outcomes = []
        for row in rows:
            outcomes.append(ClassificationOutcome(
                id=row['id'],
                tree_id=row['tree_id'],
                outcome_code=row['outcome_code'],
                outcome_title=row['outcome_title'],
                description=row['description'],
                regulatory_basis=row['regulatory_basis'],
                outcome_text=row['outcome_text'],
                is_controlled=row['is_controlled'],
                guidance_notes=row['guidance_notes'],
                created_at=row['created_at'].isoformat() if row['created_at'] else None
            ))
        
        return outcomes
    finally:
        await conn.close()

@router.post("/admin/outcomes", response_model=ClassificationOutcome)
async def create_tree_independent_outcome(outcome_data: ClassificationOutcomeCreate, user: AuthorizedUser):
    """Create a new tree-independent classification outcome"""
    conn = await get_db_connection()
    try:
        query = """
            INSERT INTO classification_outcomes 
            (tree_id, outcome_code, outcome_title, description, regulatory_basis, outcome_text, is_controlled, guidance_notes)
            VALUES (NULL, $1, $2, $3, $4, $5, $6, $7)
            RETURNING id, tree_id, outcome_code, outcome_title, description, regulatory_basis, outcome_text, is_controlled, guidance_notes, created_at
        """
        
        row = await conn.fetchrow(
            query,
            outcome_data.outcome_code,
            outcome_data.outcome_title,
            outcome_data.description,
            outcome_data.regulatory_basis,
            outcome_data.outcome_text,
            outcome_data.is_controlled,
            outcome_data.guidance_notes
        )
        
        if not row:
            raise HTTPException(status_code=500, detail="Failed to create classification outcome")
            
        return ClassificationOutcome(
            id=row['id'],
            tree_id=row['tree_id'],
            outcome_code=row['outcome_code'],
            outcome_title=row['outcome_title'],
            description=row['description'],
            regulatory_basis=row['regulatory_basis'],
            outcome_text=row['outcome_text'],
            is_controlled=row['is_controlled'],
            guidance_notes=row['guidance_notes'],
            created_at=row['created_at']
        )
    finally:
        await conn.close()

@router.get("/admin/trees/{tree_id}/outcomes", response_model=List[ClassificationOutcome])
async def list_classification_outcomes(tree_id: UUID, user: AuthorizedUser):
    """List all outcomes for a classification tree"""
    conn = await get_db_connection()
    try:
        rows = await conn.fetch("""
            SELECT id, tree_id, outcome_code, outcome_title, description,
                   regulatory_basis, outcome_text, is_controlled, guidance_notes, created_at
            FROM classification_outcomes
            WHERE tree_id = $1
            ORDER BY outcome_code
        """, tree_id)
        
        outcomes = []
        for row in rows:
            outcomes.append(ClassificationOutcome(
                id=row['id'],
                tree_id=row['tree_id'],
                outcome_code=row['outcome_code'],
                outcome_title=row['outcome_title'],
                description=row['description'],
                regulatory_basis=row['regulatory_basis'],
                outcome_text=row['outcome_text'],
                is_controlled=row['is_controlled'],
                guidance_notes=row['guidance_notes'],
                created_at=row['created_at']
            ))
        
        return outcomes
    finally:
        await conn.close()

@router.post("/admin/trees/{tree_id}/outcomes", response_model=ClassificationOutcome)
async def create_classification_outcome(tree_id: UUID, outcome_data: ClassificationOutcomeCreate, user: AuthorizedUser):
    """Create a new classification outcome for a tree"""
    conn = await get_db_connection()
    try:
        query = """
            INSERT INTO classification_outcomes 
            (tree_id, outcome_code, outcome_title, description, regulatory_basis, outcome_text, is_controlled, guidance_notes)
            VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
            RETURNING id, tree_id, outcome_code, outcome_title, description, regulatory_basis, outcome_text, is_controlled, guidance_notes, created_at
        """
        
        row = await conn.fetchrow(
            query,
            tree_id,
            outcome_data.outcome_code,
            outcome_data.outcome_title,
            outcome_data.description,
            outcome_data.regulatory_basis,
            outcome_data.outcome_text,
            outcome_data.is_controlled,
            outcome_data.guidance_notes
        )
        
        if not row:
            raise HTTPException(status_code=500, detail="Failed to create classification outcome")
            
        return ClassificationOutcome(
            id=row['id'],
            tree_id=row['tree_id'],
            outcome_code=row['outcome_code'],
            outcome_title=row['outcome_title'],
            description=row['description'],
            regulatory_basis=row['regulatory_basis'],
            outcome_text=row['outcome_text'],
            is_controlled=row['is_controlled'],
            guidance_notes=row['guidance_notes'],
            created_at=row['created_at']
        )
    finally:
        await conn.close()

@router.put("/admin/outcomes/{outcome_id}", response_model=ClassificationOutcome)
async def update_classification_outcome(outcome_id: UUID, outcome_data: ClassificationOutcomeUpdate, user: AuthorizedUser):
    """Update a classification outcome"""
    conn = await get_db_connection()
    try:
        # Build dynamic update query
        updates = []
        values = []
        param_count = 1
        
        if outcome_data.outcome_code is not None:
            updates.append(f"outcome_code = ${param_count}")
            values.append(outcome_data.outcome_code)
            param_count += 1
            
        if outcome_data.outcome_title is not None:
            updates.append(f"outcome_title = ${param_count}")
            values.append(outcome_data.outcome_title)
            param_count += 1
            
        if outcome_data.description is not None:
            updates.append(f"description = ${param_count}")
            values.append(outcome_data.description)
            param_count += 1
            
        if outcome_data.regulatory_basis is not None:
            updates.append(f"regulatory_basis = ${param_count}")
            values.append(outcome_data.regulatory_basis)
            param_count += 1
            
        if outcome_data.outcome_text is not None:
            updates.append(f"outcome_text = ${param_count}")
            values.append(outcome_data.outcome_text)
            param_count += 1
            
        if outcome_data.is_controlled is not None:
            updates.append(f"is_controlled = ${param_count}")
            values.append(outcome_data.is_controlled)
            param_count += 1
            
        if outcome_data.guidance_notes is not None:
            updates.append(f"guidance_notes = ${param_count}")
            values.append(outcome_data.guidance_notes)
            param_count += 1
            
        if not updates:
            raise HTTPException(status_code=400, detail="No fields to update")
            
        # Add the outcome_id as the last parameter
        values.append(outcome_id)
        
        query = f"""
            UPDATE classification_outcomes 
            SET {', '.join(updates)}
            WHERE id = ${param_count}
            RETURNING id, tree_id, outcome_code, outcome_title, description, regulatory_basis, outcome_text, is_controlled, guidance_notes, created_at
        """
        
        row = await conn.fetchrow(query, *values)
        
        if not row:
            raise HTTPException(status_code=404, detail="Classification outcome not found")
            
        return ClassificationOutcome(
            id=row['id'],
            tree_id=row['tree_id'],
            outcome_code=row['outcome_code'],
            outcome_title=row['outcome_title'],
            description=row['description'],
            regulatory_basis=row['regulatory_basis'],
            outcome_text=row['outcome_text'],
            is_controlled=row['is_controlled'],
            guidance_notes=row['guidance_notes'],
            created_at=row['created_at']
        )
    finally:
        await conn.close()

@router.delete("/admin/outcomes/{outcome_id}")
async def delete_classification_outcome(outcome_id: UUID, user: AuthorizedUser):
    """Delete a classification outcome"""
    conn = await get_db_connection()
    try:
        result = await conn.execute("""
            DELETE FROM classification_outcomes WHERE id = $1
        """, outcome_id)
        
        if result == "DELETE 0":
            raise HTTPException(status_code=404, detail="Classification outcome not found")
        
        return {"message": "Classification outcome deleted successfully"}
    finally:
        await conn.close()

# ============================================================================
# Public Endpoints - For Users
# ============================================================================

@router.get("/trees", response_model=List[ClassificationTree])
async def list_active_trees():
    """List all active classification trees for public use"""
    conn = await get_db_connection()
    try:
        rows = await conn.fetch("""
            SELECT id, name, description, jurisdiction, category, version, status,
                   created_by, created_at, updated_at, published_at, introduction_tree_id, is_introduction_template
            FROM classification_trees
            WHERE status IN ('active', 'published')
            ORDER BY jurisdiction, category, name
        """)
        
        trees = []
        for row in rows:
            trees.append(ClassificationTree(
                id=row['id'],
                name=row['name'],
                description=row['description'],
                jurisdiction=row['jurisdiction'],
                category=row['category'],
                version=row['version'],
                status=row['status'],
                created_by=row['created_by'],
                created_at=row['created_at'],
                updated_at=row['updated_at'],
                published_at=row['published_at'],
                introduction_tree_id=row['introduction_tree_id'],
                is_introduction_template=row['is_introduction_template']
            ))
        
        return trees
    finally:
        await conn.close()

@router.get("/trees/{tree_id}/start")
async def get_tree_start_node(tree_id: UUID):
    """Get the starting node for a classification tree"""
    conn = await get_db_connection()
    try:
        # Get tree info
        tree = await conn.fetchrow("""
            SELECT id, name, description, jurisdiction, category
            FROM classification_trees
            WHERE id = $1 AND status IN ('active', 'published')
        """, tree_id)
        
        if not tree:
            raise HTTPException(status_code=404, detail="Classification tree not found or not active")
        
        # Get root node
        root_node = await conn.fetchrow("""
            SELECT id, node_key, title, description, question_text, question_type
            FROM tree_nodes
            WHERE tree_id = $1 AND is_root = true
            ORDER BY display_order
            LIMIT 1
        """, tree_id)
        
        if not root_node:
            raise HTTPException(status_code=404, detail="No root node found for this tree")
        
        # Get options for root node
        options = await conn.fetch("""
            SELECT id, option_text, option_value, routing_rule, regulatory_notes, note
            FROM node_options
            WHERE node_id = $1
            ORDER BY display_order
        """, root_node['id'])
        
        # Convert options to list of dictionaries
        resolved_options = []
        for option in options:
            resolved_options.append({
                "id": option['id'],
                "option_text": option['option_text'],
                "option_value": option['option_value'],
                "routing_rule": option['routing_rule'],
                "regulatory_notes": option['regulatory_notes'],
                "note": option['note']
            })
        
        return {
            "tree": {
                "id": tree['id'],
                "name": tree['name'],
                "description": tree['description'],
                "jurisdiction": tree['jurisdiction'],
                "category": tree['category']
            },
            "node": {
                "id": root_node['id'],
                "node_key": root_node['node_key'],
                "title": root_node['title'],
                "description": root_node['description'],
                "question_text": root_node['question_text'],
                "question_type": root_node['question_type']
            },
            "options": resolved_options
        }
    finally:
        await conn.close()

@router.get("/trees/{tree_id}/nodes/{node_key}")
async def get_node_by_key(tree_id: UUID, node_key: str):
    """Get a specific node by its key within a tree"""
    conn = await get_db_connection()
    try:
        # Get node info
        node = await conn.fetchrow("""
            SELECT id, node_key, title, description, question_text, question_type
            FROM tree_nodes
            WHERE tree_id = $1 AND node_key = $2
        """, tree_id, node_key)
        
        if not node:
            raise HTTPException(status_code=404, detail="Node not found")
        
        # Get options for this node
        options = await conn.fetch("""
            SELECT id, option_text, option_value, routing_rule, regulatory_notes, note
            FROM node_options
            WHERE node_id = $1
            ORDER BY display_order
        """, node['id'])
        
        # Convert options to list of dictionaries
        resolved_options = []
        for option in options:
            resolved_options.append({
                "id": option['id'],
                "option_text": option['option_text'],
                "option_value": option['option_value'],
                "routing_rule": option['routing_rule'],
                "regulatory_notes": option['regulatory_notes'],
                "note": option['note']
            })
        
        return {
            "node": {
                "id": node['id'],
                "node_key": node['node_key'],
                "title": node['title'],
                "description": node['description'],
                "question_text": node['question_text'],
                "question_type": node['question_type']
            },
            "options": resolved_options
        }
    finally:
        await conn.close()

@router.post("/trees/{tree_id}/navigate")
async def navigate_tree(tree_id: UUID, navigation: NavigationRequest, user: AuthorizedUser):
    """Navigate to the next node based on selected option"""
    conn = await get_db_connection()
    try:
        # Get the selected option and its routing rule
        option = await conn.fetchrow("""
            SELECT no.routing_rule, no.option_text, tn.node_key as current_node_key
            FROM node_options no
            JOIN tree_nodes tn ON no.node_id = tn.id
            WHERE no.id = $1 AND tn.tree_id = $2
        """, navigation.option_id, tree_id)
        
        if not option:
            raise HTTPException(status_code=404, detail="Option not found")
        
        routing_rule_text = option['routing_rule']
        
        # If no routing rule, this might be an endpoint
        if not routing_rule_text:
            # Check if there's a classification outcome for this option value
            outcome = await conn.fetchrow("""
                SELECT id, outcome_code, outcome_title, description, regulatory_basis, outcome_text
                FROM classification_outcomes
                WHERE tree_id = $1 AND outcome_code = $2
            """, tree_id, navigation.option_value)
            
            if not outcome:
                print(f"DEBUG: Outcome '{navigation.option_value}' not found in tree {tree_id}")
                # Try to find outcome without tree_id restriction
                global_outcome = await conn.fetchrow("""
                    SELECT id, outcome_code, outcome_title, description, regulatory_basis, outcome_text
                    FROM classification_outcomes
                    WHERE outcome_code = $1
                    LIMIT 1
                """, navigation.option_value)
                if global_outcome:
                    print(f"DEBUG: Found global outcome for '{navigation.option_value}'")
                    outcome = global_outcome
                else:
                    print(f"DEBUG: No outcome found anywhere for '{navigation.option_value}'")
                    raise HTTPException(status_code=404, detail=f"Outcome '{navigation.option_value}' not found")
            
            return {
                "type": "outcome",
                "outcome": {
                    "id": outcome['id'],
                    "outcome_code": outcome['outcome_code'],
                    "outcome_title": outcome['outcome_title'],
                    "description": outcome['description'],
                    "regulatory_basis": outcome['regulatory_basis'],
                    "outcome_text": outcome['outcome_text']
                }
            }
        
        # Parse routing rule using new parser
        parsed_rule = parse_routing_rule(routing_rule_text)
        intermediate_outcomes = []
        
        # If this rule has an intermediate outcome, collect it
        if parsed_rule.has_intermediate_outcome():
            outcome = await conn.fetchrow("""
                SELECT id, outcome_code, outcome_title, description, regulatory_basis, outcome_text
                FROM classification_outcomes
                WHERE tree_id = $1 AND outcome_code = $2
            """, tree_id, parsed_rule.outcome_code)
            
            if not outcome:
                print(f"DEBUG: Outcome '{parsed_rule.outcome_code}' not found in tree {tree_id}")
                # Try to find outcome without tree_id restriction
                global_outcome = await conn.fetchrow("""
                    SELECT id, outcome_code, outcome_title, description, regulatory_basis, outcome_text
                    FROM classification_outcomes
                    WHERE outcome_code = $1
                    LIMIT 1
                """, parsed_rule.outcome_code)
                if global_outcome:
                    print(f"DEBUG: Found global outcome for '{parsed_rule.outcome_code}'")
                    outcome = global_outcome
                else:
                    print(f"DEBUG: No outcome found anywhere for '{parsed_rule.outcome_code}'")
                    raise HTTPException(status_code=404, detail=f"Outcome '{parsed_rule.outcome_code}' not found")
            
            intermediate_outcomes.append({
                "id": outcome['id'],
                "outcome_code": outcome['outcome_code'],
                "outcome_title": outcome['outcome_title'],
                "description": outcome['description'],
                "regulatory_basis": outcome['regulatory_basis'],
                "outcome_text": outcome['outcome_text']
            })
        
        # Get the next target (either from complex rule's continue_target or simple rule's target)
        next_target = parsed_rule.get_next_target()
        
        if not next_target:
            raise HTTPException(status_code=400, detail="No navigation target found in routing rule")
        
        # First try to find it as a node in the current tree
        next_node = await conn.fetchrow("""
            SELECT id, node_key, title, description, question_text, question_type, multi_questions, outcome_rules
            FROM tree_nodes
            WHERE tree_id = $1 AND node_key = $2
        """, tree_id, next_target)
        
        if next_node:
            # Get options for the next node
            next_options = await conn.fetch("""
                SELECT id, option_text, option_value, routing_rule, regulatory_notes, note
                FROM node_options
                WHERE node_id = $1
                ORDER BY display_order
            """, next_node['id'])
            
            # Convert options to list of dictionaries
            resolved_options = []
            for option in next_options:
                resolved_options.append({
                    "id": option['id'],
                    "option_text": option['option_text'],
                    "option_value": option['option_value'],
                    "routing_rule": option['routing_rule'],
                    "regulatory_notes": option['regulatory_notes'],
                    "note": option['note']
                })
            
            response = {
                "type": "node",
                "node": {
                    "id": next_node['id'],
                    "node_key": next_node['node_key'],
                    "title": next_node['title'],
                    "description": next_node['description'],
                    "question_text": next_node['question_text'],
                    "question_type": next_node['question_type'],
                    "multi_questions": next_node['multi_questions'],
                    "outcome_rules": next_node['outcome_rules']
                },
                "options": resolved_options
            }
            
            # Add intermediate outcomes if any
            if intermediate_outcomes:
                response["intermediate_outcomes"] = intermediate_outcomes
                
            return response
        
        # If not found as a node, check if it's an outcome code
        outcome = await conn.fetchrow("""
            SELECT id, outcome_code, outcome_title, description, regulatory_basis, outcome_text
            FROM classification_outcomes
            WHERE tree_id = $1 AND outcome_code = $2
        """, tree_id, next_target)
        
        if outcome:
            # This is a final outcome
            final_outcome = {
                "id": outcome['id'],
                "outcome_code": outcome['outcome_code'],
                "outcome_title": outcome['outcome_title'],
                "description": outcome['description'],
                "regulatory_basis": outcome['regulatory_basis'],
                "outcome_text": outcome['outcome_text']
            }
            
            response = {
                "type": "outcome",
                "outcome": final_outcome
            }
            
            # Add intermediate outcomes if any
            if intermediate_outcomes:
                response["intermediate_outcomes"] = intermediate_outcomes
                
            return response
        
        # If not found as a node or outcome, try to find it as another tree
        next_tree = await conn.fetchrow("""
            SELECT id, name, description, jurisdiction, category
            FROM classification_trees
            WHERE name = $1 OR id::text = $2
        """, next_target, next_target)
        
        if next_tree:
            response = {
                "type": "tree_transition",
                "tree": {
                    "id": next_tree['id'],
                    "name": next_tree['name'],
                    "description": next_tree['description'],
                    "jurisdiction": next_tree['jurisdiction'],
                    "category": next_tree['category']
                }
            }
            
            # Add intermediate outcomes if any
            if intermediate_outcomes:
                response["intermediate_outcomes"] = intermediate_outcomes
                
            return response
        
        # Special handling for workflow transitions
        if next_target in ["CLASSIFICATION_START", "NEXT_TREE", "WORKFLOW_CONTINUE"]:
            response = {
                "type": "workflow_transition",
                "target": next_target
            }
            
            # Add intermediate outcomes if any
            if intermediate_outcomes:
                response["intermediate_outcomes"] = intermediate_outcomes
                
            return response
        
        raise HTTPException(status_code=404, detail=f"Navigation target '{next_target}' not found as node, outcome, or tree")
    finally:
        await conn.close()

# ============================================================================
# User-facing Endpoints - Multi-Question Assessments
# ============================================================================

@router.post("/trees/{tree_id}/nodes/{node_key}/assess", response_model=MultiQuestionAssessmentResponse)
async def process_classification_multi_question_assessment(tree_id: UUID, node_key: str, request: MultiQuestionAssessmentRequest, user: AuthorizedUser):
    """Process responses to a multi-question assessment and determine routing"""
    conn = await get_db_connection()
    try:
        # Get node with multi-question assessment data
        node = await conn.fetchrow("""
            SELECT id, tree_id, node_key, title, question_type, multi_questions, outcome_rules
            FROM tree_nodes
            WHERE tree_id = $1 AND node_key = $2 AND question_type = 'multi_question_assessment'
        """, tree_id, node_key)
        
        if not node:
            raise HTTPException(status_code=404, detail="Multi-question assessment node not found")
        
        # Parse multi-questions and outcome rules
        multi_questions = json.loads(node['multi_questions']) if node['multi_questions'] else []
        outcome_rules = json.loads(node['outcome_rules']) if node['outcome_rules'] else []
        
        # Validate that all required questions were answered
        total_questions = len(multi_questions)
        if len(request.responses) != total_questions:
            raise HTTPException(status_code=400, detail=f"Expected {total_questions} responses, got {len(request.responses)}")
        
        # Count yes/no responses
        yes_count = sum(1 for response in request.responses.values() if response)
        no_count = sum(1 for response in request.responses.values() if not response)
        
        # Evaluate outcome rules to find a match
        matched_rule = None
        routing_target = None
        routing_type = None
        
        # Sort rules by priority (higher priority first)
        sorted_rules = sorted(outcome_rules, key=lambda r: r.get('priority', 0), reverse=True)
        
        for rule_data in sorted_rules:
            rule = OutcomeRule(**rule_data)
            logic = rule.logic
            
            # Check if this rule matches current response pattern
            rule_matches = True
            
            # Check yes_count conditions
            if 'yes_count' in logic:
                yes_condition = logic['yes_count']
                if isinstance(yes_condition, int):
                    if yes_count != yes_condition:
                        rule_matches = False
                elif isinstance(yes_condition, dict):
                    if 'min' in yes_condition and yes_count < yes_condition['min']:
                        rule_matches = False
                    if 'max' in yes_condition and yes_count > yes_condition['max']:
                        rule_matches = False
                    if 'exact' in yes_condition and yes_count != yes_condition['exact']:
                        rule_matches = False
            
            # Check no_count conditions
            if rule_matches and 'no_count' in logic:
                no_condition = logic['no_count']
                if isinstance(no_condition, int):
                    if no_count != no_condition:
                        rule_matches = False
                elif isinstance(no_condition, dict):
                    if 'min' in no_condition and no_count < no_condition['min']:
                        rule_matches = False
                    if 'max' in no_condition and no_count > no_condition['max']:
                        rule_matches = False
                    if 'exact' in no_condition and no_count != no_condition['exact']:
                        rule_matches = False
            
            # If rule matches, use it
            if rule_matches:
                matched_rule = rule
                routing_target = rule.target
                routing_type = rule.target_type
                break
        
        # Store assessment result
        await conn.execute("""
            INSERT INTO public.multi_question_assessments 
            (tree_id, node_id, user_id, responses, matched_rule, routing_target, routing_type)
            VALUES ($1, $2, $3, $4, $5, $6, $7)
        """, tree_id, node['id'], user.sub, json.dumps(request.responses),
            json.dumps(matched_rule.dict()) if matched_rule else None,
            routing_target, routing_type)
        
        return MultiQuestionAssessmentResponse(
            matched_rule=matched_rule,
            routing_target=routing_target,
            routing_type=routing_type,
            yes_count=yes_count,
            no_count=no_count,
            total_questions=total_questions
        )
        
    finally:
        await conn.close()
