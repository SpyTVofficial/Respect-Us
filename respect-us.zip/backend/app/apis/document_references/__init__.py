


"""Document reference API for cross-referencing knowledge base documents"""

from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel
from typing import List, Optional, Dict, Any
import asyncpg
import databutton as db
from app.auth import AuthorizedUser
from app.env import Mode, mode
from datetime import datetime

router = APIRouter(prefix="/doc-references")

class DocumentReference(BaseModel):
    id: int
    reference_id: str  # e.g., "DOC-123"
    title: str
    description: Optional[str]
    country_jurisdiction: Optional[str]
    regulation_type: Optional[str]
    publication_date: Optional[str]
    legal_status: Optional[str]

class ResolvedReference(BaseModel):
    reference_id: str
    document_id: Optional[int]
    title: Optional[str]
    description: Optional[str]
    url: Optional[str]
    status: str  # "found", "not_found", "error"
    error_message: Optional[str]

class ReferenceSearchResponse(BaseModel):
    references: List[DocumentReference]
    total: int

class ResolveReferencesResponse(BaseModel):
    resolved: List[ResolvedReference]
    total: int

def generate_reference_id(document_id: int) -> str:
    """Generate a user-friendly document reference ID"""
    return f"DOC-{document_id}"

def parse_reference_id(reference: str) -> Optional[int]:
    """Parse a reference ID to extract document ID"""
    pattern = re.compile(r'^(DOC|KB|REG)-(\d+)$', re.IGNORECASE)
    match = pattern.match(reference.strip())
    if match:
        return int(match.group(2))
    return None

def extract_references_from_text(text: str) -> List[str]:
    """Extract all document references from text content"""
    if not text:
        return []
    
    pattern = re.compile(r'\b(DOC|KB|REG)-(\d+)\b', re.IGNORECASE)
    matches = pattern.findall(text)
    return [f"{doc_type.upper()}-{doc_id}" for doc_type, doc_id in matches]

# Database connection helper
async def get_db_connection():
    database_url = db.secrets.get("DATABASE_URL_DEV")
    return await asyncpg.connect(database_url)

@router.get("/search")
async def search_documents_for_reference(
    q: str = Query(..., description="Search term"),
    limit: int = Query(10, description="Maximum number of results")
) -> ReferenceSearchResponse:
    """Search documents that can be referenced"""
    
    conn = await get_db_connection()
    try:
        query = """
            SELECT id, title, description, country_jurisdiction, regulation_type, 
                   publication_date, legal_status
            FROM kb_documents
            WHERE publishing_status IN ('published', 'pending_validation')
            AND (title ILIKE $1 OR description ILIKE $1 OR CAST(id AS TEXT) = $2)
            ORDER BY 
                CASE 
                    WHEN CAST(id AS TEXT) = $2 THEN 1
                    WHEN title ILIKE $1 THEN 2
                    WHEN description ILIKE $1 THEN 3
                    ELSE 4
                END,
                publication_date DESC
            LIMIT $3
        """
        
        # Check if search term is a number (direct ID search)
        direct_id = None
        try:
            direct_id = str(int(q)) if q.isdigit() else None
        except:
            pass
        
        rows = await conn.fetch(query, f'%{q}%', direct_id or '', limit)
        
        references = [
            DocumentReference(
                id=row['id'],
                reference_id=generate_reference_id(row['id']),
                title=row['title'],
                description=row['description'],
                country_jurisdiction=row['country_jurisdiction'],
                regulation_type=row['regulation_type'],
                publication_date=row['publication_date'].isoformat() if row['publication_date'] else None,
                legal_status=row['legal_status']
            )
            for row in rows
        ]
        
        return ReferenceSearchResponse(
            references=references,
            total=len(references)
        )
        
    except Exception as e:
        print(f"Error searching documents for reference: {e}")
        raise HTTPException(status_code=500, detail="Failed to search documents")
    finally:
        await conn.close()

@router.post("/resolve")
async def resolve_document_references(
    reference_ids: List[str]
) -> ResolveReferencesResponse:
    """Resolve document reference IDs to actual document data"""
    
    conn = await get_db_connection()
    try:
        resolved = []
        
        for ref_id in reference_ids:
            doc_id = parse_reference_id(ref_id)
            
            if not doc_id:
                resolved.append(ResolvedReference(
                    reference_id=ref_id,
                    document_id=None,
                    title=None,
                    description=None,
                    url=None,
                    status="error",
                    error_message="Invalid reference format"
                ))
                continue
            
            query = """
                SELECT id, title, description, publishing_status
                FROM kb_documents 
                WHERE id = $1
            """
            
            try:
                doc = await conn.fetchrow(query, doc_id)
                if doc:
                    resolved.append(ResolvedReference(
                        reference_id=ref_id,
                        document_id=doc['id'],
                        title=doc['title'],
                        description=doc['description'],
                        url=f'/document-reader?documentId={doc_id}',
                        status="found",
                        error_message=None
                    ))
                else:
                    resolved.append(ResolvedReference(
                        reference_id=ref_id,
                        document_id=doc_id,
                        title=None,
                        description=None,
                        url=None,
                        status="not_found",
                        error_message=f"Document {ref_id} not found"
                    ))
                    
            except Exception as e:
                print(f"Error resolving reference {ref_id}: {e}")
                resolved.append(ResolvedReference(
                    reference_id=ref_id,
                    document_id=doc_id,
                    title=None,
                    description=None,
                    url=None,
                    status="error",
                    error_message=f"Error accessing document: {str(e)}"
                ))
        
        return ResolveReferencesResponse(
            resolved=resolved,
            total=len(resolved)
        )
        
    except Exception as e:
        print(f"Error resolving document references: {e}")
        raise HTTPException(status_code=500, detail="Failed to resolve references")
    finally:
        await conn.close()

@router.get("/extract-from-text")
async def extract_references_from_text_endpoint(
    text: str = Query(..., description="Text content to extract references from")
) -> Dict[str, List[str]]:
    """Extract document references from text content"""
    
    try:
        references = extract_references_from_text(text)
        return {
            "references": references,
            "count": [str(len(references))]  # Convert to list of strings as expected
        }
    except Exception as e:
        print(f"Error extracting references from text: {e}")
        raise HTTPException(status_code=500, detail="Failed to extract references")

@router.get("/document/{document_id}/reference-id")
async def get_document_reference_id(
    document_id: int,
    user: AuthorizedUser
) -> Dict[str, str]:
    """Get the reference ID for a specific document"""
    
    conn = await get_db_connection()
    try:
        # Verify document exists
        doc = await conn.fetchrow(
            "SELECT id, title FROM kb_documents WHERE id = $1",
            document_id
        )
        
        if not doc:
            raise HTTPException(status_code=404, detail="Document not found")
        
        return {
            "document_id": str(document_id),
            "reference_id": generate_reference_id(document_id),
            "title": doc['title']
        }
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error getting document reference ID: {e}")
        raise HTTPException(status_code=500, detail="Failed to get reference ID")
    finally:
        await conn.close()
