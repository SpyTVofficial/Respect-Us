
from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel
from typing import List, Optional, Dict, Any
import asyncpg
import databutton as db
from app.auth import AuthorizedUser
from app.env import Mode, mode
from datetime import datetime, timezone
import uuid

router = APIRouter(prefix="/doc-collaboration")

# Database connection helper
async def get_db_connection():
    if mode == Mode.PROD:
        database_url = db.secrets.get("DATABASE_URL_PROD")
    else:
        database_url = db.secrets.get("DATABASE_URL_DEV")
    return await asyncpg.connect(database_url)

# Models for Annotations
class DocumentAnnotation(BaseModel):
    document_id: int
    section_id: Optional[int] = None
    annotation_type: str  # highlight, note, question, suggestion
    content: str
    start_position: Optional[int] = None
    end_position: Optional[int] = None
    is_public: bool = False
    tags: Optional[List[str]] = None
    metadata: Optional[Dict[str, Any]] = None

class AnnotationResponse(BaseModel):
    id: int
    document_id: int
    section_id: Optional[int]
    user_id: str
    user_name: str
    annotation_type: str
    content: str
    start_position: Optional[int]
    end_position: Optional[int]
    is_public: bool
    tags: Optional[List[str]]
    metadata: Optional[Dict[str, Any]]
    created_at: datetime
    updated_at: datetime
    resolved: bool
    resolved_by: Optional[str]
    resolved_at: Optional[datetime]

class AnnotationUpdate(BaseModel):
    content: Optional[str] = None
    annotation_type: Optional[str] = None
    is_public: Optional[bool] = None
    tags: Optional[List[str]] = None
    resolved: Optional[bool] = None

# Models for Bookmarks
class UserBookmark(BaseModel):
    document_id: int
    section_id: Optional[int] = None
    bookmark_type: str = "document"  # document, section, annotation
    notes: Optional[str] = None
    tags: Optional[List[str]] = None

class BookmarkResponse(BaseModel):
    id: int
    user_id: str
    document_id: int
    document_title: str
    section_id: Optional[int]
    section_title: Optional[str]
    bookmark_type: str
    notes: Optional[str]
    tags: Optional[List[str]]
    created_at: datetime
    updated_at: datetime

# Models for Activity Tracking
class DocumentActivity(BaseModel):
    activity_type: str  # viewed, downloaded, annotated, bookmarked, shared
    metadata: Optional[Dict[str, Any]] = None

class ActivityResponse(BaseModel):
    id: int
    user_id: str
    user_name: str
    document_id: int
    document_title: str
    activity_type: str
    metadata: Optional[Dict[str, Any]]
    created_at: datetime

class CollaborationStats(BaseModel):
    total_annotations: int
    public_annotations: int
    user_annotations: int
    resolved_annotations: int
    total_bookmarks: int
    recent_activity_count: int
    top_annotated_documents: List[Dict[str, Any]]
    collaboration_score: float

class UserCollaborationSummary(BaseModel):
    user_id: str
    user_name: str
    total_annotations: int
    public_annotations: int
    resolved_annotations: int
    total_bookmarks: int
    documents_accessed: int
    last_activity: Optional[datetime]
    collaboration_rank: int

class CollaborationStatsResponse(BaseModel):
    total_annotations: int
    public_annotations: int
    user_annotations: int
    resolved_annotations: int
    total_bookmarks: int
    recent_activity_count: int
    top_annotated_documents: List[Dict[str, Any]]
    collaboration_score: int

# Annotation Endpoints
@router.get("/documents/{document_id}/annotations", response_model=List[AnnotationResponse])
async def get_document_annotations_collab(document_id: int, user: AuthorizedUser, include_private: bool = False):
    """Get all annotations for a document"""
    try:
        conn = await get_db_connection()
        
        # Build query based on privacy settings
        if include_private:
            where_clause = "WHERE da.document_id = $1 AND (da.is_public = true OR da.user_id = $2)"
            params = [document_id, user.sub]
        else:
            where_clause = "WHERE da.document_id = $1 AND da.is_public = true"
            params = [document_id]
        
        annotations = await conn.fetch(
            f"""
            SELECT da.*, u.display_name as user_name,
                   ds.title as section_title
            FROM document_annotations da
            LEFT JOIN kb_document_sections ds ON da.section_id = ds.id
            LEFT JOIN (
                SELECT sub as user_id, display_name
                FROM auth_users
            ) u ON da.user_id = u.user_id
            {where_clause}
            ORDER BY da.created_at DESC
            """,
            *params
        )
        
        await conn.close()
        
        return [
            AnnotationResponse(
                id=ann['id'],
                document_id=ann['document_id'],
                section_id=ann['section_id'],
                user_id=ann['user_id'],
                user_name=ann['user_name'] or 'Unknown User',
                annotation_type=ann['annotation_type'],
                content=ann['content'],
                start_position=ann['start_position'],
                end_position=ann['end_position'],
                is_public=ann['is_public'],
                tags=ann['tags'],
                metadata=ann['metadata'],
                created_at=ann['created_at'],
                updated_at=ann['updated_at'],
                resolved=ann['resolved'],
                resolved_by=ann['resolved_by'],
                resolved_at=ann['resolved_at']
            )
            for ann in annotations
        ]
        
    except Exception as e:
        print(f"Error getting document annotations: {e}")
        raise HTTPException(status_code=500, detail="Failed to get document annotations")

@router.post("/annotations", response_model=AnnotationResponse)
async def create_annotation_collab(annotation: DocumentAnnotation, user: AuthorizedUser):
    """Create a new document annotation"""
    try:
        conn = await get_db_connection()
        
        # Verify document exists
        doc_exists = await conn.fetchval(
            "SELECT EXISTS(SELECT 1 FROM kb_documents WHERE id = $1)",
            annotation.document_id
        )
        
        if not doc_exists:
            raise HTTPException(status_code=404, detail="Document not found")
        
        # Create annotation
        annotation_id = await conn.fetchval(
            """
            INSERT INTO document_annotations (
                document_id, section_id, user_id, annotation_type, content,
                start_position, end_position, is_public, tags, metadata,
                created_at, updated_at, resolved
            ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, NOW(), NOW(), false)
            RETURNING id
            """,
            annotation.document_id, annotation.section_id, user.sub,
            annotation.annotation_type, annotation.content,
            annotation.start_position, annotation.end_position,
            annotation.is_public, annotation.tags, annotation.metadata
        )
        
        # Get the created annotation with user info
        created_annotation = await conn.fetchrow(
            """
            SELECT da.*, u.display_name as user_name
            FROM document_annotations da
            LEFT JOIN (
                SELECT sub as user_id, display_name
                FROM auth_users
            ) u ON da.user_id = u.user_id
            WHERE da.id = $1
            """,
            annotation_id
        )
        
        await conn.close()
        
        return AnnotationResponse(
            id=created_annotation['id'],
            document_id=created_annotation['document_id'],
            section_id=created_annotation['section_id'],
            user_id=created_annotation['user_id'],
            user_name=created_annotation['user_name'] or 'Unknown User',
            annotation_type=created_annotation['annotation_type'],
            content=created_annotation['content'],
            start_position=created_annotation['start_position'],
            end_position=created_annotation['end_position'],
            is_public=created_annotation['is_public'],
            tags=created_annotation['tags'],
            metadata=created_annotation['metadata'],
            created_at=created_annotation['created_at'],
            updated_at=created_annotation['updated_at'],
            resolved=created_annotation['resolved'],
            resolved_by=created_annotation['resolved_by'],
            resolved_at=created_annotation['resolved_at']
        )
        
    except Exception as e:
        print(f"Error creating annotation: {e}")
        raise HTTPException(status_code=500, detail="Failed to create annotation")

@router.put("/annotations/{annotation_id}", response_model=AnnotationResponse)
async def update_annotation_collab(annotation_id: int, update_data: AnnotationUpdate, user: AuthorizedUser):
    """Update an existing annotation"""
    try:
        conn = await get_db_connection()
        
        # Check if annotation exists and user has permission
        annotation = await conn.fetchrow(
            "SELECT * FROM document_annotations WHERE id = $1",
            annotation_id
        )
        
        if not annotation:
            raise HTTPException(status_code=404, detail="Annotation not found")
        
        if annotation['user_id'] != user.sub:
            raise HTTPException(status_code=403, detail="Not authorized to update this annotation")
        
        # Build update query dynamically
        update_fields = []
        params = []
        param_count = 1
        
        if update_data.content is not None:
            update_fields.append(f"content = ${param_count}")
            params.append(update_data.content)
            param_count += 1
        
        if update_data.annotation_type is not None:
            update_fields.append(f"annotation_type = ${param_count}")
            params.append(update_data.annotation_type)
            param_count += 1
        
        if update_data.is_public is not None:
            update_fields.append(f"is_public = ${param_count}")
            params.append(update_data.is_public)
            param_count += 1
        
        if update_data.tags is not None:
            update_fields.append(f"tags = ${param_count}")
            params.append(update_data.tags)
            param_count += 1
        
        if update_data.resolved is not None:
            update_fields.append(f"resolved = ${param_count}")
            params.append(update_data.resolved)
            param_count += 1
            
            if update_data.resolved:
                update_fields.append(f"resolved_by = ${param_count}")
                params.append(user.sub)
                param_count += 1
                update_fields.append(f"resolved_at = NOW()")
        
        if not update_fields:
            raise HTTPException(status_code=400, detail="No fields to update")
        
        update_fields.append("updated_at = NOW()")
        params.append(annotation_id)
        
        await conn.execute(
            f"UPDATE document_annotations SET {', '.join(update_fields)} WHERE id = ${len(params)}",
            *params
        )
        
        # Get updated annotation
        updated_annotation = await conn.fetchrow(
            """
            SELECT da.*, u.display_name as user_name
            FROM document_annotations da
            LEFT JOIN (
                SELECT sub as user_id, display_name
                FROM auth_users
            ) u ON da.user_id = u.user_id
            WHERE da.id = $1
            """,
            annotation_id
        )
        
        await conn.close()
        
        return AnnotationResponse(
            id=updated_annotation['id'],
            document_id=updated_annotation['document_id'],
            section_id=updated_annotation['section_id'],
            user_id=updated_annotation['user_id'],
            user_name=updated_annotation['user_name'] or 'Unknown User',
            annotation_type=updated_annotation['annotation_type'],
            content=updated_annotation['content'],
            start_position=updated_annotation['start_position'],
            end_position=updated_annotation['end_position'],
            is_public=updated_annotation['is_public'],
            tags=updated_annotation['tags'],
            metadata=updated_annotation['metadata'],
            created_at=updated_annotation['created_at'],
            updated_at=updated_annotation['updated_at'],
            resolved=updated_annotation['resolved'],
            resolved_by=updated_annotation['resolved_by'],
            resolved_at=updated_annotation['resolved_at']
        )
        
    except Exception as e:
        print(f"Error updating annotation: {e}")
        raise HTTPException(status_code=500, detail="Failed to update annotation")

@router.delete("/annotations/{annotation_id}")
async def delete_annotation_collab(annotation_id: int, user: AuthorizedUser):
    """Delete an annotation"""
    try:
        conn = await get_db_connection()
        
        # Check if annotation exists and user has permission
        annotation = await conn.fetchrow(
            "SELECT * FROM document_annotations WHERE id = $1 AND user_id = $2",
            annotation_id, user.sub
        )
        
        if not annotation:
            raise HTTPException(status_code=404, detail="Annotation not found")
        
        # Delete annotation
        await conn.execute(
            "DELETE FROM document_annotations WHERE id = $1",
            annotation_id
        )
        
        await conn.close()
        
        return {"message": "Annotation deleted successfully"}
        
    except Exception as e:
        print(f"Error deleting annotation: {e}")
        raise HTTPException(status_code=500, detail="Failed to delete annotation")

@router.post("/annotations/{annotation_id}/resolve")
async def resolve_annotation_collab(annotation_id: int, user: AuthorizedUser):
    """Mark an annotation as resolved"""
    try:
        conn = await get_db_connection()
        
        # Update annotation to resolved
        await conn.execute(
            """UPDATE document_annotations 
               SET resolved = true, resolved_by = $1, resolved_at = NOW()
               WHERE id = $2""",
            user.sub, annotation_id
        )
        
        await conn.close()
        
        return {"message": "Annotation resolved successfully"}
        
    except Exception as e:
        print(f"Error resolving annotation: {e}")
        raise HTTPException(status_code=500, detail="Failed to resolve annotation")

# Bookmark Endpoints
@router.get("/bookmarks", response_model=List[BookmarkResponse])
async def get_user_bookmarks_collab(user: AuthorizedUser, document_id: Optional[int] = None):
    """Get user's bookmarks"""
    try:
        conn = await get_db_connection()
        
        if document_id:
            where_clause = "WHERE b.user_id = $1 AND b.document_id = $2"
            params = [user.sub, document_id]
        else:
            where_clause = "WHERE b.user_id = $1"
            params = [user.sub]

        bookmarks = await conn.fetch(
            f"""
            SELECT b.*, d.title as document_title, ds.title as section_title
            FROM user_bookmarks b
            JOIN kb_documents d ON b.document_id = d.id
            LEFT JOIN kb_document_sections ds ON b.section_id = ds.id
            {where_clause}
            ORDER BY b.created_at DESC
            """,
            *params
        )
        
        await conn.close()
        
        return [
            BookmarkResponse(
                id=bookmark['id'],
                user_id=bookmark['user_id'],
                document_id=bookmark['document_id'],
                document_title=bookmark['document_title'],
                section_id=bookmark['section_id'],
                section_title=bookmark['section_title'],
                bookmark_type=bookmark['bookmark_type'],
                notes=bookmark['notes'],
                tags=bookmark['tags'],
                created_at=bookmark['created_at'],
                updated_at=bookmark['updated_at']
            )
            for bookmark in bookmarks
        ]
        
    except Exception as e:
        print(f"Error getting user bookmarks: {e}")
        raise HTTPException(status_code=500, detail="Failed to get user bookmarks")

@router.post("/bookmarks", response_model=BookmarkResponse)
async def create_bookmark_collab(bookmark: UserBookmark, user: AuthorizedUser):
    """Create a new bookmark"""
    try:
        conn = await get_db_connection()
        
        # Verify document exists
        doc_exists = await conn.fetchval(
            "SELECT EXISTS(SELECT 1 FROM kb_documents WHERE id = $1)",
            bookmark.document_id
        )
        
        if not doc_exists:
            raise HTTPException(status_code=404, detail="Document not found")
        
        # Check if bookmark already exists
        existing = await conn.fetchval(
            """
            SELECT id FROM user_bookmarks 
            WHERE user_id = $1 AND document_id = $2 AND 
                  COALESCE(section_id, 0) = COALESCE($3, 0)
            """,
            user.sub, bookmark.document_id, bookmark.section_id
        )
        
        if existing:
            raise HTTPException(status_code=400, detail="Bookmark already exists")
        
        # Create bookmark
        bookmark_id = await conn.fetchval(
            """
            INSERT INTO user_bookmarks (
                user_id, document_id, section_id, bookmark_type,
                notes, tags, created_at, updated_at
            ) VALUES ($1, $2, $3, $4, $5, $6, NOW(), NOW())
            RETURNING id
            """,
            user.sub, bookmark.document_id, bookmark.section_id,
            bookmark.bookmark_type, bookmark.notes, bookmark.tags
        )
        
        # Get created bookmark with document info
        created_bookmark = await conn.fetchrow(
            """
            SELECT ub.*, d.title as document_title, ds.title as section_title
            FROM user_bookmarks ub
            JOIN kb_documents d ON ub.document_id = d.id
            LEFT JOIN kb_document_sections ds ON ub.section_id = ds.id
            WHERE ub.id = $1
            """,
            bookmark_id
        )
        
        await conn.close()
        
        return BookmarkResponse(
            id=created_bookmark['id'],
            user_id=created_bookmark['user_id'],
            document_id=created_bookmark['document_id'],
            document_title=created_bookmark['document_title'],
            section_id=created_bookmark['section_id'],
            section_title=created_bookmark['section_title'],
            bookmark_type=created_bookmark['bookmark_type'],
            notes=created_bookmark['notes'],
            tags=created_bookmark['tags'],
            created_at=created_bookmark['created_at'],
            updated_at=created_bookmark['updated_at']
        )
        
    except Exception as e:
        print(f"Error creating bookmark: {e}")
        raise HTTPException(status_code=500, detail="Failed to create bookmark")

@router.delete("/bookmarks/{bookmark_id}")
async def delete_bookmark_collab(bookmark_id: int, user: AuthorizedUser):
    """Delete a bookmark"""
    try:
        conn = await get_db_connection()
        
        # Check if bookmark exists and belongs to user
        bookmark = await conn.fetchrow(
            "SELECT * FROM user_bookmarks WHERE id = $1 AND user_id = $2",
            bookmark_id, user.sub
        )
        
        if not bookmark:
            raise HTTPException(status_code=404, detail="Bookmark not found")
        
        # Delete bookmark
        await conn.execute(
            "DELETE FROM user_bookmarks WHERE id = $1",
            bookmark_id
        )
        
        await conn.close()
        
        return {"message": "Bookmark deleted successfully"}
        
    except Exception as e:
        print(f"Error deleting bookmark: {e}")
        raise HTTPException(status_code=500, detail="Failed to delete bookmark")

# Activity Tracking
@router.get("/documents/{document_id}/activity", response_model=List[ActivityResponse])
async def get_document_activity_collab(document_id: int, user: AuthorizedUser):
    """Get document activity history"""
    try:
        conn = await get_db_connection()
        
        # Query document activity
        activity_query = """SELECT * FROM document_activity 
                           WHERE document_id = $1 
                           ORDER BY created_at DESC LIMIT 50"""
        
        rows = await conn.fetch(activity_query, document_id)
        
        await conn.close()
        
        return [
            ActivityResponse(
                id=row['id'],
                user_id=row['user_id'],
                user_name=row['user_name'] or 'Unknown User',
                document_id=row['document_id'],
                document_title=row['document_title'],
                activity_type=row['activity_type'],
                metadata=row['metadata'],
                created_at=row['created_at']
            )
            for row in rows
        ]
        
    except Exception as e:
        print(f"Error getting document activity: {e}")
        raise HTTPException(status_code=500, detail="Failed to get document activity")

@router.post("/documents/{document_id}/activity")
async def track_document_activity_collab(document_id: int, activity: DocumentActivity, user: AuthorizedUser):
    """Track a new document activity"""
    try:
        conn = await get_db_connection()
        
        # Insert activity record
        await conn.execute(
            """INSERT INTO document_activity 
               (document_id, user_id, activity_type, metadata, created_at)
               VALUES ($1, $2, $3, $4, NOW())""",
            document_id, user.sub, activity.activity_type, activity.metadata
        )
        
        await conn.close()
        
        return {"message": "Activity tracked successfully"}
        
    except Exception as e:
        print(f"Error tracking document activity: {e}")
        raise HTTPException(status_code=500, detail="Failed to track document activity")

# Collaboration Statistics
@router.get("/stats", response_model=CollaborationStatsResponse)
async def get_collaboration_stats_collab(user: AuthorizedUser, document_id: Optional[int] = None):
    """Get collaboration statistics"""
    try:
        conn = await get_db_connection()
        
        # Get stats for specific document or all documents
        if document_id:
            where_clause = "WHERE document_id = $1"
            params = [document_id]
        else:
            where_clause = ""
            params = []

        # Get annotation stats
        annotation_stats = await conn.fetchrow(
            f"""
            SELECT 
                COUNT(*) as total_annotations,
                COUNT(*) FILTER (WHERE is_public = true) as public_annotations,
                COUNT(*) FILTER (WHERE user_id = $1) as user_annotations,
                COUNT(*) FILTER (WHERE resolved = true) as resolved_annotations
            FROM document_annotations
            {where_clause}
            """,
            user.sub, *params
        )
        
        # Get bookmark stats
        bookmark_stats = await conn.fetchrow(
            f"SELECT COUNT(*) as total_bookmarks FROM user_bookmarks WHERE user_id = $1 {where_clause}",
            user.sub, *params
        )
        
        # Get recent activity count
        activity_count = await conn.fetchval(
            """
            SELECT COUNT(*) FROM document_activity 
            WHERE created_at >= CURRENT_DATE - INTERVAL '7 days'
            """
        )
        
        # Get top annotated documents
        top_docs = await conn.fetch(
            """
            SELECT d.id, d.title, COUNT(da.id) as annotation_count
            FROM kb_documents d
            JOIN document_annotations da ON d.id = da.document_id
            GROUP BY d.id, d.title
            ORDER BY annotation_count DESC
            LIMIT 5
            """
        )
        
        # Calculate collaboration score (simple metric)
        collaboration_score = (
            (annotation_stats['user_annotations'] or 0) * 2 +
            (bookmark_stats['total_bookmarks'] or 0) * 1 +
            (activity_count or 0) * 0.5
        )
        
        await conn.close()
        
        return CollaborationStats(
            total_annotations=annotation_stats['total_annotations'] or 0,
            public_annotations=annotation_stats['public_annotations'] or 0,
            user_annotations=annotation_stats['user_annotations'] or 0,
            resolved_annotations=annotation_stats['resolved_annotations'] or 0,
            total_bookmarks=bookmark_stats['total_bookmarks'] or 0,
            recent_activity_count=activity_count or 0,
            top_annotated_documents=[
                {
                    "id": doc['id'],
                    "title": doc['title'],
                    "annotation_count": doc['annotation_count']
                }
                for doc in top_docs
            ],
            collaboration_score=collaboration_score
        )
        
    except Exception as e:
        print(f"Error getting collaboration stats: {e}")
        raise HTTPException(status_code=500, detail="Failed to get collaboration stats")

@router.get("/users/{user_id}/summary", response_model=UserCollaborationSummary)
async def get_user_collaboration_summary_collab(user_id: str, requesting_user: AuthorizedUser):
    """Get collaboration summary for a user"""
    try:
        conn = await get_db_connection()
        
        # Get user's collaboration stats
        user_stats = await conn.fetchrow(
            """SELECT 
                 COUNT(DISTINCT da.document_id) as documents_annotated,
                 COUNT(da.id) as total_annotations,
                 COUNT(CASE WHEN da.created_at > NOW() - INTERVAL '7 days' THEN 1 END) as recent_annotations
               FROM document_annotations da
               WHERE da.user_id = $1""",
            user_id
        )
        
        # Calculate user rank (simplified)
        user_rank = await conn.fetchval(
            """
            SELECT COUNT(*) + 1 as rank
            FROM (
                SELECT user_id, COUNT(*) as total_contributions
                FROM (
                    SELECT user_id FROM document_annotations
                    UNION ALL
                    SELECT user_id FROM user_bookmarks
                    UNION ALL
                    SELECT user_id FROM document_activity
                ) all_activities
                GROUP BY user_id
                HAVING COUNT(*) > (
                    SELECT COUNT(*)
                    FROM (
                        SELECT user_id FROM document_annotations WHERE user_id = $1
                        UNION ALL
                        SELECT user_id FROM user_bookmarks WHERE user_id = $1
                        UNION ALL
                        SELECT user_id FROM document_activity WHERE user_id = $1
                    ) user_activities
                )
            ) ranked_users
            """,
            user.sub
        ) or 1
        
        await conn.close()
        
        return UserCollaborationSummary(
            user_id=user.sub,
            user_name=user.display_name or 'Unknown User',
            annotations_created=user_stats['annotations_created'],
            annotations_resolved=user_stats['annotations_resolved'],
            bookmarks_created=user_stats['bookmarks_created'],
            documents_viewed=user_stats['documents_viewed'],
            last_activity=user_stats['last_activity'],
            collaboration_rank=user_rank
        )
        
    except Exception as e:
        print(f"Error getting user collaboration summary: {e}")
        raise HTTPException(status_code=500, detail="Failed to get user collaboration summary")
