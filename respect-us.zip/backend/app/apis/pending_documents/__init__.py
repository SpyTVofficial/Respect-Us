from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import List, Optional
import asyncpg
import databutton as db
from app.auth import AuthorizedUser
from datetime import datetime

router = APIRouter(prefix="/pending-documents")

class PendingDocumentResponse(BaseModel):
    id: int
    title: str
    description: Optional[str]
    uploaded_by: str
    uploaded_at: datetime
    file_name: Optional[str]
    file_size: Optional[int]
    document_type: Optional[str]
    jurisdiction: Optional[List[str]]
    regulation_type: Optional[List[str]]
    publishing_status: str
    extraction_method: Optional[str]
    
class ApprovalRequest(BaseModel):
    document_id: int
    action: str  # 'approve' or 'reject'
    admin_notes: Optional[str] = None

class PendingDocumentsListResponse(BaseModel):
    documents: List[PendingDocumentResponse]
    total_count: int

async def get_db_connection():
    database_url = db.secrets.get("DATABASE_URL_DEV")
    return await asyncpg.connect(database_url)

@router.get("/list", response_model=PendingDocumentsListResponse)
async def list_pending_documents(user: AuthorizedUser, limit: int = 50, offset: int = 0):
    """Get all documents pending admin approval"""
    conn = await get_db_connection()
    try:
        # Check if user is admin (simple check)
        is_admin = user.primaryEmail and 'admin' in user.primaryEmail.lower()
        if not is_admin:
            raise HTTPException(status_code=403, detail="Admin access required")
        
        # Get pending documents
        query = """
        SELECT id, title, description, uploaded_by, created_at as uploaded_at,
               file_name, file_size, document_type, country_jurisdiction as jurisdiction,
               regulation_type, publishing_status, extraction_method
        FROM kb_documents 
        WHERE publishing_status = 'draft'
        ORDER BY created_at DESC
        LIMIT $1 OFFSET $2
        """
        
        rows = await conn.fetch(query, limit, offset)
        
        # Get total count
        total_count = await conn.fetchval(
            "SELECT COUNT(*) FROM kb_documents WHERE publishing_status = 'draft'"
        )
        
        documents = []
        for row in rows:
            documents.append(PendingDocumentResponse(
                id=row['id'],
                title=row['title'],
                description=row['description'],
                uploaded_by=row['uploaded_by'],
                uploaded_at=row['uploaded_at'],
                file_name=row['file_name'],
                file_size=row['file_size'],
                document_type=row['document_type'],
                jurisdiction=row['jurisdiction'] or [],
                regulation_type=row['regulation_type'] or [],
                publishing_status=row['publishing_status'],
                extraction_method=row['extraction_method']
            ))
        
        return PendingDocumentsListResponse(
            documents=documents,
            total_count=total_count
        )
        
    finally:
        await conn.close()

@router.post("/approve")
async def approve_or_reject_document(request: ApprovalRequest, user: AuthorizedUser):
    """Approve or reject a pending document"""
    conn = await get_db_connection()
    try:
        # Check if user is admin
        is_admin = user.primaryEmail and 'admin' in user.primaryEmail.lower()
        if not is_admin:
            raise HTTPException(status_code=403, detail="Admin access required")
        
        # Update document status
        if request.action == 'approve':
            new_status = 'published'
            await conn.execute(
                """
                UPDATE kb_documents 
                SET publishing_status = $1, approved_by = $2, approved_at = $3, admin_notes = $4
                WHERE id = $5 AND publishing_status = 'draft'
                """,
                new_status, user.sub, datetime.utcnow(), request.admin_notes, request.document_id
            )
        elif request.action == 'reject':
            new_status = 'rejected'
            await conn.execute(
                """
                UPDATE kb_documents 
                SET publishing_status = $1, rejected_by = $2, rejected_at = $3, admin_notes = $4
                WHERE id = $5 AND publishing_status = 'draft'
                """,
                new_status, user.sub, datetime.utcnow(), request.admin_notes, request.document_id
            )
        else:
            raise HTTPException(status_code=400, detail="Invalid action. Use 'approve' or 'reject'")
        
        # Check if document was found and updated
        updated_count = await conn.fetchval(
            "SELECT COUNT(*) FROM kb_documents WHERE id = $1 AND publishing_status = $2",
            request.document_id, new_status
        )
        
        if updated_count == 0:
            raise HTTPException(status_code=404, detail="Document not found or already processed")
        
        return {
            "success": True,
            "message": f"Document {request.action}d successfully",
            "document_id": request.document_id,
            "new_status": new_status
        }
        
    finally:
        await conn.close()

@router.get("/stats")
async def get_pending_stats(user: AuthorizedUser):
    """Get statistics for pending documents"""
    conn = await get_db_connection()
    try:
        # Check if user is admin
        is_admin = user.primaryEmail and 'admin' in user.primaryEmail.lower()
        if not is_admin:
            raise HTTPException(status_code=403, detail="Admin access required")
        
        stats = await conn.fetchrow(
            """
            SELECT 
                COUNT(*) FILTER (WHERE publishing_status = 'draft') as pending_count,
                COUNT(*) FILTER (WHERE publishing_status = 'published') as published_count,
                COUNT(*) FILTER (WHERE publishing_status = 'rejected') as rejected_count,
                COUNT(*) FILTER (WHERE created_at >= NOW() - INTERVAL '7 days') as this_week_count
            FROM kb_documents
            """
        )
        
        return {
            "pending_count": stats['pending_count'],
            "published_count": stats['published_count'], 
            "rejected_count": stats['rejected_count'],
            "this_week_count": stats['this_week_count']
        }
        
    finally:
        await conn.close()
