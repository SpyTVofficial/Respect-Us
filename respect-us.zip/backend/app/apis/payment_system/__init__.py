



from fastapi import APIRouter, HTTPException, Depends, Query, Request, Header
from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
import asyncpg
from datetime import datetime, timedelta
import databutton as db
from app.auth import AuthorizedUser
from app.env import Mode, mode
import stripe
import json
from enum import Enum
from app.libs.vat_service import VATService

router = APIRouter()

# Configure Stripe - using test key for now
# TODO: User needs to add their Stripe secret key to db.secrets
try:
    stripe_key = db.secrets.get("STRIPE_SECRET_KEY")
    if stripe_key:
        stripe.api_key = stripe_key
    else:
        print("Warning: STRIPE_SECRET_KEY not found in secrets. Using test mode.")
        stripe.api_key = "sk_test_dummy_key_for_testing"
except Exception as e:
    print(f"Stripe configuration error: {e}")
    stripe.api_key = "sk_test_dummy_key_for_testing"

# Pydantic models
class ModuleInfo(BaseModel):
    name: str
    title: str
    description: str
    status: str  # 'available', 'locked', 'coming_soon'
    price_eur: Optional[float] = None
    user_has_access: bool = False
    templates_available: int = 0
    user_template_access: Optional[Dict[str, Any]] = None

class UserAccessStatus(BaseModel):
    modules: List[ModuleInfo]
    total_purchases: int
    active_subscriptions: int

class VATBreakdown(BaseModel):
    net_amount: float
    vat_amount: float
    gross_amount: float
    vat_rate: float
    vat_type: str
    country_code: Optional[str] = None

class CustomerDetails(BaseModel):
    company_name: str
    contact_person: str
    email: str
    phone: Optional[str] = None
    billing_address: str
    city: str
    postal_code: str
    country: str
    tax_id: Optional[str] = None
    vat_number: Optional[str] = None

class PaymentIntent(BaseModel):
    module_name: str
    template_id: Optional[int] = None
    price_amount: float
    currency: str = "EUR"
    customer_details: CustomerDetails

class PaymentIntentResponse(BaseModel):
    client_secret: str
    purchase_id: str
    amount: float  # This will be gross_amount (including VAT)
    currency: str
    company_name: str
    contact_person: str
    email: str
    phone: Optional[str] = None
    billing_address: str
    city: str
    postal_code: str
    country: str

class InvoiceRequest(BaseModel):
    # For custom credit purchases
    credits: Optional[int] = None
    amount: Optional[float] = None
    currency: str = "USD"
    
    # For module purchases (legacy)
    module_name: Optional[str] = None
    template_id: Optional[int] = None
    price_amount: Optional[float] = None
    customer_details: Optional[CustomerDetails] = None
    custom_credits: Optional[int] = None  # For custom credit amounts
    payment_method: str = "bank_transfer"  # Always bank transfer for invoices

class InvoiceResponse(BaseModel):
    invoice_id: str
    amount: float
    currency: str
    company_name: str
    contact_person: str
    email: str
    phone: Optional[str] = None
    billing_address: str
    city: str
    postal_code: str
    country: str
    payment_instructions: str
    due_date: str

class TemplateSelectionRequest(BaseModel):
    purchase_id: str
    template_id: int

class TemplateSelectionResponse(BaseModel):
    success: bool
    message: str
    access_granted: bool

# Default MODULE_CONFIG - will be overridden by database configurations
MODULE_CONFIG = {
    "validation_by_respectus": {
        "title": "Validation by RespectUs", 
        "description": "Professional validation and review services",
        "price_eur": None,  # Credit-based pricing
        "credit_cost": 1900,  # Default fallback
        "status": "available"
    },
    "risk_assessment": {
        "title": "Risk Assessment", 
        "description": "Comprehensive export control risk assessment tools",
        "price_eur": None,  # Credit-based pricing
        "credit_cost": 4000,  # Default fallback
        "status": "available"
    },
    "product_classification": {
        "title": "Product Classification",
        "description": "Classify products for export control",
        "price_eur": None,
        "status": "available"
    },
    "sanctions_embargoes": {
        "title": "Sanctions & Embargoes",
        "description": "Sanctions and embargo compliance checks",
        "price_eur": None,
        "status": "available"
    },
    "customer_screening": {
        "title": "Customer Screening",
        "description": "Verify customer compliance status",
        "price_eur": None,
        "status": "available"
    },
    "end_use_check": {
        "title": "End-use Check",
        "description": "Verify intended use compliance",
        "price_eur": None,
        "status": "available"
    },
    "license_determination": {
        "title": "License Determination",
        "description": "Determine required export licenses",
        "price_eur": None,
        "status": "available"
    }
}

# Database connection helper
async def get_db_connection():
    """Get database connection based on environment"""
    if mode == Mode.PROD:
        database_url = db.secrets.get("DATABASE_URL_PROD")
    else:
        database_url = db.secrets.get("DATABASE_URL_DEV")
    return await asyncpg.connect(database_url)

# Load module pricing from database
async def load_module_pricing_config():
    """Load module pricing configurations from database"""
    try:
        conn = await get_db_connection()
        try:
            query = """
                SELECT module_name, module_title, pricing_type, credit_cost, price_eur, description, is_active
                FROM module_pricing_config
                WHERE is_active = true
            """
            rows = await conn.fetch(query)
            
            # Update MODULE_CONFIG with database configurations
            for row in rows:
                module_name = row['module_name']
                if module_name in MODULE_CONFIG:
                    MODULE_CONFIG[module_name].update({
                        "title": row['module_title'],
                        "description": row['description'] or MODULE_CONFIG[module_name]["description"],
                        "credit_cost": row['credit_cost'] if row['pricing_type'] == 'credits' else None,
                        "price_eur": row['price_eur'] if row['pricing_type'] == 'eur' else None,
                        "status": "available" if row['is_active'] else "unavailable"
                    })
                else:
                    # Add new module configuration from database
                    MODULE_CONFIG[module_name] = {
                        "title": row['module_title'],
                        "description": row['description'] or "Module description",
                        "credit_cost": row['credit_cost'] if row['pricing_type'] == 'credits' else None,
                        "price_eur": row['price_eur'] if row['pricing_type'] == 'eur' else None,
                        "status": "available" if row['is_active'] else "unavailable"
                    }
        finally:
            await conn.close()
    except Exception as e:
        print(f"Warning: Could not load module pricing config from database: {e}")
        # Continue with default configuration

@router.get("/user-access-status")
async def get_user_access_status(user: AuthorizedUser):
    """Get user's module access status and subscription information"""
    try:
        # All 7 modules are now free to access - only actions/components cost credits
        all_modules = []
        
        for module_name, config in MODULE_CONFIG.items():
            module_info = {
                "name": module_name,
                "title": config["title"],
                "description": config["description"],
                "status": config["status"],
                "user_has_access": True,  # ALL modules are free to access
                "templates_available": 1 if module_name == "risk_assessment" else 0
            }
            
            all_modules.append(module_info)
        
        # Note: Component/action pricing is handled separately in component_pricing_config table
        # Risk Assessment submit_assessment: 4000 credits
        # Validation validation_by_respectus: 1900 credits
        
        return {
            "modules": all_modules,
            "total_purchases": 0,  # No module purchases needed anymore
            "active_subscriptions": len(all_modules)  # All modules are accessible
        }
        
    except Exception as e:
        print(f"Error getting user access status: {e}")
        # Return safe default status
        return {
            "modules": [
                {
                    "name": "knowledge_base",
                    "title": "Knowledge Base",
                    "description": "Export control regulations and guidance",
                    "status": "coming_soon",
                    "user_has_access": True,
                    "templates_available": 0
                },
                {
                    "name": "risk_assessment",
                    "title": "Risk Assessment",
                    "description": "Comprehensive export control risk assessment tools",
                    "status": "available",
                    "price_eur": 199,
                    "user_has_access": False,
                    "templates_available": 1
                },
                {
                    "name": "product_classification",
                    "title": "Product Classification",
                    "description": "Classify products for export control",
                    "status": "coming_soon",
                    "user_has_access": False,
                    "templates_available": 0
                },
                {
                    "name": "sanctions_embargoes",
                    "title": "Sanctions & Embargoes",
                    "description": "Check sanctions and embargo restrictions",
                    "status": "coming_soon",
                    "user_has_access": False,
                    "templates_available": 0
                },
                {
                    "name": "customer_screening",
                    "title": "Customer Screening",
                    "description": "Screen customers against watchlists",
                    "status": "coming_soon",
                    "user_has_access": False,
                    "templates_available": 0
                },
                {
                    "name": "end_use_check",
                    "title": "End-use Check",
                    "description": "Verify end-use and end-user compliance",
                    "status": "coming_soon",
                    "user_has_access": False,
                    "templates_available": 0
                },
                {
                    "name": "license_determination",
                    "title": "License Determination",
                    "description": "Determine export license requirements",
                    "status": "coming_soon",
                    "user_has_access": False,
                    "templates_available": 0
                }
            ],
            "total_purchases": 0,
            "active_subscriptions": 1
        }

class VATPreviewRequest(BaseModel):
    module_name: str
    customer_country: str
    vat_number: Optional[str] = None

class VATPreviewResponse(BaseModel):
    vat_breakdown: VATBreakdown
    price_display: str

@router.post("/vat-preview", response_model=VATPreviewResponse)
async def get_vat_preview(request: VATPreviewRequest, user: AuthorizedUser):
    """
    Calculate VAT preview for a module purchase without creating payment intent
    """
    try:
        # Validate module exists
        if request.module_name not in MODULE_CONFIG:
            raise HTTPException(status_code=400, detail="Invalid module name")
        
        module_config = MODULE_CONFIG[request.module_name]
        base_price = module_config["price_eur"]
        
        # Calculate VAT breakdown
        vat_breakdown = VATService.calculate_vat(
            net_amount=base_price,
            customer_country=request.customer_country,
            vat_number=request.vat_number
        )
        
        # Generate price display string
        price_display = VATService.format_price_display(
            net_amount=base_price,
            customer_country=request.customer_country,
            vat_number=request.vat_number
        )
        
        return VATPreviewResponse(
            vat_breakdown=VATBreakdown(**vat_breakdown),
            price_display=price_display
        )
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error calculating VAT preview: {e}")
        raise HTTPException(status_code=500, detail="Failed to calculate VAT preview")

@router.post("/create-payment-intent", response_model=PaymentIntentResponse)
async def create_payment_intent(request: PaymentIntent, user: AuthorizedUser):
    """
    Create a Stripe payment intent for module access
    """
    try:
        # Validate module exists and is available
        if request.module_name not in MODULE_CONFIG:
            raise HTTPException(status_code=400, detail="Invalid module name")
        
        module_config = MODULE_CONFIG[request.module_name]
        if module_config["status"] != "available":
            raise HTTPException(status_code=400, detail="Module not available for purchase")
        
        # Calculate VAT breakdown - request.price_amount should be the net amount
        vat_breakdown = VATService.calculate_vat(
            net_amount=request.price_amount,
            customer_country=request.customer_details.country,
            vat_number=request.customer_details.vat_number
        )
        
        # Validate net price matches module config
        if request.price_amount != module_config["price_eur"]:
            raise HTTPException(status_code=400, detail="Invalid price amount")
        
        # Use gross amount (including VAT) for Stripe payment
        payment_amount = vat_breakdown["gross_amount"]
        
        conn = await get_db_connection()
        
        # Check if user already has access
        existing_access = await conn.fetchrow(
            "SELECT id FROM user_module_access WHERE user_id = $1 AND module_name = $2 AND access_status = 'active'",
            user.sub, request.module_name
        )
        
        if existing_access:
            await conn.close()
            raise HTTPException(status_code=400, detail="User already has access to this module")
        
        # Generate purchase ID
        purchase_id = f"PUR_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{user.sub[:8]}"
        
        # Create payment intent with Stripe
        try:
            stripe_intent = stripe.PaymentIntent.create(
                amount=int(payment_amount * 100),  # Stripe expects cents, use gross amount
                currency=request.currency.lower(),
                automatic_payment_methods={
                    'enabled': True,
                },
                metadata={
                    'user_id': user.sub,
                    'purchase_id': purchase_id,
                    'module_name': request.module_name,
                    'template_id': str(request.template_id) if request.template_id else None,
                    'company_name': request.customer_details.company_name,
                    'contact_person': request.customer_details.contact_person,
                    'vat_type': vat_breakdown["vat_type"],
                    'vat_rate': str(vat_breakdown["vat_rate"]),
                    'vat_amount': str(vat_breakdown["vat_amount"]),
                    'net_amount': str(vat_breakdown["net_amount"])
                }
            )
            client_secret = stripe_intent.client_secret
            stripe_payment_intent_id = stripe_intent.id
        except Exception as stripe_error:
            print(f"Stripe error: {stripe_error}")
            # Fallback to mock for testing
            client_secret = f"pi_mock_{purchase_id}_secret"
            stripe_payment_intent_id = f"pi_mock_{purchase_id}"
        
        # Store customer details first
        customer_id = f"cust_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{user.sub[:8]}"
        await conn.execute(
            """
            INSERT INTO customer_details 
            (customer_id, user_id, company_name, contact_person, email, phone,
             billing_address, city, postal_code, country, tax_id, vat_number, created_at, updated_at)
            VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14)
            ON CONFLICT (user_id) DO UPDATE SET
                company_name = EXCLUDED.company_name,
                contact_person = EXCLUDED.contact_person,
                email = EXCLUDED.email,
                phone = EXCLUDED.phone,
                billing_address = EXCLUDED.billing_address,
                city = EXCLUDED.city,
                postal_code = EXCLUDED.postal_code,
                country = EXCLUDED.country,
                tax_id = EXCLUDED.tax_id,
                vat_number = EXCLUDED.vat_number,
                updated_at = EXCLUDED.updated_at
            """,
            customer_id, user.sub, request.customer_details.company_name, 
            request.customer_details.contact_person, request.customer_details.email,
            request.customer_details.phone, request.customer_details.billing_address,
            request.customer_details.city, request.customer_details.postal_code,
            request.customer_details.country, request.customer_details.tax_id,
            request.customer_details.vat_number, datetime.now(), datetime.now()
        )
        
        # Save purchase record with VAT breakdown
        await conn.execute(
            """
            INSERT INTO user_purchases (
                user_id, purchase_id, module_name, template_id, price_amount, currency,
                payment_method, payment_status, stripe_payment_intent_id, customer_id,
                net_amount, vat_amount, vat_rate, vat_type
            ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14)
            """,
            user.sub, purchase_id, request.module_name, request.template_id,
            payment_amount, request.currency, "stripe", "pending",  # price_amount is now gross
            stripe_payment_intent_id, customer_id,
            vat_breakdown["net_amount"], vat_breakdown["vat_amount"], 
            vat_breakdown["vat_rate"], vat_breakdown["vat_type"]
        )
        
        await conn.close()
        
        return PaymentIntentResponse(
            client_secret=client_secret,
            purchase_id=purchase_id,
            amount=payment_amount,  # Return gross amount
            currency=request.currency,
            company_name=request.customer_details.company_name,
            contact_person=request.customer_details.contact_person,
            email=request.customer_details.email,
            phone=request.customer_details.phone,
            billing_address=request.customer_details.billing_address,
            city=request.customer_details.city,
            postal_code=request.customer_details.postal_code,
            country=request.customer_details.country
        )
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error creating payment intent: {e}")
        raise HTTPException(status_code=500, detail="Failed to create payment intent")

@router.post("/request-invoice", response_model=InvoiceResponse)
async def request_invoice(request: InvoiceRequest, user: AuthorizedUser):
    """
    Request an invoice for bank transfer payment (supports custom credit amounts)
    """
    try:
        from datetime import datetime, timedelta
        
        print(f"DEBUG: Received request - credits={request.credits}, amount={request.amount}, module_name={request.module_name}")
        
        conn = await get_db_connection()
        
        # Handle new simplified structure for custom credits
        if request.credits and request.amount:
            # Custom credit purchase - use simplified flow
            payment_amount = request.amount
            currency = request.currency
            custom_credits = request.credits
            module_name = 'custom_credits'
            
            print(f"DEBUG: Custom credit purchase - module_name={module_name}, credits={custom_credits}, amount={payment_amount}")
            
            # Use default customer details from user profile or create minimal ones
            try:
                user_profile = await conn.fetchrow(
                    "SELECT * FROM user_profiles WHERE user_id = $1", user.sub
                )
                
                if user_profile:
                    customer_details_dict = {
                        'company_name': user_profile['company_name'] or 'Company',
                        'contact_person': user_profile['contact_person'] or 'Contact',
                        'email': user_profile['contact_email'] or 'email@example.com',
                        'phone': user_profile['contact_phone'] or '',
                        'billing_address': user_profile['billing_address'] or 'Address',
                        'city': 'City',
                        'postal_code': '12345',
                        'country': 'DE',
                        'tax_id': '',
                        'vat_number': ''
                    }
                else:
                    customer_details_dict = {
                        'company_name': 'Company',
                        'contact_person': 'Contact',
                        'email': 'email@example.com',
                        'phone': '',
                        'billing_address': 'Address',
                        'city': 'City',
                        'postal_code': '12345',
                        'country': 'DE',
                        'tax_id': '',
                        'vat_number': ''
                    }
            except Exception:
                customer_details_dict = {
                    'company_name': 'Company',
                    'contact_person': 'Contact',
                    'email': 'email@example.com',
                    'phone': '',
                    'billing_address': 'Address',
                    'city': 'City',
                    'postal_code': '12345',
                    'country': 'DE',
                    'tax_id': '',
                    'vat_number': ''
                }
        else:
            # Legacy module purchase structure OR treat as custom credits if no module_name
            if request.module_name is None:
                # Treat as custom credit purchase with default values
                payment_amount = 10.0  # Default amount for testing
                currency = request.currency
                custom_credits = 10000  # Default credits for testing
                module_name = 'custom_credits'
                print(f"DEBUG: Fallback custom credit purchase - module_name={module_name}")
                
                # Use default customer details
                customer_details_dict = {
                    'company_name': 'Company',
                    'contact_person': 'Contact',
                    'email': 'email@example.com',
                    'phone': '',
                    'billing_address': 'Address',
                    'city': 'City',
                    'postal_code': '12345',
                    'country': 'DE',
                    'tax_id': '',
                    'vat_number': ''
                }
            else:
                # Legacy module purchase
                if not request.customer_details or not request.price_amount:
                    raise HTTPException(status_code=400, detail="Missing required fields for module purchase")
                    
                # Calculate VAT breakdown
                vat_breakdown = VATService.calculate_vat(
                    net_amount=request.price_amount,
                    customer_country=request.customer_details.country,
                    vat_number=request.customer_details.vat_number
                )
                
                payment_amount = vat_breakdown["gross_amount"]
                currency = request.currency
                custom_credits = request.custom_credits
                module_name = request.module_name
                customer_details_dict = {
                    'company_name': request.customer_details.company_name,
                    'contact_person': request.customer_details.contact_person,
                    'email': request.customer_details.email,
                    'phone': request.customer_details.phone,
                    'billing_address': request.customer_details.billing_address,
                    'city': request.customer_details.city,
                    'postal_code': request.customer_details.postal_code,
                    'country': request.customer_details.country,
                    'tax_id': request.customer_details.tax_id,
                    'vat_number': request.customer_details.vat_number
                }
        
        # Generate invoice ID
        invoice_id = f"INV_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{user.sub[:8]}"
        
        # Store customer details first
        customer_id = f"cust_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{user.sub[:8]}"
        await conn.execute(
            """
            INSERT INTO customer_details 
            (customer_id, user_id, company_name, contact_person, email, phone,
             billing_address, city, postal_code, country, tax_id, vat_number, created_at, updated_at)
            VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14)
            ON CONFLICT (user_id) DO UPDATE SET
                company_name = EXCLUDED.company_name,
                contact_person = EXCLUDED.contact_person,
                email = EXCLUDED.email,
                phone = EXCLUDED.phone,
                billing_address = EXCLUDED.billing_address,
                city = EXCLUDED.city,
                postal_code = EXCLUDED.postal_code,
                country = EXCLUDED.country,
                tax_id = EXCLUDED.tax_id,
                vat_number = EXCLUDED.vat_number,
                updated_at = EXCLUDED.updated_at
            """,
            customer_id, user.sub, customer_details_dict['company_name'],
            customer_details_dict['contact_person'], customer_details_dict['email'],
            customer_details_dict['phone'], customer_details_dict['billing_address'],
            customer_details_dict['city'], customer_details_dict['postal_code'],
            customer_details_dict['country'], customer_details_dict['tax_id'],
            customer_details_dict['vat_number'], datetime.now(), datetime.now()
        )
        
        # Save invoice record
        await conn.execute(
            """
            INSERT INTO user_purchases (
                user_id, purchase_id, module_name, template_id, price_amount, currency,
                payment_method, payment_status, stripe_payment_intent_id, customer_id,
                net_amount, vat_amount, vat_rate, vat_type, custom_credits
            ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15)
            """,
            user.sub, invoice_id, module_name, request.template_id,
            payment_amount, currency, "bank_transfer", "pending_invoice",
            None, customer_id,  # No Stripe payment intent for bank transfer
            payment_amount, 0.0,  # For custom credits, no VAT breakdown needed
            0.0, 'none', custom_credits
        )
        
        await conn.close()
        
        # Calculate due date (14 days from now)
        due_date = (datetime.now() + timedelta(days=14)).strftime('%Y-%m-%d')
        
        # Generate payment instructions
        currency_symbol = '$' if currency == 'USD' else '€'
        payment_instructions = f"""
Please transfer the amount to our bank account:

Bank: RespectUs Compliance Bank
Account Number: DE89 3704 0044 0532 0130 00
BIC/SWIFT: COBADEFFXXX
Reference: {invoice_id}

Amount: {currency_symbol}{payment_amount:.2f}
Due Date: {due_date}

Please include the invoice ID ({invoice_id}) in the transfer reference.
Once payment is received, your credits will be activated within 1-2 business days.
        """.strip()
        
        return InvoiceResponse(
            invoice_id=invoice_id,
            amount=payment_amount,
            currency=currency,
            company_name=customer_details_dict['company_name'],
            contact_person=customer_details_dict['contact_person'],
            email=customer_details_dict['email'],
            phone=customer_details_dict['phone'],
            billing_address=customer_details_dict['billing_address'],
            city=customer_details_dict['city'],
            postal_code=customer_details_dict['postal_code'],
            country=customer_details_dict['country'],
            payment_instructions=payment_instructions,
            due_date=due_date
        )
        
    except Exception as e:
        print(f"Error creating invoice: {e}")
        raise HTTPException(status_code=500, detail="Failed to create invoice")

@router.post("/select-template", response_model=TemplateSelectionResponse)
async def select_template(request: TemplateSelectionRequest, user: AuthorizedUser):
    """
    Select a template after successful payment
    """
    try:
        conn = await get_db_connection()
        
        # Verify purchase exists and is completed
        purchase = await conn.fetchrow(
            """
            SELECT id, module_name, payment_status FROM user_purchases 
            WHERE purchase_id = $1 AND user_id = $2
            """,
            request.purchase_id, user.sub
        )
        
        if not purchase:
            await conn.close()
            raise HTTPException(status_code=404, detail="Purchase not found")
        
        if purchase['payment_status'] != 'completed':
            await conn.close()
            raise HTTPException(status_code=400, detail="Payment not completed")
        
        # Verify template exists
        template = await conn.fetchrow(
            "SELECT id FROM assessment_templates WHERE id = $1 AND status = 'active'",
            request.template_id
        )
        
        if not template:
            await conn.close()
            raise HTTPException(status_code=404, detail="Template not found")
        
        # Grant access to the template
        await conn.execute(
            """
            INSERT INTO user_module_access (
                user_id, module_name, template_id, purchase_id, access_type, access_status
            ) VALUES ($1, $2, $3, $4, $5, $6)
            ON CONFLICT (user_id, module_name, template_id) 
            DO UPDATE SET access_status = 'active', updated_at = NOW()
            """,
            user.sub, purchase['module_name'], request.template_id, 
            request.purchase_id, 'template_specific', 'active'
        )
        
        # Update purchase with template selection
        await conn.execute(
            "UPDATE user_purchases SET template_id = $1, access_granted_at = $2, updated_at = $3 WHERE purchase_id = $4",
            request.template_id, datetime.now(), datetime.now(), request.purchase_id
        )
        
        await conn.close()
        
        return TemplateSelectionResponse(
            success=True,
            message="Template access granted successfully",
            access_granted=True
        )
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error selecting template: {e}")
        raise HTTPException(status_code=500, detail="Failed to select template")

@router.post("/complete-template-selection")
async def complete_template_selection(request: TemplateSelectionRequest, user: AuthorizedUser):
    """Complete template selection after successful payment verification"""
    try:
        async with get_db_connection() as conn:
            # Check if user has active purchase for risk assessment
            purchase_check = await conn.fetchrow("""
                SELECT id, purchase_id, module_name, template_id, payment_status 
                FROM user_purchases 
                WHERE user_id = $1 AND module_name = 'risk_assessment' AND status = 'active'
                ORDER BY created_at DESC
                LIMIT 1
            """, user.sub)
            
            if not purchase_check:
                raise HTTPException(
                    status_code=403, 
                    detail="No active purchase found for Risk Assessment module. Please complete payment first."
                )
            
            # Check if payment is completed
            if purchase_check['payment_status'] != 'completed':
                raise HTTPException(
                    status_code=400, 
                    detail="Payment not yet completed. Please wait for payment confirmation."
                )
            
            # Check if template is already selected
            if purchase_check['template_id'] is not None:
                # Get current template info
                current_template = await conn.fetchrow("""
                    SELECT title FROM assessment_templates WHERE id = $1
                """, purchase_check['template_id'])
                
                return TemplateSelectionResponse(
                    success=True,
                    message=f"Template already selected: {current_template['title'] if current_template else 'Unknown'}",
                    template_id=purchase_check['template_id'],
                    template_title=current_template['title'] if current_template else 'Unknown',
                    access_granted=True
                )
            
            # Verify requested template exists and is active
            template_check = await conn.fetchrow("""
                SELECT id, title, status FROM assessment_templates 
                WHERE id = $1 AND is_active = true
            """, request.template_id)
            
            if not template_check:
                raise HTTPException(
                    status_code=404, 
                    detail="Template not found or not available"
                )
            
            # Update purchase with selected template
            await conn.execute("""
                UPDATE user_purchases 
                SET template_id = $1, access_granted_at = $2, updated_at = $3
                WHERE user_id = $4 AND module_name = 'risk_assessment' AND status = 'active'
            """, request.template_id, datetime.now(), datetime.now(), user.sub)
            
            return TemplateSelectionResponse(
                success=True,
                message=f"Template '{template_check['title']}' successfully selected! You now have full access to the Risk Assessment module.",
                template_id=request.template_id,
                template_title=template_check['title'],
                access_granted=True
            )
            
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error in template selection: {e}")
        raise HTTPException(status_code=500, detail="Failed to select template")

@router.patch("/webhook/stripe")
async def stripe_webhook(request: Request):
    """
    Handle Stripe webhook events for payment confirmations
    """
    try:
        payload = await request.body()
        sig_header = request.headers.get('stripe-signature')
        
        # For now, just log the webhook (in production, verify signature)
        print(f"Stripe webhook received: {payload.decode()[:200]}...")
        
        return {"status": "success"}
    except Exception as e:
        print(f"Stripe webhook error: {e}")
        raise HTTPException(status_code=400, detail="Webhook error")

@router.get("/admin/customers")
async def get_admin_customers(user: AuthorizedUser):
    """
    Get all customer details for admin dashboard
    """
    conn = await get_db_connection()
    try:
        customers = await conn.fetch(
            """
            SELECT 
                cd.customer_id,
                cd.company_name,
                cd.contact_person,
                cd.email,
                cd.phone,
                cd.billing_address,
                cd.city,
                cd.postal_code,
                cd.country,
                cd.tax_id,
                cd.vat_number,
                cd.created_at,
                cd.updated_at,
                COUNT(up.id) as total_purchases,
                SUM(CASE WHEN up.payment_status = 'completed' THEN up.price_amount ELSE 0 END) as total_spent
            FROM customer_details cd
            LEFT JOIN user_purchases up ON cd.user_id = up.user_id
            GROUP BY cd.customer_id, cd.company_name, cd.contact_person, cd.email, 
                     cd.phone, cd.billing_address, cd.city, cd.postal_code, 
                     cd.country, cd.tax_id, cd.vat_number, cd.created_at, cd.updated_at
            ORDER BY cd.created_at DESC
            """
        )
        
        customers_list = []
        for customer in customers:
            customers_list.append({
                "customer_id": customer["customer_id"],
                "company_name": customer["company_name"],
                "contact_person": customer["contact_person"],
                "email": customer["email"],
                "phone": customer["phone"],
                "billing_address": customer["billing_address"],
                "city": customer["city"],
                "postal_code": customer["postal_code"],
                "country": customer["country"],
                "tax_id": customer["tax_id"],
                "vat_number": customer["vat_number"],
                "created_at": customer["created_at"].isoformat() if customer["created_at"] else None,
                "updated_at": customer["updated_at"].isoformat() if customer["updated_at"] else None,
                "total_purchases": customer["total_purchases"],
                "total_spent": float(customer["total_spent"]) if customer["total_spent"] else 0.0
            })
        
        return {
            "customers": customers_list,
            "total_count": len(customers_list)
        }
    
    except Exception as e:
        print(f"Error fetching customers: {e}")
        raise HTTPException(status_code=500, detail="Failed to fetch customers")
    finally:
        await conn.close()

# Load module pricing configurations on startup
async def initialize_module_pricing():
    """Initialize default module pricing if none exists"""
    conn = await get_db_connection()
    try:
        # Check if module pricing exists
        existing = await conn.fetchrow("SELECT COUNT(*) as count FROM module_pricing_config")
        if existing['count'] == 0:
            # Add default pricing
            await conn.execute(
                """
                INSERT INTO module_pricing_config (module_name, credit_cost, description, is_active)
                VALUES 
                    ('risk_assessment', 4000, 'Comprehensive risk assessment validation', true),
                    ('validation_by_respectus', 1900, 'Expert validation by RespectUs team', true)
                """
            )
            print("✅ Default module pricing initialized")
    except Exception as e:
        print(f"Error initializing module pricing: {e}")
    finally:
        await conn.close()

@router.get("/admin/all-users")
async def get_all_admin_users(user: AuthorizedUser):
    """
    Get comprehensive list of all users for admin dashboard
    Includes both users with customer details and registered users without billing info
    """
    conn = await get_db_connection()
    try:
        # Get users with customer details
        customers_query = """
            SELECT 
                cd.customer_id,
                cd.user_id,
                cd.company_name,
                cd.contact_person,
                cd.email,
                cd.phone,
                cd.billing_address,
                cd.city,
                cd.postal_code,
                cd.country,
                cd.tax_id,
                cd.vat_number,
                cd.created_at,
                cd.updated_at,
                COUNT(up.id) as total_purchases,
                SUM(CASE WHEN up.payment_status = 'completed' THEN up.price_amount ELSE 0 END) as total_spent,
                'customer' as user_type
            FROM customer_details cd
            LEFT JOIN user_purchases up ON cd.user_id = up.user_id
            GROUP BY cd.customer_id, cd.user_id, cd.company_name, cd.contact_person, cd.email, 
                     cd.phone, cd.billing_address, cd.city, cd.postal_code, 
                     cd.country, cd.tax_id, cd.vat_number, cd.created_at, cd.updated_at
        """
        
        customers = await conn.fetch(customers_query)
        
        # Get additional registered users (from various tables that reference user_id)
        registered_users_query = """
            SELECT DISTINCT
                user_id,
                'registered' as user_type,
                NULL as customer_id,
                NULL as company_name,
                NULL as contact_person,
                NULL as email,
                NULL as phone,
                NULL as billing_address,
                NULL as city,
                NULL as postal_code,
                NULL as country,
                NULL as tax_id,
                NULL as vat_number,
                MIN(created_at) as created_at,
                MAX(updated_at) as updated_at,
                0 as total_purchases,
                0 as total_spent
            FROM (
                SELECT sa.user_id, sa.created_at, sa.updated_at FROM saved_assessments sa
                UNION
                SELECT sc.user_id, sc.created_at, sc.updated_at FROM saved_classifications sc
                UNION 
                SELECT vr.user_id, vr.created_at, vr.updated_at FROM validation_requests vr
                UNION
                SELECT cu.user_id, cu.created_at, cu.created_at as updated_at FROM credit_usage cu
                UNION
                SELECT up.user_id, up.created_at, up.created_at as updated_at FROM user_purchases up
            ) all_users
            WHERE user_id NOT IN (SELECT user_id FROM customer_details)
            GROUP BY user_id
        """
        
        registered_users = await conn.fetch(registered_users_query)
        
        # Combine and format all users
        all_users = []
        
        # Add customers
        for customer in customers:
            all_users.append({
                "customer_id": customer["customer_id"],
                "user_id": customer["user_id"],
                "user_type": "customer",
                "company_name": customer["company_name"],
                "contact_person": customer["contact_person"],
                "email": customer["email"],
                "phone": customer["phone"],
                "billing_address": customer["billing_address"],
                "city": customer["city"],
                "postal_code": customer["postal_code"],
                "country": customer["country"],
                "tax_id": customer["tax_id"],
                "vat_number": customer["vat_number"],
                "created_at": customer["created_at"].isoformat() if customer["created_at"] else None,
                "updated_at": customer["updated_at"].isoformat() if customer["updated_at"] else None,
                "total_purchases": customer["total_purchases"],
                "total_spent": float(customer["total_spent"]) if customer["total_spent"] else 0.0
            })
        
        # Add registered users
        for reg_user in registered_users:
            all_users.append({
                "customer_id": None,
                "user_id": reg_user["user_id"],
                "user_type": "registered",
                "company_name": None,
                "contact_person": None,
                "email": None,
                "phone": None,
                "billing_address": None,
                "city": None,
                "postal_code": None,
                "country": None,
                "tax_id": None,
                "vat_number": None,
                "created_at": reg_user["created_at"].isoformat() if reg_user["created_at"] else None,
                "updated_at": reg_user["updated_at"].isoformat() if reg_user["updated_at"] else None,
                "total_purchases": 0,
                "total_spent": 0.0
            })
        
        # Sort by created_at desc
        all_users.sort(key=lambda x: x["created_at"] or "", reverse=True)
        
        return {
            "users": all_users,
            "total_count": len(all_users),
            "customers_count": len(customers),
            "registered_users_count": len(registered_users)
        }
    
    except Exception as e:
        print(f"Error fetching all users: {e}")
        raise HTTPException(status_code=500, detail="Failed to fetch all users")
    finally:
        await conn.close()
