
from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel
from typing import List, Optional
from datetime import datetime, timezone
import asyncpg
import databutton as db
from app.auth import AuthorizedUser
import json
import uuid

router = APIRouter()

# Database connection helper
async def get_db_connection():
    database_url = db.secrets.get("DATABASE_URL_DEV")
    return await asyncpg.connect(database_url)

# Request Models
class SupportRequestCreate(BaseModel):
    subject: str
    description: str
    category: str  # 'technical', 'billing', 'feature_request', 'bug_report', 'general'
    priority: str = 'medium'  # 'low', 'medium', 'high', 'urgent'
    module_context: Optional[str] = None  # Which module user was on when requesting support
    user_context: Optional[dict] = None  # Additional context like browser, page, etc.

class SupportRequestResponse(BaseModel):
    ticket_id: str
    status: str
    message: str
    created_at: datetime

class AdminSupportResponse(BaseModel):
    response_message: str
    status: str  # 'open', 'in_progress', 'resolved', 'closed'
    internal_notes: Optional[str] = None

class SupportTicket(BaseModel):
    ticket_id: str
    user_id: str
    user_name: str
    user_email: str
    subject: str
    description: str
    category: str
    priority: str
    status: str
    module_context: Optional[str]
    user_context: Optional[dict]
    created_at: datetime
    updated_at: datetime
    assigned_to: Optional[str] = None
    resolution_notes: Optional[str] = None
    admin_responses: List[dict] = []

class SupportTicketListResponse(BaseModel):
    tickets: List[SupportTicket]
    total_count: int
    open_count: int
    in_progress_count: int
    resolved_count: int

# User Support Request Endpoints
@router.post("/request", response_model=SupportRequestResponse)
async def create_support_request(request: SupportRequestCreate, user: AuthorizedUser):
    """
    Create a new support request from a user. 
    This creates a task in the admin dashboard for review.
    """
    try:
        # Generate unique ticket ID
        ticket_id = f"SUP_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{str(uuid.uuid4())[:8]}"
        
        conn = await get_db_connection()
        try:
            # Insert support ticket
            await conn.execute(
                """
                INSERT INTO support_tickets (
                    ticket_id, user_id, user_name, user_email, subject, description, 
                    category, priority, status, module_context, user_context, 
                    created_at, updated_at
                ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13)
                """,
                ticket_id, user.sub, user.name or 'Unknown User', user.email or 'unknown@example.com',
                request.subject, request.description, request.category, request.priority,
                'open', request.module_context, json.dumps(request.user_context) if request.user_context else None,
                datetime.now(timezone.utc), datetime.now(timezone.utc)
            )
            
            print(f"Support ticket created: {ticket_id} for user {user.email}")
            
        finally:
            await conn.close()
        
        # Send notification email to admin (in production, this would be to support team)
        try:
            db.notify.email(
                to="support@respectus.com",  # This would be actual support email
                subject=f"New Support Request: {request.subject} [{ticket_id}]",
                content_html=f"""
                <h2>New Support Request Received</h2>
                <p><strong>Ticket ID:</strong> {ticket_id}</p>
                <p><strong>User:</strong> {user.email}</p>
                <p><strong>Category:</strong> {request.category}</p>
                <p><strong>Priority:</strong> {request.priority}</p>
                <p><strong>Module Context:</strong> {request.module_context or 'N/A'}</p>
                
                <h3>Subject:</h3>
                <p>{request.subject}</p>
                
                <h3>Description:</h3>
                <p>{request.description}</p>
                
                <hr>
                <p><em>Please log into the RespectUs Admin Dashboard to respond to this ticket.</em></p>
                """,
                content_text=f"""
                New Support Request Received
                
                Ticket ID: {ticket_id}
                User: {user.email}
                Category: {request.category}
                Priority: {request.priority}
                Module Context: {request.module_context or 'N/A'}
                
                Subject: {request.subject}
                
                Description: {request.description}
                
                Please log into the RespectUs Admin Dashboard to respond to this ticket.
                """
            )
        except Exception as e:
            print(f"Failed to send admin notification email: {e}")
            # Don't fail the request if email fails
        
        return SupportRequestResponse(
            ticket_id=ticket_id,
            status="open",
            message="Your support request has been submitted successfully. Our team will review it and respond within 24 hours.",
            created_at=datetime.now(timezone.utc)
        )
        
    except Exception as e:
        print(f"Error creating support request: {e}")
        raise HTTPException(status_code=500, detail="Failed to create support request")

@router.get("/my-tickets", response_model=List[SupportTicket])
async def get_user_support_tickets(user: AuthorizedUser, status: Optional[str] = None):
    """
    Get all support tickets for the current user.
    Optionally filter by status: 'open', 'in_progress', 'resolved', 'closed'
    """
    try:
        conn = await get_db_connection()
        try:
            if status:
                tickets_query = """
                    SELECT * FROM support_tickets 
                    WHERE user_id = $1 AND status = $2
                    ORDER BY created_at DESC
                """
                tickets = await conn.fetch(tickets_query, user.sub, status)
            else:
                tickets_query = """
                    SELECT * FROM support_tickets 
                    WHERE user_id = $1
                    ORDER BY created_at DESC
                """
                tickets = await conn.fetch(tickets_query, user.sub)
                
        finally:
            await conn.close()
        
        # Transform tickets
        ticket_list = []
        for ticket in tickets:
            user_context = json.loads(ticket['user_context']) if ticket['user_context'] else None
            admin_responses = json.loads(ticket['admin_responses']) if ticket['admin_responses'] else []
            
            ticket_list.append(SupportTicket(
                ticket_id=ticket['ticket_id'],
                user_id=ticket['user_id'],
                user_name=ticket['user_name'],
                user_email=ticket['user_email'],
                subject=ticket['subject'],
                description=ticket['description'],
                category=ticket['category'],
                priority=ticket['priority'],
                status=ticket['status'],
                module_context=ticket['module_context'],
                user_context=user_context,
                created_at=ticket['created_at'],
                updated_at=ticket['updated_at'],
                assigned_to=ticket['assigned_to'],
                resolution_notes=ticket['resolution_notes'],
                admin_responses=admin_responses
            ))
        
        return ticket_list
        
    except Exception as e:
        print(f"Error fetching user support tickets: {e}")
        raise HTTPException(status_code=500, detail="Failed to fetch support tickets")

# Admin Support Management Endpoints
@router.get("/admin/tickets", response_model=SupportTicketListResponse)
async def get_admin_support_tickets(user: AuthorizedUser, status: Optional[str] = None, priority: Optional[str] = None):
    """
    Get all support tickets for admin review.
    Optionally filter by status and/or priority.
    """
    try:
        conn = await get_db_connection()
        try:
            # Build query with optional filters
            conditions = []
            params = []
            param_count = 0
            
            if status:
                param_count += 1
                conditions.append(f"status = ${param_count}")
                params.append(status)
                
            if priority:
                param_count += 1
                conditions.append(f"priority = ${param_count}")
                params.append(priority)
            
            where_clause = "WHERE " + " AND ".join(conditions) if conditions else ""
            
            tickets_query = f"""
                SELECT * FROM support_tickets 
                {where_clause}
                ORDER BY 
                    CASE priority 
                        WHEN 'urgent' THEN 1
                        WHEN 'high' THEN 2 
                        WHEN 'medium' THEN 3
                        WHEN 'low' THEN 4
                    END,
                    created_at DESC
            """
            
            tickets = await conn.fetch(tickets_query, *params)
            
            # Get counts
            counts = await conn.fetchrow(
                """
                SELECT 
                    COUNT(*) as total_count,
                    COUNT(*) FILTER (WHERE status = 'open') as open_count,
                    COUNT(*) FILTER (WHERE status = 'in_progress') as in_progress_count,
                    COUNT(*) FILTER (WHERE status = 'resolved') as resolved_count
                FROM support_tickets
                """
            )
            
        finally:
            await conn.close()
        
        # Transform tickets
        ticket_list = []
        for ticket in tickets:
            user_context = json.loads(ticket['user_context']) if ticket['user_context'] else None
            admin_responses = json.loads(ticket['admin_responses']) if ticket['admin_responses'] else []
            
            ticket_list.append(SupportTicket(
                ticket_id=ticket['ticket_id'],
                user_id=ticket['user_id'],
                user_name=ticket['user_name'],
                user_email=ticket['user_email'],
                subject=ticket['subject'],
                description=ticket['description'],
                category=ticket['category'],
                priority=ticket['priority'],
                status=ticket['status'],
                module_context=ticket['module_context'],
                user_context=user_context,
                created_at=ticket['created_at'],
                updated_at=ticket['updated_at'],
                assigned_to=ticket['assigned_to'],
                resolution_notes=ticket['resolution_notes'],
                admin_responses=admin_responses
            ))
        
        return SupportTicketListResponse(
            tickets=ticket_list,
            total_count=counts['total_count'] or 0,
            open_count=counts['open_count'] or 0,
            in_progress_count=counts['in_progress_count'] or 0,
            resolved_count=counts['resolved_count'] or 0
        )
        
    except Exception as e:
        print(f"Error fetching admin support tickets: {e}")
        raise HTTPException(status_code=500, detail="Failed to fetch support tickets")

@router.post("/admin/tickets/{ticket_id}/respond")
async def admin_respond_to_ticket(ticket_id: str, response: AdminSupportResponse, user: AuthorizedUser):
    """
    Admin responds to a support ticket and optionally updates status.
    Sends email notification to the user.
    """
    try:
        conn = await get_db_connection()
        try:
            # Get the ticket
            ticket = await conn.fetchrow(
                "SELECT * FROM support_tickets WHERE ticket_id = $1",
                ticket_id
            )
            
            if not ticket:
                raise HTTPException(status_code=404, detail="Support ticket not found")
            
            # Parse existing admin responses
            existing_responses = json.loads(ticket['admin_responses']) if ticket['admin_responses'] else []
            
            # Add new response
            new_response = {
                "response_id": str(uuid.uuid4()),
                "admin_user_id": user.sub,
                "admin_name": user.name or "Admin",
                "message": response.response_message,
                "internal_notes": response.internal_notes,
                "timestamp": datetime.now(timezone.utc).isoformat()
            }
            
            existing_responses.append(new_response)
            
            # Update ticket with response and new status
            await conn.execute(
                """
                UPDATE support_tickets 
                SET status = $1, admin_responses = $2, updated_at = $3, assigned_to = $4,
                    resolution_notes = CASE WHEN $1 = 'resolved' THEN $5 ELSE resolution_notes END
                WHERE ticket_id = $6
                """,
                response.status, json.dumps(existing_responses), datetime.now(timezone.utc),
                user.sub, response.response_message if response.status == 'resolved' else None, ticket_id
            )
            
        finally:
            await conn.close()
        
        # Send email notification to user
        try:
            status_message = {
                'open': 'Your ticket is open and awaiting review',
                'in_progress': 'Your ticket is being worked on',
                'resolved': 'Your ticket has been resolved',
                'closed': 'Your ticket has been closed'
            }.get(response.status, 'Your ticket status has been updated')
            
            db.notify.email(
                to=ticket['user_email'],
                subject=f"Support Ticket Update: {ticket['subject']} [{ticket_id}]",
                content_html=f"""
                <h2>Support Ticket Update</h2>
                <p><strong>Ticket ID:</strong> {ticket_id}</p>
                <p><strong>Status:</strong> {response.status.upper()}</p>
                <p><strong>Subject:</strong> {ticket['subject']}</p>
                
                <h3>Response from RespectUs Support:</h3>
                <p>{response.response_message}</p>
                
                <hr>
                <p><em>{status_message}</em></p>
                
                <p>You can view all your support tickets in your RespectUs dashboard.</p>
                """,
                content_text=f"""
                Support Ticket Update
                
                Ticket ID: {ticket_id}
                Status: {response.status.upper()}
                Subject: {ticket['subject']}
                
                Response from RespectUs Support:
                {response.response_message}
                
                {status_message}
                
                You can view all your support tickets in your RespectUs dashboard.
                """
            )
        except Exception as e:
            print(f"Failed to send user notification email: {e}")
            # Don't fail the request if email fails
        
        return {
            "success": True,
            "message": "Response sent successfully",
            "ticket_id": ticket_id,
            "new_status": response.status
        }
        
    except Exception as e:
        print(f"Error responding to support ticket: {e}")
        raise HTTPException(status_code=500, detail="Failed to respond to support ticket")

@router.get("/admin/tickets/{ticket_id}", response_model=SupportTicket)
async def get_support_ticket_detail(ticket_id: str, user: AuthorizedUser):
    """
    Get detailed information about a specific support ticket for admin review.
    """
    try:
        conn = await get_db_connection()
        try:
            ticket = await conn.fetchrow(
                "SELECT * FROM support_tickets WHERE ticket_id = $1",
                ticket_id
            )
            
            if not ticket:
                raise HTTPException(status_code=404, detail="Support ticket not found")
                
        finally:
            await conn.close()
        
        user_context = json.loads(ticket['user_context']) if ticket['user_context'] else None
        admin_responses = json.loads(ticket['admin_responses']) if ticket['admin_responses'] else []
        
        return SupportTicket(
            ticket_id=ticket['ticket_id'],
            user_id=ticket['user_id'],
            user_name=ticket['user_name'],
            user_email=ticket['user_email'],
            subject=ticket['subject'],
            description=ticket['description'],
            category=ticket['category'],
            priority=ticket['priority'],
            status=ticket['status'],
            module_context=ticket['module_context'],
            user_context=user_context,
            created_at=ticket['created_at'],
            updated_at=ticket['updated_at'],
            assigned_to=ticket['assigned_to'],
            resolution_notes=ticket['resolution_notes'],
            admin_responses=admin_responses
        )
        
    except Exception as e:
        print(f"Error fetching support ticket detail: {e}")
        raise HTTPException(status_code=500, detail="Failed to fetch support ticket detail")
