
from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel
from typing import List, Optional, Dict, Any
import asyncpg
import databutton as db
from app.auth import AuthorizedUser
from app.env import Mode, mode
import json
from datetime import datetime

router = APIRouter(prefix="/doc-metadata")

class MetadataOption(BaseModel):
    id: Optional[int] = None
    category: str
    value: str
    display_name: str
    display_order: int = 0
    is_active: bool = True

class CreateMetadataOptionRequest(BaseModel):
    category: str  # jurisdiction, type, subject
    value: str
    display_name: str
    display_order: Optional[int] = None

class UpdateMetadataOptionRequest(BaseModel):
    value: Optional[str] = None
    display_name: Optional[str] = None
    display_order: Optional[int] = None
    is_active: Optional[bool] = None

class BulkReorderRequest(BaseModel):
    category: str
    option_orders: List[dict]  # [{"id": 1, "display_order": 0}, ...]

class MetadataOptionsResponse(BaseModel):
    options: List[MetadataOption]
    total_count: int

class BulkImportRequest(BaseModel):
    category: str
    options: List[dict]  # [{"value": "...", "display_name": "..."}]
    replace_existing: bool = False

# Database connection
async def get_db_connection():
    """Get database connection based on environment"""
    if mode == Mode.PROD:
        database_url = db.secrets.get("DATABASE_URL_PROD")
    else:
        database_url = db.secrets.get("DATABASE_URL_DEV")
    return await asyncpg.connect(database_url)

@router.get("/metadata-options/{category}")
async def get_document_metadata_options(category: str, user: AuthorizedUser) -> MetadataOptionsResponse:
    """Get all metadata options for a specific category (jurisdiction/type/subject)"""
    if category not in ['jurisdiction', 'type', 'subject']:
        raise HTTPException(status_code=400, detail="Invalid category. Must be jurisdiction, type, or subject")
    
    try:
        conn = await get_db_connection()
        try:
            query = """
                SELECT id, category, value, display_name, display_order, is_active
                FROM document_metadata_options 
                WHERE category = $1 AND is_active = true
                ORDER BY display_order, id
            """
            rows = await conn.fetch(query, category)
            
            options = [
                MetadataOption(
                    id=row['id'],
                    category=row['category'],
                    value=row['value'],
                    display_name=row['display_name'],
                    display_order=row['display_order'],
                    is_active=row['is_active']
                )
                for row in rows
            ]
            
            return MetadataOptionsResponse(
                options=options,
                total_count=len(options)
            )
            
        finally:
            await conn.close()
            
    except Exception as e:
        print(f"Error fetching metadata options: {e}")
        raise HTTPException(status_code=500, detail="Failed to fetch metadata options") from e

@router.get("/metadata-options")
async def get_all_document_metadata_options(user: AuthorizedUser) -> dict:
    """Get all metadata options grouped by category"""
    try:
        conn = await get_db_connection()
        try:
            query = """
                SELECT id, category, value, display_name, display_order, is_active
                FROM document_metadata_options 
                WHERE is_active = true
                ORDER BY category, display_order, id
            """
            rows = await conn.fetch(query)
            
            # Group by category
            grouped_options = {
                'jurisdiction': [],
                'type': [],
                'subject': []
            }
            
            for row in rows:
                option = MetadataOption(
                    id=row['id'],
                    category=row['category'],
                    value=row['value'],
                    display_name=row['display_name'],
                    display_order=row['display_order'],
                    is_active=row['is_active']
                )
                if row['category'] in grouped_options:
                    grouped_options[row['category']].append(option)
            
            return grouped_options
            
        finally:
            await conn.close()
            
    except Exception as e:
        print(f"Error fetching all metadata options: {e}")
        raise HTTPException(status_code=500, detail="Failed to fetch metadata options") from e

@router.post("/metadata-options")
async def create_document_metadata_option(request: CreateMetadataOptionRequest, user: AuthorizedUser) -> MetadataOption:
    """Create a new metadata option"""
    if request.category not in ['jurisdiction', 'type', 'subject']:
        raise HTTPException(status_code=400, detail="Invalid category. Must be jurisdiction, type, or subject")
    
    try:
        conn = await get_db_connection()
        try:
            # Check if value already exists in this category
            check_query = "SELECT id FROM document_metadata_options WHERE category = $1 AND value = $2"
            existing = await conn.fetchrow(check_query, request.category, request.value)
            
            if existing:
                raise HTTPException(status_code=400, detail="Option value already exists in this category")
            
            # Get next display order if not provided
            if request.display_order is None:
                order_query = "SELECT COALESCE(MAX(display_order), 0) + 1 FROM document_metadata_options WHERE category = $1"
                next_order = await conn.fetchval(order_query, request.category)
                request.display_order = next_order
            
            query = """
                INSERT INTO document_metadata_options 
                (category, value, display_name, display_order)
                VALUES ($1, $2, $3, $4)
                RETURNING id, category, value, display_name, display_order, is_active
            """
            
            row = await conn.fetchrow(
                query,
                request.category,
                request.value,
                request.display_name,
                request.display_order
            )
            
            return MetadataOption(
                id=row['id'],
                category=row['category'],
                value=row['value'],
                display_name=row['display_name'],
                display_order=row['display_order'],
                is_active=row['is_active']
            )
            
        finally:
            await conn.close()
            
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error creating metadata option: {e}")
        raise HTTPException(status_code=500, detail="Failed to create metadata option") from e

@router.put("/metadata-options/{option_id}")
async def update_document_metadata_option(option_id: int, request: UpdateMetadataOptionRequest, user: AuthorizedUser) -> MetadataOption:
    """Update an existing metadata option"""
    try:
        conn = await get_db_connection()
        try:
            # Check if option exists
            check_query = "SELECT id, category FROM document_metadata_options WHERE id = $1"
            existing = await conn.fetchrow(check_query, option_id)
            
            if not existing:
                raise HTTPException(status_code=404, detail="Metadata option not found")
            
            # Build update query dynamically based on provided fields
            update_fields = []
            values = []
            param_count = 1
            
            if request.value is not None:
                # Check for duplicate value in same category
                dup_query = "SELECT id FROM document_metadata_options WHERE category = $1 AND value = $2 AND id != $3"
                duplicate = await conn.fetchrow(dup_query, existing['category'], request.value, option_id)
                if duplicate:
                    raise HTTPException(status_code=400, detail="Option value already exists in this category")
                
                update_fields.append(f"value = ${param_count}")
                values.append(request.value)
                param_count += 1
            
            if request.display_name is not None:
                update_fields.append(f"display_name = ${param_count}")
                values.append(request.display_name)
                param_count += 1
            
            if request.display_order is not None:
                update_fields.append(f"display_order = ${param_count}")
                values.append(request.display_order)
                param_count += 1
            
            if request.is_active is not None:
                update_fields.append(f"is_active = ${param_count}")
                values.append(request.is_active)
                param_count += 1
            
            if not update_fields:
                raise HTTPException(status_code=400, detail="No fields to update")
            
            # Add updated_at field
            update_fields.append(f"updated_at = CURRENT_TIMESTAMP")
            values.append(option_id)
            
            query = f"""
                UPDATE document_metadata_options 
                SET {', '.join(update_fields)}
                WHERE id = ${param_count}
                RETURNING id, category, value, display_name, display_order, is_active
            """
            
            row = await conn.fetchrow(query, *values)
            
            return MetadataOption(
                id=row['id'],
                category=row['category'],
                value=row['value'],
                display_name=row['display_name'],
                display_order=row['display_order'],
                is_active=row['is_active']
            )
            
        finally:
            await conn.close()
            
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error updating metadata option: {e}")
        raise HTTPException(status_code=500, detail="Failed to update metadata option") from e

@router.delete("/metadata-options/{option_id}")
async def delete_document_metadata_option(option_id: int, user: AuthorizedUser) -> dict:
    """Delete a metadata option (soft delete by setting is_active to false)"""
    try:
        conn = await get_db_connection()
        try:
            # Check if option exists
            check_query = "SELECT id FROM document_metadata_options WHERE id = $1"
            existing = await conn.fetchrow(check_query, option_id)
            
            if not existing:
                raise HTTPException(status_code=404, detail="Metadata option not found")
            
            # Soft delete by setting is_active to false
            query = "UPDATE document_metadata_options SET is_active = false, updated_at = CURRENT_TIMESTAMP WHERE id = $1"
            await conn.execute(query, option_id)
            
            return {"success": True, "message": "Metadata option deactivated successfully"}
            
        finally:
            await conn.close()
            
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error deleting metadata option: {e}")
        raise HTTPException(status_code=500, detail="Failed to delete metadata option") from e

@router.put("/metadata-options/{category}/reorder")
async def reorder_document_metadata_options(category: str, request: BulkReorderRequest, user: AuthorizedUser) -> dict:
    """Bulk update display orders for drag-and-drop reordering"""
    if category not in ['jurisdiction', 'type', 'subject']:
        raise HTTPException(status_code=400, detail="Invalid category. Must be jurisdiction, type, or subject")
    
    try:
        conn = await get_db_connection()
        try:
            # Update all option orders in a transaction
            async with conn.transaction():
                for option_order in request.option_orders:
                    option_id = option_order.get('id')
                    display_order = option_order.get('display_order')
                    
                    if option_id and display_order is not None:
                        await conn.execute(
                            "UPDATE document_metadata_options SET display_order = $1, updated_at = CURRENT_TIMESTAMP WHERE id = $2 AND category = $3",
                            display_order, option_id, category
                        )
            
            return {"success": True, "message": "Option order updated successfully"}
            
        finally:
            await conn.close()
            
    except Exception as e:
        print(f"Error reordering metadata options: {e}")
        raise HTTPException(status_code=500, detail="Failed to reorder metadata options") from e

@router.post("/metadata-options/{category}/bulk-import")
async def bulk_import_metadata_options(category: str, request: BulkImportRequest, user: AuthorizedUser) -> dict:
    """Bulk import metadata options from structured data"""
    if category not in ['jurisdiction', 'type', 'subject']:
        raise HTTPException(status_code=400, detail="Invalid category. Must be jurisdiction, type, or subject")
    
    print(f"🚀 Bulk import request for {category}:")
    print(f"   - Request category: {request.category}")
    print(f"   - Options count: {len(request.options)}")
    print(f"   - Replace existing: {request.replace_existing}")
    print(f"   - First few options: {request.options[:3] if request.options else 'None'}")
    
    try:
        conn = await get_db_connection()
        try:
            async with conn.transaction():
                # If replace_existing is True, deactivate all existing options in this category
                if request.replace_existing:
                    await conn.execute(
                        "UPDATE document_metadata_options SET is_active = false WHERE category = $1", 
                        category
                    )
                
                # Insert new options
                imported_count = 0
                for i, option_data in enumerate(request.options):
                    value = option_data.get('value')
                    display_name = option_data.get('display_name', value)
                    display_order = option_data.get('display_order', i)
                    
                    print(f"   Processing option {i}: value={value}, display_name={display_name}")
                    
                    if not value:
                        print(f"   Skipping option {i}: no value")
                        continue
                    
                    # Check if option already exists
                    existing_query = "SELECT id FROM document_metadata_options WHERE category = $1 AND value = $2"
                    existing = await conn.fetchrow(existing_query, category, value)
                    
                    if existing:
                        # Update existing option
                        print(f"   Updating existing option {value}")
                        await conn.execute(
                            "UPDATE document_metadata_options SET display_name = $1, display_order = $2, is_active = true, updated_at = CURRENT_TIMESTAMP WHERE id = $3",
                            display_name, display_order, existing['id']
                        )
                    else:
                        # Insert new option
                        print(f"   Inserting new option {value}")
                        await conn.execute(
                            "INSERT INTO document_metadata_options (category, value, display_name, display_order) VALUES ($1, $2, $3, $4)",
                            category, value, display_name, display_order
                        )
                    
                    imported_count += 1
            
            print(f"✅ Bulk import completed: {imported_count} options imported")
            return {
                "success": True, 
                "message": f"Successfully imported {imported_count} {category} options",
                "options_imported": imported_count
            }
            
        finally:
            await conn.close()
            
    except Exception as e:
        print(f"Error bulk importing metadata options: {e}")
        raise HTTPException(status_code=500, detail="Failed to bulk import metadata options") from e

@router.get("/metadata-options/{category}/export")
async def export_metadata_options(category: str, user: AuthorizedUser) -> dict:
    """Export metadata options in a structured format for backup/transfer"""
    if category not in ['jurisdiction', 'type', 'subject']:
        raise HTTPException(status_code=400, detail="Invalid category. Must be jurisdiction, type, or subject")
    
    try:
        conn = await get_db_connection()
        try:
            query = """
                SELECT value, display_name, display_order, is_active
                FROM document_metadata_options 
                WHERE category = $1
                ORDER BY display_order, id
            """
            rows = await conn.fetch(query, category)
            
            options = [
                {
                    "value": row['value'],
                    "display_name": row['display_name'],
                    "display_order": row['display_order'],
                    "is_active": row['is_active']
                }
                for row in rows
            ]
            
            return {
                "category": category,
                "options_count": len(options),
                "options": options,
                "exported_at": "now"
            }
            
        finally:
            await conn.close()
            
    except Exception as e:
        print(f"Error exporting metadata options: {e}")
        raise HTTPException(status_code=500, detail="Failed to export metadata options") from e
