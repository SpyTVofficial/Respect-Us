
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import List, Optional
from uuid import UUID
import databutton as db
import asyncpg
from app.env import Mode, mode
from app.auth import AuthorizedUser

router = APIRouter(prefix="/classification/notes")

# Database connection
async def get_db_connection():
    if mode == Mode.PROD:
        database_url = db.secrets.get("DATABASE_URL_PROD")
    else:
        database_url = db.secrets.get("DATABASE_URL_DEV")
    return await asyncpg.connect(database_url)

# Pydantic models
class ClassificationNote(BaseModel):
    id: Optional[int] = None
    note_key: str
    title: str
    content: str
    tree_id: Optional[UUID] = None
    module_type: str = "product_classification"  # Add module_type field
    created_by: Optional[str] = None
    created_at: Optional[str] = None
    updated_at: Optional[str] = None

class CreateNoteRequest(BaseModel):
    note_key: str
    title: str
    content: str
    tree_id: Optional[UUID] = None
    module_type: str = "product_classification"  # Add module_type field

class UpdateNoteRequest(BaseModel):
    note_key: str
    title: str
    content: str

class NoteResponse(BaseModel):
    success: bool
    message: str
    note: Optional[ClassificationNote] = None

@router.get("/list", response_model=List[ClassificationNote])
async def list_classification_notes(user: AuthorizedUser, tree_id: Optional[UUID] = None, module_type: Optional[str] = None):
    """
    List all classification notes, optionally filtered by tree_id and/or module_type
    """
    conn = await get_db_connection()
    try:
        base_query = """
            SELECT id, note_key, title, content, tree_id, module_type, created_by, created_at, updated_at
            FROM classification_notes
        """
        
        conditions = []
        params = []
        
        if tree_id:
            conditions.append("(tree_id = $" + str(len(params) + 1) + " OR tree_id IS NULL)")
            params.append(tree_id)
            
        if module_type:
            conditions.append("module_type = $" + str(len(params) + 1))
            params.append(module_type)
        
        if conditions:
            query = base_query + " WHERE " + " AND ".join(conditions)
        else:
            query = base_query
            
        query += " ORDER BY created_at DESC"
        
        rows = await conn.fetch(query, *params)
        
        notes = []
        for row in rows:
            notes.append(ClassificationNote(
                id=row['id'],
                note_key=row['note_key'],
                title=row['title'],
                content=row['content'],
                tree_id=row['tree_id'],
                module_type=row['module_type'],
                created_by=row['created_by'],
                created_at=row['created_at'].isoformat() if row['created_at'] else None,
                updated_at=row['updated_at'].isoformat() if row['updated_at'] else None
            ))
        
        return notes
    except Exception as e:
        print(f"Error listing notes: {e}")
        raise HTTPException(status_code=500, detail="Failed to list notes")
    finally:
        await conn.close()

@router.post("/create", response_model=NoteResponse)
async def create_classification_note(request: CreateNoteRequest, user: AuthorizedUser):
    """
    Create a new classification note
    """
    conn = await get_db_connection()
    try:
        # Check if note_key already exists
        existing_query = "SELECT id FROM classification_notes WHERE note_key = $1"
        existing = await conn.fetchval(existing_query, request.note_key)
        
        if existing:
            raise HTTPException(status_code=400, detail="Note key already exists")
        
        # Create the note
        query = """
            INSERT INTO classification_notes (note_key, title, content, tree_id, module_type, created_by)
            VALUES ($1, $2, $3, $4, $5, $6)
            RETURNING id, note_key, title, content, tree_id, module_type, created_by, created_at, updated_at
        """
        
        row = await conn.fetchrow(
            query,
            request.note_key,
            request.title,
            request.content,
            request.tree_id,
            request.module_type,
            user.sub
        )
        
        note = ClassificationNote(
            id=row['id'],
            note_key=row['note_key'],
            title=row['title'],
            content=row['content'],
            tree_id=row['tree_id'],
            module_type=row['module_type'],
            created_by=row['created_by'],
            created_at=row['created_at'].isoformat() if row['created_at'] else None,
            updated_at=row['updated_at'].isoformat() if row['updated_at'] else None
        )
        
        return NoteResponse(
            success=True,
            message="Note created successfully",
            note=note
        )
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error creating note: {e}")
        raise HTTPException(status_code=500, detail="Failed to create note")
    finally:
        await conn.close()

@router.get("/get/{note_key}", response_model=ClassificationNote)
async def get_classification_note_by_key(note_key: str, user: AuthorizedUser):
    """
    Get a classification note by its key
    """
    conn = await get_db_connection()
    try:
        query = """
            SELECT id, note_key, title, content, tree_id, module_type, created_by, created_at, updated_at
            FROM classification_notes
            WHERE note_key = $1
        """
        
        row = await conn.fetchrow(query, note_key)
        
        if not row:
            raise HTTPException(status_code=404, detail="Note not found")
        
        return ClassificationNote(
            id=row['id'],
            note_key=row['note_key'],
            title=row['title'],
            content=row['content'],
            tree_id=row['tree_id'],
            module_type=row['module_type'],
            created_by=row['created_by'],
            created_at=row['created_at'].isoformat() if row['created_at'] else None,
            updated_at=row['updated_at'].isoformat() if row['updated_at'] else None
        )
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error getting note: {e}")
        raise HTTPException(status_code=500, detail="Failed to get note")
    finally:
        await conn.close()

@router.put("/update/{note_id}", response_model=NoteResponse)
async def update_classification_note(note_id: int, request: UpdateNoteRequest, user: AuthorizedUser):
    """
    Update a classification note
    """
    conn = await get_db_connection()
    try:
        # Check if note exists
        existing_query = "SELECT id FROM classification_notes WHERE id = $1"
        existing = await conn.fetchval(existing_query, note_id)
        
        if not existing:
            raise HTTPException(status_code=404, detail="Note not found")
        
        # Update the note
        query = """
            UPDATE classification_notes
            SET note_key = $1, title = $2, content = $3, updated_at = NOW()
            WHERE id = $4
            RETURNING id, note_key, title, content, tree_id, created_by, created_at, updated_at
        """
        
        row = await conn.fetchrow(query, request.note_key, request.title, request.content, note_id)
        
        note = ClassificationNote(
            id=row['id'],
            note_key=row['note_key'],
            title=row['title'],
            content=row['content'],
            tree_id=row['tree_id'],
            created_by=row['created_by'],
            created_at=row['created_at'].isoformat() if row['created_at'] else None,
            updated_at=row['updated_at'].isoformat() if row['updated_at'] else None
        )
        
        return NoteResponse(
            success=True,
            message="Note updated successfully",
            note=note
        )
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error updating note: {e}")
        raise HTTPException(status_code=500, detail="Failed to update note")
    finally:
        await conn.close()

@router.delete("/delete/{note_id}", response_model=NoteResponse)
async def delete_classification_note(note_id: int, user: AuthorizedUser):
    """
    Delete a classification note
    """
    conn = await get_db_connection()
    try:
        # Check if note exists
        existing_query = "SELECT id FROM classification_notes WHERE id = $1"
        existing = await conn.fetchval(existing_query, note_id)
        
        if not existing:
            raise HTTPException(status_code=404, detail="Note not found")
        
        # Delete the note
        query = "DELETE FROM classification_notes WHERE id = $1"
        await conn.execute(query, note_id)
        
        return NoteResponse(
            success=True,
            message="Note deleted successfully"
        )
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error deleting note: {e}")
        raise HTTPException(status_code=500, detail="Failed to delete note")
    finally:
        await conn.close()

@router.get("/screening-explanation", response_model=ClassificationNote)
async def get_screening_explanation(user: AuthorizedUser):
    """
    Get the screening explanation content for the Sanctions & Embargoes screening tab
    """
    conn = await get_db_connection()
    try:
        query = """
            SELECT id, note_key, title, content, tree_id, module_type, created_by, created_at, updated_at
            FROM classification_notes
            WHERE note_key = 'screening_explanation' AND module_type = 'sanctions_embargoes'
            ORDER BY updated_at DESC
            LIMIT 1
        """
        
        row = await conn.fetchrow(query)
        
        if not row:
            # Return default content if no CMS content exists
            return ClassificationNote(
                id=None,
                note_key="screening_explanation",
                title="How are entities and individuals affected by sanctions and restrictive measures",
                content="""Sanctions and restrictive measures are tools used by governments and international organizations to address threats to international peace and security, violations of international law, or other unacceptable behavior.

**Types of Sanctions:**
- **Asset Freezes**: Preventing access to funds and economic resources
- **Travel Bans**: Restrictions on movement and entry to territories
- **Arms Embargoes**: Prohibiting the sale or transfer of weapons
- **Trade Restrictions**: Limiting or prohibiting specific commercial activities

**Who Can Be Affected:**
- Individuals (politicians, military leaders, business people)
- Entities (companies, organizations, government agencies)
- Sectors (banking, energy, technology)
- Entire countries or regions

**Compliance Requirements:**
Businesses must screen their customers, suppliers, and transaction parties against sanctions lists to ensure compliance with applicable laws and regulations. Failure to comply can result in severe penalties, including fines and legal action.""",
                module_type="sanctions_embargoes",
                created_by=None,
                created_at=None,
                updated_at=None
            )
        
        return ClassificationNote(
            id=row['id'],
            note_key=row['note_key'],
            title=row['title'],
            content=row['content'],
            tree_id=row['tree_id'],
            module_type=row['module_type'],
            created_by=row['created_by'],
            created_at=row['created_at'].isoformat() if row['created_at'] else None,
            updated_at=row['updated_at'].isoformat() if row['updated_at'] else None
        )
        
    except Exception as e:
        print(f"❌ Error fetching screening explanation: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to fetch screening explanation: {str(e)}")
    finally:
        await conn.close()

@router.post("/screening-explanation", response_model=NoteResponse)
async def create_or_update_screening_explanation(request: CreateNoteRequest, user: AuthorizedUser):
    """
    Create or update the screening explanation content for the Sanctions & Embargoes screening tab
    """
    conn = await get_db_connection()
    try:
        # Check if content already exists
        existing_query = """
            SELECT id FROM classification_notes
            WHERE note_key = 'screening_explanation' AND module_type = 'sanctions_embargoes'
        """
        
        existing_row = await conn.fetchrow(existing_query)
        
        if existing_row:
            # Update existing content
            update_query = """
                UPDATE classification_notes
                SET title = $1, content = $2, updated_at = NOW()
                WHERE note_key = 'screening_explanation' AND module_type = 'sanctions_embargoes'
                RETURNING id, note_key, title, content, tree_id, module_type, created_by, created_at, updated_at
            """
            
            row = await conn.fetchrow(update_query, request.title, request.content)
        else:
            # Create new content
            insert_query = """
                INSERT INTO classification_notes (note_key, title, content, tree_id, module_type, created_by, created_at, updated_at)
                VALUES ('screening_explanation', $1, $2, NULL, 'sanctions_embargoes', $3, NOW(), NOW())
                RETURNING id, note_key, title, content, tree_id, module_type, created_by, created_at, updated_at
            """
            
            row = await conn.fetchrow(insert_query, request.title, request.content, user.sub)
        
        note = ClassificationNote(
            id=row['id'],
            note_key=row['note_key'],
            title=row['title'],
            content=row['content'],
            tree_id=row['tree_id'],
            module_type=row['module_type'],
            created_by=row['created_by'],
            created_at=row['created_at'].isoformat() if row['created_at'] else None,
            updated_at=row['updated_at'].isoformat() if row['updated_at'] else None
        )
        
        return NoteResponse(
            success=True,
            message="Screening explanation updated successfully",
            note=note
        )
        
    except Exception as e:
        print(f"❌ Error creating/updating screening explanation: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to update screening explanation: {str(e)}")
    finally:
        await conn.close()
