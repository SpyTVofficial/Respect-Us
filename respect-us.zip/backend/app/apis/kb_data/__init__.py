from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import List, Optional
import asyncpg
import databutton as db
from app.env import Mode, mode
from app.auth import AuthorizedUser

router = APIRouter(prefix="/kb-data")

class Country(BaseModel):
    id: int
    country_code: str
    country_name: str
    flag_emoji: str
    description: str
    regulation_summary: str

class Sanction(BaseModel):
    id: int
    sanction_type: str
    name: str
    description: str
    flag_emoji: str
    status: str

class DocumentSection(BaseModel):
    id: int
    document_id: int
    section_number: str
    section_title: str
    section_content: str
    parent_section_id: Optional[int]
    display_order: int

class CountriesResponse(BaseModel):
    countries: List[Country]
    total: int

class SanctionsResponse(BaseModel):
    sanctions: List[Sanction]
    total: int

class DocumentSectionsResponse(BaseModel):
    sections: List[DocumentSection]
    total: int

async def get_db_connection():
    """Get database connection based on environment"""
    if mode == Mode.PROD:
        database_url = db.secrets.get("DATABASE_URL_PROD")
    else:
        database_url = db.secrets.get("DATABASE_URL_DEV")
    
    return await asyncpg.connect(database_url)

@router.get("/countries")
async def list_countries() -> CountriesResponse:
    """Get all countries for Knowledge Base browsing"""
    try:
        conn = await get_db_connection()
        try:
            query = """
                SELECT id, country_code, country_name, flag_emoji, description, regulation_summary
                FROM kb_countries 
                ORDER BY country_name
            """
            rows = await conn.fetch(query)
            
            countries = [
                Country(
                    id=row['id'],
                    country_code=row['country_code'],
                    country_name=row['country_name'],
                    flag_emoji=row['flag_emoji'],
                    description=row['description'],
                    regulation_summary=row['regulation_summary']
                )
                for row in rows
            ]
            
            return CountriesResponse(countries=countries, total=len(countries))
            
        finally:
            await conn.close()
            
    except Exception as e:
        print(f"Error fetching countries: {e}")
        raise HTTPException(status_code=500, detail="Failed to fetch countries")

@router.get("/sanctions")
async def list_sanctions() -> SanctionsResponse:
    """Get all sanctions for Knowledge Base browsing"""
    try:
        conn = await get_db_connection()
        try:
            query = """
                SELECT id, sanction_type, name, description, flag_emoji, status
                FROM kb_sanctions 
                WHERE status = 'active'
                ORDER BY sanction_type, name
            """
            rows = await conn.fetch(query)
            
            sanctions = [
                Sanction(
                    id=row['id'],
                    sanction_type=row['sanction_type'],
                    name=row['name'],
                    description=row['description'],
                    flag_emoji=row['flag_emoji'],
                    status=row['status']
                )
                for row in rows
            ]
            
            return SanctionsResponse(sanctions=sanctions, total=len(sanctions))
            
        finally:
            await conn.close()
            
    except Exception as e:
        print(f"Error fetching sanctions: {e}")
        raise HTTPException(status_code=500, detail="Failed to fetch sanctions")

@router.get("/documents/{document_id}/sections")
async def get_document_sections(document_id: int, user: AuthorizedUser) -> DocumentSectionsResponse:
    """Get sections for a specific document with credit enforcement"""
    try:
        conn = await get_db_connection()
        try:
            # First verify document exists and get pricing info
            # Allow admins to access both published and pending_validation documents
            doc_query = """
                SELECT id, credit_cost, is_premium, title, status
                FROM kb_documents 
                WHERE id = $1 AND status IN ('published', 'pending_validation')
            """
            doc_result = await conn.fetchrow(doc_query, document_id)
            
            if not doc_result:
                raise HTTPException(status_code=404, detail="Document not found or not published")
            
            # Check if document requires credits
            credit_cost = doc_result['credit_cost'] or 0
            is_premium = doc_result['is_premium'] or False
            
            if is_premium and credit_cost > 0:
                # Check user's credit balance
                balance_row = await conn.fetchrow(
                    "SELECT current_balance FROM user_credits WHERE user_id = $1",
                    user.sub
                )
                
                current_balance = balance_row['current_balance'] if balance_row else 0
                
                if current_balance < credit_cost:
                    raise HTTPException(
                        status_code=402,
                        detail={
                            "message": "Insufficient credits for document access",
                            "required_credits": credit_cost,
                            "current_balance": current_balance,
                            "document_title": doc_result['title']
                        }
                    )
                
                # Consume credits in a transaction
                async with conn.transaction():
                    # Update user balance
                    new_balance = current_balance - credit_cost
                    await conn.execute(
                        """UPDATE user_credits 
                           SET current_balance = $1, lifetime_consumed = lifetime_consumed + $2, updated_at = CURRENT_TIMESTAMP
                           WHERE user_id = $3""",
                        new_balance, credit_cost, user.sub
                    )
                    
                    # Log the transaction
                    await conn.execute(
                        """INSERT INTO credit_transactions 
                           (user_id, transaction_type, amount, balance_after, description, component_name, action_name, resource_id)
                           VALUES ($1, 'consume', $2, $3, $4, 'knowledge_base', 'document_sections_access', $5)""",
                        user.sub, credit_cost, new_balance, 
                        f"Accessed sections for document: {doc_result['title']}", document_id
                    )
            
            # Fetch document sections
            query = """
                SELECT id, document_id, section_number, section_title, section_content, 
                       parent_section_id, display_order
                FROM kb_document_sections 
                WHERE document_id = $1
                ORDER BY display_order, id
            """
            rows = await conn.fetch(query, document_id)
            
            sections = [
                DocumentSection(
                    id=row['id'],
                    document_id=row['document_id'],
                    section_number=row['section_number'],
                    section_title=row['section_title'],
                    section_content=row['section_content'],
                    parent_section_id=row['parent_section_id'],
                    display_order=row['display_order']
                )
                for row in rows
            ]
            
            return DocumentSectionsResponse(sections=sections, total=len(sections))
            
        finally:
            await conn.close()
            
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error fetching document sections: {e}")
        raise HTTPException(status_code=500, detail="Failed to fetch document sections")
