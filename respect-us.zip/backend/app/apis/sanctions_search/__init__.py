

from fastapi import APIRouter, Query
from pydantic import BaseModel, Field
from typing import List, Optional
from datetime import datetime
import asyncio
from app.auth import AuthorizedUser

router = APIRouter()

class SanctionEntity(BaseModel):
    id: str
    name: str
    entity_type: str  # "person", "entity", "vessel", "aircraft"
    aliases: List[str] = []
    sanctions_program: str
    jurisdiction: str
    risk_level: str  # "high", "medium", "low"
    description: Optional[str] = None
    date_added: datetime
    source_list: str
    details: dict = {}
    
class SanctionsSearchRequest(BaseModel):
    query: str = Field(..., min_length=2, description="Search query for person/entity name")
    entity_type: Optional[str] = Field(None, description="Filter by entity type")
    jurisdiction: Optional[str] = Field(None, description="Filter by jurisdiction")
    sanctions_program: Optional[str] = Field(None, description="Filter by sanctions program")
    risk_level: Optional[str] = Field(None, description="Filter by risk level")
    limit: int = Field(default=50, le=100, description="Maximum number of results")
    exact_match: bool = Field(default=False, description="Require exact name match")

class SanctionsSearchResponse(BaseModel):
    entities: List[SanctionEntity]
    total_count: int
    search_time_ms: int
    query_used: str
    suggestions: List[str] = []

# Sample sanctions data for demonstration
SAMPLE_SANCTIONS_DATA = [
    SanctionEntity(
        id="sanc-001",
        name="Ivan Petrov",
        entity_type="person",
        aliases=["I. Petrov", "Ivan P."],
        sanctions_program="Ukraine-related sanctions",
        jurisdiction="US (OFAC)",
        risk_level="high",
        description="Senior government official involved in undermining Ukraine's sovereignty",
        date_added=datetime(2022, 3, 15),
        source_list="OFAC SDN List",
        details={
            "program_code": "UKRAINE-EO13661",
            "sanctions_type": "Asset freeze, travel ban",
            "citizenship": "Russian Federation",
            "dob": "1965-04-12"
        }
    ),
    SanctionEntity(
        id="sanc-002",
        name="Crimean Development Corporation",
        entity_type="entity",
        aliases=["CDC", "Crimean Dev Corp"],
        sanctions_program="Crimea-related sanctions",
        jurisdiction="US (OFAC)", 
        risk_level="high",
        description="State-owned enterprise operating in occupied Crimea",
        date_added=datetime(2021, 8, 20),
        source_list="OFAC SDN List",
        details={
            "program_code": "CRIMEA-EO13685",
            "sanctions_type": "Asset freeze, transaction prohibition",
            "location": "Simferopol, Crimea",
            "entity_type": "State-owned enterprise"
        }
    ),
    SanctionEntity(
        id="sanc-003",
        name="Muhammad Hassan Al-Rashid",
        entity_type="person",
        aliases=["M.H. Al-Rashid", "Hassan Rashid"],
        sanctions_program="Counter-terrorism sanctions",
        jurisdiction="EU",
        risk_level="high",
        description="Individual associated with terrorist financing activities",
        date_added=datetime(2020, 11, 5),
        source_list="EU Consolidated List",
        details={
            "program_code": "EU-TERRORISM",
            "sanctions_type": "Asset freeze, travel restriction",
            "nationality": "Lebanese",
            "dob": "1978-09-22"
        }
    ),
    SanctionEntity(
        id="sanc-004",
        name="North Korean Mining Enterprise",
        entity_type="entity",
        aliases=["NKME", "NK Mining Co"],
        sanctions_program="DPRK sanctions",
        jurisdiction="UN",
        risk_level="high",
        description="Entity involved in prohibited mineral trade from North Korea",
        date_added=datetime(2019, 6, 30),
        source_list="UN Consolidated List",
        details={
            "program_code": "UN-DPRK-1718",
            "sanctions_type": "Asset freeze, transaction prohibition",
            "location": "Pyongyang, DPRK",
            "sector": "Mining and minerals"
        }
    ),
    SanctionEntity(
        id="sanc-005",
        name="Viktor Kozlov",
        entity_type="person",
        aliases=["V. Kozlov", "Victor Kozlov"],
        sanctions_program="Belarus-related sanctions",
        jurisdiction="UK (HMT)",
        risk_level="medium",
        description="Government official supporting the Lukashenko regime",
        date_added=datetime(2021, 12, 10),
        source_list="UK Sanctions List",
        details={
            "program_code": "UK-BELARUS",
            "sanctions_type": "Asset freeze, travel ban",
            "position": "Deputy Minister of Interior",
            "dob": "1972-03-18"
        }
    ),
    SanctionEntity(
        id="sanc-006",
        name="Iranian Petrochemical Company",
        entity_type="entity",
        aliases=["IPC", "Iran Petrochem"],
        sanctions_program="Iran sanctions",
        jurisdiction="US (OFAC)",
        risk_level="high",
        description="Entity involved in Iran's petrochemical sector subject to sanctions",
        date_added=datetime(2020, 2, 14),
        source_list="OFAC SDN List",
        details={
            "program_code": "IRAN-EO13846",
            "sanctions_type": "Sectoral sanctions, asset freeze",
            "sector": "Petrochemicals",
            "location": "Tehran, Iran"
        }
    )
]

def search_sanctions_entities(query: str, filters: dict = None) -> List[SanctionEntity]:
    """Search sanctions entities with fuzzy matching and filtering"""
    if not query or len(query.strip()) < 2:
        return []
    
    query_lower = query.lower().strip()
    results = []
    
    for entity in SAMPLE_SANCTIONS_DATA:
        # Check if query matches name or aliases
        name_match = query_lower in entity.name.lower()
        alias_match = any(query_lower in alias.lower() for alias in entity.aliases)
        
        if name_match or alias_match:
            # Apply filters if provided
            if filters:
                if filters.get('entity_type') and entity.entity_type != filters['entity_type']:
                    continue
                if filters.get('jurisdiction') and entity.jurisdiction != filters['jurisdiction']:
                    continue
                if filters.get('sanctions_program') and entity.sanctions_program != filters['sanctions_program']:
                    continue
                if filters.get('risk_level') and entity.risk_level != filters['risk_level']:
                    continue
            
            results.append(entity)
    
    # Sort by relevance (exact matches first, then partial matches)
    def relevance_score(entity):
        score = 0
        if query_lower == entity.name.lower():
            score += 100  # Exact name match
        elif query_lower in entity.name.lower():
            score += 50   # Partial name match
        
        for alias in entity.aliases:
            if query_lower == alias.lower():
                score += 80  # Exact alias match
            elif query_lower in alias.lower():
                score += 30  # Partial alias match
        
        # Boost high-risk entities
        if entity.risk_level == "high":
            score += 10
        
        return score
    
    results.sort(key=relevance_score, reverse=True)
    return results

@router.post("/sanctions/search", response_model=SanctionsSearchResponse)
async def search_sanctions(
    request: SanctionsSearchRequest,
    user: AuthorizedUser
):
    """Search sanctions lists for compliance screening"""
    start_time = datetime.now()
    
    # Build filters from request
    filters = {}
    if request.entity_type:
        filters['entity_type'] = request.entity_type
    if request.jurisdiction:
        filters['jurisdiction'] = request.jurisdiction
    if request.sanctions_program:
        filters['sanctions_program'] = request.sanctions_program
    if request.risk_level:
        filters['risk_level'] = request.risk_level
    
    # Perform search
    entities = search_sanctions_entities(request.query, filters)
    
    # Apply limit
    limited_entities = entities[:request.limit]
    
    # Calculate search time
    search_time = (datetime.now() - start_time).total_seconds() * 1000
    
    # Generate suggestions for no results
    suggestions = []
    if not entities and len(request.query) > 2:
        # Simple suggestions based on available data
        all_names = [entity.name for entity in SAMPLE_SANCTIONS_DATA]
        suggestions = [name for name in all_names if any(word in name.lower() for word in request.query.lower().split())][:3]
    
    return SanctionsSearchResponse(
        entities=limited_entities,
        total_count=len(entities),
        search_time_ms=int(search_time),
        query_used=request.query,
        suggestions=suggestions
    )

@router.get("/entity/{entity_id}", response_model=SanctionEntity)
async def get_sanctions_search_entity(
    entity_id: str,
    user: AuthorizedUser
):
    """Get detailed information about a specific sanctioned entity"""
    for entity in SAMPLE_SANCTIONS_DATA:
        if entity.id == entity_id:
            return entity
    
    from fastapi import HTTPException
    raise HTTPException(status_code=404, detail="Sanctioned entity not found")

@router.get("/jurisdictions", response_model=List[str])
async def get_sanctions_jurisdictions(user: AuthorizedUser):
    """Get list of available sanctions jurisdictions"""
    jurisdictions = list(set(entity.jurisdiction for entity in SAMPLE_SANCTIONS_DATA))
    return sorted(jurisdictions)

@router.get("/programs", response_model=List[str])
async def get_sanctions_programs(user: AuthorizedUser):
    """Get list of available sanctions programs"""
    programs = list(set(entity.sanctions_program for entity in SAMPLE_SANCTIONS_DATA))
    return sorted(programs)

@router.get("/entity-types", response_model=List[str])
async def get_entity_types(user: AuthorizedUser):
    """Get list of available entity types"""
    return ["person", "entity", "vessel", "aircraft"]

@router.get("/sanctions/risk-levels", response_model=List[str])
async def get_risk_levels(user: AuthorizedUser):
    """Get list of available risk levels for sanctions"""
    return ["critical", "high", "medium", "low"]
