from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
from datetime import datetime, date
import asyncpg
import databutton as db
from app.auth import AuthorizedUser
from app.libs.database import get_db_connection
import json
import uuid
import io
import zipfile
from xml.etree import ElementTree as ET
from fastapi import UploadFile, File

router = APIRouter(prefix="/sanctions-lists")

# Pydantic Models
class SanctionsListBase(BaseModel):
    """Base model for sanctions list"""
    name: str = Field(..., min_length=1, max_length=255)
    description: Optional[str] = None
    list_type: str = Field(..., description="Type of list: sanctions, watchlist, denied_persons, export_control, terrorism, pep, custom")
    source: Optional[str] = None
    source_url: Optional[str] = None
    authority: Optional[str] = None  # e.g., OFAC, EU, UN, BIS
    country_jurisdiction: Optional[str] = None
    is_active: bool = True
    is_official: bool = False
    update_frequency: str = Field(default="manual", description="manual, daily, weekly, monthly")
    risk_level: str = Field(default="high", description="low, medium, high, critical")
    matching_algorithm: str = Field(default="fuzzy", description="exact, fuzzy, phonetic, combined")
    minimum_match_score: float = Field(default=0.80, ge=0, le=1)
    notes: Optional[str] = None

class SanctionsListCreate(SanctionsListBase):
    """Model for creating a new sanctions list"""
    pass

class SanctionsListUpdate(BaseModel):
    """Model for updating a sanctions list"""
    name: Optional[str] = None
    description: Optional[str] = None
    list_type: Optional[str] = None
    source: Optional[str] = None
    source_url: Optional[str] = None
    authority: Optional[str] = None
    country_jurisdiction: Optional[str] = None
    is_active: Optional[bool] = None
    is_official: Optional[bool] = None
    update_frequency: Optional[str] = None
    last_list_update: Optional[datetime] = None
    risk_level: Optional[str] = None
    matching_algorithm: Optional[str] = None
    minimum_match_score: Optional[float] = None
    notes: Optional[str] = None

class SanctionsListResponse(SanctionsListBase):
    """Model for sanctions list response"""
    id: int
    last_updated: Optional[datetime] = None
    last_list_update: Optional[datetime] = None
    next_update_due: Optional[datetime] = None
    total_entries: int = 0
    created_at: datetime
    updated_at: datetime
    created_by: Optional[str] = None
    updated_by: Optional[str] = None

class SanctionsListEntryBase(BaseModel):
    """Base model for sanctions list entry"""
    entry_type: str = Field(..., description="individual, entity, vessel, aircraft, address")
    primary_name: str = Field(..., min_length=1, max_length=500)
    aliases: List[str] = Field(default_factory=list)
    date_of_birth: Optional[date] = None
    place_of_birth: Optional[str] = None
    nationality: Optional[str] = None
    passport_numbers: List[str] = Field(default_factory=list)
    id_numbers: List[str] = Field(default_factory=list)
    addresses: List[str] = Field(default_factory=list)
    programs: List[str] = Field(default_factory=list)
    reasons: Optional[str] = None
    remarks: Optional[str] = None
    list_date: Optional[date] = None
    modification_date: Optional[date] = None
    is_active: bool = True
    external_id: Optional[str] = None

class SanctionsListEntryCreate(SanctionsListEntryBase):
    """Model for creating a new sanctions list entry"""
    sanctions_list_id: int

class SanctionsListEntryResponse(SanctionsListEntryBase):
    """Model for sanctions list entry response"""
    id: int
    sanctions_list_id: int
    created_at: datetime
    updated_at: datetime

class SanctionsListStats(BaseModel):
    """Statistics for sanctions lists overview"""
    total_lists: int
    active_lists: int
    official_lists: int
    total_entries: int
    lists_by_type: Dict[str, int]
    lists_by_authority: Dict[str, int]
    lists_by_risk_level: Dict[str, int]

class BulkImportRequest(BaseModel):
    """Model for bulk importing sanctions list entries"""
    sanctions_list_id: int
    entries: List[Dict[str, Any]]
    replace_existing: bool = False

class BulkImportResponse(BaseModel):
    """Response for bulk import operation"""
    success: bool
    imported_count: int
    updated_count: int
    skipped_count: int
    errors: List[str]

@router.get("/stats", response_model=SanctionsListStats)
async def get_sanctions_list_stats(user: AuthorizedUser):
    """Get statistics for sanctions lists overview"""
    async with get_db_connection() as conn:
        try:
            # Get basic counts
            total_lists = await conn.fetchval("SELECT COUNT(*) FROM sanctions_lists")
            active_lists = await conn.fetchval("SELECT COUNT(*) FROM sanctions_lists WHERE is_active = true")
            official_lists = await conn.fetchval("SELECT COUNT(*) FROM sanctions_lists WHERE is_official = true")
            total_entries = await conn.fetchval("SELECT SUM(total_entries) FROM sanctions_lists WHERE is_active = true")
            
            # Get counts by type
            type_counts = await conn.fetch(
                "SELECT list_type, COUNT(*) as count FROM sanctions_lists WHERE is_active = true GROUP BY list_type"
            )
            lists_by_type = {row['list_type']: row['count'] for row in type_counts}
            
            # Get counts by authority
            authority_counts = await conn.fetch(
                "SELECT authority, COUNT(*) as count FROM sanctions_lists WHERE is_active = true AND authority IS NOT NULL GROUP BY authority"
            )
            lists_by_authority = {row['authority']: row['count'] for row in authority_counts}
            
            # Get counts by risk level
            risk_counts = await conn.fetch(
                "SELECT risk_level, COUNT(*) as count FROM sanctions_lists WHERE is_active = true GROUP BY risk_level"
            )
            lists_by_risk_level = {row['risk_level']: row['count'] for row in risk_counts}
            
            return SanctionsListStats(
                total_lists=total_lists or 0,
                active_lists=active_lists or 0,
                official_lists=official_lists or 0,
                total_entries=total_entries or 0,
                lists_by_type=lists_by_type,
                lists_by_authority=lists_by_authority,
                lists_by_risk_level=lists_by_risk_level
            )
            
        except Exception as e:
            print(f"Error getting sanctions list stats: {e}")
            raise HTTPException(status_code=500, detail="Failed to get sanctions list statistics")

@router.get("/lists", response_model=List[SanctionsListResponse])
async def list_sanctions_lists(
    user: AuthorizedUser,
    active_only: bool = False,
    list_type: Optional[str] = None,
    authority: Optional[str] = None,
    limit: int = 100,
    offset: int = 0
):
    """List all sanctions lists with filtering"""
    async with get_db_connection() as conn:
        # Build dynamic query
        query = "SELECT * FROM sanctions_lists WHERE 1=1"
        args = []
        
        if active_only:
            query += " AND is_active = true"
        
        if list_type:
            query += f" AND list_type = ${len(args) + 1}"
            args.append(list_type)
        
        if authority:
            query += f" AND authority = ${len(args) + 1}"
            args.append(authority)
        
        query += " ORDER BY created_at DESC"
        query += f" LIMIT ${len(args) + 1} OFFSET ${len(args) + 2}"
        args.extend([limit, offset])
        
        rows = await conn.fetch(query, *args)
        
        return [
            SanctionsListResponse(
                id=row['id'],
                name=row['name'],
                description=row['description'],
                list_type=row['list_type'],
                source=row['source'],
                source_url=row['source_url'],
                authority=row['authority'],
                country_jurisdiction=row['country_jurisdiction'],
                is_active=row['is_active'],
                is_official=row['is_official'],
                update_frequency=row['update_frequency'],
                last_updated=row['last_updated'],
                last_list_update=row['last_list_update'],
                next_update_due=row['next_update_due'],
                total_entries=row['total_entries'] or 0,
                risk_level=row['risk_level'],
                matching_algorithm=row['matching_algorithm'],
                minimum_match_score=float(row['minimum_match_score']),
                notes=row['notes'],
                created_at=row['created_at'],
                updated_at=row['updated_at'],
                created_by=row['created_by'],
                updated_by=row['updated_by']
            )
            for row in rows
        ]

@router.get("/lists/{list_id}", response_model=SanctionsListResponse)
async def get_sanctions_list(list_id: int, user: AuthorizedUser):
    """Get a specific sanctions list by ID"""
    async with get_db_connection() as conn:
        try:
            row = await conn.fetchrow("SELECT * FROM sanctions_lists WHERE id = $1", list_id)
            if not row:
                raise HTTPException(status_code=404, detail="Sanctions list not found")
            
            return SanctionsListResponse(
                id=row['id'],
                name=row['name'],
                description=row['description'],
                list_type=row['list_type'],
                source=row['source'],
                source_url=row['source_url'],
                authority=row['authority'],
                country_jurisdiction=row['country_jurisdiction'],
                is_active=row['is_active'],
                is_official=row['is_official'],
                update_frequency=row['update_frequency'],
                last_updated=row['last_updated'],
                last_list_update=row['last_list_update'],
                next_update_due=row['next_update_due'],
                total_entries=row['total_entries'] or 0,
                risk_level=row['risk_level'],
                matching_algorithm=row['matching_algorithm'],
                minimum_match_score=float(row['minimum_match_score']),
                notes=row['notes'],
                created_at=row['created_at'],
                updated_at=row['updated_at'],
                created_by=row['created_by'],
                updated_by=row['updated_by']
            )
        except Exception as e:
            print(f"Error getting sanctions list: {e}")
            raise HTTPException(status_code=500, detail="Failed to get sanctions list")

@router.post("/lists", response_model=SanctionsListResponse)
async def create_sanctions_list(list_data: SanctionsListCreate, user: AuthorizedUser):
    """Create a new sanctions list"""
    async with get_db_connection() as conn:
        try:
            # Check if list with same name already exists
            existing = await conn.fetchval("SELECT id FROM sanctions_lists WHERE name = $1", list_data.name)
            if existing:
                raise HTTPException(status_code=400, detail="A sanctions list with this name already exists")
            
            row = await conn.fetchrow(
                """
                INSERT INTO sanctions_lists (
                    name, description, list_type, source, source_url, authority, 
                    country_jurisdiction, is_active, is_official, update_frequency, 
                    risk_level, matching_algorithm, minimum_match_score, notes, 
                    created_by, updated_by
                ) VALUES (
                    $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16
                )
                RETURNING *
                """,
                list_data.name, list_data.description, list_data.list_type,
                list_data.source, list_data.source_url, list_data.authority,
                list_data.country_jurisdiction, list_data.is_active, list_data.is_official,
                list_data.update_frequency, list_data.risk_level, list_data.matching_algorithm,
                list_data.minimum_match_score, list_data.notes, user.sub, user.sub
            )
            
            return SanctionsListResponse(
                id=row['id'],
                name=row['name'],
                description=row['description'],
                list_type=row['list_type'],
                source=row['source'],
                source_url=row['source_url'],
                authority=row['authority'],
                country_jurisdiction=row['country_jurisdiction'],
                is_active=row['is_active'],
                is_official=row['is_official'],
                update_frequency=row['update_frequency'],
                last_updated=row['last_updated'],
                last_list_update=row['last_list_update'],
                next_update_due=row['next_update_due'],
                total_entries=row['total_entries'] or 0,
                risk_level=row['risk_level'],
                matching_algorithm=row['matching_algorithm'],
                minimum_match_score=float(row['minimum_match_score']),
                notes=row['notes'],
                created_at=row['created_at'],
                updated_at=row['updated_at'],
                created_by=row['created_by'],
                updated_by=row['updated_by']
            )
        except Exception as e:
            print(f"Error creating sanctions list: {e}")
            raise HTTPException(status_code=500, detail="Failed to create sanctions list")

@router.put("/lists/{list_id}", response_model=SanctionsListResponse)
async def update_sanctions_list(list_id: int, list_data: SanctionsListUpdate, user: AuthorizedUser):
    """Update an existing sanctions list"""
    async with get_db_connection() as conn:
        try:
            # Check if list exists
            existing = await conn.fetchrow("SELECT * FROM sanctions_lists WHERE id = $1", list_id)
            if not existing:
                raise HTTPException(status_code=404, detail="Sanctions list not found")
            
            # Check if new name conflicts with existing list (if name is being updated)
            if list_data.name and list_data.name != existing['name']:
                name_conflict = await conn.fetchval(
                    "SELECT id FROM sanctions_lists WHERE name = $1 AND id != $2", 
                    list_data.name, list_id
                )
                if name_conflict:
                    raise HTTPException(status_code=400, detail="A sanctions list with this name already exists")
            
            # Build update query dynamically
            update_fields = []
            args = []
            
            for field, value in list_data.dict(exclude_unset=True).items():
                update_fields.append(f"{field} = ${len(args) + 1}")
                args.append(value)
            
            if not update_fields:
                return await get_sanctions_list(list_id, user)
            
            update_fields.append(f"updated_by = ${len(args) + 1}")
            args.append(user.sub)
            
            args.append(list_id)  # For WHERE clause
            
            query = f"""
                UPDATE sanctions_lists 
                SET {', '.join(update_fields)}
                WHERE id = ${len(args)}
                RETURNING *
            """
            
            row = await conn.fetchrow(query, *args)
            
            return SanctionsListResponse(
                id=row['id'],
                name=row['name'],
                description=row['description'],
                list_type=row['list_type'],
                source=row['source'],
                source_url=row['source_url'],
                authority=row['authority'],
                country_jurisdiction=row['country_jurisdiction'],
                is_active=row['is_active'],
                is_official=row['is_official'],
                update_frequency=row['update_frequency'],
                last_updated=row['last_updated'],
                last_list_update=row['last_list_update'],
                next_update_due=row['next_update_due'],
                total_entries=row['total_entries'] or 0,
                risk_level=row['risk_level'],
                matching_algorithm=row['matching_algorithm'],
                minimum_match_score=float(row['minimum_match_score']),
                notes=row['notes'],
                created_at=row['created_at'],
                updated_at=row['updated_at'],
                created_by=row['created_by'],
                updated_by=row['updated_by']
            )
        except Exception as e:
            print(f"Error updating sanctions list: {e}")
            raise HTTPException(status_code=500, detail="Failed to update sanctions list")

@router.delete("/lists/{list_id}")
async def delete_sanctions_list(list_id: int, user: AuthorizedUser):
    """Delete a sanctions list and all its entries"""
    async with get_db_connection() as conn:
        try:
            # Check if list exists
            existing = await conn.fetchval("SELECT id FROM sanctions_lists WHERE id = $1", list_id)
            if not existing:
                raise HTTPException(status_code=404, detail="Sanctions list not found")
            
            # Delete the list (entries will be cascade deleted)
            await conn.execute("DELETE FROM sanctions_lists WHERE id = $1", list_id)
            
            return {"message": "Sanctions list deleted successfully"}
        except Exception as e:
            print(f"Error deleting sanctions list: {e}")
            raise HTTPException(status_code=500, detail="Failed to delete sanctions list")

@router.get("/lists/{list_id}/entries", response_model=List[SanctionsListEntryResponse])
async def get_sanctions_list_entries(
    list_id: int, 
    user: AuthorizedUser,
    entry_type: Optional[str] = None,
    active_only: bool = True,
    search: Optional[str] = None,
    limit: int = 100,
    offset: int = 0
):
    """Get entries for a specific sanctions list"""
    async with get_db_connection() as conn:
        try:
            # Check if list exists
            list_exists = await conn.fetchval("SELECT id FROM sanctions_lists WHERE id = $1", list_id)
            if not list_exists:
                raise HTTPException(status_code=404, detail="Sanctions list not found")
            
            query = "SELECT * FROM sanctions_list_entries WHERE sanctions_list_id = $1"
            args = [list_id]
            
            if active_only:
                query += " AND is_active = true"
            
            if entry_type:
                query += f" AND entry_type = ${len(args) + 1}"
                args.append(entry_type)
            
            if search:
                query += f" AND (primary_name ILIKE ${len(args) + 1} OR ${len(args) + 1} = ANY(aliases))"
                search_pattern = f"%{search}%"
                args.extend([search_pattern, search])
            
            query += " ORDER BY primary_name"
            query += f" LIMIT ${len(args) + 1} OFFSET ${len(args) + 2}"
            args.extend([limit, offset])
            
            rows = await conn.fetch(query, *args)
            
            return [
                SanctionsListEntryResponse(
                    id=row['id'],
                    sanctions_list_id=row['sanctions_list_id'],
                    entry_type=row['entry_type'],
                    primary_name=row['primary_name'],
                    aliases=row['aliases'] or [],
                    date_of_birth=row['date_of_birth'],
                    place_of_birth=row['place_of_birth'],
                    nationality=row['nationality'],
                    passport_numbers=row['passport_numbers'] or [],
                    id_numbers=row['id_numbers'] or [],
                    addresses=row['addresses'] or [],
                    programs=row['programs'] or [],
                    reasons=row['reasons'],
                    remarks=row['remarks'],
                    list_date=row['list_date'],
                    modification_date=row['modification_date'],
                    is_active=row['is_active'],
                    external_id=row['external_id'],
                    created_at=row['created_at'],
                    updated_at=row['updated_at']
                )
                for row in rows
            ]
        except Exception as e:
            print(f"Error getting sanctions list entries: {e}")
            raise HTTPException(status_code=500, detail="Failed to get sanctions list entries")

@router.post("/lists/{list_id}/entries", response_model=SanctionsListEntryResponse)
async def create_sanctions_list_entry(list_id: int, entry_data: SanctionsListEntryCreate, user: AuthorizedUser):
    """Add a new entry to a sanctions list"""
    async with get_db_connection() as conn:
        try:
            # Check if list exists
            list_exists = await conn.fetchval("SELECT id FROM sanctions_lists WHERE id = $1", list_id)
            if not list_exists:
                raise HTTPException(status_code=404, detail="Sanctions list not found")
            
            # Override the list_id to ensure consistency
            entry_data.sanctions_list_id = list_id
            
            row = await conn.fetchrow(
                """
                INSERT INTO sanctions_list_entries (
                    sanctions_list_id, entry_type, primary_name, aliases, date_of_birth,
                    place_of_birth, nationality, passport_numbers, id_numbers, addresses,
                    programs, reasons, remarks, list_date, modification_date, is_active, external_id
                ) VALUES (
                    $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17
                )
                RETURNING *
                """,
                entry_data.sanctions_list_id, entry_data.entry_type, entry_data.primary_name,
                entry_data.aliases, entry_data.date_of_birth, entry_data.place_of_birth,
                entry_data.nationality, entry_data.passport_numbers, entry_data.id_numbers,
                entry_data.addresses, entry_data.programs, entry_data.reasons, entry_data.remarks,
                entry_data.list_date, entry_data.modification_date, entry_data.is_active, entry_data.external_id
            )
            
            # Update total entries count in the list
            await conn.execute(
                "UPDATE sanctions_lists SET total_entries = (SELECT COUNT(*) FROM sanctions_list_entries WHERE sanctions_list_id = $1 AND is_active = true) WHERE id = $1",
                list_id
            )
            
            return SanctionsListEntryResponse(
                id=row['id'],
                sanctions_list_id=row['sanctions_list_id'],
                entry_type=row['entry_type'],
                primary_name=row['primary_name'],
                aliases=row['aliases'] or [],
                date_of_birth=row['date_of_birth'],
                place_of_birth=row['placeof_birth'],
                nationality=row['nationality'],
                passport_numbers=row['passport_numbers'] or [],
                id_numbers=row['id_numbers'] or [],
                addresses=row['addresses'] or [],
                programs=row['programs'] or [],
                reasons=row['reasons'],
                remarks=row['remarks'],
                list_date=row['list_date'],
                modification_date=row['modification_date'],
                is_active=row['is_active'],
                external_id=row['external_id'],
                created_at=row['created_at'],
                updated_at=row['updated_at']
            )
        except Exception as e:
            print(f"Error creating sanctions list entry: {e}")
            raise HTTPException(status_code=500, detail="Failed to create sanctions list entry")

@router.post("/lists/{list_id}/bulk-import", response_model=BulkImportResponse)
async def bulk_import_entries(list_id: int, import_request: BulkImportRequest, user: AuthorizedUser):
    """Bulk import entries into a sanctions list"""
    async with get_db_connection() as conn:
        try:
            # Check if list exists
            list_exists = await conn.fetchval("SELECT id FROM sanctions_lists WHERE id = $1", list_id)
            if not list_exists:
                raise HTTPException(status_code=404, detail="Sanctions list not found")
            
            imported_count = 0
            updated_count = 0
            skipped_count = 0
            errors = []
            
            print(f"🚀 Starting bulk import for list {list_id}: {len(import_request.entries)} entries")
            print(f"   Replace existing: {import_request.replace_existing}")
            
            # Start transaction
            async with conn.transaction():
                if import_request.replace_existing:
                    # Delete existing entries
                    deleted_count = await conn.fetchval(
                        "SELECT COUNT(*) FROM sanctions_list_entries WHERE sanctions_list_id = $1",
                        list_id
                    )
                    await conn.execute(
                        "DELETE FROM sanctions_list_entries WHERE sanctions_list_id = $1", 
                        list_id
                    )
                    print(f"   Deleted {deleted_count} existing entries")
                
                for i, entry_data in enumerate(import_request.entries):
                    try:
                        # Parse date fields safely
                        date_of_birth = parse_date_safely(entry_data.get('date_of_birth'))
                        list_date = parse_date_safely(entry_data.get('list_date'))
                        modification_date = parse_date_safely(entry_data.get('modification_date'))
                        
                        # Check if entry already exists (by external_id or primary_name)
                        existing = None
                        if entry_data.get('external_id'):
                            existing = await conn.fetchval(
                                "SELECT id FROM sanctions_list_entries WHERE sanctions_list_id = $1 AND external_id = $2",
                                list_id, entry_data['external_id']
                            )
                        
                        if not existing and entry_data.get('primary_name'):
                            existing = await conn.fetchval(
                                "SELECT id FROM sanctions_list_entries WHERE sanctions_list_id = $1 AND primary_name = $2",
                                list_id, entry_data['primary_name']
                            )
                        
                        if existing and not import_request.replace_existing:
                            skipped_count += 1
                            continue
                        
                        # Insert or update entry
                        if existing:
                            # Update existing entry
                            await conn.execute(
                                """
                                UPDATE sanctions_list_entries SET
                                    entry_type = $1, primary_name = $2, aliases = $3,
                                    date_of_birth = $4, place_of_birth = $5, nationality = $6,
                                    passport_numbers = $7, id_numbers = $8, addresses = $9,
                                    programs = $10, reasons = $11, remarks = $12,
                                    list_date = $13, modification_date = $14, is_active = $15,
                                    external_id = $16, updated_at = CURRENT_TIMESTAMP
                                WHERE id = $17
                                """,
                                entry_data.get('entry_type', 'individual'),
                                entry_data.get('primary_name', ''),
                                entry_data.get('aliases', []),
                                date_of_birth,
                                entry_data.get('place_of_birth'),
                                entry_data.get('nationality'),
                                entry_data.get('passport_numbers', []),
                                entry_data.get('id_numbers', []),
                                entry_data.get('addresses', []),
                                entry_data.get('programs', []),
                                entry_data.get('reasons'),
                                entry_data.get('remarks'),
                                list_date,
                                modification_date,
                                entry_data.get('is_active', True),
                                entry_data.get('external_id'),
                                existing
                            )
                            updated_count += 1
                        else:
                            # Insert new entry
                            await conn.execute(
                                """
                                INSERT INTO sanctions_list_entries (
                                    sanctions_list_id, entry_type, primary_name, aliases, date_of_birth,
                                    place_of_birth, nationality, passport_numbers, id_numbers, addresses,
                                    programs, reasons, remarks, list_date, modification_date, is_active, external_id
                                ) VALUES (
                                    $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17
                                )
                                """,
                                list_id,
                                entry_data.get('entry_type', 'individual'),
                                entry_data.get('primary_name', ''),
                                entry_data.get('aliases', []),
                                date_of_birth,
                                entry_data.get('place_of_birth'),
                                entry_data.get('nationality'),
                                entry_data.get('passport_numbers', []),
                                entry_data.get('id_numbers', []),
                                entry_data.get('addresses', []),
                                entry_data.get('programs', []),
                                entry_data.get('reasons'),
                                entry_data.get('remarks'),
                                list_date,
                                modification_date,
                                entry_data.get('is_active', True),
                                entry_data.get('external_id')
                            )
                            imported_count += 1
                        
                        if (i + 1) % 100 == 0:
                            print(f"   Processed {i + 1} entries: {imported_count} imported, {updated_count} updated, {skipped_count} skipped")
                        
                    except Exception as e:
                        error_msg = f"Row {i + 1}: {str(e)}"
                        errors.append(error_msg)
                        skipped_count += 1
                        print(f"❌ Error processing row {i + 1}: {e}")
                
                # Update total entries count in the list
                total_entries = await conn.fetchval(
                    "SELECT COUNT(*) FROM sanctions_list_entries WHERE sanctions_list_id = $1 AND is_active = true",
                    list_id
                )
                await conn.execute(
                    "UPDATE sanctions_lists SET total_entries = $1, last_updated = CURRENT_TIMESTAMP WHERE id = $2",
                    total_entries, list_id
                )
                
                print(f"✅ Bulk import completed: {imported_count} imported, {updated_count} updated, {skipped_count} skipped")
                print(f"   Total entries in list: {total_entries}")
            
            return BulkImportResponse(
                success=len(errors) == 0,
                imported_count=imported_count,
                updated_count=updated_count,
                skipped_count=skipped_count,
                errors=errors
            )
        except Exception as e:
            print(f"❌ Bulk import failed: {e}")
            raise HTTPException(status_code=500, detail=f"Bulk import failed: {str(e)}")
        finally:
            await conn.close()

@router.get("/list-types")
async def get_list_types(user: AuthorizedUser):
    """Get available list types"""
    return {
        "list_types": [
            {"value": "sanctions", "label": "Sanctions List"},
            {"value": "watchlist", "label": "Watchlist"},
            {"value": "denied_persons", "label": "Denied Persons List"},
            {"value": "export_control", "label": "Export Control List"},
            {"value": "terrorism", "label": "Terrorism List"},
            {"value": "pep", "label": "Politically Exposed Persons"},
            {"value": "custom", "label": "Custom List"}
        ],
        "entry_types": [
            {"value": "individual", "label": "Individual"},
            {"value": "entity", "label": "Entity/Company"},
            {"value": "vessel", "label": "Vessel"},
            {"value": "aircraft", "label": "Aircraft"},
            {"value": "address", "label": "Address"}
        ],
        "risk_levels": [
            {"value": "low", "label": "Low Risk"},
            {"value": "medium", "label": "Medium Risk"},
            {"value": "high", "label": "High Risk"},
            {"value": "critical", "label": "Critical Risk"}
        ],
        "matching_algorithms": [
            {"value": "exact", "label": "Exact Match"},
            {"value": "fuzzy", "label": "Fuzzy Match"},
            {"value": "phonetic", "label": "Phonetic Match"},
            {"value": "combined", "label": "Combined Match"}
        ],
        "update_frequencies": [
            {"value": "manual", "label": "Manual"},
            {"value": "daily", "label": "Daily"},
            {"value": "weekly", "label": "Weekly"},
            {"value": "monthly", "label": "Monthly"}
        ]
    }

# Module-level singleton to avoid B008 linting issue
_FILE_DEPENDENCY = File(...)

@router.post("/import-xml")
async def import_xml_sanctions(file: UploadFile = _FILE_DEPENDENCY) -> Dict[str, Any]:
    """Import sanctions from UN Security Council XML file"""
    print(f"📁 Importing XML sanctions file: {file.filename}")
    
    if not file.filename.endswith('.xml'):
        raise HTTPException(status_code=400, detail="File must be an XML file")
    
    try:
        # Read XML content
        content = await file.read()
        xml_content = content.decode('utf-8')
        
        # Parse UN Security Council XML
        imported_entries = await parse_un_security_council_xml(xml_content)
        
        if not imported_entries:
            return {
                "success": True,
                "message": "No valid entries found in XML file",
                "imported_count": 0,
                "errors": []
            }
        
        # Connect to database and import entries
        db_url = db.secrets.get("DATABASE_URL_DEV")
        conn = await asyncpg.connect(db_url)
        
        try:
            imported_count = 0
            errors = []
            
            # First, ensure the UN Security Council sanctions list exists (outside main transaction)
            list_name = "UN Security Council List"
            
            # Check if the sanctions list already exists
            existing_list = await conn.fetchrow("""
                SELECT id, total_entries FROM sanctions_lists 
                WHERE name = $1
            """, list_name)
            
            sanctions_list_id = None
            
            if existing_list:
                sanctions_list_id = existing_list['id']
                print(f"📋 Found existing sanctions list: {list_name} (ID: {sanctions_list_id})")
            else:
                # Create new sanctions list
                sanctions_list_id = await conn.fetchval("""
                    INSERT INTO sanctions_lists 
                    (name, description, list_type, source, source_url, authority, 
                     country_jurisdiction, is_active, is_official, update_frequency, 
                     risk_level, matching_algorithm, minimum_match_score, notes, 
                     total_entries, created_at, updated_at)
                    VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17)
                    RETURNING id
                """, 
                    list_name,
                    "UN Security Council Consolidated Sanctions List - imported from XML",
                    "sanctions",
                    "UN Security Council",
                    "https://www.un.org/securitycouncil/sanctions/1267/aq_sanctions_list",
                    "UN Security Council",
                    "UN",
                    True,  # is_active
                    True,  # is_official
                    "manual",  # update_frequency
                    "high",  # risk_level
                    "fuzzy",  # matching_algorithm
                    0.80,  # minimum_match_score
                    "Imported from UN Security Council XML file",
                    0,  # entry_count - will be updated below
                    datetime.now(),
                    datetime.now()
                )
                print(f"📋 Created new sanctions list: {list_name} (ID: {sanctions_list_id})")

            # Clear existing entries for this list if updating
            if existing_list:
                await conn.execute("""
                    DELETE FROM sanctions_list_entries 
                    WHERE sanctions_list_id = $1
                """, sanctions_list_id)
                print(f"🧹 Cleared existing entries for list ID: {sanctions_list_id}")
            
            # Import entries into both watchlist_entries and sanctions_list_entries tables
            # Use individual transactions for each entry to isolate failures
            for entry_data in imported_entries:
                try:
                    # Start individual transaction for this entry
                    async with conn.transaction():
                        # Create JSON-safe version for raw_data
                        raw_data = entry_data.copy()
                        if raw_data.get('dateof_birth'):
                            raw_data['dateof_birth'] = raw_data['date_of_birth'].isoformat() if hasattr(raw_data['dateof_birth'], 'isoformat') else str(raw_data['dateof_birth'])
                        if raw_data.get('listing_date'):
                            raw_data['listing_date'] = raw_data['listing_date'].isoformat() if hasattr(raw_data['listing_date'], 'isoformat') else str(raw_data['listing_date'])
                        if raw_data.get('last_updated'):
                            raw_data['last_updated'] = raw_data['last_updated'].isoformat() if hasattr(raw_data['last_updated'], 'isoformat') else str(raw_data['last_updated'])
                        
                        # Insert into watchlist_entries table
                        await conn.execute("""
                            INSERT INTO watchlist_entries 
                            (list_name, entity_name, aliases, entity_type, country, date_of_birth, 
                             identification_numbers, sanctions_program, listing_date, last_updated, 
                             is_active, source_url, raw_data)
                            VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13)
                        """, 
                            entry_data['list_name'],
                            entry_data['entity_name'], 
                            json.dumps(entry_data['aliases']),
                            'company' if entry_data['entity_type'] == 'entity' else entry_data['entity_type'],  # Map 'entity' to 'company' for watchlist_entries constraint
                            entry_data['country'],
                            entry_data['dateof_birth'],
                            json.dumps(entry_data['identification_numbers']),
                            entry_data['sanctions_program'],
                            entry_data['listing_date'],
                            entry_data['last_updated'],
                            entry_data['is_active'],
                            'https://www.un.org/securitycouncil/sanctions/1267/aq_sanctions_list',
                            json.dumps(raw_data)
                        )
                        
                        # Insert into sanctions_list_entries table
                        await conn.execute("""
                            INSERT INTO sanctions_list_entries 
                            (sanctions_list_id, entry_type, primary_name, aliases, 
                             date_of_birth, place_of_birth, nationality, passport_numbers, id_numbers, addresses,
                             programs, reasons, remarks, list_date, modification_date, is_active, external_id, source_data)
                            VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18)
                        """, 
                            sanctions_list_id,
                            entry_data['entity_type'],  # Use 'entity' directly for sanctions_list_entries constraint
                            entry_data['entity_name'],
                            entry_data['aliases'] if entry_data['aliases'] else [],  # Pass as Python list for ARRAY type
                            entry_data['dateof_birth'],
                            None,  # place_of_birth - not available in UN data
                            entry_data['country'],  # Map to nationality
                            [],  # passport_numbers - Pass as empty list for ARRAY type
                            entry_data['identification_numbers'] if entry_data['identification_numbers'] else [],  # Pass as Python list for ARRAY type
                            [],  # addresses - Pass as empty list for ARRAY type
                            [entry_data['sanctions_program']] if entry_data['sanctions_program'] else [],  # Pass as Python list for ARRAY type
                            None,  # reasons - not available in UN data
                            None,  # remarks - not available in UN data
                            entry_data['listing_date'],
                            entry_data['listing_date'] if entry_data.get('listing_date') else None,  # modification_date (use listing_date, not last_updated for date field)
                            entry_data['is_active'],
                            None,  # external_id - could add UN reference if needed
                            json.dumps({  # Convert to JSON string for JSONB
                                'sanctions_program': entry_data['sanctions_program'],
                                'listing_date': entry_data['listing_date'].isoformat() if hasattr(entry_data['listing_date'], 'isoformat') else str(entry_data['listing_date']),
                                'source_url': 'https://www.un.org/securitycouncil/sanctions/1267/aq_sanctions_list',
                                'country': entry_data['country']
                            })
                        )
                    
                    # If we get here, the transaction committed successfully
                    imported_count += 1
                    print(f"✅ Imported: {entry_data['entity_name']}")
                    
                except Exception as e:
                    print(f"❌ Error importing entry '{entry_data.get('entity_name', 'unknown')}': {e}")
                    errors.append(f"Failed to import {entry_data.get('entity_name', 'unknown')}: {str(e)}")
                    continue
            
            # Update the entry count for the sanctions list
            await conn.execute("""
                UPDATE sanctions_lists 
                SET total_entries = $1, updated_at = $2
                WHERE id = $3
            """, imported_count, datetime.now(), sanctions_list_id)
            
            print(f"✅ Imported {imported_count} sanctions entries from XML")
            
            return {
                "success": True,
                "message": f"Successfully imported {imported_count} sanctions entries",
                "imported_count": imported_count,
                "errors": errors[:10]  # Limit to first 10 errors
            }
            
        finally:
            await conn.close()
            
    except Exception as e:
        print(f"❌ Error importing XML: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to import XML file: {str(e)}")

# Helper functions
async def parse_un_security_council_xml(xml_content: str) -> List[Dict[str, Any]]:
    """Parse UN Security Council Consolidated List XML format"""
    try:
        root = ET.fromstring(xml_content)
        entries = []
        
        # Handle different XML namespaces and structures
        # UN Security Council XML typically has INDIVIDUAL and ENTITY elements
        
        # Find all individuals
        for individual in root.findall('.//INDIVIDUAL'):
            entry = parse_individual_entry(individual)
            if entry:
                entries.append(entry)
        
        # Find all entities
        for entity in root.findall('.//ENTITY'):
            entry = parse_entity_entry(entity)
            if entry:
                entries.append(entry)
                
        print(f"📊 Parsed {len(entries)} entries from UN Security Council XML")
        return entries
        
    except ET.ParseError as e:
        print(f"❌ XML parsing error: {e}")
        raise HTTPException(status_code=400, detail=f"Invalid XML format: {str(e)}")
    except Exception as e:
        print(f"❌ Error parsing UN XML: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to parse XML: {str(e)}")

def parse_individual_entry(individual_elem) -> Optional[Dict[str, Any]]:
    """Parse individual person entry from UN XML"""
    try:
        # Extract basic information
        dataid = individual_elem.get('DATAID', '')
        
        # Get names - first name + last name or full name
        first_names = []
        last_names = []
        
        for name in individual_elem.findall('.//INDIVIDUAL_NAME'):
            first_name = name.findtext('FIRST_NAME', '').strip()
            last_name = name.findtext('LAST_NAME', '').strip()
            if first_name:
                first_names.append(first_name)
            if last_name:
                last_names.append(last_name)
        
        # Construct entity name
        if first_names and last_names:
            entity_name = f"{' '.join(first_names)} {' '.join(last_names)}".strip()
        elif last_names:
            entity_name = ' '.join(last_names)
        elif first_names:
            entity_name = ' '.join(first_names)
        else:
            return None  # Skip if no name found
        
        # Get aliases
        aliases = []
        for alias in individual_elem.findall('.//INDIVIDUAL_ALIAS'):
            alias_name = alias.findtext('ALIAS_NAME', '').strip()
            if alias_name:
                aliases.append(alias_name)
        
        # Get date of birth
        date_of_birth = None
        dob_elem = individual_elem.find('.//INDIVIDUAL_DATE_OF_BIRTH')
        if dob_elem is not None:
            date_str = dob_elem.findtext('DATE', '')
            if date_str:
                try:
                    date_of_birth = datetime.strptime(date_str, '%Y-%m-%d').date()
                except ValueError:
                    pass
        
        # Get country information
        country = None
        country_elem = individual_elem.find('.//COUNTRY')
        if country_elem is not None:
            country = country_elem.text or country_elem.get('VALUE', '')
        
        # Get identification numbers
        identification_numbers = []
        for doc in individual_elem.findall('.//INDIVIDUAL_DOCUMENT'):
            doc_number = doc.findtext('NUMBER', '').strip()
            if doc_number:
                identification_numbers.append(doc_number)
        
        return {
            'list_name': 'UN Security Council Consolidated List',
            'entity_name': entity_name,
            'aliases': aliases,
            'entity_type': 'individual',
            'country': country,
            'date_of_birth': date_of_birth,  # Keep as Python date object
            'identification_numbers': identification_numbers,
            'sanctions_program': 'UN Security Council Sanctions',
            'listing_date': datetime.now().date(),  # Keep as Python date object
            'last_updated': datetime.now(),  # Keep as Python datetime object
            'is_active': True,
            'source_url': 'https://www.un.org/securitycouncil/sanctions/1267/aq_sanctions_list',
            'raw_data': f'Individual: {entity_name}'
        }
        
    except Exception as e:
        print(f"❌ Error parsing individual entry: {e}")
        return None

def parse_entity_entry(entity_elem) -> Optional[Dict[str, Any]]:
    """Parse entity/organization entry from UN XML"""
    try:
        # Extract basic information
        dataid = entity_elem.get('DATAID', '')
        
        # Get entity name
        entity_name = entity_elem.findtext('.//FIRST_NAME', '').strip()
        if not entity_name:
            entity_name = entity_elem.findtext('.//NAME', '').strip()
        if not entity_name:
            return None  # Skip if no name found
        
        # Get aliases
        aliases = []
        for alias in entity_elem.findall('.//ENTITY_ALIAS'):
            alias_name = alias.findtext('ALIAS_NAME', '').strip()
            if alias_name:
                aliases.append(alias_name)
        
        # Get country information
        country = None
        country_elem = entity_elem.find('.//COUNTRY')
        if country_elem is not None:
            country = country_elem.text or country_elem.get('VALUE', '')
        
        return {
            'list_name': 'UN Security Council Consolidated List',
            'entity_name': entity_name,
            'aliases': aliases,
            'entity_type': 'entity',
            'country': country,
            'dateof_birth': None,
            'identification_numbers': [],
            'sanctions_program': 'UN Security Council Sanctions',
            'listing_date': datetime.now().date(),  # Keep as Python date object
            'last_updated': datetime.now(),  # Keep as Python datetime object
            'is_active': True,
            'source_url': 'https://www.un.org/securitycouncil/sanctions/1267/aq_sanctions_list',
            'raw_data': json.dumps({'dataid': dataid, 'type': 'entity'})
        }
        
    except Exception as e:
        print(f"❌ Error parsing entity entry: {e}")
        return None

def parse_date_safely(date_string):
    """Safely parse date string to date object"""
    if not date_string or date_string == '':
        return None
    
    try:
        # Handle various date formats
        if isinstance(date_string, str):
            # Remove any extra whitespace
            date_string = date_string.strip()
            
            # Handle partial dates like '2006-18'
            if len(date_string) == 7 and '-' in date_string:
                year, day = date_string.split('-')
                # This seems to be a partial date, skip it
                return None
            
            # Handle standard date formats
            for fmt in ['%Y-%m-%d', '%d/%m/%Y', '%m/%d/%Y', '%Y']:
                try:
                    return datetime.strptime(date_string, fmt).date()
                except ValueError:
                    continue
            
            # If no format matches, return None
            return None
    except Exception:
        return None
    
    return date_string if hasattr(date_string, 'year') else None
