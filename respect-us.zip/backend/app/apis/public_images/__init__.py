from fastapi import APIRouter, HTTPException
from fastapi.responses import Response
import databutton as db
import re
from app.libs.storage_utils import sanitize_storage_key

router = APIRouter()

@router.get("/serve/{image_filename}")
async def serve_public_image(image_filename: str):
    """Serve uploaded images publicly (no authentication required)"""
    try:
        # Sanitize the filename
        safe_filename = re.sub(r'[^a-zA-Z0-9._-]', '_', image_filename)
        
        # Use sanitized storage key format (no forward slash)
        storage_key = sanitize_storage_key(f"images_{safe_filename}")
        
        print(f"Serving public image with storage key: {storage_key}")
        
        # Get image data from storage
        image_data = db.storage.binary.get(storage_key)
        
        if not image_data:
            print(f"Image not found with key: {storage_key}")
            raise HTTPException(status_code=404, detail="Image not found")
        
        # Determine content type based on file extension
        ext = safe_filename.lower().split('.')[-1] if '.' in safe_filename else 'jpg'
        content_type_map = {
            'jpg': 'image/jpeg',
            'jpeg': 'image/jpeg',
            'png': 'image/png',
            'gif': 'image/gif',
            'webp': 'image/webp'
        }
        content_type = content_type_map.get(ext, 'image/jpeg')
        
        return Response(content=image_data, media_type=content_type)
        
    except Exception as e:
        print(f"Error serving public image {image_filename}: {str(e)}")
        raise HTTPException(status_code=404, detail="Image not found")
