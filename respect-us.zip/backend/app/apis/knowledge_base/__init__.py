import json
import re
from datetime import datetime, date
import uuid
from typing import Optional, List, Dict, Any, Union
from pydantic import BaseModel, Field, ValidationError
from fastapi import APIRouter, HTTPException, Form, UploadFile, Query, Depends, File
from fastapi.responses import StreamingResponse
from app.auth import AuthorizedUser
import databutton as db
import asyncpg
from app.libs.text_extraction import TextExtractor
from app.libs.enhanced_document_parser import EnhancedDocumentParser
from app.libs.advanced_search import AdvancedSearchEngine, SearchFilter
from app.libs.performance_cache import performance_cache
from app.env import Mode, mode
import uuid
from io import BytesIO
from app.libs.credit_wrapper import consume_credits_for_action
from app.libs.storage_utils import sanitize_storage_key, sanitize_filename

router = APIRouter(prefix="/knowledge-base")

# Use a constant for the default file to avoid function call in argument defaults
DEFAULT_FILE = None

# Helper function to safely parse JSON fields
def safe_json_parse(field_value):
    """Convert JSON string or list to comma-separated string for DocumentResponse"""
    if field_value is None:
        return None
    if isinstance(field_value, str):
        try:
            parsed = json.loads(field_value)
            # Convert back to comma-separated string for DocumentResponse
            if isinstance(parsed, list):
                return ', '.join(parsed) if parsed else None
            return field_value
        except (json.JSONDecodeError, TypeError):
            return field_value
    elif isinstance(field_value, list):
        return ', '.join(field_value) if field_value else None
    return field_value

# Helper function to parse date strings
def parse_date_string(date_str: str) -> Optional[date]:
    """Parse various date string formats into date object"""
    if not date_str or date_str.strip() == '':
        return None
    
    # Common date formats
    formats = [
        '%Y-%m-%d',                   # Date only (ISO format)
        '%Y-%m-%dT%H:%M:%S',         # ISO datetime without timezone
        '%Y-%m-%dT%H:%M:%S.%f',      # ISO datetime with microseconds
        '%Y-%m-%dT%H:%M:%S%z',       # ISO datetime with timezone
        '%d/%m/%Y',                  # European format
        '%m/%d/%Y',                  # US format
        '%d %b %Y',                  # Day Month Year
        '%Y%m%d',                    # Compact format
    ]
    
    for fmt in formats:
        try:
            parsed_datetime = datetime.strptime(date_str.strip(), fmt)
            return parsed_datetime.date()  # Convert to date object
        except ValueError:
            continue
    
    print(f"Warning: Could not parse date string: {date_str}")
    return None

# Pydantic models
class DocumentMetadata(BaseModel):
    title: str
    description: Optional[str] = None
    country_jurisdiction: Union[str, List[str]] = []
    regulation_type: Union[str, List[str]] = []
    subject: Union[str, List[str], None] = None
    source_url: Optional[str] = None
    publication_date: Optional[str] = None
    effective_date: Optional[str] = None
    abrogation_date: Optional[str] = None
    legal_status: str = "in_force"
    tags: Optional[str] = None
    issuing_authority: Optional[str] = None
    document_url: Optional[str] = None
    version: str = "1.0"
    badge: Union[str, List[str], None] = None  # Support multi-selection for badges
    category_ids: Optional[List[int]] = []
    # New field for sections preference
    create_sections: Optional[bool] = True
    
    # Pricing fields
    is_premium: Optional[bool] = False
    credit_cost: Optional[int] = None
    
    # Enhanced metadata fields
    classification_level: Optional[str] = "public"
    security_markings: Optional[List[str]] = []
    access_control_list: Optional[List[str]] = []
    retention_period_months: Optional[int] = None
    document_type: Optional[str] = "regulation"
    compliance_framework: Optional[str] = None
    product_category: Optional[str] = None
    geographic_scope: Optional[List[str]] = []
    expiration_date: Optional[str] = None
    approval_chain: Optional[List[str]] = []
    version_major: Optional[int] = 1
    version_minor: Optional[int] = 0
    review_schedule: Optional[str] = None
    next_review_date: Optional[str] = None
    document_owner: Optional[str] = None
    sme_reviewers: Optional[List[str]] = []
    training_required: Optional[bool] = False
    adoption_date: Optional[str] = None

# Response models
class DocumentResponse(BaseModel):
    id: int
    title: str
    description: Optional[str] = None
    content_text: Optional[str] = None
    file_name: Optional[str] = None
    file_path: Optional[str] = None
    file_size: Optional[int] = None
    file_type: Optional[str] = None
    country_jurisdiction: Optional[str] = None
    regulation_type: Optional[str] = None
    subject: Optional[str] = None
    publishing_status: str = "draft"
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    created_by: Optional[str] = None
    updated_by: Optional[str] = None
    
    # Blog-specific fields
    author: Optional[str] = None
    reading_time: Optional[int] = None  # Reading time in minutes
    featured_status: Optional[bool] = False
    article_type: Optional[str] = None  # 'blog', 'regulation', 'guidance', etc.
    publication_date: Optional[datetime] = None
    excerpt: Optional[str] = None  # Short summary for blog cards
    thumbnail_url: Optional[str] = None
    attached_documents: Optional[List[Dict[str, Any]]] = []  # Array of attached document objects
    category: Optional[str] = None  # Blog category
    view_count: Optional[int] = 0
    likes_count: Optional[int] = 0
    is_blog_article: Optional[bool] = False  # Added field to identify blog articles

# Database connection
async def get_db_connection():
    """Get database connection based on environment"""
    if mode == Mode.PROD:
        database_url = db.secrets.get("DATABASE_URL_PROD")
    else:
        database_url = db.secrets.get("DATABASE_URL_DEV")
    return await asyncpg.connect(database_url)

# Add request models for the new endpoints
class DocumentSearchRequest(BaseModel):
    query: Optional[str] = None
    category_id: Optional[int] = None
    country_jurisdiction: Optional[str] = None
    regulation_type: Optional[str] = None
    legal_status: Optional[str] = None
    publishing_status: Optional[str] = None
    status: Optional[str] = None  # Alias for publishing_status
    tags: Optional[List[str]] = None
    search_fields: Optional[List[str]] = None
    # New Boolean search capabilities
    boolean_query: Optional[str] = None  # Raw Boolean query like "export AND control NOT sanctions"
    phrase_query: Optional[str] = None   # Exact phrase search
    wildcard_query: Optional[str] = None # Wildcard search like "export*"
    fuzzy_query: Optional[str] = None    # Fuzzy search with tolerance
    search_mode: Optional[str] = "simple"  # "simple", "boolean", "phrase", "wildcard", "fuzzy"
    date_from: Optional[str] = None      # Filter by date range
    date_to: Optional[str] = None
    limit: int = 50
    offset: int = 0

class DocumentListRequest(BaseModel):
    status: Optional[str] = None
    country_jurisdiction: Optional[str] = None
    regulation_type: Optional[str] = None
    limit: int = 50
    offset: int = 0

class DocumentSearchResponse(BaseModel):
    documents: List[DocumentResponse]
    total_count: int
    has_more: bool
    query_info: Optional[dict] = None

class DocumentListResponse(BaseModel):
    documents: List[DocumentResponse]
    total_count: int
    has_more: bool

class AdvancedSearchRequest(BaseModel):
    query: str = Field(default="", description="Search query with Boolean operators (AND, OR, NOT)")
    filters: Optional[List[Dict[str, Any]]] = Field(default=None, description="Advanced filters")
    search_sections: bool = Field(default=False, description="Search within document sections")
    sort_by: str = Field(default="relevance", description="Sort by: relevance, date, title")
    limit: int = Field(default=50, le=100)
    offset: int = Field(default=0)

class AdvancedSearchResponse(BaseModel):
    documents: List[Dict[str, Any]]
    sections: List[Dict[str, Any]] = []
    total_count: int
    has_more: bool
    search_terms: List[Dict[str, Any]] = []
    filters_applied: List[Dict[str, Any]] = []
    error: Optional[str] = None

# Helper function to build document response
def build_document_response(row: dict) -> DocumentResponse:
    """Build DocumentResponse from database row"""
    
    # Parse attached_documents from metadata or direct field
    attached_documents = []
    if row.get('attached_documents'):
        if isinstance(row['attached_documents'], str):
            try:
                import json
                attached_documents = json.loads(row['attached_documents'])
            except (json.JSONDecodeError, TypeError):
                attached_documents = []
        elif isinstance(row['attached_documents'], list):
            attached_documents = row['attached_documents']
    
    # Parse thumbnail_url and other metadata if needed
    thumbnail_url = None
    if row.get('metadata'):
        try:
            import json
            metadata_json = json.loads(row['metadata'])
            thumbnail_url = metadata_json.get('thumbnail_url')
            if not attached_documents:  # Only use metadata if not already set
                attached_documents = metadata_json.get('attached_documents', [])
        except (json.JSONDecodeError, TypeError):
            pass
    
    return DocumentResponse(
        id=row['id'],
        title=row['title'],
        description=row['description'],
        content_text=row.get('content_text'),
        file_name=row.get('file_name'),
        file_path=None,  # Not used
        file_size=row.get('file_size'),
        file_type=row.get('file_type'),
        country_jurisdiction=safe_json_parse(row.get('country_jurisdiction')),
        regulation_type=safe_json_parse(row.get('regulation_type')),
        subject=safe_json_parse(row.get('subject')),
        publishing_status=row.get('publishing_status', 'draft'),
        created_at=row.get('created_at'),
        updated_at=row.get('updated_at'),
        created_by=row.get('uploaded_by'),
        updated_by=row.get('uploaded_by'),
        is_blog_article=row.get('is_blog_article', False),
        attached_documents=attached_documents,
        thumbnail_url=thumbnail_url,
        # Add default values for blog fields
        author=row.get('author'),
        reading_time=row.get('reading_time'),
        featured_status=row.get('featured_status', False),
        article_type=row.get('article_type'),
        publication_date=row.get('publication_date'),
        excerpt=row.get('excerpt'),
        category=row.get('category'),
        view_count=row.get('view_count', 0),
        likes_count=row.get('likes_count', 0)
    )

# Helper function to parse Boolean queries
def parse_boolean_query(boolean_query: str, search_fields: List[str] = None) -> tuple:
    """
    Parse Boolean query and convert to SQL conditions
    Returns: (conditions_list, params_list)
    """
    if not boolean_query or not boolean_query.strip():
        return [], []
    
    # Default search fields if not specified
    if not search_fields:
        search_fields = ['title', 'description', 'content_text']
    
    # Simple Boolean parsing (can be enhanced further)
    conditions = []
    params = []
    
    # Split by Boolean operators (keeping operators)
    import re
    tokens = re.split(r'\s+(AND|OR|NOT)\s+', boolean_query.strip(), flags=re.IGNORECASE)
    
    if len(tokens) == 1:
        # Single term, treat as regular search
        term = tokens[0].strip().strip('"')
        if term:
            field_conditions = []
            for field in search_fields:
                field_conditions.append(f"d.{field} ILIKE %s")
                params.append(f"%{term}%")
            conditions.append(f"({' OR '.join(field_conditions)})")
    else:
        # Multiple terms with operators
        i = 0
        while i < len(tokens):
            term = tokens[i].strip().strip('"')
            if term and term.upper() not in ['AND', 'OR', 'NOT']:
                field_conditions = []
                for field in search_fields:
                    field_conditions.append(f"d.{field} ILIKE %s")
                    params.append(f"%{term}%")
                
                term_condition = f"({' OR '.join(field_conditions)})"
                
                # Check for NOT operator before this term
                if i > 0 and tokens[i-1].upper() == 'NOT':
                    term_condition = f"NOT {term_condition}"
                
                conditions.append(term_condition)
            i += 1
    
    return conditions, params

# Helper function for phrase search
def build_phrase_search(phrase: str, search_fields: List[str] = None) -> tuple:
    """
    Build exact phrase search conditions
    """
    if not phrase or not phrase.strip():
        return [], []
    
    if not search_fields:
        search_fields = ['title', 'description', 'content_text']
    
    conditions = []
    params = []
    
    # Clean phrase
    clean_phrase = phrase.strip().strip('"')
    
    # Build ILIKE conditions for exact phrase
    field_conditions = []
    for field in search_fields:
        field_conditions.append(f"d.{field} ILIKE %s")
        params.append(f"%{clean_phrase}%")
    
    conditions.append(f"({' OR '.join(field_conditions)})")
    return conditions, params

# Helper function for wildcard search
def build_wildcard_search(wildcard: str, search_fields: List[str] = None) -> tuple:
    """
    Build wildcard search conditions
    """
    if not wildcard or not wildcard.strip():
        return [], []
    
    if not search_fields:
        search_fields = ['title', 'description', 'content_text']
    
    conditions = []
    params = []
    
    # Convert wildcard to SQL LIKE pattern
    pattern = wildcard.strip().replace('*', '%').replace('?', '_')
    
    field_conditions = []
    for field in search_fields:
        field_conditions.append(f"d.{field} ILIKE %s")
        params.append(pattern)
    
    conditions.append(f"({' OR '.join(field_conditions)})")
    return conditions, params

# Endpoints
@router.get("/health")
async def knowledge_base_health():
    """Health check endpoint"""
    return {"status": "healthy", "service": "knowledge_base"}

@router.post("/documents", response_model=DocumentResponse)
@consume_credits_for_action("knowledge_base", "document_upload")
async def upload_document(
    user: AuthorizedUser,
    file: Optional[UploadFile] = DEFAULT_FILE,
    metadata: str = Form(...)
):
    """Upload a new document to the knowledge base"""
    try:
        print(f"Received upload request with metadata: {metadata}")
        
        # Parse metadata JSON
        doc_metadata = DocumentMetadata.parse_raw(metadata);
        
        conn = await get_db_connection()
        try:
            file_content = None
            storage_key = None
            content_text = ""
            extraction_method = "none"
            extraction_metadata = {}
            
            # Handle file upload if provided
            if file:
                # Read file content
                file_content = await file.read()
                
                # Sanitize filename for storage key
                safe_filename = re.sub(r'[^a-zA-Z0-9._-]', '_', file.filename or 'document')
                timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
                file_ext = safe_filename.split('.')[-1] if '.' in safe_filename else 'pdf'
                storage_key = f"doc_{timestamp}.{file_ext}"
                
                try:
                    db.storage.binary.put(storage_key, file_content)
                    print(f"Stored file in storage with key: {storage_key}")
                except Exception as e:
                    print(f"Warning: Failed to store file: {e}")
                    storage_key = None
                
                # Extract text from file
                try:
                    if len(file_content) < 5 * 1024 * 1024:  # Less than 5MB
                        extraction_result = TextExtractor.extract_text_from_file(file, file_content)
                        content_text = extraction_result.get("content_text", "")
                        extraction_method = extraction_result.get("extraction_method", "none")
                        
                        if extraction_result.get("success") and content_text:
                            extraction_metadata = TextExtractor.extract_metadata_from_text(content_text)
                    else:
                        extraction_method = "skipped_large_file"
                except Exception as e:
                    print(f"Text extraction failed: {e}")
                    extraction_method = "failed"
            
            # Convert empty date strings to None and parse valid dates
            def parse_date_string(date_str):
                if not date_str or not date_str.strip():
                    return None
                try:
                    # Parse ISO format date string to date object
                    return datetime.strptime(date_str.strip(), '%Y-%m-%d').date()
                except ValueError:
                    try:
                        # Try alternative format
                        return datetime.strptime(date_str.strip(), '%Y/%m/%d').date()
                    except ValueError:
                        print(f"Warning: Could not parse date '{date_str}', setting to None")
                        return None
            
            pub_date = parse_date_string(doc_metadata.publication_date)
            eff_date = parse_date_string(doc_metadata.effective_date)
            exp_date = parse_date_string(doc_metadata.expiration_date)
            adoption_date = parse_date_string(doc_metadata.adoption_date)
            next_review = parse_date_string(doc_metadata.next_review_date)
            
            # Convert tags string to array
            tags_array = []
            if doc_metadata.tags and doc_metadata.tags.strip():
                tags_array = [tag.strip() for tag in doc_metadata.tags.split(',') if tag.strip()]
            
            # Prepare metadata for blog articles
            blog_metadata = {}
            if hasattr(doc_metadata, 'thumbnail_url') and doc_metadata.thumbnail_url:
                blog_metadata['thumbnail_url'] = doc_metadata.thumbnail_url
                print(f"💾 Adding thumbnail_url to metadata: {doc_metadata.thumbnail_url}")
            
            if hasattr(doc_metadata, 'attached_documents') and doc_metadata.attached_documents:
                blog_metadata['attached_documents'] = doc_metadata.attached_documents
                print(f"💾 Adding attached_documents to metadata: {len(doc_metadata.attached_documents)} documents")
            
            # Add other blog-specific metadata fields if present
            for field in ['publication_date', 'reading_time', 'category', 'excerpt', 'featured']:
                if hasattr(doc_metadata, field) and getattr(doc_metadata, field) is not None:
                    blog_metadata[field] = getattr(doc_metadata, field)
            
            metadata_json = json.dumps(blog_metadata) if blog_metadata else None
            print(f"💾 Prepared metadata JSON for creation: {blog_metadata}")
            
            # Insert document into database
            document_id = await conn.fetchval(
                """
                INSERT INTO kb_documents (
                    title, description, country_jurisdiction, regulation_type, subject,
                    source_url, issuing_authority, publication_date, effective_date,
                    adoption_date, legal_status, file_name, file_size, file_type, content_text, tags,
                    uploaded_by, extraction_method, extraction_metadata, version,
                    file_storage_key, classification_level, security_markings,
                    access_control_list, retention_period_months, document_type,
                    compliance_framework, product_category, geographic_scope,
                    expiration_date, approval_chain, version_major, version_minor,
                    review_schedule, next_review_date, document_owner, sme_reviewers,
                    training_required, is_premium, credit_cost, document_source_type,
                    publishing_status, is_blog_article, metadata
                ) VALUES (
                    $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17,
                    $18, $19, $20, $21, $22, $23, $24, $25, $26, $27, $28, $29, $30, $31, $32,
                    $33, $34, $35, $36, $37, $38, $39, $40, 'file', 'draft', $41, $42
                ) RETURNING id
                """,
                doc_metadata.title, doc_metadata.description,
                doc_metadata.country_jurisdiction if isinstance(doc_metadata.country_jurisdiction, list) else [doc_metadata.country_jurisdiction] if doc_metadata.country_jurisdiction else [],
                doc_metadata.regulation_type if isinstance(doc_metadata.regulation_type, list) else [doc_metadata.regulation_type] if doc_metadata.regulation_type else [],
                doc_metadata.subject if isinstance(doc_metadata.subject, list) else [doc_metadata.subject] if doc_metadata.subject else [],
                doc_metadata.source_url, doc_metadata.issuing_authority, pub_date, eff_date,
                adoption_date, doc_metadata.legal_status, safe_filename if file else None,
                len(file_content) if file_content else None, file.content_type if file else None,
                content_text, tags_array, user.sub, extraction_method,
                json.dumps(extraction_metadata), doc_metadata.version, storage_key,
                doc_metadata.classification_level, doc_metadata.security_markings or [],
                json.dumps(doc_metadata.access_control_list or []), doc_metadata.retention_period_months,
                doc_metadata.document_type, doc_metadata.compliance_framework,
                doc_metadata.product_category, doc_metadata.geographic_scope or [], exp_date,
                json.dumps(doc_metadata.approval_chain or []), doc_metadata.version_major,
                doc_metadata.version_minor, doc_metadata.review_schedule, next_review,
                doc_metadata.document_owner, doc_metadata.sme_reviewers or [],
                doc_metadata.training_required, doc_metadata.is_premium, doc_metadata.credit_cost,
                doc_metadata.document_type == 'blog',  # Set is_blog_article to True when document_type is 'blog'
                metadata_json  # Add the metadata JSON
            )
            
            # Enhanced document section parsing and creation
            if doc_metadata.create_sections and content_text and content_text.strip():
                try:
                    print(f"Starting enhanced document parsing for document {document_id}")
                    parser = EnhancedDocumentParser()
                    
                    # Parse document into hierarchical sections
                    hierarchical_sections = parser.parse_document(content_text, doc_metadata.title)
                    
                    if hierarchical_sections:
                        print(f"Found {len(hierarchical_sections)} top-level sections")
                        
                        # Flatten sections for database storage
                        flattened_sections = parser.flatten_sections(hierarchical_sections)
                        
                        print(f"Flattened to {len(flattened_sections)} sections for database")
                        
                        # Insert sections into database
                        for section_data in flattened_sections:
                            await conn.execute(
                                """
                                INSERT INTO kb_document_sections (
                                    document_id, section_number, section_title, section_content,
                                    section_type, level, parent_section_id, display_order,
                                    cross_references, regulatory_references, definitions, keywords
                                ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
                                """,
                                document_id,
                                section_data['section_number'],
                                section_data['section_title'],
                                section_data['section_content'],
                                section_data.get('section_type', 'section'),
                                section_data.get('level', 1),
                                section_data.get('parent_section_id'),
                                section_data['display_order'],
                                section_data.get('cross_references', '[]'),
                                section_data.get('regulatory_references', '[]'),
                                section_data.get('definitions', '[]'),
                                section_data.get('keywords', '[]')
                            )
                        
                        # Extract and store table of contents
                        toc = parser.extract_table_of_contents(hierarchical_sections)
                        
                        # Update document with table of contents
                        await conn.execute(
                            "UPDATE kb_documents SET table_of_contents = $1 WHERE id = $2",
                            json.dumps(toc), document_id
                        )
                        
                        print(f"Successfully created {len(flattened_sections)} sections with enhanced parsing")
                    else:
                        print("No sections detected by enhanced parser, falling back to basic sectioning")
                        # Fallback to basic text sectioning if enhanced parsing fails
                        basic_sections = TextExtractor.create_document_sections(content_text, document_id)
                        
                        for section_data in basic_sections:
                            await conn.execute(
                                """
                                INSERT INTO kb_document_sections (
                                    document_id, section_number, section_title, section_content, display_order
                                ) VALUES ($1, $2, $3, $4, $5)
                                """,
                                document_id,
                                section_data['section_number'],
                                section_data['section_title'],
                                section_data['section_content'],
                                section_data['display_order']
                            )
                        
                        print(f"Created {len(basic_sections)} basic sections as fallback")
                        
                except Exception as section_error:
                    print(f"Error during section parsing: {section_error}")
                    # Continue without sections rather than failing the upload
                    pass
            else:
                print(f"Section creation skipped: create_sections={doc_metadata.create_sections}, content_length={len(content_text) if content_text else 0}")
            
            # Fetch the created document to return
            created_doc = await conn.fetchrow(
                """
                SELECT d.*, 
                       (SELECT COUNT(*) FROM kb_document_sections WHERE document_id = d.id) as section_count
                FROM kb_documents d
                WHERE d.id = $1
                """,
                document_id
            )
            
            return DocumentResponse(
                id=created_doc['id'],
                title=created_doc['title'],
                description=created_doc['description'],
                country_jurisdiction=safe_json_parse(created_doc.get('country_jurisdiction')),
                regulation_type=safe_json_parse(created_doc.get('regulation_type')),
                subject=safe_json_parse(created_doc.get('subject')),
                issuing_authority=created_doc['issuing_authority'],
                publication_date=created_doc['publication_date'],
                effective_date=created_doc['effective_date'],
                legal_status=created_doc['legal_status'],
                file_name=created_doc['file_name'],
                file_size=created_doc['file_size'],
                file_type=created_doc['file_type'],
                tags=safe_json_parse(created_doc.get('tags', [])),
                uploaded_by=created_doc.get('uploaded_by'),
                created_at=created_doc['created_at'],
                updated_at=created_doc['updated_at'],
                content_html=created_doc.get('content_html'),
                content_text=created_doc.get('content_text'),
                document_source_type=created_doc.get('document_source_type'),
                extraction_metadata=created_doc.get('extraction_metadata'),
                version=created_doc.get('version', '1.0'),
                published_at=created_doc.get('published_at'),
                published_by=created_doc.get('published_by'),
                publishing_status=created_doc.get('publishing_status', 'draft'),
                section_count=created_doc.get('section_count', 0),
                is_blog_article=created_doc.get('is_blog_article', False)
            )
            
        except HTTPException:
            raise
        except Exception as e:
            print(f"Error uploading document: {e}")
            raise HTTPException(status_code=500, detail=f"Failed to upload document: {str(e)}")
        finally:
            await conn.close()
            
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error uploading document: {e}");
        raise HTTPException(status_code=500, detail=f"Failed to upload document: {str(e)}")

@router.put("/documents/{document_id}")
async def update_document(document_id: int, user: AuthorizedUser, metadata: str = Form(...), file: UploadFile | None = File(None)):
    """
    Update a document
    """
    print(f"📝 Updating document {document_id}")
    print(f"📄 File provided: {file.filename if file else 'None'}")
    print(f"🔍 Raw metadata received: {repr(metadata)}")
    print(f"🔍 Metadata type: {type(metadata)}")
    
    try:
        # Parse the metadata
        parsed_metadata = json.loads(metadata)
        print(f"📊 Parsed metadata: {parsed_metadata}")
        print(f"✅ Metadata parsing successful")
        
        # Validate required fields
        if "title" not in parsed_metadata or not parsed_metadata["title"]:
            print(f"❌ Missing required field: title")
            raise HTTPException(status_code=400, detail="Title is required")
            
        print(f"✅ Title validation passed: {parsed_metadata['title']}")
        
    except json.JSONDecodeError as e:
        print(f"❌ JSON decode error: {str(e)}")
        raise HTTPException(status_code=400, detail=f"Invalid JSON metadata: {str(e)}")
    except Exception as e:
        print(f"❌ Metadata validation error: {str(e)}")
        print(f"📊 Error type: {type(e)}")
        raise HTTPException(status_code=400, detail=f"Metadata validation failed: {str(e)}")
    
    try:
        # Get database connection
        database_url = db.secrets.get("DATABASE_URL_DEV")
        print(f"🔗 Connecting to database...")
        
        conn = await asyncpg.connect(database_url)
        print(f"✅ Database connection established")
        
        try:
            # Check if document exists and belongs to user
            print(f"🔍 Checking document ownership...")
            document_check = await conn.fetchrow(
                "SELECT id, title FROM kb_documents WHERE id = $1",
                document_id
            )
            
            if not document_check:
                print(f"❌ Document {document_id} not found")
                raise HTTPException(status_code=404, detail="Document not found")
                
            print(f"✅ Document found: {document_check['title']}")
            
            # Build update fields - start with basic metadata
            update_fields = {
                "title": parsed_metadata.get("title"),
                "description": parsed_metadata.get("description"),
                "uploaded_by": parsed_metadata.get("author"),  # Map author to uploaded_by
                "updated_at": datetime.now()
            }
            print(f"📝 Basic update fields prepared: {list(update_fields.keys())}")
            
            # Extract and prepare metadata JSON for blog articles
            blog_metadata = {}
            if parsed_metadata.get("thumbnail_url"):
                blog_metadata["thumbnail_url"] = parsed_metadata["thumbnail_url"]
                print(f"💾 Adding thumbnail_url to metadata: {parsed_metadata['thumbnail_url']}")
            
            if parsed_metadata.get("attached_documents"):
                blog_metadata["attached_documents"] = parsed_metadata["attached_documents"]
                print(f"💾 Adding attached_documents to metadata: {len(parsed_metadata['attached_documents'])} documents")
            
            # Add other blog-specific metadata fields
            for field in ["publication_date", "reading_time", "category", "excerpt", "featured"]:
                if parsed_metadata.get(field) is not None:
                    blog_metadata[field] = parsed_metadata[field]
            
            # Store metadata as JSON if we have any blog metadata
            if blog_metadata:
                update_fields["metadata"] = json.dumps(blog_metadata)
                print(f"💾 Prepared metadata JSON: {blog_metadata}")
            
            # Process file upload if provided
            if file and file.filename:
                print(f"📁 Processing file upload: {file.filename}")
                try:
                    # Read file content
                    file_content = await file.read()
                    print(f"📄 File content read: {len(file_content)} bytes")
                    
                    # Sanitize filename and create storage key
                    safe_filename = sanitize_filename(file.filename, default_name="document", default_ext="md")
                    storage_key = sanitize_storage_key(f"documents/{document_id}/{safe_filename}")
                    print(f"💾 Storing with key: {storage_key}")
                    
                    db.storage.binary.put(storage_key, file_content)
                    print(f"✅ File stored successfully")
                    
                    file_updates = {
                        "file_name": safe_filename,
                        "file_size": len(file_content),
                        "file_type": file.content_type or "application/octet-stream",
                        "file_storage_key": storage_key,
                        "original_format": file.content_type or "application/octet-stream"
                    }
                    update_fields.update(file_updates)
                    print(f"✅ File metadata added to update fields")
                    
                except Exception as file_error:
                    print(f"❌ File processing error: {str(file_error)}")
                    print(f"📊 File error type: {type(file_error)}")
                    # Continue without file update
                    pass
            else:
                print(f"📁 No file provided for update")
            
            # Build SQL update query
            set_clauses = []
            params = []
            param_count = 1
            
            for field, value in update_fields.items():
                if value is not None:
                    set_clauses.append(f"{field} = ${param_count}")
                    params.append(value)
                    param_count += 1
            
            if not set_clauses:
                print(f"❌ No fields to update")
                raise HTTPException(status_code=400, detail="No valid fields to update")
            
            params.append(document_id)
            update_query = f"""
                UPDATE kb_documents 
                SET {', '.join(set_clauses)}
                WHERE id = ${param_count}
                RETURNING id, title, description
            """
            
            print(f"🔄 Executing update query with {len(params)} parameters")
            print(f"📝 Set clauses: {set_clauses}")
            
            # Execute update
            updated_doc = await conn.fetchrow(update_query, *params)
            print(f"✅ Document updated successfully: {updated_doc['title']}")
            
            # Return success response
            response_data = {
                "message": "Document updated successfully",
                "document_id": document_id,
                "title": updated_doc["title"]
            }
            print(f"📤 Returning success response: {response_data}")
            return response_data
            
        finally:
            await conn.close()
            print(f"🔗 Database connection closed")
            
    except HTTPException:
        print(f"📤 Re-raising HTTP exception")
        raise
    except Exception as e:
        print(f"❌ Error updating document: {str(e)}")
        print(f"📊 Error type: {type(e)}")
        import traceback
        print(f"🔍 Full traceback: {traceback.format_exc()}")
        raise HTTPException(
            status_code=500,
            detail=f"Error updating document: {str(e)}"
        )

@router.get("/metadata-options")
async def get_knowledge_base_metadata_options():
    """Get all available metadata options for document upload forms"""
    try:
        conn = await get_db_connection()
        try:
            # Fetch all metadata options grouped by category
            query = """
                SELECT category, value, display_name, display_order
                FROM document_metadata_options 
                WHERE is_active = true 
                ORDER BY category, display_order, display_name
            """
            
            rows = await conn.fetch(query)
            
            # Group options by category
            options = {}
            for row in rows:
                category = row['category']
                if category not in options:
                    options[category] = []
                options[category].append({
                    "value": row['value'],
                    "display_name": row['display_name'],
                    "display_order": row['display_order']
                })
            
            return options
            
        finally:
            await conn.close()
            
    except Exception as e:
        print(f"Error fetching metadata options: {e}")
        raise HTTPException(status_code=500, detail="Failed to fetch metadata options")

@router.get("/documents/{document_id}", response_model=DocumentResponse)
async def get_document(document_id: int, user: AuthorizedUser):
    """
    Get a single document by ID for editing
    """
    conn = await get_db_connection()
    try:
        query = """
            SELECT id, title, description, content_text, file_name,
                   file_name as file_path, file_size, file_type, 
                   regulation_type as document_type, 
                   country_jurisdiction, issuing_authority,
                   effective_date, expiration_date, legal_status, 
                   version, tags, created_at, updated_at, uploaded_by, publishing_status,
                   is_blog_article, subject, metadata
            FROM kb_documents 
            WHERE id = $1
        """
        
        row = await conn.fetchrow(query, document_id)
        
        if not row:
            raise HTTPException(status_code=404, detail="Document not found")
        
        # Safely extract first element from arrays or use None
        def safe_array_first(arr):
            return arr[0] if arr and len(arr) > 0 else None
        
        # Extract metadata fields
        thumbnail_url = None
        attached_documents = []
        
        if row['metadata']:
            try:
                import json
                metadata_json = json.loads(row['metadata'])
                thumbnail_url = metadata_json.get('thumbnail_url')
                attached_documents = metadata_json.get('attached_documents', [])
            except (json.JSONDecodeError, TypeError):
                # If metadata parsing fails, use defaults
                pass
        
        return DocumentResponse(
            id=row['id'],
            title=row['title'],
            description=row['description'],
            content_text=row['content_text'],
            file_name=row['file_name'],
            file_path=row['file_path'],
            file_size=row['file_size'],
            file_type=row['file_type'],
            country_jurisdiction=safe_array_first(row['country_jurisdiction']),
            regulation_type=safe_array_first(row['document_type']),
            subject=safe_array_first(row['subject']),
            publishing_status=row['publishing_status'],
            created_at=row['created_at'],
            updated_at=row['updated_at'],
            created_by=row['uploaded_by'],
            updated_by=row['uploaded_by'],
            is_blog_article=row.get('is_blog_article', False),
            thumbnail_url=thumbnail_url,
            attached_documents=attached_documents
        )
        
    finally:
        await conn.close()

@router.post("/search", response_model=DocumentSearchResponse)
@consume_credits_for_action("knowledge_base", "document_search")
async def search_documents(
    request: DocumentSearchRequest,
    user: AuthorizedUser
):
    """Search documents with filters, full-text search, and pagination"""
    conn = await get_db_connection()
    try:
        # Build base query
        base_query = """
            SELECT d.id, d.title, d.description, d.content_text, d.file_name, 
                   d.file_size, d.file_type, d.country_jurisdiction, d.regulation_type,
                   d.subject, d.publishing_status, d.created_at, d.updated_at, d.uploaded_by,
                   d.is_blog_article,
                   COALESCE(d.metadata->>'thumbnail_url', '') as thumbnail_url,
                   COALESCE(d.metadata->'attached_documents', '[]'::jsonb) as attached_documents
            FROM kb_documents d
        """
        
        # Build WHERE conditions - filter for blog articles only
        conditions = ["d.is_blog_article = true"]
        params = []
        param_count = 0
        
        # Enhanced search based on mode
        search_conditions = []
        search_params = []
        
        if request.search_mode == "boolean" and request.boolean_query:
            # Boolean search with AND/OR/NOT operators
            bool_conditions, bool_params = parse_boolean_query(
                request.boolean_query, 
                request.search_fields or ['title', 'description', 'content_text']
            )
            search_conditions.extend(bool_conditions)
            search_params.extend(bool_params)
            
        elif request.search_mode == "phrase" and request.phrase_query:
            # Exact phrase search
            phrase_conditions, phrase_params = build_phrase_search(
                request.phrase_query,
                request.search_fields or ['title', 'description', 'content_text']
            )
            search_conditions.extend(phrase_conditions)
            search_params.extend(phrase_params)
            
        elif request.search_mode == "wildcard" and request.wildcard_query:
            # Wildcard search
            wildcard_conditions, wildcard_params = build_wildcard_search(
                request.wildcard_query,
                request.search_fields or ['title', 'description', 'content_text']
            )
            search_conditions.extend(wildcard_conditions)
            search_params.extend(wildcard_params)
            
        elif request.query and request.query.strip():
            # Default simple search
            search_term = f"%{request.query.strip()}%"
            search_fields = request.search_fields or ['title', 'description', 'content_text']
            field_conditions = []
            for field in search_fields:
                field_conditions.append(f"d.{field} ILIKE %s")
                search_params.append(search_term)
            search_conditions.append(f"({' OR '.join(field_conditions)})")
        
        # Add search conditions to main conditions
        if search_conditions:
            # Update parameter placeholders
            for condition in search_conditions:
                # Replace %s with proper parameter numbers
                while '%s' in condition:
                    param_count += 1
                    condition = condition.replace('%s', f'${param_count}', 1)
                conditions.append(condition)
            params.extend(search_params)
        
        # Status filtering
        if request.status:
            status_filter = request.status
        else:
            status_filter = "published"
        
        if status_filter:
            param_count += 1
            conditions.append(f"d.publishing_status = ${param_count}")
            params.append(status_filter)
        
        # Date range filtering
        if request.date_from:
            param_count += 1
            conditions.append(f"d.created_at >= ${param_count}")
            params.append(request.date_from)
            
        if request.date_to:
            param_count += 1
            conditions.append(f"d.created_at <= ${param_count}")
            params.append(request.date_to)
        
        # Category filtering (would need to join with categories if implemented)
        if request.category_id:
            # For now, skip category filtering as it's not in current schema
            pass
        
        # Country jurisdiction filtering
        if request.country_jurisdiction:
            param_count += 1
            conditions.append(f"${param_count} = ANY(country_jurisdiction)")
            params.append(request.country_jurisdiction)
        
        # Regulation type filtering
        if request.regulation_type:
            param_count += 1
            conditions.append(f"${param_count} = ANY(regulation_type)")
            params.append(request.regulation_type)
        
        # Legal status filtering
        if request.legal_status:
            param_count += 1
            conditions.append(f"d.legal_status = ${param_count}")
            params.append(request.legal_status)
        
        # Tags filtering
        if request.tags:
            for tag in request.tags:
                param_count += 1
                conditions.append(f"${param_count} = ANY(tags)")
                params.append(tag)
        
        # Build final query
        if conditions:
            base_query += " WHERE " + " AND ".join(conditions)
        
        # Add ordering
        base_query += " ORDER BY d.updated_at DESC, d.created_at DESC"
        
        # Count query - simplified to avoid column issues
        count_query = f"SELECT COUNT(*) FROM kb_documents d{base_query[base_query.find('WHERE'):]}"
        total_count = await conn.fetchval(count_query, *params)
        
        # Add pagination
        param_count += 1
        base_query += f" LIMIT ${param_count}"
        params.append(request.limit)
        
        param_count += 1
        base_query += f" OFFSET ${param_count}"
        params.append(request.offset)
        
        # Execute search
        rows = await conn.fetch(base_query, *params)
        
        # Build response with proper attached_documents handling
        documents = []
        for row in rows:
            row_dict = dict(row)
            
            # Handle attached_documents parsing
            attached_documents = []
            try:
                if row_dict.get('metadata'):
                    metadata = row_dict['metadata']
                    if isinstance(metadata, str):
                        metadata = json.loads(metadata)
                    
                    attached_docs = metadata.get('attached_documents', [])
                    if isinstance(attached_docs, str):
                        attached_documents = json.loads(attached_docs)
                    elif isinstance(attached_docs, list):
                        attached_documents = attached_docs
            except (json.JSONDecodeError, TypeError) as e:
                print(f"Error parsing attached_documents: {e}")
                attached_documents = []
            
            row_dict['attached_documents'] = attached_documents
            documents.append(build_document_response(row_dict))
        
        has_more = (request.offset + len(documents)) < total_count
        
        return DocumentSearchResponse(
            documents=documents,
            total_count=total_count,
            has_more=has_more,
            query_info={
                "query": request.query,
                "search_mode": request.search_mode,
                "filters_applied": {
                    "status": status_filter,
                    "country_jurisdiction": request.country_jurisdiction,
                    "regulation_type": request.regulation_type,
                    "legal_status": request.legal_status,
                    "tags": request.tags,
                    "date_from": request.date_from,
                    "date_to": request.date_to
                },
                "results_count": len(documents)
            }
        )
        
    finally:
        await conn.close()

@router.get("/documents")
async def list_documents(
    user: AuthorizedUser,
    page: int = Query(1, ge=1),
    per_page: int = Query(20, ge=1, le=100),
    search: Optional[str] = Query(None),
    sort_by: str = Query("created_at_desc"),
    document_type: Optional[str] = Query(None),
    jurisdiction: Optional[str] = Query(None)
) -> DocumentListResponse:
    """List documents with caching for improved performance"""
    
    # Prepare filters for cache key
    filters = {
        "sort_by": sort_by,
        "document_type": document_type,
        "jurisdiction": jurisdiction
    }
    
    # Try to get from cache first
    search_query = search or ""
    # Temporarily disable cache to debug
    # cached_result = performance_cache.get_search_results(
    #     search_query=search_query,
    #     filters=filters,
    #     page=page,
    #     per_page=per_page
    # )
    
    # if cached_result:
    #     return cached_result
    cached_result = None
    
    try:
        database_url = db.secrets.get("DATABASE_URL_DEV")
        conn = await asyncpg.connect(database_url)
        
        # Build query with optimizations
        conditions = ["1=1"]
        params = []
        param_count = 0
        
        # Only show published documents
        param_count += 1
        conditions.append(f"publishing_status = ${param_count}")
        params.append("published")
        
        if search:
            param_count += 1
            conditions.append(f"(title ILIKE ${param_count} OR description ILIKE ${param_count} OR content_text ILIKE ${param_count})")
            params.append(f"%{search}%")
        
        if document_type:
            param_count += 1
            conditions.append(f"document_type = ${param_count}")
            params.append(document_type)
        
        if jurisdiction:
            param_count += 1
            conditions.append(f"${param_count} = ANY(country_jurisdiction)")
            params.append(jurisdiction)
        
        where_clause = " AND ".join(conditions)
        
        # Determine sort order
        order_clause = {
            "created_at_desc": "created_at DESC",
            "created_at_asc": "created_at ASC", 
            "title_asc": "title ASC",
            "title_desc": "title DESC"
        }.get(sort_by, "created_at DESC")
        
        # Get total count
        count_query = f"SELECT COUNT(*) FROM kb_documents WHERE {where_clause}"
        total_count = await conn.fetchval(count_query, *params)
        
        # Get documents with pagination
        offset = (page - 1) * per_page
        param_count += 1
        limit_param = param_count
        param_count += 1
        offset_param = param_count
        
        query = f"""
            SELECT id, title, description, content_text, file_name, 
                   file_name as file_path, file_size, file_type, 
                   regulation_type as document_type, 
                   country_jurisdiction as jurisdiction, issuing_authority,
                   effective_date, expiration_date as expiry_date, legal_status, 
                   version, 'en' as language, tags, created_at, updated_at,
                   is_blog_article,
                   COALESCE(metadata->>'thumbnail_url', '') as thumbnail_url,
                   COALESCE(metadata->'attached_documents', '[]'::jsonb) as attached_documents
            FROM kb_documents 
            WHERE {where_clause}
            ORDER BY {order_clause}
            LIMIT ${limit_param} OFFSET ${offset_param}
        """
        
        params.extend([per_page, offset])
        
        rows = await conn.fetch(query, *params)
        await conn.close()
        
        # Convert rows to DocumentResponse objects, handling array fields properly
        documents = []
        for row in rows:
            row_dict = dict(row)
            # Convert array fields to strings for DocumentResponse compatibility
            if row_dict.get('jurisdiction'):
                if isinstance(row_dict['jurisdiction'], list):
                    row_dict['jurisdiction'] = ', '.join(row_dict['jurisdiction']) if row_dict['jurisdiction'] else ''
                else:
                    row_dict['jurisdiction'] = str(row_dict['jurisdiction']) if row_dict['jurisdiction'] else ''
            else:
                row_dict['jurisdiction'] = ''
                
            if row_dict.get('document_type'):
                if isinstance(row_dict['document_type'], list):
                    row_dict['document_type'] = ', '.join(row_dict['document_type']) if row_dict['document_type'] else ''
                else:
                    row_dict['document_type'] = str(row_dict['document_type']) if row_dict['document_type'] else ''
            else:
                row_dict['document_type'] = ''
            
            # Map jurisdiction to country_jurisdiction for DocumentResponse
            if 'jurisdiction' in row_dict:
                row_dict['country_jurisdiction'] = row_dict.pop('jurisdiction')
            if 'document_type' in row_dict:
                row_dict['regulation_type'] = row_dict.pop('document_type')
            
            # Ensure required fields have default values
            row_dict.setdefault('country_jurisdiction', '')
            row_dict.setdefault('regulation_type', '')
            
            documents.append(DocumentResponse(**row_dict))
        
        result = DocumentListResponse(
            documents=documents,
            total_count=total_count,
            has_more=(page * per_page) < total_count
        )
        
        # Cache the result
        performance_cache.set_search_results(
            search_query=search_query,
            filters=filters,
            page=page,
            per_page=per_page,
            data=result
        )
        
        return result
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Database error: {str(e)}")

@router.post("/advanced-search")
@consume_credits_for_action("knowledge_base", "advanced_search")
async def advanced_search_documents(
    request: AdvancedSearchRequest,
    user: AuthorizedUser
) -> AdvancedSearchResponse:
    """Advanced search with Boolean operators and filtering"""
    
    try:
        # Get database connection
        db_url = db.secrets.get("DATABASE_URL_DEV")
        conn = await asyncpg.connect(db_url)
        
        try:
            # Initialize search engine
            search_engine = AdvancedSearchEngine(conn)
            
            # Convert filter dictionaries to SearchFilter objects
            search_filters = []
            if request.filters:
                for filter_dict in request.filters:
                    search_filters.append(SearchFilter(
                        field=filter_dict.get('field', ''),
                        value=filter_dict.get('value', ''),
                        operator=filter_dict.get('operator', '=')
                    ))
            
            # Execute search
            results = await search_engine.search_documents(
                query=request.query,
                filters=search_filters,
                search_sections=request.search_sections,
                limit=request.limit,
                offset=request.offset,
                sort_by=request.sort_by
            )
            
            return AdvancedSearchResponse(**results)
            
        finally:
            await conn.close()
            
    except Exception as e:
        print(f"Advanced search error: {e}")
        raise HTTPException(status_code=500, detail=f"Search failed: {str(e)}")

@router.get("/search-suggestions")
async def get_search_suggestions(
    user: AuthorizedUser,
    query: str = Query(..., description="Partial search query")
) -> Dict[str, List[str]]:
    """Get search suggestions and auto-complete options"""
    
    try:
        db_url = db.secrets.get("DATABASE_URL_DEV")
        conn = await asyncpg.connect(db_url)
        
        try:
            suggestions = {
                'terms': [],
                'document_types': [],
                'authorities': [],
                'tags': []
            }
            
            # Get term suggestions from document titles and content
            if len(query) >= 2:
                term_query = """
                SELECT DISTINCT word
                FROM (
                    SELECT unnest(string_to_array(lower(title), ' ')) as word FROM kb_documents
                    UNION
                    SELECT unnest(string_to_array(lower(description), ' ')) as word FROM kb_documents
                ) words
                WHERE word LIKE $1 AND length(word) > 2
                ORDER BY word
                LIMIT 10
                """
                
                rows = await conn.fetch(term_query, f"{query.lower()}%")
                suggestions['terms'] = [row['word'] for row in rows]
            
            # Get document type suggestions
            type_query = """
            SELECT DISTINCT document_type
            FROM kb_documents
            WHERE document_type ILIKE $1 AND document_type IS NOT NULL
            ORDER BY document_type
            LIMIT 5
            """
            
            rows = await conn.fetch(type_query, f"%{query}%")
            suggestions['document_types'] = [row['document_type'] for row in rows]
            
            # Get authority suggestions
            auth_query = """
            SELECT DISTINCT issuing_authority
            FROM kb_documents
            WHERE issuing_authority ILIKE $1 AND issuing_authority IS NOT NULL
            ORDER BY issuing_authority
            LIMIT 5
            """
            
            rows = await conn.fetch(auth_query, f"%{query}%")
            suggestions['authorities'] = [row['issuing_authority'] for row in rows]
            
            # Get tag suggestions
            tag_query = """
            SELECT DISTINCT tag
            FROM (
                SELECT unnest(tags) as tag FROM kb_documents WHERE tags IS NOT NULL
            ) tag_list
            WHERE tag ILIKE $1
            ORDER BY tag
            LIMIT 8
            """
            
            rows = await conn.fetch(tag_query, f"%{query}%")
            suggestions['tags'] = [row['tag'] for row in rows]
            
            return suggestions
            
        finally:
            await conn.close()
            
    except Exception as e:
        print(f"Search suggestions error: {e}")
        return {'terms': [], 'document_types': [], 'authorities': [], 'tags': []}

# Response model for delete_document
class DeleteDocumentResponse(BaseModel):
    success: bool
    message: str

@router.delete("/documents/{document_id}")
async def delete_document(document_id: int, user: AuthorizedUser) -> DeleteDocumentResponse:
    """
    Delete a document and all its sections from the knowledge base
    """
    try:
        conn = await get_db_connection()
        
        # First check if document exists
        doc_check = await conn.fetchval(
            "SELECT id FROM kb_documents WHERE id = $1",
            document_id
        )
        
        if not doc_check:
            raise HTTPException(status_code=404, detail="Document not found")
        
        # Delete all sections for this document first
        await conn.execute(
            "DELETE FROM kb_document_sections WHERE document_id = $1",
            document_id
        )
        
        # Delete the document
        await conn.execute(
            "DELETE FROM kb_documents WHERE id = $1",
            document_id
        )
        
        await conn.close()
        
        return DeleteDocumentResponse(
            success=True,
            message=f"Document {document_id} deleted successfully"
        )
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error deleting document: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"Failed to delete document: {str(e)}"
        )

@router.get("/file/{document_id}", tags=["stream"])
async def download_document_file(
    document_id: int,
    user: AuthorizedUser,
    token: Optional[str] = Query(None, description="Authentication token as query parameter")
):
    """Download document file from storage"""
    try:
        # Use authenticated user instead of token-based auth
        user_id = user.sub
        print(f"Downloading file for document {document_id}, user: {user_id}")
        
        conn = await get_db_connection()
        try:
            # Get document details
            doc = await conn.fetchrow(
                """
                SELECT file_storage_key, file_name, file_type, file_size
                FROM kb_documents 
                WHERE id = $1
                """,
                document_id
            )
            
            if not doc:
                raise HTTPException(status_code=404, detail="Document not found")
            
            if not doc['file_storage_key']:
                raise HTTPException(status_code=404, detail="File not available")
            
            print(f"Retrieved document: {doc['file_name']}, storage key: {doc['file_storage_key']}")
            
            # Get file from storage
            try:
                file_content = db.storage.binary.get(doc['file_storage_key'])
                if not file_content:
                    raise HTTPException(status_code=404, detail="File content not found")
                
                print(f"File content size: {len(file_content)} bytes")
                
                # Create streaming response
                def generate():
                    yield file_content
                
                headers = {
                    'Content-Disposition': f'inline; filename="{doc["file_name"]}"',
                    'Content-Length': str(len(file_content))
                }
                
                return StreamingResponse(
                    generate(),
                    media_type=doc['file_type'] or 'application/pdf',
                    headers=headers
                )
                
            except Exception as storage_error:
                print(f"Storage error: {storage_error}")
                raise HTTPException(status_code=404, detail="File not found in storage")
                
        finally:
            await conn.close()
            
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error downloading file: {e}")
        raise HTTPException(status_code=500, detail=f"Error downloading file: {str(e)}")

@router.get("/blog/{document_id}", response_model=DocumentResponse)
async def get_blog_document(document_id: int, user: AuthorizedUser):
    """
    Get a single blog document by ID for editing
    """
    conn = await get_db_connection()
    try:
        query = """
            SELECT id, title, description, content_text, file_name,
                   file_name as file_path, file_size, file_type, 
                   regulation_type, 
                   country_jurisdiction, issuing_authority,
                   effective_date, expiration_date, legal_status, 
                   version, tags, created_at, updated_at, uploaded_by, publishing_status,
                   is_blog_article
            FROM kb_documents 
            WHERE id = $1
        """
        
        row = await conn.fetchrow(query, document_id)
        
        if not row:
            raise HTTPException(status_code=404, detail="Document not found")
        
        return DocumentResponse(
            id=row['id'],
            title=row['title'],
            description=row['description'],
            content_text=row['content_text'],
            file_name=row['file_name'],
            file_path=row['file_path'],
            file_size=row['file_size'],
            file_type=row['file_type'],
            country_jurisdiction=row['country_jurisdiction'][0] if row['country_jurisdiction'] else None,
            regulation_type=row['regulation_type'][0] if row['regulation_type'] else None,
            subject=None,  # Not available in this query
            publishing_status=row['publishing_status'],
            created_at=row['created_at'],
            updated_at=row['updated_at'],
            created_by=row['uploaded_by'],
            updated_by=row['uploaded_by'],
            is_blog_article=row.get('is_blog_article', False)
        )
        
    finally:
        await conn.close()

@router.post("/blog-search", response_model=DocumentSearchResponse)
@consume_credits_for_action("knowledge_base", "blog_search")
async def search_blog_documents(
    request: DocumentSearchRequest,
    user: AuthorizedUser
):
    """Search blog documents with filters, full-text search, and pagination"""
    conn = await get_db_connection()
    try:
        # Build base query
        base_query = """
            SELECT d.id, d.title, d.description, d.content_text, d.file_name, 
                   d.file_size, d.file_type, d.country_jurisdiction, d.regulation_type,
                   d.subject, d.publishing_status, d.created_at, d.updated_at, d.uploaded_by,
                   d.is_blog_article, d.metadata,
                   COALESCE(d.metadata->>'thumbnail_url', '') as thumbnail_url,
                   COALESCE(d.metadata->>'featured_status', 'false') as featured_status
            FROM kb_documents d
        """
        
        # Build WHERE conditions - filter for blog articles only
        conditions = ["d.is_blog_article = true"]
        params = []
        param_count = 0
        
        # Enhanced search based on mode
        if request.query and request.query.strip():
            # Simple search
            search_term = f"%{request.query.strip()}%"
            search_fields = request.search_fields or ['title', 'description', 'content_text']
            field_conditions = []
            for field in search_fields:
                param_count += 1
                field_conditions.append(f"d.{field} ILIKE ${param_count}")
                params.append(search_term)
            conditions.append(f"({' OR '.join(field_conditions)})")

        # Status filtering
        if request.status:
            status_filter = request.status
        else:
            status_filter = "published"
        
        if status_filter:
            param_count += 1
            conditions.append(f"d.publishing_status = ${param_count}")
            params.append(status_filter)
        
        # Country jurisdiction filtering
        if request.country_jurisdiction:
            param_count += 1
            conditions.append(f"${param_count} = ANY(d.country_jurisdiction)")
            params.append(request.country_jurisdiction)
        
        # Regulation type filtering
        if request.regulation_type:
            param_count += 1
            conditions.append(f"${param_count} = ANY(d.regulation_type)")
            params.append(request.regulation_type)
        
        # Legal status filtering
        if request.legal_status:
            param_count += 1
            conditions.append(f"d.legal_status = ${param_count}")
            params.append(request.legal_status)
        
        # Tags filtering
        if request.tags:
            for tag in request.tags:
                param_count += 1
                conditions.append(f"${param_count} = ANY(d.tags)")
                params.append(tag)
        
        # Build final query
        where_clause = ""
        if conditions:
            where_clause = " WHERE " + " AND ".join(conditions)
        
        # Count query - simplified to avoid column issues
        count_query = f"SELECT COUNT(*) FROM kb_documents d{where_clause}"
        total_count = await conn.fetchval(count_query, *params)
        
        # Add ordering
        full_query = base_query + where_clause + " ORDER BY d.updated_at DESC, d.created_at DESC"
        
        # Add pagination
        param_count += 1
        full_query += f" LIMIT ${param_count}"
        params.append(request.limit)
        
        param_count += 1
        full_query += f" OFFSET ${param_count}"
        params.append(request.offset)
        
        # Execute search
        rows = await conn.fetch(full_query, *params)
        
        # Build response with proper attached_documents handling
        documents = []
        for row in rows:
            row_dict = dict(row)
            
            # Handle attached_documents parsing
            attached_documents = []
            try:
                if row_dict.get('metadata'):
                    metadata = row_dict['metadata']
                    if isinstance(metadata, str):
                        metadata = json.loads(metadata)
                    
                    attached_docs = metadata.get('attached_documents', [])
                    if isinstance(attached_docs, str):
                        attached_documents = json.loads(attached_docs)
                    elif isinstance(attached_docs, list):
                        attached_documents = attached_docs
            except (json.JSONDecodeError, TypeError) as e:
                print(f"Error parsing attached_documents: {e}")
                attached_documents = []
            
            row_dict['attached_documents'] = attached_documents
            documents.append(build_document_response(row_dict))
        
        has_more = (request.offset + len(documents)) < total_count
        
        return DocumentSearchResponse(
            documents=documents,
            total_count=total_count,
            has_more=has_more,
            query_info={
                "query": request.query,
                "search_mode": request.search_mode,
                "filters_applied": {
                    "status": status_filter,
                    "country_jurisdiction": request.country_jurisdiction,
                    "regulation_type": request.regulation_type,
                    "legal_status": request.legal_status,
                    "tags": request.tags,
                    "date_from": request.date_from,
                    "date_to": request.date_to
                },
                "results_count": len(documents)
            }
        )
        
    finally:
        await conn.close()

@router.get("/blog")
async def list_blog_documents(
    user: AuthorizedUser,
    page: int = Query(1, ge=1),
    per_page: int = Query(20, ge=1, le=100),
    search: Optional[str] = Query(None),
    sort_by: str = Query("created_at_desc"),
    document_type: Optional[str] = Query(None),
    jurisdiction: Optional[str] = Query(None)
) -> DocumentListResponse:
    """List blog documents with caching for improved performance"""
    
    # Prepare filters for cache key
    filters = {
        "sort_by": sort_by,
        "document_type": document_type,
        "jurisdiction": jurisdiction
    }
    
    # Try to get from cache first
    search_query = search or ""
    # Temporarily disable cache to debug
    # cached_result = performance_cache.get_search_results(
    #     search_query=search_query,
    #     filters=filters,
    #     page=page,
    #     per_page=per_page
    # )
    
    # if cached_result:
    #     return cached_result
    cached_result = None
    
    try:
        database_url = db.secrets.get("DATABASE_URL_DEV")
        conn = await asyncpg.connect(database_url)
        
        # Build query with optimizations
        conditions = ["1=1"]
        params = []
        param_count = 0
        
        # Only show published documents
        param_count += 1
        conditions.append(f"publishing_status = ${param_count}")
        params.append("published")
        
        # Only show blog articles
        param_count += 1
        conditions.append(f"is_blog_article = ${param_count}")
        params.append(True)
        
        if search:
            param_count += 1
            conditions.append(f"(title ILIKE ${param_count} OR description ILIKE ${param_count} OR content_text ILIKE ${param_count})")
            params.append(f"%{search}%")
        
        if document_type:
            param_count += 1
            conditions.append(f"document_type = ${param_count}")
            params.append(document_type)
        
        if jurisdiction:
            param_count += 1
            conditions.append(f"${param_count} = ANY(country_jurisdiction)")
            params.append(jurisdiction)
        
        where_clause = " AND ".join(conditions)
        
        # Determine sort order
        order_clause = {
            "created_at_desc": "created_at DESC",
            "created_at_asc": "created_at ASC", 
            "title_asc": "title ASC",
            "title_desc": "title DESC"
        }.get(sort_by, "created_at DESC")
        
        # Get total count
        count_query = f"SELECT COUNT(*) FROM kb_documents WHERE {where_clause}"
        total_count = await conn.fetchval(count_query, *params)
        
        # Get documents with pagination
        offset = (page - 1) * per_page
        param_count += 1
        limit_param = param_count
        param_count += 1
        offset_param = param_count
        
        query = f"""
            SELECT id, title, description, content_text, file_name, 
                   file_name as file_path, file_size, file_type, 
                   regulation_type as document_type, 
                   country_jurisdiction as jurisdiction, issuing_authority,
                   effective_date, expiration_date as expiry_date, legal_status, 
                   version, 'en' as language, tags, created_at, updated_at,
                   is_blog_article,
                   COALESCE(metadata->>'thumbnail_url', '') as thumbnail_url,
                   COALESCE(metadata->'attached_documents', '[]'::jsonb) as attached_documents
            FROM kb_documents 
            WHERE {where_clause}
            ORDER BY {order_clause}
            LIMIT ${limit_param} OFFSET ${offset_param}
        """
        
        params.extend([per_page, offset])
        
        rows = await conn.fetch(query, *params)
        await conn.close()
        
        # Convert rows to DocumentResponse objects, handling array fields properly
        documents = []
        for row in rows:
            row_dict = dict(row)
            # Convert array fields to strings for DocumentResponse compatibility
            if row_dict.get('jurisdiction'):
                if isinstance(row_dict['jurisdiction'], list):
                    row_dict['jurisdiction'] = ', '.join(row_dict['jurisdiction']) if row_dict['jurisdiction'] else ''
                else:
                    row_dict['jurisdiction'] = str(row_dict['jurisdiction']) if row_dict['jurisdiction'] else ''
            else:
                row_dict['jurisdiction'] = ''
                
            if row_dict.get('document_type'):
                if isinstance(row_dict['document_type'], list):
                    row_dict['document_type'] = ', '.join(row_dict['document_type']) if row_dict['document_type'] else ''
                else:
                    row_dict['document_type'] = str(row_dict['document_type']) if row_dict['document_type'] else ''
            else:
                row_dict['document_type'] = ''
            
            # Map jurisdiction to country_jurisdiction for DocumentResponse
            if 'jurisdiction' in row_dict:
                row_dict['country_jurisdiction'] = row_dict.pop('jurisdiction')
            if 'document_type' in row_dict:
                row_dict['regulation_type'] = row_dict.pop('document_type')
            
            # Ensure required fields have default values
            row_dict.setdefault('country_jurisdiction', '')
            row_dict.setdefault('regulation_type', '')
            
            documents.append(DocumentResponse(**row_dict))
        
        result = DocumentListResponse(
            documents=documents,
            total_count=total_count,
            has_more=(page * per_page) < total_count
        )
        
        # Cache the result
        performance_cache.set_search_results(
            search_query=search_query,
            filters=filters,
            page=page,
            per_page=per_page,
            data=result
        )
        
        return result
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Database error: {str(e)}")

@router.post("/blog-advanced-search")
@consume_credits_for_action("knowledge_base", "blog_advanced_search")
async def advanced_search_blog_documents(
    request: AdvancedSearchRequest,
    user: AuthorizedUser
) -> AdvancedSearchResponse:
    """Advanced search with Boolean operators and filtering"""
    
    try:
        # Get database connection
        db_url = db.secrets.get("DATABASE_URL_DEV")
        conn = await asyncpg.connect(db_url)
        
        try:
            # Initialize search engine
            search_engine = AdvancedSearchEngine(conn)
            
            # Convert filter dictionaries to SearchFilter objects
            search_filters = []
            if request.filters:
                for filter_dict in request.filters:
                    search_filters.append(SearchFilter(
                        field=filter_dict.get('field', ''),
                        value=filter_dict.get('value', ''),
                        operator=filter_dict.get('operator', '=')
                    ))
            
            # Execute search
            results = await search_engine.search_documents(
                query=request.query,
                filters=search_filters,
                search_sections=request.search_sections,
                limit=request.limit,
                offset=request.offset,
                sort_by=request.sort_by
            )
            
            return AdvancedSearchResponse(**results)
            
        finally:
            await conn.close()
            
    except Exception as e:
        print(f"Advanced search error: {e}")
        raise HTTPException(status_code=500, detail=f"Search failed: {str(e)}")

@router.get("/blog-search-suggestions")
async def get_blog_search_suggestions(
    user: AuthorizedUser,
    query: str = Query(..., description="Partial search query")
) -> Dict[str, List[str]]:
    """Get search suggestions and auto-complete options"""
    
    try:
        db_url = db.secrets.get("DATABASE_URL_DEV")
        conn = await asyncpg.connect(db_url)
        
        try:
            suggestions = {
                'terms': [],
                'document_types': [],
                'authorities': [],
                'tags': []
            }
            
            # Get term suggestions from document titles and content
            if len(query) >= 2:
                term_query = """
                SELECT DISTINCT word
                FROM (
                    SELECT unnest(string_to_array(lower(title), ' ')) as word FROM kb_documents
                    UNION
                    SELECT unnest(string_to_array(lower(description), ' ')) as word FROM kb_documents
                ) words
                WHERE word LIKE $1 AND length(word) > 2
                ORDER BY word
                LIMIT 10
                """
                
                rows = await conn.fetch(term_query, f"{query.lower()}%")
                suggestions['terms'] = [row['word'] for row in rows]
            
            # Get document type suggestions
            type_query = """
            SELECT DISTINCT document_type
            FROM kb_documents
            WHERE document_type ILIKE $1 AND document_type IS NOT NULL
            ORDER BY document_type
            LIMIT 5
            """
            
            rows = await conn.fetch(type_query, f"%{query}%")
            suggestions['document_types'] = [row['document_type'] for row in rows]
            
            # Get authority suggestions
            auth_query = """
            SELECT DISTINCT issuing_authority
            FROM kb_documents
            WHERE issuing_authority ILIKE $1 AND issuing_authority IS NOT NULL
            ORDER BY issuing_authority
            LIMIT 5
            """
            
            rows = await conn.fetch(auth_query, f"%{query}%")
            suggestions['authorities'] = [row['issuing_authority'] for row in rows]
            
            # Get tag suggestions
            tag_query = """
            SELECT DISTINCT tag
            FROM (
                SELECT unnest(tags) as tag FROM kb_documents WHERE tags IS NOT NULL
            ) tag_list
            WHERE tag ILIKE $1
            ORDER BY tag
            LIMIT 8
            """
            
            rows = await conn.fetch(tag_query, f"%{query}%")
            suggestions['tags'] = [row['tag'] for row in rows]
            
            return suggestions
            
        finally:
            await conn.close()
            
    except Exception as e:
        print(f"Search suggestions error: {e}")
        return {'terms': [], 'document_types': [], 'authorities': [], 'tags': []}
