from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import List, Optional, Dict, Any
from datetime import datetime, timedelta
import asyncpg
import databutton as db
from app.auth import AuthorizedUser
import json
import math

router = APIRouter(prefix="/predictive-analytics")

# Pydantic Models
class PredictiveRiskRequest(BaseModel):
    customer_id: Optional[int] = None  # If None, analyze all customers
    prediction_horizon_days: int = 30  # How far ahead to predict
    include_confidence_scores: bool = True
    risk_factors: Optional[List[str]] = None  # Specific factors to analyze

class CustomerRiskPrediction(BaseModel):
    customer_id: int
    customer_name: str
    current_risk_level: str
    current_risk_score: float
    predicted_risk_level: str
    predicted_risk_score: float
    confidence_score: float
    risk_trend: str  # "increasing", "decreasing", "stable"
    key_risk_factors: List[str]
    prediction_date: datetime
    next_review_date: datetime

class PredictiveRiskResponse(BaseModel):
    success: bool
    message: str
    predictions: List[CustomerRiskPrediction]
    total_predictions: int
    high_risk_predictions: int
    model_accuracy: Optional[float] = None

class RiskTrendAnalysisRequest(BaseModel):
    customer_ids: Optional[List[int]] = None
    analysis_period_days: int = 90
    trend_type: str = "risk_score"  # "risk_score", "screening_frequency", "sanctions_matches"

class TrendDataPoint(BaseModel):
    date: datetime
    value: float
    customer_count: int

class RiskTrendAnalysisResponse(BaseModel):
    success: bool
    message: str
    trend_data: List[TrendDataPoint]
    trend_direction: str  # "upward", "downward", "stable"
    correlation_score: float
    period_start: datetime
    period_end: datetime

class ModelPerformanceRequest(BaseModel):
    evaluation_period_days: int = 30
    model_type: str = "risk_prediction"  # Future: support multiple models

class ModelPerformanceMetrics(BaseModel):
    accuracy: float
    precision: float
    recall: float
    f1_score: float
    true_positives: int
    false_positives: int
    true_negatives: int
    false_negatives: int

class ModelPerformanceResponse(BaseModel):
    success: bool
    message: str
    metrics: ModelPerformanceMetrics
    evaluation_period: str
    last_updated: datetime

# Database connection helper
async def get_db_connection():
    from app.env import Mode, mode
    if mode.value == "PROD":
        database_url = db.secrets.get("DATABASE_URL_PROD")
    else:
        database_url = db.secrets.get("DATABASE_URL_DEV")
    return await asyncpg.connect(database_url)

@router.post("/predict-customer-risks")
async def predict_customer_risks(request: PredictiveRiskRequest, user: AuthorizedUser) -> PredictiveRiskResponse:
    """
    Generate predictive risk scores for customers using historical data patterns
    """
    try:
        conn = await get_db_connection()
        predictions = []
        
        # Get customers to analyze
        if request.customer_id:
            customers_query = """
                SELECT c.id, c.name, c.risk_level, c.risk_score, c.created_at
                FROM customers c
                WHERE c.id = $1
            """
            customers = await conn.fetch(customers_query, request.customer_id)
        else:
            customers_query = """
                SELECT c.id, c.name, c.risk_level, c.risk_score, c.created_at
                FROM customers c
                ORDER BY c.risk_score DESC NULLS LAST
                LIMIT 100
            """
            customers = await conn.fetch(customers_query)
        
        high_risk_count = 0
        
        for customer in customers:
            # Get historical screening data
            historical_query = """
                SELECT 
                    cs.sanctions_matches,
                    cs.pep_matches,
                    cs.adverse_media_matches,
                    cs.other_matches,
                    cs.created_at,
                    cs.risk_score
                FROM customer_screenings cs
                WHERE cs.customer_id = $1
                ORDER BY cs.created_at DESC
                LIMIT 10
            """
            historical_data = await conn.fetch(historical_query, customer['id'])
            
            if len(historical_data) >= 2:  # Need at least 2 data points for prediction
                # Calculate prediction using trend analysis and weighted factors
                prediction_result = await calculate_predictive_risk(
                    customer, 
                    historical_data, 
                    request.prediction_horizon_days,
                    conn
                )
                
                if prediction_result['predicted_risk_score'] >= 60:
                    high_risk_count += 1
                
                predictions.append(CustomerRiskPrediction(
                    customer_id=customer['id'],
                    customer_name=customer['name'],
                    current_risk_level=customer['risk_level'] or "Unknown",
                    current_risk_score=float(customer['risk_score']) if customer['risk_score'] else 0.0,
                    predicted_risk_level=prediction_result['predicted_risk_level'],
                    predicted_risk_score=prediction_result['predicted_risk_score'],
                    confidence_score=prediction_result['confidence_score'],
                    risk_trend=prediction_result['risk_trend'],
                    key_risk_factors=prediction_result['key_risk_factors'],
                    prediction_date=datetime.now(),
                    next_review_date=datetime.now() + timedelta(days=request.prediction_horizon_days)
                ))
        
        await conn.close()
        
        return PredictiveRiskResponse(
            success=True,
            message=f"Generated predictions for {len(predictions)} customers",
            predictions=predictions,
            total_predictions=len(predictions),
            high_risk_predictions=high_risk_count,
            model_accuracy=0.85  # Simulated model accuracy - would be calculated from validation data
        )
        
    except Exception as e:
        return PredictiveRiskResponse(
            success=False,
            message=f"Error generating risk predictions: {str(e)}",
            predictions=[],
            total_predictions=0,
            high_risk_predictions=0
        )

@router.post("/analyze-risk-trends")
async def analyze_risk_trends(request: RiskTrendAnalysisRequest, user: AuthorizedUser) -> RiskTrendAnalysisResponse:
    """
    Analyze risk trends over time for pattern recognition
    """
    try:
        conn = await get_db_connection()
        
        # Calculate date range
        end_date = datetime.now()
        start_date = end_date - timedelta(days=request.analysis_period_days)
        
        # Build query based on trend type
        if request.trend_type == "risk_score":
            trend_query = """
                SELECT 
                    DATE_TRUNC('day', cs.created_at) as trend_date,
                    AVG(cs.risk_score) as avg_value,
                    COUNT(DISTINCT cs.customer_id) as customer_count
                FROM customer_screenings cs
                WHERE cs.created_at >= $1 AND cs.created_at <= $2
            """
        elif request.trend_type == "sanctions_matches":
            trend_query = """
                SELECT 
                    DATE_TRUNC('day', cs.created_at) as trend_date,
                    AVG(cs.sanctions_matches) as avg_value,
                    COUNT(DISTINCT cs.customer_id) as customer_count
                FROM customer_screenings cs
                WHERE cs.created_at >= $1 AND cs.created_at <= $2
            """
        else:  # screening_frequency
            trend_query = """
                SELECT 
                    DATE_TRUNC('day', cs.created_at) as trend_date,
                    COUNT(cs.id) as avg_value,
                    COUNT(DISTINCT cs.customer_id) as customer_count
                FROM customer_screenings cs
                WHERE cs.created_at >= $1 AND cs.created_at <= $2
            """
        
        # Add customer filter if specified
        if request.customer_ids:
            trend_query += " AND cs.customer_id = ANY($3)"
            trend_query += " GROUP BY DATE_TRUNC('day', cs.created_at) ORDER BY trend_date"
            trend_data = await conn.fetch(trend_query, start_date, end_date, request.customer_ids)
        else:
            trend_query += " GROUP BY DATE_TRUNC('day', cs.created_at) ORDER BY trend_date"
            trend_data = await conn.fetch(trend_query, start_date, end_date)
        
        # Calculate trend direction and correlation
        trend_direction, correlation_score = calculate_trend_direction(trend_data)
        
        # Format response data
        trend_points = [
            TrendDataPoint(
                date=row['trend_date'],
                value=float(row['avg_value']) if row['avg_value'] else 0.0,
                customer_count=row['customer_count']
            )
            for row in trend_data
        ]
        
        await conn.close()
        
        return RiskTrendAnalysisResponse(
            success=True,
            message=f"Analyzed {len(trend_points)} data points over {request.analysis_period_days} days",
            trend_data=trend_points,
            trend_direction=trend_direction,
            correlation_score=correlation_score,
            period_start=start_date,
            period_end=end_date
        )
        
    except Exception as e:
        return RiskTrendAnalysisResponse(
            success=False,
            message=f"Error analyzing risk trends: {str(e)}",
            trend_data=[],
            trend_direction="unknown",
            correlation_score=0.0,
            period_start=datetime.now(),
            period_end=datetime.now()
        )

@router.get("/model-performance")
async def get_model_performance(request: ModelPerformanceRequest, user: AuthorizedUser) -> ModelPerformanceResponse:
    """
    Evaluate the performance of the predictive risk model
    """
    try:
        conn = await get_db_connection()
        
        # Get validation data from the specified period
        end_date = datetime.now()
        start_date = end_date - timedelta(days=request.evaluation_period_days)
        
        # For demonstration, we'll simulate model performance metrics
        # In a real implementation, this would compare predictions vs actual outcomes
        validation_query = """
            SELECT COUNT(*) as total_predictions
            FROM customer_screenings cs
            WHERE cs.created_at >= $1 AND cs.created_at <= $2
        """
        result = await conn.fetchrow(validation_query, start_date, end_date)
        total_predictions = result['total_predictions'] if result else 0
        
        # Simulated performance metrics (would be calculated from actual prediction accuracy)
        metrics = ModelPerformanceMetrics(
            accuracy=0.87,
            precision=0.82,
            recall=0.78,
            f1_score=0.80,
            true_positives=int(total_predictions * 0.65),
            false_positives=int(total_predictions * 0.15),
            true_negatives=int(total_predictions * 0.15),
            false_negatives=int(total_predictions * 0.05)
        )
        
        await conn.close()
        
        return ModelPerformanceResponse(
            success=True,
            message=f"Model performance evaluated over {request.evaluation_period_days} days",
            metrics=metrics,
            evaluation_period=f"{request.evaluation_period_days} days",
            last_updated=datetime.now()
        )
        
    except Exception as e:
        return ModelPerformanceResponse(
            success=False,
            message=f"Error evaluating model performance: {str(e)}",
            metrics=ModelPerformanceMetrics(
                accuracy=0.0, precision=0.0, recall=0.0, f1_score=0.0,
                true_positives=0, false_positives=0, true_negatives=0, false_negatives=0
            ),
            evaluation_period="0 days",
            last_updated=datetime.now()
        )

# Helper Functions
async def calculate_predictive_risk(customer: dict, historical_data: list, horizon_days: int, conn) -> dict:
    """
    Calculate predictive risk score using trend analysis and weighted factors
    """
    if not historical_data:
        return {
            'predicted_risk_score': 0.0,
            'predicted_risk_level': 'Unknown',
            'confidence_score': 0.0,
            'risk_trend': 'stable',
            'key_risk_factors': []
        }
    
    # Calculate trend from historical data
    scores = [float(row['risk_score']) if row['risk_score'] else 0.0 for row in historical_data]
    sanctions_trend = [row['sanctions_matches'] for row in historical_data]
    pep_trend = [row['pep_matches'] for row in historical_data]
    
    # Calculate linear trend
    if len(scores) >= 2:
        # Simple linear regression for trend
        x_values = list(range(len(scores)))
        n = len(scores)
        sum_x = sum(x_values)
        sum_y = sum(scores)
        sum_xy = sum(x * y for x, y in zip(x_values, scores))
        sum_x2 = sum(x * x for x in x_values)
        
        # Calculate slope
        slope = (n * sum_xy - sum_x * sum_y) / (n * sum_x2 - sum_x * sum_x) if (n * sum_x2 - sum_x * sum_x) != 0 else 0
        
        # Project future risk score
        current_score = scores[0]  # Most recent score
        projected_score = current_score + (slope * horizon_days / 7)  # Adjust for time horizon
        
        # Add volatility factor
        score_variance = sum((s - sum_y/n)**2 for s in scores) / n if n > 1 else 0
        volatility_adjustment = math.sqrt(score_variance) * 0.1
        
        final_predicted_score = max(0, min(100, projected_score + volatility_adjustment))
        
    else:
        final_predicted_score = scores[0] if scores else 0.0
        slope = 0
    
    # Determine risk trend
    if slope > 2:
        risk_trend = "increasing"
    elif slope < -2:
        risk_trend = "decreasing"
    else:
        risk_trend = "stable"
    
    # Determine risk level
    if final_predicted_score >= 80:
        predicted_risk_level = "Critical"
    elif final_predicted_score >= 60:
        predicted_risk_level = "High"
    elif final_predicted_score >= 40:
        predicted_risk_level = "Medium"
    elif final_predicted_score >= 20:
        predicted_risk_level = "Low"
    else:
        predicted_risk_level = "Minimal"
    
    # Calculate confidence score based on data quality
    confidence_score = min(0.95, 0.5 + (len(historical_data) * 0.05) + (0.2 if score_variance < 100 else 0))
    
    # Identify key risk factors
    key_risk_factors = []
    if any(s > 0 for s in sanctions_trend):
        key_risk_factors.append("Sanctions matches")
    if any(p > 0 for p in pep_trend):
        key_risk_factors.append("PEP exposure")
    if slope > 5:
        key_risk_factors.append("Increasing risk trend")
    if score_variance > 200:
        key_risk_factors.append("High volatility")
    
    return {
        'predicted_risk_score': round(final_predicted_score, 2),
        'predicted_risk_level': predicted_risk_level,
        'confidence_score': round(confidence_score, 2),
        'risk_trend': risk_trend,
        'key_risk_factors': key_risk_factors
    }

def calculate_trend_direction(trend_data: list) -> tuple:
    """
    Calculate overall trend direction and correlation score
    """
    if len(trend_data) < 2:
        return "stable", 0.0
    
    values = [float(row['avg_value']) if row['avg_value'] else 0.0 for row in trend_data]
    
    # Calculate simple linear correlation
    n = len(values)
    x_values = list(range(n))
    
    sum_x = sum(x_values)
    sum_y = sum(values)
    sum_xy = sum(x * y for x, y in zip(x_values, values))
    sum_x2 = sum(x * x for x in x_values)
    sum_y2 = sum(y * y for y in values)
    
    # Pearson correlation coefficient
    numerator = n * sum_xy - sum_x * sum_y
    denominator = math.sqrt((n * sum_x2 - sum_x * sum_x) * (n * sum_y2 - sum_y * sum_y))
    
    correlation = numerator / denominator if denominator != 0 else 0
    
    # Determine trend direction
    if correlation > 0.3:
        direction = "upward"
    elif correlation < -0.3:
        direction = "downward"
    else:
        direction = "stable"
    
    return direction, round(correlation, 3)
