
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, EmailStr
from typing import List, Optional, Dict, Any
from app.auth import AuthorizedUser
import asyncpg
import databutton as db
import uuid
import secrets
from datetime import datetime, timedelta
import json

router = APIRouter(prefix="/team-management")

# Database connection
async def get_db_connection():
    return await asyncpg.connect(db.secrets.get("DATABASE_URL_DEV"))

# Pydantic Models
class CreateCompanyRequest(BaseModel):
    company_name: str
    company_domain: Optional[str] = None
    billing_email: Optional[str] = None
    subscription_tier: str = 'basic'
    max_team_members: int = 10

class InviteUserRequest(BaseModel):
    email: EmailStr
    role_name: str
    message: Optional[str] = None

class UpdateMemberRoleRequest(BaseModel):
    role_name: str

class CompanyResponse(BaseModel):
    id: int
    company_name: str
    company_slug: str
    company_domain: Optional[str]
    billing_email: Optional[str]
    subscription_tier: str
    max_team_members: int
    created_by: str
    created_at: str
    updated_at: str
    is_active: bool
    sso_enabled: bool
    audit_logs_enabled: bool
    api_access_enabled: bool
    member_count: int
    current_user_role: str

class TeamMemberResponse(BaseModel):
    id: int
    user_id: str
    email: Optional[str] = None
    display_name: Optional[str] = None
    role_name: str
    role_description: str
    status: str
    joined_at: str
    last_active: Optional[str]
    invited_by: Optional[str]

class InvitationResponse(BaseModel):
    id: int
    email: str
    role_name: str
    status: str
    invited_by: str
    invited_at: str
    expires_at: str
    message: Optional[str]

class RoleDefinitionResponse(BaseModel):
    id: int
    role_name: str
    role_description: str
    permissions: Dict[str, bool]
    is_system_role: bool

# Helper Functions
def generate_company_slug(company_name: str) -> str:
    """Generate a URL-safe slug from company name"""
    import re
    slug = re.sub(r'[^a-zA-Z0-9\s-]', '', company_name.lower())
    slug = re.sub(r'[\s-]+', '-', slug).strip('-')
    return slug[:50]  # Limit length

async def get_user_company_role(user_id: str, company_id: int, conn) -> Optional[str]:
    """Get user's role in a specific company"""
    result = await conn.fetchrow("""
        SELECT rd.role_name 
        FROM team_memberships tm
        JOIN role_definitions rd ON tm.role_id = rd.id
        WHERE tm.user_id = $1 AND tm.company_id = $2 AND tm.status = 'active'
    """, user_id, company_id)
    return result['role_name'] if result else None

async def check_permission(user_id: str, company_id: int, permission: str, conn) -> bool:
    """Check if user has specific permission in company"""
    result = await conn.fetchrow("""
        SELECT rd.permissions 
        FROM team_memberships tm
        JOIN role_definitions rd ON tm.role_id = rd.id
        WHERE tm.user_id = $1 AND tm.company_id = $2 AND tm.status = 'active'
    """, user_id, company_id)
    
    if not result:
        return False
    
    permissions = result['permissions'] or {}
    return permissions.get(permission, False)

async def log_audit_action(company_id: int, user_id: str, action: str, details: Dict, conn):
    """Log an audit action"""
    await conn.execute("""
        INSERT INTO company_audit_logs (company_id, user_id, action, details, created_at)
        VALUES ($1, $2, $3, $4, $5)
    """, company_id, user_id, action, json.dumps(details), datetime.now())

# Company Management Endpoints
@router.post("/create-company")
async def create_company(body: CreateCompanyRequest, user: AuthorizedUser) -> CompanyResponse:
    """Create a new company (automatically makes user the owner)"""
    try:
        conn = await get_db_connection()
        
        # Generate unique slug
        base_slug = generate_company_slug(body.company_name)
        slug = base_slug
        counter = 1
        
        while await conn.fetchval("SELECT id FROM companies WHERE company_slug = $1", slug):
            slug = f"{base_slug}-{counter}"
            counter += 1
        
        # Create company
        company_id = await conn.fetchval("""
            INSERT INTO companies 
            (company_name, company_slug, company_domain, billing_email, subscription_tier, 
             max_team_members, created_by, created_at, updated_at)
            VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
            RETURNING id
        """, body.company_name, slug, body.company_domain, body.billing_email,
        body.subscription_tier, body.max_team_members, user.sub, datetime.now(), datetime.now())
        
        # Get owner role ID
        owner_role_id = await conn.fetchval(
            "SELECT id FROM role_definitions WHERE role_name = 'owner'"
        )
        
        # Add creator as owner
        await conn.execute("""
            INSERT INTO team_memberships 
            (company_id, user_id, role_id, status, joined_at, created_at, updated_at)
            VALUES ($1, $2, $3, 'active', $4, $5, $6)
        """, company_id, user.sub, owner_role_id, datetime.now(), datetime.now(), datetime.now())
        
        # Log audit action
        await log_audit_action(company_id, user.sub, "company_created", {
            "company_name": body.company_name
        }, conn)
        
        # Return company details
        company = await conn.fetchrow("""
            SELECT c.*, COUNT(tm.id) as member_count
            FROM companies c
            LEFT JOIN team_memberships tm ON c.id = tm.company_id AND tm.status = 'active'
            WHERE c.id = $1
            GROUP BY c.id
        """, company_id)
        
        await conn.close()
        
        return CompanyResponse(
            id=company['id'],
            company_name=company['company_name'],
            company_slug=company['company_slug'],
            company_domain=company['company_domain'],
            billing_email=company['billing_email'],
            subscription_tier=company['subscription_tier'],
            max_team_members=company['max_team_members'],
            created_by=company['created_by'],
            created_at=company['created_at'].isoformat(),
            updated_at=company['updated_at'].isoformat(),
            is_active=company['is_active'],
            sso_enabled=company['sso_enabled'],
            audit_logs_enabled=company['audit_logs_enabled'],
            api_access_enabled=company['api_access_enabled'],
            member_count=company['member_count'],
            current_user_role='owner'
        )
        
    except Exception as e:
        print(f"Error creating company: {e}")
        raise HTTPException(status_code=500, detail="Failed to create company")

@router.get("/my-companies")
async def get_my_companies(user: AuthorizedUser) -> List[CompanyResponse]:
    """Get all companies where user is a member"""
    try:
        conn = await get_db_connection()
        
        companies = await conn.fetch("""
            SELECT c.*, rd.role_name, COUNT(all_members.id) as member_count
            FROM companies c
            JOIN team_memberships tm ON c.id = tm.company_id
            JOIN role_definitions rd ON tm.role_id = rd.id
            LEFT JOIN team_memberships all_members ON c.id = all_members.company_id AND all_members.status = 'active'
            WHERE tm.user_id = $1 AND tm.status = 'active'
            GROUP BY c.id, rd.role_name
            ORDER BY c.company_name
        """, user.sub)
        
        await conn.close()
        
        return [
            CompanyResponse(
                id=company['id'],
                company_name=company['company_name'],
                company_slug=company['company_slug'],
                company_domain=company['company_domain'],
                billing_email=company['billing_email'],
                subscription_tier=company['subscription_tier'],
                max_team_members=company['max_team_members'],
                created_by=company['created_by'],
                created_at=company['created_at'].isoformat(),
                updated_at=company['updated_at'].isoformat(),
                is_active=company['is_active'],
                sso_enabled=company['sso_enabled'],
                audit_logs_enabled=company['audit_logs_enabled'],
                api_access_enabled=company['api_access_enabled'],
                member_count=company['member_count'],
                current_user_role=company['role_name']
            )
            for company in companies
        ]
        
    except Exception as e:
        print(f"Error getting user companies: {e}")
        raise HTTPException(status_code=500, detail="Failed to get companies")

# Team Member Management
@router.post("/companies/{company_id}/invite")
async def invite_team_member(company_id: int, body: InviteUserRequest, user: AuthorizedUser) -> Dict[str, Any]:
    """Invite a new team member to the company"""
    try:
        conn = await get_db_connection()
        
        # Check if user has team management permission
        if not await check_permission(user.sub, company_id, "team_management", conn):
            raise HTTPException(status_code=403, detail="Insufficient permissions to invite team members")
        
        # Check if company exists and is active
        company = await conn.fetchrow(
            "SELECT * FROM companies WHERE id = $1 AND is_active = true", company_id
        )
        if not company:
            raise HTTPException(status_code=404, detail="Company not found")
        
        # Check team member limit
        current_members = await conn.fetchval(
            "SELECT COUNT(*) FROM team_memberships WHERE company_id = $1 AND status = 'active'", 
            company_id
        )
        if current_members >= company['max_team_members']:
            raise HTTPException(status_code=400, detail="Team member limit reached")
        
        # Check if user is already a member or has pending invitation
        existing_member = await conn.fetchval(
            "SELECT id FROM team_memberships WHERE company_id = $1 AND user_id = (SELECT id FROM neon_auth.users_sync WHERE email = $2)",
            company_id, body.email
        )
        if existing_member:
            raise HTTPException(status_code=400, detail="User is already a team member")
        
        existing_invitation = await conn.fetchval(
            "SELECT id FROM team_invitations WHERE company_id = $1 AND email = $2 AND status = 'pending'",
            company_id, body.email
        )
        if existing_invitation:
            raise HTTPException(status_code=400, detail="User already has a pending invitation")
        
        # Get role ID
        role = await conn.fetchrow(
            "SELECT id, role_name FROM role_definitions WHERE role_name = $1", body.role_name
        )
        if not role:
            raise HTTPException(status_code=400, detail="Invalid role")
        
        # Generate invitation token
        invitation_token = secrets.token_urlsafe(32)
        expires_at = datetime.now() + timedelta(days=7)  # 7 days to accept
        
        # Create invitation
        invitation_id = await conn.fetchval("""
            INSERT INTO team_invitations 
            (company_id, email, role_id, invitation_token, invited_by, invited_at, expires_at, message)
            VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
            RETURNING id
        """, company_id, body.email, role['id'], invitation_token, user.sub, 
        datetime.now(), expires_at, body.message)
        
        # Log audit action
        await log_audit_action(company_id, user.sub, "team_member_invited", {
            "email": body.email,
            "role": body.role_name,
            "invitation_id": invitation_id
        }, conn)
        
        # TODO: Send invitation email
        # await send_invitation_email(body.email, company['company_name'], invitation_token)
        
        await conn.close()
        
        return {
            "success": True,
            "invitation_id": invitation_id,
            "message": f"Invitation sent to {body.email}",
            "expires_at": expires_at.isoformat()
        }
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error inviting team member: {e}")
        raise HTTPException(status_code=500, detail="Failed to send invitation")

@router.get("/companies/{company_id}/members")
async def get_team_members(company_id: int, user: AuthorizedUser) -> List[TeamMemberResponse]:
    """Get all team members for a company"""
    try:
        conn = await get_db_connection()
        
        # Check if user is a member of the company
        user_role = await get_user_company_role(user.sub, company_id, conn)
        if not user_role:
            raise HTTPException(status_code=403, detail="Access denied")
        
        # Get team members with user details from auth system
        members = await conn.fetch("""
            SELECT 
                tm.id, tm.user_id, tm.status, tm.joined_at, tm.last_active, tm.invited_by,
                rd.role_name, rd.role_description,
                u.email, u.name as display_name
            FROM team_memberships tm
            JOIN role_definitions rd ON tm.role_id = rd.id
            LEFT JOIN neon_auth.users_sync u ON tm.user_id = u.id
            WHERE tm.company_id = $1
            ORDER BY tm.joined_at
        """, company_id)
        
        await conn.close()
        
        return [
            TeamMemberResponse(
                id=member['id'],
                user_id=member['user_id'],
                email=member['email'],
                display_name=member['display_name'],
                role_name=member['role_name'],
                role_description=member['role_description'],
                status=member['status'],
                joined_at=member['joined_at'].isoformat(),
                last_active=member['last_active'].isoformat() if member['last_active'] else None,
                invited_by=member['invited_by']
            )
            for member in members
        ]
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error getting team members: {e}")
        raise HTTPException(status_code=500, detail="Failed to get team members")

@router.get("/companies/{company_id}/invitations")
async def get_pending_invitations(company_id: int, user: AuthorizedUser) -> List[InvitationResponse]:
    """Get all pending invitations for a company"""
    try:
        conn = await get_db_connection()
        
        # Check if user has team management permission
        if not await check_permission(user.sub, company_id, "team_management", conn):
            raise HTTPException(status_code=403, detail="Insufficient permissions")
        
        invitations = await conn.fetch("""
            SELECT ti.*, rd.role_name
            FROM team_invitations ti
            JOIN role_definitions rd ON ti.role_id = rd.id
            WHERE ti.company_id = $1 AND ti.status = 'pending'
            ORDER BY ti.invited_at DESC
        """, company_id)
        
        await conn.close()
        
        return [
            InvitationResponse(
                id=inv['id'],
                email=inv['email'],
                role_name=inv['role_name'],
                status=inv['status'],
                invited_by=inv['invited_by'],
                invited_at=inv['invited_at'].isoformat(),
                expires_at=inv['expires_at'].isoformat(),
                message=inv['message']
            )
            for inv in invitations
        ]
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error getting invitations: {e}")
        raise HTTPException(status_code=500, detail="Failed to get invitations")

@router.put("/companies/{company_id}/members/{member_id}/role")
async def update_member_role(company_id: int, member_id: int, body: UpdateMemberRoleRequest, user: AuthorizedUser) -> Dict[str, Any]:
    """Update a team member's role"""
    try:
        conn = await get_db_connection()
        
        # Check if user has team management permission
        if not await check_permission(user.sub, company_id, "team_management", conn):
            raise HTTPException(status_code=403, detail="Insufficient permissions")
        
        # Get member details
        member = await conn.fetchrow(
            "SELECT * FROM team_memberships WHERE id = $1 AND company_id = $2",
            member_id, company_id
        )
        if not member:
            raise HTTPException(status_code=404, detail="Team member not found")
        
        # Prevent changing your own role
        if member['user_id'] == user.sub:
            raise HTTPException(status_code=400, detail="Cannot change your own role")
        
        # Get new role ID
        new_role = await conn.fetchrow(
            "SELECT id FROM role_definitions WHERE role_name = $1", body.role_name
        )
        if not new_role:
            raise HTTPException(status_code=400, detail="Invalid role")
        
        # Update member role
        await conn.execute(
            "UPDATE team_memberships SET role_id = $1, updated_at = $2 WHERE id = $3",
            new_role['id'], datetime.now(), member_id
        )
        
        # Log audit action
        await log_audit_action(company_id, user.sub, "member_role_updated", {
            "member_user_id": member['user_id'],
            "new_role": body.role_name,
            "member_id": member_id
        }, conn)
        
        await conn.close()
        
        return {
            "success": True,
            "message": f"Member role updated to {body.role_name}"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error updating member role: {e}")
        raise HTTPException(status_code=500, detail="Failed to update member role")

@router.delete("/companies/{company_id}/members/{member_id}")
async def remove_team_member(company_id: int, member_id: int, user: AuthorizedUser) -> Dict[str, Any]:
    """Remove a team member from the company"""
    try:
        conn = await get_db_connection()
        
        # Check if user has team management permission
        if not await check_permission(user.sub, company_id, "team_management", conn):
            raise HTTPException(status_code=403, detail="Insufficient permissions")
        
        # Get member details
        member = await conn.fetchrow(
            "SELECT * FROM team_memberships WHERE id = $1 AND company_id = $2",
            member_id, company_id
        )
        if not member:
            raise HTTPException(status_code=404, detail="Team member not found")
        
        # Prevent removing yourself
        if member['user_id'] == user.sub:
            raise HTTPException(status_code=400, detail="Cannot remove yourself from the team")
        
        # Mark as inactive instead of deleting (for audit purposes)
        await conn.execute(
            "UPDATE team_memberships SET status = 'inactive', updated_at = $1 WHERE id = $2",
            datetime.now(), member_id
        )
        
        # Log audit action
        await log_audit_action(company_id, user.sub, "member_removed", {
            "member_user_id": member['user_id'],
            "member_id": member_id
        }, conn)
        
        await conn.close()
        
        return {
            "success": True,
            "message": "Team member removed successfully"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error removing team member: {e}")
        raise HTTPException(status_code=500, detail="Failed to remove team member")

@router.get("/role-definitions")
async def get_role_definitions(user: AuthorizedUser) -> List[RoleDefinitionResponse]:
    """Get all available role definitions"""
    try:
        conn = await get_db_connection()
        
        roles = await conn.fetch(
            "SELECT * FROM role_definitions ORDER BY role_name"
        )
        
        await conn.close()
        
        return [
            RoleDefinitionResponse(
                id=role['id'],
                role_name=role['role_name'],
                role_description=role['role_description'],
                permissions=role['permissions'] or {},
                is_system_role=role['is_system_role']
            )
            for role in roles
        ]
        
    except Exception as e:
        print(f"Error getting role definitions: {e}")
        raise HTTPException(status_code=500, detail="Failed to get role definitions")

# Company Profile Management
class UpdateCompanyProfileRequest(BaseModel):
    company_name: str
    company_domain: Optional[str] = None
    billing_email: Optional[str] = None
    max_team_members: int

@router.get("/companies/{company_id}/profile")
async def get_company_profile(company_id: int, user: AuthorizedUser) -> CompanyResponse:
    """Get company profile details"""
    try:
        conn = await get_db_connection()
        
        # Check if user is a member of the company
        user_role = await get_user_company_role(user.sub, company_id, conn)
        if not user_role:
            raise HTTPException(status_code=403, detail="Access denied")
        
        # Get company details
        company = await conn.fetchrow("""
            SELECT c.*, COUNT(tm.id) as member_count
            FROM companies c
            LEFT JOIN team_memberships tm ON c.id = tm.company_id AND tm.status = 'active'
            WHERE c.id = $1
            GROUP BY c.id
        """, company_id)
        
        if not company:
            raise HTTPException(status_code=404, detail="Company not found")
        
        await conn.close()
        
        return CompanyResponse(
            id=company['id'],
            company_name=company['company_name'],
            company_slug=company['company_slug'],
            company_domain=company['company_domain'],
            billing_email=company['billing_email'],
            subscription_tier=company['subscription_tier'],
            max_team_members=company['max_team_members'],
            created_by=company['created_by'],
            created_at=company['created_at'].isoformat(),
            updated_at=company['updated_at'].isoformat(),
            is_active=company['is_active'],
            sso_enabled=company['sso_enabled'],
            audit_logs_enabled=company['audit_logs_enabled'],
            api_access_enabled=company['api_access_enabled'],
            member_count=company['member_count'],
            current_user_role=user_role
        )
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error getting company profile: {e}")
        raise HTTPException(status_code=500, detail="Failed to get company profile")

@router.put("/companies/{company_id}/profile")
async def update_company_profile(company_id: int, body: UpdateCompanyProfileRequest, user: AuthorizedUser) -> CompanyResponse:
    """Update company profile (requires billing management permission)"""
    try:
        conn = await get_db_connection()
        
        # Check if user has billing management permission
        if not await check_permission(user.sub, company_id, "billing", conn):
            raise HTTPException(status_code=403, detail="Insufficient permissions to update company profile")
        
        # Check if company exists
        existing_company = await conn.fetchrow(
            "SELECT * FROM companies WHERE id = $1", company_id
        )
        if not existing_company:
            raise HTTPException(status_code=404, detail="Company not found")
        
        # Update company profile
        await conn.execute("""
            UPDATE companies 
            SET company_name = $1, company_domain = $2, billing_email = $3, 
                max_team_members = $4, updated_at = $5
            WHERE id = $6
        """, body.company_name, body.company_domain, body.billing_email, 
        body.max_team_members, datetime.now(), company_id)
        
        # Log audit action
        await log_audit_action(company_id, user.sub, "company_profile_updated", {
            "company_name": body.company_name,
            "company_domain": body.company_domain,
            "billing_email": body.billing_email,
            "max_team_members": body.max_team_members
        }, conn)
        
        # Get updated company details
        company = await conn.fetchrow("""
            SELECT c.*, COUNT(tm.id) as member_count
            FROM companies c
            LEFT JOIN team_memberships tm ON c.id = tm.company_id AND tm.status = 'active'
            WHERE c.id = $1
            GROUP BY c.id
        """, company_id)
        
        user_role = await get_user_company_role(user.sub, company_id, conn)
        
        await conn.close()
        
        return CompanyResponse(
            id=company['id'],
            company_name=company['company_name'],
            company_slug=company['company_slug'],
            company_domain=company['company_domain'],
            billing_email=company['billing_email'],
            subscription_tier=company['subscription_tier'],
            max_team_members=company['max_team_members'],
            created_by=company['created_by'],
            created_at=company['created_at'].isoformat(),
            updated_at=company['updated_at'].isoformat(),
            is_active=company['is_active'],
            sso_enabled=company['sso_enabled'],
            audit_logs_enabled=company['audit_logs_enabled'],
            api_access_enabled=company['api_access_enabled'],
            member_count=company['member_count'],
            current_user_role=user_role
        )
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error updating company profile: {e}")
        raise HTTPException(status_code=500, detail="Failed to update company profile")
