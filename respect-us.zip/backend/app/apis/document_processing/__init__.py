


from fastapi import APIRouter, UploadFile, File, HTTPException, BackgroundTasks
from pydantic import BaseModel
from typing import List, Optional, Dict, Any
import asyncpg
import databutton as db
from app.auth import AuthorizedUser
from app.env import Mode, mode
from datetime import datetime

# Import the document processor library
from app.libs.document_processor import (
    DocumentProcessor,
    process_uploaded_document,
    extract_document_metadata
)

router = APIRouter(prefix="/doc-processing")

# In-memory storage for processing status (in production, use Redis or database)
processing_status_store: Dict[str, Dict[str, Any]] = {}

# Models
class ProcessDocumentResponse(BaseModel):
    processing_id: str
    message: str
    estimated_completion: str
    supported_formats: List[str]

class ProcessingStatusResponse(BaseModel):
    processing_id: str
    status: str  # 'pending', 'processing', 'complete', 'failed'
    progress: int
    message: str
    result: Optional[Dict[str, Any]] = None
    errors: Optional[List[str]] = None
    started_at: Optional[str] = None
    completed_at: Optional[str] = None

class DocumentSection(BaseModel):
    section_id: str
    title: str
    content: str
    level: int
    parent_section_id: Optional[str] = None
    page_number: Optional[int] = None
    confidence_score: Optional[float] = None

class DocumentSectionsResponse(BaseModel):
    document_id: str
    sections: List[DocumentSection]
    total_sections: int
    processing_method: str

class CrossReference(BaseModel):
    reference_id: str
    source_text: str
    target_regulation: str
    target_section: Optional[str] = None
    reference_type: str  # 'cites', 'amends', 'repeals', 'references'
    confidence_score: float
    context: str

class CrossReferencesResponse(BaseModel):
    document_id: str
    cross_references: List[CrossReference]
    total_references: int

class BatchProcessRequest(BaseModel):
    document_ids: List[str]
    processing_options: Dict[str, Any] = {}

class BatchProcessResponse(BaseModel):
    batch_id: str
    document_count: int
    estimated_completion: str
    individual_processing_ids: List[str]

class SupportedFormat(BaseModel):
    format_type: str
    extensions: List[str]
    description: str
    ocr_supported: bool
    max_file_size_mb: int

class SupportedFormatsResponse(BaseModel):
    formats: List[SupportedFormat]
    total_formats: int

# Async function to process document
async def process_document_async(processing_id: str, file_content: bytes, 
                                content_type: str, filename: str) -> None:
    """Process document asynchronously and update status"""
    try:
        # Update status to processing
        processing_status_store[processing_id].update({
            'status': 'processing',
            'progress': 20,
            'message': 'Processing document content...'
        })
        
        # Process the document
        processor = DocumentProcessor()
        result = processor.process_document(file_content, content_type, filename)
        
        # Update progress for OCR stage if needed
        if result.requires_ocr:
            processing_status_store[processing_id].update({
                'progress': 60,
                'message': 'Performing OCR text extraction...'
            })
        
        # Convert result to serializable format
        result_dict = {
            'document_type': result.document_type.value,
            'text_content': result.text_content,
            'confidence_score': result.confidence_score,
            'processing_time': result.processing_time.total_seconds(),
            'sections': [
                {
                    'section_id': str(uuid.uuid4()),
                    'title': section.title,
                    'content': section.content,
                    'level': section.level,
                    'page_number': section.page_number
                }
                for section in result.sections
            ],
            'cross_references': [
                {
                    'reference_id': str(uuid.uuid4()),
                    'source_text': ref.source_text,
                    'target_regulation': ref.target_regulation,
                    'target_section': ref.target_section,
                    'reference_type': ref.reference_type,
                    'confidence_score': ref.confidence_score,
                    'context': ref.context
                }
                for ref in result.cross_references
            ],
            'metadata': result.metadata,
            'requires_ocr': result.requires_ocr,
            'errors': result.errors if result.errors else []
        }
        
        # Update status to complete
        processing_status_store[processing_id].update({
            'status': 'complete',
            'progress': 100,
            'message': 'Document processing completed successfully',
            'result': result_dict,
            'completed_at': datetime.utcnow().isoformat()
        })
        
    except Exception as e:
        # Update status to failed
        processing_status_store[processing_id].update({
            'status': 'failed',
            'progress': 0,
            'message': f'Processing failed: {str(e)}',
            'errors': [str(e)],
            'completed_at': datetime.utcnow().isoformat()
        })

@router.post("/process-document")
async def process_document(
    background_tasks: BackgroundTasks,
    file: UploadFile = File(...),
    user: AuthorizedUser = None
) -> ProcessDocumentResponse:
    """Upload and process a document with OCR and text extraction"""
    
    # Validate file size (50MB limit)
    max_size = 50 * 1024 * 1024  # 50MB
    file_content = await file.read()
    if len(file_content) > max_size:
        raise HTTPException(status_code=413, detail="File too large. Maximum size is 50MB.")
    
    # Generate processing ID
    processing_id = str(uuid.uuid4())
    
    # Initialize status tracking
    processing_status_store[processing_id] = {
        'processing_id': processing_id,
        'status': 'pending',
        'progress': 0,
        'message': 'Document uploaded, processing queued',
        'started_at': datetime.utcnow().isoformat(),
        'filename': file.filename
    }
    
    # Add background task for processing
    background_tasks.add_task(
        process_document_async,
        processing_id,
        file_content,
        file.content_type or 'application/octet-stream',
        file.filename or 'unknown'
    )
    
    return ProcessDocumentResponse(
        processing_id=processing_id,
        message="Document processing started",
        estimated_completion="1-3 minutes depending on document size and complexity",
        supported_formats=["PDF", "Word", "Images", "HTML", "XML"]
    )

@router.get("/processing-status/{processing_id}")
async def get_processing_status(processing_id: str) -> ProcessingStatusResponse:
    """Get the processing status for a document"""
    
    if processing_id not in processing_status_store:
        raise HTTPException(status_code=404, detail="Processing ID not found")
    
    status_data = processing_status_store[processing_id]
    
    return ProcessingStatusResponse(
        processing_id=processing_id,
        status=status_data['status'],
        progress=status_data['progress'],
        message=status_data['message'],
        result=status_data.get('result'),
        errors=status_data.get('errors'),
        started_at=status_data.get('started_at'),
        completed_at=status_data.get('completed_at')
    )

@router.get("/document/{document_id}/sections")
async def get_processed_document_sections(document_id: str) -> DocumentSectionsResponse:
    """Get hierarchical sections from a processed document"""
    
    # For now, return mock data. In production, retrieve from database
    # This would be populated after document processing
    sections = [
        DocumentSection(
            section_id="sect_1",
            title="Article 1 - Definitions",
            content="For the purposes of this regulation, the following definitions shall apply...",
            level=1,
            page_number=1,
            confidence_score=0.95
        ),
        DocumentSection(
            section_id="sect_2",
            title="Article 2 - Scope",
            content="This regulation applies to all export control items...",
            level=1,
            page_number=2,
            confidence_score=0.92
        ),
        DocumentSection(
            section_id="sect_2_1",
            title="2.1 - Dual-use items",
            content="Dual-use items shall be classified according to...",
            level=2,
            parent_section_id="sect_2",
            page_number=2,
            confidence_score=0.88
        )
    ]
    
    return DocumentSectionsResponse(
        document_id=document_id,
        sections=sections,
        total_sections=len(sections),
        processing_method="OCR with hierarchical parsing"
    )

@router.get("/document/{document_id}/cross-references")
async def get_document_cross_references_processing(document_id: str) -> CrossReferencesResponse:
    """Get cross-references extracted from a document"""
    
    # For now, return mock data. In production, retrieve from database
    cross_references = [
        CrossReference(
            reference_id="ref_1",
            source_text="in accordance with Regulation (EC) No 428/2009",
            target_regulation="Regulation (EC) No 428/2009",
            target_section="Article 3",
            reference_type="cites",
            confidence_score=0.94,
            context="Export authorization requirements must be met in accordance with Regulation (EC) No 428/2009 Article 3."
        ),
        CrossReference(
            reference_id="ref_2",
            source_text="as amended by Regulation (EU) 2021/821",
            target_regulation="Regulation (EU) 2021/821",
            reference_type="amends",
            confidence_score=0.91,
            context="The dual-use export control list as amended by Regulation (EU) 2021/821 shall apply."
        )
    ]
    
    return CrossReferencesResponse(
        document_id=document_id,
        cross_references=cross_references,
        total_references=len(cross_references)
    )

@router.post("/batch-process")
async def batch_process_documents(
    request: BatchProcessRequest,
    background_tasks: BackgroundTasks
) -> BatchProcessResponse:
    """Process multiple documents in batch"""
    
    batch_id = str(uuid.uuid4())
    processing_ids = []
    
    # For now, just generate processing IDs for each document
    # In production, this would iterate through actual documents
    for doc_id in request.document_ids:
        processing_id = str(uuid.uuid4())
        processing_ids.append(processing_id)
        
        # Initialize status for each document
        processing_status_store[processing_id] = {
            'processing_id': processing_id,
            'status': 'pending',
            'progress': 0,
            'message': f'Queued for batch processing (batch: {batch_id})',
            'started_at': datetime.utcnow().isoformat(),
            'batch_id': batch_id,
            'document_id': doc_id
        }
    
    return BatchProcessResponse(
        batch_id=batch_id,
        document_count=len(request.document_ids),
        estimated_completion=f"{len(request.document_ids) * 2}-{len(request.document_ids) * 4} minutes",
        individual_processing_ids=processing_ids
    )

@router.get("/supported-formats")
async def get_supported_formats() -> SupportedFormatsResponse:
    """Get list of supported document formats for processing"""
    
    formats = [
        SupportedFormat(
            format_type="PDF",
            extensions=[".pdf"],
            description="Portable Document Format (including scanned documents with OCR)",
            ocr_supported=True,
            max_file_size_mb=50
        ),
        SupportedFormat(
            format_type="Microsoft Word",
            extensions=[".docx", ".doc"],
            description="Microsoft Word documents with text extraction",
            ocr_supported=False,
            max_file_size_mb=25
        ),
        SupportedFormat(
            format_type="Images",
            extensions=[".jpg", ".jpeg", ".png", ".tiff", ".bmp"],
            description="Image files with OCR text extraction",
            ocr_supported=True,
            max_file_size_mb=20
        ),
        SupportedFormat(
            format_type="HTML",
            extensions=[".html", ".htm"],
            description="HyperText Markup Language documents",
            ocr_supported=False,
            max_file_size_mb=10
        ),
        SupportedFormat(
            format_type="XML",
            extensions=[".xml"],
            description="Extensible Markup Language documents",
            ocr_supported=False,
            max_file_size_mb=10
        )
    ]
    
    return SupportedFormatsResponse(
        formats=formats,
        total_formats=len(formats)
    )

# Cleanup endpoint to remove old processing records
@router.delete("/cleanup-processing-history")
async def cleanup_processing_history(hours_old: int = 24) -> Dict[str, Any]:
    """Clean up old processing status records"""
    
    from datetime import timedelta
    
    cutoff_time = datetime.utcnow() - timedelta(hours=hours_old)
    cleaned_count = 0
    
    # Remove old records
    keys_to_remove = []
    for processing_id, status_data in processing_status_store.items():
        if 'started_at' in status_data:
            started_at = datetime.fromisoformat(status_data['started_at'])
            if started_at < cutoff_time:
                keys_to_remove.append(processing_id)
    
    for key in keys_to_remove:
        del processing_status_store[key]
        cleaned_count += 1
    
    return {
        "message": f"Cleaned up {cleaned_count} old processing records",
        "remaining_records": len(processing_status_store),
        "cutoff_hours": hours_old
    }
