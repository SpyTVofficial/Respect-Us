import json
import uuid
from datetime import datetime
from typing import List, Optional, Dict, Any
import asyncpg
import databutton as db
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field
from app.auth import AuthorizedUser
from app.env import Mode, mode

router = APIRouter(prefix="/classification-workflows")

# Database connection helper
async def get_db_connection():
    if mode == Mode.PROD:
        database_url = db.secrets.get("DATABASE_URL_PROD")
    else:
        database_url = db.secrets.get("DATABASE_URL_DEV")
    return await asyncpg.connect(database_url)

# Pydantic Models
class TreeOrder(BaseModel):
    tree_id: str
    order: int
    tree_type: str = Field(pattern="^(introduction|classification)$")

class ConditionalRule(BaseModel):
    id: str
    condition: str
    action: str
    priority: int = 1

class WorkflowOutcome(BaseModel):
    id: str
    title: str
    description: str
    action: str

class ClassificationWorkflowCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=255)
    description: Optional[str] = None
    pricing_tier: Optional[str] = None
    introduction_tree_ids: List[str] = Field(default_factory=list)
    classification_tree_ids: List[str] = Field(default_factory=list)
    tree_orders: List[TreeOrder] = Field(default_factory=list)  # Global ordering for all trees
    status: str = Field(default="draft", pattern="^(draft|published|archived)$")
    conditional_rules: List[ConditionalRule] = Field(default_factory=list)
    outcomes: List[WorkflowOutcome] = Field(default_factory=list)
    trigger_condition: str = Field(default="automatic")
    workflow_type: Optional[str] = Field(default="classification", pattern="^(classification|sanctions)$")

class ClassificationWorkflowUpdate(BaseModel):
    name: Optional[str] = Field(None, min_length=1, max_length=255)
    description: Optional[str] = None
    pricing_tier: Optional[str] = None
    introduction_tree_ids: Optional[List[str]] = None
    classification_tree_ids: Optional[List[str]] = None
    tree_orders: Optional[List[TreeOrder]] = None  # Global ordering for all trees
    status: Optional[str] = Field(None, pattern="^(draft|published|archived)$")
    conditional_rules: Optional[List[ConditionalRule]] = None
    outcomes: Optional[List[WorkflowOutcome]] = None
    trigger_condition: Optional[str] = None
    global_order: Optional[int] = None  # Global ordering across all trees

class ClassificationTree(BaseModel):
    id: str
    name: str
    description: Optional[str]
    sequence_order: int
    tree_type: str = "classification"  # introduction or classification
    global_order: Optional[int] = None  # Global ordering across all trees

class IntroductionTree(BaseModel):
    id: str
    name: str
    description: Optional[str]
    sequence_order: int
    tree_type: str = "introduction"
    global_order: Optional[int] = None  # Global ordering across all trees

class ClassificationWorkflow(BaseModel):
    id: str
    name: str
    description: Optional[str]
    pricing_tier: Optional[str]
    introduction_tree_id: Optional[str]  # Deprecated - kept for backward compatibility
    introduction_tree_name: Optional[str]  # Deprecated - kept for backward compatibility
    created_by: str
    status: str
    created_at: datetime
    updated_at: datetime
    introduction_trees: List[IntroductionTree]
    classification_trees: List[ClassificationTree]
    conditional_rules: List[ConditionalRule] = Field(default_factory=list)
    outcomes: List[WorkflowOutcome] = Field(default_factory=list)
    trigger_condition: str = Field(default="automatic")
    workflow_type: Optional[str] = Field(default="classification", pattern="^(classification|sanctions)$")  # Add missing workflow_type field

class ClassificationWorkflowList(BaseModel):
    workflows: List[ClassificationWorkflow]
    total: int

# Admin APIs
@router.post("/admin/workflows")
async def create_workflow(workflow: ClassificationWorkflowCreate, user: AuthorizedUser) -> ClassificationWorkflow:
    """Create a new classification workflow (Admin only)"""
    async with get_db_connection() as conn:
        try:
            # Validate introduction trees exist if provided
            if workflow.introduction_tree_ids:
                intro_trees = await conn.fetch(
                    "SELECT id, name FROM introduction_trees WHERE id = ANY($1)",
                    [uuid.UUID(tree_id) for tree_id in workflow.introduction_tree_ids]
                )
                if len(intro_trees) != len(workflow.introduction_tree_ids):
                    raise HTTPException(status_code=404, detail="One or more introduction trees not found")
            
            # Validate all classification trees exist
            if workflow.classification_tree_ids:
                existing_trees = await conn.fetch(
                    "SELECT id FROM classification_trees WHERE id = ANY($1)",
                    [uuid.UUID(tree_id) for tree_id in workflow.classification_tree_ids]
                )
                if len(existing_trees) != len(workflow.classification_tree_ids):
                    raise HTTPException(status_code=404, detail="One or more classification trees not found")
            
            # Start transaction
            async with conn.transaction():
                # Create workflow
                workflow_id = uuid.uuid4()
                workflow_row = await conn.fetchrow("""
                    INSERT INTO classification_workflows 
                    (id, name, description, pricing_tier, created_by, status, trigger_condition, conditional_rules, outcomes, workflow_type)
                    VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
                    RETURNING *
                """, 
                    workflow_id,
                    workflow.name,
                    workflow.description,
                    workflow.pricing_tier,
                    user.sub,
                    workflow.status,
                    workflow.trigger_condition,
                    json.dumps([rule.model_dump() for rule in workflow.conditional_rules]),
                    json.dumps([outcome.model_dump() for outcome in workflow.outcomes]),
                    workflow.workflow_type
                )
                
                # Add introduction trees to workflow
                if workflow.introduction_tree_ids:
                    for i, tree_id in enumerate(workflow.introduction_tree_ids):
                        await conn.execute("""
                            INSERT INTO workflow_introduction_trees 
                            (workflow_id, introduction_tree_id, sequence_order)
                            VALUES ($1, $2, $3)
                        """, workflow_id, uuid.UUID(tree_id), i + 1)
                
                # Add classification trees to workflow
                if workflow.classification_tree_ids:
                    for i, tree_id in enumerate(workflow.classification_tree_ids):
                        await conn.execute("""
                            INSERT INTO workflow_classification_trees 
                            (workflow_id, classification_tree_id, sequence_order)
                            VALUES ($1, $2, $3)
                        """, workflow_id, uuid.UUID(tree_id), i + 1)
                
                # Add global ordering
                if workflow.tree_orders:
                    for order in workflow.tree_orders:
                        await conn.execute("""
                            INSERT INTO workflow_tree_orders 
                            (workflow_id, tree_id, global_order, tree_type)
                            VALUES ($1, $2, $3, $4)
                        """, workflow_id, uuid.UUID(order.tree_id), order.order, order.tree_type)
                
                # Add conditional rules
                if workflow.conditional_rules:
                    for rule in workflow.conditional_rules:
                        await conn.execute("""
                            INSERT INTO workflow_conditional_rules 
                            (workflow_id, rule_id, condition, action, priority)
                            VALUES ($1, $2, $3, $4, $5)
                        """, workflow_id, rule.id, rule.condition, rule.action, rule.priority)
                
                # Add outcomes
                if workflow.outcomes:
                    for outcome in workflow.outcomes:
                        await conn.execute("""
                            INSERT INTO workflow_outcomes 
                            (workflow_id, outcome_id, title, description, action)
                            VALUES ($1, $2, $3, $4, $5)
                        """, workflow_id, outcome.id, outcome.title, outcome.description, outcome.action)
            
            # Fetch and return complete workflow
            return await get_workflow_by_id(str(workflow_id), user)
            
        except Exception as e:
            if "not found" in str(e):
                raise e
            raise HTTPException(status_code=500, detail=f"Failed to create workflow: {str(e)}")

@router.get("/admin/workflows")
async def list_admin_workflows(workflow_type: Optional[str] = None, user: AuthorizedUser = AuthorizedUser) -> List[ClassificationWorkflow]:
    """List classification workflows for admin with optional type filtering"""
    conn = await get_db_connection()
    try:
        base_query = """
            SELECT id, name, description, status, pricing_tier,
                   introduction_tree_id, conditional_rules, outcomes, trigger_condition,
                   workflow_type, created_by, created_at, updated_at
            FROM classification_workflows
        """
        
        params = []
        if workflow_type:
            base_query += " WHERE workflow_type = $1"
            params.append(workflow_type)
        
        base_query += " ORDER BY name"
        
        rows = await conn.fetch(base_query, *params)
        
        workflows = []
        for row in rows:
            workflow = ClassificationWorkflow(
                id=str(row['id']),
                name=row['name'],
                description=row['description'] or "",
                status=row['status'],
                pricing_tier=row['pricing_tier'],
                introduction_tree_id=str(row['introduction_tree_id']) if row['introduction_tree_id'] else None,
                introduction_tree_name=None,  # Optional field
                created_by=row['created_by'],
                created_at=row['created_at'],
                updated_at=row['updated_at'],
                introduction_trees=[],  # Will be empty for list view
                classification_trees=[],  # Will be empty for list view
                conditional_rules=[],
                outcomes=[],
                trigger_condition=row['trigger_condition'] or "automatic",
                workflow_type=row['workflow_type']  # Add missing workflow_type field
            )
            workflows.append(workflow)
        
        return workflows
        
    except Exception as e:
        print(f"Error fetching workflows: {e}")
        raise HTTPException(status_code=500, detail="Failed to fetch workflows")
    finally:
        await conn.close()

@router.get("/admin/workflows/{workflow_id}")
async def get_workflow_by_id(workflow_id: str, user: AuthorizedUser) -> ClassificationWorkflow:
    """Get workflow by ID (Admin only)"""
    async with get_db_connection() as conn:
        try:
            # Get workflow details
            workflow_row = await conn.fetchrow("""
                SELECT cw.*, ct_intro.name as introduction_tree_name
                FROM classification_workflows cw
                LEFT JOIN classification_trees ct_intro ON cw.introduction_tree_id = ct_intro.id
                WHERE cw.id = $1
            """, uuid.UUID(workflow_id))
            
            if not workflow_row:
                raise HTTPException(status_code=404, detail="Workflow not found")
            
            # Get introduction trees for this workflow
            intro_trees_rows = await conn.fetch("""
                SELECT ct.id, ct.name, ct.description, wit.sequence_order
                FROM workflow_introduction_trees wit
                JOIN introduction_trees ct ON wit.introduction_tree_id = ct.id
                WHERE wit.workflow_id = $1
                ORDER BY wit.sequence_order
            """, uuid.UUID(workflow_id))
            
            introduction_trees = [
                IntroductionTree(
                    id=str(row['id']),
                    name=row['name'],
                    description=row['description'] or "",
                    assessment_criteria="",
                    regulatory_framework="",
                    sequence_order=row['sequence_order'] or 0,
                    tree_type="introduction",
                    global_order=row['sequence_order'] or 0
                )
                for row in intro_trees_rows
            ]
            
            # Get classification trees for this workflow
            class_trees_rows = await conn.fetch("""
                SELECT ct.id, ct.name, ct.description, wct.sequence_order
                FROM workflow_classification_trees wct
                JOIN classification_trees ct ON wct.classification_tree_id = ct.id
                WHERE wct.workflow_id = $1
                ORDER BY wct.sequence_order
            """, uuid.UUID(workflow_id))
            
            classification_trees = [
                ClassificationTree(
                    id=str(row['id']),
                    name=row['name'],
                    description=row['description'] or "",
                    assessment_criteria="",
                    regulatory_framework="",
                    sequence_order=row['sequence_order'] or 0,
                    tree_type="classification",
                    global_order=row['sequence_order'] or 0
                )
                for row in class_trees_rows
            ]
            
            # Parse conditional rules and outcomes
            conditional_rules = []
            if workflow_row['conditional_rules']:
                rules_data = json.loads(workflow_row['conditional_rules'])
                conditional_rules = [ConditionalRule(**rule) for rule in rules_data]
            
            outcomes = []
            if workflow_row['outcomes']:
                outcomes_data = json.loads(workflow_row['outcomes'])
                outcomes = [WorkflowOutcome(**outcome) for outcome in outcomes_data]
            
            return ClassificationWorkflow(
                id=str(workflow_row['id']),
                name=workflow_row['name'],
                description=workflow_row['description'] or "",
                pricing_tier=workflow_row['pricing_tier'],
                introduction_tree_id=str(workflow_row['introduction_tree_id']) if workflow_row['introduction_tree_id'] else None,
                introduction_tree_name=workflow_row['introduction_tree_name'],
                created_by=workflow_row['created_by'],
                status=workflow_row['status'],
                created_at=workflow_row['created_at'],
                updated_at=workflow_row['updated_at'],
                introduction_trees=introduction_trees,
                classification_trees=classification_trees,
                conditional_rules=conditional_rules,
                outcomes=outcomes,
                trigger_condition=workflow_row['trigger_condition'],
                workflow_type=workflow_row['workflow_type']  # Add missing workflow_type field
            )
            
        except HTTPException:
            raise
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Failed to get workflow: {str(e)}")

@router.put("/admin/workflows/{workflow_id}")
async def update_workflow(
    workflow_id: str, 
    workflow: ClassificationWorkflowUpdate, 
    user: AuthorizedUser
) -> dict:
    """Update a classification workflow (Admin only)"""
    print(f"🔧 UPDATE WORKFLOW called with ID: {workflow_id}")
    print(f"📝 Update data: {workflow.dict(exclude_unset=True)}")
    
    try:
        async with get_db_connection() as conn:
            # Check if workflow exists
            print(f"🔍 Looking for workflow with UUID: {workflow_id}")
            existing = await conn.fetchrow(
                "SELECT id FROM classification_workflows WHERE id = $1",
                uuid.UUID(workflow_id)
            )
            print(f"🎯 Query result: {existing}")
            
            if not existing:
                print(f"❌ Workflow not found in database!")
                # Let's check what workflows actually exist
                all_workflows = await conn.fetch("SELECT id, name FROM classification_workflows")
                print(f"📋 Available workflows: {[(str(w['id']), w['name']) for w in all_workflows]}")
                raise HTTPException(status_code=404, detail="Workflow not found")
            
            # Validate introduction trees if provided
            if workflow.introduction_tree_ids is not None:
                if workflow.introduction_tree_ids:  # Not empty list
                    intro_trees = await conn.fetch(
                        "SELECT id FROM introduction_trees WHERE id = ANY($1)",
                        [uuid.UUID(tree_id) for tree_id in workflow.introduction_tree_ids]
                    )
                    if len(intro_trees) != len(workflow.introduction_tree_ids):
                        raise HTTPException(status_code=404, detail="One or more introduction trees not found")
            
            # Validate classification trees if provided
            if workflow.classification_tree_ids is not None:
                if workflow.classification_tree_ids:  # Not empty list
                    existing_trees = await conn.fetch(
                        "SELECT id FROM classification_trees WHERE id = ANY($1)",
                        [uuid.UUID(tree_id) for tree_id in workflow.classification_tree_ids]
                    )
                    if len(existing_trees) != len(workflow.classification_tree_ids):
                        raise HTTPException(status_code=404, detail="One or more classification trees not found")
            
            # Start transaction
            async with conn.transaction():
                # Update workflow fields
                update_fields = []
                update_values = []
                param_count = 1
                
                for field, value in workflow.dict(exclude_unset=True).items():
                    if field not in ['introduction_tree_ids', 'classification_tree_ids', 'tree_orders']:  # Handle trees separately
                        update_fields.append(f"{field} = ${param_count}")
                        if field == 'introduction_tree_id' and value:
                            update_values.append(uuid.UUID(value))
                        elif field in ['conditional_rules', 'outcomes']:  # Convert lists to JSON
                            update_values.append(json.dumps(value) if value is not None else None)
                        else:
                            update_values.append(value)
                        param_count += 1
                
                if update_fields:
                    update_values.append(uuid.UUID(workflow_id))
                    await conn.execute(
                        f"UPDATE classification_workflows SET {', '.join(update_fields)} WHERE id = ${param_count}",
                        *update_values
                    )
                
                # Update introduction trees if provided
                if workflow.introduction_tree_ids is not None:
                    # Remove existing associations
                    await conn.execute(
                        "DELETE FROM workflow_introduction_trees WHERE workflow_id = $1",
                        uuid.UUID(workflow_id)
                    )
                    
                    # Add new associations
                    for i, tree_id in enumerate(workflow.introduction_tree_ids):
                        await conn.execute("""
                            INSERT INTO workflow_introduction_trees 
                            (workflow_id, introduction_tree_id, sequence_order)
                            VALUES ($1, $2, $3)
                        """, uuid.UUID(workflow_id), uuid.UUID(tree_id), i + 1)
                
                # Update classification trees if provided
                if workflow.classification_tree_ids is not None:
                    # Remove existing associations
                    await conn.execute(
                        "DELETE FROM workflow_classification_trees WHERE workflow_id = $1",
                        uuid.UUID(workflow_id)
                    )
                    
                    # Add new associations
                    for i, tree_id in enumerate(workflow.classification_tree_ids):
                        await conn.execute("""
                            INSERT INTO workflow_classification_trees 
                            (workflow_id, classification_tree_id, sequence_order)
                            VALUES ($1, $2, $3)
                        """, uuid.UUID(workflow_id), uuid.UUID(tree_id), i + 1)
            
            return {"message": "Workflow updated successfully"}
            
    except HTTPException:
        raise
    except Exception as e:
        print(f"❌ Error updating workflow: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to update workflow: {str(e)}")

@router.delete("/admin/workflows/{workflow_id}")
async def delete_workflow(workflow_id: str, user: AuthorizedUser) -> dict:
    """Delete a classification workflow (Admin only)"""
    async with get_db_connection() as conn:
        try:
            # Check if workflow exists
            existing = await conn.fetchrow(
                "SELECT id FROM classification_workflows WHERE id = $1",
                uuid.UUID(workflow_id)
            )
            if not existing:
                raise HTTPException(status_code=404, detail="Workflow not found")
            
            # Delete workflow (cascade will handle workflow_classification_trees)
            await conn.execute(
                "DELETE FROM classification_workflows WHERE id = $1",
                uuid.UUID(workflow_id)
            )
            
            return {"message": "Workflow deleted successfully"}
            
        except HTTPException:
            raise
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Failed to delete workflow: {str(e)}")

# User-facing APIs
@router.get("/workflows")
async def list_workflows(user: AuthorizedUser) -> ClassificationWorkflowList:
    """Get all classification workflows for the authenticated user"""
    conn = await get_db_connection()
    try:
        # Filter to only return classification workflows, not sanctions workflows
        rows = await conn.fetch("""
            SELECT * FROM classification_workflows 
            WHERE workflow_type = 'classification' AND status = 'published'
            ORDER BY created_at DESC
        """)
        
        workflows = []
        for row in rows:
            # For each workflow, get associated trees using correct table names
            intro_trees = await conn.fetch("""
                SELECT it.id, it.name, it.description, wit.sequence_order, 'introduction' as tree_type, wto.global_order
                FROM workflow_introduction_trees wit
                JOIN introduction_trees it ON wit.introduction_tree_id = it.id  
                LEFT JOIN workflow_tree_orders wto ON (wto.workflow_id = wit.workflow_id AND wto.tree_id = it.id AND wto.tree_type = 'introduction')
                WHERE wit.workflow_id = $1
                ORDER BY wit.sequence_order
            """, row['id'])
            
            classification_trees = await conn.fetch("""
                SELECT ct.id, ct.name, ct.description, wct.sequence_order, 'classification' as tree_type, wto.global_order
                FROM workflow_classification_trees wct
                JOIN classification_trees ct ON wct.classification_tree_id = ct.id
                LEFT JOIN workflow_tree_orders wto ON (wto.workflow_id = wct.workflow_id AND wto.tree_id = ct.id AND wto.tree_type = 'classification')
                WHERE wct.workflow_id = $1
                ORDER BY wct.sequence_order
            """, row['id'])
            
            workflows.append(ClassificationWorkflow(
                id=str(row['id']),
                name=row['name'],
                description=row['description'],
                pricing_tier=row['pricing_tier'],
                introduction_tree_id=str(intro_trees[0]['id']) if intro_trees else None,
                introduction_tree_name=intro_trees[0]['name'] if intro_trees else None,
                created_by=row['created_by'],
                status=row['status'],
                created_at=row['created_at'],
                updated_at=row['updated_at'],
                introduction_trees=[
                    IntroductionTree(
                        id=str(tree['id']),
                        name=tree['name'],
                        description=tree['description'],
                        sequence_order=tree['sequence_order'],
                        tree_type=tree['tree_type'],
                        global_order=tree['global_order']
                    ) for tree in intro_trees
                ],
                classification_trees=[
                    ClassificationTree(
                        id=str(tree['id']),
                        name=tree['name'],
                        description=tree['description'],
                        sequence_order=tree['sequence_order'],
                        tree_type=tree['tree_type'],
                        global_order=tree['global_order']
                    ) for tree in classification_trees
                ],
                conditional_rules=json.loads(row['conditional_rules']) if row['conditional_rules'] else [],
                outcomes=json.loads(row['outcomes']) if row['outcomes'] else [],
                trigger_condition=row['trigger_condition'] or "automatic",
                workflow_type=row['workflow_type'] or "classification"
            ))
        
        return ClassificationWorkflowList(
            workflows=workflows,
            total=len(workflows)
        )
    except Exception as e:
        print(f"Error fetching workflows: {e}")
        raise HTTPException(status_code=500, detail="Failed to fetch workflows")
    finally:
        await conn.close()

@router.get("/workflows/{workflow_id}")
async def get_published_workflow(workflow_id: str, user: AuthorizedUser) -> ClassificationWorkflow:
    """Get a published workflow by ID for users"""
    conn = await get_db_connection()
    try:
        workflow_row = await conn.fetchrow("""
            SELECT cw.*, ct_intro.name as introduction_tree_name
            FROM classification_workflows cw
            LEFT JOIN classification_trees ct_intro ON cw.introduction_tree_id = ct_intro.id
            WHERE cw.id = $1 AND cw.status = 'published'
        """, uuid.UUID(workflow_id))
        
        if not workflow_row:
            raise HTTPException(status_code=404, detail="Workflow not found or not published")
        
        # Get introduction trees for this workflow
        intro_trees_rows = await conn.fetch("""
            SELECT ct.id, ct.name, ct.description, wit.sequence_order
            FROM workflow_introduction_trees wit
            JOIN introduction_trees ct ON wit.introduction_tree_id = ct.id
            WHERE wit.workflow_id = $1
            ORDER BY wit.sequence_order
        """, uuid.UUID(workflow_id))
        
        introduction_trees = [
            IntroductionTree(
                id=str(row['id']),
                name=row['name'],
                description=row['description'] or "",
                sequence_order=row['sequence_order'] or 0,
                tree_type="introduction",
                global_order=row['sequence_order'] or 0
            )
            for row in intro_trees_rows
        ]
        
        # Get classification trees for this workflow
        class_trees_rows = await conn.fetch("""
            SELECT ct.id, ct.name, ct.description, wct.sequence_order
            FROM workflow_classification_trees wct
            JOIN classification_trees ct ON wct.classification_tree_id = ct.id
            WHERE wct.workflow_id = $1
            ORDER BY wct.sequence_order
        """, uuid.UUID(workflow_id))
        
        classification_trees = [
            ClassificationTree(
                id=str(row['id']),
                name=row['name'],
                description=row['description'] or "",
                sequence_order=row['sequence_order'] or 0,
                tree_type="classification",
                global_order=row['sequence_order'] or 0
            )
            for row in class_trees_rows
        ]
        
        # Parse conditional rules and outcomes
        conditional_rules = []
        if workflow_row['conditional_rules']:
            rules_data = json.loads(workflow_row['conditional_rules'])
            conditional_rules = [ConditionalRule(**rule) for rule in rules_data]
        
        outcomes = []
        if workflow_row['outcomes']:
            outcomes_data = json.loads(workflow_row['outcomes'])
            outcomes = [WorkflowOutcome(**outcome) for outcome in outcomes_data]
        
        return ClassificationWorkflow(
            id=str(workflow_row['id']),
            name=workflow_row['name'],
            description=workflow_row['description'] or "",
            pricing_tier=workflow_row['pricing_tier'],
            introduction_tree_id=str(workflow_row['introduction_tree_id']) if workflow_row['introduction_tree_id'] else None,
            introduction_tree_name=workflow_row['introduction_tree_name'],
            created_by=workflow_row['created_by'],
            status=workflow_row['status'],
            created_at=workflow_row['created_at'],
            updated_at=workflow_row['updated_at'],
            introduction_trees=introduction_trees,
            classification_trees=classification_trees,
            conditional_rules=conditional_rules,
            outcomes=outcomes,
            trigger_condition=workflow_row['trigger_condition'],
            workflow_type=workflow_row['workflow_type']  # Add missing workflow_type field
        )
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to get workflow: {str(e)}")
    finally:
        await conn.close()
