from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import List, Dict, Any, Optional

router = APIRouter(prefix="/widget-search")

class WidgetSearchRequest(BaseModel):
    widget_id: str
    search_query: str
    filters: Dict[str, Any] = {}
    limit: int = 20
    offset: int = 0

class SearchResult(BaseModel):
    id: str
    title: str
    subtitle: Optional[str] = None
    description: Optional[str] = None
    badge: Optional[str] = None
    badge_color: Optional[str] = None
    risk_level: Optional[str] = None
    details: Dict[str, Any] = {}
    confidence_score: float = 1.0

class WidgetSearchResponse(BaseModel):
    results: List[SearchResult]
    total_count: int
    search_time: float
    filters_applied: Dict[str, Any]
    suggestions: List[str] = []

@router.post("/search")
async def search_widget_data(request: WidgetSearchRequest):
    """Perform search using a custom widget configuration"""
    # This would integrate with the widget management system
    # to get the widget configuration and perform the actual search
    
    # For demo purposes, return mock results
    import time
    start_time = time.time()
    
    # Simulate search based on widget_id and query
    if "sanctions" in request.widget_id.lower() or request.widget_id == "sanctions_template":
        results = [
            SearchResult(
                id="sanctions_1",
                title=f"Entity matching '{request.search_query}'",
                subtitle="OFAC SDN List",
                description="Sanctioned entity under US export control regulations",
                badge="HIGH RISK",
                badge_color="red",
                risk_level="HIGH",
                details={
                    "jurisdiction": "United States",
                    "list_type": "SDN",
                    "date_added": "2023-06-15",
                    "aliases": ["Alternative Name 1", "Alternative Name 2"]
                },
                confidence_score=0.95
            ),
            SearchResult(
                id="sanctions_2",
                title=f"Related entity to '{request.search_query}'",
                subtitle="EU Sanctions List",
                description="Entity subject to European Union sanctions",
                badge="MEDIUM RISK",
                badge_color="orange",
                risk_level="MEDIUM",
                details={
                    "jurisdiction": "European Union",
                    "list_type": "Consolidated List",
                    "date_added": "2023-08-22",
                    "aliases": []
                },
                confidence_score=0.78
            )
        ]
    elif "product" in request.widget_id.lower() or request.widget_id == "products_template":
        results = [
            SearchResult(
                id="product_1",
                title=f"Product matching '{request.search_query}'",
                subtitle="EAR Category 9A001",
                description="Dual-use item subject to export controls",
                badge="LICENSE REQUIRED",
                badge_color="red",
                details={
                    "control_category": "EAR",
                    "license_exceptions": ["CIV", "TSR"],
                    "technical_notes": "Includes related software and technology",
                    "ccats": "9A001"
                },
                confidence_score=0.92
            ),
            SearchResult(
                id="product_2",
                title=f"Related technology for '{request.search_query}'",
                subtitle="ITAR Category VIII",
                description="Defense article requiring State Department license",
                badge="ITAR CONTROLLED",
                badge_color="purple",
                details={
                    "control_category": "ITAR",
                    "usml_category": "VIII",
                    "license_exemptions": [],
                    "technical_data": "Classified technical documentation required"
                },
                confidence_score=0.85
            )
        ]
    else:
        # Generic results for custom widgets
        results = [
            SearchResult(
                id="custom_1",
                title=f"Result for '{request.search_query}'",
                subtitle="Custom Widget Result",
                description="Custom search result based on widget configuration",
                badge="FOUND",
                badge_color="blue",
                details={
                    "category": "Custom",
                    "source": "Custom Data Source",
                    "last_updated": "2024-01-08"
                },
                confidence_score=0.80
            )
        ]
    
    search_time = (time.time() - start_time) * 1000  # Convert to milliseconds
    
    return WidgetSearchResponse(
        results=results,
        total_count=len(results),
        search_time=search_time,
        filters_applied=request.filters,
        suggestions=[
            f"Try searching for '{request.search_query} entity'",
            f"Search for '{request.search_query} products'",
            f"Look up '{request.search_query} regulations'"
        ]
    )

@router.get("/widget/{widget_id}/preview")
async def preview_widget_search(widget_id: str, query: str = "test"):
    """Preview search results for a widget without full configuration"""
    request = WidgetSearchRequest(
        widget_id=widget_id,
        search_query=query,
        limit=5
    )
    return await search_widget_data(request)
