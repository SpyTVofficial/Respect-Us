

from fastapi import APIRouter, HTTPException, BackgroundTasks
from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any
import asyncpg
import databutton as db
from app.auth import AuthorizedUser
from app.env import Mode, mode
from app.libs.auto_recharge_manager import AutoRechargeManager, AutoRechargeStatus, PaymentStatus
from datetime import datetime, date, timedelta

router = APIRouter(prefix="/auto-billing")
auto_recharge_manager = AutoRechargeManager()

# Database connection helper
async def get_db_connection():
    database_url = db.secrets.get("DATABASE_URL_DEV")
    return await asyncpg.connect(database_url)

# Pydantic models
class AutoRechargeConfigRequest(BaseModel):
    trigger_threshold: int = Field(..., ge=1, le=1000, description="Credits remaining to trigger recharge")
    recharge_amount: int = Field(..., ge=10, le=10000, description="Credits to purchase on recharge")
    max_recharges_per_month: int = Field(..., ge=1, le=50, description="Maximum recharges per month")
    payment_method_id: str = Field(..., description="Stripe payment method ID")
    is_enabled: bool = Field(default=True, description="Enable/disable auto-recharge")

class AutoRechargeConfigResponse(BaseModel):
    user_id: str
    trigger_threshold: int
    recharge_amount: int
    max_recharges_per_month: int
    payment_method_id: str
    is_enabled: bool
    status: str
    pause_reason: Optional[str]
    created_at: datetime
    updated_at: datetime

class AutoRechargeTransactionResponse(BaseModel):
    transaction_id: str
    credit_amount: int
    payment_amount: float
    currency: str
    status: str
    failure_reason: Optional[str]
    created_at: datetime
    completed_at: Optional[datetime]

class PaymentMethodRequest(BaseModel):
    payment_method_id: str
    set_as_default: bool = True

class InvoiceLineItem(BaseModel):
    description: str
    quantity: int
    unit_price: float
    total_price: float

class EnterpriseInvoiceRequest(BaseModel):
    credit_amount: int = Field(..., ge=100, description="Minimum 100 credits for enterprise invoices")
    line_items: List[InvoiceLineItem]
    payment_terms: str = Field(default="Net 30", description="Payment terms")
    notes: Optional[str] = None

class EnterpriseInvoiceResponse(BaseModel):
    invoice_id: str
    invoice_number: str
    total_amount: float
    net_amount: float
    vat_amount: float
    currency: str
    status: str
    due_date: date
    line_items: List[Dict[str, Any]]
    created_at: datetime

# Auto-recharge configuration endpoints
@router.post("/auto-recharge/setup", response_model=dict)
async def setup_auto_recharge(request: AutoRechargeConfigRequest, user: AuthorizedUser):
    """
    Set up auto-recharge configuration for the user
    """
    try:
        config_dict = request.dict()
        result = await auto_recharge_manager.setup_auto_recharge(user.sub, config_dict)
        return result
    except Exception as e:
        print(f"Error setting up auto-recharge: {e}")
        raise HTTPException(status_code=500, detail="Failed to setup auto-recharge")

@router.get("/auto-recharge/config", response_model=Optional[AutoRechargeConfigResponse])
async def get_auto_recharge_config(user: AuthorizedUser):
    """
    Get user's auto-recharge configuration
    """
    try:
        config = await auto_recharge_manager.get_auto_recharge_config(user.sub)
        return config
    except Exception as e:
        print(f"Error getting auto-recharge config: {e}")
        raise HTTPException(status_code=500, detail="Failed to get auto-recharge config")

@router.patch("/auto-recharge/toggle", response_model=dict)
async def toggle_auto_recharge(user: AuthorizedUser, enabled: bool = True):
    """
    Enable or disable auto-recharge
    """
    conn = await get_db_connection()
    try:
        await conn.execute(
            "UPDATE auto_recharge_config SET is_enabled = $1, updated_at = $2 WHERE user_id = $3",
            enabled, datetime.now(), user.sub
        )
        return {"status": "success", "message": f"Auto-recharge {'enabled' if enabled else 'disabled'}"}
    except Exception as e:
        print(f"Error toggling auto-recharge: {e}")
        raise HTTPException(status_code=500, detail="Failed to toggle auto-recharge")
    finally:
        await conn.close()

@router.post("/auto-recharge/trigger", response_model=dict)
async def manual_trigger_recharge(user: AuthorizedUser, background_tasks: BackgroundTasks):
    """
    Manually trigger an auto-recharge (for testing or immediate need)
    """
    try:
        result = await auto_recharge_manager.check_and_trigger_recharge(user.sub)
        if result:
            return result
        else:
            return {"status": "no_action", "message": "Auto-recharge not needed or not configured"}
    except Exception as e:
        print(f"Error triggering manual recharge: {e}")
        raise HTTPException(status_code=500, detail="Failed to trigger recharge")

@router.get("/auto-recharge/history", response_model=List[AutoRechargeTransactionResponse])
async def get_auto_recharge_history(user: AuthorizedUser, limit: int = 50):
    """
    Get user's auto-recharge transaction history
    """
    try:
        history = await auto_recharge_manager.get_auto_recharge_history(user.sub, limit)
        return history
    except Exception as e:
        print(f"Error getting auto-recharge history: {e}")
        raise HTTPException(status_code=500, detail="Failed to get auto-recharge history")

# Payment method management
@router.post("/payment-methods/add", response_model=dict)
async def add_payment_method(request: PaymentMethodRequest, user: AuthorizedUser):
    """
    Add or update payment method for the user
    """
    conn = await get_db_connection()
    try:
        # Update or create Stripe customer record
        await conn.execute(
            """
            INSERT INTO stripe_customers (user_id, default_payment_method_id, updated_at)
            VALUES ($1, $2, $3)
            ON CONFLICT (user_id) 
            DO UPDATE SET 
                default_payment_method_id = $2,
                updated_at = $3
            """,
            user.sub, request.payment_method_id, datetime.now()
        )
        
        return {
            "status": "success", 
            "message": "Payment method added successfully",
            "payment_method_id": request.payment_method_id
        }
    except Exception as e:
        print(f"Error adding payment method: {e}")
        raise HTTPException(status_code=500, detail="Failed to add payment method")
    finally:
        await conn.close()

@router.get("/payment-methods", response_model=dict)
async def get_payment_methods(user: AuthorizedUser):
    """
    Get user's saved payment methods
    """
    conn = await get_db_connection()
    try:
        customer = await conn.fetchrow(
            "SELECT * FROM stripe_customers WHERE user_id = $1",
            user.sub
        )
        
        if customer:
            return {
                "default_payment_method_id": customer['default_payment_method_id'],
                "payment_methods": customer['payment_methods'] or [],
                "has_payment_method": bool(customer['default_payment_method_id'])
            }
        else:
            return {
                "default_payment_method_id": None,
                "payment_methods": [],
                "has_payment_method": False
            }
    except Exception as e:
        print(f"Error getting payment methods: {e}")
        raise HTTPException(status_code=500, detail="Failed to get payment methods")
    finally:
        await conn.close()

# Enterprise invoice generation
@router.post("/enterprise/generate-invoice", response_model=EnterpriseInvoiceResponse)
async def generate_enterprise_invoice(request: EnterpriseInvoiceRequest, user: AuthorizedUser):
    """
    Generate an enterprise invoice for bulk credit purchase
    """
    conn = await get_db_connection()
    try:
        # Get customer details
        customer = await conn.fetchrow(
            "SELECT * FROM customer_details WHERE user_id = $1",
            user.sub
        )
        
        if not customer:
            raise HTTPException(status_code=400, detail="Customer details not found. Please complete your profile first.")
        
        # Calculate totals
        total_net = sum(item.total_price for item in request.line_items)
        vat_rate = 0.19 if customer['country'] in ['DE', 'Germany'] else 0.0  # Simplified VAT logic
        vat_amount = total_net * vat_rate
        total_gross = total_net + vat_amount
        
        # Generate invoice ID and number
        invoice_id = f"INV_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{user.sub[:8]}"
        invoice_number = f"INV-{datetime.now().strftime('%Y%m')}-{await conn.fetchval('SELECT COUNT(*) FROM enterprise_invoices') + 1:04d}"
        
        # Calculate due date (30 days default)
        due_date = datetime.now().date()
        if "Net 14" in request.payment_terms:
            due_date = (datetime.now() + timedelta(days=14)).date()
        elif "Net 30" in request.payment_terms:
            due_date = (datetime.now() + timedelta(days=30)).date()
        elif "Net 60" in request.payment_terms:
            due_date = (datetime.now() + timedelta(days=60)).date()
        
        # Save invoice
        await conn.execute(
            """
            INSERT INTO enterprise_invoices 
            (invoice_id, user_id, customer_id, invoice_number, total_amount, net_amount, 
             vat_amount, vat_rate, due_date, line_items, payment_terms, notes, status)
            VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13)
            """,
            invoice_id, user.sub, customer['customer_id'], invoice_number,
            total_gross, total_net, vat_amount, vat_rate, due_date,
            [item.dict() for item in request.line_items], request.payment_terms,
            request.notes, 'draft'
        )
        
        return EnterpriseInvoiceResponse(
            invoice_id=invoice_id,
            invoice_number=invoice_number,
            total_amount=total_gross,
            net_amount=total_net,
            vat_amount=vat_amount,
            currency="EUR",
            status="draft",
            due_date=due_date,
            line_items=[item.dict() for item in request.line_items],
            created_at=datetime.now()
        )
        
    except Exception as e:
        print(f"Error generating enterprise invoice: {e}")
        raise HTTPException(status_code=500, detail="Failed to generate invoice")
    finally:
        await conn.close()

@router.get("/enterprise/invoices", response_model=List[EnterpriseInvoiceResponse])
async def get_enterprise_invoices(user: AuthorizedUser, status: Optional[str] = None):
    """
    Get user's enterprise invoices
    """
    conn = await get_db_connection()
    try:
        query = "SELECT * FROM enterprise_invoices WHERE user_id = $1"
        params = [user.sub]
        
        if status:
            query += " AND status = $2"
            params.append(status)
        
        query += " ORDER BY created_at DESC"
        
        invoices = await conn.fetch(query, *params)
        return [dict(invoice) for invoice in invoices]
        
    except Exception as e:
        print(f"Error getting enterprise invoices: {e}")
        raise HTTPException(status_code=500, detail="Failed to get invoices")
    finally:
        await conn.close()

# Payment failure handling
@router.get("/payment-failures", response_model=List[dict])
async def get_payment_failures(user: AuthorizedUser):
    """
    Get user's payment failures that need attention
    """
    conn = await get_db_connection()
    try:
        failures = await conn.fetch(
            """
            SELECT * FROM payment_failures 
            WHERE user_id = $1 AND resolved_at IS NULL 
            ORDER BY created_at DESC
            """,
            user.sub
        )
        return [dict(failure) for failure in failures]
        
    except Exception as e:
        print(f"Error getting payment failures: {e}")
        raise HTTPException(status_code=500, detail="Failed to get payment failures")
    finally:
        await conn.close()

@router.post("/payment-failures/{failure_id}/retry", response_model=dict)
async def retry_failed_payment(failure_id: int, user: AuthorizedUser):
    """
    Retry a failed payment
    """
    conn = await get_db_connection()
    try:
        # Get failure details
        failure = await conn.fetchrow(
            "SELECT * FROM payment_failures WHERE id = $1 AND user_id = $2",
            failure_id, user.sub
        )
        
        if not failure:
            raise HTTPException(status_code=404, detail="Payment failure not found")
        
        if failure['retry_count'] >= failure['max_retries']:
            raise HTTPException(status_code=400, detail="Maximum retry attempts exceeded")
        
        # Trigger retry via auto-recharge system
        result = await auto_recharge_manager.check_and_trigger_recharge(user.sub)
        
        # Update retry count
        await conn.execute(
            "UPDATE payment_failures SET retry_count = retry_count + 1 WHERE id = $1",
            failure_id
        )
        
        return {
            "status": "retry_initiated",
            "message": "Payment retry initiated",
            "result": result
        }
        
    except Exception as e:
        print(f"Error retrying payment: {e}")
        raise HTTPException(status_code=500, detail="Failed to retry payment")
    finally:
        await conn.close()
