

from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel, EmailStr
from app.auth.user import get_authorized_user
import asyncpg
import databutton as db
from app.env import Mode, mode
from datetime import datetime
from typing import Optional

router = APIRouter()

# Database connection
async def get_db_connection():
    """Get database connection based on environment"""
    if mode == Mode.PROD:
        database_url = db.secrets.get("DATABASE_URL_PROD")
    else:
        database_url = db.secrets.get("DATABASE_URL_DEV")
    return await asyncpg.connect(database_url)

class UserProfileRequest(BaseModel):
    company_name: str
    contact_person: str
    email: EmailStr
    phone: Optional[str] = None
    billing_address: str
    city: str
    postal_code: str
    country: str
    tax_id: Optional[str] = None
    vat_number: Optional[str] = None

class UserProfileResponse(BaseModel):
    id: int
    user_id: str
    company_name: str
    contact_person: str
    email: str
    phone: Optional[str]
    billing_address: str
    city: str
    postal_code: str
    country: str
    tax_id: Optional[str]
    vat_number: Optional[str]
    created_at: str
    updated_at: str

@router.post("/save-user-profile")
async def save_user_profile(body: UserProfileRequest, user=Depends(get_authorized_user)) -> dict:
    """Save or update user business profile information"""
    try:
        conn = await get_db_connection()
        
        # Check if profile already exists
        existing_query = "SELECT id FROM user_profiles WHERE user_id = $1"
        existing_profile = await conn.fetchval(existing_query, user.sub)
        
        now = datetime.utcnow()
        
        if existing_profile:
            # Update existing profile
            update_query = """
                UPDATE user_profiles 
                SET company_name = $2, contact_person = $3, email = $4, phone = $5,
                    billing_address = $6, city = $7, postal_code = $8, country = $9,
                    tax_id = $10, vat_number = $11, updated_at = $12
                WHERE user_id = $1
                RETURNING id
            """
            
            profile_id = await conn.fetchval(
                update_query,
                user.sub, body.company_name, body.contact_person, body.email,
                body.phone, body.billing_address, body.city, body.postal_code,
                body.country, body.tax_id, body.vat_number, now
            )
            
            print(f"Updated profile {profile_id} for user {user.sub}")
        else:
            # Create new profile
            insert_query = """
                INSERT INTO user_profiles 
                (user_id, company_name, contact_person, email, phone, billing_address,
                 city, postal_code, country, tax_id, vat_number, created_at, updated_at)
                VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13)
                RETURNING id
            """
            
            profile_id = await conn.fetchval(
                insert_query,
                user.sub, body.company_name, body.contact_person, body.email,
                body.phone, body.billing_address, body.city, body.postal_code,
                body.country, body.tax_id, body.vat_number, now, now
            )
            
            print(f"Created new profile {profile_id} for user {user.sub}")
        
        await conn.close()
        
        return {
            "success": True,
            "profile_id": profile_id,
            "message": "Profile saved successfully"
        }
        
    except Exception as e:
        print(f"Error saving user profile: {e}")
        raise HTTPException(status_code=500, detail="Failed to save user profile")

@router.get("/get-user-profile")
async def get_user_profile(user=Depends(get_authorized_user)) -> UserProfileResponse:
    """Get user business profile information"""
    try:
        conn = await get_db_connection()
        
        query = """
            SELECT id, user_id, company_name, contact_person, email, phone,
                   billing_address, city, postal_code, country, tax_id, vat_number,
                   created_at, updated_at
            FROM user_profiles 
            WHERE user_id = $1
        """
        
        profile = await conn.fetchrow(query, user.sub)
        await conn.close()
        
        if not profile:
            raise HTTPException(status_code=404, detail="User profile not found")
        
        return UserProfileResponse(
            id=profile['id'],
            user_id=profile['user_id'],
            company_name=profile['company_name'],
            contact_person=profile['contact_person'],
            email=profile['email'],
            phone=profile['phone'],
            billing_address=profile['billing_address'],
            city=profile['city'],
            postal_code=profile['postal_code'],
            country=profile['country'],
            tax_id=profile['tax_id'],
            vat_number=profile['vat_number'],
            created_at=profile['created_at'].isoformat() if profile['created_at'] else '',
            updated_at=profile['updated_at'].isoformat() if profile['updated_at'] else ''
        )
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error getting user profile: {e}")
        raise HTTPException(status_code=500, detail="Failed to get user profile")

@router.delete("/delete-user-profile")
async def delete_user_profile(user=Depends(get_authorized_user)) -> dict:
    """Delete user business profile information"""
    try:
        conn = await get_db_connection()
        
        delete_query = "DELETE FROM user_profiles WHERE user_id = $1 RETURNING id"
        deleted_id = await conn.fetchval(delete_query, user.sub)
        
        await conn.close()
        
        if not deleted_id:
            raise HTTPException(status_code=404, detail="User profile not found")
        
        print(f"Deleted profile {deleted_id} for user {user.sub}")
        
        return {
            "success": True,
            "message": "Profile deleted successfully"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error deleting user profile: {e}")
        raise HTTPException(status_code=500, detail="Failed to delete user profile")
