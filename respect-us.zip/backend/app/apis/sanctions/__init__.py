


from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import List, Optional, Dict, Any
import asyncpg
import databutton as db
from app.auth import AuthorizedUser
from app.env import Mode, mode
import json
from datetime import datetime
import uuid
from app.libs.credit_wrapper import consume_credits_for_action

router = APIRouter(prefix="/sanctions")

# Database connection
async def get_db_connection():
    """Get database connection based on environment"""
    if mode == Mode.PROD:
        database_url = db.secrets.get("DATABASE_URL_PROD")
    else:
        database_url = db.secrets.get("DATABASE_URL_DEV")
    
    return await asyncpg.connect(database_url)

# ============================================================================
# Data Models
# ============================================================================

class SanctionsTreeCreate(BaseModel):
    name: str
    description: str
    jurisdiction: str
    category: str
    is_introduction_template: Optional[bool] = False
    introduction_tree_id: Optional[str] = None

class SanctionsTree(BaseModel):
    id: str
    name: str
    description: str
    jurisdiction: str
    category: str
    version: str
    status: str
    created_by: str
    created_at: datetime
    updated_at: datetime
    published_at: Optional[datetime] = None
    introduction_tree_id: Optional[str] = None
    is_introduction_template: bool

class SanctionsTreeUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    jurisdiction: Optional[str] = None
    category: Optional[str] = None
    status: Optional[str] = None

class SanctionsNodeCreate(BaseModel):
    node_key: str
    title: str
    description: str
    question_text: Optional[str] = None
    question_type: str = 'multiple_choice'
    parent_node_id: Optional[str] = None
    display_order: int = 0
    is_root: bool = False
    notes: Optional[str] = None
    metadata: Optional[dict] = None

class SanctionsNode(BaseModel):
    id: str
    tree_id: str
    node_key: str
    title: str
    description: str
    question_text: Optional[str] = None
    question_type: Optional[str] = None
    parent_node_id: Optional[str] = None
    display_order: int
    is_root: bool
    notes: Optional[str] = None
    metadata: Optional[dict] = None
    created_at: datetime
    updated_at: datetime
    children: List['SanctionsNode'] = []

class SanctionsNodeUpdate(BaseModel):
    node_key: Optional[str] = None
    title: Optional[str] = None
    description: Optional[str] = None
    question_text: Optional[str] = None
    question_type: Optional[str] = None
    parent_node_id: Optional[str] = None
    display_order: Optional[int] = None
    is_root: Optional[bool] = None
    notes: Optional[str] = None
    metadata: Optional[dict] = None

class SanctionsNodeOptionCreate(BaseModel):
    option_text: str
    option_value: str
    routing_rule: Optional[str] = None
    regulatory_notes: Optional[str] = None
    display_order: int = 0
    note: Optional[str] = None

class SanctionsNodeOption(BaseModel):
    id: str
    node_id: str
    option_text: str
    option_value: str
    routing_rule: Optional[str] = None
    regulatory_notes: Optional[str] = None
    display_order: int
    note: Optional[str] = None
    created_at: datetime
    updated_at: datetime

class SanctionsNodeOptionUpdate(BaseModel):
    option_text: Optional[str] = None
    option_value: Optional[str] = None
    routing_rule: Optional[str] = None
    regulatory_notes: Optional[str] = None
    display_order: Optional[int] = None
    note: Optional[str] = None

class SanctionsAssessmentRequest(BaseModel):
    tree_id: str
    jurisdiction: str
    entity_name: str
    entity_type: str  # 'individual', 'entity', 'vessel', etc.
    additional_details: Optional[dict] = None

class SanctionsAssessmentResult(BaseModel):
    assessment_id: str
    tree_id: str
    jurisdiction: str
    entity_name: str
    sanctions_applicable: bool
    risk_level: str  # 'low', 'medium', 'high', 'prohibited'
    applicable_sanctions: List[str]
    reasoning: str
    regulatory_notes: Optional[str] = None
    assessment_path: List[dict]  # The path taken through the tree
    created_at: datetime

# Update forward reference
SanctionsNode.model_rebuild()

# ============================================================================
# Admin Endpoints - Sanctions Trees
# ============================================================================

@router.get("/admin/trees", response_model=List[SanctionsTree])
async def list_sanctions_trees(user: AuthorizedUser):
    """List all sanctions trees for admin management"""
    conn = await get_db_connection()
    try:
        rows = await conn.fetch("""
            SELECT id, name, description, jurisdiction, category, version, status,
                   created_by, created_at, updated_at, published_at, introduction_tree_id, is_introduction_template
            FROM sanctions_trees
            ORDER BY created_at DESC
        """)

        trees = [
            SanctionsTree(
                id=str(row['id']),
                name=row['name'],
                description=row['description'],
                jurisdiction=row['jurisdiction'],
                category=row['category'],
                version=row['version'],
                status=row['status'],
                created_by=row['created_by'],
                created_at=row['created_at'],
                updated_at=row['updated_at'],
                published_at=row['published_at'],
                introduction_tree_id=str(row['introduction_tree_id']) if row['introduction_tree_id'] else None,
                is_introduction_template=row['is_introduction_template']
            )
            for row in rows
        ]
        return trees
    finally:
        await conn.close()

@router.post("/admin/trees", response_model=SanctionsTree)
async def create_sanctions_tree(tree_data: SanctionsTreeCreate, user: AuthorizedUser):
    """Create a new sanctions tree"""
    conn = await get_db_connection()
    try:
        row = await conn.fetchrow("""
            INSERT INTO sanctions_trees (name, description, jurisdiction, category, created_by, introduction_tree_id, is_introduction_template)
            VALUES ($1, $2, $3, $4, $5, $6, $7)
            RETURNING id, name, description, jurisdiction, category, version, status,
                      created_by, created_at, updated_at, published_at, introduction_tree_id, is_introduction_template
        """, tree_data.name, tree_data.description, tree_data.jurisdiction, 
             tree_data.category, user.sub, tree_data.introduction_tree_id, tree_data.is_introduction_template)

        return SanctionsTree(
            id=str(row['id']),
            name=row['name'],
            description=row['description'],
            jurisdiction=row['jurisdiction'],
            category=row['category'],
            version=row['version'],
            status=row['status'],
            created_by=row['created_by'],
            created_at=row['created_at'],
            updated_at=row['updated_at'],
            published_at=row['published_at'],
            introduction_tree_id=str(row['introduction_tree_id']) if row['introduction_tree_id'] else None,
            is_introduction_template=row['is_introduction_template']
        )
    finally:
        await conn.close()

@router.get("/admin/trees/{tree_id}", response_model=SanctionsTree)
async def get_sanctions_tree(tree_id: str, user: AuthorizedUser):
    """Get a specific sanctions tree"""
    conn = await get_db_connection()
    try:
        row = await conn.fetchrow("""
            SELECT id, name, description, jurisdiction, category, version, status,
                   created_by, created_at, updated_at, published_at, introduction_tree_id, is_introduction_template
            FROM sanctions_trees
            WHERE id = $1
        """, uuid.UUID(tree_id))

        if not row:
            raise HTTPException(status_code=404, detail="Sanctions tree not found")

        return SanctionsTree(
            id=str(row['id']),
            name=row['name'],
            description=row['description'],
            jurisdiction=row['jurisdiction'],
            category=row['category'],
            version=row['version'],
            status=row['status'],
            created_by=row['created_by'],
            created_at=row['created_at'],
            updated_at=row['updated_at'],
            published_at=row['published_at'],
            introduction_tree_id=str(row['introduction_tree_id']) if row['introduction_tree_id'] else None,
            is_introduction_template=row['is_introduction_template']
        )
    finally:
        await conn.close()

@router.put("/admin/trees/{tree_id}", response_model=SanctionsTree)
async def update_sanctions_tree(tree_id: str, tree_update: SanctionsTreeUpdate, user: AuthorizedUser):
    """Update a sanctions tree"""
    conn = await get_db_connection()
    try:
        # Validate UUID format
        try:
            tree_uuid = uuid.UUID(tree_id)
        except ValueError:
            raise HTTPException(status_code=400, detail="Invalid tree ID format")
            
        # Check if tree exists
        existing = await conn.fetchrow("SELECT id FROM sanctions_trees WHERE id = $1", tree_uuid)
        if not existing:
            raise HTTPException(status_code=404, detail="Sanctions tree not found")

        # Build update query dynamically
        update_fields = []
        update_values = []
        param_count = 1

        for field, value in tree_update.dict(exclude_unset=True).items():
            if value is not None:
                update_fields.append(f"{field} = ${param_count}")
                update_values.append(value)
                param_count += 1

        if update_fields:
            update_fields.append(f"updated_at = ${param_count}")
            update_values.append(datetime.utcnow())
            update_values.append(tree_uuid)

            query = f"""
                UPDATE sanctions_trees 
                SET {', '.join(update_fields)}
                WHERE id = ${param_count + 1}
                RETURNING id, name, description, jurisdiction, category, version, status,
                          created_by, created_at, updated_at, published_at, introduction_tree_id, is_introduction_template
            """
            
            row = await conn.fetchrow(query, *update_values)
        else:
            # No updates, just return current state
            row = await conn.fetchrow("""
                SELECT id, name, description, jurisdiction, category, version, status,
                       created_by, created_at, updated_at, published_at, introduction_tree_id, is_introduction_template
                FROM sanctions_trees WHERE id = $1
            """, tree_uuid)

        return SanctionsTree(
            id=str(row['id']),
            name=row['name'],
            description=row['description'],
            jurisdiction=row['jurisdiction'],
            category=row['category'],
            version=row['version'],
            status=row['status'],
            created_by=row['created_by'],
            created_at=row['created_at'],
            updated_at=row['updated_at'],
            published_at=row['published_at'],
            introduction_tree_id=str(row['introduction_tree_id']) if row['introduction_tree_id'] else None,
            is_introduction_template=row['is_introduction_template']
        )
    finally:
        await conn.close()

@router.delete("/admin/trees/{tree_id}")
async def delete_sanctions_tree(tree_id: str, user: AuthorizedUser):
    """Delete a sanctions tree"""
    conn = await get_db_connection()
    try:
        # Check if tree exists
        existing = await conn.fetchrow("SELECT id FROM sanctions_trees WHERE id = $1", uuid.UUID(tree_id))
        if not existing:
            raise HTTPException(status_code=404, detail="Sanctions tree not found")

        # Delete tree (cascade will handle related nodes)
        await conn.execute("DELETE FROM sanctions_trees WHERE id = $1", uuid.UUID(tree_id))
        
        return {"message": "Sanctions tree deleted successfully"}
    finally:
        await conn.close()

@router.post("/admin/trees/{tree_id}/duplicate", response_model=SanctionsTree)
async def duplicate_sanctions_tree(tree_id: str, user: AuthorizedUser):
    """Duplicate a sanctions tree with all its nodes and options"""
    conn = await get_db_connection()
    try:
        # Get original tree
        original_tree = await conn.fetchrow("""
            SELECT name, description, jurisdiction, category, introduction_tree_id, is_introduction_template
            FROM sanctions_trees WHERE id = $1
        """, uuid.UUID(tree_id))
        
        if not original_tree:
            raise HTTPException(status_code=404, detail="Sanctions tree not found")
        
        # Create new tree with "Copy of" prefix
        new_tree_name = f"Copy of {original_tree['name']}"
        
        new_tree = await conn.fetchrow("""
            INSERT INTO sanctions_trees (name, description, jurisdiction, category, version, status, 
                                       created_by, introduction_tree_id, is_introduction_template, 
                                       created_at, updated_at)
            VALUES ($1, $2, $3, $4, 'v1.0', 'draft', $5, $6, $7, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
            RETURNING id, name, description, jurisdiction, category, version, status, 
                      created_by, introduction_tree_id, is_introduction_template, created_at, updated_at
        """, new_tree_name, original_tree['description'], original_tree['jurisdiction'],
             original_tree['category'], user.sub, original_tree['introduction_tree_id'],
             original_tree['is_introduction_template'])
        
        new_tree_id = new_tree['id']
        
        # Get all nodes from original tree
        nodes = await conn.fetch("""
            SELECT id, node_key, title, description, question_text, question_type, 
                   parent_node_id, display_order, is_root, notes, metadata
            FROM sanctions_nodes 
            WHERE tree_id = $1 
            ORDER BY is_root DESC, display_order
        """, uuid.UUID(tree_id))
        
        # Map old node IDs to new node IDs
        node_id_mapping = {}
        
        # Copy all nodes
        for node in nodes:
            # Handle parent_node_id mapping
            new_parent_id = None
            if node['parent_node_id']:
                new_parent_id = node_id_mapping.get(str(node['parent_node_id']))
            
            new_node = await conn.fetchrow("""
                INSERT INTO sanctions_nodes (tree_id, node_key, title, description, question_text, 
                                           question_type, parent_node_id, display_order, is_root, notes, metadata, 
                                           created_at, updated_at)
                VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
                RETURNING id
            """, new_tree_id, node['node_key'], node['title'], node['description'],
                 node['question_text'], node['question_type'], new_parent_id,
                 node['display_order'], node['is_root'], node['notes'], node['metadata'])
            
            # Store mapping for parent node references
            node_id_mapping[str(node['id'])] = new_node['id']
            
            # Copy all options for this node
            options = await conn.fetch("""
                SELECT option_text, option_value, routing_rule, regulatory_notes, display_order, note
                FROM sanctions_node_options 
                WHERE node_id = $1 AND tree_id = $2
                ORDER BY display_order
            """, node['id'], uuid.UUID(tree_id))
            
            for option in options:
                await conn.execute("""
                    INSERT INTO sanctions_node_options (node_id, tree_id, option_text, option_value, routing_rule, 
                                                       regulatory_notes, display_order, note, created_at, updated_at)
                    VALUES ($1, $2, $3, $4, $5, $6, $7, $8, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
                """, new_node['id'], new_tree_id, option['option_text'], option['option_value'],
                     option['routing_rule'], option['regulatory_notes'], option['display_order'], option['note'])
        
        return SanctionsTree(
            id=str(new_tree['id']),
            name=new_tree['name'],
            description=new_tree['description'],
            jurisdiction=new_tree['jurisdiction'],
            category=new_tree['category'],
            version=new_tree['version'],
            status=new_tree['status'],
            created_by=new_tree['created_by'],
            created_at=new_tree['created_at'],
            updated_at=new_tree['updated_at'],
            published_at=None,
            introduction_tree_id=str(new_tree['introduction_tree_id']) if new_tree['introduction_tree_id'] else None,
            is_introduction_template=new_tree['is_introduction_template']
        )
    finally:
        await conn.close()

# ============================================================================
# Admin Endpoints - Sanctions Nodes
# ============================================================================

@router.get("/admin/trees/{tree_id}/nodes", response_model=List[SanctionsNode])
async def list_sanctions_nodes(tree_id: str, user: AuthorizedUser):
    """List all nodes for a specific sanctions tree"""
    conn = await get_db_connection()
    try:
        rows = await conn.fetch("""
            SELECT id, tree_id, node_key, title, description, question_text, question_type, parent_node_id, 
                   display_order, is_root, notes, metadata, created_at, updated_at
            FROM sanctions_nodes 
            WHERE tree_id = $1
            ORDER BY display_order, title
        """, uuid.UUID(tree_id))

        nodes = [
            SanctionsNode(
                id=str(row['id']),
                tree_id=str(row['tree_id']),
                node_key=row['node_key'],
                title=row['title'],
                description=row['description'],
                question_text=row['question_text'],
                question_type=row['question_type'],
                parent_node_id=str(row['parent_node_id']) if row['parent_node_id'] else None,
                display_order=row['display_order'],
                is_root=row['is_root'],
                notes=row['notes'],
                metadata=row['metadata'],
                created_at=row['created_at'],
                updated_at=row['updated_at']
            )
            for row in rows
        ]
        return nodes
    finally:
        await conn.close()

@router.post("/admin/trees/{tree_id}/nodes", response_model=SanctionsNode)
async def create_sanctions_node(tree_id: str, node_data: SanctionsNodeCreate, user: AuthorizedUser):
    """Create a new node in a sanctions tree"""
    conn = await get_db_connection()
    try:
        # Verify tree exists
        tree_exists = await conn.fetchrow("SELECT id FROM sanctions_trees WHERE id = $1", uuid.UUID(tree_id))
        if not tree_exists:
            raise HTTPException(status_code=404, detail="Sanctions tree not found")

        row = await conn.fetchrow("""
            INSERT INTO sanctions_nodes (tree_id, node_key, title, description, question_text, question_type, parent_node_id, 
                       display_order, is_root, notes, metadata, created_at, updated_at)
            VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
            RETURNING id, tree_id, node_key, title, description, question_text, question_type, parent_node_id, 
                      display_order, is_root, notes, metadata, created_at, updated_at
        """, uuid.UUID(tree_id), node_data.node_key, node_data.title, node_data.description,
             node_data.question_text, node_data.question_type,
             uuid.UUID(node_data.parent_node_id) if node_data.parent_node_id else None,
             node_data.display_order, node_data.is_root, node_data.notes, node_data.metadata)

        return SanctionsNode(
            id=str(row['id']),
            tree_id=str(row['tree_id']),
            node_key=row['node_key'],
            title=row['title'],
            description=row['description'],
            question_text=row['question_text'],
            question_type=row['question_type'],
            parent_node_id=str(row['parent_node_id']) if row['parent_node_id'] else None,
            display_order=row['display_order'],
            is_root=row['is_root'],
            notes=row['notes'],
            metadata=row['metadata'],
            created_at=row['created_at'],
            updated_at=row['updated_at']
        )
    finally:
        await conn.close()

@router.get("/admin/trees/{tree_id}/nodes/{node_id}", response_model=SanctionsNode)
async def get_sanctions_node(tree_id: str, node_id: str, user: AuthorizedUser):
    """Get a specific sanctions node"""
    conn = await get_db_connection()
    try:
        row = await conn.fetchrow("""
            SELECT id, tree_id, node_key, title, description, question_text, question_type, parent_node_id, 
                   display_order, is_root, notes, metadata, created_at, updated_at
            FROM sanctions_nodes WHERE id = $1 AND tree_id = $2
        """, uuid.UUID(node_id), uuid.UUID(tree_id))

        if not row:
            raise HTTPException(status_code=404, detail="Sanctions node not found")

        return SanctionsNode(
            id=str(row['id']),
            tree_id=str(row['tree_id']),
            node_key=row['node_key'],
            title=row['title'],
            description=row['description'],
            question_text=row['question_text'],
            question_type=row['question_type'],
            parent_node_id=str(row['parent_node_id']) if row['parent_node_id'] else None,
            display_order=row['display_order'],
            is_root=row['is_root'],
            notes=row['notes'],
            metadata=row['metadata'],
            created_at=row['created_at'],
            updated_at=row['updated_at']
        )
    finally:
        await conn.close()

@router.put("/admin/trees/{tree_id}/nodes/{node_id}", response_model=SanctionsNode)
async def update_sanctions_node(tree_id: str, node_id: str, node_update: SanctionsNodeUpdate, user: AuthorizedUser):
    """Update a sanctions node"""
    conn = await get_db_connection()
    try:
        # Check if node exists
        existing = await conn.fetchrow(
            "SELECT id FROM sanctions_nodes WHERE id = $1 AND tree_id = $2", 
            uuid.UUID(node_id), uuid.UUID(tree_id)
        )
        if not existing:
            raise HTTPException(status_code=404, detail="Sanctions node not found")

        # Build update query dynamically
        update_fields = []
        update_values = []
        param_count = 1

        for field, value in node_update.dict(exclude_unset=True).items():
            if value is not None:
                if field == 'parent_node_id' and value:
                    update_fields.append(f"{field} = ${param_count}")
                    update_values.append(uuid.UUID(value))
                else:
                    update_fields.append(f"{field} = ${param_count}")
                    update_values.append(value)
                param_count += 1

        if update_fields:
            update_fields.append(f"updated_at = ${param_count}")
            update_values.append(datetime.utcnow())
            param_count += 1
            update_values.append(uuid.UUID(node_id))
            update_values.append(uuid.UUID(tree_id))

            query = f"""
                UPDATE sanctions_nodes 
                SET {', '.join(update_fields)}
                WHERE id = ${param_count} AND tree_id = ${param_count + 1}
                RETURNING id, tree_id, node_key, title, description, question_text, question_type, parent_node_id, 
                          display_order, is_root, notes, metadata, created_at, updated_at
            """
            
            row = await conn.fetchrow(query, *update_values)
        else:
            # No updates, just return current state
            row = await conn.fetchrow("""
                SELECT id, tree_id, node_key, title, description, question_text, question_type, parent_node_id, 
                       display_order, is_root, notes, metadata, created_at, updated_at
                FROM sanctions_nodes WHERE id = $1 AND tree_id = $2
            """, uuid.UUID(node_id), uuid.UUID(tree_id))

        return SanctionsNode(
            id=str(row['id']),
            tree_id=str(row['tree_id']),
            node_key=row['node_key'],
            title=row['title'],
            description=row['description'],
            question_text=row['question_text'],
            question_type=row['question_type'],
            parent_node_id=str(row['parent_node_id']) if row['parent_node_id'] else None,
            display_order=row['display_order'],
            is_root=row['is_root'],
            notes=row['notes'],
            metadata=row['metadata'],
            created_at=row['created_at'],
            updated_at=row['updated_at']
        )
    finally:
        await conn.close()

@router.delete("/admin/trees/{tree_id}/nodes/{node_id}")
async def delete_sanctions_node(tree_id: str, node_id: str, user: AuthorizedUser):
    """Delete a sanctions node"""
    conn = await get_db_connection()
    try:
        # Check if node exists
        existing = await conn.fetchrow(
            "SELECT id FROM sanctions_nodes WHERE id = $1 AND tree_id = $2", 
            uuid.UUID(node_id), uuid.UUID(tree_id)
        )
        if not existing:
            raise HTTPException(status_code=404, detail="Sanctions node not found")

        # Delete node
        await conn.execute(
            "DELETE FROM sanctions_nodes WHERE id = $1 AND tree_id = $2", 
            uuid.UUID(node_id), uuid.UUID(tree_id)
        )
        
        return {"message": "Sanctions node deleted successfully"}
    finally:
        await conn.close()

@router.post("/admin/trees/{tree_id}/nodes/{node_id}/duplicate", response_model=SanctionsNode)
async def duplicate_sanctions_node(tree_id: str, node_id: str, user: AuthorizedUser):
    """Duplicate a sanctions node with all its options"""
    conn = await get_db_connection()
    try:
        # Get original node
        original_node = await conn.fetchrow("""
            SELECT tree_id, node_key, title, description, question_text, question_type, 
                   parent_node_id, display_order, is_root, notes, metadata
            FROM sanctions_nodes WHERE id = $1 AND tree_id = $2
        """, uuid.UUID(node_id), uuid.UUID(tree_id))
        
        if not original_node:
            raise HTTPException(status_code=404, detail="Sanctions node not found")
        
        # Create new node with "Copy of" prefix
        new_node_key = f"copy_of_{original_node['node_key']}"
        new_title = f"Copy of {original_node['title']}"
        
        new_node = await conn.fetchrow("""
            INSERT INTO sanctions_nodes (tree_id, node_key, title, description, question_text, 
                                      question_type, parent_node_id, display_order, is_root, notes, metadata, created_at, updated_at)
            VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
            RETURNING id, tree_id, node_key, title, description, question_text, question_type, 
                      parent_node_id, display_order, is_root, notes, metadata, created_at, updated_at
        """, uuid.UUID(tree_id), new_node_key, new_title, original_node['description'],
             original_node['question_text'], original_node['question_type'], 
             original_node['parent_node_id'], original_node['display_order'] + 1, original_node['is_root'],
             original_node['notes'], original_node['metadata'])
        
        new_node_id = new_node['id']
        
        # Copy all node options
        options = await conn.fetch("""
            SELECT option_text, option_value, routing_rule, regulatory_notes, display_order, note
            FROM sanctions_node_options 
            WHERE node_id = $1 AND tree_id = $2
            ORDER BY display_order
        """, uuid.UUID(node_id), uuid.UUID(tree_id))
        
        for option in options:
            await conn.execute("""
                INSERT INTO sanctions_node_options (node_id, tree_id, option_text, option_value, routing_rule, 
                                                  regulatory_notes, display_order, note, created_at, updated_at)
                VALUES ($1, $2, $3, $4, $5, $6, $7, $8, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
            """, new_node_id, uuid.UUID(tree_id), option['option_text'], option['option_value'],
                 option['routing_rule'], option['regulatory_notes'], option['display_order'], option['note'])
        
        return SanctionsNode(
            id=str(new_node['id']),
            tree_id=str(new_node['tree_id']),
            node_key=new_node['node_key'],
            title=new_node['title'],
            description=new_node['description'],
            question_text=new_node['question_text'],
            question_type=new_node['question_type'],
            parent_node_id=str(new_node['parent_node_id']) if new_node['parent_node_id'] else None,
            display_order=new_node['display_order'],
            is_root=new_node['is_root'],
            notes=new_node['notes'],
            metadata=new_node['metadata'],
            created_at=new_node['created_at'],
            updated_at=new_node['updated_at']
        )
    finally:
        await conn.close()

# ============================================================================
# Admin Endpoints - Sanctions Node Options
# ============================================================================

@router.get("/admin/trees/{tree_id}/nodes/{node_id}/options", response_model=List[SanctionsNodeOption])
async def list_sanctions_node_options(tree_id: str, node_id: str, user: AuthorizedUser):
    """List all options for a specific sanctions node"""
    try:
        print(f"🔍 Loading options for tree_id={tree_id}, node_id={node_id}")
        
        conn = await get_db_connection()
        
        # Validate UUIDs first
        try:
            tree_uuid = uuid.UUID(tree_id)
            node_uuid = uuid.UUID(node_id)
            print(f"✅ Valid UUIDs: tree={tree_uuid}, node={node_uuid}")
        except ValueError as e:
            print(f"❌ Invalid UUID format: {e}")
            raise HTTPException(status_code=400, detail=f"Invalid UUID format: {e}")
        
        try:
            rows = await conn.fetch("""
                SELECT id, node_id, option_text, option_value, routing_rule, regulatory_notes, display_order, note, created_at, updated_at
                FROM sanctions_node_options 
                WHERE node_id = $1 AND tree_id = $2
                ORDER BY display_order, option_text
            """, node_uuid, tree_uuid)
            
            print(f"📊 Found {len(rows)} options")

            options = []
            for row in rows:
                try:
                    option = SanctionsNodeOption(
                        id=str(row['id']),
                        node_id=str(row['node_id']),
                        option_text=row['option_text'],
                        option_value=row['option_value'],
                        routing_rule=row['routing_rule'],
                        regulatory_notes=row['regulatory_notes'],
                        display_order=row['display_order'] or 0,
                        note=row['note'],
                        created_at=row['created_at'],
                        updated_at=row['updated_at']
                    )
                    options.append(option)
                    print(f"✅ Created option: {option.option_text}")
                except Exception as e:
                    print(f"❌ Error creating option model: {e}")
                    print(f"Row data: {dict(row)}")
                    raise
            
            print(f"🎯 Returning {len(options)} options")
            return options
            
        finally:
            await conn.close()
            
    except HTTPException:
        raise
    except Exception as e:
        print(f"❌ Unexpected error in list_sanctions_node_options: {e}")
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")

@router.post("/admin/trees/{tree_id}/nodes/{node_id}/options", response_model=SanctionsNodeOption)
async def create_sanctions_node_option(tree_id: str, node_id: str, option_data: SanctionsNodeOptionCreate, user: AuthorizedUser):
    """Create a new option for a sanctions node"""
    conn = await get_db_connection()
    try:
        # Verify node exists
        node_exists = await conn.fetchrow(
            "SELECT id FROM sanctions_nodes WHERE id = $1 AND tree_id = $2", 
            uuid.UUID(node_id), uuid.UUID(tree_id)
        )
        if not node_exists:
            raise HTTPException(status_code=404, detail="Sanctions node not found")

        row = await conn.fetchrow("""
            INSERT INTO sanctions_node_options (node_id, tree_id, option_text, option_value, routing_rule, regulatory_notes, display_order, note, created_at, updated_at)
            VALUES ($1, $2, $3, $4, $5, $6, $7, $8, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
            RETURNING id, node_id, option_text, option_value, routing_rule, regulatory_notes, display_order, note, created_at, updated_at
        """, uuid.UUID(node_id), uuid.UUID(tree_id), option_data.option_text, option_data.option_value, 
             option_data.routing_rule, option_data.regulatory_notes, option_data.display_order, option_data.note)

        return SanctionsNodeOption(
            id=str(row['id']),
            node_id=str(row['node_id']),
            option_text=row['option_text'],
            option_value=row['option_value'],
            routing_rule=row['routing_rule'],
            regulatory_notes=row['regulatory_notes'],
            display_order=row['display_order'],
            note=row['note'],
            created_at=row['created_at'],
            updated_at=row['updated_at']
        )
    finally:
        await conn.close()

@router.get("/admin/trees/{tree_id}/nodes/{node_id}/options/{option_id}", response_model=SanctionsNodeOption)
async def get_sanctions_node_option(tree_id: str, node_id: str, option_id: str, user: AuthorizedUser):
    """Get a specific sanctions node option"""
    conn = await get_db_connection()
    try:
        row = await conn.fetchrow("""
            SELECT id, node_id, option_text, option_value, routing_rule, regulatory_notes, display_order, note, created_at, updated_at
            FROM sanctions_node_options WHERE id = $1 AND node_id = $2 AND tree_id = $3
        """, uuid.UUID(option_id), uuid.UUID(node_id), uuid.UUID(tree_id))

        if not row:
            raise HTTPException(status_code=404, detail="Sanctions node option not found")

        return SanctionsNodeOption(
            id=str(row['id']),
            node_id=str(row['node_id']),
            option_text=row['option_text'],
            option_value=row['option_value'],
            routing_rule=row['routing_rule'],
            regulatory_notes=row['regulatory_notes'],
            display_order=row['display_order'],
            note=row['note'],
            created_at=row['created_at'],
            updated_at=row['updated_at']
        )
    finally:
        await conn.close()

@router.put("/admin/trees/{tree_id}/nodes/{node_id}/options/{option_id}", response_model=SanctionsNodeOption)
async def update_sanctions_node_option(tree_id: str, node_id: str, option_id: str, option_update: SanctionsNodeOptionUpdate, user: AuthorizedUser):
    """Update a sanctions node option"""
    conn = await get_db_connection()
    try:
        # Check if option exists
        existing = await conn.fetchrow(
            "SELECT id FROM sanctions_node_options WHERE id = $1 AND node_id = $2 AND tree_id = $3", 
            uuid.UUID(option_id), uuid.UUID(node_id), uuid.UUID(tree_id)
        )
        if not existing:
            raise HTTPException(status_code=404, detail="Sanctions node option not found")

        # Build update query dynamically
        update_fields = []
        update_values = []
        param_count = 1

        for field, value in option_update.dict(exclude_unset=True).items():
            if value is not None:
                update_fields.append(f"{field} = ${param_count}")
                update_values.append(value)
                param_count += 1

        if update_fields:
            update_fields.append(f"updated_at = ${param_count}")
            update_values.append(datetime.utcnow())
            update_values.append(uuid.UUID(option_id))
            update_values.append(uuid.UUID(node_id))
            update_values.append(uuid.UUID(tree_id))

            query = f"""
                UPDATE sanctions_node_options 
                SET {', '.join(update_fields)}
                WHERE id = ${param_count + 1} AND node_id = ${param_count + 2} AND tree_id = ${param_count + 3}
                RETURNING id, node_id, option_text, option_value, routing_rule, regulatory_notes, display_order, note, created_at, updated_at
            """
            
            row = await conn.fetchrow(query, *update_values)
        else:
            # No updates, just return current state
            row = await conn.fetchrow("""
                SELECT id, node_id, option_text, option_value, routing_rule, regulatory_notes, display_order, note, created_at, updated_at
                FROM sanctions_node_options WHERE id = $1 AND node_id = $2 AND tree_id = $3
            """, uuid.UUID(option_id), uuid.UUID(node_id), uuid.UUID(tree_id))

        return SanctionsNodeOption(
            id=str(row['id']),
            node_id=str(row['node_id']),
            option_text=row['option_text'],
            option_value=row['option_value'],
            routing_rule=row['routing_rule'],
            regulatory_notes=row['regulatory_notes'],
            display_order=row['display_order'],
            note=row['note'],
            created_at=row['created_at'],
            updated_at=row['updated_at']
        )
    finally:
        await conn.close()

@router.delete("/admin/trees/{tree_id}/nodes/{node_id}/options/{option_id}")
async def delete_sanctions_node_option(tree_id: str, node_id: str, option_id: str, user: AuthorizedUser):
    """Delete a sanctions node option"""
    conn = await get_db_connection()
    try:
        # Check if option exists
        existing = await conn.fetchrow(
            "SELECT id FROM sanctions_node_options WHERE id = $1 AND node_id = $2 AND tree_id = $3", 
            uuid.UUID(option_id), uuid.UUID(node_id), uuid.UUID(tree_id)
        )
        if not existing:
            raise HTTPException(status_code=404, detail="Sanctions node option not found")

        # Delete option
        await conn.execute(
            "DELETE FROM sanctions_node_options WHERE id = $1 AND node_id = $2 AND tree_id = $3", 
            uuid.UUID(option_id), uuid.UUID(node_id), uuid.UUID(tree_id)
        )
        
        return {"message": "Sanctions node option deleted successfully"}
    finally:
        await conn.close()

# ============================================================================
# Public User Endpoints - Published Sanctions Trees
# ============================================================================

@router.get("/trees", response_model=List[SanctionsTree])
async def list_published_sanctions_trees(user: AuthorizedUser):
    """List all published sanctions trees for user access"""
    conn = await get_db_connection()
    try:
        rows = await conn.fetch("""
            SELECT id, name, description, jurisdiction, category, version, status,
                   created_by, created_at, updated_at, published_at, introduction_tree_id, is_introduction_template
            FROM sanctions_trees
            WHERE status = 'published'
            ORDER BY jurisdiction, category, name
        """)

        trees = [
            SanctionsTree(
                id=str(row['id']),
                name=row['name'],
                description=row['description'],
                jurisdiction=row['jurisdiction'],
                category=row['category'],
                version=row['version'],
                status=row['status'],
                created_by=row['created_by'],
                created_at=row['created_at'],
                updated_at=row['updated_at'],
                published_at=row['published_at'],
                introduction_tree_id=str(row['introduction_tree_id']) if row['introduction_tree_id'] else None,
                is_introduction_template=row['is_introduction_template']
            )
            for row in rows
        ]
        return trees
    finally:
        await conn.close()

@router.get("/trees/{tree_id}", response_model=SanctionsTree)
async def get_published_sanctions_tree(tree_id: str, user: AuthorizedUser):
    """Get a specific published sanctions tree"""
    conn = await get_db_connection()
    try:
        row = await conn.fetchrow("""
            SELECT id, name, description, jurisdiction, category, version, status,
                   created_by, created_at, updated_at, published_at, introduction_tree_id, is_introduction_template
            FROM sanctions_trees
            WHERE id = $1 AND status = 'published'
        """, uuid.UUID(tree_id))

        if not row:
            raise HTTPException(status_code=404, detail="Published sanctions tree not found")

        return SanctionsTree(
            id=str(row['id']),
            name=row['name'],
            description=row['description'],
            jurisdiction=row['jurisdiction'],
            category=row['category'],
            version=row['version'],
            status=row['status'],
            created_by=row['created_by'],
            created_at=row['created_at'],
            updated_at=row['updated_at'],
            published_at=row['published_at'],
            introduction_tree_id=str(row['introduction_tree_id']) if row['introduction_tree_id'] else None,
            is_introduction_template=row['is_introduction_template']
        )
    finally:
        await conn.close()

@router.get("/trees/{tree_id}/nodes", response_model=List[SanctionsNode])
async def get_published_sanctions_tree_nodes(tree_id: str, user: AuthorizedUser):
    """Get all nodes for a published sanctions tree"""
    conn = await get_db_connection()
    try:
        # Verify tree is published
        tree_check = await conn.fetchrow(
            "SELECT id FROM sanctions_trees WHERE id = $1 AND status = 'published'", 
            uuid.UUID(tree_id)
        )
        if not tree_check:
            raise HTTPException(status_code=404, detail="Published sanctions tree not found")

        rows = await conn.fetch("""
            SELECT id, tree_id, node_key, title, description, question_text, question_type, parent_node_id, 
                   display_order, is_root, notes, metadata, created_at, updated_at
            FROM sanctions_nodes 
            WHERE tree_id = $1
            ORDER BY display_order, title
        """, uuid.UUID(tree_id))

        nodes = [
            SanctionsNode(
                id=str(row['id']),
                tree_id=str(row['tree_id']),
                node_key=row['node_key'],
                title=row['title'],
                description=row['description'],
                question_text=row['question_text'],
                question_type=row['question_type'],
                parent_node_id=str(row['parent_node_id']) if row['parent_node_id'] else None,
                display_order=row['display_order'],
                is_root=row['is_root'],
                notes=row['notes'],
                metadata=row['metadata'],
                created_at=row['created_at'],
                updated_at=row['updated_at']
            )
            for row in rows
        ]
        return nodes
    finally:
        await conn.close()

@router.get("/trees/{tree_id}/nodes/{node_id}/options", response_model=List[SanctionsNodeOption])
async def get_published_sanctions_node_options(tree_id: str, node_id: str, user: AuthorizedUser):
    """Get all options for a published sanctions node"""
    conn = await get_db_connection()
    try:
        # Verify tree is published and node exists
        node_check = await conn.fetchrow("""
            SELECT sn.id FROM sanctions_nodes sn
            JOIN sanctions_trees st ON sn.tree_id = st.id
            WHERE sn.id = $1 AND st.id = $2 AND st.status = 'published'
        """, uuid.UUID(node_id), uuid.UUID(tree_id))
        
        if not node_check:
            raise HTTPException(status_code=404, detail="Node not found in published sanctions tree")

        rows = await conn.fetch("""
            SELECT id, node_id, option_text, option_value, routing_rule, regulatory_notes, display_order, note, created_at, updated_at
            FROM sanctions_node_options 
            WHERE node_id = $1 AND tree_id = $2
            ORDER BY display_order, option_text
        """, uuid.UUID(node_id), uuid.UUID(tree_id))

        options = [
            SanctionsNodeOption(
                id=str(row['id']),
                node_id=str(row['node_id']),
                option_text=row['option_text'],
                option_value=row['option_value'],
                routing_rule=row['routing_rule'],
                regulatory_notes=row['regulatory_notes'],
                display_order=row['display_order'],
                note=row['note'],
                created_at=row['created_at'],
                updated_at=row['updated_at']
            )
            for row in rows
        ]
        return options
    finally:
        await conn.close()

@router.post("/assess", response_model=SanctionsAssessmentResult)
@consume_credits_for_action("sanctions_embargoes", "sanctions_assessment")
async def assess_sanctions_applicability(assessment_request: SanctionsAssessmentRequest, user: AuthorizedUser):
    """Assess sanctions applicability using tree logic"""
    conn = await get_db_connection()
    try:
        # Verify tree exists and is published
        tree = await conn.fetchrow(
            "SELECT * FROM sanctions_trees WHERE id = $1 AND status = 'published'", 
            uuid.UUID(assessment_request.tree_id)
        )
        if not tree:
            raise HTTPException(status_code=404, detail="Published sanctions tree not found")

        # Generate assessment ID
        assessment_id = str(uuid.uuid4())
        
        # For now, return a sample assessment result
        # In a real implementation, this would traverse the tree based on the logic
        return SanctionsAssessmentResult(
            assessment_id=assessment_id,
            tree_id=assessment_request.tree_id,
            jurisdiction=assessment_request.jurisdiction,
            entity_name=assessment_request.entity_name,
            sanctions_applicable=True,
            risk_level='medium',
            applicable_sanctions=['Financial Sanctions', 'Asset Freeze'],
            reasoning=f"Based on {tree['name']} assessment criteria, sanctions may apply.",
            regulatory_notes="Please verify with current sanctions lists and consult legal counsel.",
            assessment_path=[
                {"step": 1, "question": "Entity Type", "answer": assessment_request.entity_type},
                {"step": 2, "question": "Jurisdiction", "answer": assessment_request.jurisdiction}
            ],
            created_at=datetime.utcnow()
        )
    finally:
        await conn.close()
