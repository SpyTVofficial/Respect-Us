


from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import List, Optional, Dict, Any
import asyncpg
import databutton as db
from app.auth import AuthorizedUser
from app.env import Mode, mode
from datetime import datetime

router = APIRouter(prefix="/credit-management")

# Request/Response Models
class CreateCreditPackageRequest(BaseModel):
    name: str
    credits: int
    price_cents: int
    currency: str = "EUR"
    discount_percentage: int = 0
    is_active: bool = True
    expiry_months: int = 12

class UpdateCreditPackageRequest(BaseModel):
    name: str
    credits: int
    price_cents: int
    discount_percentage: int = 0
    is_active: bool = True
    expiry_months: int = 12

class BaseCreditPriceRequest(BaseModel):
    price_eur_per_credit: float

class FreeTierActivationResponse(BaseModel):
    success: bool
    credits_awarded: int
    new_balance: int
    message: str
    is_first_time: bool

# Pydantic Models
class CreditBalance(BaseModel):
    user_id: str
    current_balance: int
    lifetime_purchased: int
    lifetime_consumed: int
    
class CreditTransaction(BaseModel):
    id: int
    transaction_type: str
    amount: int
    balance_after: int
    description: Optional[str] = None
    component_name: Optional[str] = None
    action_name: Optional[str] = None
    resource_id: Optional[str] = None
    created_at: datetime

class CreditPackage(BaseModel):
    id: int
    name: str
    credits: int
    price_cents: int
    currency: str
    discount_percentage: int
    is_active: bool
    expiry_months: int
    
class PurchaseRequest(BaseModel):
    package_id: int
    
class ConsumeCreditsRequest(BaseModel):
    component_name: str
    action_name: str
    resource_id: Optional[str] = None
    description: Optional[str] = None
    
class ReserveCreditsRequest(BaseModel):
    component_name: str
    action_name: str
    resource_id: Optional[str] = None
    
class AdminCreditAdjustment(BaseModel):
    user_id: str
    amount: int  # positive to add, negative to subtract
    reason: str

# Database connection
async def get_db_connection():
    """Get database connection based on environment"""
    if mode == Mode.PROD:
        database_url = db.secrets.get("DATABASE_URL_PROD")
    else:
        database_url = db.secrets.get("DATABASE_URL_DEV")
    return await asyncpg.connect(database_url)

# Free Tier Implementation
@router.post("/credits/activate-free-tier")
async def activate_free_tier(user: AuthorizedUser) -> FreeTierActivationResponse:
    """Activate free tier credits for new users automatically"""
    try:
        conn = await get_db_connection()
        try:
            # Check if user already received free tier credits
            check_query = """
                SELECT COUNT(*) FROM credit_transactions 
                WHERE user_id = $1 AND transaction_type = 'bonus' 
                AND description LIKE '%Welcome bonus%'
            """
            
            existing_free_credits = await conn.fetchval(check_query, user.sub)
            
            if existing_free_credits > 0:
                # Get current balance
                balance_query = "SELECT current_balance FROM user_credits WHERE user_id = $1"
                current_balance = await conn.fetchval(balance_query, user.sub) or 0
                
                return FreeTierActivationResponse(
                    success=False,
                    credits_awarded=0,
                    new_balance=current_balance,
                    message="Free tier credits already claimed",
                    is_first_time=False
                )
            
            # Award free tier credits (100 credits)
            free_credits = 100
            
            async with conn.transaction():
                # Ensure user record exists
                ensure_user_query = """
                    INSERT INTO user_credits (user_id) VALUES ($1)
                    ON CONFLICT (user_id) DO NOTHING
                """
                await conn.execute(ensure_user_query, user.sub)
                
                # Get current balance
                balance_query = "SELECT current_balance FROM user_credits WHERE user_id = $1"
                current_balance = await conn.fetchval(balance_query, user.sub) or 0
                
                new_balance = current_balance + free_credits
                
                # Update balance
                update_balance_query = """
                    UPDATE user_credits 
                    SET current_balance = $1, updated_at = CURRENT_TIMESTAMP
                    WHERE user_id = $2
                """
                await conn.execute(update_balance_query, new_balance, user.sub)
                
                # Record transaction
                transaction_query = """
                    INSERT INTO credit_transactions 
                    (user_id, transaction_type, amount, balance_after, description)
                    VALUES ($1, 'bonus', $2, $3, 'Welcome bonus - free tier credits to get started')
                    RETURNING id
                """
                
                transaction_id = await conn.fetchval(
                    transaction_query, 
                    user.sub, 
                    free_credits, 
                    new_balance
                )
                
                return FreeTierActivationResponse(
                    success=True,
                    credits_awarded=free_credits,
                    new_balance=new_balance,
                    message=f"Welcome! You've received {free_credits} free credits to explore the platform.",
                    is_first_time=True
                )
                
        finally:
            await conn.close()
            
    except Exception as e:
        print(f"Error activating free tier: {e}")
        raise HTTPException(status_code=500, detail="Failed to activate free tier") from e

@router.get("/credits/free-tier-status")
async def get_free_tier_status(user: AuthorizedUser) -> Dict[str, Any]:
    """Check if user has claimed free tier credits and eligibility"""
    try:
        conn = await get_db_connection()
        try:
            # Check if user already received free tier credits
            check_query = """
                SELECT COUNT(*) as claim_count, MAX(created_at) as last_claimed
                FROM credit_transactions 
                WHERE user_id = $1 AND transaction_type = 'bonus' 
                AND description LIKE '%Welcome bonus%'
            """
            
            result = await conn.fetchrow(check_query, user.sub)
            has_claimed = result['claim_count'] > 0
            
            # Get current balance
            balance_query = "SELECT current_balance FROM user_credits WHERE user_id = $1"
            current_balance = await conn.fetchval(balance_query, user.sub) or 0
            
            return {
                "has_claimed_free_tier": has_claimed,
                "is_eligible": not has_claimed,
                "current_balance": current_balance,
                "free_tier_amount": 100,
                "last_claimed": result['last_claimed'].isoformat() if result['last_claimed'] else None
            }
                
        finally:
            await conn.close()
            
    except Exception as e:
        print(f"Error checking free tier status: {e}")
        raise HTTPException(status_code=500, detail="Failed to check free tier status") from e

# User Credit Operations
@router.get("/credits/balance")
async def get_credit_balance(user: AuthorizedUser) -> CreditBalance:
    """Get current user's credit balance"""
    try:
        conn = await get_db_connection()
        try:
            # Get or create user credit record
            query = """
                INSERT INTO user_credits (user_id) VALUES ($1)
                ON CONFLICT (user_id) DO NOTHING
                RETURNING current_balance, lifetime_purchased, lifetime_consumed
            """
            await conn.execute(query, user.sub)
            
            # Fetch current balance
            balance_query = """
                SELECT current_balance, lifetime_purchased, lifetime_consumed
                FROM user_credits WHERE user_id = $1
            """
            row = await conn.fetchrow(balance_query, user.sub)
            
            return CreditBalance(
                user_id=user.sub,
                current_balance=row['current_balance'],
                lifetime_purchased=row['lifetime_purchased'],
                lifetime_consumed=row['lifetime_consumed']
            )
            
        finally:
            await conn.close()
            
    except Exception as e:
        print(f"Error fetching credit balance: {e}")
        raise HTTPException(status_code=500, detail="Failed to fetch credit balance") from e

@router.get("/credits/transactions")
async def get_credit_transactions(user: AuthorizedUser, limit: int = 50, offset: int = 0) -> List[CreditTransaction]:
    """Get user's credit transaction history"""
    try:
        conn = await get_db_connection()
        try:
            query = """
                SELECT id, transaction_type, amount, balance_after, description,
                       component_name, action_name, resource_id, created_at
                FROM credit_transactions 
                WHERE user_id = $1
                ORDER BY created_at DESC
                LIMIT $2 OFFSET $3
            """
            rows = await conn.fetch(query, user.sub, limit, offset)
            
            return [
                CreditTransaction(
                    id=row['id'],
                    transaction_type=row['transaction_type'],
                    amount=row['amount'],
                    balance_after=row['balance_after'],
                    description=row['description'],
                    component_name=row['component_name'],
                    action_name=row['action_name'],
                    resource_id=row['resource_id'],
                    created_at=row['created_at']
                )
                for row in rows
            ]
            
        finally:
            await conn.close()
            
    except Exception as e:
        print(f"Error fetching credit transactions: {e}")
        raise HTTPException(status_code=500, detail="Failed to fetch transactions") from e

@router.get("/credits/packages")
async def get_credit_packages() -> List[CreditPackage]:
    """Get available credit packages for purchase"""
    try:
        conn = await get_db_connection()
        try:
            query = """
                SELECT id, name, credits, price_cents, currency, discount_percentage, is_active, expiry_months
                FROM credit_packages 
                WHERE is_active = true
                ORDER BY display_order
            """
            rows = await conn.fetch(query)
            
            return [
                CreditPackage(
                    id=row['id'],
                    name=row['name'],
                    credits=row['credits'],
                    price_cents=row['price_cents'],
                    currency=row['currency'],
                    discount_percentage=row['discount_percentage'],
                    is_active=row['is_active'],
                    expiry_months=row['expiry_months']
                )
                for row in rows
            ]
            
        finally:
            await conn.close()
            
    except Exception as e:
        print(f"Error fetching credit packages: {e}")
        raise HTTPException(status_code=500, detail="Failed to fetch credit packages") from e

@router.post("/credits/reserve")
async def reserve_credits(request: ReserveCreditsRequest, user: AuthorizedUser) -> Dict[str, Any]:
    """Reserve credits for an action (check availability without consuming)"""
    try:
        conn = await get_db_connection()
        try:
            # First check module pricing config for new pricing system
            module_pricing_query = """
                SELECT credit_cost
                FROM module_pricing_config 
                WHERE module_name = $1 AND is_active = true
            """
            module_pricing = await conn.fetchrow(module_pricing_query, request.component_name)
            
            if module_pricing and module_pricing['credit_cost'] is not None:
                required_credits = module_pricing['credit_cost']
                
                # Check user's current balance
                balance_query = "SELECT current_balance FROM user_credits WHERE user_id = $1"
                balance_row = await conn.fetchrow(balance_query, user.sub)
                
                current_balance = balance_row['current_balance'] if balance_row else 0
                can_proceed = current_balance >= required_credits
                
                return {
                    "required_credits": required_credits,
                    "current_balance": current_balance,
                    "is_free": False,
                    "can_proceed": can_proceed,
                    "message": "Sufficient credits" if can_proceed else "Insufficient credits"
                }
            
            # Fallback to legacy component pricing config
            pricing_query = """
                SELECT cpc.credit_cost, pff.is_pricing_enabled
                FROM component_pricing_config cpc
                JOIN pricing_feature_flags pff ON pff.component_name = cpc.component_name
                WHERE cpc.component_name = $1 AND cpc.action_name = $2 
                AND cpc.is_active = true AND pff.is_pricing_enabled = true
            """
            pricing = await conn.fetchrow(pricing_query, request.component_name, request.action_name)
            
            if not pricing:
                # Action is free or pricing not enabled
                return {
                    "required_credits": 0,
                    "is_free": True,
                    "can_proceed": True,
                    "message": "This action is currently free"
                }
            
            required_credits = pricing['credit_cost']
            
            # Check user's current balance
            balance_query = "SELECT current_balance FROM user_credits WHERE user_id = $1"
            balance_row = await conn.fetchrow(balance_query, user.sub)
            
            current_balance = balance_row['current_balance'] if balance_row else 0
            can_proceed = current_balance >= required_credits
            
            return {
                "required_credits": required_credits,
                "current_balance": current_balance,
                "is_free": False,
                "can_proceed": can_proceed,
                "message": "Sufficient credits" if can_proceed else "Insufficient credits"
            }
            
        finally:
            await conn.close()
            
    except Exception as e:
        print(f"Error reserving credits: {e}")
        raise HTTPException(status_code=500, detail="Failed to reserve credits") from e

@router.post("/credits/consume")
async def consume_credits(request: ConsumeCreditsRequest, user: AuthorizedUser) -> Dict[str, Any]:
    """Consume credits for an action"""
    try:
        conn = await get_db_connection()
        try:
            async with conn.transaction():
                # Check if pricing is enabled and get cost
                pricing_query = """
                    SELECT cpc.credit_cost, pff.is_pricing_enabled
                    FROM component_pricing_config cpc
                    JOIN pricing_feature_flags pff ON pff.component_name = cpc.component_name
                    WHERE cpc.component_name = $1 AND cpc.action_name = $2 
                    AND cpc.is_active = true AND pff.is_pricing_enabled = true
                """
                pricing = await conn.fetchrow(pricing_query, request.component_name, request.action_name)
                
                if not pricing:
                    # Action is free
                    return {
                        "credits_consumed": 0,
                        "new_balance": 0,
                        "is_free": True,
                        "transaction_id": None
                    }
                
                required_credits = pricing['credit_cost']
                
                # Get current balance and ensure user exists
                balance_query = """
                    INSERT INTO user_credits (user_id) VALUES ($1)
                    ON CONFLICT (user_id) DO NOTHING
                """
                await conn.execute(balance_query, user.sub)
                
                current_balance_query = "SELECT current_balance FROM user_credits WHERE user_id = $1"
                balance_row = await conn.fetchrow(current_balance_query, user.sub)
                current_balance = balance_row['current_balance']
                
                if current_balance < required_credits:
                    raise HTTPException(
                        status_code=402, 
                        detail=f"Insufficient credits. Required: {required_credits}, Available: {current_balance}"
                    )
                
                # Consume credits
                new_balance = current_balance - required_credits
                
                # Update user balance
                update_query = """
                    UPDATE user_credits 
                    SET current_balance = $1, lifetime_consumed = lifetime_consumed + $2, updated_at = CURRENT_TIMESTAMP
                    WHERE user_id = $3
                """
                await conn.execute(update_query, new_balance, required_credits, user.sub)
                
                # Log transaction
                transaction_query = """
                    INSERT INTO credit_transactions 
                    (user_id, transaction_type, amount, balance_after, description, component_name, action_name, resource_id)
                    VALUES ($1, 'consume', $2, $3, $4, $5, $6, $7)
                    RETURNING id
                """
                transaction_row = await conn.fetchrow(
                    transaction_query,
                    user.sub,
                    -required_credits,
                    new_balance,
                    request.description or f"Used {request.component_name} - {request.action_name}",
                    request.component_name,
                    request.action_name,
                    request.resource_id
                )
                
                return {
                    "credits_consumed": required_credits,
                    "new_balance": new_balance,
                    "is_free": False,
                    "transaction_id": transaction_row['id']
                }
            
        finally:
            await conn.close()
            
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error consuming credits: {e}")
        raise HTTPException(status_code=500, detail="Failed to consume credits") from e

# Admin Credit Operations
@router.post("/admin/credits/adjust")
async def admin_adjust_credits(request: AdminCreditAdjustment, user: AuthorizedUser) -> Dict[str, Any]:
    """Admin function to manually adjust user credits"""
    # TODO: Add admin role check here
    try:
        conn = await get_db_connection()
        try:
            async with conn.transaction():
                # Ensure user exists
                ensure_user_query = """
                    INSERT INTO user_credits (user_id) VALUES ($1)
                    ON CONFLICT (user_id) DO NOTHING
                """
                await conn.execute(ensure_user_query, request.user_id)
                
                # Get current balance
                balance_query = "SELECT current_balance FROM user_credits WHERE user_id = $1"
                balance_row = await conn.fetchrow(balance_query, request.user_id)
                current_balance = balance_row['current_balance']
                new_balance = current_balance + request.amount
                
                if new_balance < 0:
                    raise HTTPException(status_code=400, detail="Cannot reduce credits below zero")
                
                # Update balance
                update_query = """
                    UPDATE user_credits 
                    SET current_balance = $1, 
                        lifetime_purchased = CASE WHEN $2 > 0 THEN lifetime_purchased + $2 ELSE lifetime_purchased END,
                        updated_at = CURRENT_TIMESTAMP
                    WHERE user_id = $3
                """
                await conn.execute(update_query, new_balance, max(0, request.amount), request.user_id)
                
                # Log transaction
                transaction_query = """
                    INSERT INTO credit_transactions 
                    (user_id, transaction_type, amount, balance_after, description)
                    VALUES ($1, 'admin_adjustment', $2, $3, $4)
                    RETURNING id
                """
                transaction_row = await conn.fetchrow(
                    transaction_query,
                    request.user_id,
                    request.amount,
                    new_balance,
                    f"Admin adjustment: {request.reason}"
                )
                
                return {
                    "success": True,
                    "previous_balance": current_balance,
                    "new_balance": new_balance,
                    "adjustment_amount": request.amount,
                    "transaction_id": transaction_row['id']
                }
            
        finally:
            await conn.close()
            
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error adjusting credits: {e}")
        raise HTTPException(status_code=500, detail="Failed to adjust credits") from e

# Admin Credit Package Management
@router.post("/admin/credits/packages")
async def create_credit_package(package: CreateCreditPackageRequest, user: AuthorizedUser) -> CreditPackage:
    """Create a new credit package (admin only)"""
    try:
        conn = await get_db_connection()
        try:
            query = """
                INSERT INTO credit_packages (name, credits, price_cents, currency, discount_percentage, is_active, expiry_months)
                VALUES ($1, $2, $3, $4, $5, $6, $7)
                RETURNING id, name, credits, price_cents, currency, discount_percentage, is_active, expiry_months
            """
            row = await conn.fetchrow(
                query,
                package.name,
                package.credits,
                package.price_cents,
                package.currency or "EUR",
                package.discount_percentage or 0,
                package.is_active,
                package.expiry_months
            )
            
            return CreditPackage(
                id=row['id'],
                name=row['name'],
                credits=row['credits'],
                price_cents=row['price_cents'],
                currency=row['currency'],
                discount_percentage=row['discount_percentage'],
                is_active=row['is_active'],
                expiry_months=row['expiry_months']
            )
            
        finally:
            await conn.close()
            
    except Exception as e:
        print(f"Error creating credit package: {e}")
        raise HTTPException(status_code=500, detail="Failed to create credit package") from e

@router.put("/admin/credits/packages/{package_id}")
async def update_credit_package(package_id: int, package: UpdateCreditPackageRequest, user: AuthorizedUser) -> CreditPackage:
    """Update an existing credit package (admin only)"""
    try:
        conn = await get_db_connection()
        try:
            query = """
                UPDATE credit_packages 
                SET name = $1, credits = $2, price_cents = $3, discount_percentage = $4, is_active = $5, expiry_months = $6
                WHERE id = $7
                RETURNING id, name, credits, price_cents, currency, discount_percentage, is_active, expiry_months
            """
            row = await conn.fetchrow(
                query,
                package.name,
                package.credits,
                package.price_cents,
                package.discount_percentage,
                package.is_active,
                package.expiry_months,
                package_id
            )
            
            if not row:
                raise HTTPException(status_code=404, detail="Credit package not found")
            
            return CreditPackage(
                id=row['id'],
                name=row['name'],
                credits=row['credits'],
                price_cents=row['price_cents'],
                currency=row['currency'],
                discount_percentage=row['discount_percentage'],
                is_active=row['is_active'],
                expiry_months=row['expiry_months']
            )
            
        finally:
            await conn.close()
            
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error updating credit package: {e}")
        raise HTTPException(status_code=500, detail="Failed to update credit package") from e

@router.delete("/admin/credits/packages/{package_id}")
async def delete_credit_package(package_id: int, user: AuthorizedUser) -> Dict[str, str]:
    """Delete a credit package (admin only)"""
    try:
        conn = await get_db_connection()
        try:
            # Check if package exists
            check_query = "SELECT id FROM credit_packages WHERE id = $1"
            existing = await conn.fetchrow(check_query, package_id)
            
            if not existing:
                raise HTTPException(status_code=404, detail="Credit package not found")
            
            # Delete the package
            delete_query = "DELETE FROM credit_packages WHERE id = $1"
            await conn.execute(delete_query, package_id)
            
            return {"message": "Credit package deleted successfully"}
            
        finally:
            await conn.close()
            
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error deleting credit package: {e}")
        raise HTTPException(status_code=500, detail="Failed to delete credit package") from e

@router.get("/admin/credits/packages")
async def get_all_credit_packages(user: AuthorizedUser) -> List[CreditPackage]:
    """Get all credit packages including inactive ones (admin only)"""
    try:
        conn = await get_db_connection()
        try:
            query = """
                SELECT id, name, credits, price_cents, currency, discount_percentage, is_active, expiry_months
                FROM credit_packages 
                ORDER BY display_order, name
            """
            rows = await conn.fetch(query)
            
            return [
                CreditPackage(
                    id=row['id'],
                    name=row['name'],
                    credits=row['credits'],
                    price_cents=row['price_cents'],
                    currency=row['currency'],
                    discount_percentage=row['discount_percentage'],
                    is_active=row['is_active'],
                    expiry_months=row['expiry_months']
                )
                for row in rows
            ]
            
        finally:
            await conn.close()
            
    except Exception as e:
        print(f"Error fetching all credit packages: {e}")
        raise HTTPException(status_code=500, detail="Failed to fetch credit packages") from e

# Base Credit Price Management
@router.get("/admin/credits/base-price")
async def get_base_credit_price(user: AuthorizedUser) -> Dict[str, float]:
    """Get the base EUR price per credit (admin only)"""
    try:
        conn = await get_db_connection()
        try:
            query = "SELECT price_eur_per_credit FROM credit_base_pricing WHERE is_active = true LIMIT 1"
            row = await conn.fetchrow(query)
            
            if row:
                return {"price_eur_per_credit": row['price_eur_per_credit']}
            else:
                # Default price if none set
                return {"price_eur_per_credit": 0.10}
            
        finally:
            await conn.close()
            
    except Exception as e:
        print(f"Error fetching base credit price: {e}")
        raise HTTPException(status_code=500, detail="Failed to fetch base credit price") from e

@router.put("/admin/credits/base-price")
async def update_base_credit_price(request: BaseCreditPriceRequest, user: AuthorizedUser) -> Dict[str, float]:
    """Update the base EUR price per credit (admin only)"""
    try:
        conn = await get_db_connection()
        try:
            # First deactivate current pricing
            await conn.execute("UPDATE credit_base_pricing SET is_active = false")
            
            # Insert new pricing
            query = """
                INSERT INTO credit_base_pricing (price_eur_per_credit, is_active, created_at)
                VALUES ($1, true, NOW())
                RETURNING price_eur_per_credit
            """
            row = await conn.fetchrow(query, request.price_eur_per_credit)
            
            return {"price_eur_per_credit": row['price_eur_per_credit']}
            
        finally:
            await conn.close()
            
    except Exception as e:
        print(f"Error updating base credit price: {e}")
        raise HTTPException(status_code=500, detail="Failed to update base credit price") from e
