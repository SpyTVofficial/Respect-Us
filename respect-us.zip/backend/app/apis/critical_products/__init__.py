import io
import csv
import asyncpg
import json
from typing import List, Optional, Dict, Any, Union
from fastapi import APIRouter, HTTPException, Query, File, UploadFile, Form
from pydantic import BaseModel
from app.auth import AuthorizedUser
from app.env import Mode, mode
from datetime import datetime
import uuid
import databutton as db
from fastapi.responses import Response, StreamingResponse
from app.libs.credit_wrapper import consume_credits_for_action
import pandas as pd
import uuid

router = APIRouter(prefix="/critical-products")

# Database connection helper
async def get_db_connection():
    """Get database connection based on environment"""
    if mode == Mode.PROD:
        database_url = db.secrets.get("DATABASE_URL_PROD")
    else:
        database_url = db.secrets.get("DATABASE_URL_DEV")
    return await asyncpg.connect(database_url)

# Pydantic models
class TradeCode(BaseModel):
    id: str
    hs_code: str
    cn_code: Optional[str] = None
    description: str
    category: Optional[str] = None
    subcategory: Optional[str] = None
    unit_of_measure: Optional[str] = None
    is_active: bool = True
    created_at: datetime
    updated_at: datetime
    created_by: str
    updated_by: Optional[str] = None

class RestrictiveMeasure(BaseModel):
    id: str
    regulation_reference: str
    article_number: Optional[str] = None
    measure_type: str
    measure_description: str
    jurisdiction: str
    authority: Optional[str] = None
    effective_date: datetime
    expiry_date: Optional[datetime] = None
    is_active: bool = True
    created_at: datetime
    updated_at: datetime
    created_by: str
    updated_by: Optional[str] = None

class TradeCodeRestriction(BaseModel):
    id: str
    trade_code_id: str
    restrictive_measure_id: str
    scope_notes: Optional[str] = None
    risk_level: str = "medium"
    created_at: datetime
    updated_at: datetime
    created_by: str
    updated_by: Optional[str] = None

class CriticalProductSearchResult(BaseModel):
    id: str
    hs_code: str
    cn_code: Optional[str] = None
    description: str
    category: Optional[str] = None
    subcategory: Optional[str] = None
    restrictions: List[Dict[str, Any]] = []
    risk_level: Optional[str] = None
    match_type: str  # "exact_hs", "exact_cn", "description", "category"

class CreateTradeCodeRequest(BaseModel):
    hs_code: str
    cn_code: Optional[str] = None
    description: str
    category: Optional[str] = None
    subcategory: Optional[str] = None
    unit_of_measure: Optional[str] = None

class CreateRestrictiveMeasureRequest(BaseModel):
    regulation_reference: str
    article_number: Optional[str] = None
    measure_type: str
    measure_description: str
    jurisdiction: str
    authority: Optional[str] = None
    effective_date: str
    expiry_date: Optional[str] = None

class SearchCriticalProductsRequest(BaseModel):
    query: Optional[str] = None
    hs_code: Optional[str] = None
    cn_code: Optional[str] = None
    category: Optional[str] = None
    jurisdiction: Optional[str] = None
    measure_type: Optional[str] = None
    risk_level: Optional[str] = None
    limit: int = 50
    offset: int = 0

# API Endpoints

@router.get("/download-template")
async def download_critical_products_template(user: AuthorizedUser):
    """Download CSV template for critical products bulk import"""
    try:
        # Create CSV template with headers and sample data
        output = io.StringIO()
        writer = csv.writer(output)
        
        # Write headers
        headers = [
            'hs_code',
            'cn_code', 
            'description',
            'category',
            'subcategory',
            'unit_ofmeasure',
            'regulation_reference',
            'article_number',
            'measure_type',
            'measure_description',
            'regulating_jurisdiction',
            'targeted_jurisdiction',
            'authority',
            'effective_date',
            'expiry_date',
            'scope_notes',
            'risk_level'
        ]
        writer.writerow(headers)
        
        # Write sample data rows
        sample_data = [
            [
                '8542.31.00',
                '8542 31 00 90',
                'Processors and controllers for semiconductors',
                'Electronics',
                'Semiconductors',
                'Units',
                'EU Regulation 2021/821',
                'Annex I, 3A001.a.1',
                'export_prohibition',
                'Export prohibition for dual-use items',
                'EU',
                'China',
                'European Commission',
                '2021-09-09',
                '',
                'Applies to advanced semiconductor processors',
                'high'
            ],
            [
                '2804.40.00',
                '2804 40 00 10',
                'Oxygen - industrial grade',
                'Chemicals',
                'Industrial Gases',
                'Cubic meters',
                'UN Security Council Resolution 1540',
                'Category 1.C.1',
                'licensing_requirement',
                'Export licensing required for dual-use chemicals',
                'UN',
                'Iran',
                'UN Security Council',
                '2004-04-28',
                '',
                'High-purity oxygen for potential dual-use applications',
                'medium'
            ]
        ]
        
        for row in sample_data:
            writer.writerow(row)
        
        # Get CSV content
        csv_content = output.getvalue()
        output.close()
        
        # Return as downloadable file
        return StreamingResponse(
            io.BytesIO(csv_content.encode('utf-8')),
            media_type='text/csv',
            headers={"Content-Disposition": "attachment; filename=critical_products_template.csv"}
        )
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to generate template: {str(e)}")

@router.get("/download-excel-template")
async def download_critical_products_excel_template(user: AuthorizedUser):
    """Download Excel template for critical products bulk import"""
    try:
        # Enhanced sample data with all the columns from user's template
        sample_data = [
            {
                'hs_code': '8542.31.00',
                'cn_code': '8542 31 00 90',
                'description': 'Processors and controllers for semiconductors',
                'category': 'Electronics',
                'subcategory': 'Semiconductors',
                'unitofmeasure': 'Units',
                'regulation_reference': 'EU Regulation 2021/821',
                'article_number': 'Annex I, 3A001.a.1',
                'measure_type': 'export_prohibition',
                'measure_description': 'Export prohibition for dual-use items',
                'regulating_jurisdiction': 'EU',
                'targeted_jurisdiction': 'China',
                'authority': 'European Commission',
                'effective_date': '2021-09-09',
                'expiry_date': '',
                'scope_notes': 'Applies to advanced semiconductor processors',
                'risk_level': 'high'
            },
            {
                'hs_code': '2804.40.00',
                'cn_code': '2804 40 00 10',
                'description': 'Oxygen - industrial grade',
                'category': 'Chemicals',
                'subcategory': 'Industrial Gases',
                'unitofmeasure': 'Cubic meters',
                'regulation_reference': 'UN Security Council Resolution 1540',
                'article_number': 'Category 1.C.1',
                'measure_type': 'licensing_requirement',
                'measure_description': 'Export licensing required for dual-use chemicals',
                'regulating_jurisdiction': 'UN',
                'targeted_jurisdiction': 'Iran',
                'authority': 'UN Security Council',
                'effective_date': '2004-04-28',
                'expiry_date': '',
                'scope_notes': 'High-purity oxygen for potential dual-use applications',
                'risk_level': 'medium'
            }
        ]
        
        # Create DataFrame
        df = pd.DataFrame(sample_data)
        
        # Save to Excel bytes
        excel_buffer = io.BytesIO()
        with pd.ExcelWriter(excel_buffer, engine='openpyxl') as writer:
            df.to_excel(writer, sheet_name='Critical Products', index=False)
            
            # Get the workbook and worksheet for formatting
            workbook = writer.book
            worksheet = writer.sheets['Critical Products']
            
            # Format headers to be bold and adjust column widths
            from openpyxl.styles import Font
            bold_font = Font(bold=True)
            
            for col_num, value in enumerate(df.columns.values):
                cell = worksheet.cell(row=1, column=col_num+1)
                cell.font = bold_font
                # Set wider column width for better readability
                column_letter = cell.column_letter
                worksheet.column_dimensions[column_letter].width = 30
        
        excel_buffer.seek(0)
        
        # Return as downloadable Excel file
        return StreamingResponse(
            io.BytesIO(excel_buffer.read()),
            media_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            headers={"Content-Disposition": "attachment; filename=critical_products_template.xlsx"}
        )
        
    except Exception as e:
        print(f"Error generating Excel template: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to generate Excel template: {str(e)}")

@router.post("/search")
@consume_credits_for_action("product_classification", "search_critical_products")
async def search_critical_products(
    request: SearchCriticalProductsRequest,
    user: AuthorizedUser
) -> List[CriticalProductSearchResult]:
    """
    Search critical products database by HS/CN codes, keywords, or filters.
    Supports multi-modal search: exact code match, fuzzy search, and full-text search.
    """
    conn = await get_db_connection()
    try:
        # Build dynamic search query
        conditions = []
        params = []
        param_count = 0
        
        base_query = """
        SELECT DISTINCT
            tc.id, tc.hs_code, tc.cn_code, tc.description, tc.category, tc.subcategory,
            'none' as max_risk_level
        FROM trade_codes tc
        WHERE tc.is_active = true
        """
        
        # Add search conditions
        if request.hs_code:
            param_count += 1
            conditions.append(f"tc.hs_code ILIKE ${param_count}")
            params.append(f"%{request.hs_code}%")
            
        if request.cn_code:
            param_count += 1
            conditions.append(f"tc.cn_code ILIKE ${param_count}");
            params.append(f"%{request.cn_code}%")
            
        if request.category:
            param_count += 1
            conditions.append(f"tc.category ILIKE ${param_count}");
            params.append(f"%{request.category}%")
            
        if request.jurisdiction:
            param_count += 1
            conditions.append(f"rm.jurisdiction ILIKE ${param_count}");
            params.append(f"%{request.jurisdiction}%")
            
        if request.measure_type:
            param_count += 1
            conditions.append(f"rm.measure_type = ${param_count}");
            params.append(request.measure_type)
            
        if request.risk_level:
            param_count += 1
            conditions.append(f"tcr.risk_level = ${param_count}");
            params.append(request.risk_level)
            
        # Full-text search on description if query provided
        if request.query:
            param_count += 1
            conditions.append(f"to_tsvector('english', tc.description) @@ plainto_tsquery('english', ${param_count})");
            params.append(request.query)
        
        # Add conditions to query
        if conditions:
            base_query += " AND " + " AND ".join(conditions)
            
        # Order results
        base_query += """
        ORDER BY tc.hs_code
        """
        
        # Add pagination
        param_count += 1
        base_query += f" LIMIT ${param_count}";
        params.append(request.limit)
        
        param_count += 1
        base_query += f" OFFSET ${param_count}";
        params.append(request.offset)
        
        print(f"🔍 Executing search query with {len(params)} parameters")
        rows = await conn.fetch(base_query, *params)
        
        results = []
        for row in rows:
            # Skip rows with null hs_code since it's required
            if not row['hs_code']:
                continue
                
            # Load restrictions for this trade code
            restrictions_query = """
            SELECT 
                rm.id as measure_id,
                rm.regulation_reference,
                rm.article_number, 
                rm.measure_type,
                rm.measure_description,
                rm.jurisdiction,
                rm.authority,
                rm.effective_date,
                rm.expiry_date,
                tcr.scope_notes,
                tcr.risk_level
            FROM trade_code_restrictions tcr
            JOIN restrictive_measures rm ON tcr.restrictive_measure_id = rm.id
            WHERE tcr.trade_code_id = $1
            """
            
            restriction_rows = await conn.fetch(restrictions_query, row['id'])
            restrictions = []
            
            for restriction_row in restriction_rows:
                restrictions.append({
                    "measure_id": str(restriction_row['measure_id']),
                    "regulation_reference": restriction_row['regulation_reference'],
                    "article_number": restriction_row['article_number'], 
                    "measure_type": restriction_row['measure_type'],
                    "measure_description": restriction_row['measure_description'],
                    "jurisdiction": restriction_row['jurisdiction'],
                    "authority": restriction_row['authority'],
                    "effective_date": restriction_row['effective_date'].isoformat() if restriction_row['effective_date'] else None,
                    "expiry_date": restriction_row['expiry_date'].isoformat() if restriction_row['expiry_date'] else None,
                    "scope_notes": restriction_row['scope_notes'],
                    "risk_level": restriction_row['risk_level']
                })
                
            # Determine match type
            match_type = "category"
            if request.hs_code and request.hs_code.lower() in row['hs_code'].lower():
                match_type = "exact_hs"
            elif request.cn_code and row['cn_code'] and request.cn_code.lower() in row['cn_code'].lower():
                match_type = "exact_cn"
            elif request.query:
                match_type = "description"
                
            # Calculate max risk level from restrictions
            risk_levels = [r['risk_level'] for r in restrictions if r['risk_level']]
            max_risk_level = None
            if risk_levels:
                risk_priority = {'critical': 4, 'high': 3, 'medium': 2, 'low': 1}
                max_risk = max(risk_levels, key=lambda x: risk_priority.get(x, 0))
                max_risk_level = max_risk
                
            results.append(CriticalProductSearchResult(
                id=str(row['id']),
                hs_code=row['hs_code'],
                cn_code=row['cn_code'],
                description=row['description'] or '',
                category=row['category'],
                subcategory=row['subcategory'],
                restrictions=restrictions,  # Now properly loaded!
                risk_level=max_risk_level,
                match_type=match_type
            ))
            
        return results
        
    except Exception as e:
        print(f"❌ Search error: {e}")
        raise HTTPException(status_code=500, detail=f"Search failed: {str(e)}")
    finally:
        await conn.close()

@router.get("/trade-codes")
async def list_trade_codes(
    user: AuthorizedUser,
    category: Optional[str] = Query(None),
    limit: int = Query(100, le=500)
) -> List[TradeCode]:
    """List all trade codes with optional category filtering."""
    conn = await get_db_connection()
    try:
        query = "SELECT * FROM trade_codes WHERE is_active = true"
        params = []
        
        if category:
            query += " AND category ILIKE $1"
            params.append(f"%{category}%")
            
        query += f" ORDER BY hs_code LIMIT {limit}"
        
        rows = await conn.fetch(query, *params)
        
        result = []
        for row in rows:
            row_dict = dict(row)
            row_dict['id'] = str(row_dict['id'])  # Convert UUID to string
            result.append(TradeCode(**row_dict))
        
        return result
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to list trade codes: {str(e)}")
    finally:
        await conn.close()

@router.post("/trade-codes")
async def create_trade_code(
    request: CreateTradeCodeRequest,
    user: AuthorizedUser
) -> TradeCode:
    """Create a new trade code entry."""
    conn = await get_db_connection()
    try:
        query = """
        INSERT INTO trade_codes (hs_code, cn_code, description, category, subcategory, unit_of_measure, created_by)
        VALUES ($1, $2, $3, $4, $5, $6, $7)
        RETURNING *
        """
        
        row = await conn.fetchrow(
            query,
            request.hs_code,
            request.cn_code,
            request.description,
            request.category,
            request.subcategory,
            request.unit_of_measure,
            user.sub
        )
        
        return TradeCode(**dict(row))
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to create trade code: {str(e)}")
    finally:
        await conn.close()

@router.get("/restrictive-measures")
async def list_restrictive_measures(
    user: AuthorizedUser,
    jurisdiction: Optional[str] = Query(None),
    measure_type: Optional[str] = Query(None),
    limit: int = Query(100, le=500)
) -> List[RestrictiveMeasure]:
    """List restrictive measures with optional filtering."""
    conn = await get_db_connection()
    try:
        query = "SELECT * FROM restrictive_measures WHERE is_active = true"
        params = []
        
        if jurisdiction:
            query += " AND jurisdiction ILIKE $1"
            params.append(f"%{jurisdiction}%")
            
        if measure_type:
            param_num = len(params) + 1
            query += f" AND measure_type = ${param_num}"
            params.append(measure_type)
            
        query += f" ORDER BY effective_date DESC LIMIT {limit}"
        
        rows = await conn.fetch(query, *params)
        
        # Convert UUID objects to strings for proper JSON serialization
        result = []
        seen_measures = set()  # Track unique measures by regulation_reference + jurisdiction
        
        for row in rows:
            row_dict = dict(row)
            # Convert UUID to string
            if 'id' in row_dict:
                row_dict['id'] = str(row_dict['id'])
            if 'created_by' in row_dict:
                row_dict['created_by'] = str(row_dict['created_by'])
            if 'updated_by' in row_dict and row_dict['updated_by']:
                row_dict['updated_by'] = str(row_dict['updated_by'])
            
            # Create unique key for deduplication
            unique_key = f"{row_dict['regulation_reference']}_{row_dict['jurisdiction']}_{row_dict['measure_type']}"
            
            if unique_key not in seen_measures:
                seen_measures.add(unique_key)
                result.append(RestrictiveMeasure(**row_dict))
        
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to list restrictive measures: {str(e)}")
    finally:
        await conn.close()

@router.post("/restrictive-measures")
async def create_restrictive_measure(
    request: CreateRestrictiveMeasureRequest,
    user: AuthorizedUser
) -> RestrictiveMeasure:
    """Create a new restrictive measure."""
    conn = await get_db_connection()
    try:
        query = """
        INSERT INTO restrictive_measures 
        (regulation_reference, article_number, measure_type, measure_description, 
         jurisdiction, authority, effective_date, expiry_date, created_by)
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
        RETURNING *
        """
        
        row = await conn.fetchrow(
            query,
            request.regulation_reference,
            request.article_number,
            request.measure_type,
            request.measure_description,
            request.jurisdiction,
            request.authority,
            request.effective_date,
            request.expiry_date,
            user.sub
        )
        
        return RestrictiveMeasure(**dict(row))
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to create restrictive measure: {str(e)}")
    finally:
        await conn.close()

@router.get("/product-categories")
async def get_categories(user: AuthorizedUser) -> List[str]:
    """Get list of available product categories."""
    conn = await get_db_connection()
    try:
        query = """
        SELECT DISTINCT category 
        FROM trade_codes 
        WHERE is_active = true AND category IS NOT NULL
        ORDER BY category
        """
        
        rows = await conn.fetch(query)
        return [row['category'] for row in rows if row['category']]
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to get categories: {str(e)}")
    finally:
        await conn.close()

@router.get("/product-jurisdictions")
async def get_jurisdictions(user: AuthorizedUser) -> List[str]:
    """Get list of available jurisdictions."""
    conn = await get_db_connection()
    try:
        query = """
        SELECT DISTINCT jurisdiction 
        FROM restrictive_measures 
        WHERE is_active = true
        ORDER BY jurisdiction
        """
        
        rows = await conn.fetch(query)
        return [row['jurisdiction'] for row in rows]
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to get jurisdictions: {str(e)}")
    finally:
        await conn.close()

@router.get("/measure-types")
async def get_measure_types(user: AuthorizedUser) -> List[str]:
    """Get list of available measure types."""
    conn = await get_db_connection()
    try:
        query = """
        SELECT DISTINCT measure_type 
        FROM restrictive_measures 
        WHERE is_active = true
        ORDER BY measure_type
        """
        
        rows = await conn.fetch(query)
        return [row['measure_type'] for row in rows]
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to get measure types: {str(e)}")
    finally:
        await conn.close()

@router.get("/critical-stats")
async def get_critical_products_stats(user: AuthorizedUser) -> Dict[str, Any]:
    """Get statistics about the critical products database."""
    conn = await get_db_connection()
    try:
        # Get counts
        stats_query = """
        SELECT 
            (SELECT COUNT(*) FROM trade_codes WHERE is_active = true) as total_trade_codes,
            (SELECT COUNT(*) FROM restrictive_measures WHERE is_active = true) as total_measures,
            (SELECT COUNT(*) FROM trade_code_restrictions) as total_restrictions,
            (SELECT COUNT(DISTINCT jurisdiction) FROM restrictive_measures WHERE is_active = true) as total_jurisdictions
        """
        
        stats_result = await conn.fetchrow(stats_query)
        
        # Get risk distribution (example aggregation)
        risk_query = """
        SELECT 
            COUNT(*) as medium
        FROM trade_code_restrictions
        """
        
        risk_result = await conn.fetchrow(risk_query)
        
        return {
            "total_trade_codes": stats_result['total_trade_codes'],
            "total_measures": stats_result['total_measures'], 
            "total_restrictions": stats_result['total_restrictions'],
            "total_jurisdictions": stats_result['total_jurisdictions'],
            "risk_distribution": {
                "medium": risk_result['medium']
            }
        }
        
    except Exception as e:
        print(f"Error getting critical products stats: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to get stats: {str(e)}")
    finally:
        await conn.close()

@router.get("/section-content/{section_type}")
async def get_critical_products_section_content(section_type: str, user: AuthorizedUser) -> Dict[str, Any]:
    """Get CMS content for Database sections (trade-codes, measures, restrictions, jurisdictions, product-classification)"""
    
    # Validate section type
    valid_sections = ['trade-codes', 'measures', 'restrictions', 'jurisdictions', 'product-classification']
    if section_type not in valid_sections:
        raise HTTPException(status_code=400, detail=f"Invalid section type. Must be one of: {valid_sections}")
    
    conn = await get_db_connection()
    try:
        # Get content from content_management table
        content_query = """
            SELECT id, content_type, title, content, metadata, created_at, updated_at
            FROM content_management 
            WHERE module_name = 'critical_products' AND content_key = $1
            ORDER BY created_at DESC
            LIMIT 1
        """
        
        content_result = await conn.fetchrow(content_query, f"{section_type}_explanation")
        
        if content_result:
            # Parse content if it's JSON
            content = content_result['content']
            if isinstance(content, str):
                try:
                    import json
                    content = json.loads(content)
                except:
                    pass
            
            # Parse metadata if it exists
            metadata = content_result['metadata']
            if isinstance(metadata, str) and metadata:
                try:
                    import json
                    metadata = json.loads(metadata)
                except:
                    metadata = {}
            
            return {
                "id": content_result['id'],
                "section_type": section_type,
                "title": content_result['title'],
                "content": content,
                "metadata": metadata or {},
                "created_at": content_result['created_at'].isoformat(),
                "updated_at": content_result['updated_at'].isoformat(),
                "has_content": True
            }
        else:
            # Return default fallback content
            default_content = {
                'trade-codes': {
                    'title': 'Understanding Trade Codes',
                    'content': 'Trade codes are standardized numerical identifiers used to classify products for international trade and regulatory purposes. They help determine applicable export controls, licensing requirements, and compliance obligations.'
                },
                'measures': {
                    'title': 'Regulatory Measures',
                    'content': 'Regulatory measures are specific requirements, restrictions, or controls imposed by governments on the export, import, or transit of certain products. These measures ensure compliance with national and international security and trade policies.'
                },
                'restrictions': {
                    'title': 'Product Restrictions',
                    'content': 'Product restrictions define specific limitations or prohibitions on the export or transfer of certain goods, technologies, or services. Understanding these restrictions is crucial for compliance with export control regulations.'
                },
                'jurisdictions': {
                    'title': 'Regulatory Jurisdictions',
                    'content': 'Different regulatory jurisdictions have varying export control frameworks. Understanding which jurisdiction\'s rules apply to your transactions is essential for proper compliance assessment.'
                },
                'product-classification': {
                    'title': 'Product Classification Overview',
                    'content': 'Product classification is the systematic process of determining the correct export control category for your products. This involves analyzing product characteristics, intended use, and technical specifications to ensure proper regulatory compliance. Our classification workflows guide you through this complex process step-by-step.'
                }
            }
            
            default = default_content.get(section_type, {
                'title': f'{section_type.replace("-", " ").title()} Information',
                'content': f'Information about {section_type} is currently being updated. Please check back later for detailed explanations.'
            })
            
            return {
                "id": None,
                "section_type": section_type,
                "title": default['title'],
                "content": default['content'],
                "metadata": {},
                "created_at": None,
                "updated_at": None,
                "has_content": False
            }
        
    except Exception as e:
        print(f"Error getting section content for {section_type}: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to get section content: {str(e)}")
    finally:
        await conn.close()

@router.get("/export-products", tags=["stream"])
async def export_critical_products(
    user: AuthorizedUser,
    format: str = "xlsx"
) -> StreamingResponse:
    """Export critical products data to Excel or CSV."""
    import io
    import pandas as pd
    from datetime import datetime
    
    conn = await get_db_connection()
    try:
        # Get all active trade codes with their restrictions
        export_query = """
        SELECT 
            tc.hs_code,
            tc.cn_code,
            tc.description,
            tc.category,
            tc.subcategory,
            tc.risk_level,
            tc.created_at,
            tc.updated_at,
            COUNT(tcr.id) as restriction_count,
            STRING_AGG(DISTINCT rm.jurisdiction, '; ') as jurisdictions,
            STRING_AGG(DISTINCT rm.measure_type, '; ') as measure_types
        FROM trade_codes tc
        LEFT JOIN trade_code_restrictions tcr ON tc.id = tcr.trade_code_id
        LEFT JOIN restrictive_measures rm ON tcr.restrictive_measure_id = rm.id AND rm.is_active = true
        WHERE tc.is_active = true
        GROUP BY tc.id, tc.hs_code, tc.cn_code, tc.description, tc.category, tc.subcategory, tc.risk_level, tc.created_at, tc.updated_at
        ORDER BY tc.hs_code
        """
        
        rows = await conn.fetch(export_query)
        
        # Convert to pandas DataFrame
        df = pd.DataFrame([
            {
                "HS Code": row["hs_code"],
                "CN Code": row["cn_code"],
                "Description": row["description"],
                "Category": row["category"],
                "Subcategory": row["subcategory"],
                "Risk Level": row["risk_level"],
                "Restrictions Count": row["restriction_count"],
                "Jurisdictions": row["jurisdictions"],
                "Measure Types": row["measure_types"],
                "Created At": row["created_at"].isoformat() if row["created_at"] else None,
                "Updated At": row["updated_at"].isoformat() if row["updated_at"] else None
            }
            for row in rows
        ])
        
        # Create export file
        output = io.BytesIO()
        
        if format.lower() == "csv":
            df.to_csv(output, index=False)
            output.seek(0)
            media_type = "text/csv"
            filename = f"critical-products-{datetime.now().strftime('%Y%m%d')}.csv"
        else:  # Excel format
            with pd.ExcelWriter(output, engine='openpyxl') as writer:
                df.to_excel(writer, sheet_name='Critical Products', index=False)
            output.seek(0)
            media_type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            filename = f"critical-products-{datetime.now().strftime('%Y%m%d')}.xlsx"
        
        return StreamingResponse(
            io.BytesIO(output.read()),
            media_type=media_type,
            headers={"Content-Disposition": f"attachment; filename={filename}"}
        )
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to export data: {str(e)}")
    finally:
        await conn.close()

@router.post("/critical-products/create")
async def create_critical_product(
    request: CreateTradeCodeRequest,
    user: AuthorizedUser
) -> Dict[str, Any]:
    """Create a new critical product entry."""
    conn = await get_db_connection()
    try:
        # Insert new trade code
        insert_query = """
        INSERT INTO trade_codes (
            hs_code, cn_code, description, category, subcategory, 
            risk_level, created_by, updated_by, is_active
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, true)
        RETURNING id, hs_code, description
        """
        
        result = await conn.fetchrow(
            insert_query,
            request.hs_code,
            getattr(request, 'cn_code', None),
            request.description,
            getattr(request, 'category', None),
            getattr(request, 'subcategory', None),
            getattr(request, 'risk_level', 'medium'),
            user.sub,
            user.sub
        )
        
        if not result:
            raise HTTPException(status_code=500, detail="Failed to create product")
            
        return {
            "id": str(result["id"]),
            "hs_code": result["hs_code"],
            "description": result["description"],
            "message": "Product created successfully"
        }
        
    except Exception as e:
        if "duplicate key" in str(e).lower():
            raise HTTPException(status_code=400, detail="Product with this HS code already exists")
        raise HTTPException(status_code=500, detail=f"Failed to create product: {str(e)}")
    finally:
        await conn.close()

@router.delete("/delete/{product_id}")
async def delete_critical_product(
    product_id: str,
    user: AuthorizedUser
) -> Dict[str, str]:
    """Delete a critical product."""
    conn = await get_db_connection()
    try:
        # Soft delete the trade code
        delete_query = """
        UPDATE trade_codes 
        SET is_active = false, updated_by = $1, updated_at = CURRENT_TIMESTAMP
        WHERE id = $2 AND is_active = true
        RETURNRETURN id
        """
        
        result = await conn.fetchrow(delete_query, user.sub, product_id)
        
        if not result:
            raise HTTPException(status_code=404, detail="Product not found")
            
        return {"message": "Product deleted successfully"}
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to delete product: {str(e)}")
    finally:
        await conn.close()

@router.post("/import")
async def import_critical_products(
    file: UploadFile,
    user: AuthorizedUser
) -> Dict[str, Any]:
    """Import critical products from Excel or CSV file."""
    import pandas as pd
    import io
    
    print(f"📁 Starting import for file: {file.filename}")
    
    if not file.filename:
        raise HTTPException(status_code=400, detail="No file provided")
        
    # Validate file format
    allowed_extensions = ['.xlsx', '.xls', '.csv']
    file_extension = None
    for ext in allowed_extensions:
        if file.filename.lower().endswith(ext):
            file_extension = ext
            break
            
    if not file_extension:
        raise HTTPException(
            status_code=400, 
            detail=f"Unsupported file format. Allowed formats: {', '.join(allowed_extensions)}"
        )
    
    print(f"📄 File extension detected: {file_extension}")
    
    conn = await get_db_connection()
    
    try:
        # Read file content
        content = await file.read()
        print(f"📊 File content size: {len(content)} bytes")
        
        # Parse based on file type
        if file_extension == '.csv':
            try:
                df = pd.read_csv(
                    io.BytesIO(content), 
                    encoding='utf-8',
                    dtype=str,  # Read all as strings to avoid type conversion issues
                    na_filter=False  # Don't convert empty strings to NaN
                )
            except UnicodeDecodeError:
                # Try different encodings
                df = pd.read_csv(
                    io.BytesIO(content), 
                    encoding='latin-1',
                    dtype=str,
                    na_filter=False
                )
        else:  # Excel
            # Try multiple approaches to read Excel files with mixed data types
            df = None
            read_attempts = [
                # Attempt 1: Read everything as strings (safest)
                {
                    'engine': 'openpyxl',
                    'dtype': str,
                    'na_filter': False,
                    'keep_default_na': False,
                    'header': 0,
                    'sheet_name': 0
                },
                # Attempt 2: Let pandas auto-detect but convert to strings after
                {
                    'engine': 'openpyxl', 
                    'header': 0,
                    'sheet_name': 0,
                    'na_filter': False
                },
                # Attempt 3: Fallback to xlrd for older files
                {
                    'engine': 'xlrd',
                    'dtype': str,
                    'na_filter': False,
                    'header': 0
                }
            ]
            
            last_error = None
            for i, params in enumerate(read_attempts):
                try:
                    print(f"📊 Excel read attempt {i+1} with engine: {params.get('engine', 'default')}")
                    df = pd.read_excel(io.BytesIO(content), **params)
                    
                    # Convert all columns to strings to avoid type issues
                    for col in df.columns:
                        df[col] = df[col].astype(str)
                        # Replace pandas string representations of NaN
                        df[col] = df[col].replace(['nan', 'None', 'NaN', 'NaT'], '')
                    
                    print(f"✅ Excel file read successfully with attempt {i+1}")
                    break
                except Exception as e:
                    last_error = e
                    print(f"❌ Excel read attempt {i+1} failed: {str(e)}")
                    continue
            
            if df is None:
                raise HTTPException(
                    status_code=400, 
                    detail=f"Cannot read Excel file with any method. Last error: {str(last_error)}"
                )
        
        print(f"📋 DataFrame shape: {df.shape}")
        print(f"📋 DataFrame columns: {list(df.columns)}")
        
        # Clean up column names - remove extra whitespace and handle encoding issues
        df.columns = [str(col).strip() for col in df.columns]
        print(f"📋 Cleaned columns: {list(df.columns)}")
        
        # Debug: Print first few rows to see actual data
        if len(df) > 0:
            first_row = {col: df.iloc[0][col] for col in df.columns}
            print(f"📋 First row actual data: {first_row}")
            if len(df) > 1:
                second_row = {col: df.iloc[1][col] for col in df.columns}
                print(f"📋 Second row actual data: {second_row}")
            if len(df) > 2:
                third_row = {col: df.iloc[2][col] for col in df.columns}
                print(f"📋 Third row actual data: {third_row}")
        
        # ENHANCED DEBUGGING: Show all unique values in each column for first 5 rows
        print("\n🔍 DETAILED COLUMN ANALYSIS:")
        for col in df.columns:
            sample_values = df[col].head(5).tolist()
            unique_values = df[col].head(10).unique().tolist()[:5]
            print(f"   Column '{col}': samples={sample_values}, unique={unique_values}")
        print("\n")
        
        # Check if DataFrame is empty
        if df.empty:
            raise HTTPException(status_code=400, detail="The uploaded file contains no data")
            
        # Remove completely empty rows (all columns are empty strings)
        df = df[~df.apply(lambda row: all(str(val).strip() == '' for val in row), axis=1)]
        print(f"📋 DataFrame after removing empty rows: {df.shape}")
        
        if df.empty:
            raise HTTPException(status_code=400, detail="The uploaded file contains no valid data rows")
        
        # Create flexible column mapping with better string handling
        column_mapping = {}
        
        # Create a mapping of lowercase, cleaned column names to original names
        available_columns = {}
        for col in df.columns:
            if col and str(col).strip():
                clean_key = str(col).lower().strip().replace('_', ' ').replace('-', ' ')
                available_columns[clean_key] = col
                print(f"🗂️ Column mapping: '{clean_key}' -> '{col}'")
        
        print(f"🗂️ Available columns for matching: {list(available_columns.keys())}")
        
        # Enhanced column matching with more variations
        def find_column(variations):
            for variation in variations:
                clean_variation = variation.lower().strip().replace('_', ' ').replace('-', ' ')
                if clean_variation in available_columns:
                    return available_columns[clean_variation]
            return None
        
        # Map HS Code with expanded variations
        hs_code_variations = [
            'hs_code', 'hs code', 'hscode', 'hs-code', 'hs',
            'harmonized system code', 'harmonized code', 'tariff code',
            'tariff number', 'commodity code', 'schedule b'
        ]
        hs_column = find_column(hs_code_variations)
        if hs_column:
            column_mapping['hs_code'] = hs_column
            print(f"✅ Found HS code column: {hs_column}")
                
        # Map Description with expanded variations  
        description_variations = [
            'description', 'product description', 'product_description', 'desc',
            'name', 'product name', 'product_name', 'commodity description',
            'item description', 'goods description', 'product'
        ]
        desc_column = find_column(description_variations)
        if desc_column:
            column_mapping['description'] = desc_column
            print(f"✅ Found description column: {desc_column}")
        
        print(f"🗂️ Required column mapping so far: {column_mapping}")
        
        # Validate required columns are found
        if 'hs_code' not in column_mapping:
            available_cols = list(df.columns)
            print(f"❌ No HS Code column found in: {available_cols}")
            raise HTTPException(
                status_code=400,
                detail=f"No HS Code column found. Available columns: {', '.join(available_cols)}. Expected: HS Code, hs_code, tariff code, etc."
            )
            
        if 'description' not in column_mapping:
            available_cols = list(df.columns)
            print(f"❌ No Description column found in: {available_cols}")
            raise HTTPException(
                status_code=400,
                detail=f"No Description column found. Available columns: {', '.join(available_cols)}. Expected: Description, Product Description, Name, etc."
            )
        
        # Map additional optional columns
        optional_mappings = {
            'cn_code': ['cn_code', 'cn code', 'cncode', 'cn-code', 'combined nomenclature', 'combined_nomenclature'],
            'category': ['category', 'product category', 'product_category', 'cat'],
            'subcategory': ['subcategory', 'sub category', 'sub_category', 'subcat'],
            'unitofmeasure': ['unitofmeasure', 'unit of measure', 'unit', 'uom', 'units'],
            'regulation_reference': ['regulation_reference', 'regulation reference', 'legal_reference', 'legal reference', 'regulation', 'reference'],
            'article_number': ['article_number', 'article number', 'article', 'section'],
            'measure_type': ['measure_type', 'measure type', 'measure', 'restriction_type', 'restriction type'],
            'measure_description': ['measure_description', 'measure description', 'description of measure', 'restriction_description', 'restriction description', 'notes'],
            'regulating_jurisdiction': ['regulating_jurisdiction', 'regulating jurisdiction', 'jurisdiction', 'authority_jurisdiction', 'issuing_jurisdiction'],
            'targeted_jurisdiction': ['targeted_jurisdiction', 'targeted jurisdiction', 'target_jurisdiction', 'target jurisdiction', 'restricted_jurisdiction'],
            'authority': ['authority', 'issuing_authority', 'issuing authority', 'regulatory_authority'],
            'effective_date': ['effective_date', 'effective date', 'start_date', 'start date', 'date'],
            'expiry_date': ['expiry_date', 'expiry date', 'end_date', 'end date', 'expiration_date'],
            'scope_notes': ['scope_notes', 'scope notes', 'notes', 'comments', 'remarks'],
            'risk_level': ['risk_level', 'risk level', 'risk', 'priority', 'severity']
        }
        
        for standard_name, variations in optional_mappings.items():
            if standard_name not in column_mapping:
                found_column = find_column(variations)
                if found_column:
                    column_mapping[standard_name] = found_column
                    print(f"✅ Found {standard_name} column: {found_column}")
        
        print(f"🗂️ Complete column mapping: {column_mapping}")
        
        # Create renamed dataframe
        df_renamed = df.rename(columns={v: k for k, v in column_mapping.items()})
        print(f"📋 Renamed DataFrame columns: {list(df_renamed.columns)}")
        
        # Import statistics
        total_records = len(df_renamed)
        successful_imports = 0
        failed_imports = 0
        duplicate_records = 0
        validation_errors = []
        
        # Process each row
        for index, row in df_renamed.iterrows():
            try:
                print(f"🔄 Processing row {index + 2}: {row.get('description', 'N/A')[:50]}...")
                
                # Extract HS/CN codes (both optional)
                hs_code_raw = row.get('hs_code')
                cn_code_raw = row.get('cn_code')
                
                # Clean HS code (optional)
                hs_code = None
                if pd.notna(hs_code_raw) and str(hs_code_raw).strip():
                    hs_code_clean = str(hs_code_raw).strip()
                    if hs_code_clean and hs_code_clean.lower() not in ['nan', 'none', 'null', '']:
                        hs_code = hs_code_clean
                
                # Clean CN code (optional)  
                cn_code = None
                if pd.notna(cn_code_raw) and str(cn_code_raw).strip():
                    cn_code_clean = str(cn_code_raw).strip()
                    if cn_code_clean and cn_code_clean.lower() not in ['nan', 'none', 'null', '']:
                        cn_code = cn_code_clean
                
                # Handle description (optional with fallback)
                description_raw = row.get('description')
                description = None
                
                # Check if description exists and is not empty
                if pd.notna(description_raw) and str(description_raw).strip():
                    description_clean = str(description_raw).strip()
                    if description_clean and description_clean.lower() not in ['nan', 'none', 'null', '']:
                        description = description_clean
                
                # If no description, create fallback based on available codes
                if not description:
                    if hs_code and cn_code:
                        description = f"Product with HS Code: {hs_code} and CN Code: {cn_code}"
                    elif hs_code:
                        description = f"Product with HS Code: {hs_code}"
                    elif cn_code:
                        description = f"Product with CN Code: {cn_code}"
                    else:
                        description = f"Imported product (Row {index + 2})"
                    
                    print(f"🔄 Generated fallback description: {description}")
                
                print(f"✅ Row {index + 2} validation passed: HS={hs_code or 'None'}, CN={cn_code or 'None'}, DESC={description[:30]}...")
                
                # Allow same HS codes with different regulatory contexts
                # Same product can be regulated by multiple jurisdictions
                
                # Prepare values for insertion
                cn_code_val = str(row.get('cn_code', '')).strip() if pd.notna(row.get('cn_code')) and str(row.get('cn_code', '')).strip() != 'nan' else None
                category_val = str(row.get('category', '')).strip() if pd.notna(row.get('category')) and str(row.get('category', '')).strip() != 'nan' else None
                subcategory_val = str(row.get('subcategory', '')).strip() if pd.notna(row.get('subcategory')) and str(row.get('subcategory', '')).strip() != 'nan' else None
                risk_level_val = str(row.get('risk_level', 'medium')).strip().lower() if pd.notna(row.get('risk_level')) and str(row.get('risk_level', '')).strip() != 'nan' else 'medium'
                
                # Normalize risk level values
                if risk_level_val in ['', 'none', 'unknown', 'nan', 'null']:
                    risk_level_val = 'medium'
                elif risk_level_val not in ['low', 'medium', 'high']:
                    print(f"⚠️ Unknown risk level '{risk_level_val}', defaulting to 'medium'")
                    risk_level_val = 'medium'
                
                print(f"🔧 Prepared values - CN: {cn_code_val}, Cat: {category_val}, Risk: {risk_level_val}")
                
                # Insert new trade code
                insert_query = """
                INSERT INTO trade_codes (
                    hs_code, cn_code, description, category, subcategory, 
                    risk_level, created_by, updated_by, is_active
                ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, true)
                RETURNING id
                """
                
                print(f"🗃️ Executing trade code insert for HS: {hs_code or 'None'}")
                trade_code_result = await conn.fetchrow(
                    insert_query,
                    hs_code,  # This is now optional (can be None)
                    cn_code_val,
                    description,
                    category_val,
                    subcategory_val,
                    risk_level_val,
                    user.sub,
                    user.sub
                )
                
                trade_code_id = trade_code_result['id']
                print(f"✅ Trade code inserted with ID: {trade_code_id}")
                
                # If we have regulatory information, create a restrictive measure
                regulating_jurisdiction = str(row.get('regulating_jurisdiction', '')).strip() if pd.notna(row.get('regulating_jurisdiction')) and str(row.get('regulating_jurisdiction', '')).strip() != 'nan' else None
                targeted_jurisdiction = str(row.get('targeted_jurisdiction', '')).strip() if pd.notna(row.get('targeted_jurisdiction')) and str(row.get('targeted_jurisdiction', '')).strip() != 'nan' else None
                regulation_reference = str(row.get('regulation_reference', '')).strip() if pd.notna(row.get('regulation_reference')) and str(row.get('regulation_reference', '')).strip() != 'nan' else None
                measure_type = str(row.get('measure_type', '')).strip() if pd.notna(row.get('measure_type')) and str(row.get('measure_type', '')).strip() != 'nan' else None
                measure_description = str(row.get('measure_description', '')).strip() if pd.notna(row.get('measure_description')) and str(row.get('measure_description', '')).strip() != 'nan' else None
                authority = str(row.get('authority', '')).strip() if pd.notna(row.get('authority')) and str(row.get('authority', '')).strip() != 'nan' else None
                effective_date_raw = str(row.get('effective_date', '')).strip() if pd.notna(row.get('effective_date')) and str(row.get('effective_date', '')).strip() != 'nan' else None
                scope_notes = str(row.get('scope_notes', '')).strip() if pd.notna(row.get('scope_notes')) and str(row.get('scope_notes', '')).strip() != 'nan' else None
                
                # Convert effective_date to proper date object
                effective_date = None
                if effective_date_raw:
                    try:
                        from datetime import datetime
                        # Try to parse various date formats
                        for date_format in ['%Y-%m-%d', '%d/%m/%Y', '%m/%d/%Y', '%Y-%m-%d %H:%M:%S']:
                            try:
                                effective_date = datetime.strptime(effective_date_raw, date_format).date()
                                break
                            except ValueError:
                                continue
                        if not effective_date:
                            print(f"⚠️ Could not parse date '{effective_date_raw}', using default")
                            effective_date = datetime(2024, 1, 1).date()
                    except Exception as e:
                        print(f"⚠️ Date parsing error: {e}, using default")
                        effective_date = datetime(2024, 1, 1).date()
                else:
                    # Default effective date as proper date object
                    from datetime import datetime
                    effective_date = datetime(2024, 1, 1).date()
                
                # Normalize measure_type to match database constraints
                if measure_type:
                    measure_type_lower = measure_type.lower()
                    if 'export' in measure_type_lower and ('prohibit' in measure_type_lower or 'ban' in measure_type_lower):
                        measure_type = 'export_prohibition'
                    elif 'import' in measure_type_lower and ('prohibit' in measure_type_lower or 'ban' in measure_type_lower):
                        measure_type = 'import_prohibition'
                    elif 'licens' in measure_type_lower or 'permit' in measure_type_lower:
                        measure_type = 'licensing_requirement'
                    elif 'technical' in measure_type_lower and 'assistance' in measure_type_lower:
                        measure_type = 'technical_assistance_prohibition'
                    elif 'financ' in measure_type_lower:
                        measure_type = 'financing_prohibition'
                    else:
                        # For any other types like "Guidance", "List", etc., use 'other'
                        measure_type = 'other'
                        print(f"⚠️ Mapping non-standard measure type '{row.get('measure_type')}' to 'other'")
                
                if regulating_jurisdiction and regulation_reference and measure_type:
                    print(f"🏛️ Creating restrictive measure for {regulating_jurisdiction} -> {targeted_jurisdiction}")
                    # Create restrictive measure with combined jurisdiction info
                    jurisdiction_info = regulating_jurisdiction
                    if targeted_jurisdiction:
                        jurisdiction_info += f" -> {targeted_jurisdiction}"
                    
                    # Create restrictive measure
                    measure_insert_query = """
                    INSERT INTO restrictive_measures (
                        regulation_reference, measure_type, measure_description, jurisdiction,
                        authority, effective_date, is_active, created_by, updated_by
                    ) VALUES ($1, $2, $3, $4, $5, $6, true, $7, $8)
                    RETURNING id
                    """
                    
                    measure_result = await conn.fetchrow(
                        measure_insert_query,
                        regulation_reference,
                        measure_type,
                        measure_description or f"Imported measure for {hs_code}",
                        jurisdiction_info,
                        authority,
                        effective_date,  # Always a date object now
                        user.sub,
                        user.sub
                    )
                    
                    measure_id = measure_result['id']
                    print(f"✅ Restrictive measure created with ID: {measure_id}")
                    
                    # Link trade code to restrictive measure
                    link_query = """
                    INSERT INTO trade_code_restrictions (
                        trade_code_id, restrictive_measure_id, scope_notes, risk_level, created_by, updated_by
                    ) VALUES ($1, $2, $3, $4, $5, $6)
                    """
                    
                    await conn.execute(
                        link_query,
                        trade_code_id,
                        measure_id,
                        scope_notes,
                        risk_level_val,
                        user.sub,
                        user.sub
                    )
                    print(f"🔗 Trade code linked to restrictive measure")
                
                successful_imports += 1
                print(f"✅ Successfully imported: {hs_code} - {description}")
                
            except Exception as e:
                error_msg = f"Row {index + 2}: {str(e)}"
                print(f"❌ Error importing row {index + 2}: {str(e)}")
                print(f"📋 Row data: {dict(row)}")
                validation_errors.append(error_msg)
                failed_imports += 1
        
        print(f"📊 Import completed: {successful_imports} successful, {failed_imports} failed, {duplicate_records} duplicates")
        
        return {
            "total_records": total_records,
            "successful_imports": successful_imports,
            "failed_imports": failed_imports,
            "duplicate_records": duplicate_records,
            "validation_errors": validation_errors[:10]  # Limit to first 10 errors
        }
        
    except pd.errors.EmptyDataError:
        raise HTTPException(status_code=400, detail="The uploaded file is empty")
    except pd.errors.ParserError:
        raise HTTPException(status_code=400, detail="Unable to parse the file. Please check the format.")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to import data: {str(e)}")
    finally:
        await conn.close()

@router.post("/clear-database")
async def clear_critical_products_database(
    user: AuthorizedUser
) -> dict:
    """Clear all critical products data from the database."""
    conn = await get_db_connection()
    try:
        # Clear tables in correct order to avoid foreign key constraints
        await conn.execute("DELETE FROM trade_code_restrictions")
        await conn.execute("DELETE FROM restrictive_measures")
        await conn.execute("DELETE FROM trade_codes")
        
        return {
            "message": "Critical products database cleared successfully",
            "cleared_tables": ["trade_code_restrictions", "restrictive_measures", "trade_codes"]
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to clear database: {str(e)}")
    finally:
        await conn.close()
