from fastapi import APIRouter, UploadFile, File, HTTPException
from pydantic import BaseModel
import databutton as db
from typing import List, Optional
import uuid
import re
from app.auth import AuthorizedUser

router = APIRouter()

# Default value for optional file parameter
DEFAULT_FILE = File(None)

class DocumentUploadResponse(BaseModel):
    document_url: str
    document_id: str
    filename: str
    size: int
    file_type: str

class DocumentListResponse(BaseModel):
    documents: List[DocumentUploadResponse]

@router.post("/upload-document")
async def upload_document_attachment(
    file: UploadFile = File(...),
    user: AuthorizedUser = None
) -> DocumentUploadResponse:
    """Upload a document for attachment to blog articles"""
    
    # Validate file type - allow common document formats
    allowed_types = [
        'application/pdf',
        'application/msword',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'application/vnd.ms-excel',
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'application/vnd.ms-powerpoint',
        'application/vnd.openxmlformats-officedocument.presentationml.presentation',
        'text/plain',
        'text/csv',
        'application/rtf',
        'application/vnd.oasis.opendocument.text',
        'application/vnd.oasis.opendocument.spreadsheet',
        'application/vnd.oasis.opendocument.presentation'
    ]
    
    if file.content_type not in allowed_types:
        raise HTTPException(
            status_code=400,
            detail="Unsupported file type. Please upload PDF, Word, Excel, PowerPoint, or text files."
        )
    
    # Validate file size (10MB max)
    content = await file.read()
    if len(content) > 10 * 1024 * 1024:
        raise HTTPException(
            status_code=400,
            detail="File size exceeds 10MB limit"
        )

    try:
        # Generate unique ID - use only alphanumeric characters
        document_id = str(uuid.uuid4()).replace('-', '')
        original_filename = file.filename or 'document'
        
        print(f"Debug - Original filename: {original_filename}")
        print(f"Debug - Document ID: {document_id}")
        
        # Use the simplest possible storage key - just the UUID without slash
        storage_key = f"documents_{document_id}"
        
        print(f"Debug - Ultra-simple storage key: {storage_key}")
        print(f"Debug - Storage key characters: {[c for c in storage_key]}")
        
        # Store the file
        db.storage.binary.put(storage_key, content)
        
        # Generate public URL for the document
        document_url = f"/api/documents/{document_id}"
        
        print(f"Document uploaded successfully: {storage_key}")
        
        return DocumentUploadResponse(
            document_url=document_url,
            document_id=document_id,
            filename=original_filename,
            size=len(content),
            file_type=file.content_type or 'application/octet-stream'
        )
        
    except Exception as e:
        print(f"Document upload error: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail="Failed to upload document. Please try again."
        ) from e

@router.get("/documents/{document_filename}")
async def serve_document(document_filename: str):
    """Serve uploaded documents"""
    try:
        # The document_filename is now just the document ID
        document_id = document_filename
        storage_key = f"documents_{document_id}"
        
        print(f"Debug - Serving document with storage key: {storage_key}")
        
        # Get document data from storage
        document_data = db.storage.binary.get(storage_key)
        
        if not document_data:
            raise HTTPException(status_code=404, detail="Document not found")
        
        # Determine content type based on file extension
        content_type = "application/octet-stream"
        if document_id.lower().endswith('.pdf'):
            content_type = "application/pdf"
        elif document_id.lower().endswith(('.doc', '.docx')):
            content_type = "application/msword"
        elif document_id.lower().endswith(('.xls', '.xlsx')):
            content_type = "application/vnd.ms-excel"
        elif document_id.lower().endswith('.txt'):
            content_type = "text/plain"
        
        # Return the document with appropriate headers
        from fastapi.responses import Response
        return Response(
            content=document_data,
            media_type=content_type,
            headers={
                "Content-Disposition": f"inline; filename={document_id}"
            }
        )
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error serving document {document_filename}: {str(e)}")
        raise HTTPException(status_code=404, detail="Document not found")

@router.get("/list-documents")
async def list_attachment_documents(user: AuthorizedUser) -> DocumentListResponse:
    """List all uploaded documents"""
    try:
        # Get all files from the documents folder using prefix
        document_files = db.storage.list_files(prefix="documents_")
        
        documents = []
        for file_info in document_files:
            filename = file_info['key'].replace('documents_', '')
            document_id = filename.split('_')[0] if '_' in filename else filename
            
            # Determine file type based on extension
            file_type = "application/octet-stream"
            if filename.lower().endswith('.pdf'):
                file_type = "application/pdf"
            elif filename.lower().endswith(('.doc', '.docx')):
                file_type = "application/msword"
            elif filename.lower().endswith(('.xls', '.xlsx')):
                file_type = "application/vnd.ms-excel"
            elif filename.lower().endswith('.txt'):
                file_type = "text/plain"
            
            documents.append(DocumentUploadResponse(
                document_url=f"/api/documents/{filename}",
                document_id=document_id,
                filename=filename,
                size=file_info.get('size', 0),
                file_type=file_type
            ))
        
        return DocumentListResponse(documents=documents)
        
    except Exception as e:
        print(f"Error listing documents: {str(e)}")
        return DocumentListResponse(documents=[])

@router.delete("/documents/{document_filename}")
async def delete_attachment_document(document_filename: str, user: AuthorizedUser):
    """Delete an uploaded document"""
    try:
        # Sanitize the filename
        safe_filename = re.sub(r'[^a-zA-Z0-9._-]', '_', document_filename)
        storage_key = f"documents_{safe_filename}"
        
        # Delete from storage
        db.storage.delete(storage_key)
        
        return {"message": "Document deleted successfully"}
        
    except Exception as e:
        print(f"Error deleting document {document_filename}: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail="Failed to delete document"
        ) from e
