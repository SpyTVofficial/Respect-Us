
from fastapi import APIRouter, HTTPException, Response, File, UploadFile, Depends
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from typing import List, Optional, Dict, Any
import asyncpg
import databutton as db
from app.auth import AuthorizedUser
from app.env import Mode, mode
from datetime import datetime

router = APIRouter(prefix="/excel-export")

class ExcelImportResponse(BaseModel):
    success_count: int
    error_count: int
    message: str

# Database connection helper
async def get_db_connection():
    database_url = db.secrets.get("DATABASE_URL_DEV")
    return await asyncpg.connect(database_url)

@router.get("/export-notes/{tree_id}")
async def export_notes_to_excel(tree_id: str, user: AuthorizedUser, module_type: str = "product_classification"):
    """
    Export all regulatory notes to Excel format
    If tree_id is 'global', export all global notes (tree_id = NULL)
    Otherwise export notes for specific tree
    """
    conn = await get_db_connection()
    try:
        # Determine query based on tree_id parameter
        if tree_id.lower() == 'global':
            # Export all global notes (tree_id = NULL) for specific module
            query = """
            SELECT note_key, title, content, tree_id, module_type, created_by, created_at, updated_at
            FROM classification_notes 
            WHERE tree_id IS NULL AND module_type = $1
            ORDER BY note_key
            """
            query_params = [module_type]
            filename_prefix = f"global_{module_type}_notes"
        else:
            # Export notes for specific tree and module
            query = """
            SELECT note_key, title, content, tree_id, module_type, created_by, created_at, updated_at
            FROM classification_notes 
            WHERE tree_id = $1 AND module_type = $2
            ORDER BY note_key
            """
            query_params = [tree_id, module_type]
            filename_prefix = f"tree_{module_type}_notes"
        
        rows = await conn.fetch(query, *query_params)
        
        if not rows:
            if tree_id.lower() == 'global':
                raise HTTPException(status_code=404, detail=f"No global notes found for module {module_type}")
            else:
                raise HTTPException(status_code=404, detail=f"No notes found for this tree in module {module_type}")
        
        # Create Excel workbook
        wb = Workbook()
        ws = wb.active
        ws.title = "Regulatory Notes"
        
        # Add headers
        headers = ['Note Key', 'Title', 'Content', 'Tree ID', 'Module Type', 'Created By', 'Created At', 'Updated At']
        ws.append(headers)
        
        # Add data rows
        for row in rows:
            ws.append([
                row['note_key'],
                row['title'], 
                row['content'],
                str(row['tree_id']) if row['tree_id'] else 'Global',  # Show 'Global' for NULL tree_id
                row['module_type'],
                str(row['created_by']) if row['created_by'] else '',  # Convert UUID to string
                row['created_at'].isoformat() if row['created_at'] else '',
                row['updated_at'].isoformat() if row['updated_at'] else ''
            ])
        
        # Save to memory buffer
        excel_buffer = io.BytesIO()
        wb.save(excel_buffer)
        excel_buffer.seek(0)
        excel_data = excel_buffer.getvalue()
        
        # Generate filename with timestamp
        timestamp = datetime.now().strftime("%Y%m%dT%H%M%S")
        filename = f"{filename_prefix}_{timestamp}.xlsx"
        
        # Return as proper Response with Excel data
        return Response(
            content=excel_data,
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers={"Content-Disposition": f"attachment; filename={filename}"}
        )
        
    except Exception as e:
        print(f"Error exporting notes: {e}")
        raise HTTPException(status_code=500, detail="Failed to export notes")
    finally:
        await conn.close()

@router.post("/import-notes/{tree_id}")
async def import_notes_from_excel(
    tree_id: str, 
    user: AuthorizedUser,
    file_content: UploadFile = File(...),
    module_type: str = "product_classification"
) -> ExcelImportResponse:
    """
    Import regulatory notes from Excel file content
    """
    conn = await get_db_connection()
    try:
        # Read file content
        file_bytes = await file_content.read()
        
        # Load Excel file from bytes
        excel_buffer = io.BytesIO(file_bytes)
        wb = load_workbook(excel_buffer)
        ws = wb.active
        
        success_count = 0
        error_count = 0
        
        # Skip header row, process data rows
        for row_num, row in enumerate(ws.iter_rows(min_row=2, values_only=True), start=2):
            try:
                # Extract values from row
                note_key = row[0] if row[0] else ''
                title = row[1] if row[1] else ''
                content = row[2] if row[2] else ''
                
                # Validate required fields
                if not note_key.strip() or not title.strip() or not content.strip():
                    print(f"Skipping row {row_num}: missing required fields")
                    error_count += 1
                    continue
                
                # Insert into database with module_type
                insert_query = """
                INSERT INTO classification_notes (note_key, title, content, tree_id, module_type, created_by, created_at, updated_at)
                VALUES ($1, $2, $3, $4, $5, $6, NOW(), NOW())
                """
                
                await conn.execute(
                    insert_query,
                    note_key.strip(),
                    title.strip(), 
                    content.strip(),
                    tree_id if tree_id.lower() != 'global' else None,
                    module_type,
                    user.sub
                )
                
                success_count += 1
                
            except Exception as row_error:
                print(f"Error processing row {row_num}: {row_error}")
                error_count += 1
                continue
        
        message = f"Import completed: {success_count} notes imported successfully"
        if error_count > 0:
            message += f", {error_count} rows failed"
        
        return ExcelImportResponse(
            success_count=success_count,
            error_count=error_count,
            message=message
        )
        
    except Exception as e:
        print(f"Error importing notes: {e}")
        raise HTTPException(status_code=500, detail="Failed to import notes")
    finally:
        await conn.close()
