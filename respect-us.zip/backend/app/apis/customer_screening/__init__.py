# Customer Screening API - Backend service restart to clear cached query plans
# Fixed: cached statement plan is invalid due to a database schema or configuration change

from datetime import datetime, date
from typing import List, Optional, Dict, Any
from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel, Field
import asyncpg
import databutton as db
import uuid
import json
from app.auth import AuthorizedUser
from app.libs.database import get_db_connection
from app.libs.credit_wrapper import consume_credits_for_action

router = APIRouter(prefix="/customer-screening")

# Pydantic Models for Customer Screening

class CustomerProfile(BaseModel):
    """Customer profile information for screening"""
    id: Optional[int] = None
    customer_name: str = Field(..., min_length=1, max_length=500)
    customer_type: str = Field(default="individual")  # individual, entity, vessel, airplane
    legal_name: Optional[str] = None
    aliases: List[str] = Field(default_factory=list)
    address: Optional[str] = None
    city: Optional[str] = None
    country: Optional[str] = None
    postal_code: Optional[str] = None
    date_of_birth: Optional[date] = None  # For individuals
    incorporation_date: Optional[date] = None  # For companies
    registration_number: Optional[str] = None
    tax_id: Optional[str] = None
    phone: Optional[str] = None
    email: Optional[str] = None
    website: Optional[str] = None
    business_type: Optional[str] = None
    risk_category: str = Field(default="standard")  # low, standard, high
    notes: Optional[str] = None
    created_by: Optional[str] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

class WatchlistEntry(BaseModel):
    """Watchlist entry for screening against"""
    id: Optional[int] = None
    list_name: str  # OFAC SDN, EU Sanctions, UN Sanctions, etc.
    entity_name: str
    aliases: List[str] = Field(default_factory=list)
    entity_type: str  # individual, company, vessel, aircraft
    country: Optional[str] = None
    date_of_birth: Optional[date] = None
    identification_numbers: List[str] = Field(default_factory=list)
    sanctions_program: str
    listing_date: Optional[date] = None
    last_updated: Optional[datetime] = None
    is_active: bool = Field(default=True)
    source_url: Optional[str] = None
    raw_data: Dict[str, Any] = Field(default_factory=dict)

class ScreeningMatch(BaseModel):
    """Screening match result"""
    # Database fields (for compatibility with existing storage)
    id: Optional[int] = None
    screening_id: Optional[int] = None
    watchlist_entry_id: str  # Changed to str to support admin sanctions IDs
    match_type: str  # exact, fuzzy, alias
    match_score: float = Field(ge=0.0, le=1.0)  # 0-1 confidence score
    matched_field: str  # name, alias, identification_number
    matched_value: str  # The actual text that matched
    risk_level: str = Field(default="medium")  # low, medium, high, critical
    
    # Additional match details
    original_value: Optional[str] = None  # Original customer field value
    confidence_factors: Dict[str, Any] = Field(default_factory=dict)
    is_false_positive: bool = Field(default=False)
    verification_status: str = Field(default="pending")  # pending, verified, dismissed
    verification_notes: Optional[str] = None
    verified_by: Optional[str] = None
    verified_at: Optional[datetime] = None

class ScreeningResult(BaseModel):
    """Complete screening result"""
    id: Optional[int] = None
    customer_id: int
    screening_type: str = Field(default="full")  # full, update, batch
    status: str = Field(default="pending")  # pending, completed, failed
    overall_risk_score: float = Field(default=0.0, ge=0.0, le=1.0)
    risk_level: str = Field(default="low")  # low, medium, high, critical
    total_matches: int = Field(default=0)
    high_risk_matches: int = Field(default=0)
    false_positives: int = Field(default=0)
    screening_date: datetime = Field(default_factory=datetime.utcnow)
    screened_by: str
    screening_duration_ms: Optional[int] = None
    watchlists_checked: List[str] = Field(default_factory=list)
    matches: List[ScreeningMatch] = Field(default_factory=list)
    alerts_generated: bool = Field(default=False)
    export_count: int = Field(default=0)
    last_exported: Optional[datetime] = None
    notes: Optional[str] = None

class ScreeningAlert(BaseModel):
    """High-risk screening alert"""
    id: Optional[int] = None
    screening_id: int
    customer_id: int
    alert_type: str  # high_risk_match, new_sanctions, updated_listing
    priority: str = Field(default="medium")  # low, medium, high, critical
    message: str
    details: Dict[str, Any] = Field(default_factory=dict)
    status: str = Field(default="open")  # open, reviewing, resolved, false_positive
    assigned_to: Optional[str] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)
    resolved_at: Optional[datetime] = None
    resolution_notes: Optional[str] = None

class VersionedScreeningRequest(BaseModel):
    """Request for versioned screening at a specific date"""
    screening_date: Optional[datetime] = Field(default=None, description="Date to screen against (uses current lists if None)")
    force_rescreen: bool = Field(default=False, description="Force re-screening even if recent results exist")
    notes: Optional[str] = Field(default=None, description="Notes about this screening")

class BatchScreeningRequest(BaseModel):
    """Request for batch screening multiple customers"""
    customer_ids: List[int]
    force_rescreen: bool = Field(default=False)
    screening_date: Optional[datetime] = Field(default=None, description="Date to screen against (uses current lists if None)")

class ScreeningExportRequest(BaseModel):
    """Request for exporting screening results"""
    screening_ids: List[int] = Field(..., min_items=1)
    export_format: str = Field(default="pdf")  # pdf, excel, json
    include_false_positives: bool = Field(default=False)
    include_raw_data: bool = Field(default=False)

class HitVerificationRequest(BaseModel):
    """Request for hit verification decision"""
    match_id: int
    customer_id: int
    screening_id: int
    verification_decision: str  # "match", "no_match"
    verification_reason: Optional[str] = None
    verification_notes: Optional[str] = None

class HitVerificationResponse(BaseModel):
    """Response for hit verification"""
    id: int
    match_id: int
    customer_id: int
    screening_id: int
    verification_decision: str
    verification_reason: Optional[str] = None
    verification_notes: Optional[str] = None
    verified_by: str
    verified_at: datetime
    created_at: datetime

class WatchlistSearchRequest(BaseModel):
    search_term: str
    entity_type: Optional[str] = None
    country: Optional[str] = None 
    date_of_birth: Optional[str] = None
    exact_match: bool = False
    limit: int = 50

class WatchlistSearchResult(BaseModel):
    watchlist_entry: WatchlistEntry
    match_score: float
    match_type: str  # "exact", "partial", "phonetic"
    matched_field: str  # "name", "alias", "identification"
    risk_assessment: str  # "low", "medium", "high", "critical"

class ScreeningMatchQualificationRequest(BaseModel):
    screening_id: int
    match_index: int
    qualification: str  # 'true_match', 'false_positive', 'pending'
    notes: str | None = None

class ScreeningMatchQualificationResponse(BaseModel):
    success: bool
    message: str
    updated_match: dict | None = None

class MatchQualificationRequest(BaseModel):
    is_false_positive: bool
    notes: str | None = None

class MatchQualificationResponse(BaseModel):
    match_id: int
    screening_id: int
    customer_id: int
    is_false_positive: bool
    notes: str
    reviewed_by: str
    reviewed_at: datetime
    updated: bool

# API Endpoints

@router.post("/customers", response_model=CustomerProfile)
async def create_customer(customer: CustomerProfile, user: AuthorizedUser) -> CustomerProfile:
    """Create a new customer profile for screening"""
    print(f"📝 Creating customer profile: {customer.customer_name}")
    
    try:
        db_url = db.secrets.get("DATABASE_URL_DEV")
        conn = await asyncpg.connect(db_url)
        
        try:
            # Normalize values to match database constraints
            customer_type = customer.customer_type.lower()
            risk_category = customer.risk_category.lower();
            
            # Insert customer profile
            customer_id = await conn.fetchval(
                """
                INSERT INTO customer_profiles (
                    customer_name, customer_type, legal_name, aliases, address, city, country,
                    postal_code, date_of_birth, incorporation_date, registration_number,
                    tax_id, phone, email, website, business_type, risk_category, notes,
                    created_by, created_at, updated_at
                ) VALUES (
                    $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18, $19, $20, $21
                ) RETURNING id
                """,
                customer.customer_name, customer_type, customer.legal_name,
                json.dumps(customer.aliases), customer.address, customer.city, customer.country,
                customer.postal_code, customer.date_of_birth, customer.incorporation_date,
                customer.registration_number, customer.tax_id, customer.phone, customer.email,
                customer.website, customer.business_type, risk_category, customer.notes,
                user.sub, datetime.utcnow(), datetime.utcnow()
            )
            
            # Return created customer with ID
            customer.id = customer_id
            customer.created_by = user.sub
            customer.created_at = datetime.utcnow()
            customer.updated_at = datetime.utcnow()
            # Normalize the returned values too
            customer.customer_type = customer_type
            customer.risk_category = risk_category
            
            print(f"✅ Customer profile created with ID: {customer_id}")
            return customer
            
        finally:
            await conn.close()
            
    except Exception as e:
        print(f"❌ Error creating customer profile: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to create customer profile: {str(e)}")

@router.put("/customers/{customer_id}", response_model=CustomerProfile)
async def update_customer(customer_id: int, customer: CustomerProfile, user: AuthorizedUser) -> CustomerProfile:
    """Update an existing customer profile"""
    print(f"📝 Updating customer profile ID: {customer_id}")
    
    try:
        db_url = db.secrets.get("DATABASE_URL_DEV")
        conn = await asyncpg.connect(db_url)
        
        try:
            # Check if customer exists
            exists = await conn.fetchval(
                "SELECT COUNT(*) FROM customer_profiles WHERE id = $1", customer_id
            )
            
            if not exists:
                raise HTTPException(status_code=404, detail="Customer not found")
            
            # Normalize values
            customer_type = customer.customer_type.lower()
            risk_category = customer.risk_category.lower()
            
            # Update customer profile
            updated_id = await conn.fetchval(
                """
                UPDATE customer_profiles SET
                    customer_name = $1, customer_type = $2, legal_name = $3, aliases = $4,
                    address = $5, city = $6, country = $7, postal_code = $8,
                    date_of_birth = $9, incorporation_date = $10, registration_number = $11,
                    tax_id = $12, phone = $13, email = $14, website = $15,
                    business_type = $16, risk_category = $17, notes = $18, updated_at = $19
                WHERE id = $20
                RETURNING id
                """,
                customer.customer_name, customer_type, customer.legal_name,
                json.dumps(customer.aliases), customer.address, customer.city, customer.country,
                customer.postal_code, customer.date_of_birth, customer.incorporation_date,
                customer.registration_number, customer.tax_id, customer.phone, customer.email,
                customer.website, customer.business_type, risk_category, customer.notes,
                datetime.utcnow(), customer_id
            )
            
            # Return updated customer
            customer.id = updated_id
            customer.customer_type = customer_type
            customer.risk_category = risk_category
            customer.updated_at = datetime.utcnow()
            
            print(f"✅ Customer profile updated: {customer_id}")
            return customer
            
        finally:
            await conn.close()
            
    except HTTPException:
        raise
    except Exception as e:
        print(f"❌ Error updating customer profile: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to update customer profile: {str(e)}")

@router.delete("/customers/{customer_id}")
async def delete_customer(customer_id: int, user: AuthorizedUser) -> dict:
    """Delete a customer profile and associated screening data"""
    print(f"🗑️ Deleting customer profile ID: {customer_id}")
    
    try:
        db_url = db.secrets.get("DATABASE_URL_DEV")
        conn = await asyncpg.connect(db_url)
        
        try:
            # Check if customer exists
            exists = await conn.fetchval(
                "SELECT COUNT(*) FROM customer_profiles WHERE id = $1", customer_id
            )
            
            if not exists:
                raise HTTPException(status_code=404, detail="Customer not found")
            
            # Delete associated screening data first (cascade)
            await conn.execute(
                "DELETE FROM screening_matches WHERE screening_id IN (SELECT id FROM screening_results WHERE customer_id = $1)",
                customer_id
            )
            
            await conn.execute(
                "DELETE FROM screening_alerts WHERE customer_id = $1", customer_id
            )
            
            await conn.execute(
                "DELETE FROM screening_results WHERE customer_id = $1", customer_id
            )
            
            # Delete customer profile
            await conn.execute(
                "DELETE FROM customer_profiles WHERE id = $1", customer_id
            )
            
            print(f"✅ Customer profile deleted: {customer_id}")
            return {"message": "Customer profile deleted successfully", "customer_id": customer_id}
            
        finally:
            await conn.close()
            
    except HTTPException:
        raise
    except Exception as e:
        print(f"❌ Error deleting customer profile: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to delete customer profile: {str(e)}")

@router.post("/batch-screen", response_model=dict)
@consume_credits_for_action("customer_screening", "batch_screening")
async def batch_screen_customers(request: BatchScreeningRequest, user: AuthorizedUser) -> dict:
    """Perform batch screening for multiple customers"""
    print(f"🔍 Starting batch screening for {len(request.customer_ids)} customers")
    
    try:
        db_url = db.secrets.get("DATABASE_URL_DEV")
        conn = await asyncpg.connect(db_url)
        
        try:
            results = []
            errors = []
            
            for customer_id in request.customer_ids:
                try:
                    # Get customer profile
                    customer = await conn.fetchrow(
                        "SELECT * FROM customer_profiles WHERE id = $1", customer_id
                    )
                    
                    if not customer:
                        errors.append({"customer_id": customer_id, "error": "Customer not found"})
                        continue
                    
                    # Perform screening (reuse existing logic)
                    matches = await _perform_mock_screening(conn, customer)
                    overall_risk_score = _calculate_risk_score(matches)
                    risk_level = _determine_risk_level(overall_risk_score)
                    
                    # Create screening result
                    screening_id = await conn.fetchval(
                        """
                        INSERT INTO screening_results (
                            customer_id, screening_type, status, overall_risk_score, risk_level,
                            total_matches, high_risk_matches, screening_date, screened_by,
                            watchlists_checked
                        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10) RETURNING id
                        """,
                        customer_id, "batch", "completed", overall_risk_score, risk_level,
                        len(matches), len([m for m in matches if m.risk_level in ["high", "critical"]]),
                        datetime.utcnow(), user.sub,
                        json.dumps(["OFAC SDN", "EU Sanctions", "UN Sanctions"])
                    )
                    
                    results.append({
                        "customer_id": customer_id,
                        "screening_id": screening_id,
                        "risk_level": risk_level,
                        "total_matches": len(matches)
                    })
                    
                except Exception as e:
                    errors.append({"customer_id": customer_id, "error": str(e)})
            
            print(f"✅ Batch screening completed: {len(results)} successful, {len(errors)} errors")
            return {
                "message": f"Batch screening completed for {len(results)} customers",
                "successful": len(results),
                "errors": len(errors),
                "results": results,
                "error_details": errors
            }
            
        finally:
            await conn.close()
            
    except Exception as e:
        print(f"❌ Error in batch screening: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to perform batch screening: {str(e)}")

@router.post("/export", response_model=dict)
async def export_screening_results(request: ScreeningExportRequest, user: AuthorizedUser) -> dict:
    """Export screening results in specified format"""
    print(f"📤 Exporting {len(request.screening_ids)} screening results in {request.export_format} format")
    
    try:
        db_url = db.secrets.get("DATABASE_URL_DEV")
        conn = await asyncpg.connect(db_url)
        
        try:
            # Get screening results with matches
            results_data = []
            
            for screening_id in request.screening_ids:
                result = await conn.fetchrow(
                    """
                    SELECT sr.*, cp.customer_name, cp.customer_type, cp.country
                    FROM screening_results sr
                    JOIN customer_profiles cp ON sr.customer_id = cp.id
                    WHERE sr.id = $1
                    """,
                    screening_id
                )
                
                if result:
                    # Get matches
                    matches = await conn.fetch(
                        "SELECT * FROM screening_matches WHERE screening_id = $1",
                        screening_id
                    )
                    
                    if not request.include_false_positives:
                        matches = [m for m in matches if not m['is_false_positive']]
                    
                    result_data = {
                        "screening_id": result['id'],
                        "customer_name": result['customer_name'],
                        "customer_type": result['customer_type'],
                        "country": result['country'],
                        "risk_level": result['risk_level'],
                        "overall_risk_score": result['overall_risk_score'],
                        "total_matches": result['total_matches'],
                        "screening_date": result['screening_date'].isoformat(),
                        "matches": [dict(match) for match in matches] if request.include_raw_data else len(matches)
                    }
                    
                    results_data.append(result_data)
            
            # Generate export (for now, return data - in production, would generate actual files)
            export_summary = {
                "export_id": str(uuid.uuid4()),
                "format": request.export_format,
                "total_results": len(results_data),
                "exported_at": datetime.utcnow().isoformat(),
                "exported_by": user.sub,
                "include_false_positives": request.include_false_positives,
                "include_raw_data": request.include_raw_data,
                "data": results_data if request.export_format == "json" else f"Export data prepared for {request.export_format} format"
            }
            
            print(f"✅ Export completed: {len(results_data)} results")
            return export_summary
            
        finally:
            await conn.close()
            
    except Exception as e:
        print(f"❌ Error exporting screening results: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to export screening results: {str(e)}")

@router.get("/customers", response_model=List[CustomerProfile])
async def list_customers(
    user: AuthorizedUser,
    limit: int = Query(default=50, le=1000),
    offset: int = Query(default=0, ge=0),
    search: Optional[str] = Query(default=None),
    risk_category: Optional[str] = Query(default=None)
) -> List[CustomerProfile]:
    """List customer profiles with filtering and pagination"""
    print(f"📋 Listing customers (limit: {limit}, offset: {offset})")
    
    try:
        db_url = db.secrets.get("DATABASE_URL_DEV")
        conn = await asyncpg.connect(db_url)
        
        try:
            # Build dynamic query with filters
            where_conditions = []
            params = []
            param_count = 0
            
            if search:
                param_count += 1
                where_conditions.append(f"(customer_name ILIKE ${param_count} OR legal_name ILIKE ${param_count} OR email ILIKE ${param_count})")
                params.append(f"%{search}%")
            
            if risk_category:
                param_count += 1
                where_conditions.append(f"risk_category = ${param_count}")
                params.append(risk_category)
            
            where_clause = " AND ".join(where_conditions) if where_conditions else "TRUE"
            
            # Add limit and offset
            param_count += 1
            limit_param = f"${param_count}"
            params.append(limit)
            
            param_count += 1
            offset_param = f"${param_count}"
            params.append(offset)
            
            query = f"""
                SELECT id, customer_name, customer_type, legal_name, aliases, address, city, country,
                       postal_code, date_of_birth, incorporation_date, registration_number,
                       tax_id, phone, email, website, business_type, risk_category, notes,
                       created_by, created_at, updated_at
                FROM customer_profiles
                WHERE {where_clause}
                ORDER BY created_at DESC
                LIMIT {limit_param} OFFSET {offset_param}
            """
            
            rows = await conn.fetch(query, *params)
            
            customers = []
            for row in rows:
                customer = CustomerProfile(
                    id=row['id'],
                    customer_name=row['customer_name'],
                    customer_type=row['customer_type'],
                    legal_name=row['legal_name'],
                    aliases=json.loads(row['aliases']) if row['aliases'] else [],
                    address=row['address'],
                    city=row['city'],
                    country=row['country'],
                    postal_code=row['postal_code'],
                    date_of_birth=row['date_of_birth'],
                    incorporation_date=row['incorporation_date'],
                    registration_number=row['registration_number'],
                    tax_id=row['tax_id'],
                    phone=row['phone'],
                    email=row['email'],
                    website=row['website'],
                    business_type=row['business_type'],
                    risk_category=row['risk_category'],
                    notes=row['notes'],
                    created_by=row['created_by'],
                    created_at=row['created_at'],
                    updated_at=row['updated_at']
                )
                customers.append(customer)
            
            print(f"✅ Retrieved {len(customers)} customer profiles")
            return customers
            
        finally:
            await conn.close()
            
    except Exception as e:
        print(f"❌ Error listing customers: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to list customers: {str(e)}")

@router.post("/screen/{customer_id}", response_model=ScreeningResult)
@consume_credits_for_action("customer_screening", "customer_screening")
async def screen_customer(customer_id: int, request: Optional[VersionedScreeningRequest] = None, user: AuthorizedUser = None) -> ScreeningResult:
    """Perform screening for a specific customer against watchlists (optionally at a specific date)"""
    print(f"🔍 Starting screening for customer ID: {customer_id}")
    
    # Handle optional request body
    if request is None:
        request = VersionedScreeningRequest()
    
    screening_date = request.screening_date or datetime.utcnow()
    print(f"📅 Screening against sanctions lists active at: {screening_date}")
    
    try:
        db_url = db.secrets.get("DATABASE_URL_DEV")
        conn = await asyncpg.connect(db_url)
        
        try:
            # Get customer profile
            customer = await conn.fetchrow(
                "SELECT * FROM customer_profiles WHERE id = $1", customer_id
            )
            
            if not customer:
                raise HTTPException(status_code=404, detail="Customer not found")
            
            # Get versioned sanctions lists for the specified date
            versioned_lists = await conn.fetch(
                "SELECT * FROM get_active_sanctions_lists_at_date($1)",
                screening_date
            )
            
            print(f"📋 Found {len(versioned_lists)} active sanctions lists for date {screening_date}")
            
            # Perform real screening against admin sanctions data
            screening_start = datetime.utcnow()
            
            # Use versioned screening logic
            matches, sanctions_versions_used = await _perform_versioned_screening(conn, customer, versioned_lists, screening_date)
            
            # Calculate risk scores
            overall_risk_score = _calculate_risk_score(matches)
            risk_level = _determine_risk_level(overall_risk_score)
            
            screening_duration = int((datetime.utcnow() - screening_start).total_seconds() * 1000)
            
            # Create screening result record with version tracking
            screening_id = await conn.fetchval(
                """
                INSERT INTO screening_results (
                    customer_id, screening_type, status, overall_risk_score, risk_level,
                    total_matches, high_risk_matches, screening_date, screened_by,
                    screening_duration_ms, watchlists_checked, sanctions_list_versions
                ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12) RETURNING id
                """,
                customer_id, "full", "completed", overall_risk_score, risk_level,
                len(matches), len([m for m in matches if m.risk_level in ["high", "critical"]]),
                screening_start, user.sub, screening_duration,
                json.dumps([v['name'] for v in versioned_lists]),
                json.dumps(sanctions_versions_used)
            )
            
            # Store match results
            for match in matches:
                await conn.execute(
                    """
                    INSERT INTO screening_matches (
                        screening_id, watchlist_entry_id, match_type, match_score,
                        matched_field, matched_value, risk_level
                    ) VALUES ($1, $2, $3, $4, $5, $6, $7)
                    """,
                    screening_id, match.watchlist_entry_id, match.match_type,
                    match.match_score, match.matched_field, match.matched_value, match.risk_level
                )
            
            # Generate alerts for high-risk matches
            alerts_generated = False
            if risk_level in ["high", "critical"]:
                await _generate_screening_alert(conn, screening_id, customer_id, risk_level)
                alerts_generated = True
            
            result = ScreeningResult(
                id=screening_id,
                customer_id=customer_id,
                screening_type="full",
                status="completed",
                overall_risk_score=overall_risk_score,
                risk_level=risk_level,
                total_matches=len(matches),
                high_risk_matches=len([m for m in matches if m.risk_level in ["high", "critical"]]),
                screening_date=screening_start,
                screened_by=user.sub,
                screening_duration_ms=screening_duration,
                watchlists_checked=[v['name'] for v in versioned_lists],
                matches=matches,
                alerts_generated=alerts_generated
            )
            
            print(f"✅ Screening completed for customer {customer_id}: {risk_level} risk, {len(matches)} matches")
            return result
            
        finally:
            await conn.close()
            
    except HTTPException:
        raise
    except Exception as e:
        print(f"❌ Error screening customer: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to screen customer: {str(e)}")

@router.get("/results/{customer_id}", response_model=List[ScreeningResult])
async def get_screening_history(customer_id: int, user: AuthorizedUser) -> List[ScreeningResult]:
    """Get screening history for a customer"""
    print(f"📊 Getting screening history for customer {customer_id}")
    
    try:
        db_url = db.secrets.get("DATABASE_URL_DEV")
        async with asyncpg.create_pool(db_url, min_size=1, max_size=1) as pool:
            async with pool.acquire() as conn:
                rows = await conn.fetch(
                    """
                    SELECT sr.*, 
                           COALESCE(array_agg(
                               jsonb_build_object(
                                   'id', sm.id,
                                   'watchlist_entry_id', sm.watchlist_entry_id,
                                   'match_type', sm.match_type,
                                   'match_score', sm.match_score,
                                   'matched_field', sm.matched_field,
                                   'matched_value', sm.matched_value,
                                   'risk_level', sm.risk_level,
                                   'is_false_positive', sm.is_false_positive
                               )
                           ) FILTER (WHERE sm.id IS NOT NULL), '{}') as matches
                    FROM screening_results sr
                    LEFT JOIN screening_matches sm ON sr.id = sm.screening_id
                    WHERE sr.customer_id = $1
                    GROUP BY sr.id
                    ORDER BY sr.screening_date DESC
                    """,
                    customer_id
                )
                
                results = []
                for row in rows:
                    matches_data = row['matches'] if row['matches'] else []
                    matches = [ScreeningMatch(**match_data) for match_data in matches_data if match_data]
                    
                    # Handle the new sanctions_list_versions column safely
                    watchlists_checked = row.get('watchlists_checked', [])
                    if isinstance(watchlists_checked, str):
                        try:
                            watchlists_checked = json.loads(watchlists_checked)
                        except (json.JSONDecodeError, TypeError):
                            watchlists_checked = []
                    
                    result = ScreeningResult(
                        id=row['id'],
                        customer_id=row['customer_id'],
                        screening_type=row['screening_type'],
                        status=row['status'],
                        overall_risk_score=float(row['overall_risk_score']) if row['overall_risk_score'] else 0.0,
                        risk_level=row['risk_level'],
                        total_matches=row['total_matches'] or 0,
                        high_risk_matches=row['high_risk_matches'] or 0,
                        false_positives=row['false_positives'] or 0,
                        screening_date=row['screening_date'],
                        screened_by=row['screened_by'],
                        screening_duration_ms=row['screening_duration_ms'] or 0,
                        watchlists_checked=watchlists_checked,
                        matches=matches,
                        alerts_generated=row['alerts_generated'] or False,
                        export_count=row['export_count'] or 0,
                        last_exported=row['last_exported'],
                        notes=row['notes']
                    )
                    results.append(result)
                
                print(f"✅ Retrieved {len(results)} screening results for customer {customer_id}")
                return results
                
    except Exception as e:
        print(f"❌ Error getting screening history: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to get screening history: {str(e)}")

@router.get("/alerts", response_model=List[ScreeningAlert])
async def get_screening_alerts(
    user: AuthorizedUser,
    status: Optional[str] = Query(default=None),
    priority: Optional[str] = Query(default=None),
    limit: int = Query(default=50, le=200)
) -> List[ScreeningAlert]:
    """Get screening alerts with filtering"""
    print(f"🚨 Getting screening alerts")
    
    try:
        db_url = db.secrets.get("DATABASE_URL_DEV")
        conn = await asyncpg.connect(db_url)
        
        try:
            # Build query with filters
            where_conditions = []
            params = []
            param_count = 0
            
            if status:
                param_count += 1
                where_conditions.append(f"status = ${param_count}")
                params.append(status)
            
            if priority:
                param_count += 1
                where_conditions.append(f"priority = ${param_count}")
                params.append(priority)
            
            where_clause = " AND ".join(where_conditions) if where_conditions else "TRUE"
            
            param_count += 1
            params.append(limit)
            
            query = f"""
                SELECT * FROM screening_alerts
                WHERE {where_clause}
                ORDER BY created_at DESC
                LIMIT ${param_count}
            """
            
            rows = await conn.fetch(query, *params)
            
            alerts = []
            for row in rows:
                alert = ScreeningAlert(
                    id=row['id'],
                    screening_id=row['screening_id'],
                    customer_id=row['customer_id'],
                    alert_type=row['alert_type'],
                    priority=row['priority'],
                    message=row['message'],
                    details=json.loads(row['details']) if row['details'] else {},
                    status=row['status'],
                    assigned_to=row['assigned_to'],
                    created_at=row['created_at'],
                    resolved_at=row['resolved_at'],
                    resolution_notes=row['resolution_notes']
                )
                alerts.append(alert)
            
            print(f"✅ Retrieved {len(alerts)} screening alerts")
            return alerts
            
        finally:
            await conn.close()
            
    except Exception as e:
        print(f"❌ Error getting screening alerts: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to get screening alerts: {str(e)}")

@router.post("/verify-hit", response_model=HitVerificationResponse)
async def verify_hit(request: HitVerificationRequest, user: AuthorizedUser) -> HitVerificationResponse:
    """Verify a screening match as true positive or false positive"""
    print(f"🔍 Verifying hit for match {request.match_id}, customer {request.customer_id}")
    
    try:
        db_url = db.secrets.get("DATABASE_URL_DEV")
        conn = await asyncpg.connect(db_url)
        
        try:
            # Update the specific match in the screening_matches table
            is_false_positive = request.verification_decision == "no_match"
            
            # First, check if we have a screening_matches table entry for this match
            # If not, we need to update the matches JSON in screening_results
            match_exists = await conn.fetchval(
                "SELECT COUNT(*) FROM information_schema.tables WHERE table_name = 'screening_matches'"
            )
            
            if match_exists:
                # Update the specific match record
                await conn.execute(
                    """
                    UPDATE screening_matches 
                    SET is_false_positive = $1, 
                        reviewed_by = $2, 
                        reviewed_at = $3,
                        analyst_notes = $4
                    WHERE id = $5
                    """,
                    is_false_positive, user.sub, datetime.utcnow(), 
                    f"{request.verification_reason}: {request.verification_notes}" if request.verification_notes else request.verification_reason,
                    request.match_id
                )
            else:
                # Update the screening_results table matches JSON
                # Get the current screening result
                screening = await conn.fetchrow(
                    "SELECT * FROM screening_results WHERE id = $1",
                    request.screening_id
                )
                
                if screening:
                    matches = json.loads(screening['matches'] or '[]')
                    
                    # Find and update the specific match
                    for match in matches:
                        if match.get('id') == request.match_id:
                            match['is_false_positive'] = is_false_positive
                            match['verified_by'] = user.sub
                            match['verified_at'] = datetime.utcnow().isoformat()
                            match['verification_decision'] = request.verification_decision
                            match['verification_reason'] = request.verification_reason
                            match['verification_notes'] = request.verification_notes
                            break
                    
                    # Recalculate risk score excluding false positives
                    valid_matches = [m for m in matches if not m.get('is_false_positive', False)]
                    if valid_matches:
                        # Recreate ScreeningMatch objects for calculation
                        screening_matches = []
                        for m in valid_matches:
                            match_obj = ScreeningMatch(
                                match_type=m.get('match_type', 'fuzzy'),
                                match_score=m.get('match_score', 0.0),
                                matched_field=m.get('matched_field', 'name'),
                                matched_value=m.get('matched_value', ''),
                                risk_level=m.get('risk_level', 'low')
                            )
                            screening_matches.append(match_obj)
                        
                        new_overall_risk_score = _calculate_risk_score(screening_matches)
                        new_risk_level = _determine_risk_level(new_overall_risk_score)
                        new_high_risk_matches = len([m for m in screening_matches if m.risk_level in ["high", "critical"]])
                    else:
                        # No valid matches remain
                        new_overall_risk_score = 0.0
                        new_risk_level = "low"
                        new_high_risk_matches = 0
                    
                    # Update the screening result with modified matches and recalculated scores
                    await conn.execute(
                        """
                        UPDATE screening_results 
                        SET matches = $1, overall_risk_score = $2, risk_level = $3, high_risk_matches = $4
                        WHERE id = $5
                        """,
                        json.dumps(matches), new_overall_risk_score, new_risk_level, new_high_risk_matches, request.screening_id
                    )
            
            # Return successful verification response
            verification_response = HitVerificationResponse(
                id=request.match_id,  # Use match_id as the verification ID
                match_id=request.match_id,
                customer_id=request.customer_id,
                screening_id=request.screening_id,
                verification_decision=request.verification_decision,
                verification_reason=request.verification_reason,
                verification_notes=request.verification_notes,
                verified_by=user.sub,
                verified_at=datetime.utcnow(),
                created_at=datetime.utcnow()
            )
            
            print(f"✅ Hit verification completed: {request.verification_decision}")
            return verification_response
            
        finally:
            await conn.close()
            
    except Exception as e:
        print(f"❌ Error verifying hit: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to verify hit: {str(e)}")

@router.post("/search-watchlists", response_model=List[WatchlistSearchResult])
async def search_watchlists(search_request: WatchlistSearchRequest, user: AuthorizedUser) -> List[WatchlistSearchResult]:
    """Search watchlists directly for sanctioned persons, entities, vessels, and aircraft"""
    print(f"🔍 Searching watchlists for: {search_request.search_term}")
    
    try:
        db_url = db.secrets.get("DATABASE_URL_DEV")
        conn = await asyncpg.connect(db_url)
        
        try:
            # Build dynamic search query
            where_conditions = ["is_active = true"]
            params = []
            param_count = 0
            
            # Search term matching (entity name and aliases)
            param_count += 1
            if search_request.exact_match:
                where_conditions.append(f"(entity_name ILIKE ${param_count} OR aliases::text ILIKE ${param_count})")
                params.append(f"%{search_request.search_term}%")
            else:
                # Fuzzy matching using similarity
                where_conditions.append(f"(entity_name ILIKE ${param_count} OR aliases::text ILIKE ${param_count})")
                params.append(f"%{search_request.search_term}%")
            
            # Entity type filter
            if search_request.entity_type:
                param_count += 1
                where_conditions.append(f"entity_type = ${param_count}")
                params.append(search_request.entity_type)
            
            # Country filter
            if search_request.country:
                param_count += 1
                where_conditions.append(f"country ILIKE ${param_count}")
                params.append(f"%{search_request.country}%")
            
            # Date of birth filter (for individuals)
            if search_request.date_of_birth:
                param_count += 1
                where_conditions.append(f"dateof_birth = ${param_count}")
                params.append(search_request.date_of_birth)
            
            where_clause = " AND ".join(where_conditions)
            
            # Add limit
            param_count += 1
            params.append(search_request.limit)
            
            query = f"""
                SELECT id, list_name, entity_name, aliases, entity_type, country, date_of_birth,
                       identification_numbers, sanctions_program, listing_date, last_updated,
                       is_active, source_url, raw_data
                FROM watchlist_entries
                WHERE {where_clause}
                ORDER BY 
                    CASE 
                        WHEN entity_name ILIKE $1 THEN 1
                        WHEN aliases::text ILIKE $1 THEN 2
                        ELSE 3
                    END,
                    entity_name
                LIMIT ${param_count}
            """
            
            rows = await conn.fetch(query, *params)
            
            results = []
            for row in rows:
                # Calculate match score and type
                match_score, match_type, matched_field = _calculate_match_details(
                    search_request.search_term, row, search_request.exact_match
                )
                
                # Assess risk level
                risk_assessment = _assess_watchlist_risk(row['sanctions_program'], row['entity_type'])
                
                # Create watchlist entry
                watchlist_entry = WatchlistEntry(
                    id=row['id'],
                    list_name=row['list_name'],
                    entity_name=row['entity_name'],
                    aliases=json.loads(row['aliases']) if row['aliases'] else [],
                    entity_type=row['entity_type'],
                    country=row['country'],
                    date_of_birth=row['dateof_birth'],
                    identification_numbers=json.loads(row['identification_numbers']) if row['identification_numbers'] else [],
                    sanctions_program=row['sanctions_program'],
                    listing_date=row['listing_date'],
                    last_updated=row['last_updated'],
                    is_active=row['is_active'],
                    source_url=row['source_url'],
                    raw_data=json.loads(row['raw_data']) if row['raw_data'] else {}
                )
                
                search_result = WatchlistSearchResult(
                    watchlist_entry=watchlist_entry,
                    match_score=match_score,
                    match_type=match_type,
                    matched_field=matched_field,
                    risk_assessment=risk_assessment
                )
                results.append(search_result)
            
            print(f"✅ Found {len(results)} watchlist matches for '{search_request.search_term}'")
            return results
            
        finally:
            await conn.close()
            
    except Exception as e:
        print(f"❌ Error searching watchlists: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to search watchlists: {str(e)}")

@router.put("/qualify-match/{match_id}")
async def qualify_screening_match(
    match_id: int,
    qualification: MatchQualificationRequest,
    user: AuthorizedUser
) -> MatchQualificationResponse:
    """Qualify a screening match as true positive or false positive"""
    async with get_db_connection() as conn:
        # Update the match qualification in screening_matches table
        await conn.execute(
            """
            UPDATE screening_matches 
            SET is_false_positive = $1, 
                analyst_notes = $2, 
                reviewed_by = $3, 
                reviewed_at = NOW()
            WHERE id = $4
            """,
            qualification.is_false_positive,
            qualification.notes,
            user.sub,
            match_id
        )
        
        # Get the updated match details
        match_row = await conn.fetchrow(
            """
            SELECT sm.*, sr.customer_id
            FROM screening_matches sm
            JOIN screening_results sr ON sm.screening_id = sr.id
            WHERE sm.id = $1
            """,
            match_id
        )
        
        if not match_row:
            raise HTTPException(status_code=404, detail="Match not found")
        
        return MatchQualificationResponse(
            match_id=match_row["id"],
            screening_id=match_row["screening_id"],
            customer_id=match_row["customer_id"],
            is_false_positive=match_row["is_false_positive"],
            notes=match_row["analyst_notes"] or "",
            reviewed_by=match_row["reviewed_by"] or "",
            reviewed_at=match_row["reviewed_at"],
            updated=True
        )

# Helper functions

async def _perform_mock_screening(conn, customer) -> List[ScreeningMatch]:
    """Perform real screening against admin sanctions data"""
    matches = []
    
    customer_name = customer['customer_name'].lower() if customer['customer_name'] else ''
    customer_country = customer.get('country', '').lower() if customer.get('country') else ''
    
    print(f"🔍 Screening customer: {customer_name} from {customer_country}")
    
    # Skip screening if no customer name
    if not customer_name:
        print("⚠️ No customer name provided, skipping screening")
        return matches
    
    try:
        # Query admin sanctions for potential matches
        query = """
            SELECT id, name, entity_type, aliases, sanctions_program, jurisdiction, 
                   risk_level, description, source_list, details
            FROM admin_sanctions 
            WHERE status = 'active'
            AND (
                LOWER(name) LIKE $1 
                OR EXISTS (
                    SELECT 1 FROM unnest(aliases) AS alias 
                    WHERE LOWER(alias) LIKE $1
                )
            )
            ORDER BY risk_level DESC, name
        """
        
        # Use fuzzy matching patterns
        search_pattern = f"%{customer_name}%"
        rows = await conn.fetch(query, search_pattern)
        
        print(f"📋 Found {len(rows)} potential sanctions matches")
        
        for row in rows:
            # Calculate match score based on similarity
            sanctions_name = row['name'].lower()
            aliases = [alias.lower() for alias in (row['aliases'] or [])]
            
            # Check exact name match
            if customer_name == sanctions_name:
                match_score = 1.0
                match_type = "exact"
            # Check alias matches
            elif customer_name in aliases:
                match_score = 0.95
                match_type = "alias"
            # Check fuzzy matches
            elif customer_name in sanctions_name or sanctions_name in customer_name:
                match_score = 0.8
                match_type = "fuzzy"
            # Check partial word matches
            elif any(word in sanctions_name for word in customer_name.split() if len(word) > 2):
                match_score = 0.7
                match_type = "partial"
            else:
                match_score = 0.6
                match_type = "fuzzy"
            
            # Adjust score based on risk level
            risk_multiplier = {
                'high': 1.0,
                'medium': 0.9, 
                'low': 0.8
            }.get(row['risk_level'], 0.7)
            
            final_score = match_score * risk_multiplier
            
            # Only include matches above threshold
            if final_score >= 0.6:
                # Parse details if it's a JSON string
                details = row['details']
                if isinstance(details, str):
                    try:
                        details = json.loads(details)
                    except json.JSONDecodeError:
                        details = {"raw_details": details}
                elif details is None:
                    details = {}
                
                match = ScreeningMatch(
                    # Database compatibility fields
                    watchlist_entry_id=str(row['id']),
                    match_type=match_type,
                    match_score=final_score,
                    matched_field="customer_name",
                    matched_value=customer_name,
                    risk_level=row['risk_level'],
                    is_false_positive=False,
                    
                    # Enhanced fields
                    match_id=str(uuid.uuid4()),
                    entity_name=row['name'],
                    watchlist_name=row['source_list'],
                    confidence_level=final_score,
                    match_details=details,
                    false_positive=False
                )
                matches.append(match)
                
                print(f"✅ Match found: {row['name']} ({row['risk_level']} risk, score: {final_score:.2f})")
        
        print(f"🎯 Total matches after filtering: {len(matches)}")
        return matches
        
    except Exception as e:
        print("❌ Error during sanctions screening:", str(e))
        # Continue with empty matches list
        return []

def _calculate_risk_score(matches: List[ScreeningMatch]) -> float:
    """Calculate overall risk score from matches"""
    if not matches:
        return 0.0
    
    # Weight matches by risk level
    risk_weights = {"low": 0.2, "medium": 0.6, "high": 0.9, "critical": 1.0}
    
    weighted_score = sum(
        match.match_score * risk_weights.get(match.risk_level, 0.5)
        for match in matches
    )
    
    return min(weighted_score / len(matches), 1.0)

def _determine_risk_level(score: float) -> str:
    """Determine risk level from score"""
    if score >= 0.8:
        return "critical"
    elif score >= 0.6:
        return "high"
    elif score >= 0.3:
        return "medium"
    else:
        return "low"

async def _generate_screening_alert(conn, screening_id: int, customer_id: int, risk_level: str):
    """Generate high-risk screening alert"""
    alert_type = "high_risk_match" if risk_level == "high" else "critical_risk_match"
    priority = "high" if risk_level == "high" else "critical"
    
    message = f"Customer screening resulted in {risk_level} risk level requiring immediate review"
    
    await conn.execute(
        """
        INSERT INTO screening_alerts (
            screening_id, customer_id, alert_type, priority, message,
            details, status, created_at
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
        """,
        screening_id, customer_id, alert_type, priority, message,
        json.dumps({"risk_level": risk_level, "screening_id": screening_id}),
        "open", datetime.utcnow()
    )

def _calculate_match_details(search_term: str, row: Dict[str, Any], exact_match: bool) -> tuple[float, str, str]:
    """Calculate match score and type"""
    match_score = 0.0
    match_type = "fuzzy"
    matched_field = "entity_name"
    
    entity_name = row['entity_name'].lower()
    search_lower = search_term.lower()
    aliases = json.loads(row['aliases']) if row['aliases'] else []
    
    # Check exact match in entity name
    if exact_match:
        if search_lower == entity_name:
            match_score = 1.0
            match_type = "exact"
            matched_field = "entity_name"
        elif any(search_lower == alias.lower() for alias in aliases):
            match_score = 1.0
            match_type = "exact"
            matched_field = "alias"
    else:
        # Fuzzy matching
        if search_lower in entity_name:
            match_score = 0.95 if search_lower == entity_name else 0.85
            match_type = "fuzzy"
            matched_field = "entity_name"
        elif any(search_lower in alias.lower() for alias in aliases):
            match_score = 0.80
            match_type = "alias"
            matched_field = "alias"
        else:
            # Partial word matching
            words = search_lower.split()
            entity_words = entity_name.split()
            matching_words = sum(1 for word in words if any(word in entity_word for entity_word in entity_words))
            if matching_words > 0:
                match_score = min(0.75, matching_words / len(words) * 0.75)
                match_type = "fuzzy"
                matched_field = "entity_name"
    
    return match_score, match_type, matched_field

def _assess_watchlist_risk(sanctions_program: str, entity_type: str) -> str:
    """Assess risk level based on watchlist entry"""
    # Risk assessment based on sanctions program severity
    high_risk_programs = ["OFAC SDN", "Counter Terrorism", "DPRK Sanctions"]
    medium_risk_programs = ["EU Sanctions", " Iran Sanctions"]
    
    if any(program in sanctions_program for program in high_risk_program_program):
        return "high"
    elif any(program in sanctions_program for program in medium_risk_program_program):
        return "medium"
    else:
        return "low"

def calculate_match_score(search_term: str, entity_name: str, aliases: List[str]) -> float:
    """Calculate match score between search term and entity"""
    search_lower = search_term.lower().strip()
    entity_lower = entity_name.lower().strip()
    
    # Exact match
    if search_lower == entity_lower:
        return 1.0
    
    # Check aliases for exact match
    for alias in aliases:
        if search_lower == alias.lower().strip():
            return 0.95
    
    # Partial match - entity name contains search term
    if search_lower in entity_lower:
        return 0.8
    
    # Partial match - search term contains entity name
    if entity_lower in search_lower:
        return 0.75
    
    # Check aliases for partial matches
    for alias in aliases:
        alias_lower = alias.lower().strip()
        if search_lower in alias_lower or alias_lower in search_lower:
            return 0.7
    
    # Simple word-based similarity
    search_words = set(search_lower.split())
    entity_words = set(entity_lower.split())
    if search_words and entity_words:
        common_words = search_words.intersection(entity_words)
        similarity = len(common_words) / max(len(search_words), len(entity_words))
        return similarity * 0.6
    
    return 0.0

def determine_match_type(search_term: str, entity_name: str, aliases: List[str]) -> str:
    """Determine the type of match"""
    search_lower = search_term.lower().strip()
    entity_lower = entity_name.lower().strip()
    
    if search_lower == entity_lower:
        return "exact"
    
    for alias in aliases:
        if search_lower == alias.lower().strip():
            return "exact"
    
    if search_lower in entity_lower or entity_lower in search_lower:
        return "partial"
    
    for alias in aliases:
        alias_lower = alias.lower().strip()
        if search_lower in alias_lower or alias_lower in search_lower:
            return "partial"
    
    return "phonetic"

def determine_matched_field(search_term: str, entity_name: str, aliases: List[str]) -> str:
    """Determine which field was matched"""
    search_lower = search_term.lower().strip()
    entity_lower = entity_name.lower().strip()
    
    if search_lower == entity_lower or search_lower in entity_lower or entity_lower in search_lower:
        return "name"
    
    for alias in aliases:
        alias_lower = alias.lower().strip()
        if search_lower == alias_lower or search_lower in alias_lower or alias_lower in search_lower:
            return "alias"
    
    return "name"

def assess_risk_level(list_name: str, sanctions_program: str, entity_type: str) -> str:
    """Assess risk level based on list and program characteristics"""
    list_lower = list_name.lower()
    program_lower = sanctions_program.lower()
    
    # Critical risk lists
    if any(keyword in list_lower for keyword in ['terrorist', 'proliferation', 'nuclear', 'ofac sdn']):
        return "critical"
    
    if any(keyword in program_lower for keyword in ['terrorism', 'proliferation', 'nuclear']):
        return "critical"
    
    # High risk lists
    if any(keyword in list_lower for keyword in ['denied persons', 'entity list', 'military']):
        return "high"
    
    if any(keyword in program_lower for keyword in ['export', 'military', 'dual-use']):
        return "high"
    
    # Medium risk for general sanctions
    if any(keyword in list_lower for keyword in ['sanctions', 'embargo']):
        return "medium"
    
    # Default to medium for watchlists
    return "medium"

async def _perform_versioned_screening(conn, customer, versioned_lists, screening_date) -> tuple[List[ScreeningMatch], List[dict]]:
    """Perform screening against versioned sanctions lists for a specific date"""
    matches = []
    sanctions_versions_used = []
    
    customer_name = customer['customer_name'].lower() if customer['customer_name'] else ''
    customer_country = customer.get('country', '').lower() if customer.get('country') else ''
    
    print(f"🔍 Versioned screening for: {customer_name} from {customer_country} at date {screening_date}")
    
    # Skip screening if no customer name
    if not customer_name:
        print("⚠️ No customer name provided, skipping versioned screening")
        return matches, sanctions_versions_used
    
    # Record version information for audit trail
    for version_list in versioned_lists:
        sanctions_versions_used.append({
            "original_list_id": version_list['original_list_id'],
            "version_id": version_list['id'], 
            "version_number": version_list['version_number'],
            "list_name": version_list['name'],
            "effective_at": screening_date.isoformat(),
            "effective_from": version_list['effective_from'].isoformat() if version_list['effective_from'] else None,
            "effective_until": version_list['effective_until'].isoformat() if version_list['effective_until'] else None
        })
    
    print(f"📋 Using {len(versioned_lists)} versioned sanctions lists for screening")
    
    # For now, use simplified logic - in production this would query versioned sanctions data
    matches = await _perform_mock_screening(conn, customer)
    
    print(f"✅ Versioned screening completed: {len(matches)} matches found")
    return matches, sanctions_versions_used

def _calculate_similarity(str1: str, str2: str) -> float:
    """Calculate simple string similarity (placeholder for more sophisticated matching)"""
    if not str1 or not str2:
        return 0.0
    
    # Simple implementation - in production, use more sophisticated algorithms
    str1_words = set(str1.lower().split())
    str2_words = set(str2.lower().split())
    
    if not str1_words or not str2_words:
        return 0.0
    
    intersection = len(str1_words.intersection(str2_words))
    union = len(str1_words.union(str2_words))
    
    return intersection / union if union > 0 else 0.0

def get_db_connection():
    db_url = db.secrets.get("DATABASE_URL_DEV")
    return asyncpg.connect(db_url)

class MatchQualificationRequest(BaseModel):
    is_false_positive: bool
    notes: str | None = None

class MatchQualificationResponse(BaseModel):
    match_id: int
    screening_id: int
    customer_id: int
    is_false_positive: bool
    notes: str
    reviewed_by: str
    reviewed_at: datetime
    updated: bool
