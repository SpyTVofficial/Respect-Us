

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import List, Optional, Dict, Any
import asyncpg
import databutton as db
from app.auth import AuthorizedUser
from app.env import Mode, mode
import json
from datetime import datetime, timezone, timedelta
import uuid

router = APIRouter(prefix="/classification-save")

# Database connection helper
async def get_db_connection():
    database_url = db.secrets.get("DATABASE_URL_DEV")
    return await asyncpg.connect(database_url)

class SavedClassificationRequest(BaseModel):
    name: str
    description: Optional[str] = None
    workflow_data: Dict[str, Any]
    item_name: str
    item_description: Optional[str] = None
    current_step: str
    progress_percentage: float
    auto_save: bool = True

class SavedClassificationResponse(BaseModel):
    id: str
    name: str
    description: Optional[str]
    item_name: str
    item_description: Optional[str]
    current_step: str
    progress_percentage: float
    created_at: datetime
    updated_at: datetime
    expires_at: datetime
    days_until_expiry: int
    auto_save: bool
    status: str  # 'active', 'expiring_soon', 'archived'

class ClassificationNotification(BaseModel):
    id: str
    classification_id: str
    classification_name: str
    notification_type: str  # 'expiry_warning', 'archived'
    message: str
    created_at: datetime
    acknowledged: bool = False

@router.post("/save-classification", response_model=SavedClassificationResponse)
async def save_classification(request: SavedClassificationRequest, user: AuthorizedUser):
    """Save or update a classification progress"""
    conn = await get_db_connection()
    try:
        # Calculate expiry date (7 days from now) with timezone
        now = datetime.now(timezone.utc)
        expires_at = now + timedelta(days=7)
        
        # Check if this is an update (based on workflow data similarity)
        existing_query = """
            SELECT id FROM saved_classifications 
            WHERE user_id = $1 AND item_name = $2 AND auto_save = $3 AND archived = FALSE
            ORDER BY updated_at DESC LIMIT 1
        """
        existing_id = await conn.fetchval(existing_query, user.sub, request.item_name, request.auto_save)
        
        if existing_id and request.auto_save:
            # Update existing auto-save
            await conn.execute(
                """
                UPDATE saved_classifications 
                SET workflow_data = $1, current_step = $2, progress_percentage = $3,
                    updated_at = $4, expires_at = $5, description = $6, item_description = $7
                WHERE id = $8
                """,
                json.dumps(request.workflow_data), request.current_step, request.progress_percentage,
                now, expires_at, request.description, request.item_description, existing_id
            )
            classification_id = existing_id
        else:
            # Create new classification save
            classification_id = await conn.fetchval(
                """
                INSERT INTO saved_classifications (
                    user_id, name, description, workflow_data, item_name, item_description,
                    current_step, progress_percentage, auto_save, created_at, updated_at, expires_at
                ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
                RETURNING id
                """,
                user.sub, request.name, request.description, json.dumps(request.workflow_data),
                request.item_name, request.item_description, request.current_step,
                request.progress_percentage, request.auto_save, now, now, expires_at
            )
        
        # Fetch the saved classification
        saved = await conn.fetchrow(
            "SELECT * FROM saved_classifications WHERE id = $1", classification_id
        )
        
        # Calculate days until expiry with proper timezone handling
        days_until_expiry = max(0, (saved['expires_at'] - now).days)
        status = 'expiring_soon' if days_until_expiry <= 1 else 'active'
        
        return SavedClassificationResponse(
            id=str(saved['id']),
            name=saved['name'],
            description=saved['description'],
            item_name=saved['item_name'],
            item_description=saved['item_description'],
            current_step=saved['current_step'],
            progress_percentage=saved['progress_percentage'],
            created_at=saved['created_at'],
            updated_at=saved['updated_at'],
            expires_at=saved['expires_at'],
            days_until_expiry=days_until_expiry,
            auto_save=saved['auto_save'],
            status=status
        )
        
    finally:
        await conn.close()

@router.get("/list-classifications", response_model=List[SavedClassificationResponse])
async def list_saved_classifications(user: AuthorizedUser, include_archived: bool = False):
    """List user's saved classifications"""
    conn = await get_db_connection()
    try:
        query = """
            SELECT * FROM saved_classifications 
            WHERE user_id = $1 AND (archived = FALSE OR $2 = TRUE)
            ORDER BY updated_at DESC
        """
        classifications = await conn.fetch(query, user.sub, include_archived)
        
        now = datetime.now(timezone.utc)
        result = []
        for c in classifications:
            days_until_expiry = max(0, (c['expires_at'] - now).days) if not c['archived'] else 0
            
            if c['archived']:
                status = 'archived'
            elif days_until_expiry <= 1:
                status = 'expiring_soon'
            else:
                status = 'active'
            
            result.append(SavedClassificationResponse(
                id=str(c['id']),
                name=c['name'],
                description=c['description'],
                item_name=c['item_name'],
                item_description=c['item_description'],
                current_step=c['current_step'],
                progress_percentage=c['progress_percentage'],
                created_at=c['created_at'],
                updated_at=c['updated_at'],
                expires_at=c['expires_at'],
                days_until_expiry=days_until_expiry,
                auto_save=c['auto_save'],
                status=status
            ))
        
        return result
        
    finally:
        await conn.close()

@router.get("/load-classification/{classification_id}")
async def load_classification(classification_id: str, user: AuthorizedUser):
    """Load a specific classification"""
    conn = await get_db_connection()
    try:
        classification = await conn.fetchrow(
            "SELECT * FROM saved_classifications WHERE id = $1 AND user_id = $2",
            classification_id, user.sub
        )
        
        if not classification:
            raise HTTPException(status_code=404, detail="Classification not found")
        
        # Update last accessed timestamp
        now = datetime.now(timezone.utc)
        await conn.execute(
            "UPDATE saved_classifications SET last_accessed = $1 WHERE id = $2",
            now, classification_id
        )
        
        return {
            "id": str(classification['id']),
            "name": classification['name'],
            "description": classification['description'],
            "workflow_data": json.loads(classification['workflow_data']),
            "item_name": classification['item_name'],
            "item_description": classification['item_description'],
            "current_step": classification['current_step'],
            "progress_percentage": classification['progress_percentage'],
            "auto_save": classification['auto_save'],
            "created_at": classification['created_at'].isoformat(),
            "updated_at": classification['updated_at'].isoformat(),
            "expires_at": classification['expires_at'].isoformat()
        }
        
    finally:
        await conn.close()

@router.delete("/delete-classification/{classification_id}")
async def delete_classification(classification_id: str, user: AuthorizedUser):
    """Delete a classification (move to archived)"""
    conn = await get_db_connection()
    try:
        now = datetime.now(timezone.utc)
        # Move to archived instead of hard delete
        result = await conn.execute(
            """
            UPDATE saved_classifications 
            SET archived = TRUE, archived_at = $1 
            WHERE id = $2 AND user_id = $3
            """,
            now, classification_id, user.sub
        )
        
        if result == "UPDATE 0":
            raise HTTPException(status_code=404, detail="Classification not found")
        
        return {"message": "Classification archived successfully"}
        
    finally:
        await conn.close()

@router.post("/restore-classification/{classification_id}")
async def restore_classification(classification_id: str, user: AuthorizedUser):
    """Restore an archived classification"""
    conn = await get_db_connection()
    try:
        now = datetime.now(timezone.utc)
        # Restore from archived and extend expiry
        new_expiry = now + timedelta(days=7)
        
        result = await conn.execute(
            """
            UPDATE saved_classifications 
            SET archived = FALSE, archived_at = NULL, expires_at = $1, updated_at = $2
            WHERE id = $3 AND user_id = $4 AND archived = TRUE
            """,
            new_expiry, now, classification_id, user.sub
        )
        
        if result == "UPDATE 0":
            raise HTTPException(status_code=404, detail="Archived classification not found")
        
        return {"message": "Classification restored successfully", "new_expiry": new_expiry.isoformat()}
        
    finally:
        await conn.close()

@router.get("/notifications", response_model=List[ClassificationNotification])
async def get_classification_notifications(user: AuthorizedUser):
    """Get pending notifications for classifications"""
    conn = await get_db_connection()
    try:
        now = datetime.now(timezone.utc)
        # Get classifications expiring soon
        expiring_soon = await conn.fetch(
            """
            SELECT id, name, expires_at FROM saved_classifications 
            WHERE user_id = $1 AND archived = FALSE 
            AND expires_at <= $2 AND expires_at > $3
            """,
            user.sub, now + timedelta(days=1), now
        )
        
        notifications = []
        for c in expiring_soon:
            hours_until_expiry = (c['expires_at'] - now).total_seconds() / 3600
            
            notifications.append(ClassificationNotification(
                id=f"expiry_{c['id']}",
                classification_id=str(c['id']),
                classification_name=c['name'],
                notification_type="expiry_warning",
                message=f"Your classification '{c['name']}' will be archived in {int(hours_until_expiry)} hours. Save it manually to extend the retention period.",
                created_at=now
            ))
        
        return notifications
        
    finally:
        await conn.close()

@router.post("/cleanup-expired")
async def cleanup_expired_classifications():
    """Background task to archive expired classifications"""
    conn = await get_db_connection()
    try:
        now = datetime.now(timezone.utc)
        # Archive expired classifications
        result = await conn.execute(
            """
            UPDATE saved_classifications 
            SET archived = TRUE, archived_at = $1 
            WHERE expires_at < $2 AND archived = FALSE
            """,
            now, now
        )
        
        # Extract count from result (format: "UPDATE n")
        archived_count = int(result.split()[-1]) if result.startswith("UPDATE") else 0
        
        return {"message": f"Archived {archived_count} expired classifications"}
        
    finally:
        await conn.close()
