

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import List, Optional, Dict, Any
from app.auth import AuthorizedUser
import asyncpg
import databutton as db
from datetime import datetime, date, timedelta
import json
from decimal import Decimal

router = APIRouter(prefix="/billing-management")

# Database connection
async def get_db_connection():
    return await asyncpg.connect(db.secrets.get("DATABASE_URL_DEV"))

# Pydantic Models
class InvoiceLineItem(BaseModel):
    description: str
    quantity: int
    unit_price: float
    total_price: float
    module_name: Optional[str] = None
    template_id: Optional[int] = None

class CreateInvoiceRequest(BaseModel):
    company_id: int
    line_items: List[InvoiceLineItem]
    billing_address: Dict[str, Any]
    notes: Optional[str] = None
    due_days: int = 30

class InvoiceResponse(BaseModel):
    id: int
    company_id: Optional[int]
    user_id: str
    invoice_number: str
    invoice_date: str
    due_date: Optional[str]
    amount_net: float
    amount_vat: float
    amount_total: float
    currency: str
    status: str
    payment_method: Optional[str]
    payment_date: Optional[str]
    line_items: List[Dict[str, Any]]
    billing_address: Optional[Dict[str, Any]]
    notes: Optional[str]
    pdf_url: Optional[str]
    created_at: str
    updated_at: str
    # Company details if available
    company_name: Optional[str] = None

class BillingHistoryResponse(BaseModel):
    invoices: List[InvoiceResponse]
    total_count: int
    total_amount_paid: float
    total_amount_pending: float
    currency: str

class PaymentMethodResponse(BaseModel):
    id: str
    type: str
    last_four: Optional[str]
    brand: Optional[str]
    exp_month: Optional[int]
    exp_year: Optional[int]
    is_default: bool
    created_at: str

class UsageAnalyticsResponse(BaseModel):
    company_id: Optional[int]
    period_start: str
    period_end: str
    total_users: int
    active_users: int
    module_usage: Dict[str, int]
    total_credits_used: int
    total_amount_spent: float
    average_monthly_spend: float

class BillingSettingsResponse(BaseModel):
    company_id: Optional[int]
    billing_email: Optional[str]
    auto_pay_enabled: bool
    invoice_delivery_method: str
    currency_preference: str
    billing_cycle: str

# Helper Functions
async def check_billing_permission(user_id: str, company_id: Optional[int], conn) -> bool:
    """Check if user has billing permissions"""
    if not company_id:
        # Individual user - always has billing permission for themselves
        return True
    
    result = await conn.fetchrow("""
        SELECT rd.permissions 
        FROM team_memberships tm
        JOIN role_definitions rd ON tm.role_id = rd.id
        WHERE tm.user_id = $1 AND tm.company_id = $2 AND tm.status = 'active'
    """, user_id, company_id)
    
    if not result:
        return False
    
    permissions = result['permissions'] or {}
    return permissions.get('billing', False)

def generate_invoice_number() -> str:
    """Generate a unique invoice number"""
    from datetime import datetime
    timestamp = datetime.now().strftime('%Y%m%d%H%M%S')
    return f"INV-{timestamp}"

# Billing and Invoice Endpoints
@router.get("/invoice-history")
async def get_invoice_history(
    user: AuthorizedUser,
    company_id: Optional[int] = None,
    status: Optional[str] = None,
    limit: int = 50,
    offset: int = 0
) -> BillingHistoryResponse:
    """Get comprehensive invoice history with filtering"""
    try:
        conn = await get_db_connection()
        
        # Build query based on company vs individual user
        if company_id:
            # Check billing permission for company
            if not await check_billing_permission(user.sub, company_id, conn):
                raise HTTPException(status_code=403, detail="Insufficient billing permissions")
            
            base_query = """
                SELECT ih.*, c.company_name
                FROM invoice_history ih
                LEFT JOIN companies c ON ih.company_id = c.id
                WHERE ih.company_id = $1
            """
            params = [company_id]
        else:
            # Individual user billing history
            base_query = """
                SELECT ih.*, c.company_name
                FROM invoice_history ih
                LEFT JOIN companies c ON ih.company_id = c.id
                WHERE ih.user_id = $1
            """
            params = [user.sub]
        
        # Add status filter if provided
        if status:
            base_query += f" AND ih.status = ${len(params) + 1}"
            params.append(status)
        
        # Get total count
        count_query = f"SELECT COUNT(*) FROM ({base_query}) as filtered"
        total_count = await conn.fetchval(count_query, *params)
        
        # Get paginated results
        query = f"{base_query} ORDER BY ih.invoice_date DESC LIMIT ${len(params) + 1} OFFSET ${len(params) + 2}"
        params.extend([limit, offset])
        
        invoices = await conn.fetch(query, *params)
        
        # Calculate totals
        totals_query = f"""
            SELECT 
                SUM(CASE WHEN ih.status = 'paid' THEN ih.amount_total ELSE 0 END) as total_paid,
                SUM(CASE WHEN ih.status IN ('pending', 'overdue') THEN ih.amount_total ELSE 0 END) as total_pending
            FROM ({base_query}) as filtered
        """
        totals = await conn.fetchrow(totals_query, *params[:-2])  # Exclude limit/offset
        
        await conn.close()
        
        invoice_list = [
            InvoiceResponse(
                id=inv['id'],
                company_id=inv['company_id'],
                user_id=inv['user_id'],
                invoice_number=inv['invoice_number'],
                invoice_date=inv['invoice_date'].isoformat(),
                due_date=inv['due_date'].isoformat() if inv['due_date'] else None,
                amount_net=float(inv['amount_net']),
                amount_vat=float(inv['amount_vat']),
                amount_total=float(inv['amount_total']),
                currency=inv['currency'],
                status=inv['status'],
                payment_method=inv['payment_method'],
                payment_date=inv['payment_date'].isoformat() if inv['payment_date'] else None,
                line_items=inv['line_items'] or [],
                billing_address=inv['billing_address'],
                notes=inv['notes'],
                pdf_url=inv['pdf_url'],
                created_at=inv['created_at'].isoformat(),
                updated_at=inv['updated_at'].isoformat(),
                company_name=inv['company_name']
            )
            for inv in invoices
        ]
        
        return BillingHistoryResponse(
            invoices=invoice_list,
            total_count=total_count,
            total_amount_paid=float(totals['total_paid'] or 0),
            total_amount_pending=float(totals['total_pending'] or 0),
            currency='EUR'
        )
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error getting invoice history: {e}")
        raise HTTPException(status_code=500, detail="Failed to get invoice history")

@router.post("/create-invoice")
async def create_invoice(body: CreateInvoiceRequest, user: AuthorizedUser) -> InvoiceResponse:
    """Create a new invoice (Admin only)"""
    try:
        conn = await get_db_connection()
        
        # Check billing permission
        if not await check_billing_permission(user.sub, body.company_id, conn):
            raise HTTPException(status_code=403, detail="Insufficient billing permissions")
        
        # Calculate totals
        amount_net = sum(item.total_price for item in body.line_items)
        amount_vat = amount_net * 0.19  # 19% VAT (adjust based on country)
        amount_total = amount_net + amount_vat
        
        # Generate invoice number
        invoice_number = generate_invoice_number()
        invoice_date = date.today()
        due_date = date.today() + timedelta(days=body.due_days)
        
        # Create invoice
        invoice_id = await conn.fetchval("""
            INSERT INTO invoice_history 
            (company_id, user_id, invoice_number, invoice_date, due_date, 
             amount_net, amount_vat, amount_total, currency, status,
             line_items, billing_address, notes, created_at, updated_at)
            VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15)
            RETURNING id
        """, 
        body.company_id, user.sub, invoice_number, invoice_date, due_date,
        amount_net, amount_vat, amount_total, 'EUR', 'pending',
        json.dumps([item.dict() for item in body.line_items]),
        json.dumps(body.billing_address), body.notes,
        datetime.now(), datetime.now())
        
        # Get created invoice
        invoice = await conn.fetchrow(
            "SELECT * FROM invoice_history WHERE id = $1", invoice_id
        )
        
        await conn.close()
        
        return InvoiceResponse(
            id=invoice['id'],
            company_id=invoice['company_id'],
            user_id=invoice['user_id'],
            invoice_number=invoice['invoice_number'],
            invoice_date=invoice['invoice_date'].isoformat(),
            due_date=invoice['due_date'].isoformat() if invoice['due_date'] else None,
            amount_net=float(invoice['amount_net']),
            amount_vat=float(invoice['amount_vat']),
            amount_total=float(invoice['amount_total']),
            currency=invoice['currency'],
            status=invoice['status'],
            payment_method=invoice['payment_method'],
            payment_date=invoice['payment_date'].isoformat() if invoice['payment_date'] else None,
            line_items=invoice['line_items'] or [],
            billing_address=invoice['billing_address'],
            notes=invoice['notes'],
            pdf_url=invoice['pdf_url'],
            created_at=invoice['created_at'].isoformat(),
            updated_at=invoice['updated_at'].isoformat()
        )
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error creating invoice: {e}")
        raise HTTPException(status_code=500, detail="Failed to create invoice")

@router.get("/usage-analytics")
async def get_usage_analytics(
    user: AuthorizedUser,
    company_id: Optional[int] = None,
    period_days: int = 30
) -> UsageAnalyticsResponse:
    """Get usage analytics for billing insights"""
    try:
        conn = await get_db_connection()
        
        # Check permission
        if company_id and not await check_billing_permission(user.sub, company_id, conn):
            raise HTTPException(status_code=403, detail="Insufficient permissions")
        
        # Calculate period
        end_date = datetime.now()
        start_date = end_date - timedelta(days=period_days)
        
        if company_id:
            # Company analytics
            # Get team size
            team_stats = await conn.fetchrow("""
                SELECT 
                    COUNT(*) as total_users,
                    COUNT(CASE WHEN last_active >= $1 THEN 1 END) as active_users
                FROM team_memberships
                WHERE company_id = $2 AND status = 'active'
            """, start_date, company_id)
            
            # Get spending in period
            spending = await conn.fetchrow("""
                SELECT 
                    SUM(amount_total) as total_spent,
                    COUNT(*) as transaction_count
                FROM user_purchases
                WHERE company_id = $1 AND created_at >= $2 AND payment_status = 'completed'
            """, company_id, start_date)
            
        else:
            # Individual user analytics
            team_stats = {'total_users': 1, 'active_users': 1}
            spending = await conn.fetchrow("""
                SELECT 
                    SUM(amount_total) as total_spent,
                    COUNT(*) as transaction_count
                FROM user_purchases
                WHERE user_id = $1 AND created_at >= $2 AND payment_status = 'completed'
            """, user.sub, start_date)
        
        # Get credit usage
        credit_usage = await conn.fetchrow("""
            SELECT SUM(ABS(amount)) as credits_used
            FROM credit_transactions
            WHERE user_id = $1 AND transaction_type = 'debit' AND created_at >= $2
        """, user.sub, start_date)
        
        # Calculate average monthly spend
        total_spent = float(spending['total_spent'] or 0)
        avg_monthly = (total_spent / period_days) * 30 if period_days > 0 else 0
        
        await conn.close()
        
        return UsageAnalyticsResponse(
            company_id=company_id,
            period_start=start_date.isoformat(),
            period_end=end_date.isoformat(),
            total_users=team_stats['total_users'],
            active_users=team_stats['active_users'],
            module_usage={},  # TODO: Implement module-specific usage tracking
            total_credits_used=int(credit_usage['credits_used'] or 0),
            total_amount_spent=total_spent,
            average_monthly_spend=avg_monthly
        )
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error getting usage analytics: {e}")
        raise HTTPException(status_code=500, detail="Failed to get usage analytics")

@router.get("/download-invoice/{invoice_id}")
async def download_invoice(invoice_id: int, user: AuthorizedUser) -> Dict[str, Any]:
    """Download invoice as PDF"""
    try:
        conn = await get_db_connection()
        
        # Get invoice and check permissions
        invoice = await conn.fetchrow(
            "SELECT * FROM invoice_history WHERE id = $1", invoice_id
        )
        
        if not invoice:
            raise HTTPException(status_code=404, detail="Invoice not found")
        
        # Check if user can access this invoice
        if invoice['company_id']:
            if not await check_billing_permission(user.sub, invoice['company_id'], conn):
                raise HTTPException(status_code=403, detail="Access denied")
        elif invoice['user_id'] != user.sub:
            raise HTTPException(status_code=403, detail="Access denied")
        
        await conn.close()
        
        # TODO: Generate PDF and return download URL
        # For now, return invoice data that can be used to generate PDF on frontend
        
        return {
            "success": True,
            "invoice_data": {
                "invoice_number": invoice['invoice_number'],
                "invoice_date": invoice['invoice_date'].isoformat(),
                "due_date": invoice['due_date'].isoformat() if invoice['due_date'] else None,
                "amount_total": float(invoice['amount_total']),
                "line_items": invoice['line_items'],
                "billing_address": invoice['billing_address']
            },
            "message": "Invoice data retrieved successfully"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error downloading invoice: {e}")
        raise HTTPException(status_code=500, detail="Failed to download invoice")

@router.put("/invoices/{invoice_id}/status")
async def update_invoice_status(
    invoice_id: int, 
    status: str, 
    payment_method: Optional[str] = None,
    user: AuthorizedUser = None
) -> Dict[str, Any]:
    """Update invoice status (Admin only)"""
    try:
        conn = await get_db_connection()
        
        # Get invoice
        invoice = await conn.fetchrow(
            "SELECT * FROM invoice_history WHERE id = $1", invoice_id
        )
        
        if not invoice:
            raise HTTPException(status_code=404, detail="Invoice not found")
        
        # Check permissions
        if invoice['company_id'] and not await check_billing_permission(user.sub, invoice['company_id'], conn):
            raise HTTPException(status_code=403, detail="Insufficient permissions")
        
        # Update invoice
        payment_date = date.today() if status == 'paid' else None
        
        await conn.execute("""
            UPDATE invoice_history 
            SET status = $1, payment_method = $2, payment_date = $3, updated_at = $4
            WHERE id = $5
        """, status, payment_method, payment_date, datetime.now(), invoice_id)
        
        await conn.close()
        
        return {
            "success": True,
            "message": f"Invoice status updated to {status}"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error updating invoice status: {e}")
        raise HTTPException(status_code=500, detail="Failed to update invoice status")

@router.get("/billing-summary")
async def get_billing_summary(user: AuthorizedUser, company_id: Optional[int] = None) -> Dict[str, Any]:
    """Get billing summary for dashboard"""
    try:
        conn = await get_db_connection()
        
        # Check permissions
        if company_id and not await check_billing_permission(user.sub, company_id, conn):
            raise HTTPException(status_code=403, detail="Insufficient permissions")
        
        # Build query based on scope
        if company_id:
            where_clause = "WHERE company_id = $1"
            params = [company_id]
        else:
            where_clause = "WHERE user_id = $1"
            params = [user.sub]
        
        # Get summary statistics
        summary = await conn.fetchrow(f"""
            SELECT 
                COUNT(*) as total_invoices,
                SUM(CASE WHEN status = 'paid' THEN amount_total ELSE 0 END) as total_paid,
                SUM(CASE WHEN status = 'pending' THEN amount_total ELSE 0 END) as total_pending,
                SUM(CASE WHEN status = 'overdue' THEN amount_total ELSE 0 END) as total_overdue,
                MAX(invoice_date) as last_invoice_date
            FROM invoice_history
            {where_clause}
        """, *params)
        
        # Get recent invoices
        recent_invoices = await conn.fetch(f"""
            SELECT invoice_number, amount_total, status, invoice_date
            FROM invoice_history
            {where_clause}
            ORDER BY invoice_date DESC
            LIMIT 5
        """, *params)
        
        await conn.close()
        
        return {
            "total_invoices": summary['total_invoices'],
            "total_paid": float(summary['total_paid'] or 0),
            "total_pending": float(summary['total_pending'] or 0),
            "total_overdue": float(summary['total_overdue'] or 0),
            "last_invoice_date": summary['last_invoice_date'].isoformat() if summary['last_invoice_date'] else None,
            "recent_invoices": [
                {
                    "invoice_number": inv['invoice_number'],
                    "amount_total": float(inv['amount_total']),
                    "status": inv['status'],
                    "invoice_date": inv['invoice_date'].isoformat()
                }
                for inv in recent_invoices
            ],
            "currency": "EUR"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error getting billing summary: {e}")
        raise HTTPException(status_code=500, detail="Failed to get billing summary")

@router.get("/billing-settings")
async def get_billing_settings(user: AuthorizedUser, company_id: Optional[int] = None) -> BillingSettingsResponse:
    """Get billing settings and preferences"""
    try:
        conn = await get_db_connection()
        
        # Check permissions
        if company_id and not await check_billing_permission(user.sub, company_id, conn):
            raise HTTPException(status_code=403, detail="Insufficient billing permissions")
        
        # Get or create billing settings
        if company_id:
            settings = await conn.fetchrow(
                "SELECT * FROM billing_settings WHERE company_id = $1", company_id
            )
            identifier = company_id
        else:
            settings = await conn.fetchrow(
                "SELECT * FROM billing_settings WHERE user_id = $1", user.sub
            )
            identifier = user.sub
        
        if not settings:
            # Create default settings
            if company_id:
                await conn.execute("""
                    INSERT INTO billing_settings 
                    (company_id, billing_email, auto_pay_enabled, invoice_delivery_method, currency_preference, billing_cycle, created_at, updated_at)
                    VALUES ($1, NULL, false, 'email', 'EUR', 'monthly', $2, $3)
                """, company_id, datetime.now(), datetime.now())
            else:
                await conn.execute("""
                    INSERT INTO billing_settings 
                    (user_id, billing_email, auto_pay_enabled, invoice_delivery_method, currency_preference, billing_cycle, created_at, updated_at)
                    VALUES ($1, NULL, false, 'email', 'EUR', 'monthly', $2, $3)
                """, user.sub, datetime.now(), datetime.now())
            
            # Fetch the newly created settings
            if company_id:
                settings = await conn.fetchrow(
                    "SELECT * FROM billing_settings WHERE company_id = $1", company_id
                )
            else:
                settings = await conn.fetchrow(
                    "SELECT * FROM billing_settings WHERE user_id = $1", user.sub
                )
        
        await conn.close()
        
        return BillingSettingsResponse(
            company_id=settings['company_id'],
            billing_email=settings['billing_email'],
            auto_pay_enabled=settings['auto_pay_enabled'],
            invoice_delivery_method=settings['invoice_delivery_method'],
            currency_preference=settings['currency_preference'],
            billing_cycle=settings['billing_cycle']
        )
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error getting billing settings: {e}")
        raise HTTPException(status_code=500, detail="Failed to get billing settings")

class UpdateBillingSettingsRequest(BaseModel):
    billing_email: Optional[str] = None
    auto_pay_enabled: Optional[bool] = None
    invoice_delivery_method: Optional[str] = None
    currency_preference: Optional[str] = None
    billing_cycle: Optional[str] = None

@router.put("/billing-settings")
async def update_billing_settings(
    request: UpdateBillingSettingsRequest, 
    user: AuthorizedUser, 
    company_id: Optional[int] = None
) -> Dict[str, Any]:
    """Update billing settings and preferences"""
    try:
        conn = await get_db_connection()
        
        # Check permissions
        if company_id and not await check_billing_permission(user.sub, company_id, conn):
            raise HTTPException(status_code=403, detail="Insufficient billing permissions")
        
        # Build update query dynamically
        update_fields = []
        params = []
        param_count = 1
        
        if request.billing_email is not None:
            update_fields.append(f"billing_email = ${param_count}")
            params.append(request.billing_email)
            param_count += 1
        
        if request.auto_pay_enabled is not None:
            update_fields.append(f"auto_pay_enabled = ${param_count}")
            params.append(request.auto_pay_enabled)
            param_count += 1
        
        if request.invoice_delivery_method is not None:
            update_fields.append(f"invoice_delivery_method = ${param_count}")
            params.append(request.invoice_delivery_method)
            param_count += 1
        
        if request.currency_preference is not None:
            update_fields.append(f"currency_preference = ${param_count}")
            params.append(request.currency_preference)
            param_count += 1
        
        if request.billing_cycle is not None:
            update_fields.append(f"billing_cycle = ${param_count}")
            params.append(request.billing_cycle)
            param_count += 1
        
        if not update_fields:
            raise HTTPException(status_code=400, detail="No fields to update")
        
        # Add updated_at
        update_fields.append(f"updated_at = ${param_count}")
        params.append(datetime.now())
        param_count += 1
        
        # Add WHERE clause parameter
        if company_id:
            where_clause = f"company_id = ${param_count}"
            params.append(company_id)
        else:
            where_clause = f"user_id = ${param_count}"
            params.append(user.sub)
        
        # Execute update
        query = f"""
            UPDATE billing_settings 
            SET {', '.join(update_fields)}
            WHERE {where_clause}
        """
        
        result = await conn.execute(query, *params)
        
        if result == "UPDATE 0":
            # Settings don't exist, create them first
            await get_billing_settings(user, company_id)
            # Then try update again
            result = await conn.execute(query, *params)
        
        await conn.close()
        
        return {
            "success": True,
            "message": "Billing settings updated successfully"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error updating billing settings: {e}")
        raise HTTPException(status_code=500, detail="Failed to update billing settings")
