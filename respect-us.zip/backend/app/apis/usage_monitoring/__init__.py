from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel
from typing import List, Optional, Dict, Any
from datetime import datetime, timedelta
import asyncpg
import databutton as db
from app.env import Mode, mode
from app.auth import AuthorizedUser

router = APIRouter()

# Pydantic Models
class UsageSummary(BaseModel):
    total_credits_consumed: int
    total_actions_performed: int
    most_used_component: str
    most_used_action: str
    daily_average: float
    weekly_trend: str  # "increasing", "decreasing", "stable"
    current_balance: int
    lifetime_consumed: int

class ComponentUsage(BaseModel):
    component_name: str
    action_name: str
    total_usage: int
    total_cost: int
    usage_count: int
    avg_cost_per_action: float
    last_used: datetime
    percentage_of_total: float

class DailyUsagePoint(BaseModel):
    date: str
    credits_consumed: int
    actions_performed: int
    components_used: List[str]

class SpendingAlert(BaseModel):
    id: int
    user_id: str
    alert_type: str  # "low_balance", "high_usage", "daily_limit", "weekly_limit"
    threshold_value: int
    current_value: int
    message: str
    is_active: bool
    created_at: datetime
    triggered_at: Optional[datetime]

class AlertThreshold(BaseModel):
    alert_type: str
    threshold_value: int
    is_enabled: bool

class AdminUsageAnalytics(BaseModel):
    total_users: int
    active_users_last_30_days: int
    total_credits_consumed_all_time: int
    total_credits_consumed_last_30_days: int
    average_credits_per_user: float
    top_components_by_usage: List[ComponentUsage]
    revenue_analytics: Dict[str, Any]
    user_engagement_metrics: Dict[str, Any]

class RealTimeMetrics(BaseModel):
    credits_consumed_today: int
    actions_performed_today: int
    active_sessions: int
    peak_usage_hour: str
    current_burn_rate: float  # credits per hour
    projected_daily_consumption: int

# Database connection helper
async def get_db_connection():
    if mode == Mode.PROD:
        database_url = db.secrets.get("DATABASE_URL_PROD")
    else:
        database_url = db.secrets.get("DATABASE_URL_DEV")
    return await asyncpg.connect(database_url)

@router.get("/usage/summary", response_model=UsageSummary)
async def get_user_usage_summary(user: AuthorizedUser):
    """Get comprehensive usage summary for the current user"""
    conn = await get_db_connection()
    try:
        # Get basic stats
        summary_query = """
            SELECT 
                COALESCE(SUM(ABS(amount)), 0) as total_consumed,
                COUNT(*) as total_actions,
                uc.current_balance,
                uc.lifetime_consumed
            FROM credit_transactions ct
            RIGHT JOIN user_credits uc ON uc.user_id = ct.user_id
            WHERE uc.user_id = $1 AND (ct.transaction_type = 'consume' OR ct.transaction_type IS NULL)
        """
        summary = await conn.fetchrow(summary_query, user.sub)
        
        # Get most used component/action
        top_usage_query = """
            SELECT component_name, action_name, COUNT(*) as usage_count
            FROM credit_transactions 
            WHERE user_id = $1 AND transaction_type = 'consume'
            GROUP BY component_name, action_name
            ORDER BY usage_count DESC
            LIMIT 1
        """
        top_usage = await conn.fetchrow(top_usage_query, user.sub)
        
        # Calculate daily average (last 30 days)
        daily_avg_query = """
            SELECT COALESCE(AVG(daily_consumption), 0) as daily_average
            FROM (
                SELECT DATE(created_at) as day, SUM(ABS(amount)) as daily_consumption
                FROM credit_transactions 
                WHERE user_id = $1 AND transaction_type = 'consume' 
                AND created_at > $2
                GROUP BY DATE(created_at)
            ) daily_stats
        """
        thirty_days_ago = datetime.utcnow() - timedelta(days=30)
        daily_avg = await conn.fetchval(daily_avg_query, user.sub, thirty_days_ago)
        
        # Calculate weekly trend
        trend_query = """
            SELECT 
                SUM(CASE WHEN created_at > $2 THEN ABS(amount) ELSE 0 END) as this_week,
                SUM(CASE WHEN created_at BETWEEN $3 AND $2 THEN ABS(amount) ELSE 0 END) as last_week
            FROM credit_transactions 
            WHERE user_id = $1 AND transaction_type = 'consume'
        """
        one_week_ago = datetime.utcnow() - timedelta(days=7)
        two_weeks_ago = datetime.utcnow() - timedelta(days=14)
        trend_data = await conn.fetchrow(trend_query, user.sub, one_week_ago, two_weeks_ago)
        
        # Determine trend
        this_week = trend_data['this_week'] or 0
        last_week = trend_data['last_week'] or 0
        if this_week > last_week * 1.1:
            trend = "increasing"
        elif this_week < last_week * 0.9:
            trend = "decreasing"
        else:
            trend = "stable"
        
        return UsageSummary(
            total_credits_consumed=summary['total_consumed'] or 0,
            total_actions_performed=summary['total_actions'] or 0,
            most_used_component=top_usage['component_name'] if top_usage else "N/A",
            most_used_action=top_usage['action_name'] if top_usage else "N/A",
            daily_average=float(daily_avg or 0),
            weekly_trend=trend,
            current_balance=summary['current_balance'] or 0,
            lifetime_consumed=summary['lifetime_consumed'] or 0
        )
    finally:
        await conn.close()

@router.get("/usage/components", response_model=List[ComponentUsage])
async def get_component_usage_breakdown(user: AuthorizedUser, days: int = Query(30, description="Number of days to analyze")):
    """Get detailed breakdown of usage by component and action"""
    conn = await get_db_connection()
    try:
        cutoff_date = datetime.utcnow() - timedelta(days=days)
        
        # Get total consumption for percentage calculation
        total_query = """
            SELECT COALESCE(SUM(ABS(amount)), 1) as total_consumed
            FROM credit_transactions 
            WHERE user_id = $1 AND transaction_type = 'consume' AND created_at > $2
        """
        total_consumed = await conn.fetchval(total_query, user.sub, cutoff_date)
        
        # Get component breakdown
        breakdown_query = """
            SELECT 
                component_name,
                action_name,
                SUM(ABS(amount)) as total_cost,
                COUNT(*) as usage_count,
                MAX(created_at) as last_used
            FROM credit_transactions 
            WHERE user_id = $1 AND transaction_type = 'consume' AND created_at > $2
            GROUP BY component_name, action_name
            ORDER BY total_cost DESC
        """
        breakdown = await conn.fetch(breakdown_query, user.sub, cutoff_date)
        
        return [
            ComponentUsage(
                component_name=row['component_name'],
                action_name=row['action_name'],
                total_usage=row['usage_count'],
                total_cost=row['total_cost'],
                usage_count=row['usage_count'],
                avg_cost_per_action=row['total_cost'] / row['usage_count'],
                last_used=row['last_used'],
                percentage_of_total=(row['total_cost'] / total_consumed) * 100
            )
            for row in breakdown
        ]
    finally:
        await conn.close()

@router.get("/usage/daily-chart", response_model=List[DailyUsagePoint])
async def get_daily_usage_chart(user: AuthorizedUser, days: int = Query(30, description="Number of days to chart")):
    """Get daily usage data for charting"""
    conn = await get_db_connection()
    try:
        cutoff_date = datetime.utcnow() - timedelta(days=days)
        
        daily_query = """
            SELECT 
                DATE(created_at) as usage_date,
                SUM(ABS(amount)) as credits_consumed,
                COUNT(*) as actions_performed,
                ARRAY_AGG(DISTINCT component_name) as components_used
            FROM credit_transactions 
            WHERE user_id = $1 AND transaction_type = 'consume' AND created_at > $2
            GROUP BY DATE(created_at)
            ORDER BY usage_date
        """
        daily_data = await conn.fetch(daily_query, user.sub, cutoff_date)
        
        return [
            DailyUsagePoint(
                date=row['usage_date'].isoformat(),
                credits_consumed=row['credits_consumed'],
                actions_performed=row['actions_performed'],
                components_used=row['components_used']
            )
            for row in daily_data
        ]
    finally:
        await conn.close()

@router.get("/usage/real-time-metrics", response_model=RealTimeMetrics)
async def get_real_time_metrics(user: AuthorizedUser):
    """Get real-time usage metrics for the current day"""
    conn = await get_db_connection()
    try:
        today = datetime.utcnow().date()
        
        # Today's consumption
        today_query = """
            SELECT 
                COALESCE(SUM(ABS(amount)), 0) as credits_today,
                COUNT(*) as actions_today
            FROM credit_transactions 
            WHERE user_id = $1 AND transaction_type = 'consume' 
            AND DATE(created_at) = $2
        """
        today_data = await conn.fetchrow(today_query, user.sub, today)
        
        # Peak usage hour (last 7 days)
        peak_hour_query = """
            SELECT 
                EXTRACT(HOUR FROM created_at) as hour,
                COUNT(*) as activity_count
            FROM credit_transactions 
            WHERE user_id = $1 AND transaction_type = 'consume' 
            AND created_at > $2
            GROUP BY EXTRACT(HOUR FROM created_at)
            ORDER BY activity_count DESC
            LIMIT 1
        """
        week_ago = datetime.utcnow() - timedelta(days=7)
        peak_hour = await conn.fetchrow(peak_hour_query, user.sub, week_ago)
        
        # Calculate burn rate (credits per hour today)
        hours_elapsed = (datetime.utcnow().hour + 1) if datetime.utcnow().date() == today else 24
        burn_rate = (today_data['credits_today'] or 0) / max(hours_elapsed, 1)
        
        # Project daily consumption
        projected_daily = burn_rate * 24
        
        return RealTimeMetrics(
            credits_consumed_today=today_data['credits_today'] or 0,
            actions_performed_today=today_data['actions_today'] or 0,
            active_sessions=1,  # Current user session
            peak_usage_hour=f"{int(peak_hour['hour']):02d}:00" if peak_hour else "N/A",
            current_burn_rate=burn_rate,
            projected_daily_consumption=int(projected_daily)
        )
    finally:
        await conn.close()

# Spending Alerts System
@router.get("/alerts/active", response_model=List[SpendingAlert])
async def get_active_spending_alerts(user: AuthorizedUser):
    """Get active spending alerts for the user"""
    conn = await get_db_connection()
    try:
        alerts_query = """
            SELECT * FROM spending_alerts 
            WHERE user_id = $1 AND is_active = true
            ORDER BY created_at DESC
        """
        alerts = await conn.fetch(alerts_query, user.sub)
        
        return [
            SpendingAlert(
                id=alert['id'],
                user_id=alert['user_id'],
                alert_type=alert['alert_type'],
                threshold_value=alert['threshold_value'],
                current_value=alert['current_value'],
                message=alert['message'],
                is_active=alert['is_active'],
                created_at=alert['created_at'],
                triggered_at=alert['triggered_at']
            )
            for alert in alerts
        ]
    finally:
        await conn.close()

@router.post("/alerts/configure")
async def configure_spending_alerts(user: AuthorizedUser, thresholds: List[AlertThreshold]):
    """Configure spending alert thresholds"""
    conn = await get_db_connection()
    try:
        async with conn.transaction():
            # Clear existing alert configurations
            await conn.execute(
                "DELETE FROM alert_thresholds WHERE user_id = $1",
                user.sub
            )
            
            # Insert new configurations
            for threshold in thresholds:
                await conn.execute(
                    """
                    INSERT INTO alert_thresholds (user_id, alert_type, threshold_value, is_enabled)
                    VALUES ($1, $2, $3, $4)
                    """,
                    user.sub, threshold.alert_type, threshold.threshold_value, threshold.is_enabled
                )
        
        return {"message": "Alert thresholds configured successfully"}
    finally:
        await conn.close()

@router.post("/alerts/check")
async def check_and_trigger_alerts(user: AuthorizedUser):
    """Check current usage against thresholds and trigger alerts if needed"""
    conn = await get_db_connection()
    try:
        # Get user's current balance and recent usage
        balance_query = "SELECT current_balance FROM user_credits WHERE user_id = $1"
        current_balance = await conn.fetchval(balance_query, user.sub) or 0
        
        # Get today's usage
        today = datetime.utcnow().date()
        today_usage_query = """
            SELECT COALESCE(SUM(ABS(amount)), 0) as credits_today
            FROM credit_transactions 
            WHERE user_id = $1 AND transaction_type = 'consume' 
            AND DATE(created_at) = $2
        """
        credits_today = await conn.fetchval(today_usage_query, user.sub, today)
        
        # Get alert thresholds
        thresholds_query = """
            SELECT * FROM alert_thresholds 
            WHERE user_id = $1 AND is_enabled = true
        """
        thresholds = await conn.fetch(thresholds_query, user.sub)
        
        alerts_triggered = []
        
        for threshold in thresholds:
            should_trigger = False
            current_value = 0
            message = ""
            
            if threshold['alert_type'] == 'low_balance':
                current_value = current_balance
                if current_balance <= threshold['threshold_value']:
                    should_trigger = True
                    message = f"Low credit balance: {current_balance} credits remaining (threshold: {threshold['threshold_value']})"
            
            elif threshold['alert_type'] == 'daily_limit':
                current_value = credits_today
                if credits_today >= threshold['threshold_value']:
                    should_trigger = True
                    message = f"Daily usage limit reached: {credits_today} credits used today (limit: {threshold['threshold_value']})"
            
            if should_trigger:
                # Check if alert already exists today
                existing_alert_query = """
                    SELECT id FROM spending_alerts 
                    WHERE user_id = $1 AND alert_type = $2 
                    AND DATE(created_at) = $3 AND is_active = true
                """
                existing = await conn.fetchval(existing_alert_query, user.sub, threshold['alert_type'], today)
                
                if not existing:
                    # Create new alert
                    alert_id = await conn.fetchval(
                        """
                        INSERT INTO spending_alerts 
                        (user_id, alert_type, threshold_value, current_value, message, is_active, triggered_at)
                        VALUES ($1, $2, $3, $4, $5, true, CURRENT_TIMESTAMP)
                        RETURNING id
                        """,
                        user.sub, threshold['alert_type'], threshold['threshold_value'], current_value, message
                    )
                    alerts_triggered.append(alert_id)
        
        return {
            "message": f"Alert check completed. {len(alerts_triggered)} alerts triggered.",
            "alerts_triggered": alerts_triggered
        }
    finally:
        await conn.close()

@router.post("/alerts/{alert_id}/dismiss")
async def dismiss_spending_alert(user: AuthorizedUser, alert_id: int):
    """Dismiss a spending alert"""
    conn = await get_db_connection()
    try:
        result = await conn.execute(
            "UPDATE spending_alerts SET is_active = false WHERE id = $1 AND user_id = $2",
            alert_id, user.sub
        )
        
        if result == "UPDATE 0":
            raise HTTPException(status_code=404, detail="Alert not found")
        
        return {"message": "Alert dismissed successfully"}
    finally:
        await conn.close()

# Admin Analytics
@router.get("/admin/analytics", response_model=AdminUsageAnalytics)
async def get_admin_usage_analytics(user: AuthorizedUser):
    """Get comprehensive usage analytics for admin dashboard"""
    # TODO: Add admin role check
    conn = await get_db_connection()
    try:
        # Total users and active users
        users_query = """
            SELECT 
                COUNT(DISTINCT uc.user_id) as total_users,
                COUNT(DISTINCT CASE WHEN ct.created_at > $1 THEN ct.user_id END) as active_users
            FROM user_credits uc
            LEFT JOIN credit_transactions ct ON uc.user_id = ct.user_id
        """
        thirty_days_ago = datetime.utcnow() - timedelta(days=30)
        users_data = await conn.fetchrow(users_query, thirty_days_ago)
        
        # Credit consumption stats
        consumption_query = """
            SELECT 
                COALESCE(SUM(ABS(amount)), 0) as total_consumed_all_time,
                COALESCE(SUM(CASE WHEN created_at > $1 THEN ABS(amount) ELSE 0 END), 0) as consumed_last_30_days
            FROM credit_transactions 
            WHERE transaction_type = 'consume'
        """
        consumption_data = await conn.fetchrow(consumption_query, thirty_days_ago)
        
        # Average credits per user
        avg_per_user = (consumption_data['total_consumed_all_time'] / max(users_data['total_users'], 1))
        
        # Top components by usage
        top_components_query = """
            SELECT 
                component_name,
                action_name,
                SUM(ABS(amount)) as total_cost,
                COUNT(*) as usage_count,
                MAX(created_at) as last_used
            FROM credit_transactions 
            WHERE transaction_type = 'consume' AND created_at > $1
            GROUP BY component_name, action_name
            ORDER BY total_cost DESC
            LIMIT 10
        """
        top_components = await conn.fetch(top_components_query, thirty_days_ago)
        
        return AdminUsageAnalytics(
            total_users=users_data['total_users'] or 0,
            active_users_last_30_days=users_data['active_users'] or 0,
            total_credits_consumed_all_time=consumption_data['total_consumed_all_time'] or 0,
            total_credits_consumed_last_30_days=consumption_data['consumed_last_30_days'] or 0,
            average_credits_per_user=avg_per_user,
            top_components_by_usage=[
                ComponentUsage(
                    component_name=comp['component_name'],
                    action_name=comp['action_name'],
                    total_usage=comp['usage_count'],
                    total_cost=comp['total_cost'],
                    usage_count=comp['usage_count'],
                    avg_cost_per_action=comp['total_cost'] / comp['usage_count'],
                    last_used=comp['last_used'],
                    percentage_of_total=0  # Calculate if needed
                )
                for comp in top_components
            ],
            revenue_analytics={
                "total_credits_purchased": 0,  # TODO: Calculate from purchase transactions
                "total_revenue": 0,  # TODO: Calculate from Stripe data
                "average_purchase_size": 0
            },
            user_engagement_metrics={
                "daily_active_users": 0,  # TODO: Calculate
                "retention_rate": 0,  # TODO: Calculate
                "churn_rate": 0  # TODO: Calculate
            }
        )
    finally:
        await conn.close()

@router.get("/admin/real-time-dashboard")
async def get_admin_real_time_dashboard(user: AuthorizedUser):
    """Get real-time system-wide metrics for admin dashboard"""
    conn = await get_db_connection()
    try:
        today = datetime.utcnow().date()
        
        # Today's system-wide activity
        today_activity_query = """
            SELECT 
                COUNT(DISTINCT user_id) as active_users_today,
                SUM(ABS(amount)) as credits_consumed_today,
                COUNT(*) as total_actions_today
            FROM credit_transactions 
            WHERE transaction_type = 'consume' AND DATE(created_at) = $1
        """
        activity = await conn.fetchrow(today_activity_query, today)
        
        # Current hour activity
        current_hour = datetime.utcnow().replace(minute=0, second=0, microsecond=0)
        hour_activity_query = """
            SELECT COUNT(*) as actions_this_hour
            FROM credit_transactions 
            WHERE transaction_type = 'consume' AND created_at >= $1
        """
        hour_activity = await conn.fetchval(hour_activity_query, current_hour)
        
        # System health
        health_query = """
            SELECT 
                COUNT(*) as total_transactions_today,
                COUNT(CASE WHEN created_at > $1 THEN 1 END) as transactions_last_hour
            FROM credit_transactions 
            WHERE DATE(created_at) = $2
        """
        one_hour_ago = datetime.utcnow() - timedelta(hours=1)
        health = await conn.fetchrow(health_query, one_hour_ago, today)
        
        return {
            "real_time_metrics": {
                "active_users_today": activity['active_users_today'] or 0,
                "credits_consumed_today": activity['credits_consumed_today'] or 0,
                "total_actions_today": activity['total_actions_today'] or 0,
                "actions_this_hour": hour_activity or 0,
                "transactions_last_hour": health['transactions_last_hour'] or 0
            },
            "system_health": {
                "status": "healthy",
                "transaction_rate": hour_activity or 0,
                "error_rate": 0,  # TODO: Calculate from error logs
                "response_time": "<100ms"  # TODO: Calculate from performance metrics
            },
            "timestamp": datetime.utcnow().isoformat()
        }
    finally:
        await conn.close()
