from fastapi import APIRouter, HTTPException
from typing import List, Optional
from pydantic import BaseModel
from app.auth import AuthorizedUser

router = APIRouter(prefix="/categories", tags=["categories"])

# Simplified category model
class CategoryResponse(BaseModel):
    id: int
    name: str
    description: Optional[str] = None
    parent_id: Optional[int] = None
    jurisdiction: Optional[str] = None
    sort_order: int = 0
    created_at: str
    updated_at: str
    children: Optional[List['CategoryResponse']] = []
    document_count: int = 0

# Allow forward references
CategoryResponse.model_rebuild()

@router.get("/hierarchy", response_model=List[CategoryResponse])
async def get_categories_hierarchy(user: AuthorizedUser) -> List[CategoryResponse]:
    """Get hierarchical categories structure with document counts"""
    
    # Comprehensive categories for all supported jurisdictions
    categories = [
        # European Union and member states
        {
            "id": 1,
            "name": "European Union",
            "description": "EU export control regulations and directives",
            "parent_id": None,
            "jurisdiction": "EU",
            "sort_order": 1,
            "created_at": "2024-01-01T00:00:00Z",
            "updated_at": "2024-01-01T00:00:00Z",
            "children": [
                {
                    "id": 2,
                    "name": "Sanctions",
                    "description": "EU sanctions and embargoes",
                    "parent_id": 1,
                    "jurisdiction": "EU",
                    "sort_order": 1,
                    "created_at": "2024-01-01T00:00:00Z",
                    "updated_at": "2024-01-01T00:00:00Z",
                    "children": [
                        {
                            "id": 3,
                            "name": "Sanctions Iran",
                            "description": "EU sanctions against Iran",
                            "parent_id": 2,
                            "jurisdiction": "EU",
                            "sort_order": 1,
                            "created_at": "2024-01-01T00:00:00Z",
                            "updated_at": "2024-01-01T00:00:00Z",
                            "children": [],
                            "document_count": 5
                        },
                        {
                            "id": 4,
                            "name": "Sanctions Russia",
                            "description": "EU sanctions against Russia",
                            "parent_id": 2,
                            "jurisdiction": "EU",
                            "sort_order": 2,
                            "created_at": "2024-01-01T00:00:00Z",
                            "updated_at": "2024-01-01T00:00:00Z",
                            "children": [],
                            "document_count": 8
                        }
                    ],
                    "document_count": 13
                },
                {
                    "id": 5,
                    "name": "Export Controls",
                    "description": "EU export control regulations",
                    "parent_id": 1,
                    "jurisdiction": "EU",
                    "sort_order": 2,
                    "created_at": "2024-01-01T00:00:00Z",
                    "updated_at": "2024-01-01T00:00:00Z",
                    "children": [
                        {
                            "id": 6,
                            "name": "Dual-Use Items",
                            "description": "EU dual-use export controls",
                            "parent_id": 5,
                            "jurisdiction": "EU",
                            "sort_order": 1,
                            "created_at": "2024-01-01T00:00:00Z",
                            "updated_at": "2024-01-01T00:00:00Z",
                            "children": [],
                            "document_count": 12
                        }
                    ],
                    "document_count": 12
                }
            ],
            "document_count": 25
        },
        
        # United States
        {
            "id": 10,
            "name": "United States",
            "description": "US export control regulations and sanctions",
            "parent_id": None,
            "jurisdiction": "US",
            "sort_order": 2,
            "created_at": "2024-01-01T00:00:00Z",
            "updated_at": "2024-01-01T00:00:00Z",
            "children": [
                {
                    "id": 11,
                    "name": "OFAC Sanctions",
                    "description": "US OFAC sanctions programs",
                    "parent_id": 10,
                    "jurisdiction": "US",
                    "sort_order": 1,
                    "created_at": "2024-01-01T00:00:00Z",
                    "updated_at": "2024-01-01T00:00:00Z",
                    "children": [],
                    "document_count": 15
                },
                {
                    "id": 12,
                    "name": "EAR Export Controls",
                    "description": "US Export Administration Regulations",
                    "parent_id": 10,
                    "jurisdiction": "US",
                    "sort_order": 2,
                    "created_at": "2024-01-01T00:00:00Z",
                    "updated_at": "2024-01-01T00:00:00Z",
                    "children": [],
                    "document_count": 18
                }
            ],
            "document_count": 33
        },
        
        # United Kingdom
        {
            "id": 20,
            "name": "United Kingdom",
            "description": "UK export control and sanctions regulations",
            "parent_id": None,
            "jurisdiction": "GB",
            "sort_order": 3,
            "created_at": "2024-01-01T00:00:00Z",
            "updated_at": "2024-01-01T00:00:00Z",
            "children": [
                {
                    "id": 21,
                    "name": "UK Sanctions",
                    "description": "UK sanctions and asset freezes",
                    "parent_id": 20,
                    "jurisdiction": "GB",
                    "sort_order": 1,
                    "created_at": "2024-01-01T00:00:00Z",
                    "updated_at": "2024-01-01T00:00:00Z",
                    "children": [],
                    "document_count": 12
                },
                {
                    "id": 22,
                    "name": "Strategic Export Controls",
                    "description": "UK strategic export control regulations",
                    "parent_id": 20,
                    "jurisdiction": "GB",
                    "sort_order": 2,
                    "created_at": "2024-01-01T00:00:00Z",
                    "updated_at": "2024-01-01T00:00:00Z",
                    "children": [],
                    "document_count": 8
                }
            ],
            "document_count": 20
        },
        
        # Germany
        {
            "id": 30,
            "name": "Germany",
            "description": "German export control regulations",
            "parent_id": None,
            "jurisdiction": "DE",
            "sort_order": 4,
            "created_at": "2024-01-01T00:00:00Z",
            "updated_at": "2024-01-01T00:00:00Z",
            "children": [],
            "document_count": 15
        },
        
        # France
        {
            "id": 40,
            "name": "France",
            "description": "French export control regulations",
            "parent_id": None,
            "jurisdiction": "FR",
            "sort_order": 5,
            "created_at": "2024-01-01T00:00:00Z",
            "updated_at": "2024-01-01T00:00:00Z",
            "children": [],
            "document_count": 10
        },
        
        # Japan
        {
            "id": 50,
            "name": "Japan",
            "description": "Japanese export control regulations",
            "parent_id": None,
            "jurisdiction": "JP",
            "sort_order": 6,
            "created_at": "2024-01-01T00:00:00Z",
            "updated_at": "2024-01-01T00:00:00Z",
            "children": [],
            "document_count": 8
        },
        
        # Canada
        {
            "id": 60,
            "name": "Canada",
            "description": "Canadian export control regulations",
            "parent_id": None,
            "jurisdiction": "CA",
            "sort_order": 7,
            "created_at": "2024-01-01T00:00:00Z",
            "updated_at": "2024-01-01T00:00:00Z",
            "children": [],
            "document_count": 1
        },
        
        # Australia
        {
            "id": 70,
            "name": "Australia",
            "description": "Australian export control regulations",
            "parent_id": None,
            "jurisdiction": "AU",
            "sort_order": 8,
            "created_at": "2024-01-01T00:00:00Z",
            "updated_at": "2024-01-01T00:00:00Z",
            "children": [],
            "document_count": 5
        },
        
        # South Korea
        {
            "id": 80,
            "name": "South Korea",
            "description": "South Korean export control regulations",
            "parent_id": None,
            "jurisdiction": "KR",
            "sort_order": 9,
            "created_at": "2024-01-01T00:00:00Z",
            "updated_at": "2024-01-01T00:00:00Z",
            "children": [],
            "document_count": 4
        },
        
        # Switzerland
        {
            "id": 90,
            "name": "Switzerland",
            "description": "Swiss export control regulations",
            "parent_id": None,
            "jurisdiction": "CH",
            "sort_order": 10,
            "created_at": "2024-01-01T00:00:00Z",
            "updated_at": "2024-01-01T00:00:00Z",
            "children": [],
            "document_count": 3
        },
        
        # Netherlands
        {
            "id": 100,
            "name": "Netherlands",
            "description": "Dutch export control regulations",
            "parent_id": None,
            "jurisdiction": "NL",
            "sort_order": 11,
            "created_at": "2024-01-01T00:00:00Z",
            "updated_at": "2024-01-01T00:00:00Z",
            "children": [],
            "document_count": 7
        },
        
        # Italy
        {
            "id": 110,
            "name": "Italy",
            "description": "Italian export control regulations",
            "parent_id": None,
            "jurisdiction": "IT",
            "sort_order": 12,
            "created_at": "2024-01-01T00:00:00Z",
            "updated_at": "2024-01-01T00:00:00Z",
            "children": [],
            "document_count": 5
        },
        
        # Spain
        {
            "id": 120,
            "name": "Spain",
            "description": "Spanish export control regulations",
            "parent_id": None,
            "jurisdiction": "ES",
            "sort_order": 13,
            "created_at": "2024-01-01T00:00:00Z",
            "updated_at": "2024-01-01T00:00:00Z",
            "children": [],
            "document_count": 4
        },
        
        # Sweden
        {
            "id": 130,
            "name": "Sweden",
            "description": "Swedish export control regulations",
            "parent_id": None,
            "jurisdiction": "SE",
            "sort_order": 14,
            "created_at": "2024-01-01T00:00:00Z",
            "updated_at": "2024-01-01T00:00:00Z",
            "children": [],
            "document_count": 3
        },
        
        # Norway
        {
            "id": 140,
            "name": "Norway",
            "description": "Norwegian export control regulations",
            "parent_id": None,
            "jurisdiction": "NO",
            "sort_order": 15,
            "created_at": "2024-01-01T00:00:00Z",
            "updated_at": "2024-01-01T00:00:00Z",
            "children": [],
            "document_count": 2
        },
        
        # Denmark
        {
            "id": 150,
            "name": "Denmark",
            "description": "Danish export control regulations",
            "parent_id": None,
            "jurisdiction": "DK",
            "sort_order": 16,
            "created_at": "2024-01-01T00:00:00Z",
            "updated_at": "2024-01-01T00:00:00Z",
            "children": [],
            "document_count": 3
        },
        
        # Finland
        {
            "id": 160,
            "name": "Finland",
            "description": "Finnish export control regulations",
            "parent_id": None,
            "jurisdiction": "FI",
            "sort_order": 17,
            "created_at": "2024-01-01T00:00:00Z",
            "updated_at": "2024-01-01T00:00:00Z",
            "children": [],
            "document_count": 2
        },
        
        # Austria
        {
            "id": 170,
            "name": "Austria",
            "description": "Austrian export control regulations",
            "parent_id": None,
            "jurisdiction": "AT",
            "sort_order": 18,
            "created_at": "2024-01-01T00:00:00Z",
            "updated_at": "2024-01-01T00:00:00Z",
            "children": [],
            "document_count": 3
        },
        
        # Belgium
        {
            "id": 180,
            "name": "Belgium",
            "description": "Belgian export control regulations",
            "parent_id": None,
            "jurisdiction": "BE",
            "sort_order": 19,
            "created_at": "2024-01-01T00:00:00Z",
            "updated_at": "2024-01-01T00:00:00Z",
            "children": [],
            "document_count": 2
        },
        
        # Ireland
        {
            "id": 190,
            "name": "Ireland",
            "description": "Irish export control regulations",
            "parent_id": None,
            "jurisdiction": "IE",
            "sort_order": 20,
            "created_at": "2024-01-01T00:00:00Z",
            "updated_at": "2024-01-01T00:00:00Z",
            "children": [],
            "document_count": 1
        },
        
        # Luxembourg
        {
            "id": 200,
            "name": "Luxembourg",
            "description": "Luxembourg export control regulations",
            "parent_id": None,
            "jurisdiction": "LU",
            "sort_order": 21,
            "created_at": "2024-01-01T00:00:00Z",
            "updated_at": "2024-01-01T00:00:00Z",
            "children": [],
            "document_count": 1
        }
    ]
    
    return categories
