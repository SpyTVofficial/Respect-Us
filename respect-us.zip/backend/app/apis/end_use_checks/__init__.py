from datetime import datetime
from fastapi import APIRouter, HTTPException, Query, File, UploadFile
from pydantic import BaseModel
from typing import List, Dict, Any, Optional
import asyncpg
import databutton as db
from app.auth import AuthorizedUser
from app.env import Mode, mode
from app.libs.credit_wrapper import consume_credits_for_action
import json
import io
from openpyxl import load_workbook

# Module-level singleton to avoid B008 linting issue
_FILE_DEPENDENCY = File(...)

# Add new import for creating Excel files
from openpyxl import Workbook
from fastapi.responses import Response

router = APIRouter(prefix="/end-use-checks")

# Database connection
async def get_db_connection():
    if mode == Mode.PROD:
        DATABASE_URL = db.secrets.get("DATABASE_URL_PROD")
    else:
        DATABASE_URL = db.secrets.get("DATABASE_URL_DEV")
    return await asyncpg.connect(DATABASE_URL)

# Pydantic models
class RiskCategory(BaseModel):
    id: int
    category_name: str
    description: Optional[str] = None
    display_order: int

class RiskIndicator(BaseModel):
    id: int
    category_id: int
    indicator_name: str
    indicator_type: str
    description: Optional[str] = None
    display_order: int

class CountryRiskValue(BaseModel):
    indicator_id: int
    indicator_name: str
    value_text: Optional[str] = None
    value_boolean: Optional[bool] = None
    value_numeric: Optional[float] = None
    value_date: Optional[str] = None
    notes: Optional[str] = None

# Pydantic models for critical countries
class CriticalCountry(BaseModel):
    id: int
    country_name: str
    abbreviation: str | None = None
    iso_code: str | None = None
    is_active: bool = True
    
    # Risk assessment
    risk_level: str | None = None
    risk_categories: dict | None = None
    risk_description: str | None = None
    last_risk_assessment_date: str | None = None
    
    # Export Control Regimes
    export_control_wassenaar: bool | None = None
    export_control_nsg: bool | None = None
    export_control_ag: bool | None = None
    export_control_mtcr: bool | None = None
    export_control_zc: bool | None = None
    export_control_notes: str | None = None
    export_control_risk: str | None = None
    
    # Sanctions
    sanctions: bool | None = None
    sanctions_notes: str | None = None
    sanctions_risk: str | None = None
    
    # Arms Embargoes
    un_arms_embargo: bool | None = None
    un_arms_embargo_notes: str | None = None
    us_arms_embargo: bool | None = None
    us_arms_embargo_notes: str | None = None
    eu_arms_embargo: bool | None = None
    eu_arms_embargo_notes: str | None = None
    other_arms_embargo: bool | None = None
    other_arms_embargo_notes: str | None = None
    arms_risk: str | None = None
    
    # Chemical Weapons
    cwc_1993_signatory: bool | None = None
    cwc_1993_ratified: bool | None = None
    cwc_violations: bool | None = None
    chemical_risk: str | None = None
    
    # Biological Weapons
    bwc_1972_signatory: bool | None = None
    bwc_1972_ratified: bool | None = None
    bwc_violations: bool | None = None
    biological_risk: str | None = None
    
    # Nuclear Treaties
    npt_signatory: bool | None = None
    npt_ratified: bool | None = None
    npt_notes: str | None = None
    ctbt_signatory: bool | None = None
    ctbt_ratified: bool | None = None
    ctbt_notes: str | None = None
    iaea_signatory: bool | None = None
    iaea_ratified: bool | None = None
    iaea_notes: str | None = None
    nsg_1974_signatory: bool | None = None
    nsg_1974_ratified: bool | None = None
    nsg_notes: str | None = None
    conv_1980_signatory: bool | None = None
    conv_1980_ratified: bool | None = None
    conv_1980_notes: str | None = None
    conv_1994_signatory: bool | None = None
    conv_1994_ratified: bool | None = None
    conv_1994_notes: str | None = None
    nuclear_violations: bool | None = None
    nuclear_risk: str | None = None
    
    # Human Rights and Democracy
    human_rights: str | None = None
    human_rights_note: str | None = None
    human_rights_risk_score: int | None = None
    political_rights: str | None = None
    civil_liberties: str | None = None
    freedom_in_the_world: bool | None = None
    freedom_note: str | None = None
    freedom_risk: str | None = None
    
    # Internet Freedom
    obstacles_to_access: str | None = None
    limits_on_content: str | None = None
    violations_of_user_rights: str | None = None
    freedom_net_note: str | None = None
    freedom_net_risk: str | None = None
    
    # Democracy Indicators
    democracy_status: str | None = None
    democracy_percentage: str | None = None
    nations_in_transit: str | None = None
    regime_type: str | None = None
    human_rights_freedoms_risk: str | None = None
    
    # Metadata
    created_at: str | None = None
    updated_at: str | None = None
    created_by: str | None = None
    updated_by: str | None = None
    notes: str | None = None

class CountrySearchFilters(BaseModel):
    search_term: Optional[str] = None
    risk_categories: Optional[List[str]] = None
    has_arms_embargo: Optional[bool] = None
    treaty_compliance: Optional[List[str]] = None
    freedom_score_min: Optional[float] = None
    freedom_score_max: Optional[float] = None

class CountryCreateRequest(BaseModel):
    name: str
    abbreviation: Optional[str] = None
    iso_code: Optional[str] = None

class CountryUpdateRequest(BaseModel):
    name: Optional[str] = None
    abbreviation: Optional[str] = None
    iso_code: Optional[str] = None

class RiskAssessmentRequest(BaseModel):
    country_id: int
    indicator_id: int
    value_text: Optional[str] = None
    value_boolean: Optional[bool] = None
    value_numeric: Optional[float] = None
    value_date: Optional[str] = None
    notes: Optional[str] = None

class BulkUploadResponse(BaseModel):
    success_count: int
    error_count: int
    message: str
    errors: List[str] = []

# Risk Categories endpoints
@router.get("/risk-categories", response_model=List[RiskCategory])
async def get_risk_categories():
    """Get all risk categories"""
    conn = await get_db_connection()
    try:
        query = """
        SELECT id, category_name, description, display_order
        FROM risk_categories
        ORDER BY display_order, category_name
        """
        rows = await conn.fetch(query)
        return [dict(row) for row in rows]
    finally:
        await conn.close()

@router.get("/risk-indicators", response_model=List[RiskIndicator])
async def get_risk_indicators(category_id: Optional[int] = None):
    """Get risk indicators, optionally filtered by category"""
    conn = await get_db_connection()
    try:
        if category_id:
            query = """
            SELECT id, category_id, indicator_name, indicator_type, description, display_order
            FROM risk_indicators
            WHERE category_id = $1
            ORDER BY display_order, indicator_name
            """
            rows = await conn.fetch(query, category_id)
        else:
            query = """
            SELECT id, category_id, indicator_name, indicator_type, description, display_order
            FROM risk_indicators
            ORDER BY category_id, display_order, indicator_name
            """
            rows = await conn.fetch(query)
        return [dict(row) for row in rows]
    finally:
        await conn.close()

# Critical Countries endpoints
@router.get("/countries", response_model=List[CriticalCountry])
async def list_critical_countries(
    search: Optional[str] = None,
    category: Optional[str] = None,
    limit: int = 100,
    offset: int = 0
):
    """Get critical countries with optional search and filtering"""
    conn = await get_db_connection()
    try:
        # Base query for countries
        base_query = """
        SELECT DISTINCT cc.id, cc.country_name, cc.abbreviation, cc.iso_code
        FROM critical_countries cc
        """
        
        conditions = []
        params = []
        param_count = 0
        
        if search:
            param_count += 1
            conditions.append(f"(cc.country_name ILIKE ${param_count} OR cc.abbreviation ILIKE ${param_count})")
            params.append(f"%{search}%")
        
        if category:
            base_query += """
            LEFT JOIN country_risk_assessments cra ON cc.id = cra.country_id
            LEFT JOIN risk_indicators ri ON cra.indicator_id = ri.id
            LEFT JOIN risk_categories rc ON ri.category_id = rc.id
            """
            param_count += 1
            conditions.append(f"rc.category_name = ${param_count}")
            params.append(category)
        
        if conditions:
            base_query += " WHERE " + " AND ".join(conditions)
        
        base_query += f" ORDER BY cc.country_name LIMIT ${param_count + 1} OFFSET ${param_count + 2}"
        params.extend([limit, offset])
        
        countries = await conn.fetch(base_query, *params)
        
        # Get risk values for each country
        result = []
        for country in countries:
            risk_query = """
            SELECT ri.id as indicator_id, ri.indicator_name,
                   cra.value_text, cra.value_boolean, cra.value_numeric, cra.value_date, cra.notes
            FROM country_risk_assessments cra
            JOIN risk_indicators ri ON cra.indicator_id = ri.id
            WHERE cra.country_id = $1
            ORDER BY ri.category_id, ri.display_order
            """
            risk_values = await conn.fetch(risk_query, country['id'])
            
            country_data = dict(country)
            country_data['risk_values'] = [dict(rv) for rv in risk_values]
            result.append(country_data)
        
        return result
    finally:
        await conn.close()

@router.get("/countries/{country_id}", response_model=CriticalCountry)
async def get_country_detail(country_id: int):
    """Get detailed information for a specific country"""
    conn = await get_db_connection()
    try:
        # Get country basic info
        country_query = """
        SELECT id, name, abbreviation, iso_code
        FROM critical_countries
        WHERE id = $1
        """
        country = await conn.fetchrow(country_query, country_id)
        
        if not country:
            raise HTTPException(status_code=404, detail="Country not found")
        
        # Get risk assessments
        risk_query = """
        SELECT ri.id as indicator_id, ri.indicator_name,
               cra.value_text, cra.value_boolean, cra.value_numeric, cra.value_date, cra.notes
        FROM country_risk_assessments cra
        JOIN risk_indicators ri ON cra.indicator_id = ri.id
        WHERE cra.country_id = $1
        ORDER BY ri.category_id, ri.display_order
        """
        risk_values = await conn.fetch(risk_query, country_id)
        
        country_data = dict(country)
        country_data['risk_values'] = [dict(rv) for rv in risk_values]
        
        return country_data
    finally:
        await conn.close()

@router.post("/countries", response_model=CriticalCountry)
async def create_country(country: CountryCreateRequest):
    """Create a new critical country"""
    conn = await get_db_connection()
    try:
        query = """
        INSERT INTO critical_countries (name, abbreviation, iso_code)
        VALUES ($1, $2, $3)
        RETURNING id, name, abbreviation, iso_code
        """
        result = await conn.fetchrow(query, country.name, country.abbreviation, country.iso_code)
        
        country_data = dict(result)
        country_data['risk_values'] = []
        
        return country_data
    except asyncpg.UniqueViolationError:
        raise HTTPException(status_code=400, detail="Country with this name or abbreviation already exists")
    finally:
        await conn.close()

@router.put("/countries/{country_id}", response_model=CriticalCountry)
async def update_country(country_id: int, country: CountryUpdateRequest):
    """Update a critical country"""
    conn = await get_db_connection()
    try:
        # Build dynamic update query
        updates = []
        params = []
        param_count = 0
        
        if country.name is not None:
            param_count += 1
            updates.append(f"name = ${param_count}")
            params.append(country.name)
        
        if country.abbreviation is not None:
            param_count += 1
            updates.append(f"abbreviation = ${param_count}");
            params.append(country.abbreviation)
        
        if country.iso_code is not None:
            param_count += 1
            updates.append(f"iso_code = ${param_count}");
            params.append(country.iso_code)
        
        if not updates:
            raise HTTPException(status_code=400, detail="No fields to update")
        
        param_count += 1
        updates.append(f"updated_at = CURRENT_TIMESTAMP");
        params.append(country_id)
        
        query = f"""
        UPDATE critical_countries
        SET {', '.join(updates)}
        WHERE id = ${param_count}
        RETURNING id, name, abbreviation, iso_code
        """
        
        result = await conn.fetchrow(query, *params)
        
        if not result:
            raise HTTPException(status_code=404, detail="Country not found")
        
        # Get updated risk values
        risk_query = """
        SELECT ri.id as indicator_id, ri.indicator_name,
               cra.value_text, cra.value_boolean, cra.value_numeric, cra.value_date, cra.notes
        FROM country_risk_assessments cra
        JOIN risk_indicators ri ON cra.indicator_id = ri.id
        WHERE cra.country_id = $1
        ORDER BY ri.category_id, ri.display_order
        """
        risk_values = await conn.fetch(risk_query, country_id)
        
        country_data = dict(result)
        country_data['risk_values'] = [dict(rv) for rv in risk_values]
        
        return country_data
    finally:
        await conn.close()

@router.delete("/countries/{country_id}")
async def delete_country(country_id: int):
    """Delete a critical country"""
    conn = await get_db_connection()
    try:
        query = """
        DELETE FROM critical_countries
        WHERE id = $1
        """
        result = await conn.execute(query, country_id)
        
        if result == "DELETE 0":
            raise HTTPException(status_code=404, detail="Country not found")
        
        return {"message": "Country deleted successfully"}
    finally:
        await conn.close()

# Risk Assessment endpoints
@router.post("/risk-assessments")
@consume_credits_for_action("end_use_checks", "risk_assessment")
async def create_or_update_risk_assessment(assessment: RiskAssessmentRequest):
    """Create or update a risk assessment for a country"""
    conn = await get_db_connection()
    try:
        query = """
        INSERT INTO country_risk_assessments 
        (country_id, indicator_id, value_text, value_boolean, value_numeric, value_date, notes)
        VALUES ($1, $2, $3, $4, $5, $6, $7)
        ON CONFLICT (country_id, indicator_id)
        DO UPDATE SET
            value_text = EXCLUDED.value_text,
            value_boolean = EXCLUDED.value_boolean,
            value_numeric = EXCLUDED.value_numeric,
            value_date = EXCLUDED.value_date,
            notes = EXCLUDED.notes,
            updated_at = CURRENT_TIMESTAMP
        """
        await conn.execute(
            query,
            assessment.country_id,
            assessment.indicator_id,
            assessment.value_text,
            assessment.value_boolean,
            assessment.value_numeric,
            assessment.value_date,
            assessment.notes
        )
        
        return {"message": "Risk assessment updated successfully"}
    finally:
        await conn.close()

@router.delete("/risk-assessments/{country_id}/{indicator_id}")
async def delete_risk_assessment(country_id: int, indicator_id: int):
    """Delete a specific risk assessment"""
    conn = await get_db_connection()
    try:
        query = """
        DELETE FROM country_risk_assessments
        WHERE country_id = $1 AND indicator_id = $2
        """
        result = await conn.execute(query, country_id, indicator_id)
        
        if result == "DELETE 0":
            raise HTTPException(status_code=404, detail="Risk assessment not found")
        
        return {"message": "Risk assessment deleted successfully"}
    finally:
        await conn.close()

# Search and filter endpoints
@router.post("/countries/search", response_model=List[CriticalCountry])
@consume_credits_for_action("end_use_checks", "country_search")
async def search_critical_countries(filters: CountrySearchFilters):
    """Advanced search for countries with risk-based filtering"""
    conn = await get_db_connection()
    try:
        # Build complex query based on filters
        base_query = """
        SELECT DISTINCT cc.id, cc.name, cc.abbreviation, cc.iso_code
        FROM critical_countries cc
        LEFT JOIN country_risk_assessments cra ON cc.id = cra.country_id
        LEFT JOIN risk_indicators ri ON cra.indicator_id = ri.id
        LEFT JOIN risk_categories rc ON ri.category_id = rc.id
        """
        
        conditions = []
        params = []
        param_count = 0
        
        if filters.search_term:
            param_count += 1
            conditions.append(f"(cc.name ILIKE ${param_count} OR cc.abbreviation ILIKE ${param_count})")
            params.append(f"%{filters.search_term}%")
        
        if filters.risk_categories:
            param_count += 1
            conditions.append(f"rc.category_name = ANY(${param_count})")
            params.append(filters.risk_categories)
        
        if filters.has_arms_embargo is not None:
            if filters.has_arms_embargo:
                conditions.append("""
                EXISTS (
                    SELECT 1 FROM country_risk_assessments cra2
                    JOIN risk_indicators ri2 ON cra2.indicator_id = ri2.id
                    JOIN risk_categories rc2 ON ri2.category_id = rc2.id
                    WHERE cra2.country_id = cc.id 
                    AND rc2.category_name = 'Arms Embargo'
                    AND cra2.value_text IS NOT NULL
                    AND cra2.value_text != ''
                )
                """)
        
        if filters.freedom_score_min is not None or filters.freedom_score_max is not None:
            freedom_conditions = []
            if filters.freedom_score_min is not None:
                param_count += 1
                freedom_conditions.append(f"cra.value_numeric >= ${param_count}")
                params.append(filters.freedom_score_min)
            if filters.freedom_score_max is not None:
                param_count += 1
                freedom_conditions.append(f"cra.value_numeric <= ${param_count}")
                params.append(filters.freedom_score_max)
            
            if freedom_conditions:
                conditions.append(f"""
                EXISTS (
                    SELECT 1 FROM country_risk_assessments cra3
                    JOIN risk_indicators ri3 ON cra3.indicator_id = ri3.id
                    WHERE cra3.country_id = cc.id 
                    AND ri3.indicator_name = 'Freedom House Score'
                    AND {' AND '.join(freedom_conditions)}
                )
                """)
        
        if conditions:
            base_query += " WHERE " + " AND ".join(conditions)
        
        base_query += " ORDER BY cc.name"
        
        countries = await conn.fetch(base_query, *params)
        
        # Get risk values for each country
        result = []
        for country in countries:
            risk_query = """
            SELECT ri.id as indicator_id, ri.indicator_name,
                   cra.value_text, cra.value_boolean, cra.value_numeric, cra.value_date, cra.notes
            FROM country_risk_assessments cra
            JOIN risk_indicators ri ON cra.indicator_id = ri.id
            WHERE cra.country_id = $1
            ORDER BY ri.category_id, ri.display_order
            """
            risk_values = await conn.fetch(risk_query, country['id'])
            
            country_data = dict(country)
            country_data['risk_values'] = [dict(rv) for rv in risk_values]
            result.append(country_data)
        
        return result
    finally:
        await conn.close()

# Statistics endpoint
@router.get("/stats")
async def get_critical_countries_stats():
    """Get statistics about critical countries data"""
    conn = await get_db_connection()
    try:
        stats_query = """
        SELECT 
            (SELECT COUNT(*) FROM critical_countries) as total_countries,
            (SELECT COUNT(*) FROM risk_categories) as total_categories,
            (SELECT COUNT(*) FROM risk_indicators) as total_indicators,
            (SELECT COUNT(*) FROM country_risk_assessments) as total_assessments
        """
        stats = await conn.fetchrow(stats_query)
        
        # Get category breakdown
        category_query = """
        SELECT rc.category_name, COUNT(DISTINCT cra.country_id) as country_count
        FROM risk_categories rc
        LEFT JOIN risk_indicators ri ON rc.id = ri.category_id
        LEFT JOIN country_risk_assessments cra ON ri.id = cra.indicator_id
        GROUP BY rc.id, rc.category_name
        ORDER BY rc.display_order
        """
        categories = await conn.fetch(category_query)
        
        return {
            "overview": dict(stats),
            "categories": [dict(cat) for cat in categories]
        }
    finally:
        await conn.close()

@router.post("/critical-countries/bulk-upload")
@consume_credits_for_action("end_use_checks", "bulk_upload")
async def bulk_upload_critical_countries(file: UploadFile = _FILE_DEPENDENCY):
    """Bulk upload critical countries from Excel file"""
    if not file.filename.endswith(('.xlsx', '.xls')):
        raise HTTPException(status_code=400, detail="File must be an Excel file (.xlsx or .xls)")
    
    try:
        # Read file content
        content = await file.read()
        
        # Parse Excel file
        import pandas as pd
        import io
        
        df = pd.read_excel(io.BytesIO(content))
        
        # Connect to database
        conn = await get_db_connection()
        
        success_count = 0
        error_count = 0
        errors = []
        
        print(f"📊 Processing {len(df)} rows from uploaded file")
        print(f"Columns found: {list(df.columns)}")
        
        # Define the field mapping from Excel columns to database columns
        field_mapping = {
            "Country Name": "country_name",
            "Abbreviation": "abbreviation",
            "ISO Code": "iso_code",
            "Is Active": "is_active",
            "Risk Level": "risk_level",
            "Risk Categories": "risk_categories",
            "Risk Description": "risk_description",
            "Last Risk Assessment Date": "last_risk_assessment_date",
            "Export Control Regime: Wassenaar Arrangement": "export_control_wassenaar",
            "Export Control Regime: Nuclear Suppliers Group (NSG)": "export_control_nsg",
            "Export Control Regime: Australia Group (AG)": "export_control_ag",
            "Export Control Regime:Missile Technology Control Regime (MTCR)": "export_control_mtcr",
            "Export Control Regime:Zangger Committee (ZC)": "export_control_zc",
            "Export Control Regimes Notes": "export_control_notes",
            "Export Control Regimes: Risk": "export_control_risk",
            # Skip "Unnamed: 15" column as it doesn't exist in database
            "Sanctions": "sanctions",
            "Sanctions Notes": "sanctions_notes",
            "Sanctions: Risk": "sanctions_risk",
            "UN Arms Embargo": "un_arms_embargo",
            "UN Arms Embargo Notes": "un_arms_embargo_notes",
            "US Arms Embargo": "us_arms_embargo",
            "US Arms Embargo Notes": "us_arms_embargo_notes",
            "EU Arms Embargo": "eu_arms_embargo",
            "EU Arms Embargo Notes": "eu_arms_embargo_notes",
            "Other Arms Embargo": "other_arms_embargo",
            "Other Arms Embargo Notes": "other_arms_embargo_notes",
            "Arms Risk": "arms_risk",
            "CWC 1993 Signatory": "cwc_1993_signatory",
            "CWC 1993 Ratified": "cwc_1993_ratified",
            "CWC Violations": "cwc_violations",
            "Chemical Risk": "chemical_risk",
            "BWC 1972 Signatory": "bwc_1972_signatory",
            "BWC 1972 Ratified": "bwc_1972_ratified",
            "BWC Violations": "bwc_violations",
            "Biological Risk": "biological_risk",
            "NPT Signatory": "npt_signatory",
            "NPT Ratified": "npt_ratified",
            "NPT Notes": "npt_notes",
            "CTBT Signatory": "ctbt_signatory",
            "CTBT Ratified": "ctbt_ratified",
            "CTBT Notes": "ctbt_notes",
            "IAEA Signatory": "iaea_signatory",
            "IAEA Ratified": "iaea_ratified",
            "IAEA Notes": "iaea_notes",
            "NSG 1974 Signatory": "nsg_1974_signatory",
            "NSG 1974 Ratified": "nsg_1974_ratified",
            "NSG Notes": "nsg_notes",
            "Conv 1980 Signatory": "conv_1980_signatory",
            "Conv 1980 Ratified": "conv_1980_ratified",
            "Conv 1980 Notes": "conv_1980_notes",
            "Conv 1994 Signatory": "conv_1994_signatory",
            "Conv 1994 Ratified": "conv_1994_ratified",
            "Conv 1994 Notes": "conv_1994_notes",
            "Nuclear Violations": "nuclear_violations",
            "Nuclear Risk": "nuclear_risk",
            "Human Rights": "human_rights",
            "Human Rights Note ": "human_rights_note",
            "Human Rights Risk Score": "human_rights_risk_score",
            "Political Rights ": "political_rights",
            "Civil Liberties": "civil_liberties",
            "Freedom in the World": "freedom_in_the_world",
            "Freedom Note": "freedom_note",
            "Freedom Risk": "freedom_risk",
            "Obstacles to Access": "obstacles_to_access",
            "Limits on Content": "limits_on_content",
            "Violations of User Rights": "violations_of_user_rights",
            "Freedom Net Note": "freedom_net_note",
            "Freedom Net Risk": "freedom_net_risk",
            "Democracy Status": "democracy_status",
            "Democracy Percentage": "democracy_percentage",
            "Nations in Transit": "nations_in_transit",
            "Regime Type": "regime_type",
            "Human Rights Freedoms Risk": "human_rights_freedoms_risk"
        }
        
        # Helper function to convert Excel values to appropriate types
        def process_value(value, field_type="text"):
            if pd.isna(value) or value == "":
                return None
            
            if field_type == "boolean":
                if isinstance(value, bool):
                    return value
                if isinstance(value, str):
                    return value.upper() in ['TRUE', 'YES', '1', 'Y']
                return bool(value)
            elif field_type == "integer":
                try:
                    return int(float(value))
                except (ValueError, TypeError):
                    return None
            elif field_type == "date":
                # Handle date conversion for last_risk_assessment_date
                try:
                    if isinstance(value, datetime):
                        return value.date()  # Return date object, not string
                    elif isinstance(value, str):
                        # Try to parse various date formats
                        try:
                            parsed_date = datetime.strptime(value, '%Y-%m-%d')
                            return parsed_date.date()
                        except ValueError:
                            try:
                                parsed_date = datetime.strptime(value, '%m/%d/%Y')
                                return parsed_date.date()
                            except ValueError:
                                return None
                    else:
                        return None
                except Exception:
                    return None
            elif field_type == "json":
                if isinstance(value, dict):
                    import json
                    return json.dumps(value)  # Convert dict to JSON string
                elif isinstance(value, str):
                    try:
                        import json
                        # Validate it's valid JSON, then return as string
                        json.loads(value)
                        return value
                    except json.JSONDecodeError:
                        return None
                return None
            else:
                return str(value).strip() if value else None
        
        # Process each row
        for row_idx, row in df.iterrows():
            try:
                # Skip empty rows
                if pd.isna(row.get('Country Name')) or row.get('Country Name') == '':
                    continue
                
                print(f"🔄 Processing row {row_idx + 1}: {row.get('Country Name', 'Unknown')}")
                
                # Build the data dictionary
                country_data = {}
                
                # Map each field with appropriate type conversion
                boolean_fields = [
                    'is_active', 'export_control_wassenaar', 'export_control_nsg', 'export_control_ag',
                    'export_control_mtcr', 'export_control_zc', 'sanctions', 'un_arms_embargo',
                    'us_arms_embargo', 'eu_arms_embargo', 'other_arms_embargo', 'cwc_1993_signatory',
                    'cwc_1993_ratified', 'cwc_violations', 'bwc_1972_signatory', 'bwc_1972_ratified',
                    'bwc_violations', 'npt_signatory', 'npt_ratified', 'ctbt_signatory', 'ctbt_ratified',
                    'iaea_signatory', 'iaea_ratified', 'nsg_1974_signatory', 'nsg_1974_ratified',
                    'conv_1980_signatory', 'conv_1980_ratified', 'conv_1994_signatory', 'conv_1994_ratified',
                    'nuclear_violations', 'freedom_in_the_world'
                ]
                
                integer_fields = ['human_rights_risk_score']
                json_fields = ['risk_categories']
                date_fields = ['last_risk_assessment_date']
                
                for excel_col, db_col in field_mapping.items():
                    if excel_col in row:
                        value = row[excel_col]
                        
                        if db_col in boolean_fields:
                            country_data[db_col] = process_value(value, "boolean")
                        elif db_col in integer_fields:
                            country_data[db_col] = process_value(value, "integer")
                        elif db_col in date_fields:
                            country_data[db_col] = process_value(value, "date")
                        elif db_col in json_fields:
                            country_data[db_col] = process_value(value, "json")
                        else:
                            country_data[db_col] = process_value(value, "text")
                
                # Ensure required fields
                if not country_data.get('country_name'):
                    raise ValueError(f"Country name is required")
                
                # Check if country already exists
                existing_query = """
                    SELECT id FROM critical_countries 
                    WHERE LOWER(country_name) = LOWER($1) OR LOWER(iso_code) = LOWER($2)
                """
                existing = await conn.fetchrow(existing_query, 
                                             country_data['country_name'], 
                                             country_data.get('iso_code'))
                
                if existing:
                    # Update existing country
                    set_clauses = []
                    values = []
                    param_count = 1
                    
                    for field, value in country_data.items():
                        if field != 'country_name':  # Don't update the name
                            set_clauses.append(f"{field} = ${param_count}")
                            values.append(value)
                            param_count += 1
                    
                    if set_clauses:
                        set_clauses.append(f"updated_at = ${param_count}")
                        values.append(datetime.now())
                        param_count += 1
                        
                        values.append(existing['id'])
                        
                        update_query = f"""
                            UPDATE critical_countries 
                            SET {', '.join(set_clauses)}
                            WHERE id = ${param_count}
                        """
                        
                        await conn.execute(update_query, *values)
                        print(f"✅ Updated: {country_data['country_name']}")
                else:
                    # Insert new country
                    fields = list(country_data.keys())
                    placeholders = [f"${i+1}" for i in range(len(fields))]
                    
                    insert_query = f"""
                        INSERT INTO critical_countries ({', '.join(fields)}, created_at, updated_at)
                        VALUES ({', '.join(placeholders)}, ${len(fields)+1}, ${len(fields)+2})
                    """
                    
                    values = list(country_data.values()) + [datetime.now(), datetime.now()]
                    await conn.execute(insert_query, *values)
                    print(f"✅ Inserted: {country_data['country_name']}")
                
                success_count += 1
                
            except Exception as row_error:
                error_count += 1
                error_msg = f"Row {row_idx + 1}: {str(row_error)}"
                errors.append(error_msg)
                print(f"❌ Error processing row {row_idx + 1}: {row_error}")
        
        message = f"Upload completed: {success_count} countries processed successfully"
        if error_count > 0:
            message += f", {error_count} rows failed"
        
        print(f"✅ {message}")
        return BulkUploadResponse(
            success_count=success_count,
            error_count=error_count,
            message=message,
            errors=errors[:10]  # Limit to first 10 errors
        )
        
    except Exception as e:
        print(f"❌ Error during bulk upload: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to upload data: {str(e)}")
    finally:
        await conn.close()

@router.get("/critical-countries/download-template")
async def download_critical_countries_template():
    """Download Excel template for critical countries bulk upload"""
    try:
        from openpyxl import Workbook
        from openpyxl.styles import Font, PatternFill, Alignment
        from openpyxl.utils import get_column_letter
        from fastapi.responses import Response
        import io
        
        # Create workbook with two sheets
        wb = Workbook()
        ws = wb.active
        ws.title = "Critical Countries Template"
        
        # Define all 74 column headers exactly as in your finalized template
        headers = [
            "Country Name",
            "Abbreviation",
            "ISO Code",
            "Is Active",
            "Risk Level",
            "Risk Categories",
            "Risk Description",
            "Last Risk Assessment Date",
            "Export Control Regime: Wassenaar Arrangement",
            "Export Control Regime: Nuclear Suppliers Group (NSG)",
            "Export Control Regime: Australia Group (AG)",
            "Export Control Regime:Missile Technology Control Regime (MTCR)",
            "Export Control Regime:Zangger Committee (ZC)",
            "Export Control Regimes Notes",
            "Export Control Regimes: Risk",
            "Unnamed: 15",  # This appears to be an empty column in your template
            "Sanctions",
            "Sanctions Notes",
            "Sanctions: Risk",
            "UN Arms Embargo",
            "UN Arms Embargo Notes",
            "US Arms Embargo",
            "US Arms Embargo Notes",
            "EU Arms Embargo",
            "EU Arms Embargo Notes",
            "Other Arms Embargo",
            "Other Arms Embargo Notes",
            "Arms Risk",
            "CWC 1993 Signatory",
            "CWC 1993 Ratified",
            "CWC Violations",
            "Chemical Risk",
            "BWC 1972 Signatory",
            "BWC 1972 Ratified",
            "BWC Violations",
            "Biological Risk",
            "NPT Signatory",
            "NPT Ratified",
            "NPT Notes",
            "CTBT Signatory",
            "CTBT Ratified",
            "CTBT Notes",
            "IAEA Signatory",
            "IAEA Ratified",
            "IAEA Notes",
            "NSG 1974 Signatory",
            "NSG 1974 Ratified",
            "NSG Notes",
            "Conv 1980 Signatory",
            "Conv 1980 Ratified",
            "Conv 1980 Notes",
            "Conv 1994 Signatory",
            "Conv 1994 Ratified",
            "Conv 1994 Notes",
            "Nuclear Violations",
            "Nuclear Risk",
            "Human Rights",
            "Human Rights Note ",
            "Human Rights Risk Score",
            "Political Rights ",
            "Civil Liberties",
            "Freedom in the World",
            "Freedom Note",
            "Freedom Risk",
            "Obstacles to Access",
            "Limits on Content",
            "Violations of User Rights",
            "Freedom Net Note",
            "Freedom Net Risk",
            "Democracy Status",
            "Democracy Percentage",
            "Nations in Transit",
            "Regime Type",
            "Human Rights Freedoms Risk"
        ]
        
        # Add headers to the first row
        for col_idx, header in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col_idx)
            cell.value = header
            cell.font = Font(bold=True, color="FFFFFF")
            cell.fill = PatternFill(start_color="366092", end_color="366092", fill_type="solid")
            cell.alignment = Alignment(horizontal="center", vertical="center")
        
        # Add sample data rows based on your template
        sample_data = [
            [
                "Iran", "IR", "IRN", True, "Critical", 
                '{"proliferation": true, "terrorism": true}',
                "High proliferation risk with nuclear ambitions", "2024-01-15",
                None, None, None, None, None, None, "Critical", None,  # Export control regimes
                True, "Comprehensive sanctions", "Critical",  # Sanctions
                True, "UN embargo active", True, "Comprehensive sanctions since 1979", 
                True, "EU sanctions active", False, None, "Critical",  # Arms embargoes
                True, True, False, "Medium",  # Chemical weapons
                True, True, False, "Low",  # Biological weapons
                True, True, "Withdrew from JCPOA", False, False, "Not signed",
                True, True, "IAEA member", False, False, "Not member",
                True, True, "Member since 1980", True, True, "Member since 1994",
                True, "High",  # Nuclear violations and risk
                "Poor", "Severe human rights violations", 15, "Not Free", "Not Free",
                False, "Severe restrictions on freedoms", "Critical",  # Human rights
                "Blocked", "Pervasive", "Extensive", "Severe internet restrictions", "Critical",  # Internet freedom
                "Closed Autocracy", "16%", "Consolidated Authoritarian Regime", "Authoritarian", "Critical"  # Democracy
            ],
            [
                "Germany", "DE", "DEU", True, "Low",
                '{"proliferation": false, "terrorism": false}',
                "Low risk democratic ally", "2024-03-20",
                True, True, True, True, True, "Member of all major regimes", "Low", None,  # Export control regimes
                False, None, "Low",  # Sanctions
                False, None, False, None, False, None, False, None, "Low",  # Arms embargoes
                True, True, False, "Low",  # Chemical weapons
                True, True, False, "Low",  # Biological weapons
                True, True, "NPT member", True, True, "CTBT signed",
                True, True, "IAEA founding member", True, True, "NSG founding member",
                True, True, "Convention member", True, True, "Convention member",
                False, "Low",  # Nuclear violations and risk
                "Excellent", "Strong human rights record", 94, "Free", "Free",
                True, "Excellent freedom record", "Low",  # Human rights
                "Open", "Minimal", "Rare", "Free internet access", "Low",  # Internet freedom
                "Liberal Democracy", "89%", "Consolidated Democracy", "Democratic", "Low"  # Democracy
            ]
        ]
        
        # Add sample data
        for row_idx, row_data in enumerate(sample_data, 2):
            for col_idx, value in enumerate(row_data, 1):
                ws.cell(row=row_idx, column=col_idx, value=value)
        
        # Auto-adjust column widths
        for col_idx in range(1, len(headers) + 1):
            column_letter = get_column_letter(col_idx)
            ws.column_dimensions[column_letter].width = 20
        
        # Create Instructions sheet
        instructions_ws = wb.create_sheet("Instructions")
        instructions_ws.cell(row=1, column=1, value="Critical Countries Template Instructions")
        instructions_ws.cell(row=1, column=1).font = Font(bold=True, size=16)
        
        instructions = [
            "",
            "GENERAL INSTRUCTIONS:",
            "• Fill in all 74 columns as specified in the template",
            "• Country Name is required for each row",
            "• Boolean fields should use TRUE/FALSE or YES/NO",
            "• Risk Categories should be in JSON format: {\"field\": true/false}",
            "• Dates should be in YYYY-MM-DD format",
            "",
            "FIELD DESCRIPTIONS:",
            "• Country Name: Official country name",
            "• Abbreviation: 2-letter country code",
            "• ISO Code: 3-letter ISO country code",
            "• Risk Level: Critical, High, Medium, Low",
            "• Export Control Regimes: TRUE if country is member",
            "• Sanctions: TRUE if country has active sanctions",
            "• Arms Embargoes: TRUE if embargo is active",
            "• Chemical/Biological Weapons: Treaty status and violations",
            "• Nuclear Treaties: Signatory and ratification status",
            "• Human Rights: Freedom ratings and democracy indicators",
            "",
            "RISK CATEGORIES:",
            "• Critical: Highest risk countries",
            "• High: Elevated risk requiring careful review",
            "• Medium: Moderate risk with some concerns",
            "• Low: Minimal risk, trusted partners"
        ]
        
        for row_idx, instruction in enumerate(instructions, 2):
            instructions_ws.cell(row=row_idx, column=1, value=instruction)
        
        # Create BytesIO object and save workbook
        output = io.BytesIO()
        wb.save(output)
        output.seek(0)
        
        # Return as direct response
        return Response(
            content=output.read(),
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers={"Content-Disposition": "attachment; filename=critical_countries_template.xlsx"}
        )
        
    except Exception as e:
        print(f"❌ Error generating template: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to generate template: {str(e)}")

@router.get("/critical-countries")
async def get_critical_countries_list(
    limit: int = 50,
    offset: int = 0,
    search: str | None = None,
    risk_level: str | None = None,
    is_active: bool | None = None,
    has_sanctions: bool | None = None,
    export_control_member: bool | None = None
):
    """List critical countries with filtering and pagination"""
    conn = await get_db_connection()
    
    try:
        # Build WHERE conditions
        where_conditions = []
        params = []
        param_count = 1
        
        if search:
            where_conditions.append(f"(LOWER(country_name) LIKE LOWER(${param_count}) OR LOWER(iso_code) LIKE LOWER(${param_count}))")
            params.append(f"%{search}%")
            param_count += 1
            
        if risk_level:
            where_conditions.append(f"risk_level = ${param_count}")
            params.append(risk_level)
            param_count += 1
            
        if is_active is not None:
            where_conditions.append(f"is_active = ${param_count}")
            params.append(is_active)
            param_count += 1
            
        if has_sanctions is not None:
            where_conditions.append(f"sanctions = ${param_count}")
            params.append(has_sanctions)
            param_count += 1
            
        if export_control_member is not None:
            where_conditions.append(f"(export_control_wassenaar = ${param_count} OR export_control_nsg = ${param_count} OR export_control_ag = ${param_count} OR export_control_mtcr = ${param_count} OR export_control_zc = ${param_count})")
            params.append(export_control_member)
            param_count += 1
        
        where_clause = "WHERE " + " AND ".join(where_conditions) if where_conditions else ""
        
        # Get total count
        count_query = f"SELECT COUNT(*) as total FROM critical_countries {where_clause}"
        total_result = await conn.fetchrow(count_query, *params)
        total = total_result['total']
        
        # Get countries data with all fields
        query = f"""
            SELECT 
                id, country_name, abbreviation, iso_code, is_active,
                risk_level, risk_categories, risk_description, last_risk_assessment_date,
                export_control_wassenaar, export_control_nsg, export_control_ag, 
                export_control_mtcr, export_control_zc, export_control_notes, export_control_risk,
                sanctions, sanctions_notes, sanctions_risk,
                un_arms_embargo, un_arms_embargo_notes, us_arms_embargo, us_arms_embargo_notes,
                eu_arms_embargo, eu_arms_embargo_notes, other_arms_embargo, other_arms_embargo_notes, arms_risk,
                cwc_1993_signatory, cwc_1993_ratified, cwc_violations, chemical_risk,
                bwc_1972_signatory, bwc_1972_ratified, bwc_violations, biological_risk,
                npt_signatory, npt_ratified, npt_notes, ctbt_signatory, ctbt_ratified, ctbt_notes,
                iaea_signatory, iaea_ratified, iaea_notes, nsg_1974_signatory, nsg_1974_ratified, nsg_notes,
                conv_1980_signatory, conv_1980_ratified, conv_1980_notes, conv_1994_signatory, conv_1994_ratified, conv_1994_notes,
                nuclear_violations, nuclear_risk,
                human_rights, human_rights_note, human_rights_risk_score, political_rights, civil_liberties,
                freedom_in_the_world, freedom_note, freedom_risk,
                obstacles_to_access, limits_on_content, violations_of_user_rights, freedom_net_note, freedom_net_risk,
                democracy_status, democracy_percentage, nations_in_transit, regime_type, human_rights_freedoms_risk,
                created_at, updated_at, created_by, updated_by, notes
            FROM critical_countries 
            {where_clause}
            ORDER BY country_name
            LIMIT ${param_count} OFFSET ${param_count + 1}
        """
        
        params.extend([limit, offset])
        countries = await conn.fetch(query, *params)
        
        # Convert to list of dictionaries
        countries_list = []
        for country in countries:
            country_dict = dict(country)
            
            # Convert dates to strings
            if country_dict.get('last_risk_assessment_date'):
                country_dict['last_risk_assessment_date'] = country_dict['last_risk_assessment_date'].strftime('%Y-%m-%d')
            if country_dict.get('created_at'):
                country_dict['created_at'] = country_dict['created_at'].isoformat()
            if country_dict.get('updated_at'):
                country_dict['updated_at'] = country_dict['updated_at'].isoformat()
                
            countries_list.append(country_dict)
        
        print(f"📊 Retrieved {len(countries_list)} countries (total: {total})")
        
        return {
            "countries": countries_list,
            "total": total,
            "limit": limit,
            "offset": offset,
            "has_more": offset + len(countries_list) < total
        }
        
    except Exception as e:
        print(f"❌ Error listing countries: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to retrieve countries: {str(e)}")
    finally:
        await conn.close()
