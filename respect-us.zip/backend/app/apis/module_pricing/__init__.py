from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import List, Optional
import asyncpg
import databutton as db
from app.auth import AuthorizedUser
from app.env import Mode, mode

router = APIRouter(prefix="/module-pricing")

# Pydantic models
class ModulePricingConfig(BaseModel):
    id: Optional[int] = None
    module_name: str
    module_title: str
    pricing_type: str  # "credits" or "eur"
    credit_cost: Optional[int] = None
    price_eur: Optional[float] = None
    is_active: bool = True
    description: Optional[str] = None

class ModulePricingUpdate(BaseModel):
    pricing_type: Optional[str] = None
    credit_cost: Optional[int] = None
    price_eur: Optional[float] = None
    is_active: Optional[bool] = None
    description: Optional[str] = None

class ModulePricingCreate(BaseModel):
    module_name: str
    module_title: str
    pricing_type: str
    credit_cost: Optional[int] = None
    price_eur: Optional[float] = None
    description: Optional[str] = None

# Database connection
async def get_db_connection():
    """Get database connection based on environment"""
    if mode == Mode.PROD:
        database_url = db.secrets.get("DATABASE_URL_PROD")
    else:
        database_url = db.secrets.get("DATABASE_URL_DEV")
    return await asyncpg.connect(database_url)

@router.get("/configurations", response_model=List[ModulePricingConfig])
async def get_module_pricing_configurations(user: AuthorizedUser):
    """Get all module pricing configurations"""
    conn = await get_db_connection()
    try:
        query = """
            SELECT id, module_name, module_title, pricing_type, credit_cost, 
                   price_eur, is_active, description, created_at, updated_at
            FROM module_pricing_config 
            ORDER BY module_name
        """
        
        rows = await conn.fetch(query)
        
        return [
            ModulePricingConfig(
                id=row['id'],
                module_name=row['module_name'],
                module_title=row['module_title'],
                pricing_type=row['pricing_type'],
                credit_cost=row['credit_cost'],
                price_eur=row['price_eur'],
                is_active=row['is_active'],
                description=row['description']
            ) for row in rows
        ]
        
    finally:
        await conn.close()

@router.post("/configurations", response_model=ModulePricingConfig)
async def create_module_pricing_configuration(request: ModulePricingCreate, user: AuthorizedUser):
    """Create new module pricing configuration"""
    conn = await get_db_connection()
    try:
        # Check if module already exists
        existing = await conn.fetchrow(
            "SELECT id FROM module_pricing_config WHERE module_name = $1",
            request.module_name
        )
        
        if existing:
            raise HTTPException(status_code=400, detail="Module pricing configuration already exists")
        
        # Create new configuration
        query = """
            INSERT INTO module_pricing_config 
            (module_name, module_title, pricing_type, credit_cost, price_eur, description, is_active, created_at, updated_at)
            VALUES ($1, $2, $3, $4, $5, $6, true, NOW(), NOW())
            RETURNING id, module_name, module_title, pricing_type, credit_cost, price_eur, is_active, description
        """
        
        row = await conn.fetchrow(
            query,
            request.module_name,
            request.module_title,
            request.pricing_type,
            request.credit_cost,
            request.price_eur,
            request.description
        )
        
        return ModulePricingConfig(
            id=row['id'],
            module_name=row['module_name'],
            module_title=row['module_title'],
            pricing_type=row['pricing_type'],
            credit_cost=row['credit_cost'],
            price_eur=row['price_eur'],
            is_active=row['is_active'],
            description=row['description']
        )
        
    finally:
        await conn.close()

@router.put("/configurations/{module_name}", response_model=ModulePricingConfig)
async def update_module_pricing_configuration(module_name: str, request: ModulePricingUpdate, user: AuthorizedUser):
    """Update module pricing configuration"""
    conn = await get_db_connection()
    try:
        # Check if module exists
        existing = await conn.fetchrow(
            "SELECT id FROM module_pricing_config WHERE module_name = $1",
            module_name
        )
        
        if not existing:
            raise HTTPException(status_code=404, detail="Module pricing configuration not found")
        
        # Build update query dynamically
        update_fields = []
        params = []
        param_count = 0
        
        if request.pricing_type is not None:
            param_count += 1
            update_fields.append(f"pricing_type = ${param_count}")
            params.append(request.pricing_type)
            
        if request.credit_cost is not None:
            param_count += 1
            update_fields.append(f"credit_cost = ${param_count}")
            params.append(request.credit_cost)
            
        if request.price_eur is not None:
            param_count += 1
            update_fields.append(f"price_eur = ${param_count}")
            params.append(request.price_eur)
            
        if request.is_active is not None:
            param_count += 1
            update_fields.append(f"is_active = ${param_count}")
            params.append(request.is_active)
            
        if request.description is not None:
            param_count += 1
            update_fields.append(f"description = ${param_count}")
            params.append(request.description)
        
        if not update_fields:
            raise HTTPException(status_code=400, detail="No fields to update")
        
        # Add updated_at
        param_count += 1
        update_fields.append(f"updated_at = NOW()")
        
        # Add module_name for WHERE clause
        param_count += 1
        params.append(module_name)
        
        query = f"""
            UPDATE module_pricing_config 
            SET {', '.join(update_fields)}
            WHERE module_name = ${param_count}
            RETURNING id, module_name, module_title, pricing_type, credit_cost, price_eur, is_active, description
        """
        
        row = await conn.fetchrow(query, *params)
        
        return ModulePricingConfig(
            id=row['id'],
            module_name=row['module_name'],
            module_title=row['module_title'],
            pricing_type=row['pricing_type'],
            credit_cost=row['credit_cost'],
            price_eur=row['price_eur'],
            is_active=row['is_active'],
            description=row['description']
        )
        
    finally:
        await conn.close()

@router.delete("/configurations/{module_name}")
async def delete_module_pricing_configuration(module_name: str, user: AuthorizedUser):
    """Delete module pricing configuration"""
    conn = await get_db_connection()
    try:
        result = await conn.execute(
            "DELETE FROM module_pricing_config WHERE module_name = $1",
            module_name
        )
        
        if result == "DELETE 0":
            raise HTTPException(status_code=404, detail="Module pricing configuration not found")
        
        return {"success": True, "message": "Module pricing configuration deleted successfully"}
        
    finally:
        await conn.close()

@router.get("/configuration/{module_name}", response_model=ModulePricingConfig)
async def get_module_pricing_configuration(module_name: str, user: AuthorizedUser):
    """Get specific module pricing configuration"""
    conn = await get_db_connection()
    try:
        query = """
            SELECT id, module_name, module_title, pricing_type, credit_cost, 
                   price_eur, is_active, description
            FROM module_pricing_config 
            WHERE module_name = $1
        """
        
        row = await conn.fetchrow(query, module_name)
        
        if not row:
            raise HTTPException(status_code=404, detail="Module pricing configuration not found")
        
        return ModulePricingConfig(
            id=row['id'],
            module_name=row['module_name'],
            module_title=row['module_title'],
            pricing_type=row['pricing_type'],
            credit_cost=row['credit_cost'],
            price_eur=row['price_eur'],
            is_active=row['is_active'],
            description=row['description']
        )
        
    finally:
        await conn.close()
