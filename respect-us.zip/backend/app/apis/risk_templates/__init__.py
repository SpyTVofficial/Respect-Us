
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import List, Optional, Any, Dict
from app.auth import AuthorizedUser
import asyncpg
import databutton as db
import json
from datetime import datetime
from app.env import Mode, mode

router = APIRouter()

# Access control middleware
async def check_risk_assessment_access(user: AuthorizedUser) -> bool:
    """Check if user has access to Risk Assessment module (credit-based)"""
    # Risk Assessment is now credit-based - access is controlled per action
    # Users can access the module but will need credits for specific actions
    return True

# Database connection
async def get_db_connection():
    """Get database connection based on environment"""
    if mode == Mode.PROD:
        database_url = db.secrets.get("DATABASE_URL_PROD")
    else:
        database_url = db.secrets.get("DATABASE_URL_DEV")
    return await asyncpg.connect(database_url)

# Pydantic models
class QuestionModel(BaseModel):
    text: str
    type: str  # text, textarea, select, radio, checkbox, multiselect, rating
    required: bool = True
    options: Optional[List[str]] = []
    information: Optional[str] = None  # Help text/explanation for the question
    notes_enabled: Optional[bool] = False  # Whether this question supports notes

class SectionModel(BaseModel):
    title: str
    information: Optional[str] = None  # Explanatory text for the section
    questions: List[QuestionModel]
    strengths_enabled: Optional[bool] = True  # Whether to show strengths field
    weaknesses_enabled: Optional[bool] = True  # Whether to show weaknesses field

class CreateTemplateRequest(BaseModel):
    title: str
    description: str
    how_it_works: Optional[str] = None
    sections: List[SectionModel]

class UpdateTemplateRequest(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    how_it_works: Optional[str] = None
    sections: Optional[List[SectionModel]] = None
    status: Optional[str] = None

class TemplateResponse(BaseModel):
    id: int
    title: str
    description: str
    how_it_works: Optional[str] = None
    sections: List[Dict[str, Any]]
    status: str
    created_at: str
    updated_at: str
    created_by: str

class TemplatesListResponse(BaseModel):
    templates: List[TemplateResponse]
    total: int

class CustomizeTemplateRequest(BaseModel):
    template_id: int
    company_name: str
    customizations: Dict[str, Any]  # Store section/question modifications

class CompanyFormResponse(BaseModel):
    id: int
    template_id: int
    company_name: str
    customizations: Dict[str, Any]
    created_at: str
    user_id: str

@router.post("/templates/create")
async def create_template(body: CreateTemplateRequest, user: AuthorizedUser) -> Dict[str, Any]:
    """Create a new risk assessment template (Admin only)"""
    try:
        conn = await get_db_connection()
        
        # Process sections and set default options for rating questions
        processed_sections = []
        for section in body.sections:
            processed_questions = []
            for question in section.questions:
                question_dict = question.dict()
                # Auto-set rating options with colors
                if question.type == 'rating':
                    question_dict['options'] = [
                        'Strong', 'Adequate', 'Weak', 'Not present', 'Not applicable', 'I do not know'
                    ]
                processed_questions.append(question_dict)
            
            section_dict = section.dict()
            section_dict['questions'] = processed_questions
            processed_sections.append(section_dict)
        
        # Insert template
        query = """
            INSERT INTO risk_assessment_templates 
            (title, description, how_it_works, sections, status, created_by, created_at, updated_at)
            VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
            RETURNING id
        """
        
        now = datetime.utcnow()
        template_id = await conn.fetchval(
            query, 
            body.title, 
            body.description, 
            body.how_it_works,
            json.dumps(processed_sections), 
            'active', 
            user.sub, 
            now, 
            now
        )
        
        await conn.close()
        
        return {
            "success": True,
            "template_id": template_id,
            "message": "Template created successfully"
        }
        
    except Exception as e:
        print(f"Error creating template: {e}")
        raise HTTPException(status_code=500, detail="Failed to create template")

@router.get("/templates")
async def list_templates(user: AuthorizedUser) -> TemplatesListResponse:
    """List all risk assessment templates"""
    try:
        conn = await get_db_connection()
        
        query = """
            SELECT id, title, description, how_it_works, sections, status, created_at, updated_at, created_by
            FROM risk_assessment_templates
            ORDER BY created_at DESC
        """
        
        rows = await conn.fetch(query)
        await conn.close()
        
        templates = []
        for row in rows:
            sections = json.loads(row['sections']) if row['sections'] else []
            templates.append(TemplateResponse(
                id=row['id'],
                title=row['title'],
                description=row['description'],
                how_it_works=row['how_it_works'],
                sections=sections,
                status=row['status'],
                created_at=row['created_at'].isoformat() if hasattr(row['created_at'], 'isoformat') else str(row['created_at']),
                updated_at=row['updated_at'].isoformat() if hasattr(row['updated_at'], 'isoformat') else str(row['updated_at']),
                created_by=row['created_by']
            ))
        
        return TemplatesListResponse(
            templates=templates,
            total=len(templates)
        )
        
    except Exception as e:
        print(f"Error listing templates: {e}")
        raise HTTPException(status_code=500, detail="Failed to list templates")

@router.get("/template/{template_id}")
async def get_template(template_id: int, user: AuthorizedUser) -> TemplateResponse:
    """Get a specific template by ID"""
    try:
        conn = await get_db_connection()
        
        query = """
            SELECT id, title, description, how_it_works, sections, status, created_at, updated_at, created_by
            FROM risk_assessment_templates
            WHERE id = $1
        """
        
        row = await conn.fetchrow(query, template_id)
        await conn.close()
        
        if not row:
            raise HTTPException(status_code=404, detail="Template not found")
        
        sections = json.loads(row['sections']) if row['sections'] else []
        
        return TemplateResponse(
            id=row['id'],
            title=row['title'],
            description=row['description'],
            how_it_works=row['how_it_works'],
            sections=sections,
            status=row['status'],
            created_at=row['created_at'].isoformat() if hasattr(row['created_at'], 'isoformat') else str(row['created_at']),
            updated_at=row['updated_at'].isoformat() if hasattr(row['updated_at'], 'isoformat') else str(row['updated_at']),
            created_by=row['created_by']
        )
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error getting template: {e}")
        raise HTTPException(status_code=500, detail="Failed to get template")

@router.put("/template/{template_id}")
async def update_template(template_id: int, body: UpdateTemplateRequest, user: AuthorizedUser) -> Dict[str, Any]:
    """Update a template (Admin only)"""
    try:
        conn = await get_db_connection()
        
        # Build dynamic update query
        updates = []
        values = []
        param_count = 1
        
        if body.title is not None:
            updates.append(f"title = ${param_count}")
            values.append(body.title)
            param_count += 1
            
        if body.description is not None:
            updates.append(f"description = ${param_count}")
            values.append(body.description)
            param_count += 1
            
        if body.how_it_works is not None:
            updates.append(f"how_it_works = ${param_count}")
            values.append(body.how_it_works)
            param_count += 1
            
        if body.sections is not None:
            updates.append(f"sections = ${param_count}")
            values.append(json.dumps([section.dict() for section in body.sections]))
            param_count += 1
            
        if body.status is not None:
            updates.append(f"status = ${param_count}")
            values.append(body.status)
            param_count += 1
        
        if not updates:
            raise HTTPException(status_code=400, detail="No updates provided")
        
        updates.append(f"updated_at = ${param_count}")
        values.append(datetime.utcnow())
        param_count += 1
        
        values.append(template_id)
        
        query = f"""
            UPDATE risk_assessment_templates 
            SET {', '.join(updates)}
            WHERE id = ${param_count}
        """
        
        result = await conn.execute(query, *values)
        await conn.close()
        
        if result == "UPDATE 0":
            raise HTTPException(status_code=404, detail="Template not found")
        
        return {
            "success": True,
            "message": "Template updated successfully"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error updating template: {e}")
        raise HTTPException(status_code=500, detail="Failed to update template")

@router.delete("/template/{template_id}")
async def delete_template(template_id: int, user: AuthorizedUser) -> Dict[str, Any]:
    """Delete a template (Admin only)"""
    try:
        conn = await get_db_connection()
        
        query = "DELETE FROM risk_assessment_templates WHERE id = $1"
        result = await conn.execute(query, template_id)
        await conn.close()
        
        if result == "DELETE 0":
            raise HTTPException(status_code=404, detail="Template not found")
        
        return {
            "success": True,
            "message": "Template deleted successfully"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error deleting template: {e}")
        raise HTTPException(status_code=500, detail="Failed to delete template")

@router.post("/customize")
async def customize_template(body: CustomizeTemplateRequest, user: AuthorizedUser) -> Dict[str, Any]:
    """Create a customized version of a template for a company"""
    try:
        conn = await get_db_connection()
        
        # Check if template exists
        template_query = "SELECT id FROM risk_assessment_templates WHERE id = $1"
        template_exists = await conn.fetchval(template_query, body.template_id)
        
        if not template_exists:
            raise HTTPException(status_code=404, detail="Template not found")
        
        # Insert customized form
        query = """
            INSERT INTO company_risk_forms 
            (template_id, company_name, customizations, user_id, created_at)
            VALUES ($1, $2, $3, $4, $5)
            RETURNING id
        """
        
        customizations_json = json.dumps(body.customizations)
        now = datetime.utcnow()
        
        form_id = await conn.fetchval(
            query, 
            body.template_id, 
            body.company_name, 
            customizations_json, 
            user.sub, 
            now
        )
        
        await conn.close()
        
        return {
            "success": True,
            "form_id": form_id,
            "message": "Customized form created successfully"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error customizing template: {e}")
        raise HTTPException(status_code=500, detail="Failed to customize template")

@router.get("/company-forms")
async def list_company_forms(user: AuthorizedUser) -> Dict[str, Any]:
    """List all customized forms for the current user's company"""
    try:
        conn = await get_db_connection()
        
        query = """
            SELECT cf.id, cf.template_id, cf.company_name, cf.customizations, cf.created_at,
                   rt.title as template_title, rt.description as template_description
            FROM company_risk_forms cf
            JOIN risk_assessment_templates rt ON cf.template_id = rt.id
            WHERE cf.user_id = $1
            ORDER BY cf.created_at DESC
        """
        
        rows = await conn.fetch(query, user.sub)
        await conn.close()
        
        forms = []
        for row in rows:
            customizations = json.loads(row['customizations']) if row['customizations'] else {}
            forms.append({
                "id": row['id'],
                "template_id": row['template_id'],
                "template_title": row['template_title'],
                "template_description": row['template_description'],
                "company_name": row['company_name'],
                "customizations": customizations,
                "created_at": row['created_at']
            })
        
        return {
            "forms": forms,
            "total": len(forms)
        }
        
    except Exception as e:
        print(f"Error listing company forms: {e}")
        raise HTTPException(status_code=500, detail="Failed to list company forms")
