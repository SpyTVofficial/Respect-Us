

from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel
from typing import List, Dict, Any, Optional
import asyncpg
import databutton as db
from app.auth import AuthorizedUser
from app.env import Mode, mode
from datetime import datetime
import difflib
import re

router = APIRouter(prefix="/doc-compare")

async def get_db_connection():
    return await asyncpg.connect(db.secrets.get("DATABASE_URL_DEV"))

class DocumentComparison(BaseModel):
    document1_id: int
    document1_title: str
    document1_excerpt: str
    document2_id: int
    document2_title: str
    document2_excerpt: str
    similarity_score: float
    differences: List[Dict[str, Any]]
    common_sections: List[str]
    comparison_type: str  # "version", "jurisdiction", "regulation_type"

class ComparisonRequest(BaseModel):
    document_ids: List[int]
    comparison_type: Optional[str] = "general"
    focus_areas: Optional[List[str]] = []  # "definitions", "requirements", "penalties", etc.

class DocumentDifference(BaseModel):
    type: str  # "addition", "deletion", "modification"
    section: str
    old_text: Optional[str] = None
    new_text: Optional[str] = None
    line_number: Optional[int] = None
    similarity: Optional[float] = None

class ComparisonResult(BaseModel):
    documents: List[Dict[str, Any]]
    comparisons: List[DocumentComparison]
    summary: Dict[str, Any]
    generated_at: datetime

@router.post("/compare", response_model=ComparisonResult)
async def compare_documents(
    request: ComparisonRequest,
    user: AuthorizedUser
) -> ComparisonResult:
    """Compare multiple documents side-by-side for regulatory analysis"""
    
    if len(request.document_ids) < 2:
        raise HTTPException(status_code=400, detail="At least 2 documents required for comparison")
    
    if len(request.document_ids) > 5:
        raise HTTPException(status_code=400, detail="Maximum 5 documents can be compared at once")
    
    conn = await get_db_connection()
    try:
        # Fetch documents
        documents = []
        for doc_id in request.document_ids:
            doc = await conn.fetchrow(
                "SELECT * FROM kb_documents WHERE id = $1 AND status = 'published'",
                doc_id
            )
            if not doc:
                raise HTTPException(status_code=404, detail=f"Document {doc_id} not found or not published")
            
            documents.append({
                "id": doc["id"],
                "title": doc["title"],
                "description": doc["description"],
                "country_jurisdiction": doc["country_jurisdiction"],
                "regulation_type": doc["regulation_type"],
                "content_text": doc["content_text"] or "",
                "file_name": doc["file_name"],
                "publication_date": doc["publication_date"],
                "effective_date": doc["effective_date"],
                "word_count": doc.get("word_count", 0),
                "page_count": doc.get("page_count", 0)
            })
        
        # Perform pairwise comparisons
        comparisons = []
        for i in range(len(documents)):
            for j in range(i + 1, len(documents)):
                doc1, doc2 = documents[i], documents[j]
                comparison = await _compare_document_pair(doc1, doc2, request.comparison_type, request.focus_areas)
                comparisons.append(comparison)
        
        # Generate summary
        summary = _generate_comparison_summary(documents, comparisons, request.comparison_type)
        
        return ComparisonResult(
            documents=documents,
            comparisons=comparisons,
            summary=summary,
            generated_at=datetime.now()
        )
        
    finally:
        await conn.close()

async def _compare_document_pair(
    doc1: Dict[str, Any], 
    doc2: Dict[str, Any], 
    comparison_type: str,
    focus_areas: List[str]
) -> DocumentComparison:
    """Compare two documents and return detailed comparison"""
    
    text1 = doc1["content_text"] or ""
    text2 = doc2["content_text"] or ""
    
    # Calculate similarity score
    similarity_score = _calculate_similarity(text1, text2)
    
    # Find differences
    differences = _find_differences(text1, text2, focus_areas)
    
    # Find common sections
    common_sections = _find_common_sections(text1, text2)
    
    # Determine comparison type based on document metadata
    detected_type = _detect_comparison_type(doc1, doc2)
    
    return DocumentComparison(
        document1_id=doc1["id"],
        document1_title=doc1["title"],
        document1_excerpt=text1[:500] + "..." if len(text1) > 500 else text1,
        document2_id=doc2["id"],
        document2_title=doc2["title"],
        document2_excerpt=text2[:500] + "..." if len(text2) > 500 else text2,
        similarity_score=similarity_score,
        differences=differences,
        common_sections=common_sections,
        comparison_type=detected_type if comparison_type == "general" else comparison_type
    )

def _calculate_similarity(text1: str, text2: str) -> float:
    """Calculate similarity score between two texts using difflib"""
    if not text1 and not text2:
        return 1.0
    if not text1 or not text2:
        return 0.0
    
    # Use SequenceMatcher for similarity calculation
    matcher = difflib.SequenceMatcher(None, text1, text2)
    return round(matcher.ratio(), 3)

def _find_differences(text1: str, text2: str, focus_areas: List[str]) -> List[Dict[str, Any]]:
    """Find specific differences between two texts"""
    differences = []
    
    # Split texts into lines for line-by-line comparison
    lines1 = text1.split('\n')
    lines2 = text2.split('\n')
    
    # Use difflib to find differences
    differ = difflib.unified_diff(
        lines1, lines2, 
        fromfile='document1', tofile='document2', 
        lineterm='', n=3
    )
    
    current_diff = None
    line_num = 0
    
    for line in differ:
        if line.startswith('@@'):
            # New section marker
            if current_diff:
                differences.append(current_diff)
            current_diff = {
                "type": "section",
                "section": line,
                "changes": []
            }
        elif line.startswith('-'):
            if current_diff:
                current_diff["changes"].append({
                    "type": "deletion",
                    "text": line[1:],
                    "line_number": line_num
                })
        elif line.startswith('+'):
            if current_diff:
                current_diff["changes"].append({
                    "type": "addition",
                    "text": line[1:],
                    "line_number": line_num
                })
        line_num += 1
    
    if current_diff:
        differences.append(current_diff)
    
    # Focus on specific areas if requested
    if focus_areas:
        differences = _filter_differences_by_focus(differences, focus_areas)
    
    return differences[:20]  # Limit to first 20 differences for performance

def _find_common_sections(text1: str, text2: str) -> List[str]:
    """Find common sections or patterns between two texts"""
    common_sections = []
    
    # Find common sentences (simple approach)
    sentences1 = re.split(r'[.!?]+', text1)
    sentences2 = re.split(r'[.!?]+', text2)
    
    for sent1 in sentences1:
        sent1 = sent1.strip()
        if len(sent1) > 50:  # Only consider substantial sentences
            for sent2 in sentences2:
                sent2 = sent2.strip()
                if len(sent2) > 50:
                    similarity = difflib.SequenceMatcher(None, sent1, sent2).ratio()
                    if similarity > 0.8:  # High similarity threshold
                        common_sections.append(sent1[:200] + "..." if len(sent1) > 200 else sent1)
                        break
    
    return list(set(common_sections))[:10]  # Remove duplicates and limit

def _detect_comparison_type(doc1: Dict[str, Any], doc2: Dict[str, Any]) -> str:
    """Detect the type of comparison based on document metadata"""
    
    # Same title suggests version comparison
    if doc1["title"] == doc2["title"]:
        return "version"
    
    # Same regulation type, different jurisdiction
    if (doc1["regulation_type"] == doc2["regulation_type"] and 
        doc1["country_jurisdiction"] != doc2["country_jurisdiction"]):
        return "jurisdiction"
    
    # Different regulation types
    if doc1["regulation_type"] != doc2["regulation_type"]:
        return "regulation_type"
    
    return "general"

def _filter_differences_by_focus(differences: List[Dict[str, Any]], focus_areas: List[str]) -> List[Dict[str, Any]]:
    """Filter differences based on focus areas"""
    
    focus_keywords = {
        "definitions": ["definition", "means", "includes", "refers to", "shall mean"],
        "requirements": ["must", "shall", "required", "mandatory", "obligation"],
        "penalties": ["penalty", "fine", "violation", "sanctions", "enforcement"],
        "procedures": ["procedure", "process", "steps", "application", "filing"],
        "exemptions": ["exempt", "exception", "exclusion", "not applicable"]
    }
    
    if not focus_areas:
        return differences
    
    filtered_differences = []
    
    for diff in differences:
        if isinstance(diff, dict) and "changes" in diff:
            relevant_changes = []
            for change in diff["changes"]:
                text = change.get("text", "").lower()
                for focus_area in focus_areas:
                    if focus_area in focus_keywords:
                        keywords = focus_keywords[focus_area]
                        if any(keyword in text for keyword in keywords):
                            relevant_changes.append(change)
                            break
            
            if relevant_changes:
                diff_copy = diff.copy()
                diff_copy["changes"] = relevant_changes
                filtered_differences.append(diff_copy)
    
    return filtered_differences

def _generate_comparison_summary(documents: List[Dict[str, Any]], comparisons: List[DocumentComparison], comparison_type: str) -> Dict[str, Any]:
    """Generate summary of all comparisons"""
    
    if not comparisons:
        return {"error": "No comparisons performed"}
    
    avg_similarity = sum(comp.similarity_score for comp in comparisons) / len(comparisons)
    total_differences = sum(len(comp.differences) for comp in comparisons)
    
    # Identify most and least similar pairs
    most_similar = max(comparisons, key=lambda x: x.similarity_score)
    least_similar = min(comparisons, key=lambda x: x.similarity_score)
    
    # Document metadata summary
    jurisdictions = list(set(doc["country_jurisdiction"] for doc in documents if doc["country_jurisdiction"]))
    regulation_types = list(set(doc["regulation_type"] for doc in documents if doc["regulation_type"]))
    
    return {
        "total_documents": len(documents),
        "total_comparisons": len(comparisons),
        "average_similarity": round(avg_similarity, 3),
        "total_differences_found": total_differences,
        "most_similar_pair": {
            "doc1": most_similar.document1_title,
            "doc2": most_similar.document2_title,
            "similarity": most_similar.similarity_score
        },
        "least_similar_pair": {
            "doc1": least_similar.document1_title,
            "doc2": least_similar.document2_title,
            "similarity": least_similar.similarity_score
        },
        "jurisdictions_covered": jurisdictions,
        "regulation_types_covered": regulation_types,
        "comparison_type": comparison_type,
        "analysis_depth": "detailed" if total_differences > 0 else "basic"
    }

@router.get("/compare/suggestions")
async def get_comparison_suggestions(
    document_id: int = Query(..., description="Base document ID for suggestions"),
    limit: int = Query(5, description="Maximum number of suggestions")
) -> List[Dict[str, Any]]:
    """Get suggested documents for comparison with a given document"""
    
    conn = await get_db_connection()
    try:
        # Get the base document
        base_doc = await conn.fetchrow(
            "SELECT * FROM kb_documents WHERE id = $1 AND status = 'published'",
            document_id
        )
        
        if not base_doc:
            raise HTTPException(status_code=404, detail="Document not found")
        
        suggestions = []
        
        # Find documents with same regulation type but different jurisdiction
        if base_doc["regulation_type"] and base_doc["country_jurisdiction"]:
            jurisdiction_variants = await conn.fetch(
                """
                SELECT id, title, country_jurisdiction, regulation_type, 
                       publication_date, file_name
                FROM kb_documents 
                WHERE regulation_type = $1 
                  AND country_jurisdiction != $2 
                  AND status = 'published'
                  AND id != $3
                ORDER BY publication_date DESC
                LIMIT $4
                """,
                base_doc["regulation_type"],
                base_doc["country_jurisdiction"],
                document_id,
                limit // 2
            )
            
            for doc in jurisdiction_variants:
                suggestions.append({
                    "id": doc["id"],
                    "title": doc["title"],
                    "reason": f"Same regulation type ({doc['regulation_type']}) in different jurisdiction",
                    "country_jurisdiction": doc["country_jurisdiction"],
                    "regulation_type": doc["regulation_type"],
                    "suggested_comparison_type": "jurisdiction"
                })
        
        # Find documents with similar titles (potential versions)
        if base_doc["title"]:
            # Simple title similarity - in production could use more sophisticated matching
            title_words = base_doc["title"].lower().split()
            if len(title_words) >= 2:
                title_variants = await conn.fetch(
                    """
                    SELECT id, title, country_jurisdiction, regulation_type,
                           publication_date, file_name
                    FROM kb_documents 
                    WHERE title ILIKE $1 
                      AND status = 'published'
                      AND id != $2
                    ORDER BY publication_date DESC
                    LIMIT $3
                    """,
                    f"%{' '.join(title_words[:2])}%",
                    document_id,
                    limit - len(suggestions)
                )
                
                for doc in title_variants:
                    suggestions.append({
                        "id": doc["id"],
                        "title": doc["title"],
                        "reason": "Similar title (potential different version)",
                        "country_jurisdiction": doc["country_jurisdiction"],
                        "regulation_type": doc["regulation_type"],
                        "suggested_comparison_type": "version"
                    })
        
        return suggestions[:limit]
        
    finally:
        await conn.close()
