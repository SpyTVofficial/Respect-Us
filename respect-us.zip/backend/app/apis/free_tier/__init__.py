
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from datetime import datetime, timedelta
from app.auth import AuthorizedUser
import asyncpg
import databutton as db
from typing import Optional

router = APIRouter()

# Pydantic Models
class FreeTierStatus(BaseModel):
    eligible: bool
    already_activated: bool
    welcome_credits: int
    activation_date: Optional[datetime] = None
    days_since_activation: Optional[int] = None
    remaining_trial_days: Optional[int] = None

class FreeTierActivationResponse(BaseModel):
    success: bool
    credits_awarded: int
    message: str
    trial_expires_date: datetime
    welcome_benefits: list[str]

class TrialUsageStats(BaseModel):
    total_credits_used: int
    credits_remaining: int
    days_active: int
    most_used_modules: list[dict]
    trial_completion_percentage: float
    suggested_next_steps: list[str]

# Free tier configuration
FREE_TIER_CONFIG = {
    "welcome_credits": 100,
    "trial_duration_days": 30,
    "max_activations_per_user": 1,
    "bonus_credits_referral": 25
}

@router.get("/check-eligibility", response_model=FreeTierStatus)
async def check_free_tier_eligibility(user: AuthorizedUser):
    """
    Check if user is eligible for free tier credits
    """
    try:
        conn = await asyncpg.connect(db.secrets.get("DATABASE_URL_DEV"))
        
        try:
            # Check if user has already activated free tier
            check_query = """
                SELECT activation_date, credits_awarded
                FROM free_tier_activations 
                WHERE user_id = $1
                ORDER BY activation_date DESC
                LIMIT 1
            """
            activation_record = await conn.fetchrow(check_query, user.sub)
            
            if activation_record:
                activation_date = activation_record['activation_date']
                days_since = (datetime.utcnow() - activation_date).days
                remaining_days = max(0, FREE_TIER_CONFIG["trial_duration_days"] - days_since)
                
                return FreeTierStatus(
                    eligible=False,
                    already_activated=True,
                    welcome_credits=activation_record['credits_awarded'],
                    activation_date=activation_date,
                    days_since_activation=days_since,
                    remaining_trial_days=remaining_days
                )
            
            # Check account age (optional: only allow for accounts older than X hours)
            user_query = """
                SELECT current_balance, lifetime_purchased 
                FROM user_credits 
                WHERE user_id = $1
            """
            user_credits = await conn.fetchrow(user_query, user.sub)
            
            # User is eligible if they haven't activated before and haven't purchased credits
            is_eligible = (
                not activation_record and 
                (not user_credits or user_credits['lifetime_purchased'] == 0)
            )
            
            return FreeTierStatus(
                eligible=is_eligible,
                already_activated=False,
                welcome_credits=FREE_TIER_CONFIG["welcome_credits"]
            )
            
        finally:
            await conn.close()
            
    except Exception as e:
        print(f"Error checking free tier eligibility: {e}")
        raise HTTPException(status_code=500, detail="Failed to check eligibility") from e

@router.post("/activate", response_model=FreeTierActivationResponse)
async def activate_free_tier_credits(user: AuthorizedUser):
    """
    Activate free tier credits for eligible users
    """
    try:
        conn = await asyncpg.connect(db.secrets.get("DATABASE_URL_DEV"))
        
        try:
            # Double-check eligibility
            eligibility_check = await check_free_tier_eligibility(user)
            if not eligibility_check.eligible:
                raise HTTPException(
                    status_code=400, 
                    detail="User is not eligible for free tier activation"
                )
            
            async with conn.transaction():
                # Create or update user credits
                upsert_credits_query = """
                    INSERT INTO user_credits (user_id, current_balance, lifetime_purchased, lifetime_consumed)
                    VALUES ($1, $2, 0, 0)
                    ON CONFLICT (user_id) 
                    DO UPDATE SET current_balance = user_credits.current_balance + $2
                    RETURNING current_balance
                """
                new_balance = await conn.fetchval(
                    upsert_credits_query, 
                    user.sub, 
                    FREE_TIER_CONFIG["welcome_credits"]
                )
                
                # Record free tier activation
                activation_query = """
                    INSERT INTO free_tier_activations 
                    (user_id, credits_awarded, activation_date, expires_date)
                    VALUES ($1, $2, $3, $4)
                """
                activation_date = datetime.utcnow()
                expires_date = activation_date + timedelta(days=FREE_TIER_CONFIG["trial_duration_days"])
                
                await conn.execute(
                    activation_query,
                    user.sub,
                    FREE_TIER_CONFIG["welcome_credits"],
                    activation_date,
                    expires_date
                )
                
                # Log transaction
                transaction_query = """
                    INSERT INTO credit_transactions 
                    (user_id, transaction_type, amount, balance_after, description, created_at)
                    VALUES ($1, 'free_tier_welcome', $2, $3, $4, $5)
                """
                await conn.execute(
                    transaction_query,
                    user.sub,
                    FREE_TIER_CONFIG["welcome_credits"],
                    new_balance,
                    "Welcome credits - Free tier activation",
                    activation_date
                )
                
                print(f"Free tier activated for user {user.sub}: {FREE_TIER_CONFIG['welcome_credits']} credits")
                
                return FreeTierActivationResponse(
                    success=True,
                    credits_awarded=FREE_TIER_CONFIG["welcome_credits"],
                    message=f"Welcome! {FREE_TIER_CONFIG['welcome_credits']} free credits have been added to your account.",
                    trial_expires_date=expires_date,
                    welcome_benefits=[
                        "🚀 Explore all 6 compliance modules",
                        "📊 Unlimited document analysis", 
                        "🔍 Advanced search capabilities",
                        "📈 Risk assessment tools",
                        "🌍 Sanctions & embargo screening",
                        "💼 Customer due diligence"
                    ]
                )
                
        finally:
            await conn.close()
            
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error activating free tier: {e}")
        raise HTTPException(status_code=500, detail="Failed to activate free tier") from e

@router.get("/trial-stats", response_model=TrialUsageStats)
async def get_trial_usage_stats(user: AuthorizedUser):
    """
    Get trial usage statistics for the user
    """
    try:
        conn = await asyncpg.connect(db.secrets.get("DATABASE_URL_DEV"))
        
        try:
            # Get activation record
            activation_query = """
                SELECT activation_date, credits_awarded, expires_date
                FROM free_tier_activations 
                WHERE user_id = $1
                ORDER BY activation_date DESC
                LIMIT 1
            """
            activation = await conn.fetchrow(activation_query, user.sub)
            
            if not activation:
                raise HTTPException(status_code=404, detail="Free tier not activated")
            
            # Get current balance
            balance_query = "SELECT current_balance FROM user_credits WHERE user_id = $1"
            current_balance = await conn.fetchval(balance_query, user.sub) or 0
            
            # Calculate usage stats
            credits_used = activation['credits_awarded'] - current_balance
            days_active = (datetime.utcnow() - activation['activation_date']).days
            
            # Get module usage stats
            module_usage_query = """
                SELECT 
                    component_name,
                    COUNT(*) as usage_count,
                    SUM(amount) as total_credits
                FROM credit_transactions 
                WHERE user_id = $1 
                    AND transaction_type = 'consumption'
                    AND created_at >= $2
                GROUP BY component_name
                ORDER BY total_credits DESC
                LIMIT 5
            """
            module_usage = await conn.fetch(
                module_usage_query, 
                user.sub, 
                activation['activation_date']
            )
            
            most_used_modules = [
                {
                    "module": row['component_name'].replace('_', ' ').title(),
                    "usage_count": row['usage_count'],
                    "credits_used": abs(row['total_credits'])
                }
                for row in module_usage
            ]
            
            # Calculate completion percentage
            completion_percentage = (credits_used / activation['credits_awarded']) * 100
            
            # Generate suggestions
            suggestions = []
            if completion_percentage < 25:
                suggestions.extend([
                    "Try the Product Classification module for export control analysis",
                    "Upload a document to the Knowledge Base for AI-powered insights",
                    "Run a sanctions screening to see compliance checks in action"
                ])
            elif completion_percentage < 75:
                suggestions.extend([
                    "Explore advanced risk assessment workflows",
                    "Try bulk operations for efficiency testing",
                    "Set up automated screening processes"
                ])
            else:
                suggestions.extend([
                    "Consider purchasing credits to continue your compliance workflow",
                    "Explore enterprise features with higher credit packages",
                    "Contact our team for custom compliance solutions"
                ])
            
            return TrialUsageStats(
                total_credits_used=credits_used,
                credits_remaining=current_balance,
                days_active=days_active,
                most_used_modules=most_used_modules,
                trial_completion_percentage=min(100, completion_percentage),
                suggested_next_steps=suggestions
            )
            
        finally:
            await conn.close()
            
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error fetching trial stats: {e}")
        raise HTTPException(status_code=500, detail="Failed to fetch trial statistics") from e

@router.post("/extend-trial")
async def extend_trial_credits(user: AuthorizedUser, bonus_credits: int = 25):
    """
    Award bonus credits for specific trial milestones
    """
    try:
        conn = await asyncpg.connect(db.secrets.get("DATABASE_URL_DEV"))
        
        try:
            # Check if user has an active trial
            activation_query = """
                SELECT activation_date, expires_date
                FROM free_tier_activations 
                WHERE user_id = $1 AND expires_date > $2
                ORDER BY activation_date DESC
                LIMIT 1
            """
            activation = await conn.fetchrow(activation_query, user.sub, datetime.utcnow())
            
            if not activation:
                raise HTTPException(status_code=400, detail="No active trial found")
            
            # Check if bonus already awarded today (prevent abuse)
            today = datetime.utcnow().date()
            bonus_check_query = """
                SELECT COUNT(*) FROM credit_transactions 
                WHERE user_id = $1 
                    AND transaction_type = 'trial_bonus'
                    AND DATE(created_at) = $2
            """
            bonus_today = await conn.fetchval(bonus_check_query, user.sub, today)
            
            if bonus_today > 0:
                raise HTTPException(status_code=400, detail="Bonus already claimed today")
            
            async with conn.transaction():
                # Add bonus credits
                update_query = """
                    UPDATE user_credits 
                    SET current_balance = current_balance + $2
                    WHERE user_id = $1
                    RETURNING current_balance
                """
                new_balance = await conn.fetchval(update_query, user.sub, bonus_credits)
                
                # Log transaction
                transaction_query = """
                    INSERT INTO credit_transactions 
                    (user_id, transaction_type, amount, balance_after, description, created_at)
                    VALUES ($1, 'trial_bonus', $2, $3, $4, $5)
                """
                await conn.execute(
                    transaction_query,
                    user.sub,
                    bonus_credits,
                    new_balance,
                    "Trial milestone bonus credits",
                    datetime.utcnow()
                )
                
                return {
                    "success": True,
                    "bonus_credits": bonus_credits,
                    "new_balance": new_balance,
                    "message": f"Congratulations! {bonus_credits} bonus credits awarded."
                }
                
        finally:
            await conn.close()
            
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error extending trial: {e}")
        raise HTTPException(status_code=500, detail="Failed to award bonus credits") from e
