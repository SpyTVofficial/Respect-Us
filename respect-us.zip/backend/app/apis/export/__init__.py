

from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse
from typing import Optional, List, Dict, Any
from pydantic import BaseModel
import asyncpg
import json
import csv
import io
import base64
from datetime import datetime
from reportlab.lib.pagesizes import letter, A4
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, PageBreak
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors
from reportlab.lib.units import inch
import databutton as db
from app.env import Mode, mode

router = APIRouter(prefix="/export")

# Database connection
async def get_db_connection():
    if mode == Mode.PROD:
        DATABASE_URL = db.secrets.get("DATABASE_URL_PROD")
    else:
        DATABASE_URL = db.secrets.get("DATABASE_URL_DEV")
    return await asyncpg.connect(DATABASE_URL)

class ExportRequest(BaseModel):
    format: str  # 'csv', 'json'
    search_term: Optional[str] = None
    risk_categories: Optional[List[str]] = None
    has_arms_embargo: Optional[bool] = None
    freedom_score_min: Optional[float] = None
    freedom_score_max: Optional[float] = None
    include_all_indicators: bool = True

@router.post("/critical-countries", tags=["stream"])
async def export_critical_countries(export_request: ExportRequest):
    """Export critical countries data in various formats"""
    conn = await get_db_connection()
    try:
        # Build query based on criteria
        base_query = """
        SELECT cc.*, 
               cc.country_name,
               cc.abbreviation,
               cc.iso_code,
               cc.is_active,
               cc.risk_level,
               cc.risk_categories,
               cc.risk_description,
               cc.last_risk_assessment_date,
               cc.export_control_wassenaar,
               cc.export_control_nsg,
               cc.export_control_ag,
               cc.export_control_mtcr,
               cc.export_control_zc,
               cc.export_control_notes,
               cc.export_control_risk,
               cc.sanctions,
               cc.sanctions_notes,
               cc.sanctions_risk,
               cc.un_arms_embargo,
               cc.un_arms_embargo_notes,
               cc.us_arms_embargo,
               cc.us_arms_embargo_notes,
               cc.eu_arms_embargo,
               cc.eu_arms_embargo_notes,
               cc.other_arms_embargo,
               cc.other_arms_embargo_notes,
               cc.arms_risk,
               cc.cwc_1993_signatory,
               cc.cwc_1993_ratified,
               cc.cwc_violations,
               cc.chemical_risk,
               cc.bwc_1972_signatory,
               cc.bwc_1972_ratified,
               cc.bwc_violations,
               cc.biological_risk,
               cc.npt_signatory,
               cc.npt_ratified,
               cc.npt_notes,
               cc.ctbt_signatory,
               cc.ctbt_ratified,
               cc.ctbt_notes,
               cc.iaea_signatory,
               cc.iaea_ratified,
               cc.iaea_notes,
               cc.nsg_1974_signatory,
               cc.nsg_1974_ratified,
               cc.nsg_notes,
               cc.conv_1980_signatory,
               cc.conv_1980_ratified,
               cc.conv_1980_notes,
               cc.conv_1994_signatory,
               cc.conv_1994_ratified,
               cc.conv_1994_notes,
               cc.nuclear_violations,
               cc.nuclear_risk,
               cc.human_rights,
               cc.human_rights_note,
               cc.human_rights_risk_score,
               cc.political_rights,
               cc.civil_liberties,
               cc.freedom_in_the_world,
               cc.freedom_note,
               cc.freedom_risk,
               cc.obstacles_to_access,
               cc.limits_on_content,
               cc.violations_of_user_rights,
               cc.freedom_net_note,
               cc.freedom_net_risk,
               cc.democracy_status,
               cc.democracy_percentage,
               cc.nations_in_transit,
               cc.regime_type,
               cc.human_rights_freedoms_risk,
               cc.created_at,
               cc.updated_at,
               cc.created_by,
               cc.updated_by,
               cc.notes
        FROM critical_countries cc 
        WHERE 1=1
    """
        
        conditions = []
        params = []
        param_count = 0
        
        # Add search filters
        if export_request.search_term:
            param_count += 1
            conditions.append(f"(cc.country_name ILIKE ${param_count} OR cc.abbreviation ILIKE ${param_count})")
            params.append(f"%{export_request.search_term}%")
        
        if conditions:
            base_query += " AND " + " AND ".join(conditions)
        
        base_query += " ORDER BY cc.country_name"
        
        countries = await conn.fetch(base_query, *params)
        
        # Get detailed data for each country
        export_data = []
        for country in countries:
            country_data = dict(country)
            
            if export_request.include_all_indicators:
                # Get all risk assessments for this country
                risk_query = """
                SELECT rc.category_name, ri.indicator_name, ri.indicator_type,
                       cra.value_text, cra.value_boolean, cra.value_numeric, 
                       cra.value_date, cra.notes
                FROM country_risk_assessments cra
                JOIN risk_indicators ri ON cra.indicator_id = ri.id
                JOIN risk_categories rc ON ri.category_id = rc.id
                WHERE cra.country_id = $1
                ORDER BY rc.display_order, ri.display_order
                """
                risk_values = await conn.fetch(risk_query, country['id'])
                country_data['risk_assessments'] = [dict(rv) for rv in risk_values]
            
            export_data.append(country_data)
        
        # Generate export based on format
        if export_request.format.lower() == 'json':
            return generate_json_export(export_data, export_request)
        elif export_request.format.lower() == 'csv':
            return generate_csv_export(export_data, export_request)
        elif export_request.format.lower() == 'pdf':
            return generate_pdf_export(export_data, export_request)
        else:
            raise HTTPException(status_code=400, detail="Unsupported export format")
        
    finally:
        await conn.close()

def generate_json_export(data: List[dict], export_request: ExportRequest):
    """Generate JSON export"""
    export_package = {
        'metadata': {
            'generated_at': datetime.utcnow().isoformat(),
            'export_criteria': {
                'search_term': export_request.search_term,
                'risk_categories': export_request.risk_categories,
                'has_arms_embargo': export_request.has_arms_embargo,
                'freedom_score_range': {
                    'min': export_request.freedom_score_min,
                    'max': export_request.freedom_score_max
                },
                'include_all_indicators': export_request.include_all_indicators
            },
            'total_countries': len(data)
        },
        'countries': data
    }
    
    json_str = json.dumps(export_package, indent=2, default=str)
    json_stream = io.BytesIO(json_str.encode('utf-8'))
    
    return StreamingResponse(
        io.BytesIO(json_str.encode('utf-8')),
        media_type="application/json",
        headers={
            "Content-Disposition": f"attachment; filename=critical-countries-{datetime.now().strftime('%Y%m%d-%H%M%S')}.json"
        }
    )

def generate_csv_export(export_data: List[Dict[str, Any]], export_request: ExportRequest):
    """Generate CSV export stream"""
    def csv_stream():
        output = io.StringIO()
        
        if export_data:
            writer = csv.DictWriter(output, fieldnames=export_data[0].keys())
            writer.writeheader()
            
            for row in export_data:
                writer.writerow(row)
                
        content = output.getvalue()
        output.close()
        yield content
    
    return StreamingResponse(csv_stream(), media_type="text/csv")

def generate_pdf_export(export_data: List[Dict[str, Any]], export_request: ExportRequest):
    """Generate PDF export stream with comprehensive country reports - one country per set of pages"""
    def pdf_stream():
        # Create PDF buffer
        buffer = io.BytesIO()
        
        # Create PDF document with margins
        doc = SimpleDocTemplate(
            buffer, 
            pagesize=A4,
            topMargin=40,
            bottomMargin=40,
            leftMargin=40,
            rightMargin=40
        )
        elements = []
        
        # Get styles
        styles = getSampleStyleSheet()
        
        # Custom styles
        title_style = ParagraphStyle(
            'CustomTitle',
            parent=styles['Heading1'],
            fontSize=24,
            spaceAfter=20,
            alignment=1,  # Center alignment
            textColor=colors.HexColor('#1e3a8a'),
            fontName='Helvetica-Bold'
        )
        
        country_title_style = ParagraphStyle(
            'CountryTitle',
            parent=styles['Heading1'],
            fontSize=18,
            spaceAfter=15,
            alignment=0,  # Left alignment
            textColor=colors.HexColor('#2563eb'),
            fontName='Helvetica-Bold'
        )
        
        section_style = ParagraphStyle(
            'SectionHeader',
            parent=styles['Heading2'],
            fontSize=14,
            spaceAfter=8,
            spaceBefore=15,
            textColor=colors.HexColor('#374151'),
            fontName='Helvetica-Bold'
        )
        
        field_style = ParagraphStyle(
            'FieldStyle',
            parent=styles['Normal'],
            fontSize=10,
            spaceAfter=4,
            leftIndent=10
        )
        
        notes_style = ParagraphStyle(
            'Notes',
            parent=styles['Normal'],
            fontSize=9,
            textColor=colors.HexColor('#6b7280'),
            spaceAfter=12
        )
        
        # Add cover page
        title = Paragraph("Critical Countries Comprehensive Report", title_style)
        elements.append(title)
        
        # Add generation info
        date_para = Paragraph(f"Generated on: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}", styles['Normal'])
        elements.append(date_para)
        
        count_para = Paragraph(f"Total Countries: {len(export_data)}", styles['Normal'])
        elements.append(count_para)
        
        if export_request.search_term:
            search_para = Paragraph(f"Search Filter: {export_request.search_term}", styles['Normal'])
            elements.append(search_para)
        
        elements.append(Spacer(1, 24))
        
        # Add table of contents
        toc_style = ParagraphStyle(
            'TOCHeader',
            parent=styles['Heading2'],
            fontSize=16,
            spaceAfter=12,
            textColor=colors.HexColor('#1e3a8a'),
            fontName='Helvetica-Bold'
        )
        
        elements.append(Paragraph("Table of Contents", toc_style))
        
        toc_item_style = ParagraphStyle(
            'TOCItem',
            parent=styles['Normal'],
            fontSize=11,
            spaceAfter=4,
            leftIndent=20
        )
        
        for i, country_data in enumerate(export_data, 1):
            country_name = country_data.get('country_name', 'Unknown Country')
            elements.append(Paragraph(f"{i}. {country_name}", toc_item_style))
        
        elements.append(PageBreak())
        
        # Process each country with comprehensive 8-tab analysis
        for i, country_data in enumerate(export_data):
            # Country header
            country_name = country_data.get('country_name', 'Unknown Country')
            elements.append(Paragraph(f"{country_name} - Comprehensive Risk Analysis", country_title_style))
            elements.append(Spacer(1, 12))
            
            # TAB 1: Overview Section
            elements.append(Paragraph("1. Country Overview", section_style))
            basic_info = [
                ('Country Code', country_data.get('abbreviation', 'N/A')),
                ('ISO Code', country_data.get('iso_code', 'N/A')),
                ('Region', country_data.get('region', 'N/A')),
                ('Sub-Region', country_data.get('sub_region', 'N/A')),
                ('Continent', country_data.get('continent', 'N/A')),
                ('Capital City', country_data.get('capital_city', 'N/A')),
                ('Population', country_data.get('population', 'N/A')),
                ('GDP (USD)', country_data.get('gdp_usd', 'N/A')),
                ('Government Type', country_data.get('government_type', 'N/A')),
                ('Head of State', country_data.get('head_of_state', 'N/A')),
                ('Official Languages', country_data.get('official_languages', 'N/A')),
                ('Currency', f"{country_data.get('currency_name', 'N/A')} ({country_data.get('currency_code', 'N/A')})"),
                ('Time Zone', country_data.get('time_zone', 'N/A')),
                ('Internet TLD', country_data.get('internet_tld', 'N/A')),
                ('Calling Code', country_data.get('calling_code', 'N/A'))
            ]
            
            for label, value in basic_info:
                elements.append(Paragraph(f"<b>{label}:</b> {value}", field_style))
            
            elements.append(Spacer(1, 16))
            
            # Overall Risk Assessment
            elements.append(Paragraph("Overall Risk Assessment", section_style))
            elements.append(Paragraph(f"<b>Overall Risk Level:</b> {country_data.get('risk_level', 'N/A').upper()}", field_style))
            elements.append(Paragraph(f"<b>Active Status:</b> {'Active' if country_data.get('is_active') else 'Inactive'}", field_style))
            
            elements.append(PageBreak())
            
            # TAB 2: Export Controls Section
            elements.append(Paragraph(f"{country_name} - Export Control Analysis", country_title_style))
            elements.append(Spacer(1, 12))
            
            export_control_data = [
                ['Regime/Treaty', 'Signatory', 'Ratified', 'Notes'],
                ['Wassenaar Arrangement', 
                 'Yes' if country_data.get('export_control_wassenaar') else 'No',
                 'Yes' if country_data.get('export_control_wassenaar') else 'No',  # Using same field as no separate ratified field
                 country_data.get('export_control_notes', 'N/A')[:50] + '...' if country_data.get('export_control_notes', '') else 'N/A'],
                ['Australia Group',
                 'Yes' if country_data.get('export_control_ag') else 'No',
                 'Yes' if country_data.get('export_control_ag') else 'No', 
                 country_data.get('export_control_notes', 'N/A')[:50] + '...' if country_data.get('export_control_notes', '') else 'N/A'],
                ['MTCR',
                 'Yes' if country_data.get('export_control_mtcr') else 'No',
                 'Yes' if country_data.get('export_control_mtcr') else 'No',
                 country_data.get('export_control_notes', 'N/A')[:50] + '...' if country_data.get('export_control_notes', '') else 'N/A'],
                ['Nuclear Suppliers Group',
                 'Yes' if country_data.get('export_control_nsg') else 'No',
                 'Yes' if country_data.get('export_control_nsg') else 'No',
                 country_data.get('export_control_notes', 'N/A')[:50] + '...' if country_data.get('export_control_notes', '') else 'N/A']
            ]
            
            export_table = Table(export_control_data, colWidths=[1.5*inch, 0.8*inch, 0.8*inch, 2.4*inch])
            export_table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#3b82f6')),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, 0), 9),
                ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
                ('FONTSIZE', (0, 1), (-1, -1), 8),
                ('GRID', (0, 0), (-1, -1), 1, colors.HexColor('#d1d5db')),
                ('VALIGN', (0, 0), (-1, -1), 'TOP'),
            ]))
            
            elements.append(export_table)
            elements.append(Spacer(1, 12))
            elements.append(Paragraph(f"<b>Export Control Risk Level:</b> {country_data.get('export_control_risk', 'N/A')}", field_style))
            
            elements.append(PageBreak())
            
            # TAB 3: Sanctions Section
            elements.append(Paragraph(f"{country_name} - Sanctions Analysis", country_title_style))
            elements.append(Spacer(1, 12))
            
            sanctions_data = [
                ['Sanctions Type', 'Status'],
                ['General Sanctions', 'Active' if country_data.get('sanctions') else 'None'],
                ['Sanctions Risk Level', country_data.get('sanctions_risk', 'N/A')]
            ]
            
            sanctions_table = Table(sanctions_data, colWidths=[2.5*inch, 2.5*inch])
            sanctions_table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#dc2626')),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, 0), 10),
                ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
                ('FONTSIZE', (0, 1), (-1, -1), 9),
                ('GRID', (0, 0), (-1, -1), 1, colors.HexColor('#d1d5db')),
            ]))
            
            elements.append(sanctions_table)
            
            if country_data.get('sanctions_notes'):
                elements.append(Spacer(1, 12))
                elements.append(Paragraph(f"<b>Sanctions Notes:</b> {country_data.get('sanctions_notes')}", notes_style))
            
            elements.append(PageBreak())
            
            # TAB 4: Arms Embargo Section
            elements.append(Paragraph(f"{country_name} - Arms Embargo Analysis", country_title_style))
            elements.append(Spacer(1, 12))
            
            arms_data = [
                ['Embargo Type', 'Status', 'Notes'],
                ['UN Arms Embargo', 'Active' if country_data.get('un_arms_embargo') else 'None', country_data.get('un_arms_embargo_notes', 'N/A')[:80] + '...' if country_data.get('un_arms_embargo_notes', '') else 'N/A'],
                ['US Arms Embargo', 'Active' if country_data.get('us_arms_embargo') else 'None', country_data.get('us_arms_embargo_notes', 'N/A')[:80] + '...' if country_data.get('us_arms_embargo_notes', '') else 'N/A'],
                ['EU Arms Embargo', 'Active' if country_data.get('eu_arms_embargo') else 'None', country_data.get('eu_arms_embargo_notes', 'N/A')[:80] + '...' if country_data.get('eu_arms_embargo_notes', '') else 'N/A'],
                ['Other Arms Embargo', 'Active' if country_data.get('other_arms_embargo') else 'None', country_data.get('other_arms_embargo_notes', 'N/A')[:80] + '...' if country_data.get('other_arms_embargo_notes', '') else 'N/A']
            ]
            
            arms_table = Table(arms_data, colWidths=[1.5*inch, 1*inch, 3*inch])
            arms_table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#dc2626')),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, 0), 10),
                ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
                ('FONTSIZE', (0, 1), (-1, -1), 9),
                ('GRID', (0, 0), (-1, -1), 1, colors.HexColor('#d1d5db')),
                ('VALIGN', (0, 0), (-1, -1), 'TOP'),
            ]))
            
            elements.append(arms_table)
            elements.append(Spacer(1, 12))
            elements.append(Paragraph(f"<b>Arms Risk Level:</b> {country_data.get('arms_risk', 'N/A')}", field_style))
            
            elements.append(PageBreak())
            
            # TAB 5: Chemical Risk Section
            elements.append(Paragraph(f"{country_name} - Chemical Weapons Analysis", country_title_style))
            elements.append(Spacer(1, 12))
            
            chemical_data = [
                ['Element', 'Status'],
                ['Chemical Risk Level', country_data.get('chemical_risk', 'N/A')],
                ['CWC 1993 Signatory', 'Yes' if country_data.get('cwc_1993_signatory') else 'No'],
                ['CWC 1993 Ratified', 'Yes' if country_data.get('cwc_1993_ratified') else 'No'],
                ['CWC Violations', 'Yes' if country_data.get('cwc_violations') else 'No'],
            ]
            
            chemical_table = Table(chemical_data, colWidths=[2.5*inch, 2.5*inch])
            chemical_table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#eab308')),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.black),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, 0), 10),
                ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
                ('FONTSIZE', (0, 1), (-1, -1), 9),
                ('GRID', (0, 0), (-1, -1), 1, colors.HexColor('#d1d5db')),
            ]))
            
            elements.append(chemical_table)
            
            elements.append(PageBreak())
            
            # TAB 6: Biological Risk Section
            elements.append(Paragraph(f"{country_name} - Biological Weapons Analysis", country_title_style))
            elements.append(Spacer(1, 12))
            
            biological_data = [
                ['Element', 'Status'],
                ['Biological Risk Level', country_data.get('biological_risk', 'N/A')],
                ['BWC 1972 Signatory', 'Yes' if country_data.get('bwc_1972_signatory') else 'No'],
                ['BWC 1972 Ratified', 'Yes' if country_data.get('bwc_1972_ratified') else 'No'],
                ['BWC Violations', 'Yes' if country_data.get('bwc_violations') else 'No'],
            ]
            
            biological_table = Table(biological_data, colWidths=[2.5*inch, 2.5*inch])
            biological_table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#8b5cf6')),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, 0), 10),
                ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
                ('FONTSIZE', (0, 1), (-1, -1), 9),
                ('GRID', (0, 0), (-1, -1), 1, colors.HexColor('#d1d5db')),
            ]))
            
            elements.append(biological_table)
            
            elements.append(PageBreak())
            
            # TAB 7: Nuclear Risk Section
            elements.append(Paragraph(f"{country_name} - Nuclear Treaties Analysis", country_title_style))
            elements.append(Spacer(1, 12))
            
            nuclear_data = [
                ['Treaty/Agreement', 'Signatory', 'Ratified', 'Notes'],
                ['NPT (Non-Proliferation Treaty)',
                 'Yes' if country_data.get('npt_signatory') else 'No',
                 'Yes' if country_data.get('npt_ratified') else 'No',
                 country_data.get('npt_notes', 'N/A')[:50] + '...' if country_data.get('npt_notes', '') else 'N/A'],
                ['CTBT (Comprehensive Test Ban)',
                 'Yes' if country_data.get('ctbt_signatory') else 'No',
                 'Yes' if country_data.get('ctbt_ratified') else 'No',
                 country_data.get('ctbt_notes', 'N/A')[:50] + '...' if country_data.get('ctbt_notes', '') else 'N/A'],
                ['IAEA Safeguards',
                 'Yes' if country_data.get('iaea_signatory') else 'No',
                 'Yes' if country_data.get('iaea_ratified') else 'No',
                 country_data.get('iaea_notes', 'N/A')[:50] + '...' if country_data.get('iaea_notes', '') else 'N/A'],
                ['NSG 1974',
                 'Yes' if country_data.get('nsg_1974_signatory') else 'No',
                 'Yes' if country_data.get('nsg_1974_ratified') else 'No',
                 country_data.get('nsg_notes', 'N/A')[:50] + '...' if country_data.get('nsg_notes', '') else 'N/A']
            ]
            
            nuclear_table = Table(nuclear_data, colWidths=[1.5*inch, 0.8*inch, 0.8*inch, 2.4*inch])
            nuclear_table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#f59e0b')),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.black),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, 0), 9),
                ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
                ('FONTSIZE', (0, 1), (-1, -1), 8),
                ('GRID', (0, 0), (-1, -1), 1, colors.HexColor('#d1d5db')),
                ('VALIGN', (0, 0), (-1, -1), 'TOP'),
            ]))
            
            elements.append(nuclear_table)
            elements.append(Spacer(1, 12))
            elements.append(Paragraph(f"<b>Nuclear Risk Level:</b> {country_data.get('nuclear_risk', 'N/A')}", field_style))
            
            if country_data.get('nuclear_notes'):
                elements.append(Spacer(1, 8))
                elements.append(Paragraph(f"<b>Nuclear Notes:</b> {country_data.get('nuclear_notes')}", notes_style))
            
            elements.append(PageBreak())
            
            # TAB 8: Human Rights and Freedoms Analysis
            elements.append(Paragraph(f"{country_name} - Human Rights & Freedoms Analysis", country_title_style))
            elements.append(Spacer(1, 12))
            
            human_rights_data = [
                ['Category', 'Status/Score'],
                ['Overall Human Rights Risk', country_data.get('human_rights_freedoms_risk', 'N/A')],
                ['Human Rights Status', country_data.get('human_rights', 'N/A')],
                ['Human Rights Risk Score', str(country_data.get('human_rights_risk_score', 'N/A'))],
                ['Political Rights', country_data.get('political_rights', 'N/A')],
                ['Civil Liberties', country_data.get('civil_liberties', 'N/A')],
                ['Freedom in the World', 'Yes' if country_data.get('freedom_in_the_world') else 'No'],
                ['Freedom Risk Level', country_data.get('freedom_risk', 'N/A')],
                ['Democracy Status', country_data.get('democracy_status', 'N/A')],
                ['Democracy Percentage', country_data.get('democracy_percentage', 'N/A')],
                ['Nations in Transit', country_data.get('nations_in_transit', 'N/A')],
                ['Regime Type', country_data.get('regime_type', 'N/A')]
            ]
            
            human_rights_table = Table(human_rights_data, colWidths=[3*inch, 2*inch])
            human_rights_table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#f97316')),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, 0), 10),
                ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
                ('FONTSIZE', (0, 1), (-1, -1), 9),
                ('GRID', (0, 0), (-1, -1), 1, colors.HexColor('#d1d5db')),
            ]))
            
            elements.append(human_rights_table)
            
            # Additional freedom details subsection
            elements.append(Spacer(1, 20))
            elements.append(Paragraph("Internet Freedom Analysis", section_style))
            elements.append(Spacer(1, 12))
            
            internet_freedom_data = [
                ['Category', 'Status'],
                ['Obstacles to Access', country_data.get('obstacles_to_access', 'N/A')],
                ['Limits on Content', country_data.get('limits_on_content', 'N/A')],
                ['Violations of User Rights', country_data.get('violations_of_user_rights', 'N/A')],
                ['Freedom Net Risk', country_data.get('freedom_net_risk', 'N/A')]
            ]
            
            internet_table = Table(internet_freedom_data, colWidths=[3*inch, 2*inch])
            internet_table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#6366f1')),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, 0), 10),
                ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
                ('FONTSIZE', (0, 1), (-1, -1), 9),
                ('GRID', (0, 0), (-1, -1), 1, colors.HexColor('#d1d5db')),
            ]))
            
            elements.append(internet_table)
            
            # Add notes if available
            if country_data.get('human_rights_note'):
                elements.append(Spacer(1, 12))
                elements.append(Paragraph(f"<b>Human Rights Notes:</b> {country_data.get('human_rights_note')}", notes_style))
            
            if country_data.get('freedom_note'):
                elements.append(Spacer(1, 12))
                elements.append(Paragraph(f"<b>Freedom Notes:</b> {country_data.get('freedom_note')}", notes_style))
            
            if country_data.get('freedom_net_note'):
                elements.append(Spacer(1, 12))
                elements.append(Paragraph(f"<b>Freedom Net Notes:</b> {country_data.get('freedom_net_note')}", notes_style))
            
            if country_data.get('notes'):
                elements.append(Spacer(1, 12))
                elements.append(Paragraph(f"<b>Additional Notes:</b> {country_data.get('notes')}", notes_style))
            
            # Metadata
            elements.append(Spacer(1, 12))
            elements.append(Paragraph("Record Information", section_style))
            if country_data.get('created_at'):
                elements.append(Paragraph(f"<b>Created:</b> {country_data.get('created_at')}", field_style))
            if country_data.get('updated_at'):
                elements.append(Paragraph(f"<b>Last Updated:</b> {country_data.get('updated_at')}", field_style))
            if country_data.get('created_by'):
                elements.append(Paragraph(f"<b>Created By:</b> {country_data.get('created_by')}", field_style))
            if country_data.get('updated_by'):
                elements.append(Paragraph(f"<b>Updated By:</b> {country_data.get('updated_by')}", field_style))
            
            # Add page break for next country (except for last country)
            if i < len(export_data) - 1:
                elements.append(PageBreak())
                elements.append(PageBreak())  # Extra break between countries for better separation
        
        # Handle empty data case
        if not export_data:
            no_data = Paragraph("No countries available for export.", styles['Normal'])
            elements.append(no_data)
        
        # Build PDF
        doc.build(elements)
        
        # Get PDF content
        pdf_content = buffer.getvalue()
        buffer.close()
        
        # Yield PDF content as bytes
        yield pdf_content
    
    return StreamingResponse(pdf_stream(), media_type="application/pdf")
