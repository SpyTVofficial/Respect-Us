
from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel
from typing import List, Optional
from datetime import datetime
import asyncpg
import databutton as db
from app.auth import AuthorizedUser

router = APIRouter()

# Database connection helper
async def get_db_connection():
    database_url = db.secrets.get("DATABASE_URL_DEV")
    return await asyncpg.connect(database_url)

# New Category Models
class CategoryRequest(BaseModel):
    name: str
    description: Optional[str] = None
    color: Optional[str] = "#6366f1"
    icon: Optional[str] = "folder"
    display_order: Optional[int] = 0

class CategoryResponse(BaseModel):
    id: int
    name: str
    description: Optional[str]
    color: str

class UpdateCategoryRequest(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    color: Optional[str] = None
    icon: Optional[str] = None
    display_order: Optional[int] = None

# Updated SaveArticleRequest to include category assignment
class SaveArticleRequest(BaseModel):
    document_id: str
    document_title: str
    document_description: Optional[str] = None
    document_type: Optional[str] = None
    document_url: Optional[str] = None
    category_ids: Optional[List[int]] = []  # New field for category assignment

# Updated SavedArticleResponse to include categories
class SavedArticleResponse(BaseModel):
    id: int
    document_id: str
    document_title: str
    document_description: Optional[str]
    document_type: Optional[str]
    document_url: Optional[str]
    saved_at: datetime
    user_id: str
    categories: List[CategoryResponse] = []  # New field for assigned categories

class AssignCategoriesRequest(BaseModel):
    category_ids: List[int]

@router.post("/save-article", response_model=SavedArticleResponse)
async def save_article(request: SaveArticleRequest, user: AuthorizedUser):
    """Save an article to user's saved collection"""
    conn = await get_db_connection()
    try:
        # Check if already saved
        existing = await conn.fetchval(
            "SELECT id FROM saved_articles WHERE user_id = $1 AND document_id = $2",
            user.sub, request.document_id
        )
        
        if existing:
            raise HTTPException(status_code=400, detail="Article is already saved")
        
        # Save the article
        article_id = await conn.fetchval(
            """
            INSERT INTO saved_articles (
                user_id, document_id, document_title, document_description,
                document_type, document_url, saved_at
            ) VALUES ($1, $2, $3, $4, $5, $6, NOW())
            RETURNING id
            """,
            user.sub, request.document_id, request.document_title,
            request.document_description, request.document_type, request.document_url
        )
        
        # Assign categories if provided
        if request.category_ids:
            for category_id in request.category_ids:
                # Verify category belongs to user
                category_exists = await conn.fetchval(
                    "SELECT id FROM user_article_categories WHERE id = $1 AND user_id = $2",
                    category_id, user.sub
                )
                if category_exists:
                    await conn.execute(
                        "INSERT INTO saved_article_categories (saved_article_id, category_id) VALUES ($1, $2)",
                        article_id, category_id
                    )
        
        # Fetch the saved article with categories
        return await get_saved_article_with_categories(conn, article_id, user.sub)
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to save article: {str(e)}")
    finally:
        await conn.close()


async def get_saved_article_with_categories(conn, article_id: int, user_id: str) -> SavedArticleResponse:
    """Helper function to get saved article with its categories"""
    # Get article details
    saved_article = await conn.fetchrow(
        "SELECT * FROM saved_articles WHERE id = $1 AND user_id = $2", 
        article_id, user_id
    )
    
    if not saved_article:
        raise HTTPException(status_code=404, detail="Saved article not found")
    
    # Get categories for this article
    categories = await conn.fetch(
        """
        SELECT c.id, c.name, c.description, c.color, c.icon, c.display_order, 
               c.created_at, c.updated_at
        FROM user_article_categories c
        JOIN saved_article_categories sac ON c.id = sac.category_id
        WHERE sac.saved_article_id = $1 AND c.user_id = $2
        ORDER BY c.display_order, c.name
        """,
        article_id, user_id
    )
    
    category_responses = [
        CategoryResponse(
            id=cat['id'],
            name=cat['name'],
            description=cat['description'],
            color=cat['color']
        )
        for cat in categories
    ]

    return SavedArticleResponse(
        id=saved_article['id'],
        document_id=saved_article['document_id'],
        document_title=saved_article['document_title'],
        document_description=saved_article['document_description'],
        document_type=saved_article['document_type'],
        document_url=saved_article['document_url'],
        saved_at=saved_article['saved_at'],
        user_id=saved_article['user_id'],
        categories=category_responses
    )


@router.delete("/unsave-article/{document_id}")
async def unsave_article(document_id: str, user: AuthorizedUser):
    """Remove an article from user's saved collection"""
    conn = await get_db_connection()
    try:
        result = await conn.execute(
            "DELETE FROM saved_articles WHERE user_id = $1 AND document_id = $2",
            user.sub, document_id
        )
        
        if result == "DELETE 0":
            raise HTTPException(status_code=404, detail="Saved article not found")
        
        return {"message": "Article removed from saved collection"}
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to unsave article: {str(e)}")
    finally:
        await conn.close()

@router.get("/saved-articles", response_model=List[SavedArticleResponse])
async def get_saved_articles(user: AuthorizedUser, category_id: Optional[int] = Query(None)):
    """Get all saved articles for the current user, optionally filtered by category"""
    conn = await get_db_connection()
    try:
        if category_id:
            # Filter by specific category
            articles = await conn.fetch(
                """
                SELECT DISTINCT sa.* FROM saved_articles sa
                JOIN saved_article_categories sac ON sa.id = sac.saved_article_id
                WHERE sa.user_id = $1 AND sac.category_id = $2
                ORDER BY sa.saved_at DESC
                """,
                user.sub, category_id
            )
        else:
            # Get all saved articles
            articles = await conn.fetch(
                """
                SELECT * FROM saved_articles 
                WHERE user_id = $1 
                ORDER BY saved_at DESC
                """,
                user.sub
            )
        
        result = []
        for article in articles:
            article_with_categories = await get_saved_article_with_categories(conn, article['id'], user.sub)
            result.append(article_with_categories)
        
        return result
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to fetch saved articles: {str(e)}")
    finally:
        await conn.close()

@router.get("/check-saved/{document_id}")
async def check_if_saved(document_id: str, user: AuthorizedUser):
    """Check if a document is saved by the user"""
    conn = await get_db_connection()
    try:
        is_saved = await conn.fetchval(
            "SELECT EXISTS(SELECT 1 FROM saved_articles WHERE user_id = $1 AND document_id = $2)",
            user.sub, document_id
        )
        
        return {"is_saved": bool(is_saved)}
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to check saved status: {str(e)}")
    finally:
        await conn.close()


# === CATEGORY MANAGEMENT ENDPOINTS ===

@router.post("/categories", response_model=CategoryResponse)
async def create_article_category(request: CategoryRequest, user: AuthorizedUser):
    """Create a new article category for the user"""
    conn = await get_db_connection()
    try:
        # Check if category name already exists for this user
        existing = await conn.fetchval(
            "SELECT id FROM user_article_categories WHERE user_id = $1 AND name = $2",
            user.sub, request.name
        )
        
        if existing:
            raise HTTPException(status_code=400, detail="Category with this name already exists")
        
        # Create new category
        category_id = await conn.fetchval(
            """
            INSERT INTO user_article_categories (user_id, name, description, color)
            VALUES ($1, $2, $3, $4)
            RETURNING id
            """,
            user.sub, request.name, request.description, request.color
        )
        
        return CategoryResponse(
            id=category_id,
            name=request.name,
            description=request.description,
            color=request.color
        )
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error creating category: {e}")
        raise HTTPException(status_code=500, detail="Failed to create category")
    finally:
        await conn.close()


@router.get("/categories", response_model=List[CategoryResponse])
async def get_article_categories(user: AuthorizedUser):
    """Get all categories for the current user with article counts"""
    conn = await get_db_connection()
    try:
        categories = await conn.fetch(
            """
            SELECT c.*, COUNT(sac.saved_article_id) as article_count
            FROM user_article_categories c
            LEFT JOIN saved_article_categories sac ON c.id = sac.category_id
            WHERE c.user_id = $1
            GROUP BY c.id
            ORDER BY c.name
            """,
            user.sub
        )
        
        return [
            CategoryResponse(
                id=cat['id'],
                name=cat['name'],
                description=cat['description'],
                color=cat['color']
            )
            for cat in categories
        ]
    except Exception as e:
        print(f"Error fetching categories: {e}")
        raise HTTPException(status_code=500, detail="Failed to fetch categories")
    finally:
        await conn.close()


@router.put("/categories/{category_id}", response_model=CategoryResponse)
async def update_article_category(category_id: int, request: CategoryRequest, user: AuthorizedUser):
    """Update an existing category"""
    conn = await get_db_connection()
    try:
        # Check if category exists and belongs to user
        existing = await conn.fetchrow(
            "SELECT * FROM user_article_categories WHERE id = $1 AND user_id = $2",
            category_id, user.sub
        )
        
        if not existing:
            raise HTTPException(status_code=404, detail="Category not found")
        
        # Check if new name conflicts with another category
        if request.name != existing['name']:
            name_conflict = await conn.fetchval(
                "SELECT id FROM user_article_categories WHERE user_id = $1 AND name = $2 AND id != $3",
                user.sub, request.name, category_id
            )
            
            if name_conflict:
                raise HTTPException(status_code=400, detail="Category with this name already exists")
        
        # Update category
        await conn.execute(
            """
            UPDATE user_article_categories 
            SET name = $1, description = $2, color = $3, updated_at = NOW()
            WHERE id = $4 AND user_id = $5
            """,
            request.name, request.description, request.color, category_id, user.sub
        )
        
        # Get article count
        article_count = await conn.fetchval(
            "SELECT COUNT(*) FROM saved_article_categories WHERE category_id = $1",
            category_id
        )
        
        return CategoryResponse(
            id=category_id,
            name=request.name,
            description=request.description,
            color=request.color
        )
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error updating category: {e}")
        raise HTTPException(status_code=500, detail="Failed to update category")
    finally:
        await conn.close()


@router.delete("/categories/{category_id}")
async def delete_article_category(category_id: int, user: AuthorizedUser):
    """Delete a category (only if it has no articles)"""
    conn = await get_db_connection()
    try:
        # Check if category exists and belongs to user
        existing = await conn.fetchrow(
            "SELECT * FROM user_article_categories WHERE id = $1 AND user_id = $2",
            category_id, user.sub
        )
        
        if not existing:
            raise HTTPException(status_code=404, detail="Category not found")
        
        # Check if category has articles
        article_count = await conn.fetchval(
            "SELECT COUNT(*) FROM saved_article_categories WHERE category_id = $1",
            category_id
        )
        
        if article_count and article_count > 0:
            raise HTTPException(status_code=400, detail="Cannot delete category with articles")
        
        # Delete category
        await conn.execute(
            "DELETE FROM user_article_categories WHERE id = $1 AND user_id = $2",
            category_id, user.sub
        )
        
        return {"message": "Category deleted successfully"}
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error deleting category: {e}")
        raise HTTPException(status_code=500, detail="Failed to delete category")
    finally:
        await conn.close()


@router.put("/saved-articles/{article_id}/categories", response_model=SavedArticleResponse)
async def assign_categories_to_article(article_id: int, request: AssignCategoriesRequest, user: AuthorizedUser):
    """Assign categories to an existing saved article"""
    conn = await get_db_connection()
    try:
        # Check if saved article exists and belongs to user
        saved_article = await conn.fetchrow(
            "SELECT * FROM saved_articles WHERE id = $1 AND user_id = $2",
            article_id, user.sub
        )
        
        if not saved_article:
            raise HTTPException(status_code=404, detail="Saved article not found")
        
        # Remove existing category assignments
        await conn.execute(
            "DELETE FROM saved_article_categories WHERE saved_article_id = $1",
            article_id
        )
        
        # Assign new categories if provided
        if request.category_ids:
            for category_id in request.category_ids:
                # Verify category belongs to user
                category_exists = await conn.fetchval(
                    "SELECT id FROM user_article_categories WHERE id = $1 AND user_id = $2",
                    category_id, user.sub
                )
                if category_exists:
                    await conn.execute(
                        "INSERT INTO saved_article_categories (saved_article_id, category_id) VALUES ($1, $2)",
                        article_id, category_id
                    )
        
        # Return the updated saved article with categories
        return await get_saved_article_with_categories(conn, article_id, user.sub)
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error assigning categories: {e}")
        raise HTTPException(status_code=500, detail="Failed to assign categories")
    finally:
        await conn.close()
