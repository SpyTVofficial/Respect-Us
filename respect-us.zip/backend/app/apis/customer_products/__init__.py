
from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
from datetime import date, datetime
from decimal import Decimal
import asyncpg
import json
import databutton as db
from app.auth import AuthorizedUser

router = APIRouter(prefix="/customer-products")

# Pydantic Models for Customer Products

class CustomerProduct(BaseModel):
    """Customer product/technology information"""
    id: Optional[int] = None
    customer_id: int
    product_name: str = Field(..., min_length=1, max_length=500)
    product_category: Optional[str] = None
    product_type: str = Field(..., pattern="^(goods|technology|software|service|dual_use)$")
    eccn_classification: Optional[str] = None
    ccl_category: Optional[str] = None
    description: Optional[str] = None
    technical_specifications: Optional[str] = None
    control_status: str = Field(default="uncontrolled", pattern="^(uncontrolled|controlled|restricted|prohibited)$")
    export_license_required: bool = Field(default=False)
    end_use_statement_required: bool = Field(default=False)
    risk_assessment: Dict[str, Any] = Field(default_factory=dict)
    compliance_notes: Optional[str] = None
    last_review_date: Optional[date] = None
    next_review_date: Optional[date] = None
    created_by: Optional[str] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

class ProductReviewUpdate(BaseModel):
    """Product review update information"""
    control_status: Optional[str] = None
    export_license_required: Optional[bool] = None
    compliance_notes: Optional[str] = None
    next_review_date: Optional[date] = None

# Product Management Endpoints

@router.post("/products", response_model=CustomerProduct)
async def create_product(product: CustomerProduct, user: AuthorizedUser) -> CustomerProduct:
    """Create a new customer product/technology record"""
    print(f"📝 Creating product for customer: {product.customer_id}")
    
    try:
        db_url = db.secrets.get("DATABASE_URL_DEV")
        conn = await asyncpg.connect(db_url)
        
        try:
            # Check if customer exists
            customer_exists = await conn.fetchval(
                "SELECT EXISTS(SELECT 1 FROM customer_profiles WHERE id = $1)",
                product.customer_id
            )
            
            if not customer_exists:
                raise HTTPException(status_code=404, detail="Customer not found")
            
            # Insert product
            row = await conn.fetchrow("""
                INSERT INTO customer_products (
                    customer_id, product_name, product_category, product_type,
                    eccn_classification, ccl_category, description, technical_specifications,
                    control_status, export_license_required, end_use_statement_required,
                    risk_assessment, compliance_notes, last_review_date, next_review_date, created_by
                ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16)
                RETURNING id, created_at, updated_at
            """, 
                product.customer_id, product.product_name, product.product_category, product.product_type,
                product.eccn_classification, product.ccl_category, product.description, product.technical_specifications,
                product.control_status, product.export_license_required, product.end_use_statement_required,
                json.dumps(product.risk_assessment), product.compliance_notes, product.last_review_date,
                product.next_review_date, user.sub
            )
            
            # Return created product
            product.id = row['id']
            product.created_by = user.sub
            product.created_at = row['created_at']
            product.updated_at = row['updated_at']
            
            print(f"✅ Product created successfully with ID: {product.id}")
            return product
            
        finally:
            await conn.close()
            
    except Exception as e:
        print(f"❌ Error creating product: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to create product: {str(e)}")

@router.get("/products", response_model=List[CustomerProduct])
async def list_products(
    user: AuthorizedUser,
    customer_id: Optional[int] = Query(default=None),
    product_type: Optional[str] = Query(default=None),
    control_status: Optional[str] = Query(default=None),
    search: Optional[str] = Query(default=None),
    limit: int = Query(default=50, le=1000),
    offset: int = Query(default=0, ge=0)
) -> List[CustomerProduct]:
    """List customer products with filtering"""
    print(f"📋 Listing products (limit: {limit}, offset: {offset})")
    
    try:
        db_url = db.secrets.get("DATABASE_URL_DEV")
        conn = await asyncpg.connect(db_url)
        
        try:
            # Build dynamic query
            where_conditions = []
            params = []
            param_count = 0
            
            if customer_id:
                param_count += 1
                where_conditions.append(f"customer_id = ${param_count}")
                params.append(customer_id)
            
            if product_type:
                param_count += 1
                where_conditions.append(f"product_type = ${param_count}")
                params.append(product_type)
                
            if control_status:
                param_count += 1
                where_conditions.append(f"control_status = ${param_count}")
                params.append(control_status)
                
            if search:
                param_count += 1
                where_conditions.append(f"(product_name ILIKE ${param_count} OR description ILIKE ${param_count} OR eccn_classification ILIKE ${param_count})")
                params.append(f"%{search}%")
            
            where_clause = " AND ".join(where_conditions) if where_conditions else "1=1"
            
            param_count += 1
            limit_param = f"${param_count}"
            params.append(limit)
            
            param_count += 1
            offset_param = f"${param_count}"
            params.append(offset)
            
            query = f"""
                SELECT * FROM customer_products 
                WHERE {where_clause}
                ORDER BY product_name, created_at DESC
                LIMIT {limit_param} OFFSET {offset_param}
            """
            
            rows = await conn.fetch(query, *params)
            
            products = []
            for row in rows:
                product = CustomerProduct(
                    id=row['id'],
                    customer_id=row['customer_id'],
                    product_name=row['product_name'],
                    product_category=row['product_category'],
                    product_type=row['product_type'],
                    eccn_classification=row['eccn_classification'],
                    ccl_category=row['ccl_category'],
                    description=row['description'],
                    technical_specifications=row['technical_specifications'],
                    control_status=row['control_status'],
                    export_license_required=row['export_license_required'],
                    end_use_statement_required=row['end_use_statement_required'],
                    risk_assessment=json.loads(row['risk_assessment']) if row['risk_assessment'] else {},
                    compliance_notes=row['compliance_notes'],
                    last_review_date=row['last_review_date'],
                    next_review_date=row['next_review_date'],
                    created_by=row['created_by'],
                    created_at=row['created_at'],
                    updated_at=row['updated_at']
                )
                products.append(product)
            
            print(f"✅ Found {len(products)} products")
            return products
            
        finally:
            await conn.close()
            
    except Exception as e:
        print(f"❌ Error listing products: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to list products: {str(e)}")

@router.put("/products/{product_id}", response_model=CustomerProduct)
async def update_product(product_id: int, product: CustomerProduct, user: AuthorizedUser) -> CustomerProduct:
    """Update an existing product"""
    print(f"📝 Updating product ID: {product_id}")
    
    try:
        db_url = db.secrets.get("DATABASE_URL_DEV")
        conn = await asyncpg.connect(db_url)
        
        try:
            # Check if product exists
            exists = await conn.fetchval(
                "SELECT EXISTS(SELECT 1 FROM customer_products WHERE id = $1)",
                product_id
            )
            
            if not exists:
                raise HTTPException(status_code=404, detail="Product not found")
            
            # Update product
            row = await conn.fetchrow("""
                UPDATE customer_products SET
                    product_name = $2, product_category = $3, product_type = $4,
                    eccn_classification = $5, ccl_category = $6, description = $7,
                    technical_specifications = $8, control_status = $9, export_license_required = $10,
                    end_use_statement_required = $11, risk_assessment = $12, compliance_notes = $13,
                    last_review_date = $14, next_review_date = $15, updated_at = NOW()
                WHERE id = $1
                RETURNING created_by, created_at, updated_at
            """,
                product_id, product.product_name, product.product_category, product.product_type,
                product.eccn_classification, product.ccl_category, product.description,
                product.technical_specifications, product.control_status, product.export_license_required,
                product.end_use_statement_required, json.dumps(product.risk_assessment),
                product.compliance_notes, product.last_review_date, product.next_review_date
            )
            
            # Return updated product
            product.id = product_id
            product.created_by = row['created_by']
            product.created_at = row['created_at']
            product.updated_at = row['updated_at']
            
            print("✅ Product updated successfully")
            return product
            
        finally:
            await conn.close()
            
    except Exception as e:
        print(f"❌ Error updating product: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to update product: {str(e)}")

@router.patch("/products/{product_id}/review", response_model=CustomerProduct)
async def update_product_review(product_id: int, review_update: ProductReviewUpdate, user: AuthorizedUser) -> CustomerProduct:
    """Update product review status and compliance information"""
    print(f"📝 Updating product review for ID: {product_id}")
    
    try:
        db_url = db.secrets.get("DATABASE_URL_DEV")
        conn = await asyncpg.connect(db_url)
        
        try:
            # Check if product exists and get current data
            current_product = await conn.fetchrow(
                "SELECT * FROM customer_products WHERE id = $1",
                product_id
            )
            
            if not current_product:
                raise HTTPException(status_code=404, detail="Product not found")
            
            # Build update query dynamically based on provided fields
            update_fields = []
            params = [product_id]
            param_count = 1
            
            if review_update.control_status is not None:
                param_count += 1
                update_fields.append(f"control_status = ${param_count}")
                params.append(review_update.control_status)
                
            if review_update.export_license_required is not None:
                param_count += 1
                update_fields.append(f"export_license_required = ${param_count}")
                params.append(review_update.export_license_required)
                
            if review_update.compliance_notes is not None:
                param_count += 1
                update_fields.append(f"compliance_notes = ${param_count}")
                params.append(review_update.compliance_notes)
                
            if review_update.next_review_date is not None:
                param_count += 1
                update_fields.append(f"next_review_date = ${param_count}")
                params.append(review_update.next_review_date)
            
            # Always update last_review_date and updated_at
            param_count += 1
            update_fields.append(f"last_review_date = ${param_count}")
            params.append(date.today())
            
            update_fields.append("updated_at = NOW()")
            
            if not update_fields:
                raise HTTPException(status_code=400, detail="No fields to update")
            
            # Execute update
            row = await conn.fetchrow(f"""
                UPDATE customer_products SET {', '.join(update_fields)}
                WHERE id = $1
                RETURNING *
            """, *params)
            
            # Return updated product
            product = CustomerProduct(
                id=row['id'],
                customer_id=row['customer_id'],
                product_name=row['product_name'],
                product_category=row['product_category'],
                product_type=row['product_type'],
                eccn_classification=row['eccn_classification'],
                ccl_category=row['ccl_category'],
                description=row['description'],
                technical_specifications=row['technical_specifications'],
                control_status=row['control_status'],
                export_license_required=row['export_license_required'],
                end_use_statement_required=row['end_use_statement_required'],
                risk_assessment=json.loads(row['risk_assessment']) if row['risk_assessment'] else {},
                compliance_notes=row['compliance_notes'],
                last_review_date=row['last_review_date'],
                next_review_date=row['next_review_date'],
                created_by=row['created_by'],
                created_at=row['created_at'],
                updated_at=row['updated_at']
            )
            
            print("✅ Product review updated successfully")
            return product
            
        finally:
            await conn.close()
            
    except Exception as e:
        print(f"❌ Error updating product review: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to update product review: {str(e)}")

@router.delete("/products/{product_id}")
async def delete_product(product_id: int, user: AuthorizedUser) -> Dict[str, str]:
    """Delete a product"""
    print(f"🗑️ Deleting product ID: {product_id}")
    
    try:
        db_url = db.secrets.get("DATABASE_URL_DEV")
        conn = await asyncpg.connect(db_url)
        
        try:
            # Check if product exists
            exists = await conn.fetchval(
                "SELECT EXISTS(SELECT 1 FROM customer_products WHERE id = $1)",
                product_id
            )
            
            if not exists:
                raise HTTPException(status_code=404, detail="Product not found")
            
            # Delete product (cascade will handle related records)
            await conn.execute(
                "DELETE FROM customer_products WHERE id = $1",
                product_id
            )
            
            print("✅ Product deleted successfully")
            return {"message": "Product deleted successfully"}
            
        finally:
            await conn.close()
            
    except Exception as e:
        print(f"❌ Error deleting product: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to delete product: {str(e)}")

@router.get("/products/categories", response_model=List[str])
async def get_customer_product_categories(user: AuthorizedUser) -> List[str]:
    """Get list of unique product categories"""
    try:
        db_url = db.secrets.get("DATABASE_URL_DEV")
        conn = await asyncpg.connect(db_url)
        
        try:
            rows = await conn.fetch("""
                SELECT DISTINCT product_category 
                FROM customer_products 
                WHERE product_category IS NOT NULL AND product_category != ''
                ORDER BY product_category
            """)
            
            categories = [row['product_category'] for row in rows]
            return categories
            
        finally:
            await conn.close()
            
    except Exception as e:
        print(f"❌ Error fetching product categories: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to fetch product categories: {str(e)}")
