
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import List, Optional, Dict, Any
import asyncpg
import databutton as db
from app.auth import AuthorizedUser
from app.env import Mode, mode
import json
from datetime import datetime

router = APIRouter(prefix="/doc-pricing")

class DocumentPricingUpdate(BaseModel):
    document_id: int
    credit_cost: Optional[int] = None
    is_premium: bool = False
    pricing_tier: str = "free"

class BulkPricingUpdate(BaseModel):
    document_ids: List[int]
    credit_cost: Optional[int] = None
    is_premium: bool = False
    pricing_tier: str = "free"

class DefaultPricingRule(BaseModel):
    regulation_type: Optional[str] = None
    country_jurisdiction: Optional[str] = None
    pricing_tier: str = "free"
    credit_cost: Optional[int] = None
    is_premium: bool = False

class DocumentPricingResponse(BaseModel):
    id: int
    title: str
    credit_cost: Optional[int]
    is_premium: bool
    pricing_tier: str
    regulation_type: Optional[str]
    country_jurisdiction: Optional[str]
    publishing_status: str

class PricingAnalyticsResponse(BaseModel):
    pricing_tier: str
    is_premium: bool
    document_count: int
    avg_credit_cost: Optional[float]
    min_credit_cost: Optional[int]
    max_credit_cost: Optional[int]
    priced_documents: int

# Database connection
async def get_db_connection():
    """Get database connection based on environment"""
    if mode == Mode.PROD:
        database_url = db.secrets.get("DATABASE_URL_PROD")
    else:
        database_url = db.secrets.get("DATABASE_URL_DEV")
    return await asyncpg.connect(database_url)

@router.get("/document-pricing")
async def get_document_pricing(user: AuthorizedUser, page: int = 1, limit: int = 50) -> List[DocumentPricingResponse]:
    """Get paginated list of documents with their pricing information"""
    conn = await get_db_connection()
    try:
        offset = (page - 1) * limit
        
        query = """
            SELECT id, title, credit_cost, is_premium, pricing_tier, 
                   regulation_type, country_jurisdiction, publishing_status
            FROM kb_documents 
            ORDER BY created_at DESC
            LIMIT $1 OFFSET $2
        """
        
        rows = await conn.fetch(query, limit, offset)
        
        return [
            DocumentPricingResponse(
                id=row['id'],
                title=row['title'],
                credit_cost=row['credit_cost'],
                is_premium=row['is_premium'],
                pricing_tier=row['pricing_tier'],
                regulation_type=row['regulation_type'],
                country_jurisdiction=row['country_jurisdiction'],
                publishing_status=row['publishing_status']
            ) for row in rows
        ]
    finally:
        await conn.close()

@router.put("/document-pricing/{document_id}")
async def update_document_pricing(document_id: int, request: DocumentPricingUpdate, user: AuthorizedUser) -> dict:
    """Update pricing for a specific document"""
    conn = await get_db_connection()
    try:
        # Check if document exists
        doc_check = await conn.fetchrow("SELECT id FROM kb_documents WHERE id = $1", document_id)
        if not doc_check:
            raise HTTPException(status_code=404, detail="Document not found")
        
        # Update pricing
        update_query = """
            UPDATE kb_documents 
            SET credit_cost = $1, is_premium = $2, pricing_tier = $3, updated_at = NOW()
            WHERE id = $4
        """
        
        await conn.execute(update_query, request.credit_cost, request.is_premium, request.pricing_tier, document_id)
        
        return {"success": True, "message": "Document pricing updated successfully"}
        
    finally:
        await conn.close()

@router.put("/bulk-pricing")
async def update_bulk_pricing(request: BulkPricingUpdate, user: AuthorizedUser) -> dict:
    """Update pricing for multiple documents"""
    conn = await get_db_connection()
    try:
        # Verify all documents exist
        existing_docs = await conn.fetch(
            "SELECT id FROM kb_documents WHERE id = ANY($1::int[])",
            request.document_ids
        )
        
        existing_ids = [row['id'] for row in existing_docs]
        missing_ids = [doc_id for doc_id in request.document_ids if doc_id not in existing_ids]
        
        if missing_ids:
            raise HTTPException(
                status_code=404, 
                detail=f"Documents not found: {missing_ids}"
            )
        
        # Update pricing for all documents
        update_query = """
            UPDATE kb_documents 
            SET credit_cost = $1, is_premium = $2, pricing_tier = $3, updated_at = NOW()
            WHERE id = ANY($4::int[])
        """
        
        result = await conn.execute(
            update_query, 
            request.credit_cost, 
            request.is_premium, 
            request.pricing_tier, 
            request.document_ids
        )
        
        return {
            "success": True, 
            "message": f"Updated pricing for {len(request.document_ids)} documents",
            "updated_count": len(request.document_ids)
        }
        
    finally:
        await conn.close()

@router.post("/apply-default-pricing")
async def apply_default_pricing(request: DefaultPricingRule, user: AuthorizedUser) -> dict:
    """Apply default pricing rules to documents matching criteria"""
    conn = await get_db_connection()
    try:
        # Build query based on criteria
        where_conditions = []
        params = []
        param_count = 0
        
        if request.regulation_type:
            param_count += 1
            where_conditions.append(f"regulation_type = ${param_count}")
            params.append(request.regulation_type)
        
        if request.country_jurisdiction:
            param_count += 1
            where_conditions.append(f"country_jurisdiction = ${param_count}")
            params.append(request.country_jurisdiction)
        
        # If no criteria provided, return error
        if not where_conditions:
            raise HTTPException(
                status_code=400, 
                detail="At least one criteria (regulation_type or country_jurisdiction) must be provided"
            )
        
        where_clause = " AND ".join(where_conditions)
        
        # Add pricing parameters
        param_count += 1
        params.append(request.credit_cost)
        param_count += 1
        params.append(request.is_premium)
        param_count += 1
        params.append(request.pricing_tier)
        
        update_query = f"""
            UPDATE kb_documents 
            SET credit_cost = ${param_count - 2}, is_premium = ${param_count - 1}, pricing_tier = ${param_count}, updated_at = NOW()
            WHERE {where_clause}
        """
        
        result = await conn.execute(update_query, *params)
        
        # Parse the result to get affected row count
        affected_rows = int(result.split()[1]) if result.startswith('UPDATE') else 0
        
        return {
            "success": True,
            "message": f"Applied default pricing to {affected_rows} documents",
            "affected_count": affected_rows
        }
        
    finally:
        await conn.close()

@router.get("/pricing-analytics")
async def get_pricing_analytics(user: AuthorizedUser) -> List[PricingAnalyticsResponse]:
    """Get pricing analytics from the view"""
    conn = await get_db_connection()
    try:
        query = "SELECT * FROM kb_document_pricing_analytics ORDER BY pricing_tier, is_premium"
        rows = await conn.fetch(query)
        
        return [
            PricingAnalyticsResponse(
                pricing_tier=row['pricing_tier'],
                is_premium=row['is_premium'],
                document_count=row['document_count'],
                avg_credit_cost=float(row['avg_credit_cost']) if row['avg_credit_cost'] else None,
                min_credit_cost=row['min_credit_cost'],
                max_credit_cost=row['max_credit_cost'],
                priced_documents=row['priced_documents']
            ) for row in rows
        ]
        
    finally:
        await conn.close()

@router.get("/document/{document_id}/pricing")
async def get_document_pricing_detail(document_id: int, user: AuthorizedUser) -> DocumentPricingResponse:
    """Get pricing details for a specific document"""
    conn = await get_db_connection()
    try:
        query = """
            SELECT id, title, credit_cost, is_premium, pricing_tier, 
                   regulation_type, country_jurisdiction, publishing_status
            FROM kb_documents 
            WHERE id = $1
        """
        
        row = await conn.fetchrow(query, document_id)
        
        if not row:
            raise HTTPException(status_code=404, detail="Document not found")
        
        return DocumentPricingResponse(
            id=row['id'],
            title=row['title'],
            credit_cost=row['credit_cost'],
            is_premium=row['is_premium'],
            pricing_tier=row['pricing_tier'],
            regulation_type=row['regulation_type'],
            country_jurisdiction=row['country_jurisdiction'],
            publishing_status=row['publishing_status']
        )
        
    finally:
        await conn.close()
