

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import List, Optional, Dict, Any
import asyncpg
import databutton as db
from app.auth import AuthorizedUser
from app.env import Mode, mode
import json
from datetime import datetime
import io
from openpyxl import Workbook, load_workbook
from fastapi.responses import Response

router = APIRouter(prefix="/doc-sections")

class DocumentSection(BaseModel):
    id: Optional[int] = None
    document_id: int
    section_number: Optional[str] = None
    section_title: Optional[str] = None
    section_content: Optional[str] = None
    parent_section_id: Optional[int] = None
    display_order: int = 0
    created_at: Optional[str] = None

class CreateSectionRequest(BaseModel):
    document_id: int
    section_number: Optional[str] = None
    section_title: Optional[str] = None
    section_content: Optional[str] = None
    parent_section_id: Optional[int] = None
    display_order: int = 0

class UpdateSectionRequest(BaseModel):
    section_number: Optional[str] = None
    section_title: Optional[str] = None
    section_content: Optional[str] = None
    parent_section_id: Optional[int] = None
    display_order: Optional[int] = None

class BulkUpdateOrderRequest(BaseModel):
    section_orders: List[dict]  # [{"id": 1, "display_order": 0}, ...]

class DocumentSectionsResponse(BaseModel):
    sections: List[DocumentSection]
    total_count: int
    sections_not_applicable: bool = False

class BulkImportRequest(BaseModel):
    document_id: int
    sections: List[dict]  # [{"section_number": "1", "section_title": "...", "section_content": "..."}]
    replace_existing: bool = False

class SectionsNotApplicableRequest(BaseModel):
    sections_not_applicable: bool

class SectionsNotApplicableResponse(BaseModel):
    sections_not_applicable: bool
    message: str

# Database connection
async def get_db_connection():
    """Get database connection based on environment"""
    if mode == Mode.PROD:
        database_url = db.secrets.get("DATABASE_URL_PROD")
    else:
        database_url = db.secrets.get("DATABASE_URL_DEV")
    return await asyncpg.connect(database_url)

@router.get("/documents/{document_id}/sections")
async def get_document_sections_admin(document_id: int, user: AuthorizedUser) -> DocumentSectionsResponse:
    """Get all sections for a document (admin version with all fields)"""
    try:
        conn = await get_db_connection()
        try:
            # Verify document exists and get sections_not_applicable flag
            doc_query = "SELECT id, sections_not_applicable FROM kb_documents WHERE id = $1"
            doc_result = await conn.fetchrow(doc_query, document_id)
            
            if not doc_result:
                raise HTTPException(status_code=404, detail="Document not found")
            
            sections_not_applicable = doc_result['sections_not_applicable'] or False
            
            query = """
                SELECT id, document_id, section_number, section_title, section_content, 
                       parent_section_id, display_order, created_at
                FROM kb_document_sections 
                WHERE document_id = $1
                ORDER BY display_order, id
            """
            rows = await conn.fetch(query, document_id)
            
            sections = [
                DocumentSection(
                    id=row['id'],
                    document_id=row['document_id'],
                    section_number=row['section_number'],
                    section_title=row['section_title'],
                    section_content=row['section_content'],
                    parent_section_id=row['parent_section_id'],
                    display_order=row['display_order']
                )
                for row in rows
            ]
            
            return DocumentSectionsResponse(
                sections=sections,
                total_count=len(sections),
                sections_not_applicable=sections_not_applicable
            )
            
        finally:
            await conn.close()
            
    except Exception as e:
        print(f"Error fetching document sections: {e}")
        raise HTTPException(status_code=500, detail="Failed to fetch document sections")

@router.post("/documents/{document_id}/sections")
async def create_document_section(document_id: int, request: CreateSectionRequest, user: AuthorizedUser) -> DocumentSection:
    """Create a new document section"""
    try:
        conn = await get_db_connection()
        try:
            # Verify document exists and get current status
            doc_query = "SELECT id, status FROM kb_documents WHERE id = $1"
            doc_result = await conn.fetchrow(doc_query, document_id)
            
            if not doc_result:
                raise HTTPException(status_code=404, detail="Document not found")
            
            # Get next display order if not provided
            if request.display_order == 0:
                order_query = "SELECT COALESCE(MAX(display_order), 0) + 1 FROM kb_document_sections WHERE document_id = $1"
                next_order = await conn.fetchval(order_query, document_id)
                request.display_order = next_order
            
            # Use transaction to ensure both section creation and status update happen together
            async with conn.transaction():
                query = """
                    INSERT INTO kb_document_sections 
                    (document_id, section_number, section_title, section_content, parent_section_id, display_order)
                    VALUES ($1, $2, $3, $4, $5, $6)
                    RETURNING id, document_id, section_number, section_title, section_content, parent_section_id, display_order
                """
                
                row = await conn.fetchrow(
                    query,
                    document_id,
                    request.section_number,
                    request.section_title,
                    request.section_content,
                    request.parent_section_id,
                    request.display_order
                )
                
                # If document is in draft status, update it to pending_validation
                # This ensures sections become visible in the UI
                if doc_result['status'] == 'draft':
                    await conn.execute(
                        "UPDATE kb_documents SET status = 'pending_validation' WHERE id = $1",
                        document_id
                    )
                
                return DocumentSection(
                    id=row['id'],
                    document_id=row['document_id'],
                    section_number=row['section_number'],
                    section_title=row['section_title'],
                    section_content=row['section_content'],
                    parent_section_id=row['parent_section_id'],
                    display_order=row['display_order']
                )
            
        finally:
            await conn.close()
            
    except Exception as e:
        print(f"Error creating document section: {e}")
        raise HTTPException(status_code=500, detail="Failed to create document section")

@router.put("/sections/{section_id}")
async def update_document_section(section_id: int, request: UpdateSectionRequest, user: AuthorizedUser) -> DocumentSection:
    """Update an existing document section"""
    try:
        conn = await get_db_connection()
        try:
            # Check if section exists
            check_query = "SELECT id, document_id FROM kb_document_sections WHERE id = $1"
            existing = await conn.fetchrow(check_query, section_id)
            
            if not existing:
                raise HTTPException(status_code=404, detail="Section not found")
            
            # Build update query dynamically based on provided fields
            update_fields = []
            values = []
            param_count = 1
            
            if request.section_number is not None:
                update_fields.append(f"section_number = ${param_count}")
                values.append(request.section_number)
                param_count += 1
            
            if request.section_title is not None:
                update_fields.append(f"section_title = ${param_count}")
                values.append(request.section_title)
                param_count += 1
            
            if request.section_content is not None:
                update_fields.append(f"section_content = ${param_count}")
                values.append(request.section_content)
                param_count += 1
            
            if request.parent_section_id is not None:
                update_fields.append(f"parent_section_id = ${param_count}")
                values.append(request.parent_section_id)
                param_count += 1
            
            if request.display_order is not None:
                update_fields.append(f"display_order = ${param_count}")
                values.append(request.display_order)
                param_count += 1
            
            if not update_fields:
                raise HTTPException(status_code=400, detail="No fields to update")
            
            values.append(section_id)
            
            query = f"""
                UPDATE kb_document_sections 
                SET {', '.join(update_fields)}
                WHERE id = ${param_count}
                RETURNING id, document_id, section_number, section_title, section_content, parent_section_id, display_order
            """
            
            row = await conn.fetchrow(query, *values)
            
            return DocumentSection(
                id=row['id'],
                document_id=row['document_id'],
                section_number=row['section_number'],
                section_title=row['section_title'],
                section_content=row['section_content'],
                parent_section_id=row['parent_section_id'],
                display_order=row['display_order']
            )
            
        finally:
            await conn.close()
            
    except Exception as e:
        print(f"Error updating document section: {e}")
        raise HTTPException(status_code=500, detail="Failed to update document section")

@router.delete("/sections/{section_id}")
async def delete_document_section(section_id: int, user: AuthorizedUser) -> dict:
    """Delete a document section"""
    try:
        conn = await get_db_connection()
        try:
            # Check if section exists
            check_query = "SELECT id FROM kb_document_sections WHERE id = $1"
            existing = await conn.fetchrow(check_query, section_id)
            
            if not existing:
                raise HTTPException(status_code=404, detail="Section not found")
            
            # Delete the section
            delete_query = "DELETE FROM kb_document_sections WHERE id = $1"
            await conn.execute(delete_query, section_id)
            
            return {"success": True, "message": "Section deleted successfully"}
            
        finally:
            await conn.close()
            
    except Exception as e:
        print(f"Error deleting document section: {e}")
        raise HTTPException(status_code=500, detail="Failed to delete document section")

@router.put("/documents/{document_id}/sections/reorder")
async def reorder_sections(document_id: int, request: BulkUpdateOrderRequest, user: AuthorizedUser) -> dict:
    """Bulk update section display orders for drag-and-drop reordering"""
    try:
        conn = await get_db_connection()
        try:
            # Verify document exists
            doc_query = "SELECT id FROM kb_documents WHERE id = $1"
            doc_result = await conn.fetchrow(doc_query, document_id)
            
            if not doc_result:
                raise HTTPException(status_code=404, detail="Document not found")
            
            # Update all section orders in a transaction
            async with conn.transaction():
                for section_order in request.section_orders:
                    section_id = section_order.get('id')
                    display_order = section_order.get('display_order')
                    
                    if section_id and display_order is not None:
                        await conn.execute(
                            "UPDATE kb_document_sections SET display_order = $1 WHERE id = $2 AND document_id = $3",
                            display_order, section_id, document_id
                        )
            
            return {"success": True, "message": "Section order updated successfully"}
            
        finally:
            await conn.close()
            
    except Exception as e:
        print(f"Error reordering sections: {e}")
        raise HTTPException(status_code=500, detail="Failed to reorder sections")

@router.post("/documents/{document_id}/sections/bulk-import")
async def bulk_import_sections(document_id: int, request: BulkImportRequest, user: AuthorizedUser) -> dict:
    """Bulk import sections from structured data"""
    try:
        conn = await get_db_connection()
        try:
            # Verify document exists
            doc_query = "SELECT id FROM kb_documents WHERE id = $1"
            doc_result = await conn.fetchrow(doc_query, document_id)
            
            if not doc_result:
                raise HTTPException(status_code=404, detail="Document not found")
            
            async with conn.transaction():
                # If replace_existing is True, delete all existing sections
                if request.replace_existing:
                    await conn.execute("DELETE FROM kb_document_sections WHERE document_id = $1", document_id)
                
                # Insert new sections
                for i, section_data in enumerate(request.sections):
                    await conn.execute(
                        """
                        INSERT INTO kb_document_sections 
                        (document_id, section_number, section_title, section_content, display_order)
                        VALUES ($1, $2, $3, $4, $5)
                        """,
                        document_id,
                        section_data.get('section_number'),
                        section_data.get('section_title'),
                        section_data.get('section_content'),
                        section_data.get('display_order', i)
                    )
            
            return {
                "success": True, 
                "message": f"Successfully imported {len(request.sections)} sections",
                "sections_imported": len(request.sections)
            }
            
        finally:
            await conn.close()
            
    except Exception as e:
        print(f"Error bulk importing sections: {e}")
        raise HTTPException(status_code=500, detail="Failed to bulk import sections")

@router.get("/documents/{document_id}/sections/export")
async def export_sections(document_id: int, user: AuthorizedUser) -> dict:
    """Export document sections in a structured format for backup/transfer"""
    try:
        conn = await get_db_connection()
        try:
            # Get document info
            doc_query = "SELECT title FROM kb_documents WHERE id = $1"
            doc_result = await conn.fetchrow(doc_query, document_id)
            
            if not doc_result:
                raise HTTPException(status_code=404, detail="Document not found")
            
            # Get all sections
            sections_query = """
                SELECT section_number, section_title, section_content, parent_section_id, display_order
                FROM kb_document_sections 
                WHERE document_id = $1
                ORDER BY display_order, id
            """
            rows = await conn.fetch(sections_query, document_id)
            
            sections = [
                {
                    "section_number": row['section_number'],
                    "section_title": row['section_title'],
                    "section_content": row['section_content'],
                    "parent_section_id": row['parent_section_id'],
                    "display_order": row['display_order']
                }
                for row in rows
            ]
            
            return {
                "document_id": document_id,
                "document_title": doc_result['title'],
                "sections_count": len(sections),
                "sections": sections,
                "exported_at": "now"
            }
            
        finally:
            await conn.close()
            
    except Exception as e:
        print(f"Error exporting sections: {e}")
        raise HTTPException(status_code=500, detail="Failed to export sections")

@router.post("/documents/{document_id}/sections-not-applicable")
async def update_sections_not_applicable(document_id: int, request: SectionsNotApplicableRequest, user: AuthorizedUser) -> SectionsNotApplicableResponse:
    """Update the sections_not_applicable flag for a document"""
    try:
        conn = await get_db_connection()
        try:
            # Verify document exists
            doc_query = "SELECT id FROM kb_documents WHERE id = $1"
            doc_result = await conn.fetchrow(doc_query, document_id)
            
            if not doc_result:
                raise HTTPException(status_code=404, detail="Document not found")
            
            # Update the flag
            update_query = "UPDATE kb_documents SET sections_not_applicable = $1 WHERE id = $2"
            await conn.execute(update_query, request.sections_not_applicable, document_id)
            
            message = "Sections marked as not applicable" if request.sections_not_applicable else "Sections marked as applicable"
            
            return SectionsNotApplicableResponse(
                sections_not_applicable=request.sections_not_applicable,
                message=message
            )
            
        finally:
            await conn.close()
            
    except Exception as e:
        print(f"Error updating sections_not_applicable: {e}")
        raise HTTPException(status_code=500, detail="Failed to update sections not applicable flag")

@router.get("/documents/{document_id}/sections-not-applicable")
async def get_sections_not_applicable(document_id: int, user: AuthorizedUser) -> SectionsNotApplicableResponse:
    """Get the sections_not_applicable flag for a document"""
    try:
        conn = await get_db_connection()
        try:
            # Get document and sections_not_applicable flag
            doc_query = "SELECT sections_not_applicable FROM kb_documents WHERE id = $1"
            doc_result = await conn.fetchrow(doc_query, document_id)
            
            if not doc_result:
                raise HTTPException(status_code=404, detail="Document not found")
            
            sections_not_applicable = doc_result['sections_not_applicable'] or False
            
            return SectionsNotApplicableResponse(
                sections_not_applicable=sections_not_applicable,
                message="Sections not applicable status retrieved"
            )
            
        finally:
            await conn.close()
            
    except Exception as e:
        print(f"Error fetching sections_not_applicable: {e}")
        raise HTTPException(status_code=500, detail="Failed to fetch sections not applicable flag")
