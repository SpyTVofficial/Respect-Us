

from fastapi import APIRouter, HTTPException, BackgroundTasks
from pydantic import BaseModel, HttpUrl
from typing import List, Dict, Any, Optional
import asyncpg
import databutton as db
from app.auth import AuthorizedUser
from app.env import Mode, mode
import httpx
import asyncio
from datetime import datetime, timedelta
import hashlib
import json
import re

router = APIRouter(prefix="/automation")

# Database connection helper
async def get_db_connection():
    if mode == Mode.PROD:
        database_url = db.secrets.get("DATABASE_URL_PROD")
    else:
        database_url = db.secrets.get("DATABASE_URL_DEV")
    return await asyncpg.connect(database_url)

# Models
class AutomatedFeedSource(BaseModel):
    name: str
    description: str
    source_url: HttpUrl
    source_type: str  # rss, api, scraper, manual
    jurisdiction: str
    document_types: List[str]
    update_frequency: str  # hourly, daily, weekly, monthly
    is_active: bool = True
    last_check: Optional[datetime] = None
    xpath_selectors: Optional[Dict[str, str]] = None  # For web scraping
    api_config: Optional[Dict[str, Any]] = None  # For API-based feeds

class FeedSourceResponse(BaseModel):
    id: int
    name: str
    description: str
    source_url: str
    source_type: str
    jurisdiction: str
    document_types: List[str]
    update_frequency: str
    is_active: bool
    last_check: Optional[datetime]
    documents_found: int
    created_at: datetime
    updated_at: datetime

class WebhookEndpoint(BaseModel):
    name: str
    description: str
    target_url: HttpUrl
    event_types: List[str]  # document_added, document_updated, feed_updated
    is_active: bool = True
    secret_token: Optional[str] = None
    custom_headers: Optional[Dict[str, str]] = None

class WebhookResponse(BaseModel):
    id: int
    name: str
    description: str
    target_url: str
    event_types: List[str]
    is_active: bool
    created_at: datetime
    last_triggered: Optional[datetime]
    success_count: int
    failure_count: int

class FeedUpdateResult(BaseModel):
    feed_id: int
    feed_name: str
    documents_processed: int
    documents_added: int
    documents_updated: int
    errors: List[str]
    duration_seconds: float
    timestamp: datetime

class AutomationAnalytics(BaseModel):
    total_feeds: int
    active_feeds: int
    total_documents_processed: int
    documents_added_today: int
    documents_added_this_week: int
    feed_success_rate: float
    average_processing_time: float
    top_performing_feeds: List[Dict[str, Any]]
    recent_updates: List[Dict[str, Any]]

class FeedHealthMetrics(BaseModel):
    feed_id: int
    feed_name: str
    uptime_percentage: float
    last_successful_update: Optional[datetime]
    consecutive_failures: int
    average_documents_per_update: float
    status: str  # healthy, warning, critical
    issues: List[str]

# Webhook and automation helper functions
async def trigger_webhooks(event_type: str, payload: Dict[str, Any]):
    """Trigger all active webhooks for a specific event type"""
    try:
        conn = await get_db_connection()
        
        webhooks = await conn.fetch(
            """
            SELECT id, name, target_url, secret_token, custom_headers
            FROM automated_webhooks
            WHERE is_active = true AND $1 = ANY(event_types)
            """,
            event_type
        )
        
        for webhook in webhooks:
            try:
                headers = {
                    "Content-Type": "application/json",
                    "User-Agent": "RespectUs-Webhook/1.0"
                }
                
                # Add custom headers
                if webhook['custom_headers']:
                    headers.update(webhook['custom_headers'])
                
                # Add secret token for verification
                if webhook['secret_token']:
                    signature = hashlib.sha256(
                        (webhook['secret_token'] + json.dumps(payload)).encode()
                    ).hexdigest()
                    headers['X-RespectUs-Signature'] = f"sha256={signature}"
                
                async with httpx.AsyncClient() as client:
                    response = await client.post(
                        webhook['target_url'],
                        json={
                            "event_type": event_type,
                            "timestamp": datetime.now().isoformat(),
                            "data": payload
                        },
                        headers=headers,
                        timeout=30.0
                    )
                    
                    # Update webhook stats
                    if response.status_code < 400:
                        await conn.execute(
                            """
                            UPDATE automated_webhooks 
                            SET last_triggered = NOW(), success_count = success_count + 1
                            WHERE id = $1
                            """,
                            webhook['id']
                        )
                    else:
                        await conn.execute(
                            """
                            UPDATE automated_webhooks 
                            SET failure_count = failure_count + 1
                            WHERE id = $1
                            """,
                            webhook['id']
                        )
                        
            except Exception as e:
                print(f"Webhook {webhook['id']} failed: {e}")
                await conn.execute(
                    """
                    UPDATE automated_webhooks 
                    SET failure_count = failure_count + 1
                    WHERE id = $1
                    """,
                    webhook['id']
                )
        
        await conn.close()
        
    except Exception as e:
        print(f"Error triggering webhooks: {e}")

async def process_feed_source(feed_id: int) -> FeedUpdateResult:
    """Process a single automated feed source"""
    start_time = datetime.now()
    conn = await get_db_connection()
    
    try:
        # Get feed source details
        feed = await conn.fetchrow(
            "SELECT * FROM automated_feed_sources WHERE id = $1 AND is_active = true",
            feed_id
        )
        
        if not feed:
            raise ValueError(f"Feed {feed_id} not found or inactive")
        
        documents_processed = 0
        documents_added = 0
        documents_updated = 0
        errors = []
        
        if feed['source_type'] == 'rss':
            # Process RSS feed
            try:
                async with httpx.AsyncClient() as client:
                    response = await client.get(feed['source_url'], timeout=30.0)
                    
                    # Simple RSS parsing - in production, use feedparser
                    rss_content = response.text
                    
                    # Extract items using regex (simplified)
                    items = re.findall(
                        r'<item>(.*?)</item>', 
                        rss_content, 
                        re.DOTALL | re.IGNORECASE
                    )
                    
                    for item in items:
                        documents_processed += 1
                        
                        # Extract title, link, description
                        title_match = re.search(r'<title>(.*?)</title>', item, re.IGNORECASE)
                        link_match = re.search(r'<link>(.*?)</link>', item, re.IGNORECASE)
                        desc_match = re.search(r'<description>(.*?)</description>', item, re.IGNORECASE)
                        
                        if title_match and link_match:
                            title = title_match.group(1).strip()
                            source_url = link_match.group(1).strip()
                            description = desc_match.group(1).strip() if desc_match else ""
                            
                            # Check if document already exists
                            existing = await conn.fetchval(
                                "SELECT id FROM kb_documents WHERE source_url = $1",
                                source_url
                            )
                            
                            if not existing:
                                # Add new document
                                doc_id = await conn.fetchval(
                                    """
                                    INSERT INTO kb_documents (
                                        title, description, source_url, jurisdiction,
                                        document_type, feed_source_id, created_at
                                    ) VALUES ($1, $2, $3, $4, $5, $6, NOW())
                                    RETURNING id
                                    """,
                                    title, description, source_url, feed['jurisdiction'],
                                    feed['document_types'][0] if feed['document_types'] else 'Regulation',
                                    feed_id
                                )
                                
                                documents_added += 1
                                
                                # Trigger webhook for new document
                                await trigger_webhooks('document_added', {
                                    'document_id': doc_id,
                                    'title': title,
                                    'jurisdiction': feed['jurisdiction'],
                                    'feed_source': feed['name']
                                })
                            
            except Exception as e:
                errors.append(f"RSS processing error: {str(e)}")
        
        elif feed['source_type'] == 'api':
            # Process API-based feed
            try:
                api_config = feed['api_config'] or {}
                headers = api_config.get('headers', {})
                params = api_config.get('params', {})
                
                async with httpx.AsyncClient() as client:
                    response = await client.get(
                        feed['source_url'],
                        headers=headers,
                        params=params,
                        timeout=30.0
                    )
                    
                    data = response.json()
                    
                    # Process API response based on configuration
                    items_path = api_config.get('items_path', 'items')
                    items = data.get(items_path, [])
                    
                    for item in items:
                        documents_processed += 1
                        
                        title = item.get('title', 'Untitled')
                        source_url = item.get('url', item.get('link', ''))
                        description = item.get('description', item.get('summary', ''))
                        
                        if title and source_url:
                            # Check if document exists
                            existing = await conn.fetchval(
                                "SELECT id FROM kb_documents WHERE source_url = $1",
                                source_url
                            )
                            
                            if not existing:
                                doc_id = await conn.fetchval(
                                    """
                                    INSERT INTO kb_documents (
                                        title, description, source_url, jurisdiction,
                                        document_type, feed_source_id, created_at
                                    ) VALUES ($1, $2, $3, $4, $5, $6, NOW())
                                    RETURNING id
                                    """,
                                    title, description, source_url, feed['jurisdiction'],
                                    feed['document_types'][0] if feed['document_types'] else 'Regulation',
                                    feed_id
                                )
                                
                                documents_added += 1
                                
                                await trigger_webhooks('document_added', {
                                    'document_id': doc_id,
                                    'title': title,
                                    'jurisdiction': feed['jurisdiction'],
                                    'feed_source': feed['name']
                                })
                        
            except Exception as e:
                errors.append(f"API processing error: {str(e)}")
        
        # Update feed source last_check
        await conn.execute(
            "UPDATE automated_feed_sources SET last_check = NOW() WHERE id = $1",
            feed_id
        )
        
        # Log feed update result
        duration = (datetime.now() - start_time).total_seconds()
        
        await conn.execute(
            """
            INSERT INTO feed_update_logs (
                feed_id, documents_processed, documents_added, documents_updated,
                errors, duration_seconds, created_at
            ) VALUES ($1, $2, $3, $4, $5, $6, NOW())
            """,
            feed_id, documents_processed, documents_added, documents_updated,
            errors, duration
        )
        
        await conn.close()
        
        # Trigger feed updated webhook
        if documents_added > 0 or documents_updated > 0:
            await trigger_webhooks('feed_updated', {
                'feed_id': feed_id,
                'feed_name': feed['name'],
                'documents_added': documents_added,
                'documents_updated': documents_updated
            })
        
        return FeedUpdateResult(
            feed_id=feed_id,
            feed_name=feed['name'],
            documents_processed=documents_processed,
            documents_added=documents_added,
            documents_updated=documents_updated,
            errors=errors,
            duration_seconds=duration,
            timestamp=datetime.now()
        )
        
    except Exception as e:
        await conn.close()
        return FeedUpdateResult(
            feed_id=feed_id,
            feed_name="Unknown",
            documents_processed=0,
            documents_added=0,
            documents_updated=0,
            errors=[str(e)],
            duration_seconds=(datetime.now() - start_time).total_seconds(),
            timestamp=datetime.now()
        )

# API Endpoints
@router.get("/feed-sources", response_model=List[FeedSourceResponse])
async def list_feed_sources(user: AuthorizedUser):
    """List all automated feed sources"""
    try:
        conn = await get_db_connection()
        
        feeds = await conn.fetch(
            """
            SELECT f.*, 
                   COUNT(d.id) as documents_found
            FROM automated_feed_sources f
            LEFT JOIN kb_documents d ON f.id = d.feed_source_id
            GROUP BY f.id
            ORDER BY f.created_at DESC
            """
        )
        
        await conn.close()
        
        return [
            FeedSourceResponse(
                id=feed['id'],
                name=feed['name'],
                description=feed['description'],
                source_url=feed['source_url'],
                source_type=feed['source_type'],
                jurisdiction=feed['jurisdiction'],
                document_types=feed['document_types'],
                update_frequency=feed['update_frequency'],
                is_active=feed['is_active'],
                last_check=feed['last_check'],
                documents_found=feed['documents_found'],
                created_at=feed['created_at'],
                updated_at=feed['updated_at']
            )
            for feed in feeds
        ]
        
    except Exception as e:
        print(f"Error listing feed sources: {e}")
        raise HTTPException(status_code=500, detail="Failed to list feed sources")

@router.post("/feed-sources", response_model=FeedSourceResponse)
async def create_feed_source(feed: AutomatedFeedSource, user: AuthorizedUser):
    """Create a new automated feed source"""
    try:
        conn = await get_db_connection()
        
        feed_id = await conn.fetchval(
            """
            INSERT INTO automated_feed_sources (
                name, description, source_url, source_type, jurisdiction,
                document_types, update_frequency, is_active, xpath_selectors,
                api_config, created_at, updated_at
            ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, NOW(), NOW())
            RETURNING id
            """,
            feed.name, feed.description, str(feed.source_url), feed.source_type,
            feed.jurisdiction, feed.document_types, feed.update_frequency,
            feed.is_active, feed.xpath_selectors, feed.api_config
        )
        
        # Get the created feed
        created_feed = await conn.fetchrow(
            "SELECT *, 0 as documents_found FROM automated_feed_sources WHERE id = $1",
            feed_id
        )
        
        await conn.close()
        
        return FeedSourceResponse(
            id=created_feed['id'],
            name=created_feed['name'],
            description=created_feed['description'],
            source_url=created_feed['source_url'],
            source_type=created_feed['source_type'],
            jurisdiction=created_feed['jurisdiction'],
            document_types=created_feed['document_types'],
            update_frequency=created_feed['update_frequency'],
            is_active=created_feed['is_active'],
            last_check=created_feed['last_check'],
            documents_found=0,
            created_at=created_feed['created_at'],
            updated_at=created_feed['updated_at']
        )
        
    except Exception as e:
        print(f"Error creating feed source: {e}")
        raise HTTPException(status_code=500, detail="Failed to create feed source")

@router.post("/feed-sources/{feed_id}/trigger", response_model=FeedUpdateResult)
async def trigger_feed_update(feed_id: int, background_tasks: BackgroundTasks, user: AuthorizedUser):
    """Manually trigger a feed update"""
    try:
        # Process the feed
        result = await process_feed_source(feed_id)
        return result
        
    except Exception as e:
        print(f"Error triggering feed update: {e}")
        raise HTTPException(status_code=500, detail="Failed to trigger feed update")

@router.get("/webhooks", response_model=List[WebhookResponse])
async def list_webhooks(user: AuthorizedUser):
    """List all webhook endpoints"""
    try:
        conn = await get_db_connection()
        
        webhooks = await conn.fetch(
            """
            SELECT id, name, description, target_url, event_types, is_active,
                   created_at, last_triggered, success_count, failure_count
            FROM automated_webhooks
            ORDER BY created_at DESC
            """
        )
        
        await conn.close()
        
        return [
            WebhookResponse(
                id=webhook['id'],
                name=webhook['name'],
                description=webhook['description'],
                target_url=webhook['target_url'],
                event_types=webhook['event_types'],
                is_active=webhook['is_active'],
                created_at=webhook['created_at'],
                last_triggered=webhook['last_triggered'],
                success_count=webhook['success_count'],
                failure_count=webhook['failure_count']
            )
            for webhook in webhooks
        ]
        
    except Exception as e:
        print(f"Error listing webhooks: {e}")
        raise HTTPException(status_code=500, detail="Failed to list webhooks")

@router.post("/webhooks", response_model=WebhookResponse)
async def create_webhook(webhook: WebhookEndpoint, user: AuthorizedUser):
    """Create a new webhook endpoint"""
    try:
        conn = await get_db_connection()
        
        webhook_id = await conn.fetchval(
            """
            INSERT INTO automated_webhooks (
                name, description, target_url, event_types, is_active,
                secret_token, custom_headers, created_at, success_count, failure_count
            ) VALUES ($1, $2, $3, $4, $5, $6, $7, NOW(), 0, 0)
            RETURNING id
            """,
            webhook.name, webhook.description, str(webhook.target_url),
            webhook.event_types, webhook.is_active, webhook.secret_token,
            webhook.custom_headers
        )
        
        # Get the created webhook
        created_webhook = await conn.fetchrow(
            """
            SELECT id, name, description, target_url, event_types, is_active,
                   created_at, last_triggered, success_count, failure_count
            FROM automated_webhooks WHERE id = $1
            """,
            webhook_id
        )
        
        await conn.close()
        
        return WebhookResponse(
            id=created_webhook['id'],
            name=created_webhook['name'],
            description=created_webhook['description'],
            target_url=created_webhook['target_url'],
            event_types=created_webhook['event_types'],
            is_active=created_webhook['is_active'],
            created_at=created_webhook['created_at'],
            last_triggered=created_webhook['last_triggered'],
            success_count=created_webhook['success_count'],
            failure_count=created_webhook['failure_count']
        )
        
    except Exception as e:
        print(f"Error creating webhook: {e}")
        raise HTTPException(status_code=500, detail="Failed to create webhook")

@router.get("/automation-analytics", response_model=AutomationAnalytics)
async def get_automation_analytics(user: AuthorizedUser):
    """Get comprehensive automation analytics"""
    try:
        conn = await get_db_connection()
        
        # Get basic feed stats
        feed_stats = await conn.fetchrow(
            """
            SELECT COUNT(*) as total_feeds,
                   COUNT(*) FILTER (WHERE is_active = true) as active_feeds
            FROM automated_feed_sources
            """
        )
        
        # Get document processing stats
        doc_stats = await conn.fetchrow(
            """
            SELECT COUNT(*) as total_documents,
                   COUNT(*) FILTER (WHERE created_at >= CURRENT_DATE) as added_today,
                   COUNT(*) FILTER (WHERE created_at >= CURRENT_DATE - INTERVAL '7 days') as added_this_week
            FROM kb_documents
            WHERE feed_source_id IS NOT NULL
            """
        )
        
        # Get feed success rate
        success_stats = await conn.fetchrow(
            """
            SELECT 
                COUNT(*) as total_updates,
                COUNT(*) FILTER (WHERE array_length(errors, 1) IS NULL OR array_length(errors, 1) = 0) as successful_updates,
                AVG(duration_seconds) as avg_duration
            FROM feed_update_logs
            WHERE created_at >= CURRENT_DATE - INTERVAL '30 days'
            """
        )
        
        success_rate = 0.0
        if success_stats['total_updates'] and success_stats['total_updates'] > 0:
            success_rate = (success_stats['successful_updates'] / success_stats['total_updates']) * 100
        
        # Get top performing feeds
        top_feeds = await conn.fetch(
            """
            SELECT f.id, f.name, 
                   COUNT(d.id) as documents_added,
                   AVG(l.duration_seconds) as avg_duration
            FROM automated_feed_sources f
            LEFT JOIN kb_documents d ON f.id = d.feed_source_id
            LEFT JOIN feed_update_logs l ON f.id = l.feed_id
            WHERE f.is_active = true
            GROUP BY f.id, f.name
            ORDER BY documents_added DESC
            LIMIT 5
            """
        )
        
        # Get recent updates
        recent_updates = await conn.fetch(
            """
            SELECT f.name as feed_name, l.documents_added, l.created_at
            FROM feed_update_logs l
            JOIN automated_feed_sources f ON l.feed_id = f.id
            WHERE l.documents_added > 0
            ORDER BY l.created_at DESC
            LIMIT 10
            """
        )
        
        await conn.close()
        
        return AutomationAnalytics(
            total_feeds=feed_stats['total_feeds'] or 0,
            active_feeds=feed_stats['active_feeds'] or 0,
            total_documents_processed=doc_stats['total_documents'] or 0,
            documents_added_today=doc_stats['added_today'] or 0,
            documents_added_this_week=doc_stats['added_this_week'] or 0,
            feed_success_rate=success_rate,
            average_processing_time=float(success_stats['avg_duration'] or 0.0),
            top_performing_feeds=[
                {
                    "id": feed['id'],
                    "name": feed['name'],
                    "documents_added": feed['documents_added'] or 0,
                    "avg_duration": float(feed['avg_duration'] or 0.0)
                }
                for feed in top_feeds
            ],
            recent_updates=[
                {
                    "feed_name": update['feed_name'],
                    "documents_added": update['documents_added'],
                    "timestamp": update['created_at'].isoformat()
                }
                for update in recent_updates
            ]
        )
        
    except Exception as e:
        print(f"Error getting automation analytics: {e}")
        raise HTTPException(status_code=500, detail="Failed to get automation analytics")
