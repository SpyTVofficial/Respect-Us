

from fastapi import APIRouter, Query
from pydantic import BaseModel, Field
from typing import List, Optional
from datetime import datetime
from app.auth import AuthorizedUser
from app.libs.credit_wrapper import consume_credits_for_action, CreditManager

router = APIRouter()

class ProductClassification(BaseModel):
    id: str
    product_name: str
    classification_code: str  # e.g., "3A001", "EAR99", "4A003"
    control_regime: str  # "EAR", "ITAR", "Dual-Use", "Military"
    category: str
    subcategory: Optional[str] = None
    description: str
    restrictions: List[str] = []
    license_required: bool
    license_exceptions: List[str] = []
    technical_notes: Optional[str] = None
    related_codes: List[str] = []
    last_updated: datetime
    source_regulation: str
    risk_level: str  # "high", "medium", "low", "unrestricted"
    details: dict = {}

class ProductSearchRequest(BaseModel):
    query: str = Field(..., min_length=2, description="Search query for product name or description")
    classification_code: Optional[str] = Field(None, description="Filter by specific classification code")
    control_regime: Optional[str] = Field(None, description="Filter by control regime")
    category: Optional[str] = Field(None, description="Filter by product category")
    license_required: Optional[bool] = Field(None, description="Filter by license requirement")
    risk_level: Optional[str] = Field(None, description="Filter by risk level")
    limit: int = Field(default=50, le=100, description="Maximum number of results")
    include_unrestricted: bool = Field(default=True, description="Include unrestricted items")

class ProductSearchResponse(BaseModel):
    products: List[ProductClassification]
    total_count: int
    search_time_ms: int
    query_used: str
    suggestions: List[str] = []

# Sample product classification data
SAMPLE_PRODUCTS_DATA = [
    ProductClassification(
        id="prod-001",
        product_name="High-Performance Computing Processors",
        classification_code="3A001.a.1",
        control_regime="EAR",
        category="Electronics",
        subcategory="Microprocessors",
        description="Digital computers with aggregate theoretical performance (ATP) exceeding 0.5 Weighted TeraFLOPS",
        restrictions=[
            "Export license required for most destinations",
            "Prohibited to certain countries (China, Russia)",
            "End-use restrictions apply"
        ],
        license_required=True,
        license_exceptions=["TSR", "CIV"],
        technical_notes="Performance calculated using IEEE 754 standard",
        related_codes=["3A001.a.2", "3A001.b"],
        last_updated=datetime(2024, 1, 15),
        source_regulation="EAR 774 - Commerce Control List",
        risk_level="high",
        details={
            "ccats": "3A001",
            "eccn": "3A001",
            "control_list": "NS, MT, NP, AT",
            "unit": "Number"
        }
    ),
    ProductClassification(
        id="prod-002",
        product_name="Cryptographic Software",
        classification_code="5D002",
        control_regime="EAR",
        category="Software",
        subcategory="Encryption",
        description="Software specially designed for cryptographic functions",
        restrictions=[
            "License Exception ENC may apply",
            "Self-classification required",
            "Notification to BIS required for certain destinations"
        ],
        license_required=True,
        license_exceptions=["ENC", "TSU"],
        technical_notes="Excludes mass market and publicly available software",
        related_codes=["5A002", "5E002"],
        last_updated=datetime(2023, 11, 20),
        source_regulation="EAR 774 - Commerce Control List",
        risk_level="medium",
        details={
            "ccats": "5D002",
            "eccn": "5D002",
            "control_list": "AT, EI",
            "encryption_note": "Note 4 applies"
        }
    ),
    ProductClassification(
        id="prod-003",
        product_name="Carbon Fiber Materials",
        classification_code="1C010.b",
        control_regime="EAR",
        category="Materials",
        subcategory="Composite Materials",
        description="Carbon fiber preforms and performs exceeding specified tensile strength",
        restrictions=[
            "License required for certain end-uses",
            "Aircraft and missile technology restrictions",
            "End-user screening required"
        ],
        license_required=True,
        license_exceptions=["CIV"],
        technical_notes="Tensile strength exceeding 4.8 × 10^8 N/m²",
        related_codes=["1C010.a", "1C010.c"],
        last_updated=datetime(2023, 9, 10),
        source_regulation="EAR 774 - Commerce Control List",
        risk_level="high",
        details={
            "ccats": "1C010",
            "eccn": "1C010",
            "control_list": "MT, NP",
            "measurement_unit": "kg"
        }
    ),
    ProductClassification(
        id="prod-004",
        product_name="Night Vision Equipment",
        classification_code="6A003",
        control_regime="EAR",
        category="Sensors",
        subcategory="Optical",
        description="Image intensifier tubes and night vision devices",
        restrictions=[
            "License required for all destinations except Canada",
            "Military and law enforcement end-use restrictions",
            "Re-export restrictions apply"
        ],
        license_required=True,
        license_exceptions=[],
        technical_notes="Includes Gen 2 and Gen 3 image intensifier technology",
        related_codes=["6A002", "6E001"],
        last_updated=datetime(2024, 2, 5),
        source_regulation="EAR 774 - Commerce Control List",
        risk_level="high",
        details={
            "ccats": "6A003",
            "eccn": "6A003",
            "control_list": "MT, NP, AT",
            "generation": "Gen 2/3"
        }
    ),
    ProductClassification(
        id="prod-005",
        product_name="Commercial GPS Receivers",
        classification_code="EAR99",
        control_regime="EAR",
        category="Electronics",
        subcategory="Navigation",
        description="Standard commercial GPS receivers for civilian use",
        restrictions=[],
        license_required=False,
        license_exceptions=["NLR"],
        technical_notes="Standard accuracy, no encryption capabilities",
        related_codes=[],
        last_updated=datetime(2023, 12, 1),
        source_regulation="EAR 774 - Commerce Control List",
        risk_level="unrestricted",
        details={
            "ccats": "EAR99",
            "eccn": "EAR99",
            "control_list": "N/A",
            "accuracy": "Standard"
        }
    ),
    ProductClassification(
        id="prod-006",
        product_name="Underwater Cameras",
        classification_code="6A003.b.4",
        control_regime="EAR",
        category="Sensors",
        subcategory="Imaging",
        description="Underwater cameras capable of operating below 150m depth",
        restrictions=[
            "License required for military/intelligence end-users",
            "Commercial diving applications generally permitted"
        ],
        license_required=True,
        license_exceptions=["CIV"],
        technical_notes="Depth rating and image resolution specifications apply",
        related_codes=["6A003.b.1", "6A003.b.2"],
        last_updated=datetime(2023, 10, 15),
        source_regulation="EAR 774 - Commerce Control List",
        risk_level="medium",
        details={
            "ccats": "6A003",
            "eccn": "6A003",
            "control_list": "MT, NP",
            "depth_rating": "150m+"
        }
    ),
    ProductClassification(
        id="prod-007",
        product_name="Drone Flight Controllers",
        classification_code="7A003",
        control_regime="EAR",
        category="Navigation",
        subcategory="Flight Control",
        description="Autopilot systems for unmanned aerial vehicles",
        restrictions=[
            "License required for advanced capability systems",
            "Payload capacity restrictions apply",
            "Range and altitude limitations"
        ],
        license_required=True,
        license_exceptions=["CIV"],
        technical_notes="Excludes consumer-grade recreational drones",
        related_codes=["7A103", "7A003.b"],
        last_updated=datetime(2024, 1, 30),
        source_regulation="EAR 774 - Commerce Control List",
        risk_level="high",
        details={
            "ccats": "7A003",
            "eccn": "7A003",
            "control_list": "MT, AT",
            "payload_limit": "Varies"
        }
    )
]

def search_product_classifications(query: str, filters: dict = None) -> List[ProductClassification]:
    """Search product classifications with fuzzy matching and filtering"""
    if not query or len(query.strip()) < 2:
        return []
    
    query_lower = query.lower().strip()
    results = []
    
    for product in SAMPLE_PRODUCTS_DATA:
        # Check if query matches product name, description, or classification code
        name_match = query_lower in product.product_name.lower()
        desc_match = query_lower in product.description.lower()
        code_match = query_lower in product.classification_code.lower()
        
        if name_match or desc_match or code_match:
            # Apply filters if provided
            if filters:
                if filters.get('control_regime') and product.control_regime != filters['control_regime']:
                    continue
                if filters.get('category') and product.category != filters['category']:
                    continue
                if filters.get('license_required') is not None and product.license_required != filters['license_required']:
                    continue
                if filters.get('risk_level') and product.risk_level != filters['risk_level']:
                    continue
                if not filters.get('include_unrestricted', True) and product.risk_level == 'unrestricted':
                    continue
            
            results.append(product)
    
    # Sort by relevance
    def relevance_score(product):
        score = 0
        if query_lower in product.classification_code.lower():
            score += 100  # Code match is highest priority
        if query_lower in product.product_name.lower():
            score += 50   # Name match
        if query_lower in product.description.lower():
            score += 25   # Description match
        
        # Boost based on risk level
        risk_boost = {'high': 15, 'medium': 10, 'low': 5, 'unrestricted': 0}
        score += risk_boost.get(product.risk_level, 0)
        
        return score
    
    results.sort(key=relevance_score, reverse=True)
    return results

@router.post("/products/search", response_model=ProductSearchResponse)
@consume_credits_for_action("product_classification", "search_products")
async def search_products(
    request: ProductSearchRequest,
    user: AuthorizedUser
):
    """Search product classifications for export control compliance"""
    start_time = datetime.now()
    
    # Build filters from request
    filters = {
        'include_unrestricted': request.include_unrestricted
    }
    if request.control_regime:
        filters['control_regime'] = request.control_regime
    if request.category:
        filters['category'] = request.category
    if request.license_required is not None:
        filters['license_required'] = request.license_required
    if request.risk_level:
        filters['risk_level'] = request.risk_level
    
    # Perform search
    products = search_product_classifications(request.query, filters)
    
    # Apply limit
    limited_products = products[:request.limit]
    
    # Calculate search time
    search_time = (datetime.now() - start_time).total_seconds() * 1000
    
    # Generate suggestions for no results
    suggestions = []
    if not products and len(request.query) > 2:
        all_names = [product.product_name for product in SAMPLE_PRODUCTS_DATA]
        suggestions = [name for name in all_names if any(word in name.lower() for word in request.query.lower().split())][:3]
    
    return ProductSearchResponse(
        products=limited_products,
        total_count=len(products),
        search_time_ms=int(search_time),
        query_used=request.query,
        suggestions=suggestions
    )

@router.get("/product/{product_id}", response_model=ProductClassification)
@consume_credits_for_action("product_classification", "get_product_detail")
async def get_product_classification(
    product_id: str,
    user: AuthorizedUser
):
    """Get detailed classification information for a specific product"""
    for product in SAMPLE_PRODUCTS_DATA:
        if product.id == product_id:
            return product
    
    from fastapi import HTTPException
    raise HTTPException(status_code=404, detail="Product classification not found")

@router.get("/control-regimes", response_model=List[str])
async def get_control_regimes(user: AuthorizedUser):
    """Get list of available control regimes"""
    regimes = list(set(product.control_regime for product in SAMPLE_PRODUCTS_DATA))
    return sorted(regimes)

@router.get("/classification-categories", response_model=List[str])
async def get_classification_categories(user: AuthorizedUser):
    """Get list of available product categories"""
    categories = list(set(product.category for product in SAMPLE_PRODUCTS_DATA))
    return sorted(categories)

@router.get("/products/risk-levels", response_model=List[str])
async def get_product_risk_levels(user: AuthorizedUser):
    """Get list of available risk levels for products"""
    return ["high", "medium", "low", "unrestricted"]
