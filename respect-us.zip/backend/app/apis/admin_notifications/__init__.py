

from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel
from typing import List, Optional, Dict, Any
import asyncpg
import databutton as db
from app.auth import AuthorizedUser
from app.env import Mode, mode
from datetime import datetime, timezone, timedelta
import json
import uuid

router = APIRouter(prefix="/admin-notifications")

# Database connection helper
async def get_db_connection():
    database_url = db.secrets.get("DATABASE_URL_DEV")
    return await asyncpg.connect(database_url)

# Admin Notification Models
class AdminNotificationCreate(BaseModel):
    title: str
    message: str
    notification_type: str  # 'announcement', 'maintenance', 'feature_update', 'security_alert', 'general'
    priority: str = 'medium'  # 'low', 'medium', 'high', 'urgent'
    target_audience: str = 'all_users'  # 'all_users', 'specific_users', 'by_role', 'by_module'
    target_criteria: Optional[Dict[str, Any]] = None  # Specific targeting rules
    expires_at: Optional[datetime] = None
    metadata: Optional[Dict[str, Any]] = None

class AdminNotificationUpdate(BaseModel):
    title: Optional[str] = None
    message: Optional[str] = None
    notification_type: Optional[str] = None
    priority: Optional[str] = None
    target_audience: Optional[str] = None
    target_criteria: Optional[Dict[str, Any]] = None
    is_active: Optional[bool] = None
    expires_at: Optional[datetime] = None
    metadata: Optional[Dict[str, Any]] = None

class AdminNotification(BaseModel):
    notification_id: str
    title: str
    message: str
    notification_type: str
    priority: str
    target_audience: str
    target_criteria: Optional[Dict[str, Any]]
    is_active: bool
    expires_at: Optional[datetime]
    created_by: str
    created_at: datetime
    updated_at: datetime
    metadata: Optional[Dict[str, Any]]
    delivery_stats: Optional[Dict[str, int]] = None  # For showing delivery statistics

class AdminNotificationResponse(BaseModel):
    notification_id: str
    message: str
    created_at: datetime

# User Notification Models
class UserNotification(BaseModel):
    notification_id: str
    title: str
    message: str
    notification_type: str
    priority: str
    status: str  # 'unread', 'read', 'dismissed'
    created_at: datetime
    read_at: Optional[datetime] = None
    dismissed_at: Optional[datetime] = None
    metadata: Optional[Dict[str, Any]] = None

class NotificationStatusUpdate(BaseModel):
    status: str  # 'read', 'dismissed'

class UserNotificationsResponse(BaseModel):
    notifications: List[UserNotification]
    total_count: int
    unread_count: int
    has_more: bool

# Admin Endpoints
@router.post("/admin/create", response_model=AdminNotificationResponse)
async def create_admin_notification(notification: AdminNotificationCreate, user: AuthorizedUser):
    """
    Create a new admin notification to be sent to users.
    Only admins can create notifications.
    """
    try:
        notification_id = f"NOTIF_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{str(uuid.uuid4())[:8]}"
        
        conn = await get_db_connection()
        try:
            await conn.execute(
                """
                INSERT INTO admin_notifications (
                    notification_id, title, message, notification_type, priority,
                    target_audience, target_criteria, expires_at, created_by, metadata
                ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
                """,
                notification_id, notification.title, notification.message,
                notification.notification_type, notification.priority,
                notification.target_audience,
                json.dumps(notification.target_criteria) if notification.target_criteria else None,
                notification.expires_at, user.sub,
                json.dumps(notification.metadata) if notification.metadata else None
            )
            
            print(f"Admin notification created: {notification_id} by {user.email}")
            
        finally:
            await conn.close()
        
        return AdminNotificationResponse(
            notification_id=notification_id,
            message="Notification created successfully",
            created_at=datetime.now(timezone.utc)
        )
        
    except Exception as e:
        print(f"Error creating admin notification: {e}")
        raise HTTPException(status_code=500, detail="Failed to create notification")

@router.get("/admin/notifications", response_model=List[AdminNotification])
async def get_admin_notifications(
    user: AuthorizedUser,
    active_only: bool = Query(True),
    notification_type: Optional[str] = None,
    limit: int = Query(50, ge=1, le=100)
):
    """
    Get all admin notifications with delivery statistics.
    Only admins can access this endpoint.
    """
    try:
        conn = await get_db_connection()
        try:
            # Build query with filters
            conditions = []
            params = []
            param_count = 0
            
            if active_only:
                param_count += 1
                conditions.append(f"is_active = ${param_count}")
                params.append(True)
                
            if notification_type:
                param_count += 1
                conditions.append(f"notification_type = ${param_count}")
                params.append(notification_type)
            
            where_clause = "WHERE " + " AND ".join(conditions) if conditions else ""
            
            notifications = await conn.fetch(
                f"""
                SELECT * FROM admin_notifications 
                {where_clause}
                ORDER BY created_at DESC 
                LIMIT {limit}
                """,
                *params
            )
            
            # Get delivery statistics for each notification
            notification_list = []
            for notif in notifications:
                # Get delivery stats
                stats = await conn.fetchrow(
                    """
                    SELECT 
                        COUNT(*) as total_users,
                        COUNT(*) FILTER (WHERE status = 'unread') as unread_count,
                        COUNT(*) FILTER (WHERE status = 'read') as read_count,
                        COUNT(*) FILTER (WHERE status = 'dismissed') as dismissed_count
                    FROM user_notification_status 
                    WHERE notification_id = $1
                    """,
                    notif['notification_id']
                )
                
                delivery_stats = {
                    "total_users": stats['total_users'] if stats else 0,
                    "unread_count": stats['unread_count'] if stats else 0,
                    "read_count": stats['read_count'] if stats else 0,
                    "dismissed_count": stats['dismissed_count'] if stats else 0
                }
                
                target_criteria = json.loads(notif['target_criteria']) if notif['target_criteria'] else None
                metadata = json.loads(notif['metadata']) if notif['metadata'] else None
                
                notification_list.append(AdminNotification(
                    notification_id=notif['notification_id'],
                    title=notif['title'],
                    message=notif['message'],
                    notification_type=notif['notification_type'],
                    priority=notif['priority'],
                    target_audience=notif['target_audience'],
                    target_criteria=target_criteria,
                    is_active=notif['is_active'],
                    expires_at=notif['expires_at'],
                    created_by=notif['created_by'],
                    created_at=notif['created_at'],
                    updated_at=notif['updated_at'],
                    metadata=metadata,
                    delivery_stats=delivery_stats
                ))
            
            return notification_list
            
        finally:
            await conn.close()
        
    except Exception as e:
        print(f"Error fetching admin notifications: {e}")
        raise HTTPException(status_code=500, detail="Failed to fetch notifications")

@router.put("/admin/notifications/{notification_id}", response_model=AdminNotificationResponse)
async def update_admin_notification(
    notification_id: str,
    update_data: AdminNotificationUpdate,
    user: AuthorizedUser
):
    """
    Update an existing admin notification.
    Only admins can update notifications.
    """
    try:
        conn = await get_db_connection()
        try:
            # Check if notification exists
            existing = await conn.fetchrow(
                "SELECT * FROM admin_notifications WHERE notification_id = $1",
                notification_id
            )
            
            if not existing:
                raise HTTPException(status_code=404, detail="Notification not found")
            
            # Build update query
            updates = []
            params = []
            param_count = 0
            
            for field, value in update_data.model_dump(exclude_unset=True).items():
                if value is not None:
                    param_count += 1
                    if field in ['target_criteria', 'metadata']:
                        updates.append(f"{field} = ${param_count}")
                        params.append(json.dumps(value))
                    else:
                        updates.append(f"{field} = ${param_count}")
                        params.append(value)
            
            if updates:
                param_count += 1
                updates.append(f"updated_at = ${param_count}")
                params.append(datetime.now(timezone.utc))
                
                param_count += 1
                params.append(notification_id)
                
                await conn.execute(
                    f"UPDATE admin_notifications SET {', '.join(updates)} WHERE notification_id = ${param_count}",
                    *params
                )
            
        finally:
            await conn.close()
        
        return AdminNotificationResponse(
            notification_id=notification_id,
            message="Notification updated successfully",
            created_at=datetime.now(timezone.utc)
        )
        
    except Exception as e:
        print(f"Error updating admin notification: {e}")
        raise HTTPException(status_code=500, detail="Failed to update notification")

@router.delete("/admin/notifications/{notification_id}")
async def delete_admin_notification(notification_id: str, user: AuthorizedUser):
    """
    Delete an admin notification (deactivate it).
    Only admins can delete notifications.
    """
    try:
        conn = await get_db_connection()
        try:
            result = await conn.execute(
                "UPDATE admin_notifications SET is_active = false, updated_at = $1 WHERE notification_id = $2",
                datetime.now(timezone.utc), notification_id
            )
            
            if result == "UPDATE 0":
                raise HTTPException(status_code=404, detail="Notification not found")
                
        finally:
            await conn.close()
        
        return {"message": "Notification deactivated successfully"}
        
    except Exception as e:
        print(f"Error deleting admin notification: {e}")
        raise HTTPException(status_code=500, detail="Failed to delete notification")

# User Endpoints
@router.get("/user/notifications", response_model=UserNotificationsResponse)
async def get_user_notifications(
    user: AuthorizedUser,
    status: Optional[str] = Query(None),  # 'unread', 'read', 'dismissed'
    limit: int = Query(20, ge=1, le=50),
    offset: int = Query(0, ge=0)
):
    """
    Get notifications for the current user.
    Automatically creates user_notification_status entries for new notifications.
    """
    try:
        conn = await get_db_connection()
        try:
            # First, create status entries for any new notifications this user hasn't seen
            await conn.execute(
                """
                INSERT INTO user_notification_status (notification_id, user_id, status)
                SELECT an.notification_id, $1, 'unread'
                FROM admin_notifications an
                LEFT JOIN user_notification_status uns ON an.notification_id = uns.notification_id AND uns.user_id = $1
                WHERE an.is_active = true 
                  AND (an.expires_at IS NULL OR an.expires_at > NOW())
                  AND (an.target_audience = 'all_users' OR an.target_audience = 'specific_users')
                  AND uns.notification_id IS NULL
                ON CONFLICT (notification_id, user_id) DO NOTHING
                """,
                user.sub
            )
            
            # Build query with status filter
            status_filter = ""
            params = [user.sub]
            if status:
                status_filter = "AND uns.status = $2"
                params.append(status)
            
            # Get notifications with user status
            notifications = await conn.fetch(
                f"""
                SELECT 
                    an.notification_id, an.title, an.message, an.notification_type,
                    an.priority, an.created_at, an.metadata,
                    uns.status, uns.read_at, uns.dismissed_at
                FROM admin_notifications an
                JOIN user_notification_status uns ON an.notification_id = uns.notification_id
                WHERE uns.user_id = $1
                  AND an.is_active = true
                  AND (an.expires_at IS NULL OR an.expires_at > NOW())
                  {status_filter}
                ORDER BY 
                    CASE an.priority 
                        WHEN 'urgent' THEN 1
                        WHEN 'high' THEN 2
                        WHEN 'medium' THEN 3
                        WHEN 'low' THEN 4
                    END,
                    an.created_at DESC
                LIMIT {limit} OFFSET {offset}
                """,
                *params
            )
            
            # Get total count and unread count
            counts = await conn.fetchrow(
                """
                SELECT 
                    COUNT(*) as total_count,
                    COUNT(*) FILTER (WHERE uns.status = 'unread') as unread_count
                FROM admin_notifications an
                JOIN user_notification_status uns ON an.notification_id = uns.notification_id
                WHERE uns.user_id = $1
                  AND an.is_active = true
                  AND (an.expires_at IS NULL OR an.expires_at > NOW())
                """,
                user.sub
            )
            
        finally:
            await conn.close()
        
        # Transform notifications
        notification_list = []
        for notif in notifications:
            metadata = json.loads(notif['metadata']) if notif['metadata'] else None
            
            notification_list.append(UserNotification(
                notification_id=notif['notification_id'],
                title=notif['title'],
                message=notif['message'],
                notification_type=notif['notification_type'],
                priority=notif['priority'],
                status=notif['status'],
                created_at=notif['created_at'],
                read_at=notif['read_at'],
                dismissed_at=notif['dismissed_at'],
                metadata=metadata
            ))
        
        total_count = counts['total_count'] if counts else 0
        unread_count = counts['unread_count'] if counts else 0
        has_more = (offset + limit) < total_count
        
        return UserNotificationsResponse(
            notifications=notification_list,
            total_count=total_count,
            unread_count=unread_count,
            has_more=has_more
        )
        
    except Exception as e:
        print(f"Error fetching user notifications: {e}")
        raise HTTPException(status_code=500, detail="Failed to fetch notifications")

@router.put("/user/notifications/{notification_id}/status")
async def update_notification_status(
    notification_id: str,
    status_update: NotificationStatusUpdate,
    user: AuthorizedUser
):
    """
    Update the status of a notification for the current user (mark as read/dismissed).
    """
    try:
        conn = await get_db_connection()
        try:
            # Prepare timestamp field based on status
            timestamp_field = None
            timestamp_value = datetime.now(timezone.utc)
            
            if status_update.status == 'read':
                timestamp_field = 'read_at'
            elif status_update.status == 'dismissed':
                timestamp_field = 'dismissed_at'
            
            if timestamp_field:
                result = await conn.execute(
                    f"""
                    UPDATE user_notification_status 
                    SET status = $1, {timestamp_field} = $2
                    WHERE notification_id = $3 AND user_id = $4
                    """,
                    status_update.status, timestamp_value, notification_id, user.sub
                )
            else:
                result = await conn.execute(
                    "UPDATE user_notification_status SET status = $1 WHERE notification_id = $2 AND user_id = $3",
                    status_update.status, notification_id, user.sub
                )
            
            if result == "UPDATE 0":
                raise HTTPException(status_code=404, detail="Notification not found")
                
        finally:
            await conn.close()
        
        return {"message": f"Notification marked as {status_update.status}"}
        
    except Exception as e:
        print(f"Error updating notification status: {e}")
        raise HTTPException(status_code=500, detail="Failed to update notification status")

@router.get("/user/notifications/unread-count")
async def get_unread_notification_count(user: AuthorizedUser):
    """
    Get the count of unread notifications for the current user.
    Used for updating the notification badge in real-time.
    """
    try:
        conn = await get_db_connection()
        try:
            # Create status entries for new notifications first
            await conn.execute(
                """
                INSERT INTO user_notification_status (notification_id, user_id, status)
                SELECT an.notification_id, $1, 'unread'
                FROM admin_notifications an
                LEFT JOIN user_notification_status uns ON an.notification_id = uns.notification_id AND uns.user_id = $1
                WHERE an.is_active = true 
                  AND (an.expires_at IS NULL OR an.expires_at > NOW())
                  AND (an.target_audience = 'all_users' OR an.target_audience = 'specific_users')
                  AND uns.notification_id IS NULL
                ON CONFLICT (notification_id, user_id) DO NOTHING
                """,
                user.sub
            )
            
            count = await conn.fetchval(
                """
                SELECT COUNT(*)
                FROM admin_notifications an
                JOIN user_notification_status uns ON an.notification_id = uns.notification_id
                WHERE uns.user_id = $1
                  AND uns.status = 'unread'
                  AND an.is_active = true
                  AND (an.expires_at IS NULL OR an.expires_at > NOW())
                """,
                user.sub
            )
            
        finally:
            await conn.close()
        
        return {"unread_count": count or 0}
        
    except Exception as e:
        print(f"Error getting unread count: {e}")
        raise HTTPException(status_code=500, detail="Failed to get unread count")

@router.post("/user/notifications/mark-all-read")
async def mark_all_notifications_read(user: AuthorizedUser):
    """
    Mark all unread notifications as read for the current user.
    """
    try:
        conn = await get_db_connection()
        try:
            result = await conn.execute(
                """
                UPDATE user_notification_status 
                SET status = 'read', read_at = $1
                WHERE user_id = $2 AND status = 'unread'
                """,
                datetime.now(timezone.utc), user.sub
            )
            
        finally:
            await conn.close()
        
        return {"message": "All notifications marked as read"}
        
    except Exception as e:
        print(f"Error marking all notifications read: {e}")
        raise HTTPException(status_code=500, detail="Failed to mark notifications as read")
