
from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
import asyncpg
import databutton as db
from app.auth import AuthorizedUser
from app.env import Mode, mode
from datetime import datetime

router = APIRouter(prefix="/country-restrictions")

class CountryRestriction(BaseModel):
    id: str
    country_name: str
    country_code: str  # ISO 3166-1 alpha-2 code
    region: str
    restriction_type: str  # "embargo", "sanctions", "license_required", "prohibited", "restricted"
    program_name: str
    issuing_authority: str  # "US", "EU", "UN", "UK", etc.
    description: str
    restrictions: List[str] = []
    exemptions: List[str] = []
    effective_date: datetime
    end_date: Optional[datetime] = None
    risk_level: str  # "critical", "high", "medium", "low"
    product_categories: List[str] = []  # Which product types are affected
    trade_restrictions: Dict[str, str] = {}  # imports, exports, financial
    last_updated: datetime
    source_url: Optional[str] = None
    details: dict = {}

class CountrySearchRequest(BaseModel):
    query: str = Field(..., min_length=1, description="Search query for country name or code")
    restriction_type: Optional[str] = Field(None, description="Filter by restriction type")
    issuing_authority: Optional[str] = Field(None, description="Filter by issuing authority")
    risk_level: Optional[str] = Field(None, description="Filter by risk level")
    region: Optional[str] = Field(None, description="Filter by geographic region")
    include_expired: bool = Field(default=False, description="Include expired restrictions")
    product_category: Optional[str] = Field(None, description="Filter by affected product category")
    limit: int = Field(default=50, le=100, description="Maximum number of results")

class CountrySearchResponse(BaseModel):
    countries: List[CountryRestriction]
    total_count: int
    search_time_ms: int
    query_used: str
    suggestions: List[str] = []

# Sample country restrictions data
SAMPLE_COUNTRY_DATA = [
    CountryRestriction(
        id="country-001",
        country_name="Russian Federation",
        country_code="RU",
        region="Eastern Europe",
        restriction_type="comprehensive_sanctions",
        program_name="Russia-related sanctions",
        issuing_authority="US (OFAC)",
        description="Comprehensive sanctions due to actions against Ukraine",
        restrictions=[
            "Asset freeze for designated individuals and entities",
            "Export restrictions on technology and luxury goods",
            "Import ban on Russian oil, gas, and coal",
            "SWIFT banking restrictions",
            "Investment prohibitions"
        ],
        exemptions=[
            "Humanitarian goods",
            "Medical supplies",
            "Food products (with license)"
        ],
        effective_date=datetime(2022, 2, 26),
        end_date=None,
        risk_level="critical",
        product_categories=[
            "Technology", "Energy", "Financial Services", "Luxury Goods", "Defense"
        ],
        trade_restrictions={
            "exports": "Prohibited (technology, luxury goods)",
            "imports": "Prohibited (energy products)",
            "financial": "Severely restricted"
        },
        last_updated=datetime(2024, 1, 15),
        source_url="https://ofac.treasury.gov/sanctions/consolidated-sanctions-list",
        details={
            "program_codes": ["UKRAINE-EO13661", "UKRAINE-EO13662"],
            "sdn_entries": 1500,
            "blocked_banks": 7
        }
    ),
    CountryRestriction(
        id="country-002",
        country_name="Iran",
        country_code="IR",
        region="Middle East",
        restriction_type="sectoral_sanctions",
        program_name="Iran sanctions",
        issuing_authority="US (OFAC)",
        description="Sectoral sanctions targeting nuclear program and terrorism support",
        restrictions=[
            "Nuclear-related technology export ban",
            "Oil and petrochemical sector restrictions",
            "Financial sector limitations",
            "Shipping and insurance restrictions"
        ],
        exemptions=[
            "Medical equipment",
            "Agricultural products",
            "Aircraft safety equipment"
        ],
        effective_date=datetime(2010, 6, 9),
        end_date=None,
        risk_level="high",
        product_categories=[
            "Nuclear Technology", "Oil & Gas", "Financial Services", "Shipping"
        ],
        trade_restrictions={
            "exports": "License required (most goods)",
            "imports": "Prohibited (oil, petrochemicals)",
            "financial": "Restricted"
        },
        last_updated=datetime(2023, 12, 10),
        source_url="https://ofac.treasury.gov/sanctions/consolidated-sanctions-list",
        details={
            "program_codes": ["IRAN-EO13846", "IRAN-EO13876"],
            "jcpoa_status": "Non-compliant"
        }
    ),
    CountryRestriction(
        id="country-003",
        country_name="North Korea",
        country_code="KP",
        region="East Asia",
        restriction_type="comprehensive_embargo",
        program_name="DPRK sanctions",
        issuing_authority="UN Security Council",
        description="Comprehensive embargo due to nuclear weapons program",
        restrictions=[
            "Complete trade embargo",
            "Asset freeze",
            "Travel ban for officials",
            "Arms embargo",
            "Luxury goods prohibition"
        ],
        exemptions=[
            "Humanitarian assistance",
            "UN-approved activities"
        ],
        effective_date=datetime(2006, 10, 14),
        end_date=None,
        risk_level="critical",
        product_categories=[
            "All Commercial Goods", "Defense", "Nuclear", "Luxury Goods"
        ],
        trade_restrictions={
            "exports": "Prohibited",
            "imports": "Prohibited",
            "financial": "Prohibited"
        },
        last_updated=datetime(2023, 11, 25),
        source_url="https://www.un.org/securitycouncil/sanctions/1718",
        details={
            "un_resolutions": ["1718", "1874", "2087", "2094"],
            "nuclear_tests": 6
        }
    ),
    CountryRestriction(
        id="country-004",
        country_name="Belarus",
        country_code="BY",
        region="Eastern Europe",
        restriction_type="targeted_sanctions",
        program_name="Belarus sanctions",
        issuing_authority="EU",
        description="Targeted sanctions against Lukashenko regime",
        restrictions=[
            "Asset freeze for officials",
            "Travel restrictions",
            "Arms embargo",
            "Technology export restrictions",
            "Potash and petroleum products ban"
        ],
        exemptions=[
            "Humanitarian goods",
            "Medical supplies",
            "Civil society support"
        ],
        effective_date=datetime(2020, 10, 2),
        end_date=None,
        risk_level="high",
        product_categories=[
            "Defense", "Technology", "Energy", "Minerals"
        ],
        trade_restrictions={
            "exports": "Restricted (technology, dual-use)",
            "imports": "Prohibited (potash, petroleum)",
            "financial": "Limited"
        },
        last_updated=datetime(2023, 10, 20),
        source_url="https://www.consilium.europa.eu/en/policies/sanctions/",
        details={
            "eu_regulation": "833/2014",
            "listed_individuals": 190
        }
    ),
    CountryRestriction(
        id="country-005",
        country_name="Myanmar",
        country_code="MM",
        region="Southeast Asia",
        restriction_type="targeted_sanctions",
        program_name="Myanmar sanctions",
        issuing_authority="US (OFAC)",
        description="Sanctions against military coup leaders and associates",
        restrictions=[
            "Asset freeze for military leaders",
            "Arms embargo",
            "Gemstone import ban",
            "Investment restrictions"
        ],
        exemptions=[
            "Humanitarian assistance",
            "Democratic institutions support"
        ],
        effective_date=datetime(2021, 2, 11),
        end_date=None,
        risk_level="medium",
        product_categories=[
            "Defense", "Gemstones", "Financial Services"
        ],
        trade_restrictions={
            "exports": "License required (dual-use)",
            "imports": "Prohibited (gemstones)",
            "financial": "Restricted (military entities)"
        },
        last_updated=datetime(2023, 9, 15),
        source_url="https://ofac.treasury.gov/sanctions/consolidated-sanctions-list",
        details={
            "program_code": "BURMA-EO14014",
            "coup_date": "2021-02-01"
        }
    ),
    CountryRestriction(
        id="country-006",
        country_name="China",
        country_code="CN",
        region="East Asia",
        restriction_type="license_required",
        program_name="Export Administration Regulations",
        issuing_authority="US (BIS)",
        description="License requirements for advanced technology exports",
        restrictions=[
            "Advanced semiconductor export controls",
            "Artificial intelligence technology restrictions",
            "Quantum computing export controls",
            "Military end-user restrictions"
        ],
        exemptions=[
            "Consumer electronics (low-level)",
            "Agricultural products",
            "Medical devices (non-advanced)"
        ],
        effective_date=datetime(2020, 8, 17),
        end_date=None,
        risk_level="high",
        product_categories=[
            "Semiconductors", "AI Technology", "Quantum Computing", "Defense"
        ],
        trade_restrictions={
            "exports": "License required (advanced tech)",
            "imports": "Unrestricted (most goods)",
            "financial": "Some restrictions"
        },
        last_updated=datetime(2024, 1, 5),
        source_url="https://www.bis.doc.gov/index.php/policy-guidance/country-guidance",
        details={
            "entity_list_entries": 600,
            "military_end_user_list": 103
        }
    )
]

def search_country_restrictions(query: str, filters: dict = None) -> List[CountryRestriction]:
    """Search country restrictions with fuzzy matching and filtering"""
    if not query or len(query.strip()) < 1:
        return []
    
    query_lower = query.lower().strip()
    results = []
    
    for country in SAMPLE_COUNTRY_DATA:
        # Check if query matches country name, code, or region
        name_match = query_lower in country.country_name.lower()
        code_match = query_lower in country.country_code.lower()
        region_match = query_lower in country.region.lower()
        program_match = query_lower in country.program_name.lower()
        
        if name_match or code_match or region_match or program_match:
            # Apply filters if provided
            if filters:
                if filters.get('restriction_type') and country.restriction_type != filters['restriction_type']:
                    continue
                if filters.get('issuing_authority') and country.issuing_authority != filters['issuing_authority']:
                    continue
                if filters.get('risk_level') and country.risk_level != filters['risk_level']:
                    continue
                if filters.get('region') and country.region != filters['region']:
                    continue
                if not filters.get('include_expired', False) and country.end_date and country.end_date < datetime.now():
                    continue
                if filters.get('product_category'):
                    if filters['product_category'] not in country.product_categories:
                        continue
            
            # Skip expired restrictions unless specifically requested
            if not filters or not filters.get('include_expired', False):
                if country.end_date and country.end_date < datetime.now():
                    continue
            
            results.append(country)
    
    # Sort by relevance and risk level
    def relevance_score(country):
        score = 0
        if query_lower == country.country_code.lower():
            score += 100  # Exact code match
        elif query_lower in country.country_name.lower():
            score += 50   # Name match
        elif query_lower in country.region.lower():
            score += 25   # Region match
        
        # Boost based on risk level
        risk_boost = {'critical': 20, 'high': 15, 'medium': 10, 'low': 5}
        score += risk_boost.get(country.risk_level, 0)
        
        return score
    
    results.sort(key=relevance_score, reverse=True)
    return results

@router.post("/countries/search", response_model=CountrySearchResponse)
async def search_countries(
    request: CountrySearchRequest,
    user: AuthorizedUser
):
    """Search country restrictions and embargoes for compliance checks"""
    start_time = datetime.now()
    
    # Build filters from request
    filters = {
        'include_expired': request.include_expired
    }
    if request.restriction_type:
        filters['restriction_type'] = request.restriction_type
    if request.issuing_authority:
        filters['issuing_authority'] = request.issuing_authority
    if request.risk_level:
        filters['risk_level'] = request.risk_level
    if request.region:
        filters['region'] = request.region
    if request.product_category:
        filters['product_category'] = request.product_category
    
    # Perform search
    countries = search_country_restrictions(request.query, filters)
    
    # Apply limit
    limited_countries = countries[:request.limit]
    
    # Calculate search time
    search_time = (datetime.now() - start_time).total_seconds() * 1000
    
    # Generate suggestions for no results
    suggestions = []
    if not countries and len(request.query) > 1:
        all_names = [country.country_name for country in SAMPLE_COUNTRY_DATA]
        suggestions = [name for name in all_names if any(word in name.lower() for word in request.query.lower().split())][:3]
    
    return CountrySearchResponse(
        countries=limited_countries,
        total_count=len(countries),
        search_time_ms=int(search_time),
        query_used=request.query,
        suggestions=suggestions
    )

@router.get("/country/{country_id}", response_model=CountryRestriction)
async def get_country_restriction(
    country_id: str,
    user: AuthorizedUser
):
    """Get detailed restriction information for a specific country"""
    for country in SAMPLE_COUNTRY_DATA:
        if country.id == country_id:
            return country
    
    from fastapi import HTTPException
    raise HTTPException(status_code=404, detail="Country restriction not found")

@router.get("/restriction-types", response_model=List[str])
async def get_restriction_types(user: AuthorizedUser):
    """Get list of available restriction types"""
    types = list(set(country.restriction_type for country in SAMPLE_COUNTRY_DATA))
    return sorted(types)

@router.get("/authorities", response_model=List[str])
async def get_issuing_authorities(user: AuthorizedUser):
    """Get list of issuing authorities"""
    authorities = list(set(country.issuing_authority for country in SAMPLE_COUNTRY_DATA))
    return sorted(authorities)

@router.get("/regions", response_model=List[str])
async def get_geographic_regions(user: AuthorizedUser):
    """Get list of geographic regions"""
    regions = list(set(country.region for country in SAMPLE_COUNTRY_DATA))
    return sorted(regions)

@router.get("/risk-levels", response_model=List[str])
async def get_country_risk_levels(user: AuthorizedUser):
    """Get list of available risk levels for countries"""
    return ["critical", "high", "medium", "low"]
