from fastapi import APIRouter, UploadFile, File, HTTPException, Form
from pydantic import BaseModel
import databutton as db
from typing import List, Optional
import uuid
import re
from app.libs.storage_utils import sanitize_storage_key, sanitize_filename

router = APIRouter()

# Default value for optional file parameter
DEFAULT_FILE = File(None)

class ImageUploadResponse(BaseModel):
    image_url: str
    image_id: str
    filename: str
    size: int

class ImageListResponse(BaseModel):
    images: List[ImageUploadResponse]

@router.post("/upload-image")
async def upload_image(
    file: UploadFile = File(...)
) -> ImageUploadResponse:
    """Upload an image for use in documents"""
    
    # Validate file type
    allowed_types = [
        'image/jpeg',
        'image/jpg', 
        'image/png',
        'image/gif',
        'image/webp'
    ]
    
    if file.content_type not in allowed_types:
        raise HTTPException(
            status_code=400,
            detail="Unsupported file type. Please upload JPEG, PNG, GIF, or WebP images."
        )
    
    # Validate file size (5MB max)
    content = await file.read()
    if len(content) > 5 * 1024 * 1024:
        raise HTTPException(
            status_code=400,
            detail="File size exceeds 5MB limit"
        )
    
    try:
        # Generate unique image ID
        image_id = str(uuid.uuid4()).replace('-', '')  # Remove hyphens from UUID
        
        # Sanitize filename using our utility function
        safe_filename = sanitize_filename(file.filename, default_name="image", default_ext="jpg")
        
        # Create storage key with proper sanitization
        storage_key = sanitize_storage_key(f"images_{image_id}_{safe_filename}")
        
        print(f"Generated storage key: {storage_key}")
        
        # Store in Databutton storage
        db.storage.binary.put(storage_key, content)
        
        # Generate the public URL for the uploaded image
        # Since APIs are protected by default, return the full API URL
        # The frontend will handle authentication automatically via the brain client
        full_filename = f"{image_id}_{safe_filename}"
        # Return the endpoint that can be called via the brain client
        image_url = f"static/{full_filename}"
        
        print(f"Generated image URL for brain client: {image_url}")
        
        return ImageUploadResponse(
            image_url=image_url,
            image_id=image_id,
            filename=safe_filename,
            size=len(content)
        )
        
    except Exception as e:
        print(f"Image upload error: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail="Failed to upload image. Please try again."
        ) from e

@router.get("/images/{image_filename}")
async def serve_image(image_filename: str):
    """Serve uploaded images"""
    try:
        # Sanitize the filename
        safe_filename = re.sub(r'[^a-zA-Z0-9._-]', '_', image_filename)
        
        # Use sanitized storage key format (no forward slash)
        storage_key = sanitize_storage_key(f"images_{safe_filename}")
        
        print(f"Serving image with storage key: {storage_key}")
        
        # Get image data from storage
        image_data = db.storage.binary.get(storage_key)
        
        if not image_data:
            print(f"Image not found with key: {storage_key}")
            raise HTTPException(status_code=404, detail="Image not found")
        
        # Determine content type based on file extension
        ext = safe_filename.lower().split('.')[-1] if '.' in safe_filename else 'jpg'
        content_type_map = {
            'jpg': 'image/jpeg',
            'jpeg': 'image/jpeg',
            'png': 'image/png',
            'gif': 'image/gif',
            'webp': 'image/webp'
        }
        content_type = content_type_map.get(ext, 'image/jpeg')
        
        from fastapi.responses import Response
        return Response(content=image_data, media_type=content_type)
        
    except Exception as e:
        print(f"Error serving image {image_filename}: {str(e)}")
        raise HTTPException(status_code=404, detail="Image not found")

@router.get("/public-serve/{image_filename}")
async def serve_public_image_alt(image_filename: str):
    """Serve uploaded images publicly (alternative endpoint without auth requirement)"""
    try:
        # The image_filename already includes the image_id prefix
        # Just sanitize it and construct the storage key directly
        safe_filename = re.sub(r'[^a-zA-Z0-9._-]', '_', image_filename)
        
        # Storage key format is: images_{image_id}_{original_filename}
        # Since image_filename already has format {image_id}_{original_filename},
        # we just need to prepend "images_"
        storage_key = f"images_{safe_filename}"
        
        print(f"Serving public image with storage key: {storage_key}")
        
        # Get image data from storage
        image_data = db.storage.binary.get(storage_key)
        
        if not image_data:
            print(f"Image not found with key: {storage_key}")
            raise HTTPException(status_code=404, detail="Image not found")
        
        # Determine content type based on file extension
        ext = safe_filename.lower().split('.')[-1] if '.' in safe_filename else 'jpg'
        content_type_map = {
            'jpg': 'image/jpeg',
            'jpeg': 'image/jpeg',
            'png': 'image/png',
            'gif': 'image/gif',
            'webp': 'image/webp'
        }
        content_type = content_type_map.get(ext, 'image/jpeg')
        
        from fastapi.responses import Response
        return Response(content=image_data, media_type=content_type)
        
    except Exception as e:
        print(f"Error serving public image {image_filename}: {str(e)}")
        raise HTTPException(status_code=404, detail="Image not found")

@router.get("/list-images")
async def list_images() -> ImageListResponse:
    """List all uploaded images"""
    try:
        # Get all files from storage with the sanitized prefix
        image_files = db.storage.list_files(prefix="images_")
        
        images = []
        for file_info in image_files:
            # Extract filename from sanitized storage key
            # Key format: images_uuid_filename.ext
            key = file_info['key']
            if key.startswith('images_'):
                filename = key[7:]  # Remove 'images_' prefix
                image_id = filename.split('_')[0] if '_' in filename else filename
                
                images.append(ImageUploadResponse(
                    image_url=f"/api/images/{filename}",
                    image_id=image_id,
                    filename=filename,
                    size=file_info.get('size', 0)
                ))
        
        return ImageListResponse(images=images)
        
    except Exception as e:
        print(f"Error listing images: {str(e)}")
        return ImageListResponse(images=[])

@router.delete("/images/{image_filename}")
async def delete_image(image_filename: str):
    """Delete an uploaded image"""
    try:
        # Sanitize the filename
        safe_filename = re.sub(r'[^a-zA-Z0-9._-]', '_', image_filename)
        
        # Use sanitized storage key format (no forward slash)
        storage_key = sanitize_storage_key(f"images_{safe_filename}")
        
        print(f"Deleting image with storage key: {storage_key}")
        
        # Delete from storage
        db.storage.delete(storage_key)
        
        return {"message": "Image deleted successfully"}
        
    except Exception as e:
        print(f"Error deleting image {image_filename}: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail="Failed to delete image"
        )
