
from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel
from typing import List, Optional, Dict, Any
from app.auth import AuthorizedUser
import databutton as db
import asyncpg
from app.env import Mode, mode
from datetime import datetime

router = APIRouter()

# Pydantic Models
class ComponentPricing(BaseModel):
    id: int
    component_name: str
    action_name: str
    credit_cost: int
    is_active: bool
    description: Optional[str] = None
    effective_from: datetime
    effective_until: Optional[datetime] = None

class UsageTierPricing(BaseModel):
    id: int
    component_name: str
    action_name: str
    tier_min_usage: int  # Minimum usage count for this tier
    tier_max_usage: Optional[int] = None  # Maximum usage count (None = unlimited)
    credit_cost: int  # Credits per action at this tier
    discount_percentage: float  # Discount from base price
    tier_name: str  # e.g., "starter", "professional", "enterprise"
    is_active: bool
    effective_from: datetime
    effective_until: Optional[datetime] = None

class GeographicPricing(BaseModel):
    id: int
    component_name: str
    action_name: str
    country_code: str  # ISO 3166-1 alpha-2 code
    region: str  # e.g., "EU", "APAC", "AMERICAS"
    credit_cost: int
    currency_multiplier: float  # Adjustment factor for local pricing
    is_active: bool
    effective_from: datetime
    effective_until: Optional[datetime] = None

class HybridPricingModel(BaseModel):
    id: int
    component_name: str
    model_type: str  # "subscription_plus_usage", "freemium_to_usage", "subscription_with_overage"
    subscription_tier: Optional[str] = None  # e.g., "basic", "premium", "enterprise"
    included_actions: int  # Actions included in subscription
    overage_credit_cost: int  # Cost per action beyond included
    subscription_monthly_cost: int  # Monthly subscription cost in credits
    is_active: bool
    effective_from: datetime
    effective_until: Optional[datetime] = None

class PricingFeatureFlag(BaseModel):
    id: int
    component_name: str
    is_pricing_enabled: bool
    rollout_strategy: str
    rollout_percentage: int
    beta_users_only: bool
    free_trial_days: int
    effective_from: Optional[datetime] = None
    
class UpdatePricingRequest(BaseModel):
    component_name: str
    action_name: str
    credit_cost: int
    is_active: Optional[bool] = True
    description: Optional[str] = None
    
class UpdateFeatureFlagRequest(BaseModel):
    is_pricing_enabled: bool
    rollout_strategy: Optional[str] = "full"
    rollout_percentage: Optional[int] = 100
    beta_users_only: Optional[bool] = False
    free_trial_days: Optional[int] = 0
    
class CreatePricingRequest(BaseModel):
    component_name: str
    action_name: str
    credit_cost: int
    is_active: bool = True
    description: Optional[str] = None

# Database connection
async def get_db_connection():
    """Get database connection based on environment"""
    if mode == Mode.PROD:
        database_url = db.secrets.get("DATABASE_URL_PROD")
    else:
        database_url = db.secrets.get("DATABASE_URL_DEV")
    return await asyncpg.connect(database_url)

# Component Pricing Management
@router.get("/admin/pricing/components")
async def get_component_pricing(user: AuthorizedUser) -> List[ComponentPricing]:
    """Get all component pricing configurations"""
    try:
        conn = await get_db_connection()
        try:
            query = """
                SELECT id, component_name, action_name, credit_cost, is_active, 
                       description, effective_from, effective_until
                FROM component_pricing_config
                ORDER BY component_name, action_name
            """
            rows = await conn.fetch(query)
            
            return [
                ComponentPricing(
                    id=row['id'],
                    component_name=row['component_name'],
                    action_name=row['action_name'],
                    credit_cost=row['credit_cost'],
                    is_active=row['is_active'],
                    description=row['description'],
                    effective_from=row['effective_from'],
                    effective_until=row['effective_until']
                )
                for row in rows
            ]
            
        finally:
            await conn.close()
            
    except Exception as e:
        print(f"Error fetching component pricing: {e}")
        raise HTTPException(status_code=500, detail="Failed to fetch component pricing") from e

@router.put("/admin/pricing/components/{pricing_id}")
async def update_component_pricing(pricing_id: int, request: UpdatePricingRequest, user: AuthorizedUser) -> ComponentPricing:
    """Update component pricing"""
    try:
        # Get fresh connection to avoid cached plans
        if mode == Mode.PROD:
            database_url = db.secrets.get("DATABASE_URL_PROD")
        else:
            database_url = db.secrets.get("DATABASE_URL_DEV")
        
        conn = await asyncpg.connect(database_url)
        try:
            # Check if pricing exists
            existing = await conn.fetchrow(
                "SELECT id FROM component_pricing_config WHERE id = $1", 
                pricing_id
            )
            
            if not existing:
                raise HTTPException(status_code=404, detail="Pricing configuration not found")
            
            # Update with explicit parameter binding to avoid cached plans
            await conn.execute(
                "UPDATE component_pricing_config SET component_name = $1, action_name = $2, credit_cost = $3, is_active = $4, description = $5, updated_at = CURRENT_TIMESTAMP WHERE id = $6",
                request.component_name,
                request.action_name, 
                request.credit_cost,
                request.is_active,
                request.description,
                pricing_id
            )
            
            # Fetch updated record
            row = await conn.fetchrow(
                "SELECT id, component_name, action_name, credit_cost, is_active, description, effective_from, effective_until FROM component_pricing_config WHERE id = $1",
                pricing_id
            )
            
            return ComponentPricing(
                id=row['id'],
                component_name=row['component_name'],
                action_name=row['action_name'],
                credit_cost=row['credit_cost'],
                is_active=row['is_active'],
                description=row['description'],
                effective_from=row['effective_from'],
                effective_until=row['effective_until']
            )
            
        finally:
            await conn.close()
            
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error updating component pricing: {e}")
        raise HTTPException(status_code=500, detail="Failed to update component pricing") from e

@router.post("/admin/pricing/components")
async def create_component_pricing(request: CreatePricingRequest, user: AuthorizedUser) -> ComponentPricing:
    """Create new component pricing"""
    try:
        conn = await get_db_connection()
        try:
            # Check if pricing already exists
            check_query = """
                SELECT id FROM component_pricing_config 
                WHERE component_name = $1 AND action_name = $2
            """
            existing = await conn.fetchrow(check_query, request.component_name, request.action_name)
            
            if existing:
                raise HTTPException(status_code=400, detail="Pricing for this component/action already exists")
            
            # Create pricing with description field
            create_query = """
                INSERT INTO component_pricing_config 
                (component_name, action_name, credit_cost, is_active, description, created_by)
                VALUES ($1, $2, $3, $4, $5, $6)
                RETURNING id, component_name, action_name, credit_cost, is_active, 
                         description, effective_from, effective_until
            """
            row = await conn.fetchrow(
                create_query, 
                request.component_name, 
                request.action_name, 
                request.credit_cost, 
                request.is_active,
                request.description,
                user.sub
            )
            
            return ComponentPricing(
                id=row['id'],
                component_name=row['component_name'],
                action_name=row['action_name'],
                credit_cost=row['credit_cost'],
                is_active=row['is_active'],
                description=row['description'],
                effective_from=row['effective_from'],
                effective_until=row['effective_until']
            )
            
        finally:
            await conn.close()
            
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error creating component pricing: {e}")
        raise HTTPException(status_code=500, detail="Failed to create component pricing") from e

@router.delete("/admin/pricing/components/{pricing_id}")
async def delete_component_pricing(pricing_id: int, user: AuthorizedUser) -> dict:
    """Delete component pricing configuration"""
    try:
        # Get fresh connection to avoid cached plans
        if mode == Mode.PROD:
            database_url = db.secrets.get("DATABASE_URL_PROD")
        else:
            database_url = db.secrets.get("DATABASE_URL_DEV")
        
        conn = await asyncpg.connect(database_url)
        try:
            # Check if pricing exists
            existing = await conn.fetchrow(
                "SELECT id FROM component_pricing_config WHERE id = $1", 
                pricing_id
            )
            
            if not existing:
                raise HTTPException(status_code=404, detail="Pricing configuration not found")
            
            # Delete the pricing configuration
            await conn.execute(
                "DELETE FROM component_pricing_config WHERE id = $1",
                pricing_id
            )
            
            return {"message": "Pricing configuration deleted successfully"}
            
        finally:
            await conn.close()
            
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error deleting component pricing: {e}")
        raise HTTPException(status_code=500, detail="Failed to delete component pricing") from e

# Feature Flag Management
@router.get("/admin/pricing/feature-flags")
async def get_pricing_feature_flags(user: AuthorizedUser) -> List[PricingFeatureFlag]:
    """Get all pricing feature flags"""
    try:
        conn = await get_db_connection()
        try:
            query = """
                SELECT id, component_name, is_pricing_enabled, rollout_strategy, 
                       rollout_percentage, beta_users_only, free_trial_days, effective_from
                FROM pricing_feature_flags
                ORDER BY component_name
            """
            rows = await conn.fetch(query)
            
            return [
                PricingFeatureFlag(
                    id=row['id'],
                    component_name=row['component_name'],
                    is_pricing_enabled=row['is_pricing_enabled'],
                    rollout_strategy=row['rollout_strategy'],
                    rollout_percentage=row['rollout_percentage'],
                    beta_users_only=row['beta_users_only'],
                    free_trial_days=row['free_trial_days'],
                    effective_from=row['effective_from']
                )
                for row in rows
            ]
            
        finally:
            await conn.close()
            
    except Exception as e:
        print(f"Error fetching feature flags: {e}")
        raise HTTPException(status_code=500, detail="Failed to fetch feature flags") from e

@router.put("/admin/pricing/feature-flags/{component_name}")
async def update_pricing_feature_flag(component_name: str, request: UpdateFeatureFlagRequest, user: AuthorizedUser) -> PricingFeatureFlag:
    """Update pricing feature flag for a component"""
    try:
        conn = await get_db_connection()
        try:
            # Check if feature flag exists
            check_query = "SELECT * FROM pricing_feature_flags WHERE component_name = $1"
            existing = await conn.fetchrow(check_query, component_name)
            
            if not existing:
                raise HTTPException(status_code=404, detail="Feature flag not found")
            
            # Update feature flag
            update_query = """
                UPDATE pricing_feature_flags 
                SET is_pricing_enabled = $1, rollout_strategy = $2, rollout_percentage = $3,
                    beta_users_only = $4, free_trial_days = $5, 
                    effective_from = CASE WHEN $1 = true AND effective_from IS NULL THEN CURRENT_TIMESTAMP ELSE effective_from END,
                    updated_at = CURRENT_TIMESTAMP
                WHERE component_name = $6
                RETURNING id, component_name, is_pricing_enabled, rollout_strategy, 
                         rollout_percentage, beta_users_only, free_trial_days, effective_from
            """
            row = await conn.fetchrow(
                update_query,
                request.is_pricing_enabled,
                request.rollout_strategy,
                request.rollout_percentage,
                request.beta_users_only,
                request.free_trial_days,
                component_name
            )
            
            return PricingFeatureFlag(
                id=row['id'],
                component_name=row['component_name'],
                is_pricing_enabled=row['is_pricing_enabled'],
                rollout_strategy=row['rollout_strategy'],
                rollout_percentage=row['rollout_percentage'],
                beta_users_only=row['beta_users_only'],
                free_trial_days=row['free_trial_days'],
                effective_from=row['effective_from']
            )
            
        finally:
            await conn.close()
            
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error updating feature flag: {e}")
        raise HTTPException(status_code=500, detail="Failed to update feature flag") from e

# Public pricing check endpoint
@router.get("/pricing/check/{component_name}/{action_name}")
async def check_action_pricing(component_name: str, action_name: str, user: AuthorizedUser) -> Dict[str, Any]:
    """Check if an action requires credits and how much"""
    try:
        conn = await get_db_connection()
        try:
            # Check if pricing is enabled and get cost
            query = """
                SELECT cpc.credit_cost, pff.is_pricing_enabled, pff.free_trial_days
                FROM component_pricing_config cpc
                JOIN pricing_feature_flags pff ON pff.component_name = cpc.component_name
                WHERE cpc.component_name = $1 AND cpc.action_name = $2 
                AND cpc.is_active = true AND pff.is_pricing_enabled = true
            """
            pricing = await conn.fetchrow(query, component_name, action_name)
            
            # Get user's current credit balance
            # First ensure user record exists
            await conn.execute(
                "INSERT INTO user_credits (user_id) VALUES ($1) ON CONFLICT (user_id) DO NOTHING",
                user.sub
            )
            
            # Then get the current balance
            user_balance = await conn.fetchval(
                "SELECT current_balance FROM user_credits WHERE user_id = $1",
                user.sub
            ) or 0
            
            if not pricing:
                return {
                    "requires_credits": False,
                    "credit_cost": 0,
                    "is_free": True,
                    "user_balance": user_balance,
                    "has_access": True,
                    "message": "This action is currently free"
                }
            
            credit_cost = pricing['credit_cost']
            has_sufficient_credits = user_balance >= credit_cost
            
            # TODO: Check if user is in free trial period
            
            return {
                "requires_credits": True,
                "credit_cost": credit_cost,
                "is_free": False,
                "user_balance": user_balance,
                "has_access": has_sufficient_credits,
                "message": f"This action costs {credit_cost} credits. You have {user_balance} credits."
            }
            
        finally:
            await conn.close()
            
    except Exception as e:
        print(f"Error checking action pricing: {e}")
        raise HTTPException(status_code=500, detail="Failed to check pricing") from e

# Usage Tier Pricing Endpoints
@router.get("/admin/pricing/usage-tiers")
async def get_usage_tier_pricing(user: AuthorizedUser) -> List[UsageTierPricing]:
    """Get all usage tier pricing configurations"""
    try:
        conn = await get_db_connection()
        try:
            query = """
                SELECT id, component_name, action_name, tier_min_usage, tier_max_usage,
                       credit_cost, discount_percentage, tier_name, is_active, 
                       effective_from, effective_until
                FROM usage_tier_pricing
                ORDER BY component_name, action_name, tier_min_usage
            """
            rows = await conn.fetch(query)
            
            return [
                UsageTierPricing(**dict(row))
                for row in rows
            ]
            
        finally:
            await conn.close()
            
    except Exception as e:
        print(f"Error fetching usage tier pricing: {e}")
        raise HTTPException(status_code=500, detail="Failed to fetch usage tier pricing") from e

@router.post("/admin/pricing/usage-tiers")
async def create_usage_tier_pricing(request: Dict[str, Any], user: AuthorizedUser) -> UsageTierPricing:
    """Create new usage tier pricing"""
    try:
        conn = await get_db_connection()
        try:
            create_query = """
                INSERT INTO usage_tier_pricing 
                (component_name, action_name, tier_min_usage, tier_max_usage, 
                 credit_cost, discount_percentage, tier_name, is_active)
                VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
                RETURNING id, component_name, action_name, tier_min_usage, tier_max_usage,
                         credit_cost, discount_percentage, tier_name, is_active, 
                         effective_from, effective_until
            """
            row = await conn.fetchrow(
                create_query, 
                request['component_name'], request['action_name'], request['tier_min_usage'],
                request.get('tier_max_usage'), request['credit_cost'], request['discount_percentage'],
                request['tier_name'], request.get('is_active', True)
            )
            
            return UsageTierPricing(**dict(row))
            
        finally:
            await conn.close()
            
    except Exception as e:
        print(f"Error creating usage tier pricing: {e}")
        raise HTTPException(status_code=500, detail="Failed to create usage tier pricing") from e

# Geographic Pricing Endpoints
@router.get("/admin/pricing/geographic")
async def get_geographic_pricing(user: AuthorizedUser) -> List[GeographicPricing]:
    """Get all geographic pricing configurations"""
    try:
        conn = await get_db_connection()
        try:
            query = """
                SELECT id, component_name, action_name, country_code, region,
                       credit_cost, currency_multiplier, is_active, 
                       effective_from, effective_until
                FROM geographic_pricing
                ORDER BY component_name, action_name, region
            """
            rows = await conn.fetch(query)
            
            return [
                GeographicPricing(**dict(row))
                for row in rows
            ]
            
        finally:
            await conn.close()
            
    except Exception as e:
        print(f"Error fetching geographic pricing: {e}")
        raise HTTPException(status_code=500, detail="Failed to fetch geographic pricing") from e

@router.post("/admin/pricing/geographic")
async def create_geographic_pricing(request: Dict[str, Any], user: AuthorizedUser) -> GeographicPricing:
    """Create new geographic pricing"""
    try:
        conn = await get_db_connection()
        try:
            create_query = """
                INSERT INTO geographic_pricing 
                (component_name, action_name, country_code, region, 
                 credit_cost, currency_multiplier, is_active)
                VALUES ($1, $2, $3, $4, $5, $6, $7)
                RETURNING id, component_name, action_name, country_code, region,
                         credit_cost, currency_multiplier, is_active, 
                         effective_from, effective_until
            """
            row = await conn.fetchrow(
                create_query, 
                request['component_name'], request['action_name'], request['country_code'],
                request['region'], request['credit_cost'], request['currency_multiplier'],
                request.get('is_active', True)
            )
            
            return GeographicPricing(**dict(row))
            
        finally:
            await conn.close()
            
    except Exception as e:
        print(f"Error creating geographic pricing: {e}")
        raise HTTPException(status_code=500, detail="Failed to create geographic pricing") from e

# Hybrid Pricing Model Endpoints
@router.get("/admin/pricing/hybrid-models")
async def get_hybrid_pricing_models(user: AuthorizedUser) -> List[HybridPricingModel]:
    """Get all hybrid pricing model configurations"""
    try:
        conn = await get_db_connection()
        try:
            query = """
                SELECT id, component_name, model_type, subscription_tier, included_actions,
                       overage_credit_cost, subscription_monthly_cost, is_active, 
                       effective_from, effective_until
                FROM hybrid_pricing_models
                ORDER BY component_name, model_type
            """
            rows = await conn.fetch(query)
            
            return [
                HybridPricingModel(**dict(row))
                for row in rows
            ]
            
        finally:
            await conn.close()
            
    except Exception as e:
        print(f"Error fetching hybrid pricing models: {e}")
        raise HTTPException(status_code=500, detail="Failed to fetch hybrid pricing models") from e

@router.post("/admin/pricing/hybrid-models")
async def create_hybrid_pricing_model(request: Dict[str, Any], user: AuthorizedUser) -> HybridPricingModel:
    """Create new hybrid pricing model"""
    try:
        conn = await get_db_connection()
        try:
            create_query = """
                INSERT INTO hybrid_pricing_models 
                (component_name, model_type, subscription_tier, included_actions,
                 overage_credit_cost, subscription_monthly_cost, is_active)
                VALUES ($1, $2, $3, $4, $5, $6, $7)
                RETURNING id, component_name, model_type, subscription_tier, included_actions,
                         overage_credit_cost, subscription_monthly_cost, is_active, 
                         effective_from, effective_until
            """
            row = await conn.fetchrow(
                create_query, 
                request['component_name'], request['model_type'], request.get('subscription_tier'),
                request['included_actions'], request['overage_credit_cost'], 
                request['subscription_monthly_cost'], request.get('is_active', True)
            )
            
            return HybridPricingModel(**dict(row))
            
        finally:
            await conn.close()
            
    except Exception as e:
        print(f"Error creating hybrid pricing model: {e}")
        raise HTTPException(status_code=500, detail="Failed to create hybrid pricing model") from e

# Enhanced pricing check with dynamic pricing logic
@router.get("/pricing/dynamic-check/{component_name}/{action_name}")
async def check_dynamic_pricing(component_name: str, action_name: str, 
                               user_country: Optional[str] = None,
                               monthly_usage: Optional[int] = None,
                               subscription_tier: Optional[str] = None,
                               user: AuthorizedUser = None) -> Dict[str, Any]:
    """Advanced pricing check with tier, geographic, and hybrid model support"""
    try:
        conn = await get_db_connection()
        try:
            base_price = 1  # Default fallback
            
            # Get base pricing
            base_query = """
                SELECT cpc.credit_cost FROM component_pricing_config cpc
                WHERE cpc.component_name = $1 AND cpc.action_name = $2 AND cpc.is_active = true
            """
            base_pricing = await conn.fetchrow(base_query, component_name, action_name)
            if base_pricing:
                base_price = base_pricing['credit_cost']
            
            # Check for usage tier pricing
            if monthly_usage is not None:
                tier_query = """
                    SELECT credit_cost, tier_name FROM usage_tier_pricing
                    WHERE component_name = $1 AND action_name = $2 
                    AND tier_min_usage <= $3 
                    AND (tier_max_usage IS NULL OR tier_max_usage >= $3)
                    AND is_active = true
                    ORDER BY tier_min_usage DESC LIMIT 1
                """
                tier_pricing = await conn.fetchrow(tier_query, component_name, action_name, monthly_usage)
                if tier_pricing:
                    base_price = tier_pricing['credit_cost']
            
            # Check for geographic pricing
            if user_country:
                geo_query = """
                    SELECT credit_cost, currency_multiplier FROM geographic_pricing
                    WHERE component_name = $1 AND action_name = $2 
                    AND country_code = $3 AND is_active = true
                    ORDER BY effective_from DESC LIMIT 1
                """
                geo_pricing = await conn.fetchrow(geo_query, component_name, action_name, user_country)
                if geo_pricing:
                    base_price = int(geo_pricing['credit_cost'] * geo_pricing['currency_multiplier'])
            
            # Check for hybrid models
            hybrid_info = None
            if subscription_tier:
                hybrid_query = """
                    SELECT * FROM hybrid_pricing_models
                    WHERE component_name = $1 AND subscription_tier = $2 AND is_active = true
                    ORDER BY effective_from DESC LIMIT 1
                """
                hybrid_model = await conn.fetchrow(hybrid_query, component_name, subscription_tier)
                if hybrid_model:
                    hybrid_info = {
                        "model_type": hybrid_model['model_type'],
                        "included_actions": hybrid_model['included_actions'],
                        "overage_cost": hybrid_model['overage_credit_cost']
                    }
            
            return {
                "requires_credits": base_price > 0,
                "credit_cost": base_price,
                "hybrid_model": hybrid_info,
                "user_country": user_country,
                "monthly_usage": monthly_usage,
                "subscription_tier": subscription_tier
            }
            
        finally:
            await conn.close()
            
    except Exception as e:
        print(f"Error in dynamic pricing check: {e}")
        raise HTTPException(status_code=500, detail="Failed to check dynamic pricing") from e
