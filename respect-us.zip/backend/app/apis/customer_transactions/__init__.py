

from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
from datetime import date, datetime
from decimal import Decimal
import asyncpg
import json
import databutton as db
from app.auth import AuthorizedUser

router = APIRouter(prefix="/customer-transactions")

# Pydantic Models for Customer Transactions

class CustomerTransaction(BaseModel):
    """Customer transaction information"""
    id: Optional[int] = None
    customer_id: int
    transaction_type: str = Field(..., pattern="^(export|import|domestic|transfer|service)$")
    transaction_date: date
    transaction_reference: Optional[str] = None
    transaction_value: Optional[Decimal] = None
    currency: str = Field(default="EUR", max_length=3)
    description: Optional[str] = None
    status: str = Field(default="pending", pattern="^(pending|approved|rejected|completed|cancelled)$")
    risk_level: str = Field(default="standard", pattern="^(low|standard|high|critical)$")
    compliance_notes: Optional[str] = None
    documents_required: List[str] = Field(default_factory=list)
    license_required: bool = Field(default=False)
    license_number: Optional[str] = None
    created_by: Optional[str] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

class CustomerProduct(BaseModel):
    """Customer product/technology information"""
    id: Optional[int] = None
    customer_id: int
    product_name: str = Field(..., min_length=1, max_length=500)
    product_category: Optional[str] = None
    product_type: str = Field(..., pattern="^(goods|technology|software|service|dual_use)$")
    eccn_classification: Optional[str] = None
    ccl_category: Optional[str] = None
    description: Optional[str] = None
    technical_specifications: Optional[str] = None
    control_status: str = Field(default="uncontrolled", pattern="^(uncontrolled|controlled|restricted|prohibited)$")
    export_license_required: bool = Field(default=False)
    end_use_statement_required: bool = Field(default=False)
    risk_assessment: Dict[str, Any] = Field(default_factory=dict)
    compliance_notes: Optional[str] = None
    last_review_date: Optional[date] = None
    next_review_date: Optional[date] = None
    created_by: Optional[str] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

class TransactionProduct(BaseModel):
    """Transaction-product association"""
    transaction_id: int
    product_id: int
    quantity: Optional[Decimal] = None
    unit_price: Optional[Decimal] = None
    total_value: Optional[Decimal] = None

class TransactionSearchParams(BaseModel):
    """Search parameters for transactions"""
    customer_id: Optional[int] = None
    transaction_type: Optional[str] = None
    status: Optional[str] = None
    risk_level: Optional[str] = None
    date_from: Optional[date] = None
    date_to: Optional[date] = None
    search_text: Optional[str] = None

class ProductSearchParams(BaseModel):
    """Search parameters for products"""
    customer_id: Optional[int] = None
    product_type: Optional[str] = None
    product_category: Optional[str] = None
    control_status: Optional[str] = None
    search_text: Optional[str] = None

# Transaction Management Endpoints

@router.post("/transactions", response_model=CustomerTransaction)
async def create_transaction(transaction: CustomerTransaction, user: AuthorizedUser) -> CustomerTransaction:
    """Create a new customer transaction"""
    print(f"📝 Creating customer transaction for customer: {transaction.customer_id}")
    
    try:
        db_url = db.secrets.get("DATABASE_URL_DEV")
        conn = await asyncpg.connect(db_url)
        
        try:
            # Check if customer exists
            customer_exists = await conn.fetchval(
                "SELECT EXISTS(SELECT 1 FROM customer_profiles WHERE id = $1)",
                transaction.customer_id
            )
            
            if not customer_exists:
                raise HTTPException(status_code=404, detail="Customer not found")
            
            # Insert transaction
            row = await conn.fetchrow("""
                INSERT INTO customer_transactions (
                    customer_id, transaction_type, transaction_date, transaction_reference,
                    transaction_value, currency, description, status, risk_level,
                    compliance_notes, documents_required, license_required, license_number, created_by
                ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14)
                RETURNING id, created_at, updated_at
            """, 
                transaction.customer_id, transaction.transaction_type, transaction.transaction_date,
                transaction.transaction_reference, transaction.transaction_value, transaction.currency,
                transaction.description, transaction.status, transaction.risk_level,
                transaction.compliance_notes, json.dumps(transaction.documents_required),
                transaction.license_required, transaction.license_number, user.sub
            )
            
            # Return created transaction
            transaction.id = row['id']
            transaction.created_by = user.sub
            transaction.created_at = row['created_at']
            transaction.updated_at = row['updated_at']
            
            print(f"✅ Transaction created successfully with ID: {transaction.id}")
            return transaction
            
        finally:
            await conn.close()
            
    except Exception as e:
        print(f"❌ Error creating transaction: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to create transaction: {str(e)}")

@router.get("/transactions", response_model=List[CustomerTransaction])
async def list_transactions(
    user: AuthorizedUser,
    customer_id: Optional[int] = Query(default=None),
    transaction_type: Optional[str] = Query(default=None),
    status: Optional[str] = Query(default=None),
    limit: int = Query(default=50, le=1000),
    offset: int = Query(default=0, ge=0)
) -> List[CustomerTransaction]:
    """List customer transactions with filtering"""
    print(f"📋 Listing transactions (limit: {limit}, offset: {offset})")
    
    try:
        db_url = db.secrets.get("DATABASE_URL_DEV")
        conn = await asyncpg.connect(db_url)
        
        try:
            # Build dynamic query
            where_conditions = []
            params = []
            param_count = 0
            
            if customer_id:
                param_count += 1
                where_conditions.append(f"customer_id = ${param_count}")
                params.append(customer_id)
            
            if transaction_type:
                param_count += 1
                where_conditions.append(f"transaction_type = ${param_count}")
                params.append(transaction_type)
                
            if status:
                param_count += 1
                where_conditions.append(f"status = ${param_count}")
                params.append(status)
            
            where_clause = " AND ".join(where_conditions) if where_conditions else "1=1"
            
            param_count += 1
            limit_param = f"${param_count}"
            params.append(limit)
            
            param_count += 1
            offset_param = f"${param_count}"
            params.append(offset)
            
            query = f"""
                SELECT * FROM customer_transactions 
                WHERE {where_clause}
                ORDER BY transaction_date DESC, created_at DESC
                LIMIT {limit_param} OFFSET {offset_param}
            """
            
            rows = await conn.fetch(query, *params)
            
            transactions = []
            for row in rows:
                transaction = CustomerTransaction(
                    id=row['id'],
                    customer_id=row['customer_id'],
                    transaction_type=row['transaction_type'],
                    transaction_date=row['transaction_date'],
                    transaction_reference=row['transaction_reference'],
                    transaction_value=row['transaction_value'],
                    currency=row['currency'],
                    description=row['description'],
                    status=row['status'],
                    risk_level=row['risk_level'],
                    compliance_notes=row['compliance_notes'],
                    documents_required=json.loads(row['documents_required']) if row['documents_required'] else [],
                    license_required=row['license_required'],
                    license_number=row['license_number'],
                    created_by=row['created_by'],
                    created_at=row['created_at'],
                    updated_at=row['updated_at']
                )
                transactions.append(transaction)
            
            print(f"✅ Found {len(transactions)} transactions")
            return transactions
            
        finally:
            await conn.close()
            
    except Exception as e:
        print(f"❌ Error listing transactions: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to list transactions: {str(e)}")

@router.put("/transactions/{transaction_id}", response_model=CustomerTransaction)
async def update_transaction(transaction_id: int, transaction: CustomerTransaction, user: AuthorizedUser) -> CustomerTransaction:
    """Update an existing transaction"""
    print(f"📝 Updating transaction ID: {transaction_id}")
    
    try:
        db_url = db.secrets.get("DATABASE_URL_DEV")
        conn = await asyncpg.connect(db_url)
        
        try:
            # Check if transaction exists
            exists = await conn.fetchval(
                "SELECT EXISTS(SELECT 1 FROM customer_transactions WHERE id = $1)",
                transaction_id
            )
            
            if not exists:
                raise HTTPException(status_code=404, detail="Transaction not found")
            
            # Update transaction
            row = await conn.fetchrow("""
                UPDATE customer_transactions SET
                    transaction_type = $2, transaction_date = $3, transaction_reference = $4,
                    transaction_value = $5, currency = $6, description = $7, status = $8,
                    risk_level = $9, compliance_notes = $10, documents_required = $11,
                    license_required = $12, license_number = $13, updated_at = NOW()
                WHERE id = $1
                RETURNING created_by, created_at, updated_at
            """,
                transaction_id, transaction.transaction_type, transaction.transaction_date,
                transaction.transaction_reference, transaction.transaction_value, transaction.currency,
                transaction.description, transaction.status, transaction.risk_level,
                transaction.compliance_notes, json.dumps(transaction.documents_required),
                transaction.license_required, transaction.license_number
            )
            
            # Return updated transaction
            transaction.id = transaction_id
            transaction.created_by = row['created_by']
            transaction.created_at = row['created_at']
            transaction.updated_at = row['updated_at']
            
            print("✅ Transaction updated successfully")
            return transaction
            
        finally:
            await conn.close()
            
    except Exception as e:
        print(f"❌ Error updating transaction: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to update transaction: {str(e)}")

@router.delete("/transactions/{transaction_id}")
async def delete_transaction(transaction_id: int, user: AuthorizedUser) -> Dict[str, str]:
    """Delete a transaction"""
    print(f"🗑️ Deleting transaction ID: {transaction_id}")
    
    try:
        db_url = db.secrets.get("DATABASE_URL_DEV")
        conn = await asyncpg.connect(db_url)
        
        try:
            # Check if transaction exists
            exists = await conn.fetchval(
                "SELECT EXISTS(SELECT 1 FROM customer_transactions WHERE id = $1)",
                transaction_id
            )
            
            if not exists:
                raise HTTPException(status_code=404, detail="Transaction not found")
            
            # Delete transaction (cascade will handle related records)
            await conn.execute(
                "DELETE FROM customer_transactions WHERE id = $1",
                transaction_id
            )
            
            print("✅ Transaction deleted successfully")
            return {"message": "Transaction deleted successfully"}
            
        finally:
            await conn.close()
            
    except Exception as e:
        print(f"❌ Error deleting transaction: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to delete transaction: {str(e)}")
