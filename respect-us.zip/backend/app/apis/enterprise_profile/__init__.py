from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, EmailStr
from typing import List, Optional, Dict, Any
from app.auth import AuthorizedUser
import asyncpg
import databutton as db
from datetime import datetime, timedelta
import json

router = APIRouter(prefix="/enterprise-profile")

# Database connection
async def get_db_connection():
    return await asyncpg.connect(db.secrets.get("DATABASE_URL_DEV"))

# Pydantic Models
class EnhancedUserProfileRequest(BaseModel):
    company_name: str
    contact_person: str
    email: EmailStr
    phone: Optional[str] = None
    billing_address: str
    city: str
    postal_code: str
    country: str
    tax_id: Optional[str] = None
    vat_number: Optional[str] = None
    # Company-specific fields
    create_company: bool = False
    join_company_slug: Optional[str] = None
    company_domain: Optional[str] = None

class EnhancedUserProfileResponse(BaseModel):
    id: int
    user_id: str
    company_name: str
    contact_person: str
    email: str
    phone: Optional[str]
    billing_address: str
    city: str
    postal_code: str
    country: str
    tax_id: Optional[str]
    vat_number: Optional[str]
    created_at: str
    updated_at: str
    # Company information
    company_id: Optional[int]
    company_slug: Optional[str]
    user_role: Optional[str]
    team_member_count: Optional[int]

class AuditLogEntry(BaseModel):
    id: int
    company_id: Optional[int]
    user_id: str
    action: str
    resource_type: Optional[str]
    resource_id: Optional[str]
    details: Dict[str, Any]
    ip_address: Optional[str]
    user_agent: Optional[str]
    created_at: str
    # User details
    user_email: Optional[str]
    user_name: Optional[str]

class AuditLogResponse(BaseModel):
    logs: List[AuditLogEntry]
    total_count: int
    has_more: bool

class UserActivitySummary(BaseModel):
    user_id: str
    user_email: Optional[str]
    user_name: Optional[str]
    total_actions: int
    last_activity: Optional[str]
    most_common_actions: List[Dict[str, Any]]
    risk_score: int  # 0-100 based on activity patterns

# Helper Functions
async def get_user_company_context(user_id: str, conn) -> Dict[str, Any]:
    """Get user's company context and role"""
    result = await conn.fetchrow("""
        SELECT 
            c.id as company_id, c.company_name, c.company_slug,
            rd.role_name, COUNT(tm2.id) as team_size
        FROM team_memberships tm
        JOIN companies c ON tm.company_id = c.id
        JOIN role_definitions rd ON tm.role_id = rd.id
        LEFT JOIN team_memberships tm2 ON c.id = tm2.company_id AND tm2.status = 'active'
        WHERE tm.user_id = $1 AND tm.status = 'active'
        GROUP BY c.id, c.company_name, c.company_slug, rd.role_name
        LIMIT 1
    """, user_id)
    
    if result:
        return {
            'company_id': result['company_id'],
            'company_name': result['company_name'],
            'company_slug': result['company_slug'],
            'role_name': result['role_name'],
            'team_size': result['team_size']
        }
    return {}

async def log_audit_action(company_id: Optional[int], user_id: str, action: str, 
                          resource_type: Optional[str] = None, resource_id: Optional[str] = None,
                          details: Optional[Dict] = None, ip_address: Optional[str] = None,
                          user_agent: Optional[str] = None, conn=None):
    """Enhanced audit logging function"""
    if not conn:
        conn = await get_db_connection()
        close_conn = True
    else:
        close_conn = False
    
    try:
        await conn.execute("""
            INSERT INTO company_audit_logs 
            (company_id, user_id, action, resource_type, resource_id, details, 
             ip_address, user_agent, created_at)
            VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
        """, company_id, user_id, action, resource_type, resource_id, 
        json.dumps(details or {}), ip_address, user_agent, datetime.now())
    finally:
        if close_conn:
            await conn.close()

# Enhanced User Profile Endpoints
@router.post("/save-enhanced-profile")
async def save_enhanced_user_profile(body: EnhancedUserProfileRequest, user: AuthorizedUser) -> EnhancedUserProfileResponse:
    """Save user profile with company integration"""
    try:
        conn = await get_db_connection()
        now = datetime.now()
        
        # Handle company creation or joining
        company_id = None
        if body.create_company:
            # Create new company
            from team_management import generate_company_slug
            
            slug = generate_company_slug(body.company_name)
            counter = 1
            base_slug = slug
            
            while await conn.fetchval("SELECT id FROM companies WHERE company_slug = $1", slug):
                slug = f"{base_slug}-{counter}"
                counter += 1
            
            company_id = await conn.fetchval("""
                INSERT INTO companies 
                (company_name, company_slug, company_domain, billing_email, created_by, created_at, updated_at)
                VALUES ($1, $2, $3, $4, $5, $6, $7)
                RETURNING id
            """, body.company_name, slug, body.company_domain, body.email, user.sub, now, now)
            
            # Add user as owner
            owner_role_id = await conn.fetchval(
                "SELECT id FROM role_definitions WHERE role_name = 'owner'"
            )
            
            await conn.execute("""
                INSERT INTO team_memberships 
                (company_id, user_id, role_id, status, joined_at, created_at, updated_at)
                VALUES ($1, $2, $3, 'active', $4, $5, $6)
            """, company_id, user.sub, owner_role_id, now, now, now)
            
            await log_audit_action(company_id, user.sub, "company_created_via_profile", 
                                 "company", str(company_id), {"company_name": body.company_name}, conn=conn)
        
        elif body.join_company_slug:
            # Join existing company (requires invitation)
            company = await conn.fetchrow(
                "SELECT id FROM companies WHERE company_slug = $1 AND is_active = true", 
                body.join_company_slug
            )
            if company:
                company_id = company['id']
            # Note: Actual joining should be handled through invitation system
        
        # Save/update user profile
        existing_profile = await conn.fetchrow(
            "SELECT id FROM user_profiles WHERE user_id = $1", user.sub
        )
        
        if existing_profile:
            # Update existing profile
            profile_id = await conn.fetchval("""
                UPDATE user_profiles 
                SET company_name = $2, contact_person = $3, email = $4, phone = $5,
                    billing_address = $6, city = $7, postal_code = $8, country = $9,
                    tax_id = $10, vat_number = $11, company_id = $12, updated_at = $13
                WHERE user_id = $1
                RETURNING id
            """, user.sub, body.company_name, body.contact_person, body.email,
            body.phone, body.billing_address, body.city, body.postal_code,
            body.country, body.tax_id, body.vat_number, company_id, now)
            
        else:
            # Create new profile
            profile_id = await conn.fetchval("""
                INSERT INTO user_profiles 
                (user_id, company_name, contact_person, email, phone, billing_address,
                 city, postal_code, country, tax_id, vat_number, company_id, created_at, updated_at)
                VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14)
                RETURNING id
            """, user.sub, body.company_name, body.contact_person, body.email,
            body.phone, body.billing_address, body.city, body.postal_code,
            body.country, body.tax_id, body.vat_number, company_id, now, now)
        
        # Get company context
        company_context = await get_user_company_context(user.sub, conn)
        
        # Get updated profile
        profile = await conn.fetchrow(
            "SELECT * FROM user_profiles WHERE id = $1", profile_id
        )
        
        await log_audit_action(company_id, user.sub, "profile_updated", 
                             "user_profile", str(profile_id), {"action": "profile_save"}, conn=conn)
        
        await conn.close()
        
        return EnhancedUserProfileResponse(
            id=profile['id'],
            user_id=profile['user_id'],
            company_name=profile['company_name'],
            contact_person=profile['contact_person'],
            email=profile['email'],
            phone=profile['phone'],
            billing_address=profile['billing_address'],
            city=profile['city'],
            postal_code=profile['postal_code'],
            country=profile['country'],
            tax_id=profile['tax_id'],
            vat_number=profile['vat_number'],
            created_at=profile['created_at'].isoformat(),
            updated_at=profile['updated_at'].isoformat(),
            company_id=company_context.get('company_id'),
            company_slug=company_context.get('company_slug'),
            user_role=company_context.get('role_name'),
            team_member_count=company_context.get('team_size')
        )
        
    except Exception as e:
        print(f"Error saving enhanced profile: {e}")
        raise HTTPException(status_code=500, detail="Failed to save profile")

@router.get("/enhanced-profile")
async def get_enhanced_user_profile(user: AuthorizedUser) -> Optional[EnhancedUserProfileResponse]:
    """Get user profile with company information"""
    try:
        conn = await get_db_connection()
        
        # Get user profile
        profile = await conn.fetchrow(
            "SELECT * FROM user_profiles WHERE user_id = $1", user.sub
        )
        
        if not profile:
            await conn.close()
            return None
        
        # Get company context
        company_context = await get_user_company_context(user.sub, conn)
        
        await conn.close()
        
        return EnhancedUserProfileResponse(
            id=profile['id'],
            user_id=profile['user_id'],
            company_name=profile['company_name'],
            contact_person=profile['contact_person'],
            email=profile['email'],
            phone=profile['phone'],
            billing_address=profile['billing_address'],
            city=profile['city'],
            postal_code=profile['postal_code'],
            country=profile['country'],
            tax_id=profile['tax_id'],
            vat_number=profile['vat_number'],
            created_at=profile['created_at'].isoformat(),
            updated_at=profile['updated_at'].isoformat(),
            company_id=company_context.get('company_id'),
            company_slug=company_context.get('company_slug'),
            user_role=company_context.get('role_name'),
            team_member_count=company_context.get('team_size')
        )
        
    except Exception as e:
        print(f"Error getting enhanced profile: {e}")
        raise HTTPException(status_code=500, detail="Failed to get profile")

# Audit Logging Endpoints
@router.get("/audit-logs")
async def get_audit_logs(
    user: AuthorizedUser,
    company_id: Optional[int] = None,
    action_filter: Optional[str] = None,
    user_filter: Optional[str] = None,
    limit: int = 100,
    offset: int = 0
) -> AuditLogResponse:
    """Get audit logs with filtering"""
    try:
        conn = await get_db_connection()
        
        # Check if user has access to audit logs
        if company_id:
            # Check if user is admin/owner in the company
            user_permissions = await conn.fetchrow("""
                SELECT rd.permissions 
                FROM team_memberships tm
                JOIN role_definitions rd ON tm.role_id = rd.id
                WHERE tm.user_id = $1 AND tm.company_id = $2 AND tm.status = 'active'
            """, user.sub, company_id)
            
            if not user_permissions or not user_permissions['permissions'].get('admin', False):
                raise HTTPException(status_code=403, detail="Insufficient permissions to view audit logs")
            
            where_clause = "WHERE cal.company_id = $1"
            params = [company_id]
        else:
            # Individual user can only see their own audit logs
            where_clause = "WHERE cal.user_id = $1"
            params = [user.sub]
        
        # Add filters
        if action_filter:
            where_clause += f" AND cal.action ILIKE ${'%' + str(len(params) + 1) + '%'}"
            params.append(f"%{action_filter}%")
        
        if user_filter:
            where_clause += f" AND (u.email ILIKE ${'%' + str(len(params) + 1) + '%'} OR u.name ILIKE ${'%' + str(len(params) + 1) + '%'})"
            params.append(f"%{user_filter}%")
        
        # Get total count
        count_query = f"""
            SELECT COUNT(*) 
            FROM company_audit_logs cal
            LEFT JOIN neon_auth.users_sync u ON cal.user_id = u.id
            {where_clause}
        """
        total_count = await conn.fetchval(count_query, *params)
        
        # Get audit logs
        query = f"""
            SELECT 
                cal.id, cal.company_id, cal.user_id, cal.action, cal.resource_type,
                cal.resource_id, cal.details, cal.ip_address, cal.user_agent, cal.created_at,
                u.email as user_email, u.name as user_name
            FROM company_audit_logs cal
            LEFT JOIN neon_auth.users_sync u ON cal.user_id = u.id
            {where_clause}
            ORDER BY cal.created_at DESC
            LIMIT ${len(params) + 1} OFFSET ${len(params) + 2}
        """
        
        params.extend([limit, offset])
        logs = await conn.fetch(query, *params)
        
        await conn.close()
        
        audit_entries = [
            AuditLogEntry(
                id=log['id'],
                company_id=log['company_id'],
                user_id=log['user_id'],
                action=log['action'],
                resource_type=log['resource_type'],
                resource_id=log['resource_id'],
                details=json.loads(log['details']) if log['details'] else {},
                ip_address=log['ip_address'],
                user_agent=log['user_agent'],
                created_at=log['created_at'].isoformat(),
                user_email=log['user_email'],
                user_name=log['user_name']
            )
            for log in logs
        ]
        
        return AuditLogResponse(
            logs=audit_entries,
            total_count=total_count,
            has_more=(offset + limit) < total_count
        )
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error getting audit logs: {e}")
        raise HTTPException(status_code=500, detail="Failed to get audit logs")

@router.get("/user-activity-summary")
async def get_user_activity_summary(
    user: AuthorizedUser,
    company_id: Optional[int] = None,
    days_back: int = 30
) -> List[UserActivitySummary]:
    """Get user activity summary for compliance monitoring"""
    try:
        conn = await get_db_connection()
        
        # Check permissions
        if company_id:
            user_permissions = await conn.fetchrow("""
                SELECT rd.permissions 
                FROM team_memberships tm
                JOIN role_definitions rd ON tm.role_id = rd.id
                WHERE tm.user_id = $1 AND tm.company_id = $2 AND tm.status = 'active'
            """, user.sub, company_id)
            
            if not user_permissions or not user_permissions['permissions'].get('admin', False):
                raise HTTPException(status_code=403, detail="Insufficient permissions")
        
        # Calculate date range
        start_date = datetime.now() - timedelta(days=days_back)
        
        # Build query
        if company_id:
            where_clause = "WHERE cal.company_id = $1 AND cal.created_at >= $2"
            params = [company_id, start_date]
        else:
            where_clause = "WHERE cal.user_id = $1 AND cal.created_at >= $2"
            params = [user.sub, start_date]
        
        # Get user activity summary
        activity_data = await conn.fetch(f"""
            SELECT 
                cal.user_id,
                u.email as user_email,
                u.name as user_name,
                COUNT(*) as total_actions,
                MAX(cal.created_at) as last_activity,
                cal.action,
                COUNT(*) as action_count
            FROM company_audit_logs cal
            LEFT JOIN neon_auth.users_sync u ON cal.user_id = u.id
            {where_clause}
            GROUP BY cal.user_id, u.email, u.name, cal.action
            ORDER BY cal.user_id, action_count DESC
        """, *params)
        
        # Process data by user
        user_summaries = {}
        for row in activity_data:
            user_id = row['user_id']
            if user_id not in user_summaries:
                user_summaries[user_id] = {
                    'user_id': user_id,
                    'user_email': row['user_email'],
                    'user_name': row['user_name'],
                    'total_actions': 0,
                    'last_activity': row['last_activity'],
                    'actions': []
                }
            
            user_summaries[user_id]['total_actions'] += row['action_count']
            user_summaries[user_id]['actions'].append({
                'action': row['action'],
                'count': row['action_count']
            })
            
            # Keep most recent activity
            if row['last_activity'] > user_summaries[user_id]['last_activity']:
                user_summaries[user_id]['last_activity'] = row['last_activity']
        
        await conn.close()
        
        # Create summary responses
        summaries = []
        for user_data in user_summaries.values():
            # Simple risk scoring based on activity patterns
            risk_score = min(100, max(0, (user_data['total_actions'] - 10) * 5))
            
            summaries.append(UserActivitySummary(
                user_id=user_data['user_id'],
                user_email=user_data['user_email'],
                user_name=user_data['user_name'],
                total_actions=user_data['total_actions'],
                last_activity=user_data['last_activity'].isoformat() if user_data['last_activity'] else None,
                most_common_actions=user_data['actions'][:5],  # Top 5 actions
                risk_score=risk_score
            ))
        
        return sorted(summaries, key=lambda x: x.total_actions, reverse=True)
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error getting user activity summary: {e}")
        raise HTTPException(status_code=500, detail="Failed to get user activity summary")

@router.post("/log-custom-action")
async def log_custom_action(
    user: AuthorizedUser,
    action: str,
    resource_type: Optional[str] = None,
    resource_id: Optional[str] = None,
    details: Optional[Dict[str, Any]] = None
) -> Dict[str, Any]:
    """Log a custom audit action"""
    try:
        conn = await get_db_connection()
        
        # Get user's company context
        company_context = await get_user_company_context(user.sub, conn)
        company_id = company_context.get('company_id')
        
        # Log the action
        await log_audit_action(
            company_id, user.sub, action, resource_type, resource_id, details, conn=conn
        )
        
        await conn.close()
        
        return {
            "success": True,
            "message": "Action logged successfully",
            "logged_at": datetime.now().isoformat()
        }
        
    except Exception as e:
        print(f"Error logging custom action: {e}")
        raise HTTPException(status_code=500, detail="Failed to log action")
