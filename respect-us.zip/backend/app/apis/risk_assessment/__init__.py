

from fastapi import APIRouter, UploadFile, File, HTTPException, Form, Response
from fastapi.responses import JSONResponse, StreamingResponse
from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any
from app.auth import AuthorizedUser
from app.libs.database import get_db_connection
import json
import uuid
from datetime import datetime
import asyncio
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import letter, A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib.units import inch
from reportlab.lib import colors
from io import BytesIO
import databutton as db
from app.env import Mode, mode

router = APIRouter(prefix="/risk-assessment")

# Credit management helper functions
async def check_and_consume_credits(user: AuthorizedUser, action_name: str, resource_id: str = None, description: str = None) -> Dict[str, Any]:
    """
    Simple credit check - in a real implementation this would integrate with the credit system
    """
    return {"success": True, "credits_consumed": 1}

async def check_risk_assessment_access(user: AuthorizedUser) -> bool:
    """
    Check if user has access to risk assessment module
    """
    return True  # For now, allow all authenticated users

class UploadResponse(BaseModel):
    file_id: str
    filename: str
    file_size: int
    file_type: str
    upload_time: datetime
    processing_status: str
    message: str

class FormField(BaseModel):
    field_id: str
    field_type: str  # text, checkbox, radio, select, textarea
    field_label: str
    field_description: Optional[str] = None
    options: Optional[List[str]] = None  # for select/radio
    required: bool = False
    section: str  # strengths, weaknesses, risk_factors

class ProcessedFormResponse(BaseModel):
    form_id: str
    form_title: str
    sections: List[str]
    fields: List[FormField]
    processing_complete: bool
    recommendations: List[str]

@router.post("/upload-form", response_model=UploadResponse)
async def upload_assessment_form(
    user: AuthorizedUser,
    file: UploadFile
):
    """
    Upload a form for risk assessment analysis
    """
    # Check access control
    if not await check_risk_assessment_access(user):
        raise HTTPException(
            status_code=403, 
            detail="Access denied. Please purchase the Risk Assessment module to use this feature."
        )
        
    try:
        # Validate file
        if not file.filename:
            raise HTTPException(status_code=400, detail="No file provided")
        
        # Check file type
        allowed_types = ["application/pdf", "image/jpeg", "image/png", "text/plain", "application/vnd.openxmlformats-officedocument.wordprocessingml.document"]
        if file.content_type not in allowed_types:
            raise HTTPException(status_code=400, detail="Unsupported file type")
        
        # Read file content
        content = await file.read()
        if len(content) > 10 * 1024 * 1024:  # 10MB limit
            raise HTTPException(status_code=400, detail="File too large. Maximum size is 10MB.")
        
        # Generate file ID
        file_id = f"risk_form_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}_{user.sub[:8]}"
        
        # Store file (in production, use proper file storage)
        print(f"Stored risk assessment form {file_id} for user {user.sub}")
        
        return UploadResponse(
            file_id=file_id,
            filename=file.filename,
            file_size=len(content),
            file_type=file.content_type,
            upload_time=datetime.utcnow(),
            processing_status="uploaded",
            message="Form uploaded successfully. Analysis will begin shortly."
        )
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"Upload error: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail="Failed to upload file. Please try again."
        )

@router.get("/analyze-form/{file_id}", response_model=ProcessedFormResponse)
async def analyze_uploaded_form(
    file_id: str,
    user: AuthorizedUser
):
    """
    Analyze the uploaded form and extract structure
    """
    # Check access control
    if not await check_risk_assessment_access(user):
        raise HTTPException(
            status_code=403, 
            detail="Access denied. Please purchase the Risk Assessment module to use this feature."
        )
    
    try:
        # Simulate form analysis
        # In a real implementation, this would:
        # 1. Retrieve the file from storage
        # 2. Use AI/ML to analyze form structure
        # 3. Extract fields and sections
        
        print(f"Analyzing form {file_id} for user {user.sub}")
        
        # Simulate processing delay
        await asyncio.sleep(1)
        
        # Mock analyzed form structure for Strengths & Weaknesses assessment
        mock_fields = [
            FormField(
                field_id="org_name",
                field_type="text",
                field_label="Organization Name",
                field_description="Enter your organization's legal name",
                required=True,
                section="general"
            ),
            FormField(
                field_id="assessment_date",
                field_type="date",
                field_label="Assessment Date",
                field_description="Date when this assessment is being conducted",
                required=True,
                section="general"
            ),
            FormField(
                field_id="strength_governance",
                field_type="checkbox",
                field_label="Strong governance structure",
                field_description="Organization has well-defined compliance governance",
                required=False,
                section="strengths"
            ),
            FormField(
                field_id="strength_training",
                field_type="checkbox",
                field_label="Regular compliance training programs",
                field_description="Systematic training and awareness programs",
                required=False,
                section="strengths"
            ),
            FormField(
                field_id="strength_documentation",
                field_type="checkbox",
                field_label="Comprehensive documentation",
                field_description="Well-maintained compliance documentation",
                required=False,
                section="strengths"
            ),
            FormField(
                field_id="weakness_resources",
                field_type="checkbox",
                field_label="Limited compliance resources",
                field_description="Insufficient staff or budget for compliance activities",
                required=False,
                section="weaknesses"
            ),
            FormField(
                field_id="weakness_systems",
                field_type="checkbox",
                field_label="Outdated systems and processes",
                field_description="Legacy systems that don't support modern compliance",
                required=False,
                section="weaknesses"
            ),
            FormField(
                field_id="risk_geographic",
                field_type="select",
                field_label="Geographic risk exposure",
                field_description="Level of risk from operating in high-risk jurisdictions",
                options=["Low", "Medium", "High", "Critical"],
                required=True,
                section="risk_factors"
            ),
            FormField(
                field_id="risk_products",
                field_type="select",
                field_label="Product/Service risk level",
                field_description="Risk level of products or services offered",
                options=["Low", "Medium", "High", "Critical"],
                required=True,
                section="risk_factors"
            ),
            FormField(
                field_id="additional_comments",
                field_type="textarea",
                field_label="Additional Comments",
                field_description="Any additional observations or notes",
                required=False,
                section="general"
            )
        ]
        
        return ProcessedFormResponse(
            form_id=file_id,
            form_title="Strengths & Weaknesses Assessment",
            sections=["general", "strengths", "weaknesses", "risk_factors"],
            fields=mock_fields,
            processing_complete=True,
            recommendations=[
                "Consider implementing digital signature capture",
                "Add scoring mechanism for risk assessment",
                "Include auto-save functionality for long forms",
                "Implement validation rules for consistency checks"
            ]
        )
        
    except Exception as e:
        print(f"Analysis error: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail="Failed to analyze form. Please try again."
        )

@router.get("/forms")
async def list_uploaded_forms(
    user: AuthorizedUser
):
    """
    List all uploaded forms for the current user
    """
    # Check access control
    if not await check_risk_assessment_access(user):
        raise HTTPException(
            status_code=403, 
            detail="Access denied. Please purchase the Risk Assessment module to use this feature."
        )
    
    # TODO: Implement database query to list user's forms
    return {
        "forms": [],
        "message": "Form listing not yet implemented"
    }

@router.get("/export-pdf/{assessment_id}", tags=["stream"])
async def export_assessment_pdf(assessment_id: str, user: AuthorizedUser) -> StreamingResponse:
    """
    Export risk assessment as PDF with RespectUs branding
    """
    try:
        async with get_db_connection() as conn:
            # Get assessment data
            assessment_query = """
                SELECT ua.*, rt.title as template_title, rt.description as template_description
                FROM user_assessments ua
                LEFT JOIN risk_assessment_templates rt ON ua.template_id = rt.id
                WHERE ua.assessment_id = $1 AND ua.user_id = $2
            """
            assessment = await conn.fetchrow(assessment_query, assessment_id, user.sub)
            
            if not assessment:
                raise HTTPException(status_code=404, detail="Assessment not found")
        
            # Parse JSON fields
            responses_data = json.loads(assessment['responses']) if assessment['responses'] else []
            section_analysis = json.loads(assessment['section_analysis']) if assessment['section_analysis'] else {}
            overall_assessment = json.loads(assessment['overall_assessment']) if assessment['overall_assessment'] else {}
            action_plan = json.loads(assessment['action_plan']) if assessment['action_plan'] else {}

            # Get template structure for proper formatting
            template_query = "SELECT * FROM risk_assessment_templates WHERE id = $1"
            template_row = await conn.fetchrow(template_query, assessment['template_id'])

            if not template_row:
                # Provide fallback template data instead of raising an error
                template_sections = []
                template_title = "Risk Assessment Template"
                template_description = "Standard risk assessment"
            else:
                template_sections = json.loads(template_row['sections']) if template_row['sections'] else []
                template_title = template_row['title'] or "Risk Assessment Template"
                template_description = template_row['description'] or "Standard risk assessment"
            
            # Calculate risk scores
            total_score = 0
            max_score = 0
            answered_questions = 0
            
            section_breakdowns = []
            for section in template_sections:
                section_score = 0
                section_max_score = 0
                section_answered = 0
                
                for question in section.get('questions', []):
                    if question.get('question_type') == 'rating':
                        # Find response for this question
                        response = next(
                            (r for r in responses_data if r['question_id'] == question['id'] and r['section_id'] == section['id']),
                            None
                        )
                        
                        if response and response['answer'] not in ['N/A', 'not_applicable']:
                            try:
                                score = int(response['answer'])
                                section_score += score
                                total_score += score
                                section_answered += 1
                                answered_questions += 1
                            except (ValueError, TypeError):
                                pass
                        
                        section_max_score += 5
                        max_score += 5
                
                section_percentage = (section_score / section_max_score * 100) if section_max_score > 0 else 0
                section_risk_level = 'low' if section_percentage >= 70 else 'medium' if section_percentage >= 40 else 'high'
                
                section_breakdowns.append({
                    'title': section['title'],
                    'score': section_score,
                    'max_score': section_max_score,
                    'percentage': section_percentage,
                    'risk_level': section_risk_level
                })
            
            overall_percentage = (total_score / max_score * 100) if max_score > 0 else 0
            overall_risk_level = 'low' if overall_percentage >= 70 else 'medium' if overall_percentage >= 40 else 'high'
            
            # Generate report ID
            report_id = f"RISK-{uuid.uuid4().hex[:8].upper()}"
            
            # Get user email for "generated by" field
            user_email = getattr(user, 'email', user.sub)
            
            # Create PDF using ReportLab
            buffer = BytesIO()
            doc = SimpleDocTemplate(buffer, pagesize=A4)
            styles = getSampleStyleSheet()
            story = []
            
            # Custom styles for RespectUs branding
            title_style = ParagraphStyle(
                'CustomTitle',
                parent=styles['Heading1'],
                fontSize=24,
                spaceAfter=30,
                textColor=colors.HexColor('#1e3a8a'),
                alignment=1  # Center alignment
            )
            
            heading_style = ParagraphStyle(
                'CustomHeading',
                parent=styles['Heading2'],
                fontSize=16,
                spaceAfter=12,
                textColor=colors.HexColor('#1e40af'),
                backColor=colors.HexColor('#f1f5f9'),
                borderPadding=8
            )
            
            subheading_style = ParagraphStyle(
                'CustomSubHeading',
                parent=styles['Heading3'],
                fontSize=14,
                spaceAfter=8,
                textColor=colors.HexColor('#374151')
            )
            
            # Title and branding
            story.append(Paragraph("RISK ASSESSMENT REPORT", title_style))
            story.append(Paragraph("Generated by <b>RespectUs</b> - Export Control Compliance Platform", styles['Normal']))
            story.append(Paragraph("www.respectus.com", styles['Normal']))
            story.append(Spacer(1, 20))
            
            # Report Information
            story.append(Paragraph("REPORT INFORMATION", heading_style))
            info_data = [
                ['Report ID:', report_id],
                ['Assessment:', assessment['assessment_title'] or 'Risk Assessment Report'],
                ['Company:', assessment['company_name'] or 'N/A'],
                ['Template:', assessment['template_title'] or 'N/A'],
                ['Status:', assessment['status']],
                ['Completion:', f"{assessment['completion_percentage'] or 0}%"],
                ['Generated:', datetime.now().strftime('%Y-%m-%d %H:%M:%S')],
                ['Generated by:', user_email or 'N/A']
            ]
            
            info_table = Table(info_data, colWidths=[2*inch, 4*inch])
            info_table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (0, -1), colors.HexColor('#f8fafc')),
                ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
                ('FONTNAME', (1, 0), (1, -1), 'Helvetica'),
                ('FONTSIZE', (0, 0), (-1, -1), 10),
                ('GRID', (0, 0), (-1, -1), 1, colors.HexColor('#e2e8f0')),
                ('VALIGN', (0, 0), (-1, -1), 'TOP'),
                ('LEFTPADDING', (0, 0), (-1, -1), 8),
                ('RIGHTPADDING', (0, 0), (-1, -1), 8),
                ('TOPPADDING', (0, 0), (-1, -1), 6),
                ('BOTTOMPADDING', (0, 0), (-1, -1), 6)
            ]))
            story.append(info_table)
            story.append(Spacer(1, 20))
            
            # Risk Analysis Summary
            story.append(Paragraph("RISK ANALYSIS SUMMARY", heading_style))
            
            risk_color = colors.red if overall_risk_level == 'high' else colors.orange if overall_risk_level == 'medium' else colors.green
            summary_data = [
                ['Overall Score:', f"{total_score}/{max_score} ({round(overall_percentage, 1)}%)"],
                ['Overall Risk Level:', f"<font color='{risk_color.hexval()}'><b>{overall_risk_level.upper()}</b></font>"],
                ['Answered Questions:', str(answered_questions)]
            ]
            
            summary_table = Table(summary_data, colWidths=[2*inch, 4*inch])
            summary_table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (0, -1), colors.HexColor('#f8fafc')),
                ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
                ('FONTNAME', (1, 0), (1, -1), 'Helvetica'),
                ('FONTSIZE', (0, 0), (-1, -1), 10),
                ('GRID', (0, 0), (-1, -1), 1, colors.HexColor('#e2e8f0')),
                ('VALIGN', (0, 0), (-1, -1), 'TOP'),
                ('LEFTPADDING', (0, 0), (-1, -1), 8),
                ('RIGHTPADDING', (0, 0), (-1, -1), 8),
                ('TOPPADDING', (0, 0), (-1, -1), 6),
                ('BOTTOMPADDING', (0, 0), (-1, -1), 6)
            ]))
            story.append(summary_table)
            story.append(Spacer(1, 20))
            
            # Section Breakdown
            if section_breakdowns:
                story.append(Paragraph("SECTION BREAKDOWN", heading_style))
                
                section_data = [['Section', 'Score', 'Percentage', 'Risk Level']]
                for section_breakdown in section_breakdowns:
                    risk_color = colors.red if section_breakdown['risk_level'] == 'high' else colors.orange if section_breakdown['risk_level'] == 'medium' else colors.green
                    section_data.append([
                        section_breakdown['title'],
                        f"{section_breakdown['score']}/{section_breakdown['max_score']}",
                        f"{round(section_breakdown['percentage'], 1)}%",
                        f"<font color='{risk_color.hexval()}'><b>{section_breakdown['risk_level'].upper()}</b></font>"
                    ])
                
                section_table = Table(section_data, colWidths=[2.5*inch, 1*inch, 1*inch, 1.5*inch])
                section_table.setStyle(TableStyle([
                    ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#1e40af')),
                    ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                    ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                    ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
                    ('FONTSIZE', (0, 0), (-1, -1), 9),
                    ('GRID', (0, 0), (-1, -1), 1, colors.HexColor('#e2e8f0')),
                    ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
                    ('LEFTPADDING', (0, 0), (-1, -1), 6),
                    ('RIGHTPADDING', (0, 0), (-1, -1), 6),
                    ('TOPPADDING', (0, 0), (-1, -1), 4),
                    ('BOTTOMPADDING', (0, 0), (-1, -1), 4),
                    ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#f8fafc')])
                ]))
                story.append(section_table)
                story.append(Spacer(1, 20))
            
            # Action Plan if available
            if action_plan and action_plan.get('items'):
                story.append(Paragraph("ACTION PLAN", heading_style))
                
                action_data = [['ID', 'Title', 'Owner', 'Due Date', 'Status']]
                for item in action_plan['items']:
                    action_data.append([
                        item.get('id', 'N/A'),
                        item.get('title', 'N/A'),
                        item.get('owner', 'N/A'),
                        item.get('due_date', 'N/A'),
                        item.get('status', 'N/A')
                    ])
                
                action_table = Table(action_data, colWidths=[0.8*inch, 2*inch, 1*inch, 1*inch, 1.2*inch])
                action_table.setStyle(TableStyle([
                    ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#1e40af')),
                    ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                    ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                    ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
                    ('FONTSIZE', (0, 0), (-1, -1), 8),
                    ('GRID', (0, 0), (-1, -1), 1, colors.HexColor('#e2e8f0')),
                    ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
                    ('LEFTPADDING', (0, 0), (-1, -1), 4),
                    ('RIGHTPADDING', (0, 0), (-1, -1), 4),
                    ('TOPPADDING', (0, 0), (-1, -1), 3),
                    ('BOTTOMPADDING', (0, 0), (-1, -1), 3),
                    ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#f8fafc')])
                ]))
                story.append(action_table)
                story.append(Spacer(1, 20))
            
            # Footer
            story.append(Spacer(1, 40))
            story.append(Paragraph("<i>This report was generated by RespectUs Export Control Compliance Platform.</i>", styles['Normal']))
            story.append(Paragraph("<i>For more information, visit www.respectus.com</i>", styles['Normal']))
            
            # Build PDF
            doc.build(story)
            buffer.seek(0)
            
            def generate_pdf():
                yield buffer.getvalue()
            
            filename = f"risk_assessment_{assessment_id}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
            
            return StreamingResponse(
                generate_pdf(),
                media_type="application/pdf",
                headers={"Content-Disposition": f"attachment; filename={filename}"}
            )
            
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error exporting assessment PDF: {str(e)}")
        raise HTTPException(status_code=500, detail="Failed to export assessment")
