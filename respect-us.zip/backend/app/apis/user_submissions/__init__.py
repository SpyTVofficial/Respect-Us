from fastapi import APIRouter, File, Form, UploadFile, HTTPException
from pydantic import BaseModel
from typing import Optional
from app.auth import AuthorizedUser
import databutton as db
import asyncpg
import uuid
import json
from datetime import datetime

router = APIRouter(prefix="/user-submissions")

class DocumentSubmissionRequest(BaseModel):
    reason: Optional[str] = None

class CaseStudySubmissionRequest(BaseModel):
    reason: Optional[str] = None

class BlogSubmissionRequest(BaseModel):
    title: str
    summary: Optional[str] = None
    content: str
    tags: Optional[str] = None

class SubmissionResponse(BaseModel):
    success: bool
    message: str
    submission_id: str
    task_id: Optional[str] = None

async def create_validation_task(submission_type: str, submission_id: str, user_id: str, title: str, description: str):
    """Create a validation task in the admin dashboard"""
    try:
        conn = await asyncpg.connect(db.secrets.get("DATABASE_URL_DEV"))
        try:
            task_id = str(uuid.uuid4())
            await conn.execute(
                """
                INSERT INTO admin_tasks (id, title, description, type, status, submission_id, submitted_by, created_at, updated_at)
                VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
                """,
                task_id,
                title,
                description,
                submission_type,
                'pending',
                submission_id,
                user_id,
                datetime.utcnow(),
                datetime.utcnow()
            )
            return task_id
        finally:
            await conn.close()
    except Exception as e:
        print(f"Error creating validation task: {e}")
        return None

@router.post("/submit-document")
async def submit_document(
    user: AuthorizedUser,
    file: UploadFile = File(...),
    reason: Optional[str] = Form(None)
) -> SubmissionResponse:
    """Submit a document for admin review and approval"""
    try:
        # Validate file type
        allowed_types = ['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'text/plain']
        if file.content_type not in allowed_types:
            raise HTTPException(status_code=400, detail="File type not supported. Please upload PDF, DOC, DOCX, or TXT files.")
        
        # Read file content
        file_content = await file.read()
        if len(file_content) > 10 * 1024 * 1024:  # 10MB limit
            raise HTTPException(status_code=400, detail="File size too large. Maximum size is 10MB.")
        
        submission_id = str(uuid.uuid4())
        
        # Store submission in database
        conn = await asyncpg.connect(db.secrets.get("DATABASE_URL_DEV"))
        try:
            await conn.execute(
                """
                INSERT INTO user_submissions (id, type, title, content, metadata, file_name, file_content, file_type, submitted_by, status, created_at, updated_at)
                VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
                """,
                submission_id,
                'document',
                file.filename or 'Untitled Document',
                reason or '',
                json.dumps({'reason': reason}),
                file.filename,
                file_content,
                file.content_type,
                user.sub,
                'pending_review',
                datetime.utcnow(),
                datetime.utcnow()
            )
        finally:
            await conn.close()
        
        # Create validation task for admin
        task_id = await create_validation_task(
            'document_validation',
            submission_id,
            user.sub,
            f"Review Document: {file.filename}",
            f"User has submitted a document for publication: {file.filename}\n\nReason: {reason or 'No reason provided'}\n\nPlease review and approve/reject for publication in the Knowledge Base."
        )
        
        return SubmissionResponse(
            success=True,
            message="Document submitted successfully for review",
            submission_id=submission_id,
            task_id=task_id
        )
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error submitting document: {e}")
        raise HTTPException(status_code=500, detail="Failed to submit document")

@router.post("/submit-case-study")
async def submit_case_study(
    user: AuthorizedUser,
    file: UploadFile = File(...),
    reason: Optional[str] = Form(None)
) -> SubmissionResponse:
    """Submit a case study for admin review and approval"""
    try:
        # Validate file type
        allowed_types = ['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'text/plain']
        if file.content_type not in allowed_types:
            raise HTTPException(status_code=400, detail="File type not supported. Please upload PDF, DOC, DOCX, or TXT files.")
        
        # Read file content
        file_content = await file.read()
        if len(file_content) > 10 * 1024 * 1024:  # 10MB limit
            raise HTTPException(status_code=400, detail="File size too large. Maximum size is 10MB.")
        
        submission_id = str(uuid.uuid4())
        
        # Store submission in database
        conn = await asyncpg.connect(db.secrets.get("DATABASE_URL_DEV"))
        try:
            await conn.execute(
                """
                INSERT INTO user_submissions (id, type, title, content, metadata, file_name, file_content, file_type, submitted_by, status, created_at, updated_at)
                VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
                """,
                submission_id,
                'case_study',
                file.filename or 'Untitled Case Study',
                reason or '',
                json.dumps({'reason': reason}),
                file.filename,
                file_content,
                file.content_type,
                user.sub,
                'pending_review',
                datetime.utcnow(),
                datetime.utcnow()
            )
        finally:
            await conn.close()
        
        # Create validation task for admin
        task_id = await create_validation_task(
            'case_study_validation',
            submission_id,
            user.sub,
            f"Review Case Study: {file.filename}",
            f"User has submitted a case study for publication: {file.filename}\n\nReason: {reason or 'No reason provided'}\n\nPlease review and approve/reject for publication in the Knowledge Base."
        )
        
        return SubmissionResponse(
            success=True,
            message="Case study submitted successfully for review",
            submission_id=submission_id,
            task_id=task_id
        )
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error submitting case study: {e}")
        raise HTTPException(status_code=500, detail="Failed to submit case study")

@router.post("/submit-blog-article")
async def submit_blog_article(
    user: AuthorizedUser,
    submission: BlogSubmissionRequest
) -> SubmissionResponse:
    """Submit a blog article for admin review and approval"""
    try:
        submission_id = str(uuid.uuid4())
        
        # Store submission in database
        conn = await asyncpg.connect(db.secrets.get("DATABASE_URL_DEV"))
        try:
            await conn.execute(
                """
                INSERT INTO user_submissions (id, type, title, content, metadata, submitted_by, status, created_at, updated_at)
                VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
                """,
                submission_id,
                'blog_article',
                submission.title,
                submission.content,
                json.dumps({
                    'summary': submission.summary,
                    'tags': submission.tags
                }),
                user.sub,
                'pending_review',
                datetime.utcnow(),
                datetime.utcnow()
            )
        finally:
            await conn.close()
        
        # Create validation task for admin
        task_id = await create_validation_task(
            'blog_validation',
            submission_id,
            user.sub,
            f"Review Blog Article: {submission.title}",
            f"User has submitted a blog article for publication: {submission.title}\n\nSummary: {submission.summary or 'No summary provided'}\n\nTags: {submission.tags or 'No tags provided'}\n\nPlease review and approve/reject for publication in the Knowledge Base."
        )
        
        return SubmissionResponse(
            success=True,
            message="Blog article submitted successfully for review",
            submission_id=submission_id,
            task_id=task_id
        )
        
    except Exception as e:
        print(f"Error submitting blog article: {e}")
        raise HTTPException(status_code=500, detail="Failed to submit blog article")

@router.get("/my-submissions")
async def get_my_submissions(user: AuthorizedUser):
    """Get user's submission history"""
    try:
        conn = await asyncpg.connect(db.secrets.get("DATABASE_URL_DEV"))
        try:
            submissions = await conn.fetch(
                """
                SELECT id, type, title, status, created_at, updated_at
                FROM user_submissions
                WHERE submitted_by = $1
                ORDER BY created_at DESC
                """,
                user.sub
            )
            return [dict(submission) for submission in submissions]
        finally:
            await conn.close()
    except Exception as e:
        print(f"Error fetching submissions: {e}")
        raise HTTPException(status_code=500, detail="Failed to fetch submissions")
