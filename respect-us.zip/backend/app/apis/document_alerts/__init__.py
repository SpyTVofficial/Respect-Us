

from fastapi import APIRouter, HTTPException, Query, Depends
from pydantic import BaseModel
from typing import List, Optional, Dict, Any
import asyncpg
import databutton as db
from app.auth import AuthorizedUser
from app.env import Mode, mode
from datetime import datetime, timezone
import uuid

router = APIRouter(prefix="/doc-alerts")

async def get_db_connection():
    return await asyncpg.connect(db.secrets.get("DATABASE_URL_DEV"))

# Pydantic models
class DocumentAlertCreate(BaseModel):
    document_id: int
    alert_type: str
    title: str
    description: Optional[str] = None
    severity: str = 'medium'
    jurisdictions: Optional[List[str]] = []
    expires_at: Optional[str] = None  # ISO format string

class DocumentAlertUpdate(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    severity: Optional[str] = None
    jurisdictions: Optional[List[str]] = None
    status: Optional[str] = None
    expires_at: Optional[str] = None

class DocumentAlertResponse(BaseModel):
    id: int
    document_id: int
    alert_type: str
    title: str
    description: Optional[str]
    severity: str
    jurisdictions: List[str]
    status: str
    created_at: datetime
    expires_at: Optional[datetime]
    acknowledged_at: Optional[datetime]
    acknowledged_by: Optional[str]
    resolved_at: Optional[datetime]
    resolved_by: Optional[str]
    created_by: str
    updated_at: datetime
    
    # Document information
    document_title: Optional[str] = None
    document_description: Optional[str] = None

class DocumentAlertStatusUpdate(BaseModel):
    status: str  # 'acknowledged' or 'resolved'
    comment: Optional[str] = None

@router.post("/create", response_model=DocumentAlertResponse)
async def create_document_alert(
    alert: DocumentAlertCreate,
    user: AuthorizedUser
) -> DocumentAlertResponse:
    """Create a new document alert"""
    
    # Validate alert_type
    valid_types = ['sanctions_embargoes', 'product_classification', 'customer_screening', 'end_use_checks', 'risk_assessment']
    if alert.alert_type not in valid_types:
        raise HTTPException(status_code=400, detail=f"Invalid alert_type. Must be one of: {valid_types}")
    
    # Validate severity
    valid_severities = ['low', 'medium', 'high', 'critical']
    if alert.severity not in valid_severities:
        raise HTTPException(status_code=400, detail=f"Invalid severity. Must be one of: {valid_severities}")
    
    conn = await get_db_connection()
    try:
        # Check if document exists
        doc_exists = await conn.fetchval(
            "SELECT EXISTS(SELECT 1 FROM kb_documents WHERE id = $1)",
            alert.document_id
        )
        
        if not doc_exists:
            raise HTTPException(status_code=404, detail="Document not found")
        
        # Parse expires_at if provided
        expires_at = None
        if alert.expires_at:
            try:
                expires_at = datetime.fromisoformat(alert.expires_at.replace('Z', '+00:00'))
            except ValueError:
                raise HTTPException(status_code=400, detail="Invalid expires_at format. Use ISO 8601 format.")
        
        # Create the alert
        alert_id = await conn.fetchval(
            """
            INSERT INTO document_alerts 
            (document_id, alert_type, title, description, severity, jurisdictions, expires_at, created_by)
            VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
            RETURNING id
            """,
            alert.document_id,
            alert.alert_type,
            alert.title,
            alert.description,
            alert.severity,
            alert.jurisdictions or [],
            expires_at,
            user.sub
        )
        
        # Fetch the created alert with document info
        row = await conn.fetchrow(
            """
            SELECT a.*, d.title as document_title, d.description as document_description
            FROM document_alerts a
            LEFT JOIN kb_documents d ON a.document_id = d.id
            WHERE a.id = $1
            """,
            alert_id
        )
        
        return DocumentAlertResponse(
            id=row['id'],
            document_id=row['document_id'],
            alert_type=row['alert_type'],
            title=row['title'],
            description=row['description'],
            severity=row['severity'],
            jurisdictions=row['jurisdictions'] or [],
            status=row['status'],
            created_at=row['created_at'],
            expires_at=row['expires_at'],
            acknowledged_at=row['acknowledged_at'],
            acknowledged_by=row['acknowledged_by'],
            resolved_at=row['resolved_at'],
            resolved_by=row['resolved_by'],
            created_by=row['created_by'],
            updated_at=row['updated_at'],
            document_title=row['document_title'],
            document_description=row['document_description']
        )
        
    finally:
        await conn.close()

@router.get("/alerts", response_model=List[DocumentAlertResponse])
async def list_document_alerts(
    user: AuthorizedUser,
    alert_type: Optional[str] = Query(None, description="Filter by alert type"),
    status: Optional[str] = Query(None, description="Filter by status"),
    severity: Optional[str] = Query(None, description="Filter by severity"),
    include_expired: bool = Query(False, description="Include expired alerts"),
    limit: int = Query(50, description="Maximum number of alerts to return"),
    offset: int = Query(0, description="Offset for pagination")
) -> List[DocumentAlertResponse]:
    """List document alerts with optional filtering"""
    
    conn = await get_db_connection()
    try:
        # Build query with filters
        where_conditions = []
        params = []
        param_count = 0
        
        if alert_type:
            param_count += 1
            where_conditions.append(f"a.alert_type = ${param_count}")
            params.append(alert_type)
        
        if status:
            param_count += 1
            where_conditions.append(f"a.status = ${param_count}")
            params.append(status)
        
        if severity:
            param_count += 1
            where_conditions.append(f"a.severity = ${param_count}")
            params.append(severity)
        
        if not include_expired:
            where_conditions.append("(a.expires_at IS NULL OR a.expires_at > NOW())")
        
        where_clause = "WHERE " + " AND ".join(where_conditions) if where_conditions else ""
        
        param_count += 1
        limit_param = f"${param_count}"
        params.append(limit)
        
        param_count += 1
        offset_param = f"${param_count}"
        params.append(offset)
        
        query = f"""
            SELECT a.*, d.title as document_title, d.description as document_description
            FROM document_alerts a
            LEFT JOIN kb_documents d ON a.document_id = d.id
            {where_clause}
            ORDER BY a.created_at DESC
            LIMIT {limit_param} OFFSET {offset_param}
        """
        
        rows = await conn.fetch(query, *params)
        
        alerts = []
        for row in rows:
            alerts.append(DocumentAlertResponse(
                id=row['id'],
                document_id=row['document_id'],
                alert_type=row['alert_type'],
                title=row['title'],
                description=row['description'],
                severity=row['severity'],
                jurisdictions=row['jurisdictions'] or [],
                status=row['status'],
                created_at=row['created_at'],
                expires_at=row['expires_at'],
                acknowledged_at=row['acknowledged_at'],
                acknowledged_by=row['acknowledged_by'],
                resolved_at=row['resolved_at'],
                resolved_by=row['resolved_by'],
                created_by=row['created_by'],
                updated_at=row['updated_at'],
                document_title=row['document_title'],
                document_description=row['document_description']
            ))
        
        return alerts
        
    finally:
        await conn.close()

@router.get("/alerts/{alert_id}", response_model=DocumentAlertResponse)
async def get_document_alert(
    alert_id: int,
    user: AuthorizedUser
) -> DocumentAlertResponse:
    """Get a specific document alert by ID"""
    
    conn = await get_db_connection()
    try:
        row = await conn.fetchrow(
            """
            SELECT a.*, d.title as document_title, d.description as document_description
            FROM document_alerts a
            LEFT JOIN kb_documents d ON a.document_id = d.id
            WHERE a.id = $1
            """,
            alert_id
        )
        
        if not row:
            raise HTTPException(status_code=404, detail="Alert not found")
        
        return DocumentAlertResponse(
            id=row['id'],
            document_id=row['document_id'],
            alert_type=row['alert_type'],
            title=row['title'],
            description=row['description'],
            severity=row['severity'],
            jurisdictions=row['jurisdictions'] or [],
            status=row['status'],
            created_at=row['created_at'],
            expires_at=row['expires_at'],
            acknowledged_at=row['acknowledged_at'],
            acknowledged_by=row['acknowledged_by'],
            resolved_at=row['resolved_at'],
            resolved_by=row['resolved_by'],
            created_by=row['created_by'],
            updated_at=row['updated_at'],
            document_title=row['document_title'],
            document_description=row['document_description']
        )
        
    finally:
        await conn.close()

@router.put("/{alert_id}/status", response_model=DocumentAlertResponse)
async def update_alert_status(
    alert_id: int,
    status_update: DocumentAlertStatusUpdate,
    user: AuthorizedUser
) -> DocumentAlertResponse:
    """Update the status of a document alert (acknowledge or resolve)"""
    
    valid_statuses = ['new', 'acknowledged', 'resolved']
    if status_update.status not in valid_statuses:
        raise HTTPException(status_code=400, detail=f"Invalid status. Must be one of: {valid_statuses}")
    
    conn = await get_db_connection()
    try:
        # Check if alert exists
        alert_exists = await conn.fetchval(
            "SELECT EXISTS(SELECT 1 FROM document_alerts WHERE id = $1)",
            alert_id
        )
        
        if not alert_exists:
            raise HTTPException(status_code=404, detail="Alert not found")
        
        # Update the alert status
        update_fields = ["status = $2"]
        params = [alert_id, status_update.status]
        param_count = 2
        
        if status_update.status == 'acknowledged':
            param_count += 1
            update_fields.append(f"acknowledged_at = NOW(), acknowledged_by = ${param_count}")
            params.append(user.sub)
        elif status_update.status == 'resolved':
            param_count += 1
            update_fields.append(f"resolved_at = NOW(), resolved_by = ${param_count}")
            params.append(user.sub)
        
        query = f"""
            UPDATE document_alerts 
            SET {', '.join(update_fields)}
            WHERE id = $1
        """
        
        await conn.execute(query, *params)
        
        # Fetch the updated alert
        row = await conn.fetchrow(
            """
            SELECT a.*, d.title as document_title, d.description as document_description
            FROM document_alerts a
            LEFT JOIN kb_documents d ON a.document_id = d.id
            WHERE a.id = $1
            """,
            alert_id
        )
        
        return DocumentAlertResponse(
            id=row['id'],
            document_id=row['document_id'],
            alert_type=row['alert_type'],
            title=row['title'],
            description=row['description'],
            severity=row['severity'],
            jurisdictions=row['jurisdictions'] or [],
            status=row['status'],
            created_at=row['created_at'],
            expires_at=row['expires_at'],
            acknowledged_at=row['acknowledged_at'],
            acknowledged_by=row['acknowledged_by'],
            resolved_at=row['resolved_at'],
            resolved_by=row['resolved_by'],
            created_by=row['created_by'],
            updated_at=row['updated_at'],
            document_title=row['document_title'],
            document_description=row['document_description']
        )
        
    finally:
        await conn.close()

@router.put("/{alert_id}", response_model=DocumentAlertResponse)
async def update_document_alert(
    alert_id: int,
    alert_update: DocumentAlertUpdate,
    user: AuthorizedUser
) -> DocumentAlertResponse:
    """Update a document alert"""
    
    conn = await get_db_connection()
    try:
        # Check if alert exists
        alert_exists = await conn.fetchval(
            "SELECT EXISTS(SELECT 1 FROM document_alerts WHERE id = $1)",
            alert_id
        )
        
        if not alert_exists:
            raise HTTPException(status_code=404, detail="Alert not found")
        
        # Build update query dynamically
        update_fields = []
        params = [alert_id]
        param_count = 1
        
        if alert_update.title is not None:
            param_count += 1
            update_fields.append(f"title = ${param_count}")
            params.append(alert_update.title)
        
        if alert_update.description is not None:
            param_count += 1
            update_fields.append(f"description = ${param_count}")
            params.append(alert_update.description)
        
        if alert_update.severity is not None:
            valid_severities = ['low', 'medium', 'high', 'critical']
            if alert_update.severity not in valid_severities:
                raise HTTPException(status_code=400, detail=f"Invalid severity. Must be one of: {valid_severities}")
            param_count += 1
            update_fields.append(f"severity = ${param_count}")
            params.append(alert_update.severity)
        
        if alert_update.jurisdictions is not None:
            param_count += 1
            update_fields.append(f"jurisdictions = ${param_count}")
            params.append(alert_update.jurisdictions)
        
        if alert_update.expires_at is not None:
            try:
                expires_at = datetime.fromisoformat(alert_update.expires_at.replace('Z', '+00:00'))
                param_count += 1
                update_fields.append(f"expires_at = ${param_count}")
                params.append(expires_at)
            except ValueError:
                raise HTTPException(status_code=400, detail="Invalid expires_at format. Use ISO 8601 format.")
        
        if not update_fields:
            raise HTTPException(status_code=400, detail="No fields to update")
        
        query = f"""
            UPDATE document_alerts 
            SET {', '.join(update_fields)}
            WHERE id = $1
        """
        
        await conn.execute(query, *params)
        
        # Fetch the updated alert
        row = await conn.fetchrow(
            """
            SELECT a.*, d.title as document_title, d.description as document_description
            FROM document_alerts a
            LEFT JOIN kb_documents d ON a.document_id = d.id
            WHERE a.id = $1
            """,
            alert_id
        )
        
        return DocumentAlertResponse(
            id=row['id'],
            document_id=row['document_id'],
            alert_type=row['alert_type'],
            title=row['title'],
            description=row['description'],
            severity=row['severity'],
            jurisdictions=row['jurisdictions'] or [],
            status=row['status'],
            created_at=row['created_at'],
            expires_at=row['expires_at'],
            acknowledged_at=row['acknowledged_at'],
            acknowledged_by=row['acknowledged_by'],
            resolved_at=row['resolved_at'],
            resolved_by=row['resolved_by'],
            created_by=row['created_by'],
            updated_at=row['updated_at'],
            document_title=row['document_title'],
            document_description=row['document_description']
        )
        
    finally:
        await conn.close()

@router.delete("/{alert_id}")
async def delete_document_alert(
    alert_id: int,
    user: AuthorizedUser
) -> Dict[str, str]:
    """Delete a document alert"""
    
    conn = await get_db_connection()
    try:
        # Check if alert exists
        alert_exists = await conn.fetchval(
            "SELECT EXISTS(SELECT 1 FROM document_alerts WHERE id = $1)",
            alert_id
        )
        
        if not alert_exists:
            raise HTTPException(status_code=404, detail="Alert not found")
        
        # Delete the alert
        await conn.execute(
            "DELETE FROM document_alerts WHERE id = $1",
            alert_id
        )
        
        return {"message": "Alert deleted successfully"}
        
    finally:
        await conn.close()

@router.get("/stats/summary")
async def get_alerts_summary(
    user: AuthorizedUser
) -> Dict[str, Any]:
    """Get summary statistics for alerts"""
    
    conn = await get_db_connection()
    try:
        # Get counts by status
        status_counts = await conn.fetch(
            "SELECT status, COUNT(*) as count FROM document_alerts GROUP BY status"
        )
        
        # Get counts by alert type
        type_counts = await conn.fetch(
            "SELECT alert_type, COUNT(*) as count FROM document_alerts GROUP BY alert_type"
        )
        
        # Get counts by severity
        severity_counts = await conn.fetch(
            "SELECT severity, COUNT(*) as count FROM document_alerts GROUP BY severity"
        )
        
        # Get expired alerts count
        expired_count = await conn.fetchval(
            "SELECT COUNT(*) FROM document_alerts WHERE expires_at < NOW()"
        )
        
        # Get active alerts count
        active_count = await conn.fetchval(
            "SELECT COUNT(*) FROM document_alerts WHERE status != 'resolved' AND (expires_at IS NULL OR expires_at > NOW())"
        )
        
        return {
            "status_counts": {row['status']: row['count'] for row in status_counts},
            "type_counts": {row['alert_type']: row['count'] for row in type_counts},
            "severity_counts": {row['severity']: row['count'] for row in severity_counts},
            "expired_count": expired_count,
            "active_count": active_count,
            "total_count": sum(row['count'] for row in status_counts)
        }
        
    finally:
        await conn.close()
