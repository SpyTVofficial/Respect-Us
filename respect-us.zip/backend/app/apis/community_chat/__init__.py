import asyncio
import json
import uuid
from datetime import datetime, timezone, timedelta
from typing import List, Optional, Dict, Any
import asyncpg
import databutton as db
from fastapi import APIRouter, WebSocket, WebSocketDisconnect, HTTPException
from pydantic import BaseModel
from app.auth import AuthorizedUser
from app.env import Mode, mode
from datetime import datetime

router = APIRouter(prefix="/community-chat")

# Database connection helper
async def get_db_connection():
    """Get database connection"""
    database_url = db.secrets.get("DATABASE_URL_DEV") if mode == Mode.DEV else db.secrets.get("DATABASE_URL_PROD")
    return await asyncpg.connect(database_url)

# Connection manager for WebSocket connections
class ConnectionManager:
    def __init__(self):
        self.active_connections: List[WebSocket] = []
        self.user_connections: dict = {}  # Maps user_id to websocket

    async def connect(self, websocket: WebSocket, user_id: str):
        await websocket.accept("databutton.app")
        self.active_connections.append(websocket)
        self.user_connections[user_id] = websocket

    def disconnect(self, websocket: WebSocket, user_id: str):
        if websocket in self.active_connections:
            self.active_connections.remove(websocket)
        if user_id in self.user_connections:
            del self.user_connections[user_id]

    async def send_personal_message(self, message: str, websocket: WebSocket):
        await websocket.send_text(message)

    async def broadcast(self, message: str):
        for connection in self.active_connections:
            try:
                await connection.send_text(message)
            except:
                # Remove broken connections
                if connection in self.active_connections:
                    self.active_connections.remove(connection)

manager = ConnectionManager()

# Models
class ChatMessage(BaseModel):
    id: str
    user_id: str
    username: str
    content: str
    message_type: str = "message"  # message, announcement, system
    thread_id: Optional[str] = None
    reply_to: Optional[str] = None
    created_at: datetime
    updated_at: Optional[datetime] = None
    reactions: Optional[dict] = None
    is_pinned: bool = False
    is_deleted: bool = False

class SendMessageRequest(BaseModel):
    content: str
    message_type: str = "message"
    thread_id: Optional[str] = None
    reply_to: Optional[str] = None

class ChatThread(BaseModel):
    id: str
    title: str
    description: Optional[str] = None
    created_by: str
    created_at: datetime
    message_count: int = 0
    last_message_at: Optional[datetime] = None
    is_pinned: bool = False
    tags: Optional[List[str]] = None

class CreateThreadRequest(BaseModel):
    title: str
    description: Optional[str] = None

class ReactionRequest(BaseModel):
    reaction_type: str
    user_id: str

class BlockUserRequest(BaseModel):
    user_id: str
    reason: str

class DeleteChatRequest(BaseModel):
    message_id: Optional[str] = None
    thread_id: Optional[str] = None
    reason: Optional[str] = None

class ChatPolicyResponse(BaseModel):
    policy: str
    last_updated: str

def is_admin_user(user: AuthorizedUser) -> bool:
    """Check if user has admin privileges"""
    # Simple admin check - you can extend this logic as needed
    admin_emails = [
        "admin@respectus.com", 
        "patrick.goergen@respectus.com",
        "patrick.goergen@respectus.space",  # Add Patrick's actual email
        "support@respectus.com"
    ]
    return getattr(user, 'primaryEmail', None) in admin_emails

# WebSocket endpoint for real-time chat
@router.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket, user: AuthorizedUser):
    user_id = user.sub
    await manager.connect(websocket, user_id)
    
    try:
        while True:
            data = await websocket.receive_text()
            message_data = json.loads(data)
            
            if message_data.get("type") == "chat_message":
                # Save message to database
                conn = await get_db_connection()
                try:
                    message_id = str(uuid.uuid4())
                    now = datetime.now(timezone.utc)
                    
                    await conn.execute(
                        """
                        INSERT INTO chat_messages (id, user_id, username, content, message_type, thread_id, reply_to, created_at)
                        VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
                        """,
                        message_id, user_id, user.email, message_data["content"], 
                        message_data.get("message_type", "message"),
                        message_data.get("thread_id"), message_data.get("reply_to"), now
                    )
                    
                    # Broadcast message to all connected clients
                    broadcast_message = {
                        "type": "new_message",
                        "message": {
                            "id": message_id,
                            "user_id": user_id,
                            "username": user.email,
                            "content": message_data["content"],
                            "message_type": message_data.get("message_type", "message"),
                            "thread_id": message_data.get("thread_id"),
                            "reply_to": message_data.get("reply_to"),
                            "created_at": now.isoformat(),
                            "reactions": {},
                            "is_pinned": False
                        }
                    }
                    
                    await manager.broadcast(json.dumps(broadcast_message))
                    
                finally:
                    await conn.close()
                    
    except WebSocketDisconnect:
        manager.disconnect(websocket, user_id)
    except Exception as e:
        print(f"WebSocket error: {e}")
        manager.disconnect(websocket, user_id)

# REST API endpoints
# Get chat messages with optional thread filter
@router.get("/messages")
async def get_chat_messages(thread_id: str = None):
    """Get chat messages, optionally filtered by thread"""
    async with get_db_connection() as conn:
        # Handle frontend sending "null" as string vs actual null
        effective_thread_id = None if thread_id in [None, "null", ""] else thread_id
        
        if effective_thread_id:
            # Validate UUID format if not null
            try:
                uuid.UUID(effective_thread_id)
            except ValueError:
                raise HTTPException(status_code=400, detail="Invalid thread_id format")
                
            # Get messages for specific thread
            rows = await conn.fetch(
                """
                SELECT cm.*, ct.title as thread_title 
                FROM chat_messages cm
                LEFT JOIN chat_threads ct ON cm.thread_id = ct.id
                WHERE cm.thread_id = $1
                ORDER BY cm.created_at ASC
                """,
                effective_thread_id
            )
        else:
            # Get general messages (no thread)
            rows = await conn.fetch(
                """
                SELECT cm.*, null as thread_title 
                FROM chat_messages cm
                WHERE cm.thread_id IS NULL
                ORDER BY cm.created_at ASC
                """
            )
        
        messages = []
        for row in rows:
            # Parse reactions if they exist
            reactions = {}
            if row['reactions']:
                try:
                    if isinstance(row['reactions'], str):
                        reactions = json.loads(row['reactions'])
                    else:
                        reactions = row['reactions']
                except:
                    reactions = {}
            
            messages.append({
                "id": row['id'],
                "user_id": row['user_id'],
                "username": row['username'],
                "content": row['content'],
                "message_type": row['message_type'],
                "thread_id": row['thread_id'],
                "reply_to": row['reply_to'],
                "created_at": row['created_at'].isoformat(),
                "reactions": reactions
            })
        
        return messages

@router.post("/send-message", response_model=ChatMessage)
async def send_message(user: AuthorizedUser, message: SendMessageRequest):
    """Send a new chat message"""
    async with get_db_connection() as conn:
        message_id = str(uuid.uuid4())
        
        # Get username from user profile or use email/id fallback
        username = getattr(user, 'displayName', None) or getattr(user, 'primaryEmail', None) or f"User-{user.sub[:8]}"
        
        # Handle thread_id properly - if None, insert NULL, if string, validate UUID
        thread_id_param = None
        if message.thread_id:
            try:
                # Validate that it's a proper UUID
                uuid.UUID(message.thread_id)
                thread_id_param = message.thread_id
            except ValueError:
                raise HTTPException(status_code=400, detail="Invalid thread_id format")
        
        # Insert message
        await conn.execute(
            """
            INSERT INTO chat_messages (id, user_id, username, content, message_type, thread_id, reply_to)
            VALUES ($1, $2, $3, $4, $5, $6, $7)
            """,
            message_id, user.sub, username, message.content, 
            message.message_type, thread_id_param, message.reply_to
        )
        
        # Get the created message
        row = await conn.fetchrow(
            "SELECT * FROM chat_messages WHERE id = $1",
            message_id
        )
        
        # Parse reactions if they exist
        reactions = {}
        if row['reactions']:
            try:
                if isinstance(row['reactions'], str):
                    reactions = json.loads(row['reactions'])
                else:
                    reactions = row['reactions']
            except:
                reactions = {}
        
        message_response = ChatMessage(
            id=str(row['id']),
            user_id=str(row['user_id']),
            username=row['username'],
            content=row['content'],
            message_type=row['message_type'],
            thread_id=str(row['thread_id']) if row['thread_id'] else None,
            reply_to=str(row['reply_to']) if row['reply_to'] else None,
            created_at=row['created_at'].isoformat(),
            updated_at=row['updated_at'].isoformat() if row.get('updated_at') else None,
            reactions=reactions,
            is_edited=False,  # Default value since column doesn't exist yet
            is_deleted=False  # Default value since column doesn't exist yet
        )
        
        # TODO: Add WebSocket broadcasting when implemented
        # await broadcast_message({
        #     "type": "new_message",
        #     "message": message_response.dict()
        # })
        
        return message_response

@router.get("/threads")
async def get_chat_threads():
    """Get all chat threads"""
    async with get_db_connection() as conn:
        rows = await conn.fetch(
            """
            SELECT ct.*, 
                   COUNT(cm.id) as message_count,
                   MAX(cm.created_at) as last_message_at
            FROM chat_threads ct
            LEFT JOIN chat_messages cm ON ct.id = cm.thread_id AND cm.is_deleted = FALSE
            GROUP BY ct.id, ct.title, ct.description, ct.created_by, ct.created_at
            ORDER BY COALESCE(MAX(cm.created_at), ct.created_at) DESC
            """
        )
        
        threads = []
        for row in rows:
            threads.append({
                "id": row['id'],
                "title": row['title'],
                "description": row['description'],
                "created_by": row['created_by'],
                "created_at": row['created_at'].isoformat(),
                "message_count": row['message_count'] or 0,
                "last_message_at": row['last_message_at'].isoformat() if row['last_message_at'] else None
            })
        
        return threads

@router.post("/threads")
async def create_chat_thread(user: AuthorizedUser, thread: CreateThreadRequest):
    """Create a new chat thread"""
    async with get_db_connection() as conn:
        thread_id = str(uuid.uuid4())
        
        await conn.execute(
            """
            INSERT INTO chat_threads (id, title, description, created_by)
            VALUES ($1, $2, $3, $4)
            """,
            thread_id, thread.title, thread.description, user.sub
        )
        
        # Get the created thread
        row = await conn.fetchrow(
            "SELECT * FROM chat_threads WHERE id = $1",
            thread_id
        )
        
        return {
            "id": row['id'],
            "title": row['title'],
            "description": row['description'],
            "created_by": row['created_by'],
            "created_at": row['created_at'].isoformat(),
            "message_count": 0,
            "last_message_at": None
        }

@router.post("/messages/{message_id}/react")
async def react_to_message(message_id: str, reaction: ReactionRequest):
    """Add or remove a reaction to a message"""
    async with get_db_connection() as conn:
        # Validate message_id is a proper UUID
        try:
            uuid.UUID(message_id)
        except ValueError:
            raise HTTPException(status_code=400, detail="Invalid message_id format")
            
        # Get current reactions
        row = await conn.fetchrow(
            "SELECT reactions FROM chat_messages WHERE id = $1",
            message_id
        )
        
        if not row:
            raise HTTPException(status_code=404, detail="Message not found")
        
        # Parse existing reactions
        current_reactions = {}
        if row['reactions']:
            try:
                if isinstance(row['reactions'], str):
                    current_reactions = json.loads(row['reactions'])
                else:
                    current_reactions = row['reactions']
            except:
                current_reactions = {}
        
        # Update reactions
        reaction_type = reaction.reaction_type
        user_id = reaction.user_id
        
        if reaction_type not in current_reactions:
            current_reactions[reaction_type] = []
        
        # Toggle reaction (add if not present, remove if present)
        if user_id in current_reactions[reaction_type]:
            current_reactions[reaction_type].remove(user_id)
            if not current_reactions[reaction_type]:  # Remove empty reaction type
                del current_reactions[reaction_type]
        else:
            current_reactions[reaction_type].append(user_id)
        
        # Update in database
        await conn.execute(
            "UPDATE chat_messages SET reactions = $1 WHERE id = $2",
            json.dumps(current_reactions), message_id
        )
        
        return {"message": "Reaction updated", "reactions": current_reactions}

@router.delete("/messages/{message_id}")
async def delete_message(message_id: str, user: AuthorizedUser):
    """Delete a chat message (admin only or message author)"""
    async with get_db_connection() as conn:
        # Validate message_id is a proper UUID
        try:
            uuid.UUID(message_id)
        except ValueError:
            raise HTTPException(status_code=400, detail="Invalid message_id format")
            
        # Get message to check ownership
        message = await conn.fetchrow(
            "SELECT user_id, content FROM chat_messages WHERE id = $1",
            message_id
        )
        
        if not message:
            raise HTTPException(status_code=404, detail="Message not found")
        
        # Check if user can delete (is author or admin)
        if message['user_id'] != user.sub and not is_admin_user(user):
            raise HTTPException(status_code=403, detail="Insufficient permissions to delete this message")
        
        # Mark message as deleted instead of hard delete for audit trail
        await conn.execute(
            """UPDATE chat_messages 
               SET content = '[This message has been deleted]', 
                   is_deleted = TRUE,
                   updated_at = NOW()
               WHERE id = $1""",
            message_id
        )
        
        return {"message": "Message deleted successfully"}

@router.post("/admin/block-user")
async def block_user(request: BlockUserRequest, user: AuthorizedUser):
    """Block a user from chat (admin only)"""
    # TODO: Add admin role check
    async with get_db_connection() as conn:
        await conn.execute(
            """
            INSERT INTO chat_user_blocks (user_id, blocked_by, reason, created_at)
            VALUES ($1, $2, $3, NOW())
            ON CONFLICT (user_id) DO UPDATE SET
                blocked_by = $2,
                reason = $3,
                created_at = NOW()
            """,
            request.user_id, user.sub, request.reason
        )
        
        return {"message": "User blocked"}

@router.post("/admin/delete-chat")
async def delete_chat(request: DeleteChatRequest, user: AuthorizedUser):
    """Delete chat content (admin only)"""
    # TODO: Add admin role check
    async with get_db_connection() as conn:
        if request.message_id:
            # Delete specific message
            await conn.execute(
                "UPDATE chat_messages SET is_deleted = TRUE WHERE id = $1",
                request.message_id
            )
        elif request.thread_id:
            # Delete entire thread
            await conn.execute(
                "UPDATE chat_threads SET is_deleted = TRUE WHERE id = $1",
                request.thread_id
            )
            await conn.execute(
                "UPDATE chat_messages SET is_deleted = TRUE WHERE thread_id = $1",
                request.thread_id
            )
        
        return {"message": "Content deleted"}

@router.get("/chat-policy")
async def get_chat_policy():
    """Get the chat community guidelines and policy"""
    return {
        "policy": {
            "title": "Community Chat Guidelines",
            "rules": [
                "Be respectful and professional in all communications",
                "Stay on-topic related to compliance and export control",
                "No spam, self-promotion, or off-topic content",
                "Respect privacy - no sharing of confidential information",
                "Use appropriate language and maintain professional standards",
                "Report inappropriate behavior to moderators"
            ],
            "consequences": [
                "First violation: Warning",
                "Second violation: Temporary suspension (24 hours)",
                "Third violation: Extended suspension (7 days)",
                "Repeated violations: Permanent ban"
            ],
            "contact": "For questions or reports, contact the administrator"
        }
    }

@router.get("/admin/check-user-blocked")
async def check_user_blocked(user_id: str, user: AuthorizedUser):
    """Check if a user is blocked (admin only)"""
    # TODO: Add admin role check
    async with get_db_connection() as conn:
        row = await conn.fetchrow(
            "SELECT * FROM chat_user_blocks WHERE user_id = $1",
            user_id
        )
        
        return {"is_blocked": row is not None, "block_info": dict(row) if row else None}
