
from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel
from typing import List, Dict, Any, Optional
import asyncpg
import databutton as db
from datetime import datetime, timedelta, timezone
from app.auth import AuthorizedUser
from app.env import Mode, mode

router = APIRouter(prefix="/monitoring-analytics")

# Database connection helper
async def get_db_connection():
    if mode == Mode.PROD:
        database_url = db.secrets.get("DATABASE_URL_PROD")
    else:
        database_url = db.secrets.get("DATABASE_URL_DEV")
    return await asyncpg.connect(database_url)

# Pydantic Models
class MonitoringDashboardResponse(BaseModel):
    total_customers: int
    high_risk_customers: int
    active_schedules: int
    completed_screenings_today: int
    pending_alerts: int
    system_health_score: float
    last_updated: datetime

class CustomerMonitoringAnalytics(BaseModel):
    by_risk_level: Dict[str, int]
    by_type: Dict[str, int]
    by_geography: Dict[str, int]
    screening_success_rate: float
    average_screening_time: float
    total_screenings_last_30_days: int

class ScreeningMetricsResponse(BaseModel):
    total_screenings: int
    successful_screenings: int
    failed_screenings: int
    success_rate: float
    average_processing_time: float
    screenings_by_day: List[Dict[str, Any]]
    top_risk_factors: List[Dict[str, Any]]

class AutomationPerformanceResponse(BaseModel):
    total_schedules: int
    active_schedules: int
    completed_jobs_today: int
    failed_jobs_today: int
    automation_efficiency: float
    schedule_performance: List[Dict[str, Any]]

class ComplianceMetricsResponse(BaseModel):
    compliance_score: float
    regulatory_coverage: float
    documentation_completeness: float
    audit_readiness_score: float
    compliance_gaps: List[Dict[str, Any]]
    recent_compliance_activities: List[Dict[str, Any]]

class AlertAnalyticsResponse(BaseModel):
    total_alerts: int
    critical_alerts: int
    pending_alerts: int
    resolved_alerts: int
    alert_response_time: float
    alerts_by_type: Dict[str, int]
    recent_alerts: List[Dict[str, Any]]

class TrendAnalysisResponse(BaseModel):
    customer_growth_trend: List[Dict[str, Any]]
    risk_score_trends: List[Dict[str, Any]]
    screening_volume_trend: List[Dict[str, Any]]
    automation_usage_trend: List[Dict[str, Any]]

# Helper functions
async def calculate_system_health_score(conn, user_id: str) -> float:
    """Calculate overall system health score based on various metrics"""
    try:
        # Get various health indicators
        screening_success = await conn.fetchval(
            """
            SELECT COALESCE(AVG(CASE WHEN status = 'completed' THEN 100.0 ELSE 0.0 END), 0)
            FROM automation_jobs 
            WHERE user_id = $1 AND created_at >= NOW() - INTERVAL '7 days'
            """,
            user_id
        )
        
        active_schedules = await conn.fetchval(
            "SELECT COUNT(*) FROM monitoring_schedules WHERE user_id = $1 AND is_active = true",
            user_id
        )
        
        # Simple health calculation - can be enhanced
        health_score = min(100.0, (screening_success or 0.0) * 0.6 + min((active_schedules or 0) * 10, 40))
        return round(health_score, 1)
        
    except Exception:
        return 75.0  # Default health score

# API Endpoints
@router.get("/dashboard-summary", response_model=MonitoringDashboardResponse)
async def get_monitoring_dashboard_summary(user: AuthorizedUser):
    """Get comprehensive monitoring dashboard summary with key metrics"""
    conn = await get_db_connection()
    try:
        # Get total customers
        total_customers = await conn.fetchval(
            "SELECT COUNT(*) FROM customer_profiles WHERE created_by = $1",
            user.sub
        ) or 0
        
        # Get high-risk customers
        high_risk_customers = await conn.fetchval(
            "SELECT COUNT(*) FROM customer_profiles WHERE created_by = $1 AND risk_level = 'high'",
            user.sub
        ) or 0
        
        # Get active schedules
        active_schedules = await conn.fetchval(
            "SELECT COUNT(*) FROM monitoring_schedules WHERE user_id = $1 AND is_active = true",
            user.sub
        ) or 0
        
        # Get completed screenings today
        completed_today = await conn.fetchval(
            """
            SELECT COUNT(*) FROM automation_jobs 
            WHERE user_id = $1 AND status = 'completed' 
            AND DATE(created_at) = CURRENT_DATE
            """,
            user.sub
        ) or 0
        
        # Get pending alerts
        pending_alerts = await conn.fetchval(
            """
            SELECT COUNT(*) FROM notification_logs 
            WHERE user_id = $1 AND status = 'pending'
            """,
            user.sub
        ) or 0
        
        # Calculate system health score
        health_score = await calculate_system_health_score(conn, user.sub)
        
        return MonitoringDashboardResponse(
            total_customers=total_customers,
            high_risk_customers=high_risk_customers,
            active_schedules=active_schedules,
            completed_screenings_today=completed_today,
            pending_alerts=pending_alerts,
            system_health_score=health_score,
            last_updated=datetime.now(timezone.utc)
        )
        
    finally:
        await conn.close()

@router.get("/customer-analytics", response_model=CustomerMonitoringAnalytics)
async def get_customer_monitoring_analytics(user: AuthorizedUser):
    """Get detailed customer monitoring analytics and distribution metrics"""
    conn = await get_db_connection()
    try:
        # Risk level distribution
        risk_data = await conn.fetch(
            """
            SELECT 
                COALESCE(risk_level, 'unknown') as risk_level,
                COUNT(*) as count
            FROM customer_profiles 
            WHERE created_by = $1
            GROUP BY risk_level
            """,
            user.sub
        )
        risk_distribution = {row['risk_level']: row['count'] for row in risk_data}
        
        # Customer type distribution
        type_data = await conn.fetch(
            """
            SELECT 
                COALESCE(customer_type, 'individual') as customer_type,
                COUNT(*) as count
            FROM customer_profiles 
            WHERE created_by = $1
            GROUP BY customer_type
            """,
            user.sub
        )
        type_distribution = {row['customer_type']: row['count'] for row in type_data}
        
        # Geography distribution
        geo_data = await conn.fetch(
            """
            SELECT 
                COALESCE(country, 'unknown') as country,
                COUNT(*) as count
            FROM customer_profiles 
            WHERE created_by = $1
            GROUP BY country
            ORDER BY count DESC
            LIMIT 10
            """,
            user.sub
        )
        geo_distribution = {row['country']: row['count'] for row in geo_data}
        
        # Screening metrics
        screening_stats = await conn.fetchrow(
            """
            SELECT 
                COUNT(*) as total_screenings,
                COUNT(*) FILTER (WHERE status = 'completed') as successful,
                AVG(EXTRACT(EPOCH FROM (completed_at - started_at))) as avg_time
            FROM automation_jobs 
            WHERE user_id = $1 AND started_at >= NOW() - INTERVAL '30 days'
            """,
            user.sub
        )
        
        success_rate = 0.0
        avg_time = 0.0
        total_30_days = 0
        
        if screening_stats:
            total_30_days = screening_stats['total_screenings'] or 0
            if total_30_days > 0:
                success_rate = (screening_stats['successful'] or 0) / total_30_days * 100
            avg_time = screening_stats['avg_time'] or 0.0
        
        return CustomerMonitoringAnalytics(
            by_risk_level=risk_distribution,
            by_type=type_distribution,
            by_geography=geo_distribution,
            screening_success_rate=round(success_rate, 1),
            average_screening_time=round(avg_time, 2),
            total_screenings_last_30_days=total_30_days
        )
        
    finally:
        await conn.close()

@router.get("/screening-metrics", response_model=ScreeningMetricsResponse)
async def get_screening_performance_metrics(user: AuthorizedUser, days: int = 30):
    """Get detailed screening performance metrics"""
    conn = await get_db_connection()
    try:
        # Overall screening stats
        overall_stats = await conn.fetchrow(
            """
            SELECT 
                COUNT(*) as total_screenings,
                COUNT(*) FILTER (WHERE status = 'completed') as successful,
                COUNT(*) FILTER (WHERE status = 'failed') as failed,
                AVG(EXTRACT(EPOCH FROM (completed_at - started_at))) as avg_time
            FROM automation_jobs 
            WHERE user_id = $1 AND created_at >= NOW() - INTERVAL '%s days'
            """ % days,
            user.sub
        )
        
        total = overall_stats['total_screenings'] or 0
        successful = overall_stats['successful'] or 0
        failed = overall_stats['failed'] or 0
        success_rate = (successful / total * 100) if total > 0 else 0.0
        avg_time = overall_stats['avg_time'] or 0.0
        
        # Daily screening data
        daily_data = await conn.fetch(
            """
            SELECT 
                DATE(created_at) as screening_date,
                COUNT(*) as total,
                COUNT(*) FILTER (WHERE status = 'completed') as successful
            FROM automation_jobs 
            WHERE user_id = $1 AND created_at >= NOW() - INTERVAL '%s days'
            GROUP BY DATE(created_at)
            ORDER BY screening_date DESC
            """ % days,
            user.sub
        )
        
        screenings_by_day = [
            {
                "date": row['screening_date'].isoformat(),
                "total": row['total'],
                "successful": row['successful'],
                "success_rate": (row['successful'] / row['total'] * 100) if row['total'] > 0 else 0
            }
            for row in daily_data
        ]
        
        # Top risk factors (simulated data for now)
        top_risk_factors = [
            {"factor": "Sanctions Match", "count": 45, "percentage": 35.2},
            {"factor": "High-Risk Geography", "count": 32, "percentage": 25.0},
            {"factor": "PEP Status", "count": 28, "percentage": 21.9},
            {"factor": "Adverse Media", "count": 23, "percentage": 17.9}
        ]
        
        return ScreeningMetricsResponse(
            total_screenings=total,
            successful_screenings=successful,
            failed_screenings=failed,
            success_rate=round(success_rate, 1),
            average_processing_time=round(avg_time, 2),
            screenings_by_day=screenings_by_day,
            top_risk_factors=top_risk_factors
        )
        
    finally:
        await conn.close()

@router.get("/automation-performance", response_model=AutomationPerformanceResponse)
async def get_automation_performance_metrics(user: AuthorizedUser):
    """Get automation system performance metrics"""
    conn = await get_db_connection()
    try:
        # Schedule stats
        schedule_stats = await conn.fetchrow(
            """
            SELECT 
                COUNT(*) as total_schedules,
                COUNT(*) FILTER (WHERE is_active = true) as active_schedules
            FROM monitoring_schedules 
            WHERE user_id = $1
            """,
            user.sub
        )
        
        # Today's job stats
        job_stats = await conn.fetchrow(
            """
            SELECT 
                COUNT(*) FILTER (WHERE status = 'completed') as completed_today,
                COUNT(*) FILTER (WHERE status = 'failed') as failed_today
            FROM automation_jobs 
            WHERE user_id = $1 AND DATE(created_at) = CURRENT_DATE
            """,
            user.sub
        )
        
        total_schedules = schedule_stats['total_schedules'] or 0
        active_schedules = schedule_stats['active_schedules'] or 0
        completed_today = job_stats['completed_today'] or 0
        failed_today = job_stats['failed_today'] or 0
        
        # Calculate efficiency
        total_today = completed_today + failed_today
        efficiency = (completed_today / total_today * 100) if total_today > 0 else 100.0
        
        # Schedule performance
        schedule_performance = await conn.fetch(
            """
            SELECT 
                ms.schedule_name,
                ms.schedule_type,
                COUNT(aj.id) as job_count,
                COUNT(aj.id) FILTER (WHERE aj.status = 'completed') as successful_jobs,
                ms.last_run_at
            FROM monitoring_schedules ms
            LEFT JOIN automation_jobs aj ON ms.id = aj.schedule_id
            WHERE ms.user_id = $1
            GROUP BY ms.id, ms.schedule_name, ms.schedule_type, ms.last_run_at
            ORDER BY job_count DESC
            """,
            user.sub
        )
        
        performance_data = [
            {
                "schedule_name": row['schedule_name'],
                "schedule_type": row['schedule_type'],
                "total_jobs": row['job_count'],
                "successful_jobs": row['successful_jobs'],
                "success_rate": (row['successful_jobs'] / row['job_count'] * 100) if row['job_count'] > 0 else 0,
                "last_run": row['last_run_at'].isoformat() if row['last_run_at'] else None
            }
            for row in schedule_performance
        ]
        
        return AutomationPerformanceResponse(
            total_schedules=total_schedules,
            active_schedules=active_schedules,
            completed_jobs_today=completed_today,
            failed_jobs_today=failed_today,
            automation_efficiency=round(efficiency, 1),
            schedule_performance=performance_data
        )
        
    finally:
        await conn.close()

@router.get("/compliance-metrics", response_model=ComplianceMetricsResponse)
async def get_compliance_regulatory_metrics(user: AuthorizedUser):
    """Get compliance and regulatory metrics"""
    conn = await get_db_connection()
    try:
        # Calculate compliance score based on various factors
        customer_count = await conn.fetchval(
            "SELECT COUNT(*) FROM customer_profiles WHERE created_by = $1",
            user.sub
        ) or 0
        
        screened_count = await conn.fetchval(
            """
            SELECT COUNT(DISTINCT cp.id) 
            FROM customer_profiles cp
            JOIN automation_jobs aj ON aj.user_id = cp.created_by
            WHERE cp.created_by = $1 AND aj.status = 'completed'
            """,
            user.sub
        ) or 0
        
        # Basic compliance calculations
        regulatory_coverage = (screened_count / customer_count * 100) if customer_count > 0 else 0
        documentation_completeness = min(100, regulatory_coverage * 1.2)  # Simulated
        audit_readiness = min(100, (regulatory_coverage + documentation_completeness) / 2)
        compliance_score = (regulatory_coverage + documentation_completeness + audit_readiness) / 3
        
        # Compliance gaps (simulated data)
        compliance_gaps = [
            {"area": "Customer Due Diligence", "severity": "medium", "count": 12},
            {"area": "Sanctions Screening", "severity": "low", "count": 3},
            {"area": "Document Retention", "severity": "high", "count": 8}
        ]
        
        # Recent activities (simulated data)
        recent_activities = [
            {
                "activity": "Completed weekly sanctions screening",
                "timestamp": (datetime.now() - timedelta(hours=2)).isoformat(),
                "status": "completed"
            },
            {
                "activity": "Updated customer risk profiles",
                "timestamp": (datetime.now() - timedelta(days=1)).isoformat(),
                "status": "completed"
            }
        ]
        
        return ComplianceMetricsResponse(
            compliance_score=round(compliance_score, 1),
            regulatory_coverage=round(regulatory_coverage, 1),
            documentation_completeness=round(documentation_completeness, 1),
            audit_readiness_score=round(audit_readiness, 1),
            compliance_gaps=compliance_gaps,
            recent_compliance_activities=recent_activities
        )
        
    finally:
        await conn.close()

@router.get("/alert-analytics", response_model=AlertAnalyticsResponse)
async def get_monitoring_alert_analytics(user: AuthorizedUser):
    """Get alert system analytics and metrics"""
    conn = await get_db_connection()
    try:
        # Alert stats
        alert_stats = await conn.fetchrow(
            """
            SELECT 
                COUNT(*) as total_alerts,
                COUNT(*) FILTER (WHERE alert_level = 'critical') as critical_alerts,
                COUNT(*) FILTER (WHERE status = 'pending') as pending_alerts,
                COUNT(*) FILTER (WHERE status = 'resolved') as resolved_alerts
            FROM notification_logs 
            WHERE user_id = $1 AND created_at >= NOW() - INTERVAL '30 days'
            """,
            user.sub
        )
        
        # Calculate average response time (simulated)
        response_time = 4.2  # hours
        
        # Alerts by type (simulated)
        alerts_by_type = {
            "high_risk_match": 23,
            "sanctions_alert": 15,
            "pep_match": 12,
            "system_alert": 8,
            "compliance_reminder": 6
        }
        
        # Recent alerts (simulated)
        recent_alerts = [
            {
                "id": 1,
                "type": "high_risk_match",
                "customer": "ABC Corp Ltd",
                "severity": "high",
                "timestamp": (datetime.now() - timedelta(hours=1)).isoformat(),
                "status": "pending"
            },
            {
                "id": 2,
                "type": "sanctions_alert",
                "customer": "XYZ Industries",
                "severity": "critical",
                "timestamp": (datetime.now() - timedelta(hours=3)).isoformat(),
                "status": "resolved"
            }
        ]
        
        return AlertAnalyticsResponse(
            total_alerts=alert_stats['total_alerts'] or 0,
            critical_alerts=alert_stats['critical_alerts'] or 0,
            pending_alerts=alert_stats['pending_alerts'] or 0,
            resolved_alerts=alert_stats['resolved_alerts'] or 0,
            alert_response_time=response_time,
            alerts_by_type=alerts_by_type,
            recent_alerts=recent_alerts
        )
        
    finally:
        await conn.close()

@router.get("/trend-analysis", response_model=TrendAnalysisResponse)
async def get_trend_analysis(user: AuthorizedUser, days: int = 90):
    """Get trend analysis data for various metrics"""
    conn = await get_db_connection()
    try:
        # Customer growth trend
        customer_growth = await conn.fetch(
            """
            SELECT 
                DATE_TRUNC('week', created_at) as week,
                COUNT(*) as new_customers
            FROM customer_profiles 
            WHERE created_by = $1 AND created_at >= NOW() - INTERVAL '%s days'
            GROUP BY DATE_TRUNC('week', created_at)
            ORDER BY week
            """ % days,
            user.sub
        )
        
        growth_trend = [
            {
                "period": row['week'].isoformat(),
                "value": row['new_customers'],
                "metric": "new_customers"
            }
            for row in customer_growth
        ]
        
        # Screening volume trend
        screening_volume = await conn.fetch(
            """
            SELECT 
                DATE_TRUNC('week', created_at) as week,
                COUNT(*) as screenings
            FROM automation_jobs 
            WHERE user_id = $1 AND created_at >= NOW() - INTERVAL '%s days'
            GROUP BY DATE_TRUNC('week', created_at)
            ORDER BY week
            """ % days,
            user.sub
        )
        
        volume_trend = [
            {
                "period": row['week'].isoformat(),
                "value": row['screenings'],
                "metric": "screening_volume"
            }
            for row in screening_volume
        ]
        
        # Simulated risk score trends and automation usage
        risk_trends = [
            {"period": (datetime.now() - timedelta(weeks=i)).isoformat(), "value": 65 + i * 2, "metric": "avg_risk_score"}
            for i in range(12, 0, -1)
        ]
        
        automation_trends = [
            {"period": (datetime.now() - timedelta(weeks=i)).isoformat(), "value": 20 + i * 3, "metric": "automation_usage"}
            for i in range(12, 0, -1)
        ]
        
        return TrendAnalysisResponse(
            customer_growth_trend=growth_trend,
            risk_score_trends=risk_trends,
            screening_volume_trend=volume_trend,
            automation_usage_trend=automation_trends
        )
        
    finally:
        await conn.close()
