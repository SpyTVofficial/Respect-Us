from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import List, Dict, Any, Optional
from app.auth import AuthorizedUser
from app.libs.cross_reference_detector import CrossReferenceDetector
import asyncpg
import databutton as db
from app.env import Mode, mode

router = APIRouter(prefix="/cross-references")

# Pydantic models
class CrossReferenceResponse(BaseModel):
    id: int
    title: str
    description: Optional[str] = None
    country_jurisdiction: Optional[List[str]] = None
    regulation_type: Optional[List[str]] = None
    reference_text: str
    reference_type: str
    relevance_score: float

class ProcessReferenceRequest(BaseModel):
    document_id: int
    content: str

class ProcessReferenceResponse(BaseModel):
    references_found: int
    related_documents: List[CrossReferenceResponse]
    processing_time_ms: int

class ExtractReferencesRequest(BaseModel):
    text: str

class ExtractedReference(BaseModel):
    text: str
    start: int
    end: int
    type: str
    groups: List[str]

class ExtractReferencesResponse(BaseModel):
    references: List[ExtractedReference]
    total_count: int

# Database connection
async def get_db_connection():
    if mode == Mode.PROD:
        database_url = db.secrets.get("DATABASE_URL_PROD")
    else:
        database_url = db.secrets.get("DATABASE_URL_DEV")
    return await asyncpg.connect(database_url)

@router.get("/document/{document_id}", response_model=List[CrossReferenceResponse])
async def get_document_cross_references(
    document_id: int,
    user: AuthorizedUser
):
    """Get cross-references for a specific document"""
    try:
        detector = CrossReferenceDetector()
        cross_refs = await detector.get_cross_references(document_id)
        
        return [
            CrossReferenceResponse(
                id=ref['id'],
                title=ref['title'],
                description=ref['description'],
                country_jurisdiction=ref['country_jurisdiction'],
                regulation_type=ref['regulation_type'],
                reference_text=ref['reference_text'],
                reference_type=ref['reference_type'],
                relevance_score=ref['relevance_score']
            )
            for ref in cross_refs
        ]
        
    except Exception as e:
        print(f"Error getting cross-references for document {document_id}: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to get cross-references: {str(e)}")

@router.post("/process", response_model=ProcessReferenceResponse)
async def process_document_references(
    request: ProcessReferenceRequest,
    user: AuthorizedUser
):
    """Process a document to extract and link cross-references"""
    import time
    start_time = time.time()
    
    try:
        detector = CrossReferenceDetector()
        
        # Process the document
        related_docs = await detector.process_document_references(
            request.document_id, 
            request.content
        )
        
        processing_time = int((time.time() - start_time) * 1000)
        
        # Extract references for count
        references = detector.extract_references(request.content)
        
        return ProcessReferenceResponse(
            references_found=len(references),
            related_documents=[
                CrossReferenceResponse(
                    id=doc['id'],
                    title=doc['title'],
                    description=doc['description'],
                    country_jurisdiction=doc['country_jurisdiction'],
                    regulation_type=doc['regulation_type'],
                    reference_text=doc['reference_text'],
                    reference_type=doc['reference_type'],
                    relevance_score=doc['relevance_score']
                )
                for doc in related_docs
            ],
            processing_time_ms=processing_time
        )
        
    except Exception as e:
        print(f"Error processing cross-references for document {request.document_id}: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to process cross-references: {str(e)}")

@router.post("/extract", response_model=ExtractReferencesResponse)
async def extract_references_from_text(
    request: ExtractReferencesRequest,
    user: AuthorizedUser
):
    """Extract regulatory references from text"""
    try:
        detector = CrossReferenceDetector()
        references = detector.extract_references(request.text)
        
        return ExtractReferencesResponse(
            references=[
                ExtractedReference(
                    text=ref['text'],
                    start=ref['start'],
                    end=ref['end'],
                    type=ref['type'],
                    groups=list(ref['groups'])
                )
                for ref in references
            ],
            total_count=len(references)
        )
        
    except Exception as e:
        print(f"Error extracting references from text: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to extract references: {str(e)}")

@router.post("/rebuild/{document_id}")
async def rebuild_document_cross_references(
    document_id: int,
    user: AuthorizedUser
):
    """Rebuild cross-references for a specific document"""
    try:
        # Get document content from database
        conn = await get_db_connection()
        try:
            row = await conn.fetchrow(
                "SELECT content_text FROM kb_documents WHERE id = $1",
                document_id
            )
            
            if not row:
                raise HTTPException(status_code=404, detail="Document not found")
            
            content = row['content_text'] or ""
            
        finally:
            await conn.close()
        
        # Process cross-references
        detector = CrossReferenceDetector()
        related_docs = await detector.process_document_references(document_id, content)
        
        return {
            "message": "Cross-references rebuilt successfully",
            "document_id": document_id,
            "related_documents_found": len(related_docs)
        }
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error rebuilding cross-references for document {document_id}: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to rebuild cross-references: {str(e)}")

@router.post("/rebuild-all")
async def rebuild_all_cross_references(
    user: AuthorizedUser
):
    """Rebuild cross-references for all documents (admin only)"""
    try:
        # Get all documents
        conn = await get_db_connection()
        try:
            rows = await conn.fetch(
                "SELECT id, content_text FROM kb_documents WHERE content_text IS NOT NULL AND content_text != ''"
            )
        finally:
            await conn.close()
        
        detector = CrossReferenceDetector()
        processed_count = 0
        total_related = 0
        
        for row in rows:
            try:
                related_docs = await detector.process_document_references(
                    row['id'], 
                    row['content_text'] or ""
                )
                processed_count += 1
                total_related += len(related_docs)
                
            except Exception as e:
                print(f"Error processing document {row['id']}: {str(e)}")
                continue
        
        return {
            "message": "Cross-references rebuilt for all documents",
            "documents_processed": processed_count,
            "total_documents": len(rows),
            "total_cross_references": total_related
        }
        
    except Exception as e:
        print(f"Error rebuilding all cross-references: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to rebuild all cross-references: {str(e)}")

@router.get("/stats")
async def get_cross_reference_stats(
    user: AuthorizedUser
):
    """Get statistics about cross-references in the system"""
    try:
        conn = await get_db_connection()
        try:
            # Check if table exists
            table_exists = await conn.fetchval("""
                SELECT EXISTS (
                    SELECT FROM information_schema.tables 
                    WHERE table_name = 'document_cross_references'
                )
            """)
            
            if not table_exists:
                return {
                    "total_cross_references": 0,
                    "documents_with_references": 0,
                    "avg_references_per_document": 0.0,
                    "reference_types": {},
                    "top_referenced_documents": []
                }
            
            # Get basic stats
            total_refs = await conn.fetchval(
                "SELECT COUNT(*) FROM document_cross_references"
            )
            
            docs_with_refs = await conn.fetchval(
                "SELECT COUNT(DISTINCT source_document_id) FROM document_cross_references"
            )
            
            avg_refs = await conn.fetchval(
                "SELECT AVG(ref_count) FROM (SELECT COUNT(*) as ref_count FROM document_cross_references GROUP BY source_document_id) as subq"
            ) or 0.0
            
            # Get reference type distribution
            type_stats = await conn.fetch(
                "SELECT reference_type, COUNT(*) as count FROM document_cross_references GROUP BY reference_type ORDER BY count DESC"
            )
            
            # Get top referenced documents
            top_docs = await conn.fetch("""
                SELECT 
                    d.title,
                    d.id,
                    COUNT(*) as reference_count
                FROM document_cross_references cr
                JOIN kb_documents d ON cr.target_document_id = d.id
                GROUP BY d.id, d.title
                ORDER BY reference_count DESC
                LIMIT 10
            """)
            
        finally:
            await conn.close()
        
        return {
            "total_cross_references": total_refs,
            "documents_with_references": docs_with_refs,
            "avg_references_per_document": float(avg_refs),
            "reference_types": {row['reference_type']: row['count'] for row in type_stats},
            "top_referenced_documents": [
                {
                    "id": row['id'],
                    "title": row['title'],
                    "reference_count": row['reference_count']
                }
                for row in top_docs
            ]
        }
        
    except Exception as e:
        print(f"Error getting cross-reference stats: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to get stats: {str(e)}")
