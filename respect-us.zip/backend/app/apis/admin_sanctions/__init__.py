


from fastapi import APIRouter, HTTPException, UploadFile, File, Query, Form
from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
import asyncpg
import databutton as db
from app.auth import AuthorizedUser
from app.env import Mode, mode
from datetime import datetime
from fastapi.responses import StreamingResponse
import json
import csv
import io

router = APIRouter(prefix="/admin-sanctions")

# ============================================================================
# Data Models
# ============================================================================

class SanctionEntityCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=500)
    entity_type: str = Field(..., description="person, entity, vessel, aircraft")
    aliases: List[str] = Field(default_factory=list)
    sanctions_program: str = Field(..., min_length=1, max_length=200)
    jurisdiction: str = Field(..., min_length=1, max_length=100)
    risk_level: str = Field(..., description="high, medium, low")
    description: Optional[str] = Field(None, max_length=2000)
    source_list: str = Field(..., min_length=1, max_length=200)
    details: Optional[Dict[str, Any]] = Field(default_factory=dict)
    status: str = Field(default="active", description="active, inactive, pending")

class SanctionEntityUpdate(BaseModel):
    name: Optional[str] = Field(None, min_length=1, max_length=500)
    entity_type: Optional[str] = None
    aliases: Optional[List[str]] = None
    sanctions_program: Optional[str] = Field(None, min_length=1, max_length=200)
    jurisdiction: Optional[str] = Field(None, min_length=1, max_length=100)
    risk_level: Optional[str] = None
    description: Optional[str] = Field(None, max_length=2000)
    source_list: Optional[str] = Field(None, min_length=1, max_length=200)
    details: Optional[Dict[str, Any]] = None
    status: Optional[str] = None

class SanctionEntityResponse(BaseModel):
    id: str
    name: str
    entity_type: str
    aliases: List[str]
    sanctions_program: str
    jurisdiction: str
    risk_level: str
    description: Optional[str]
    source_list: str
    details: Optional[Dict[str, Any]]
    status: str
    date_added: datetime
    last_updated: datetime
    created_by: str
    updated_by: Optional[str]

class SanctionEntitiesResponse(BaseModel):
    entities: List[SanctionEntityResponse]
    total: int
    page: int
    page_size: int
    total_pages: int

class BulkImportResponse(BaseModel):
    success: bool
    imported_count: int
    updated_count: int
    failed_count: int
    errors: List[str]
    summary: str

class SanctionSourceResponse(BaseModel):
    source_list: str
    jurisdiction: str
    entity_count: int
    last_updated: datetime
    status: str

class SanctionAuditLogResponse(BaseModel):
    id: int
    entity_id: str
    action: str
    changes: Optional[Dict[str, Any]]
    performed_by: str
    performed_at: datetime
    notes: Optional[str]

# ============================================================================
# Database Connection
# ============================================================================

async def get_db_connection():
    """Get database connection based on environment"""
    if mode == Mode.PROD:
        database_url = db.secrets.get("DATABASE_URL_PROD")
    else:
        database_url = db.secrets.get("DATABASE_URL_DEV")
    
    return await asyncpg.connect(database_url)

# ============================================================================
# CRUD Operations
# ============================================================================

@router.get("/entities", response_model=SanctionEntitiesResponse)
async def list_sanction_entities(
    user: AuthorizedUser,
    page: int = Query(default=1, ge=1),
    page_size: int = Query(default=20, ge=1, le=100),
    search: Optional[str] = Query(default=None),
    entity_type: Optional[str] = Query(default=None),
    jurisdiction: Optional[str] = Query(default=None),
    risk_level: Optional[str] = Query(default=None),
    status: Optional[str] = Query(default="active")
) -> SanctionEntitiesResponse:
    """List sanction entities with filtering and pagination"""
    print(f"📋 Admin listing sanction entities - Page {page}, Size {page_size}")
    
    try:
        conn = await get_db_connection()
        
        try:
            # Build dynamic WHERE clause
            where_conditions = []
            params = []
            param_count = 0
            
            if status:
                param_count += 1
                where_conditions.append(f"status = ${param_count}")
                params.append(status)
            
            if search:
                param_count += 1
                where_conditions.append(f"(name ILIKE ${param_count} OR array_to_string(aliases, ' ') ILIKE ${param_count})")
                params.append(f"%{search}%")
            
            if entity_type:
                param_count += 1
                where_conditions.append(f"entity_type = ${param_count}")
                params.append(entity_type)
            
            if jurisdiction:
                param_count += 1
                where_conditions.append(f"jurisdiction = ${param_count}")
                params.append(jurisdiction)
            
            if risk_level:
                param_count += 1
                where_conditions.append(f"risk_level = ${param_count}")
                params.append(risk_level)
            
            where_clause = " AND ".join(where_conditions) if where_conditions else "TRUE"
            
            # Get total count
            count_query = f"SELECT COUNT(*) FROM admin_sanctions WHERE {where_clause}"
            total = await conn.fetchval(count_query, *params)
            
            # Calculate pagination
            offset = (page - 1) * page_size
            total_pages = (total + page_size - 1) // page_size
            
            # Get entities
            param_count += 1
            params.append(page_size)
            param_count += 1
            params.append(offset)
            
            query = f"""
                SELECT id, name, entity_type, aliases, sanctions_program, jurisdiction,
                       risk_level, description, source_list, details, status,
                       date_added, last_updated, created_by, updated_by
                FROM admin_sanctions
                WHERE {where_clause}
                ORDER BY last_updated DESC, name ASC
                LIMIT ${param_count-1} OFFSET ${param_count}
            """
            
            rows = await conn.fetch(query, *params)
            
            entities = []
            for row in rows:
                entity = SanctionEntityResponse(
                    id=row['id'],
                    name=row['name'],
                    entity_type=row['entity_type'],
                    aliases=row['aliases'] if row['aliases'] else [],
                    sanctions_program=row['sanctions_program'],
                    jurisdiction=row['jurisdiction'],
                    risk_level=row['risk_level'],
                    description=row['description'],
                    source_list=row['source_list'],
                    details=json.loads(row['details']) if row['details'] and isinstance(row['details'], str) else (row['details'] if row['details'] else {}),
                    status=row['status'],
                    date_added=row['date_added'],
                    last_updated=row['last_updated'],
                    created_by=row['created_by'],
                    updated_by=row['updated_by']
                )
                entities.append(entity)
            
            print(f"✅ Retrieved {len(entities)} entities (total: {total})")
            
            return SanctionEntitiesResponse(
                entities=entities,
                total=total,
                page=page,
                page_size=page_size,
                total_pages=total_pages
            )
            
        finally:
            await conn.close()
            
    except Exception as e:
        print(f"❌ Error listing sanction entities: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to list sanction entities: {str(e)}")

@router.post("/entities", response_model=SanctionEntityResponse)
async def create_sanction_entity(
    entity: SanctionEntityCreate,
    user: AuthorizedUser
) -> SanctionEntityResponse:
    """Create a new sanction entity"""
    print(f"➕ Admin creating sanction entity: {entity.name}")
    
    try:
        conn = await get_db_connection()
        
        try:
            # Generate unique ID
            entity_id = f"sanc-{datetime.now().strftime('%Y%m%d%H%M%S')}-{len(entity.name.replace(' ', ''))}"
            
            # Insert entity
            query = """
                INSERT INTO admin_sanctions (
                    id, name, entity_type, aliases, sanctions_program, jurisdiction,
                    risk_level, description, source_list, details, status,
                    date_added, last_updated, created_by
                ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14)
                RETURNING *
            """
            
            now = datetime.now()
            row = await conn.fetchrow(
                query,
                entity_id, entity.name, entity.entity_type, entity.aliases,
                entity.sanctions_program, entity.jurisdiction, entity.risk_level,
                entity.description, entity.source_list, json.dumps(entity.details),
                entity.status, now, now, user.sub
            )
            
            # Log audit trail
            await conn.execute(
                """
                INSERT INTO sanctions_audit_log (entity_id, action, changes, performed_by, notes)
                VALUES ($1, $2, $3, $4, $5)
                """,
                entity_id, "CREATE", json.dumps(entity.dict()), user.sub,
                f"Created new sanction entity: {entity.name}"
            )
            
            response = SanctionEntityResponse(
                id=row['id'],
                name=row['name'],
                entity_type=row['entity_type'],
                aliases=row['aliases'] if row['aliases'] else [],
                sanctions_program=row['sanctions_program'],
                jurisdiction=row['jurisdiction'],
                risk_level=row['risk_level'],
                description=row['description'],
                source_list=row['source_list'],
                details=json.loads(row['details']) if row['details'] and isinstance(row['details'], str) else (row['details'] if row['details'] else {}),
                status=row['status'],
                date_added=row['date_added'],
                last_updated=row['last_updated'],
                created_by=row['created_by'],
                updated_by=row['updated_by']
            )
            
            print(f"✅ Created sanction entity: {entity_id}")
            return response
            
        finally:
            await conn.close()
            
    except Exception as e:
        print(f"❌ Error creating sanction entity: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to create sanction entity: {str(e)}")

@router.get("/entities/{entity_id}", response_model=SanctionEntityResponse)
async def get_admin_sanction_entity(
    entity_id: str,
    user: AuthorizedUser
) -> SanctionEntityResponse:
    """Get a specific sanction entity"""
    print(f"🔍 Admin getting sanction entity: {entity_id}")
    
    try:
        conn = await get_db_connection()
        
        try:
            query = """
                SELECT id, name, entity_type, aliases, sanctions_program, jurisdiction,
                       risk_level, description, source_list, details, status,
                       date_added, last_updated, created_by, updated_by
                FROM admin_sanctions
                WHERE id = $1
            """
            
            row = await conn.fetchrow(query, entity_id)
            
            if not row:
                raise HTTPException(status_code=404, detail="Sanction entity not found")
            
            response = SanctionEntityResponse(
                id=row['id'],
                name=row['name'],
                entity_type=row['entity_type'],
                aliases=row['aliases'] if row['aliases'] else [],
                sanctions_program=row['sanctions_program'],
                jurisdiction=row['jurisdiction'],
                risk_level=row['risk_level'],
                description=row['description'],
                source_list=row['source_list'],
                details=json.loads(row['details']) if row['details'] and isinstance(row['details'], str) else (row['details'] if row['details'] else {}),
                status=row['status'],
                date_added=row['date_added'],
                last_updated=row['last_updated'],
                created_by=row['created_by'],
                updated_by=row['updated_by']
            )
            
            print(f"✅ Retrieved sanction entity: {entity_id}")
            return response
            
        finally:
            await conn.close()
            
    except HTTPException:
        raise
    except Exception as e:
        print(f"❌ Error getting sanction entity: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to get sanction entity: {str(e)}")

@router.put("/entities/{entity_id}", response_model=SanctionEntityResponse)
async def update_sanction_entity(
    entity_id: str,
    entity_update: SanctionEntityUpdate,
    user: AuthorizedUser
) -> SanctionEntityResponse:
    """Update a sanction entity"""
    print(f"✏️ Admin updating sanction entity: {entity_id}")
    
    try:
        conn = await get_db_connection()
        
        try:
            # Get current entity for audit trail
            current_entity = await conn.fetchrow(
                "SELECT * FROM admin_sanctions WHERE id = $1", entity_id
            )
            
            if not current_entity:
                raise HTTPException(status_code=404, detail="Sanction entity not found")
            
            # Build update query dynamically
            update_fields = []
            params = []
            param_count = 0
            
            update_data = entity_update.dict(exclude_unset=True)
            
            for field, value in update_data.items():
                if value is not None:
                    param_count += 1
                    if field == "details":
                        update_fields.append(f"{field} = ${param_count}")
                        params.append(json.dumps(value))
                    else:
                        update_fields.append(f"{field} = ${param_count}")
                        params.append(value)
            
            if not update_fields:
                raise HTTPException(status_code=400, detail="No valid fields to update")
            
            # Add last_updated and updated_by
            param_count += 1
            update_fields.append(f"last_updated = ${param_count}")
            params.append(datetime.now())
            
            param_count += 1
            update_fields.append(f"updated_by = ${param_count}")
            params.append(user.sub)
            
            param_count += 1
            params.append(entity_id)
            
            query = f"""
                UPDATE admin_sanctions
                SET {', '.join(update_fields)}
                WHERE id = ${param_count}
                RETURNING *
            """
            
            row = await conn.fetchrow(query, *params)
            
            # Log audit trail
            await conn.execute(
                """
                INSERT INTO sanctions_audit_log (entity_id, action, changes, performed_by, notes)
                VALUES ($1, $2, $3, $4, $5)
                """,
                entity_id, "UPDATE", json.dumps(update_data), user.sub,
                f"Updated sanction entity: {row['name']}"
            )
            
            response = SanctionEntityResponse(
                id=row['id'],
                name=row['name'],
                entity_type=row['entity_type'],
                aliases=row['aliases'] if row['aliases'] else [],
                sanctions_program=row['sanctions_program'],
                jurisdiction=row['jurisdiction'],
                risk_level=row['risk_level'],
                description=row['description'],
                source_list=row['source_list'],
                details=json.loads(row['details']) if row['details'] and isinstance(row['details'], str) else (row['details'] if row['details'] else {}),
                status=row['status'],
                date_added=row['date_added'],
                last_updated=row['last_updated'],
                created_by=row['created_by'],
                updated_by=row['updated_by']
            )
            
            print(f"✅ Updated sanction entity: {entity_id}")
            return response
            
        finally:
            await conn.close()
            
    except HTTPException:
        raise
    except Exception as e:
        print(f"❌ Error updating sanction entity: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to update sanction entity: {str(e)}")

@router.delete("/entities/{entity_id}")
async def delete_sanction_entity(
    entity_id: str,
    user: AuthorizedUser,
    hard_delete: bool = Query(default=False, description="Permanently delete instead of marking inactive")
):
    """Delete or deactivate a sanction entity"""
    print(f"🗑️ Admin deleting sanction entity: {entity_id} (hard: {hard_delete})")
    
    try:
        conn = await get_db_connection()
        
        try:
            # Check if entity exists
            entity = await conn.fetchrow(
                "SELECT * FROM admin_sanctions WHERE id = $1", entity_id
            )
            
            if not entity:
                raise HTTPException(status_code=404, detail="Sanction entity not found")
            
            if hard_delete:
                # Permanently delete
                await conn.execute(
                    "DELETE FROM admin_sanctions WHERE id = $1", entity_id
                )
                action = "HARD_DELETE"
                message = f"Permanently deleted sanction entity: {entity['name']}"
            else:
                # Soft delete (mark as inactive)
                await conn.execute(
                    "UPDATE admin_sanctions SET status = 'inactive', last_updated = $1, updated_by = $2 WHERE id = $3",
                    datetime.now(), user.sub, entity_id
                )
                action = "SOFT_DELETE"
                message = f"Deactivated sanction entity: {entity['name']}"
            
            # Log audit trail
            await conn.execute(
                """
                INSERT INTO sanctions_audit_log (entity_id, action, performed_by, notes)
                VALUES ($1, $2, $3, $4)
                """,
                entity_id, action, user.sub, message
            )
            
            print(f"✅ {message}")
            return {"success": True, "message": message}
            
        finally:
            await conn.close()
            
    except HTTPException:
        raise
    except Exception as e:
        print(f"❌ Error deleting sanction entity: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to delete sanction entity: {str(e)}")

# ============================================================================
# Bulk Operations
# ============================================================================

@router.post("/bulk-import", response_model=BulkImportResponse)
async def bulk_import_sanctions(
    file: UploadFile = File(...),
    user: AuthorizedUser = None,
    source_list: str = Form(...),
    jurisdiction: str = Form(...),
    update_existing: bool = Form(default=False)
) -> BulkImportResponse:
    """Bulk import sanctions from CSV file"""
    print(f"📤 Admin bulk importing sanctions from {file.filename}")
    
    if not file.filename.endswith('.csv'):
        raise HTTPException(status_code=400, detail="Only CSV files are supported")
    
    try:
        # Read CSV content
        content = await file.read()
        csv_content = content.decode('utf-8')
        csv_reader = csv.DictReader(io.StringIO(csv_content))
        
        conn = await get_db_connection()
        
        try:
            imported_count = 0
            updated_count = 0
            failed_count = 0
            errors = []
            
            for row_num, row in enumerate(csv_reader, start=2):
                try:
                    # Validate required fields
                    required_fields = ['name', 'entity_type', 'sanctions_program', 'risk_level']
                    missing_fields = [field for field in required_fields if not row.get(field)]
                    
                    if missing_fields:
                        error_msg = f"Row {row_num}: Missing required fields: {', '.join(missing_fields)}"
                        errors.append(error_msg)
                        failed_count += 1
                        continue
                    
                    # Parse aliases (comma-separated)
                    aliases = [alias.strip() for alias in row.get('aliases', '').split(',') if alias.strip()]
                    
                    # Parse details JSON if provided
                    details = {}
                    if row.get('details'):
                        try:
                            details = json.loads(row['details'])
                        except json.JSONDecodeError:
                            details = {'raw_details': row['details']}
                    
                    # Generate entity ID
                    entity_id = f"sanc-{datetime.now().strftime('%Y%m%d%H%M%S')}-{row_num}"
                    
                    # Check if entity exists (by name and jurisdiction)
                    existing = await conn.fetchrow(
                        "SELECT id FROM admin_sanctions WHERE name = $1 AND jurisdiction = $2",
                        row['name'], jurisdiction
                    )
                    
                    now = datetime.now()
                    
                    if existing and update_existing:
                        # Update existing entity
                        await conn.execute(
                            """
                            UPDATE admin_sanctions
                            SET entity_type = $1, aliases = $2, sanctions_program = $3,
                                risk_level = $4, description = $5, source_list = $6,
                                details = $7, status = $8, last_updated = $9, updated_by = $10
                            WHERE id = $11
                            """,
                            row['entity_type'], aliases, row['sanctions_program'],
                            row['risk_level'], row.get('description'),
                            source_list, json.dumps(details), row.get('status', 'active'),
                            now, user.sub, existing['id']
                        )
                        updated_count += 1
                        
                        # Log audit trail
                        await conn.execute(
                            """
                            INSERT INTO sanctions_audit_log (entity_id, action, performed_by, notes)
                            VALUES ($1, $2, $3, $4)
                            """,
                            existing['id'], "BULK_UPDATE", user.sub,
                            f"Updated via bulk import from {file.filename}"
                        )
                        
                    elif not existing:
                        # Insert new entity
                        await conn.execute(
                            """
                            INSERT INTO admin_sanctions (
                                id, name, entity_type, aliases, sanctions_program, jurisdiction,
                                risk_level, description, source_list, details, status,
                                date_added, last_updated, created_by
                            ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14)
                            """,
                            entity_id, row['name'], row['entity_type'], aliases,
                            row['sanctions_program'], jurisdiction, row['risk_level'],
                            row.get('description'), source_list, json.dumps(details),
                            row.get('status', 'active'), now, now, user.sub
                        )
                        imported_count += 1
                        
                        # Log audit trail
                        await conn.execute(
                            """
                            INSERT INTO sanctions_audit_log (entity_id, action, performed_by, notes)
                            VALUES ($1, $2, $3, $4)
                            """,
                            entity_id, "BULK_IMPORT", user.sub,
                            f"Imported via bulk import from {file.filename}"
                        )
                    
                except Exception as row_error:
                    error_msg = f"Row {row_num}: {str(row_error)}"
                    errors.append(error_msg)
                    failed_count += 1
                    print(f"❌ Error processing row {row_num}: {row_error}")
            
            summary = f"Import completed: {imported_count} new, {updated_count} updated, {failed_count} failed"
            
            print(f"✅ Bulk import completed: {summary}")
            
            return BulkImportResponse(
                success=True,
                imported_count=imported_count,
                updated_count=updated_count,
                failed_count=failed_count,
                errors=errors[:10],  # Limit error list
                summary=summary
            )
            
        finally:
            await conn.close()
            
    except Exception as e:
        print(f"❌ Error during bulk import: {e}")
        raise HTTPException(status_code=500, detail=f"Bulk import failed: {str(e)}")

@router.get("/export", tags=["stream"])
async def export_sanctions(
    user: AuthorizedUser,
    format: str = Query(default="csv", description="Export format: csv or json"),
    jurisdiction: Optional[str] = Query(default=None),
    status: Optional[str] = Query(default="active")
):
    """Export sanctions data"""
    print(f"📥 Admin exporting sanctions data as {format}")
    
    try:
        conn = await get_db_connection()
        
        try:
            # Build query
            where_conditions = []
            params = []
            param_count = 0
            
            if status:
                param_count += 1
                where_conditions.append(f"status = ${param_count}")
                params.append(status)
            
            if jurisdiction:
                param_count += 1
                where_conditions.append(f"jurisdiction = ${param_count}")
                params.append(jurisdiction)
            
            where_clause = " AND ".join(where_conditions) if where_conditions else "TRUE"
            
            query = f"""
                SELECT id, name, entity_type, aliases, sanctions_program, jurisdiction,
                       risk_level, description, source_list, details, status,
                       date_added, last_updated, created_by, updated_by
                FROM admin_sanctions
                WHERE {where_clause}
                ORDER BY jurisdiction, sanctions_program, name
            """
            
            rows = await conn.fetch(query, *params)
            
            if format.lower() == "csv":
                # Generate CSV
                output = io.StringIO()
                fieldnames = [
                    'id', 'name', 'entity_type', 'aliases', 'sanctions_program',
                    'jurisdiction', 'risk_level', 'description', 'source_list',
                    'details', 'status', 'date_added', 'last_updated', 'created_by', 'updated_by'
                ]
                writer = csv.DictWriter(output, fieldnames=fieldnames)
                writer.writeheader()
                
                for row in rows:
                    row_dict = dict(row)
                    # Convert arrays and objects to strings
                    row_dict['aliases'] = ','.join(row['aliases'] or [])
                    row_dict['details'] = json.dumps(row['details'] or {})
                    row_dict['date_added'] = row['date_added'].isoformat()
                    row_dict['last_updated'] = row['last_updated'].isoformat()
                    writer.writerow(row_dict)
                
                filename = f"sanctions_export_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
                
                return StreamingResponse(
                    io.BytesIO(output.getvalue().encode()),
                    media_type="text/csv",
                    headers={"Content-Disposition": f"attachment; filename={filename}"}
                )
            
            else:  # JSON format
                data = []
                for row in rows:
                    row_dict = dict(row)
                    row_dict['date_added'] = row['date_added'].isoformat()
                    row_dict['last_updated'] = row['last_updated'].isoformat()
                    data.append(row_dict)
                
                filename = f"sanctions_export_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
                
                return StreamingResponse(
                    io.BytesIO(json.dumps(data, indent=2).encode()),
                    media_type="application/json",
                    headers={"Content-Disposition": f"attachment; filename={filename}"}
                )
            
        finally:
            await conn.close()
            
    except Exception as e:
        print(f"❌ Error exporting sanctions: {e}")
        raise HTTPException(status_code=500, detail=f"Export failed: {str(e)}")

# ============================================================================
# Source Management
# ============================================================================

@router.get("/sources", response_model=List[SanctionSourceResponse])
async def get_sanction_sources(user: AuthorizedUser) -> List[SanctionSourceResponse]:
    """Get statistics about sanction sources"""
    print(f"📊 Admin getting sanction sources statistics")
    
    try:
        conn = await get_db_connection()
        
        try:
            query = """
                SELECT source_list, jurisdiction, COUNT(*) as entity_count,
                       MAX(last_updated) as last_updated,
                       CASE 
                           WHEN COUNT(CASE WHEN status = 'active' THEN 1 END) = COUNT(*) THEN 'active'
                           WHEN COUNT(CASE WHEN status = 'active' THEN 1 END) = 0 THEN 'inactive'
                           ELSE 'mixed'
                       END as status
                FROM admin_sanctions
                GROUP BY source_list, jurisdiction
                ORDER BY jurisdiction, source_list
            """
            
            rows = await conn.fetch(query)
            
            sources = []
            for row in rows:
                source = SanctionSourceResponse(
                    source_list=row['source_list'],
                    jurisdiction=row['jurisdiction'],
                    entity_count=row['entity_count'],
                    last_updated=row['last_updated'],
                    status=row['status']
                )
                sources.append(source)
            
            print(f"✅ Retrieved {len(sources)} sanction sources")
            return sources
            
        finally:
            await conn.close()
            
    except Exception as e:
        print(f"❌ Error getting sanction sources: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to get sanction sources: {str(e)}")

# ============================================================================
# Audit Trail
# ============================================================================

@router.get("/audit-log", response_model=List[SanctionAuditLogResponse])
async def get_sanctions_audit_log(
    user: AuthorizedUser,
    entity_id: Optional[str] = Query(default=None),
    action: Optional[str] = Query(default=None),
    limit: int = Query(default=50, le=200)
) -> List[SanctionAuditLogResponse]:
    """Get sanctions audit trail"""
    print(f"📋 Admin getting sanctions audit log")
    
    try:
        conn = await get_db_connection()
        
        try:
            # Build query
            where_conditions = []
            params = []
            param_count = 0
            
            if entity_id:
                param_count += 1
                where_conditions.append(f"entity_id = ${param_count}")
                params.append(entity_id)
            
            if action:
                param_count += 1
                where_conditions.append(f"action = ${param_count}")
                params.append(action)
            
            where_clause = " AND ".join(where_conditions) if where_conditions else "TRUE"
            
            param_count += 1
            params.append(limit)
            
            query = f"""
                SELECT id, entity_id, action, changes, performed_by, performed_at, notes
                FROM sanctions_audit_log
                WHERE {where_clause}
                ORDER BY performed_at DESC
                LIMIT ${param_count}
            """
            
            rows = await conn.fetch(query, *params)
            
            logs = []
            for row in rows:
                log = SanctionAuditLogResponse(
                    id=row['id'],
                    entity_id=row['entity_id'],
                    action=row['action'],
                    changes=json.loads(row['changes']) if row['changes'] else None,
                    performed_by=row['performed_by'],
                    performed_at=row['performed_at'],
                    notes=row['notes']
                )
                logs.append(log)
            
            print(f"✅ Retrieved {len(logs)} audit log entries")
            return logs
            
        finally:
            await conn.close()
            
    except Exception as e:
        print(f"❌ Error getting sanctions audit log: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to get sanctions audit log: {str(e)}")
