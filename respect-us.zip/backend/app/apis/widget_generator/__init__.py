from fastapi import APIRouter
from pydantic import BaseModel
from typing import Dict, Any

router = APIRouter(prefix="/widget-generator")

class GenerateWidgetCodeRequest(BaseModel):
    template_id: str
    widget_name: str
    custom_settings: Dict[str, Any] = {}

class GeneratedWidgetCode(BaseModel):
    component_code: str
    api_code: str
    integration_code: str
    documentation: str

@router.post("/generate")
async def generate_widget_code(request: GenerateWidgetCodeRequest):
    """Generate React component code for a custom widget"""
    
    widget_name_pascal = ''.join(word.capitalize() for word in request.widget_name.split())
    
    # Base component template - simplified to avoid f-string complexity
    component_code = f'''import React, {{ useState }} from 'react';
import {{ Dialog, DialogContent, DialogHeader, DialogTitle }} from '@/components/ui/dialog';
import {{ Button }} from '@/components/ui/button';
import {{ Input }} from '@/components/ui/input';
import {{ Badge }} from '@/components/ui/badge';
import {{ Search }} from 'lucide-react';
import brain from 'brain';

interface {widget_name_pascal}Props {{
  open: boolean;
  onClose: () => void;
  onSelect?: (result: any) => void;
}}

export default function {widget_name_pascal}({{ open, onClose, onSelect }}: {widget_name_pascal}Props) {{
  const [searchQuery, setSearchQuery] = useState('');
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);
  
  const handleSearch = async () => {{
    if (!searchQuery.trim()) return;
    
    setLoading(true);
    try {{
      const response = await brain.search_widget_data({{
        widgetId: '{request.template_id}',
        searchQuery,
        filters: {{}},
        limit: 20
      }});
      
      if (response.ok) {{
        const data = await response.json();
        setResults(data.results || []);
      }}
    }} catch (error) {{
      console.error('Search error:', error);
    }} finally {{
      setLoading(false);
    }}
  }};
  
  return (
    <Dialog open={{open}} onOpenChange={{onClose}}>
      <DialogContent className="bg-gray-800 border-gray-700 max-w-4xl max-h-[80vh]">
        <DialogHeader>
          <DialogTitle className="text-white flex items-center gap-2">
            <Search className="h-5 w-5" />
            {request.widget_name}
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4">
          <div className="flex gap-2">
            <Input
              value={{searchQuery}}
              onChange={{(e) => setSearchQuery(e.target.value)}}
              placeholder="Enter search query..."
              className="bg-gray-700 border-gray-600 text-white"
              onKeyDown={{(e) => e.key === 'Enter' && handleSearch()}}
            />
            <Button 
              onClick={{handleSearch}} 
              disabled={{loading}}
              className="bg-blue-600 hover:bg-blue-700 text-white"
            >
              <Search className="h-4 w-4 mr-2" />
              {{loading ? 'Searching...' : 'Search'}}
            </Button>
          </div>
          
          <div className="max-h-96 overflow-y-auto space-y-3">
            {{results.map((result, index) => (
              <div 
                key={{index}} 
                className="bg-gray-700/50 border border-gray-600 rounded-lg p-4 hover:bg-gray-700/70 transition-colors"
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <h3 className="font-medium text-white">{{result.title}}</h3>
                    {{result.subtitle && (
                      <p className="text-sm text-gray-300 mb-1">{{result.subtitle}}</p>
                    )}}
                    {{result.description && (
                      <p className="text-sm text-gray-400">{{result.description}}</p>
                    )}}
                  </div>
                  {{onSelect && (
                    <Button
                      size="sm"
                      onClick={{() => onSelect(result)}}
                      className="bg-blue-600 hover:bg-blue-700 text-white"
                    >
                      Select
                    </Button>
                  )}}
                </div>
              </div>
            ))}}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}}'''
    
    api_code = f'''// API Integration for {widget_name_pascal}
const search{widget_name_pascal} = async (query: string) => {{
  const response = await brain.search_widget_data({{
    widgetId: '{request.template_id}',
    searchQuery: query,
    limit: 20
  }});
  return response.ok ? await response.json() : null;
}};'''
    
    integration_code = f'''// Usage Example
import {widget_name_pascal} from 'components/{widget_name_pascal}';

function MyComponent() {{
  const [open, setOpen] = useState(false);
  
  return (
    <>
      <Button onClick={{() => setOpen(true)}}>
        Open {request.widget_name}
      </Button>
      <{widget_name_pascal} 
        open={{open}} 
        onClose={{() => setOpen(false)}} 
      />
    </>
  );
}}'''
    
    documentation = f'''# {widget_name_pascal} Widget

Generated widget for {request.widget_name}.

## Props
- open: boolean
- onClose: () => void
- onSelect?: (result: any) => void

## Usage
1. Save as components/{widget_name_pascal}.tsx
2. Import and use in your components
3. Customize styling and functionality as needed'''
    
    return GeneratedWidgetCode(
        component_code=component_code,
        api_code=api_code,
        integration_code=integration_code,
        documentation=documentation
    )

@router.get("/templates/{template_id}/preview")
async def preview_widget_template(template_id: str):
    """Preview what a widget template would generate"""
    return {
        "template_id": template_id,
        "preview_features": [
            "Real-time search",
            "Modal interface", 
            "Dark theme styling",
            "Responsive design"
        ],
        "customizable_elements": [
            "Search placeholder",
            "Color scheme",
            "Result display format",
            "Additional filters"
        ]
    }
