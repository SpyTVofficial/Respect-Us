
from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
from datetime import datetime
import asyncpg
import databutton as db
from app.auth.user import get_authorized_user
import json

router = APIRouter(prefix="/annotations", tags=["annotations"])

class AnnotationType(str):
    HIGHLIGHT = "highlight"
    NOTE = "note"
    BOOKMARK = "bookmark"
    COMMENT = "comment"
    QUESTION = "question"

class AnnotationVisibility(str):
    PRIVATE = "private"
    TEAM = "team"
    PUBLIC = "public"

class DocumentAnnotation(BaseModel):
    id: Optional[int] = None
    document_id: int
    user_id: str
    annotation_type: str = Field(..., description="Type of annotation")
    content: str = Field(..., description="Annotation content/text")
    position_data: Dict[str, Any] = Field(default_factory=dict, description="Position/selection data")
    visibility: str = Field(default="private", description="Who can see this annotation")
    is_resolved: bool = Field(default=False)
    parent_id: Optional[int] = Field(None, description="For threaded comments")
    metadata: Dict[str, Any] = Field(default_factory=dict)
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    user_name: Optional[str] = None
    replies: List['DocumentAnnotation'] = Field(default_factory=list)

class CreateAnnotationRequest(BaseModel):
    document_id: int
    annotation_type: str
    content: str
    position_data: Dict[str, Any] = Field(default_factory=dict)
    visibility: str = "private"
    parent_id: Optional[int] = None
    metadata: Dict[str, Any] = Field(default_factory=dict)

class UpdateAnnotationRequest(BaseModel):
    content: Optional[str] = None
    visibility: Optional[str] = None
    is_resolved: Optional[bool] = None
    metadata: Optional[Dict[str, Any]] = None

class UserBookmark(BaseModel):
    id: Optional[int] = None
    user_id: str
    document_id: int
    section_id: Optional[str] = None
    title: str
    description: Optional[str] = None
    tags: List[str] = Field(default_factory=list)
    created_at: Optional[datetime] = None
    document_title: Optional[str] = None
    document_jurisdiction: Optional[str] = None

class CreateBookmarkRequest(BaseModel):
    document_id: int
    section_id: Optional[str] = None
    title: str
    description: Optional[str] = None
    tags: List[str] = Field(default_factory=list)

class CollaborationActivity(BaseModel):
    id: Optional[int] = None
    document_id: int
    user_id: str
    activity_type: str  # viewed, annotated, bookmarked, shared, etc.
    description: str
    metadata: Dict[str, Any] = Field(default_factory=dict)
    created_at: Optional[datetime] = None
    user_name: Optional[str] = None

# Database connection helper
async def get_db_connection():
    database_url = db.secrets.get("DATABASE_URL_DEV")
    return await asyncpg.connect(database_url)

# Annotation Management

@router.get("/documents/{document_id}", response_model=List[DocumentAnnotation])
async def get_document_annotations(
    document_id: int, 
    user=Depends(get_authorized_user),
    annotation_type: Optional[str] = None,
    visibility: Optional[str] = None
):
    """Get all annotations for a document"""
    conn = await get_db_connection()
    try:
        # For demo, return sample annotations stored in documents metadata
        doc_query = "SELECT metadata FROM documents WHERE id = $1"
        doc_row = await conn.fetchrow(doc_query, document_id)
        
        if not doc_row:
            raise HTTPException(status_code=404, detail="Document not found")
        
        # Sample annotations data
        sample_annotations = [
            {
                "id": 1,
                "document_id": document_id,
                "user_id": user.sub,
                "annotation_type": "highlight",
                "content": "Important export control provision",
                "position_data": {"start": 1250, "end": 1300, "text": "dual-use goods export restrictions"},
                "visibility": "team",
                "is_resolved": False,
                "created_at": datetime.now().isoformat(),
                "user_name": "Current User"
            },
            {
                "id": 2,
                "document_id": document_id,
                "user_id": "other-user",
                "annotation_type": "comment",
                "content": "This section needs clarification regarding software exports",
                "position_data": {"paragraph": 5, "line": 3},
                "visibility": "public",
                "is_resolved": False,
                "created_at": (datetime.now()).isoformat(),
                "user_name": "Compliance Expert",
                "replies": [
                    {
                        "id": 3,
                        "document_id": document_id,
                        "user_id": user.sub,
                        "annotation_type": "comment",
                        "content": "I agree, we should add more specific examples here",
                        "parent_id": 2,
                        "visibility": "public",
                        "created_at": datetime.now().isoformat(),
                        "user_name": "Current User"
                    }
                ]
            },
            {
                "id": 4,
                "document_id": document_id,
                "user_id": user.sub,
                "annotation_type": "bookmark",
                "content": "Key compliance checkpoint",
                "position_data": {"section": "Article 3.2"},
                "visibility": "private",
                "is_resolved": False,
                "created_at": datetime.now().isoformat(),
                "user_name": "Current User"
            }
        ]
        
        # Filter by type and visibility if specified
        filtered_annotations = sample_annotations
        if annotation_type:
            filtered_annotations = [a for a in filtered_annotations if a["annotation_type"] == annotation_type]
        if visibility:
            filtered_annotations = [a for a in filtered_annotations if a["visibility"] == visibility]
        
        return [DocumentAnnotation(**annotation) for annotation in filtered_annotations]
        
    except Exception as e:
        print(f"Error getting annotations: {e}")
        return []
    finally:
        await conn.close()

@router.post("/documents/{document_id}", response_model=DocumentAnnotation)
async def create_annotation(
    document_id: int,
    request: CreateAnnotationRequest,
    user=Depends(get_authorized_user)
):
    """Create a new annotation"""
    conn = await get_db_connection()
    try:
        # For demo, simulate creating annotation and return it
        new_annotation = {
            "id": 100 + document_id,  # Simple ID generation for demo
            "document_id": document_id,
            "user_id": user.sub,
            "annotation_type": request.annotation_type,
            "content": request.content,
            "position_data": request.position_data,
            "visibility": request.visibility,
            "is_resolved": False,
            "parent_id": request.parent_id,
            "metadata": request.metadata,
            "created_at": datetime.now().isoformat(),
            "user_name": "Current User"
        }
        
        print(f"Created annotation: {request.annotation_type} on document {document_id}")
        
        return DocumentAnnotation(**new_annotation)
        
    except Exception as e:
        print(f"Error creating annotation: {e}")
        raise HTTPException(status_code=500, detail="Failed to create annotation")
    finally:
        await conn.close()

@router.put("/annotations/{annotation_id}", response_model=DocumentAnnotation)
async def update_annotation(
    annotation_id: int,
    request: UpdateAnnotationRequest,
    user=Depends(get_authorized_user)
):
    """Update an existing annotation"""
    # For demo, return updated annotation
    updated_annotation = {
        "id": annotation_id,
        "document_id": 1,
        "user_id": user.sub,
        "annotation_type": "comment",
        "content": request.content or "Updated annotation content",
        "position_data": {},
        "visibility": request.visibility or "private",
        "is_resolved": request.is_resolved or False,
        "metadata": request.metadata or {},
        "created_at": datetime.now().isoformat(),
        "updated_at": datetime.now().isoformat(),
        "user_name": "Current User"
    }
    
    return DocumentAnnotation(**updated_annotation)

@router.delete("/annotations/{annotation_id}")
async def delete_annotation(annotation_id: int, user=Depends(get_authorized_user)):
    """Delete an annotation"""
    print(f"Deleted annotation {annotation_id} by user {user.sub}")
    return {"message": "Annotation deleted successfully"}

@router.post("/annotations/{annotation_id}/resolve")
async def resolve_annotation(annotation_id: int, user=Depends(get_authorized_user)):
    """Mark an annotation as resolved"""
    print(f"Resolved annotation {annotation_id} by user {user.sub}")
    return {"message": "Annotation marked as resolved"}

# Bookmark Management

@router.get("/bookmarks", response_model=List[UserBookmark])
async def get_user_bookmarks(user=Depends(get_authorized_user)):
    """Get all bookmarks for the current user"""
    conn = await get_db_connection()
    try:
        # Sample bookmarks for demo
        sample_bookmarks = [
            {
                "id": 1,
                "user_id": user.sub,
                "document_id": 1,
                "section_id": "article-3.2",
                "title": "Export Control Key Provisions",
                "description": "Important section on dual-use goods regulations",
                "tags": ["export-control", "dual-use", "compliance"],
                "created_at": datetime.now().isoformat(),
                "document_title": "EU Export Control Regulation",
                "document_jurisdiction": "European Union"
            },
            {
                "id": 2,
                "user_id": user.sub,
                "document_id": 2,
                "title": "Sanctions List Updates",
                "description": "Recent changes to sanctioned entities",
                "tags": ["sanctions", "updates", "entities"],
                "created_at": datetime.now().isoformat(),
                "document_title": "OFAC Sanctions Guidelines",
                "document_jurisdiction": "United States"
            }
        ]
        
        return [UserBookmark(**bookmark) for bookmark in sample_bookmarks]
        
    except Exception as e:
        print(f"Error getting bookmarks: {e}")
        return []
    finally:
        await conn.close()

@router.post("/bookmarks", response_model=UserBookmark)
async def create_bookmark(request: CreateBookmarkRequest, user=Depends(get_authorized_user)):
    """Create a new bookmark"""
    conn = await get_db_connection()
    try:
        # Get document info for the bookmark
        doc_query = "SELECT title, country_jurisdiction FROM documents WHERE id = $1"
        doc_row = await conn.fetchrow(doc_query, request.document_id)
        
        new_bookmark = {
            "id": 100 + request.document_id,  # Simple ID for demo
            "user_id": user.sub,
            "document_id": request.document_id,
            "section_id": request.section_id,
            "title": request.title,
            "description": request.description,
            "tags": request.tags,
            "created_at": datetime.now().isoformat(),
            "document_title": doc_row['title'] if doc_row else "Unknown Document",
            "document_jurisdiction": doc_row['country_jurisdiction'] if doc_row else "Unknown"
        }
        
        print(f"Created bookmark: {request.title} for document {request.document_id}")
        
        return UserBookmark(**new_bookmark)
        
    except Exception as e:
        print(f"Error creating bookmark: {e}")
        raise HTTPException(status_code=500, detail="Failed to create bookmark")
    finally:
        await conn.close()

@router.delete("/bookmarks/{bookmark_id}")
async def delete_bookmark(bookmark_id: int, user=Depends(get_authorized_user)):
    """Delete a bookmark"""
    print(f"Deleted bookmark {bookmark_id} by user {user.sub}")
    return {"message": "Bookmark deleted successfully"}

# Collaboration Activity Tracking

@router.get("/documents/{document_id}/activity", response_model=List[CollaborationActivity])
async def get_document_activity(document_id: int, user=Depends(get_authorized_user), limit: int = 50):
    """Get recent activity for a document"""
    # Sample activity data for demo
    sample_activities = [
        {
            "id": 1,
            "document_id": document_id,
            "user_id": user.sub,
            "activity_type": "viewed",
            "description": "Viewed document",
            "created_at": datetime.now().isoformat(),
            "user_name": "Current User"
        },
        {
            "id": 2,
            "document_id": document_id,
            "user_id": "other-user",
            "activity_type": "annotated",
            "description": "Added highlight annotation",
            "created_at": (datetime.now()).isoformat(),
            "user_name": "Compliance Expert"
        },
        {
            "id": 3,
            "document_id": document_id,
            "user_id": user.sub,
            "activity_type": "bookmarked",
            "description": "Bookmarked section 3.2",
            "created_at": datetime.now().isoformat(),
            "user_name": "Current User"
        }
    ]
    
    return [CollaborationActivity(**activity) for activity in sample_activities[:limit]]

@router.post("/documents/{document_id}/activity")
async def track_document_activity(
    document_id: int,
    activity_type: str,
    description: str,
    user=Depends(get_authorized_user),
    metadata: Dict[str, Any] = None
):
    """Track user activity on a document"""
    print(f"Activity tracked: {activity_type} - {description} on document {document_id} by {user.sub}")
    
    return {
        "message": "Activity tracked successfully",
        "activity_type": activity_type,
        "document_id": document_id
    }

# Collaboration Statistics

@router.get("/documents/{document_id}/collaboration-stats")
async def get_collaboration_stats(document_id: int, user=Depends(get_authorized_user)):
    """Get collaboration statistics for a document"""
    return {
        "document_id": document_id,
        "total_annotations": 15,
        "active_users": 4,
        "pending_comments": 3,
        "resolved_comments": 12,
        "total_bookmarks": 8,
        "recent_activity_count": 23,
        "collaboration_score": 85  # Out of 100
    }

@router.get("/user/collaboration-summary")
async def get_user_collaboration_summary(user=Depends(get_authorized_user)):
    """Get collaboration summary for the current user"""
    return {
        "user_id": user.sub,
        "total_annotations": 42,
        "total_bookmarks": 15,
        "documents_annotated": 12,
        "comments_posted": 28,
        "comments_resolved": 18,
        "activity_this_week": 34,
        "collaboration_level": "Expert"  # Novice, Intermediate, Expert
    }
