


from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from typing import List, Optional, Dict, Any
from datetime import datetime, timedelta, timezone
import asyncpg
import databutton as db
from app.auth import AuthorizedUser
from app.env import Mode, mode
import json

router = APIRouter(prefix="/monitoring")

# Database connection helper
async def get_db_connection():
    if mode == Mode.PROD:
        database_url = db.secrets.get("DATABASE_URL_PROD")
    else:
        database_url = db.secrets.get("DATABASE_URL_DEV")
    return await asyncpg.connect(database_url)

# Pydantic Models
class CreateMonitoringScheduleRequest(BaseModel):
    schedule_name: str
    schedule_type: str  # daily, weekly, monthly, custom
    frequency_value: Optional[int] = 1
    target_type: str  # all_customers, high_risk, specific_list
    target_customers: Optional[List[str]] = None

class MonitoringScheduleResponse(BaseModel):
    id: int
    schedule_name: str
    schedule_type: str
    frequency_value: int
    target_type: str
    target_customers: Optional[List[str]]
    is_active: bool
    last_run_at: Optional[datetime]
    next_run_at: Optional[datetime]
    created_at: datetime
    updated_at: datetime

class UpdateMonitoringScheduleRequest(BaseModel):
    schedule_name: Optional[str] = None
    schedule_type: Optional[str] = None
    frequency_value: Optional[int] = None
    target_type: Optional[str] = None
    target_customers: Optional[List[str]] = None
    is_active: Optional[bool] = None

class AutomationJobResponse(BaseModel):
    id: int
    job_type: str
    schedule_id: Optional[int]
    status: str
    progress: int
    total_items: int
    results: Optional[dict]
    error_message: Optional[str]
    started_at: Optional[datetime]
    completed_at: Optional[datetime]
    created_at: datetime

class NotificationPreferencesRequest(BaseModel):
    email_alerts: Optional[bool] = None
    sms_alerts: Optional[bool] = None
    high_risk_alerts: Optional[bool] = None
    schedule_completion_alerts: Optional[bool] = None
    system_alerts: Optional[bool] = None
    notification_frequency: Optional[str] = None  # immediate, daily_digest, weekly_digest

class NotificationPreferencesResponse(BaseModel):
    id: int
    user_id: str
    email_alerts: bool
    sms_alerts: bool
    high_risk_alerts: bool
    schedule_completion_alerts: bool
    system_alerts: bool
    notification_frequency: str
    created_at: datetime
    updated_at: datetime

class UpdateRiskAssessmentsRequest(BaseModel):
    customer_ids: Optional[List[int]] = None  # If None, update all customers needing reassessment
    days_since_last_assessment: Optional[int] = 30  # Only relevant if customer_ids is None
    force_update: bool = False  # Force update even if recently assessed

class CustomerRiskUpdate(BaseModel):
    customer_id: int
    name: str
    previous_risk_level: str
    new_risk_level: str
    new_risk_score: float

class UpdateRiskAssessmentsResponse(BaseModel):
    success: bool
    message: str
    updated_customers: List[CustomerRiskUpdate]
    total_updated: int

class ScheduleRiskAssessmentsRequest(BaseModel):
    schedule_name: str
    frequency: str  # "daily", "weekly", "monthly"
    customer_ids: Optional[List[int]] = None  # If None, applies to all customers
    days_threshold: Optional[int] = 30  # Days since last assessment before triggering update
    email_notifications: bool = True
    auto_update_high_risk: bool = True  # Automatically update high-risk customers more frequently
    include_screening_context: bool = True  # Include screening context in risk calculation

class ScheduleRiskAssessmentsResponse(BaseModel):
    success: bool
    message: str
    schedule_id: Optional[int]
    schedule_name: str
    frequency: str

# Calculate next run time based on schedule type
def calculate_next_run(schedule_type: str, frequency_value: int = 1) -> datetime:
    now = datetime.now(timezone.utc)
    
    if schedule_type == "daily":
        return now + timedelta(days=frequency_value)
    elif schedule_type == "weekly":
        return now + timedelta(weeks=frequency_value)
    elif schedule_type == "monthly":
        # Approximate monthly by adding 30 days * frequency
        return now + timedelta(days=30 * frequency_value)
    else:
        # Default to daily for custom types
        return now + timedelta(days=1)

# Monitoring Schedules Endpoints
@router.post("/schedules", response_model=MonitoringScheduleResponse)
async def create_monitoring_schedule(
    request: CreateMonitoringScheduleRequest,
    user: AuthorizedUser
):
    """Create a new automated monitoring schedule."""
    conn = await get_db_connection()
    try:
        next_run = calculate_next_run(request.schedule_type, request.frequency_value)
        
        query = """
            INSERT INTO monitoring_schedules (
                user_id, schedule_name, schedule_type, frequency_value,
                target_type, target_customers, next_run_at
            ) VALUES ($1, $2, $3, $4, $5, $6, $7)
            RETURNING *
        """
        
        row = await conn.fetchrow(
            query,
            user.sub,
            request.schedule_name,
            request.schedule_type,
            request.frequency_value,
            request.target_type,
            request.target_customers,
            next_run
        )
        
        return MonitoringScheduleResponse(**dict(row))
    
    finally:
        await conn.close()

@router.get("/schedules", response_model=List[MonitoringScheduleResponse])
async def list_monitoring_schedules(user: AuthorizedUser):
    """List all monitoring schedules for the current user."""
    conn = await get_db_connection()
    try:
        query = """
            SELECT * FROM monitoring_schedules 
            WHERE user_id = $1 
            ORDER BY created_at DESC
        """
        
        rows = await conn.fetch(query, user.sub)
        return [MonitoringScheduleResponse(**dict(row)) for row in rows]
    
    finally:
        await conn.close()

@router.get("/schedules/{schedule_id}", response_model=MonitoringScheduleResponse)
async def get_monitoring_schedule(schedule_id: int, user: AuthorizedUser):
    """Get a specific monitoring schedule."""
    conn = await get_db_connection()
    try:
        query = """
            SELECT * FROM monitoring_schedules 
            WHERE id = $1 AND user_id = $2
        """
        
        row = await conn.fetchrow(query, schedule_id, user.sub)
        if not row:
            raise HTTPException(status_code=404, detail="Schedule not found")
        
        return MonitoringScheduleResponse(**dict(row))
    
    finally:
        await conn.close()

@router.put("/schedules/{schedule_id}", response_model=MonitoringScheduleResponse)
async def update_monitoring_schedule(
    schedule_id: int,
    request: UpdateMonitoringScheduleRequest,
    user: AuthorizedUser
):
    """Update a monitoring schedule."""
    conn = await get_db_connection()
    try:
        # First check if schedule exists and belongs to user
        check_query = "SELECT id FROM monitoring_schedules WHERE id = $1 AND user_id = $2"
        existing = await conn.fetchrow(check_query, schedule_id, user.sub)
        if not existing:
            raise HTTPException(status_code=404, detail="Schedule not found")
        
        # Build update query dynamically
        update_fields = []
        values = []
        param_count = 1
        
        for field, value in request.dict(exclude_unset=True).items():
            if field in ['schedule_name', 'schedule_type', 'frequency_value', 'target_type', 'target_customers', 'is_active']:
                update_fields.append(f"{field} = ${param_count}")
                values.append(value)
                param_count += 1
        
        if not update_fields:
            raise HTTPException(status_code=400, detail="No fields to update")
        
        # Add updated_at
        update_fields.append(f"updated_at = ${param_count}")
        values.append(datetime.now(timezone.utc))
        param_count += 1
        
        # Recalculate next_run_at if schedule type or frequency changed
        if request.schedule_type or request.frequency_value:
            # Get current values for missing fields
            current = await conn.fetchrow(
                "SELECT schedule_type, frequency_value FROM monitoring_schedules WHERE id = $1",
                schedule_id
            )
            new_schedule_type = request.schedule_type or current['schedule_type']
            new_frequency = request.frequency_value or current['frequency_value']
            
            next_run = calculate_next_run(new_schedule_type, new_frequency)
            update_fields.append(f"next_run_at = ${param_count}")
            values.append(next_run)
            param_count += 1
        
        # Add WHERE clause parameters
        values.extend([schedule_id, user.sub])
        
        query = f"""
            UPDATE monitoring_schedules 
            SET {', '.join(update_fields)}
            WHERE id = ${param_count - 1} AND user_id = ${param_count}
            RETURNING *
        """
        
        row = await conn.fetchrow(query, *values)
        return MonitoringScheduleResponse(**dict(row))
    
    finally:
        await conn.close()

@router.delete("/schedules/{schedule_id}")
async def delete_monitoring_schedule(schedule_id: int, user: AuthorizedUser):
    """Delete a monitoring schedule."""
    conn = await get_db_connection()
    try:
        query = """
            DELETE FROM monitoring_schedules 
            WHERE id = $1 AND user_id = $2
            RETURNING id
        """
        
        row = await conn.fetchrow(query, schedule_id, user.sub)
        if not row:
            raise HTTPException(status_code=404, detail="Schedule not found")
        
        return {"message": "Schedule deleted successfully"}
    
    finally:
        await conn.close()

# Automation Jobs Endpoints
@router.get("/jobs", response_model=List[AutomationJobResponse])
async def list_automation_jobs(user: AuthorizedUser, limit: int = 50):
    """List automation jobs for the current user."""
    conn = await get_db_connection()
    try:
        query = """
            SELECT * FROM automation_jobs 
            WHERE user_id = $1 
            ORDER BY created_at DESC 
            LIMIT $2
        """
        
        rows = await conn.fetch(query, user.sub, limit)
        return [AutomationJobResponse(**dict(row)) for row in rows]
    
    finally:
        await conn.close()

@router.get("/jobs/{job_id}", response_model=AutomationJobResponse)
async def get_automation_job(job_id: int, user: AuthorizedUser):
    """Get a specific automation job."""
    conn = await get_db_connection()
    try:
        query = """
            SELECT * FROM automation_jobs 
            WHERE id = $1 AND user_id = $2
        """
        
        row = await conn.fetchrow(query, job_id, user.sub)
        if not row:
            raise HTTPException(status_code=404, detail="Job not found")
        
        return AutomationJobResponse(**dict(row))
    
    finally:
        await conn.close()

# Notification Preferences Endpoints
@router.get("/notification-preferences", response_model=NotificationPreferencesResponse)
async def get_notification_preferences(user: AuthorizedUser):
    """Get notification preferences for the current user."""
    conn = await get_db_connection()
    try:
        query = "SELECT * FROM notification_preferences WHERE user_id = $1"
        row = await conn.fetchrow(query, user.sub)
        
        if not row:
            # Create default preferences if none exist
            insert_query = """
                INSERT INTO notification_preferences (user_id)
                VALUES ($1)
                RETURNING *
            """
            row = await conn.fetchrow(insert_query, user.sub)
        
        return NotificationPreferencesResponse(**dict(row))
    
    finally:
        await conn.close()

@router.put("/notification-preferences", response_model=NotificationPreferencesResponse)
async def update_notification_preferences(
    request: NotificationPreferencesRequest,
    user: AuthorizedUser
):
    """Update notification preferences for the current user."""
    conn = await get_db_connection()
    try:
        # Ensure preferences record exists
        check_query = "SELECT id FROM notification_preferences WHERE user_id = $1"
        existing = await conn.fetchrow(check_query, user.sub)
        
        if not existing:
            # Create default preferences first
            create_query = """
                INSERT INTO notification_preferences (user_id)
                VALUES ($1)
            """
            await conn.execute(create_query, user.sub)
        
        # Build update query
        update_fields = []
        values = []
        param_count = 1
        
        for field, value in request.dict(exclude_unset=True).items():
            if field in ['email_alerts', 'sms_alerts', 'high_risk_alerts', 
                        'schedule_completion_alerts', 'system_alerts', 'notification_frequency']:
                update_fields.append(f"{field} = ${param_count}")
                values.append(value)
                param_count += 1
        
        if not update_fields:
            # Just return current preferences if nothing to update
            current_query = "SELECT * FROM notification_preferences WHERE user_id = $1"
            row = await conn.fetchrow(current_query, user.sub)
            return NotificationPreferencesResponse(**dict(row))
        
        # Add updated_at
        update_fields.append(f"updated_at = ${param_count}")
        values.append(datetime.now(timezone.utc))
        param_count += 1
        
        # Add WHERE clause parameter
        values.append(user.sub)
        
        query = f"""
            UPDATE notification_preferences 
            SET {', '.join(update_fields)}
            WHERE user_id = ${param_count}
            RETURNING *
        """
        
        row = await conn.fetchrow(query, *values)
        return NotificationPreferencesResponse(**dict(row))
    
    finally:
        await conn.close()

@router.post("/trigger-screening/{schedule_id}")
async def trigger_manual_screening(schedule_id: int, user: AuthorizedUser):
    """Manually trigger a screening job for a specific schedule."""
    conn = await get_db_connection()
    try:
        # Verify schedule exists and belongs to user
        schedule_query = """
            SELECT * FROM monitoring_schedules 
            WHERE id = $1 AND user_id = $2
        """
        schedule = await conn.fetchrow(schedule_query, schedule_id, user.sub)
        if not schedule:
            raise HTTPException(status_code=404, detail="Schedule not found")
        
        # Create automation job
        job_query = """
            INSERT INTO automation_jobs (
                user_id, job_type, schedule_id, status, total_items
            ) VALUES ($1, $2, $3, $4, $5)
            RETURNING *
        """
        
        # For now, we'll set total_items based on target_type
        # In a real implementation, this would query the actual customer count
        total_items = 1 if schedule['target_type'] == 'specific_list' else 100
        
        job = await conn.fetchrow(
            job_query,
            user.sub,
            "manual_screening",
            schedule_id,
            "pending",
            total_items
        )
        
        return {
            "message": "Screening job triggered successfully",
            "job_id": job['id'],
            "schedule_name": schedule['schedule_name']
        }
    
    finally:
        await conn.close()

@router.post("/update-risk-assessments")
async def update_risk_assessments(request: UpdateRiskAssessmentsRequest, user: AuthorizedUser) -> UpdateRiskAssessmentsResponse:
    """
    Update risk assessments for customers based on latest screening results
    """
    try:
        # Get database connection
        conn = await get_db_connection()
        
        updated_customers = []
        
        if request.customer_ids:
            # Update specific customers
            for customer_id in request.customer_ids:
                # Get latest screening results
                screening_query = """
                    SELECT cs.*, c.name, c.risk_level
                    FROM customer_screenings cs
                    JOIN customers c ON c.id = cs.customer_id
                    WHERE cs.customer_id = $1
                    ORDER BY cs.created_at DESC
                    LIMIT 5
                """
                screening_results = await conn.fetch(screening_query, customer_id)
                
                if screening_results:
                    # Calculate new risk score
                    new_risk_score = await calculate_risk_score(screening_results, conn)
                    new_risk_level = determine_risk_level(new_risk_score)
                    
                    # Update customer risk assessment
                    update_query = """
                        UPDATE customers 
                        SET risk_level = $1, 
                            risk_score = $2,
                            last_risk_assessment = NOW(),
                            updated_at = NOW()
                        WHERE id = $3
                        RETURNING id, name, risk_level, risk_score
                    """
                    updated_customer = await conn.fetchrow(update_query, new_risk_level, new_risk_score, customer_id)
                    
                    if updated_customer:
                        updated_customers.append({
                            "customer_id": updated_customer['id'],
                            "name": updated_customer['name'],
                            "previous_risk_level": screening_results[0]['risk_level'] if screening_results else "Unknown",
                            "new_risk_level": updated_customer['risk_level'],
                            "new_risk_score": float(updated_customer['risk_score']) if updated_customer['risk_score'] else 0.0
                        })
                        
                        # Create audit trail
                        audit_query = """
                            INSERT INTO customer_audit_trail (customer_id, action, details, created_by, created_at)
                            VALUES ($1, 'risk_assessment_update', $2, $3, NOW())
                        """
                        audit_details = f"Risk assessment updated via automation. New level: {new_risk_level}, Score: {new_risk_score}"
                        await conn.execute(audit_query, customer_id, audit_details, user.sub)
        else:
            # Update all customers that need reassessment (haven't been assessed in X days)
            days_threshold = request.days_since_last_assessment or 30
            
            customers_query = """
                SELECT c.id, c.name, c.risk_level, c.last_risk_assessment
                FROM customers c
                WHERE c.last_risk_assessment IS NULL 
                   OR c.last_risk_assessment < NOW() - INTERVAL '%s days'
                LIMIT 100
            """ % days_threshold
            
            customers_to_update = await conn.fetch(customers_query)
            
            for customer in customers_to_update:
                # Get latest screening results for each customer
                screening_query = """
                    SELECT cs.*, c.name, c.risk_level
                    FROM customer_screenings cs
                    JOIN customers c ON c.id = cs.customer_id
                    WHERE cs.customer_id = $1
                    ORDER BY cs.created_at DESC
                    LIMIT 5
                """
                screening_results = await conn.fetch(screening_query, customer['id'])
                
                if screening_results:
                    # Calculate new risk score
                    new_risk_score = await calculate_risk_score(screening_results, conn)
                    new_risk_level = determine_risk_level(new_risk_score)
                    
                    # Update customer risk assessment
                    update_query = """
                        UPDATE customers 
                        SET risk_level = $1, 
                            risk_score = $2,
                            last_risk_assessment = NOW(),
                            updated_at = NOW()
                        WHERE id = $3
                        RETURNING id, name, risk_level, risk_score
                    """
                    updated_customer = await conn.fetchrow(update_query, new_risk_level, new_risk_score, customer['id'])
                    
                    if updated_customer:
                        updated_customers.append({
                            "customer_id": updated_customer['id'],
                            "name": updated_customer['name'],
                            "previous_risk_level": customer['risk_level'],
                            "new_risk_level": updated_customer['risk_level'],
                            "new_risk_score": float(updated_customer['risk_score']) if updated_customer['risk_score'] else 0.0
                        })
                        
                        # Create audit trail
                        audit_query = """
                            INSERT INTO customer_audit_trail (customer_id, action, details, created_by, created_at)
                            VALUES ($1, 'automated_risk_assessment', $2, $3, NOW())
                        """
                        audit_details = f"Automated risk assessment update. New level: {new_risk_level}, Score: {new_risk_score}"
                        await conn.execute(audit_query, customer['id'], audit_details, user.sub)
        
        await conn.close()
        
        return UpdateRiskAssessmentsResponse(
            success=True,
            message=f"Successfully updated risk assessments for {len(updated_customers)} customers",
            updated_customers=updated_customers,
            total_updated=len(updated_customers)
        )
        
    except Exception as e:
        return UpdateRiskAssessmentsResponse(
            success=False,
            message=f"Error updating risk assessments: {str(e)}",
            updated_customers=[],
            total_updated=0
        )


@router.post("/schedule-risk-assessments")
async def schedule_risk_assessments(request: ScheduleRiskAssessmentsRequest, user: AuthorizedUser) -> ScheduleRiskAssessmentsResponse:
    """
    Schedule automated risk assessment updates
    """
    try:
        conn = await get_db_connection()
        
        # Create scheduled job for risk assessments
        schedule_query = """
            INSERT INTO monitoring_schedules 
            (name, schedule_type, frequency, target_type, target_ids, config, is_active, created_by, created_at)
            VALUES ($1, 'risk_assessment', $2, $3, $4, $5, true, $6, NOW())
            RETURNING id, name, frequency
        """
        
        config = {
            "days_threshold": request.days_threshold or 30,
            "email_notifications": request.email_notifications,
            "auto_update_high_risk": request.auto_update_high_risk,
            "include_screening_context": request.include_screening_context
        }
        
        target_ids = request.customer_ids if request.customer_ids else []
        target_type = "specific_customers" if request.customer_ids else "all_customers"
        
        schedule = await conn.fetchrow(
            schedule_query,
            request.schedule_name,
            request.frequency,
            target_type,
            target_ids,
            json.dumps(config),
            user.sub
        )
        
        await conn.close()
        
        return ScheduleRiskAssessmentsResponse(
            success=True,
            message=f"Risk assessment schedule '{schedule['name']}' created successfully",
            schedule_id=schedule['id'],
            schedule_name=schedule['name'],
            frequency=schedule['frequency']
        )
        
    except Exception as e:
        return ScheduleRiskAssessmentsResponse(
            success=False,
            message=f"Error creating risk assessment schedule: {str(e)}",
            schedule_id=None,
            schedule_name="",
            frequency=""
        )


async def calculate_risk_score(screening_results: list, conn) -> float:
    """
    Calculate risk score based on screening results and historical data
    """
    if not screening_results:
        return 0.0
    
    base_score = 0.0
    
    # Weight factors
    sanctions_weight = 0.4
    pep_weight = 0.3
    adverse_media_weight = 0.2
    other_weight = 0.1
    
    for result in screening_results:
        # Sanctions matches (highest risk)
        if result.get('sanctions_matches', 0) > 0:
            base_score += sanctions_weight * min(result['sanctions_matches'], 5) * 20  # Max 100 points from sanctions
        
        # PEP matches
        if result.get('pep_matches', 0) > 0:
            base_score += pep_weight * min(result['pep_matches'], 3) * 15  # Max 45 points from PEP
        
        # Adverse media
        if result.get('adverse_media_matches', 0) > 0:
            base_score += adverse_media_weight * min(result['adverse_media_matches'], 5) * 10  # Max 50 points
        
        # Other matches (general watchlists)
        if result.get('other_matches', 0) > 0:
            base_score += other_weight * min(result['other_matches'], 5) * 5  # Max 25 points
    
    # Average across recent screenings (last 5)
    final_score = base_score / len(screening_results)
    
    # Cap at 100
    return min(final_score, 100.0)


def determine_risk_level(risk_score: float) -> str:
    """
    Determine risk level based on calculated risk score
    """
    if risk_score >= 80:
        return "Critical"
    elif risk_score >= 60:
        return "High"
    elif risk_score >= 40:
        return "Medium"
    elif risk_score >= 20:
        return "Low"
    else:
        return "Minimal"
