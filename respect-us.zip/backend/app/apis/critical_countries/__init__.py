


from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import List, Optional
import asyncpg
from app.env import Mode, mode
import databutton as db

router = APIRouter()

# Database connection
async def get_db_connection():
    if mode == Mode.PROD:
        database_url = db.secrets.get("DATABASE_URL_PROD")
    else:
        database_url = db.secrets.get("DATABASE_URL_DEV")
    return await asyncpg.connect(database_url)

# Pydantic models
class CriticalCountryCreate(BaseModel):
    name: str
    abbreviation: Optional[str] = None
    iso_code: Optional[str] = None
    notes: Optional[str] = None
    status: str = "active"  # Column D
    last_assessed: Optional[str] = None  # Column H
    
    # Export Control Regimes (Columns I-N)
    wassenaar_arrangement: bool = False  # Column I (WA)
    nuclear_suppliers_group: bool = False  # Column J (NSG) 
    australia_group: bool = False  # Column K (AG)
    missile_technology_control_regime: bool = False  # Column L (MTCR)
    zangger_committee: bool = False  # Column M (ZC)
    export_control_notes: Optional[str] = None  # Column N
    export_control_risk: str = "low"  # Column O
    
    # Sanctions (Columns Q-S)
    sanctions_status: Optional[str] = None  # Column Q
    sanctions_notes: Optional[str] = None  # Column R
    sanctions_risk: str = "low"  # Column S
    
    # Arms Embargo fields (Columns T-AB)
    un_arms_embargo: bool = False
    un_arms_embargo_notes: Optional[str] = None
    us_arms_embargo: bool = False
    us_arms_embargo_notes: Optional[str] = None
    eu_arms_embargo: bool = False
    eu_arms_embargo_notes: Optional[str] = None
    other_arms_embargo: bool = False
    other_arms_embargo_notes: Optional[str] = None
    arms_risk: str = "low"  # Column AB
    
    # Chemical Weapons Convention (Columns AC-AF)
    cwc_1993_signatory: bool = False  # Column AC
    cwc_1993_ratified: bool = False  # Column AD
    cwc_violations: bool = False  # Column AE
    chemical_risk: str = "low"  # Column AF
    
    # Biological Weapons Convention (Columns AG-AJ)
    bwc_1972_signatory: bool = False  # Column AG
    bwc_1972_ratified: bool = False  # Column AH
    bwc_violations: bool = False  # Column AI
    biological_risk: str = "low"  # Column AJ
    
    # Nuclear Treaties (Columns AK-BD)
    npt_signatory: bool = False
    npt_ratified: bool = False
    npt_notes: Optional[str] = None
    ctbt_signatory: bool = False
    ctbt_ratified: bool = False
    ctbt_notes: Optional[str] = None
    iaea_signatory: bool = False
    iaea_ratified: bool = False
    iaea_notes: Optional[str] = None
    nsg_1974_signatory: bool = False
    nsg_1974_ratified: bool = False
    convention_1980_signatory: bool = False
    convention_1980_ratified: bool = False
    convention_1994_signatory: bool = False
    convention_1994_ratified: bool = False
    nuclear_violations: bool = False  # Column BC
    nuclear_risk: str = "low"  # Column BD
    
    # Human Rights (Columns BE-BG)
    human_rights_score: int = 50  # Column BE
    human_rights_notes: Optional[str] = None  # Column BF
    human_rights_risk: str = "low"  # Column BG
    
    # Freedom Risk (Columns BH-BL)
    political_rights_score: int = 50  # Column BH
    civil_liberties_score: int = 50  # Column BI
    freedom_in_the_world: Optional[str] = None  # Column BJ
    freedom_note: Optional[str] = None  # Column BK
    freedom_risk: str = "low"  # Column BL
    
    # Freedom Net Risk (Columns BM-BQ)
    obstacles_to_access: Optional[str] = None  # Column BM
    limits_on_content: Optional[str] = None  # Column BN
    violations_of_user_rights: Optional[str] = None  # Column BO
    freedom_net_note: Optional[str] = None  # Column BP
    freedom_net_risk: str = "low"  # Column BQ
    
    # Regime Risk (Columns BR-BU)
    democracy_status: Optional[str] = None  # Column BR
    democracy_percentage: Optional[float] = None  # Column BS
    nations_in_transit: Optional[str] = None  # Column BT
    regime_type: Optional[str] = None  # Column BU
    
    # Legacy fields for backward compatibility
    human_rights_freedoms_risk: str = "low"
    varieties_of_democracy: Optional[str] = None
    
    # Metadata
    risk_level: str = "medium"
    is_active: bool = True

class CriticalCountryUpdate(BaseModel):
    name: Optional[str] = None
    abbreviation: Optional[str] = None
    iso_code: Optional[str] = None
    notes: Optional[str] = None
    status: Optional[str] = None  # Column D
    last_assessed: Optional[str] = None  # Column H
    
    # Export Control Regimes (Columns I-N)
    wassenaar_arrangement: Optional[bool] = None  # Column I (WA)
    nuclear_suppliers_group: Optional[bool] = None  # Column J (NSG) 
    australia_group: Optional[bool] = None  # Column K (AG)
    missile_technology_control_regime: Optional[bool] = None  # Column L (MTCR)
    zangger_committee: Optional[bool] = None  # Column M (ZC)
    export_control_notes: Optional[str] = None  # Column N
    export_control_risk: Optional[str] = None  # Column O
    
    # Sanctions (Columns Q-S)
    sanctions_status: Optional[str] = None  # Column Q
    sanctions_notes: Optional[str] = None  # Column R
    sanctions_risk: Optional[str] = None  # Column S
    
    # Arms Embargo fields (Columns T-AB)
    un_arms_embargo: Optional[bool] = None
    un_arms_embargo_notes: Optional[str] = None
    us_arms_embargo: Optional[bool] = None
    us_arms_embargo_notes: Optional[str] = None
    eu_arms_embargo: Optional[bool] = None
    eu_arms_embargo_notes: Optional[str] = None
    other_arms_embargo: Optional[bool] = None
    other_arms_embargo_notes: Optional[str] = None
    arms_risk: Optional[str] = None  # Column AB
    
    # Chemical Weapons Convention (Columns AC-AF)
    cwc_1993_signatory: Optional[bool] = None  # Column AC
    cwc_1993_ratified: Optional[bool] = None  # Column AD
    cwc_violations: Optional[bool] = None  # Column AE
    chemical_risk: Optional[str] = None  # Column AF
    
    # Biological Weapons Convention (Columns AG-AJ)
    bwc_1972_signatory: Optional[bool] = None  # Column AG
    bwc_1972_ratified: Optional[bool] = None  # Column AH
    bwc_violations: Optional[bool] = None  # Column AI
    biological_risk: Optional[str] = None  # Column AJ
    
    # Nuclear Treaties (Columns AK-BD)
    npt_signatory: Optional[bool] = None
    npt_ratified: Optional[bool] = None
    npt_notes: Optional[str] = None
    ctbt_signatory: Optional[bool] = None
    ctbt_ratified: Optional[bool] = None
    ctbt_notes: Optional[str] = None
    iaea_signatory: Optional[bool] = None
    iaea_ratified: Optional[bool] = None
    iaea_notes: Optional[str] = None
    nsg_1974_signatory: Optional[bool] = None
    nsg_1974_ratified: Optional[bool] = None
    convention_1980_signatory: Optional[bool] = None
    convention_1980_ratified: Optional[bool] = None
    convention_1994_signatory: Optional[bool] = None
    convention_1994_ratified: Optional[bool] = None
    nuclear_violations: Optional[bool] = None  # Column BC
    nuclear_risk: Optional[str] = None  # Column BD
    
    # Human Rights (Columns BE-BG)
    human_rights_score: Optional[int] = None  # Column BE
    human_rights_notes: Optional[str] = None  # Column BF
    human_rights_risk: Optional[str] = None  # Column BG
    
    # Freedom Risk (Columns BH-BL)
    political_rights_score: Optional[int] = None  # Column BH
    civil_liberties_score: Optional[int] = None  # Column BI
    freedom_in_the_world: Optional[str] = None  # Column BJ
    freedom_note: Optional[str] = None  # Column BK
    freedom_risk: Optional[str] = None  # Column BL
    
    # Freedom Net Risk (Columns BM-BQ)
    obstacles_to_access: Optional[str] = None  # Column BM
    limits_on_content: Optional[str] = None  # Column BN
    violations_of_user_rights: Optional[str] = None  # Column BO
    freedom_net_note: Optional[str] = None  # Column BP
    freedom_net_risk: Optional[str] = None  # Column BQ
    
    # Regime Risk (Columns BR-BU)
    democracy_status: Optional[str] = None  # Column BR
    democracy_percentage: Optional[float] = None  # Column BS
    nations_in_transit: Optional[str] = None  # Column BT
    regime_type: Optional[str] = None  # Column BU
    
    # Legacy fields for backward compatibility
    human_rights_freedoms_risk: Optional[str] = None
    varieties_of_democracy: Optional[str] = None
    
    # Metadata
    risk_level: Optional[str] = None
    is_active: Optional[bool] = None

class CriticalCountryResponse(BaseModel):
    id: str
    name: str
    abbreviation: Optional[str] = None
    iso_code: Optional[str] = None
    notes: Optional[str] = None
    status: str = "active"  # Column D
    last_assessed: Optional[str] = None  # Column H
    
    # Export Control Regimes (Columns I-N)
    wassenaar_arrangement: bool = False  # Column I (WA)
    nuclear_suppliers_group: bool = False  # Column J (NSG) 
    australia_group: bool = False  # Column K (AG)
    missile_technology_control_regime: bool = False  # Column L (MTCR)
    zangger_committee: bool = False  # Column M (ZC)
    export_control_notes: Optional[str] = None  # Column N
    export_control_risk: str = "low"  # Column O
    
    # Sanctions (Columns Q-S)
    sanctions_status: Optional[str] = None  # Column Q
    sanctions_notes: Optional[str] = None  # Column R
    sanctions_risk: str = "low"  # Column S
    
    # Arms Embargo fields (Columns T-AB)
    un_arms_embargo: bool = False
    un_arms_embargo_notes: Optional[str] = None
    us_arms_embargo: bool = False
    us_arms_embargo_notes: Optional[str] = None
    eu_arms_embargo: bool = False
    eu_arms_embargo_notes: Optional[str] = None
    other_arms_embargo: bool = False
    other_arms_embargo_notes: Optional[str] = None
    arms_risk: str = "low"  # Column AB
    
    # Chemical Weapons Convention (Columns AC-AF)
    cwc_1993_signatory: bool = False  # Column AC
    cwc_1993_ratified: bool = False  # Column AD
    cwc_violations: bool = False  # Column AE
    chemical_risk: str = "low"  # Column AF
    
    # Biological Weapons Convention (Columns AG-AJ)
    bwc_1972_signatory: bool = False  # Column AG
    bwc_1972_ratified: bool = False  # Column AH
    bwc_violations: bool = False  # Column AI
    biological_risk: str = "low"  # Column AJ
    
    # Nuclear Treaties (Columns AK-BD)
    npt_signatory: bool = False
    npt_ratified: bool = False
    npt_notes: Optional[str] = None
    ctbt_signatory: bool = False
    ctbt_ratified: bool = False
    ctbt_notes: Optional[str] = None
    iaea_signatory: bool = False
    iaea_ratified: bool = False
    iaea_notes: Optional[str] = None
    nsg_1974_signatory: bool = False
    nsg_1974_ratified: bool = False
    convention_1980_signatory: bool = False
    convention_1980_ratified: bool = False
    convention_1994_signatory: bool = False
    convention_1994_ratified: bool = False
    nuclear_violations: bool = False  # Column BC
    nuclear_risk: str = "low"  # Column BD
    
    # Human Rights (Columns BE-BG)
    human_rights_score: int = 50  # Column BE
    human_rights_notes: Optional[str] = None  # Column BF
    human_rights_risk: str = "low"  # Column BG
    
    # Freedom Risk (Columns BH-BL)
    political_rights_score: int = 50  # Column BH
    civil_liberties_score: int = 50  # Column BI
    freedom_in_the_world: Optional[str] = None  # Column BJ
    freedom_note: Optional[str] = None  # Column BK
    freedom_risk: str = "low"  # Column BL
    
    # Freedom Net Risk (Columns BM-BQ)
    obstacles_to_access: Optional[str] = None  # Column BM
    limits_on_content: Optional[str] = None  # Column BN
    violations_of_user_rights: Optional[str] = None  # Column BO
    freedom_net_note: Optional[str] = None  # Column BP
    freedom_net_risk: str = "low"  # Column BQ
    
    # Regime Risk (Columns BR-BU)
    democracy_status: Optional[str] = None  # Column BR
    democracy_percentage: Optional[float] = None  # Column BS
    nations_in_transit: Optional[str] = None  # Column BT
    regime_type: Optional[str] = None  # Column BU
    
    # Legacy fields for backward compatibility
    human_rights_freedoms_risk: str = "low"
    varieties_of_democracy: Optional[str] = None
    
    # Metadata
    risk_level: str = "medium"
    is_active: bool = True
    created_at: Optional[str] = None
    updated_at: Optional[str] = None

@router.get("/critical-countries")
async def get_all_critical_countries() -> List[CriticalCountryResponse]:
    """Get all critical countries with comprehensive data"""
    conn = await get_db_connection()
    try:
        query = """
        SELECT * FROM critical_countries 
        WHERE is_active = true 
        ORDER BY name ASC
        """
        rows = await conn.fetch(query)
        
        countries = []
        for row in rows:
            country_dict = dict(row)
            # Convert UUID to string if needed
            if 'id' in country_dict:
                country_dict['id'] = str(country_dict['id'])
            # Convert timestamps to ISO strings
            for field in ['created_at', 'updated_at']:
                if field in country_dict and country_dict[field]:
                    country_dict[field] = country_dict[field].isoformat()
            countries.append(CriticalCountryResponse(**country_dict))
        
        return countries
    except Exception as e:
        print(f"Database error: {e}")
        raise HTTPException(status_code=500, detail=f"Database error: {str(e)}")
    finally:
        await conn.close()

@router.post("/critical-countries")
async def create_critical_country(country: CriticalCountryCreate) -> CriticalCountryResponse:
    """Create a new critical country"""
    conn = await get_db_connection()
    try:
        # Build dynamic insert query
        country_data = country.dict(exclude_unset=True)
        
        # Get all column names except id, created_at, updated_at
        columns = list(country_data.keys())
        placeholders = [f"${i+1}" for i in range(len(columns))]
        values = [country_data[col] for col in columns]
        
        query = f"""
        INSERT INTO critical_countries ({', '.join(columns)}) 
        VALUES ({', '.join(placeholders)})
        RETURNING *
        """
        
        row = await conn.fetchrow(query, *values)
        
        if not row:
            raise HTTPException(status_code=500, detail="Failed to create country")
        
        # Convert row to dict and handle types
        country_dict = dict(row)
        if 'id' in country_dict:
            country_dict['id'] = str(country_dict['id'])
        for field in ['created_at', 'updated_at']:
            if field in country_dict and country_dict[field]:
                country_dict[field] = country_dict[field].isoformat()
        
        return CriticalCountryResponse(**country_dict)
        
    except Exception as e:
        print(f"Database error: {e}")
        raise HTTPException(status_code=500, detail=f"Database error: {str(e)}")
    finally:
        await conn.close()

@router.put("/critical-countries/{countryId}")
async def update_critical_country(countryId: str, country: CriticalCountryUpdate) -> CriticalCountryResponse:
    """Update a critical country"""
    conn = await get_db_connection()
    try:
        # Convert string ID to integer
        country_id_int = int(countryId)
        
        # Build dynamic update query
        country_data = country.dict(exclude_unset=True, exclude_none=True)
        
        if not country_data:
            raise HTTPException(status_code=400, detail="No fields to update")
        
        # Build SET clause
        set_clauses = []
        values = []
        for i, (key, value) in enumerate(country_data.items(), 1):
            set_clauses.append(f"{key} = ${i}")
            values.append(value)
        
        values.append(country_id_int)  # For WHERE clause
        
        query = f"""
        UPDATE critical_countries 
        SET {', '.join(set_clauses)}, updated_at = CURRENT_TIMESTAMP
        WHERE id = ${len(values)}
        RETURNING *
        """
        
        row = await conn.fetchrow(query, *values)
        
        if not row:
            raise HTTPException(status_code=404, detail="Country not found")
        
        # Convert row to dict and handle types
        country_dict = dict(row)
        if 'id' in country_dict:
            country_dict['id'] = str(country_dict['id'])
        for field in ['created_at', 'updated_at']:
            if field in country_dict and country_dict[field]:
                country_dict[field] = country_dict[field].isoformat()
        
        return CriticalCountryResponse(**country_dict)
        
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid country ID format")
    except Exception as e:
        print(f"Database error: {e}")
        raise HTTPException(status_code=500, detail=f"Database error: {str(e)}")
    finally:
        await conn.close()

@router.delete("/critical-countries/{countryId}")
async def delete_critical_country(countryId: str):
    """Delete a critical country"""
    conn = await get_db_connection()
    try:
        # Convert string ID to integer
        country_id_int = int(countryId)
        query = "DELETE FROM critical_countries WHERE id = $1 RETURNING id"
        row = await conn.fetchrow(query, country_id_int)
        
        if not row:
            raise HTTPException(status_code=404, detail="Country not found")
        
        return {"message": "Country deleted successfully", "id": str(row['id'])}
        
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid country ID format")
    except Exception as e:
        print(f"Database error: {e}")
        raise HTTPException(status_code=500, detail=f"Database error: {str(e)}")
    finally:
        await conn.close()
