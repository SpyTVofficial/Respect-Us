


from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from app.auth import AuthorizedUser
import asyncpg
import databutton as db
from typing import Optional
from datetime import datetime

router = APIRouter()

class UpdateUserRequest(BaseModel):
    customer_id: str
    email: str
    contact_person: str
    company_name: Optional[str] = None
    phone: Optional[str] = None
    country: Optional[str] = None
    billing_address: Optional[str] = None
    city: Optional[str] = None
    postal_code: Optional[str] = None
    tax_id: Optional[str] = None
    vat_number: Optional[str] = None

class UpdateUserResponse(BaseModel):
    success: bool
    message: str
    customer: Optional[dict] = None

class CreateUserRequest(BaseModel):
    email: str
    contact_person: str
    company_name: Optional[str] = None
    phone: Optional[str] = None
    country: Optional[str] = None
    billing_address: Optional[str] = None
    city: Optional[str] = None
    postal_code: Optional[str] = None
    tax_id: Optional[str] = None
    vat_number: Optional[str] = None

class CreateUserResponse(BaseModel):
    success: bool
    message: str
    customer_id: Optional[str] = None
    customer: Optional[dict] = None

@router.put("/admin/users/{customer_id}")
async def update_user(customer_id: str, request: UpdateUserRequest, user: AuthorizedUser):
    """
    Update customer/user information in the database
    """
    try:
        # Get database connection
        database_url = db.secrets.get("DATABASE_URL_DEV")
        conn = await asyncpg.connect(database_url)
        
        try:
            # Check if customer exists
            existing_customer = await conn.fetchrow(
                "SELECT * FROM customer_details WHERE customer_id = $1",
                customer_id
            )
            
            if not existing_customer:
                raise HTTPException(status_code=404, detail="Customer not found")
            
            # Update customer information
            updated_customer = await conn.fetchrow("""
                UPDATE customer_details 
                SET 
                    email = $2,
                    contact_person = $3,
                    company_name = $4,
                    phone = $5,
                    country = $6,
                    billing_address = $7,
                    city = $8,
                    postal_code = $9,
                    tax_id = $10,
                    vat_number = $11,
                    updated_at = $12
                WHERE customer_id = $1
                RETURNING *
            """, 
                customer_id,
                request.email,
                request.contact_person,
                request.company_name,
                request.phone,
                request.country,
                request.billing_address,
                request.city,
                request.postal_code,
                request.tax_id,
                request.vat_number,
                datetime.utcnow()
            )
            
            if updated_customer:
                customer_dict = dict(updated_customer)
                return UpdateUserResponse(
                    success=True,
                    message="User updated successfully",
                    customer=customer_dict
                )
            else:
                raise HTTPException(status_code=500, detail="Failed to update customer")
                
        finally:
            await conn.close()
            
    except asyncpg.exceptions.UniqueViolationError:
        raise HTTPException(status_code=400, detail="Email already exists")
    except Exception as e:
        print(f"Error updating user: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")

@router.post("/admin/users")
async def create_user(request: CreateUserRequest, user: AuthorizedUser):
    """
    Create a new customer/user in the database
    """
    try:
        # Get database connection
        database_url = db.secrets.get("DATABASE_URL_DEV")
        conn = await asyncpg.connect(database_url)
        
        try:
            # Generate customer ID
            timestamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
            customer_id = f"cust_{timestamp}_{request.email.split('@')[0]}"
            
            # Create new customer
            new_customer = await conn.fetchrow("""
                INSERT INTO customer_details (
                    customer_id, user_id, email, contact_person, company_name, phone, country,
                    billing_address, city, postal_code, tax_id, vat_number,
                    created_at, updated_at
                ) VALUES (
                    $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14
                )
                RETURNING *
            """,
                customer_id,
                'admin-created',  # user_id for admin-created users
                request.email,
                request.contact_person,
                request.company_name or 'N/A',  # Default for required field
                request.phone,
                request.country or 'N/A',  # Default for required field
                request.billing_address or 'N/A',  # Default for required field
                request.city or 'N/A',  # Default for required field
                request.postal_code or 'N/A',  # Default for required field
                request.tax_id,
                request.vat_number,
                datetime.utcnow(),
                datetime.utcnow()
            )
            
            if new_customer:
                customer_dict = dict(new_customer)
                return CreateUserResponse(
                    success=True,
                    message="User created successfully",
                    customer_id=customer_id,
                    customer=customer_dict
                )
            else:
                raise HTTPException(status_code=500, detail="Failed to create customer")
                
        finally:
            await conn.close()
            
    except asyncpg.exceptions.UniqueViolationError:
        raise HTTPException(status_code=400, detail="Email already exists")
    except Exception as e:
        print(f"Error creating user: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")

@router.delete("/admin/users/{customer_id}")
async def delete_user(customer_id: str, user: AuthorizedUser):
    """
    Delete a customer/user from the database
    """
    try:
        # Get database connection
        database_url = db.secrets.get("DATABASE_URL_DEV")
        conn = await asyncpg.connect(database_url)
        
        try:
            # Check if customer exists
            existing_customer = await conn.fetchrow(
                "SELECT * FROM customer_details WHERE customer_id = $1",
                customer_id
            )
            
            if not existing_customer:
                raise HTTPException(status_code=404, detail="Customer not found")
            
            # Delete customer
            await conn.execute(
                "DELETE FROM customer_details WHERE customer_id = $1",
                customer_id
            )
            
            return {"success": True, "message": "User deleted successfully"}
                
        finally:
            await conn.close()
            
    except Exception as e:
        print(f"Error deleting user: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")
