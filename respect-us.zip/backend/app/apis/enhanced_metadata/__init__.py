from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import List, Dict, Any
from app.auth import AuthorizedUser

router = APIRouter(prefix="/enhanced-metadata")

class EnhancedMetadataOptionsResponse(BaseModel):
    classification_levels: List[Dict[str, Any]]
    security_markings: List[Dict[str, Any]] 
    compliance_frameworks: List[Dict[str, Any]]
    document_types: List[Dict[str, Any]]
    product_categories: List[Dict[str, Any]]
    review_schedules: List[Dict[str, Any]]
    geographic_scopes: List[Dict[str, Any]]

@router.get("/options")
async def get_enhanced_metadata_options(user: AuthorizedUser) -> EnhancedMetadataOptionsResponse:
    """Get all enhanced metadata options for document upload and editing"""
    
    classification_levels = [
        {"value": "Public", "display_name": "Public", "description": "Information that can be shared publicly"},
        {"value": "Internal", "display_name": "Internal", "description": "For internal use within organization"},
        {"value": "Confidential", "display_name": "Confidential", "description": "Sensitive information requiring protection"},
        {"value": "Restricted", "display_name": "Restricted", "description": "Highly sensitive, limited access"},
        {"value": "Top Secret", "display_name": "Top Secret", "description": "Highest level of classification"}
    ]
    
    security_markings = [
        {"value": "FOUO", "display_name": "For Official Use Only"},
        {"value": "PROPRIETARY", "display_name": "Proprietary"},
        {"value": "EXPORT_CONTROLLED", "display_name": "Export Controlled"},
        {"value": "ATTORNEY_CLIENT", "display_name": "Attorney-Client Privileged"},
        {"value": "PERSONAL_DATA", "display_name": "Contains Personal Data"},
        {"value": "FINANCIAL", "display_name": "Financial Information"}
    ]
    
    compliance_frameworks = [
        {"value": "EAR", "display_name": "Export Administration Regulations (EAR)"},
        {"value": "ITAR", "display_name": "International Traffic in Arms Regulations (ITAR)"},
        {"value": "OFAC", "display_name": "Office of Foreign Assets Control (OFAC)"},
        {"value": "EU_DUAL_USE", "display_name": "EU Dual-Use Regulation"},
        {"value": "WASSENAAR", "display_name": "Wassenaar Arrangement"},
        {"value": "AUSTRALIA_GROUP", "display_name": "Australia Group"},
        {"value": "MTCR", "display_name": "Missile Technology Control Regime (MTCR)"},
        {"value": "NSG", "display_name": "Nuclear Suppliers Group (NSG)"},
        {"value": "ISO_27001", "display_name": "ISO 27001"},
        {"value": "SOX", "display_name": "Sarbanes-Oxley Act"},
        {"value": "GDPR", "display_name": "General Data Protection Regulation (GDPR)"}
    ]
    
    document_types = [
        {"value": "regulation", "display_name": "Regulation"},
        {"value": "guidance", "display_name": "Guidance Document"},
        {"value": "policy", "display_name": "Policy"},
        {"value": "procedure", "display_name": "Procedure"},
        {"value": "standard", "display_name": "Standard"},
        {"value": "technical_note", "display_name": "Technical Note"},
        {"value": "advisory", "display_name": "Advisory"},
        {"value": "enforcement_action", "display_name": "Enforcement Action"},
        {"value": "license_template", "display_name": "License Template"},
        {"value": "compliance_checklist", "display_name": "Compliance Checklist"},
        {"value": "training_material", "display_name": "Training Material"},
        {"value": "legal_opinion", "display_name": "Legal Opinion"},
        {"value": "audit_report", "display_name": "Audit Report"}
    ]
    
    product_categories = [
        {"value": "dual_use_goods", "display_name": "Dual-Use Goods"},
        {"value": "military_items", "display_name": "Military Items"},
        {"value": "software", "display_name": "Software"},
        {"value": "technology", "display_name": "Technology"},
        {"value": "chemicals", "display_name": "Chemicals"},
        {"value": "nuclear_materials", "display_name": "Nuclear Materials"},
        {"value": "electronics", "display_name": "Electronics"},
        {"value": "telecommunications", "display_name": "Telecommunications"},
        {"value": "aerospace", "display_name": "Aerospace"},
        {"value": "maritime", "display_name": "Maritime"},
        {"value": "energy", "display_name": "Energy"},
        {"value": "cybersecurity", "display_name": "Cybersecurity"},
        {"value": "biotechnology", "display_name": "Biotechnology"}
    ]
    
    review_schedules = [
        {"value": "monthly", "display_name": "Monthly", "months": 1},
        {"value": "quarterly", "display_name": "Quarterly", "months": 3},
        {"value": "semi_annual", "display_name": "Semi-Annual", "months": 6},
        {"value": "annual", "display_name": "Annual", "months": 12},
        {"value": "biennial", "display_name": "Biennial", "months": 24},
        {"value": "triennial", "display_name": "Triennial", "months": 36},
        {"value": "on_demand", "display_name": "On Demand", "months": None}
    ]
    
    # Using ISO country codes for geographic scope
    geographic_scopes = [
        {"value": "US", "display_name": "United States"},
        {"value": "EU", "display_name": "European Union"},
        {"value": "GB", "display_name": "United Kingdom"},
        {"value": "CA", "display_name": "Canada"},
        {"value": "AU", "display_name": "Australia"},
        {"value": "JP", "display_name": "Japan"},
        {"value": "KR", "display_name": "South Korea"},
        {"value": "IN", "display_name": "India"},
        {"value": "CN", "display_name": "China"},
        {"value": "RU", "display_name": "Russia"},
        {"value": "BR", "display_name": "Brazil"},
        {"value": "MX", "display_name": "Mexico"},
        {"value": "SG", "display_name": "Singapore"},
        {"value": "CH", "display_name": "Switzerland"},
        {"value": "NO", "display_name": "Norway"},
        {"value": "GLOBAL", "display_name": "Global/Worldwide"}
    ]
    
    return EnhancedMetadataOptionsResponse(
        classification_levels=classification_levels,
        security_markings=security_markings,
        compliance_frameworks=compliance_frameworks,
        document_types=document_types,
        product_categories=product_categories,
        review_schedules=review_schedules,
        geographic_scopes=geographic_scopes
    )
