


from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Dict, List, Optional, Any
from app.auth import AuthorizedUser
import asyncpg
import databutton as db
from datetime import datetime
import uuid
from fastapi.responses import Response
from reportlab.lib.pagesizes import letter, A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak, Image
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_JUSTIFY
from reportlab.graphics.shapes import Drawing, Line
import io
import json

router = APIRouter()

class CustomerData(BaseModel):
    customer_id: int
    customer_name: str
    customer_type: str
    legal_name: Optional[str] = None
    country: Optional[str] = None
    risk_category: Optional[str] = None
    date_of_birth: Optional[str] = None

class ScreeningData(BaseModel):
    screening_id: int
    screening_date: datetime
    risk_level: str
    total_matches: int
    high_risk_matches: int
    overall_risk_score: float

class MatchData(BaseModel):
    match_type: str
    matched_field: str
    matched_value: str
    match_score: float
    risk_level: str
    verification_decision: Optional[str] = None
    is_false_positive: bool = False
    false_positive: bool = False

class IndividualReportRequest(BaseModel):
    customer_id: int
    screening_id: int
    include_matches: bool = True

class BatchReportRequest(BaseModel):
    customer_ids: List[int]
    batch_name: Optional[str] = None

class BatchScreeningData(BaseModel):
    customer: CustomerData
    screening: ScreeningData

# New models for country reports
class CountryReportRequest(BaseModel):
    country_id: int
    include_executive_summary: bool = True
    include_detailed_analysis: bool = True
    include_recommendations: bool = True

class BulkCountryReportRequest(BaseModel):
    country_ids: List[int]
    include_executive_summary: bool = True
    include_detailed_analysis: bool = True
    include_recommendations: bool = True

# Database connection helper
async def get_db_connection():
    database_url = db.secrets.get("DATABASE_URL_DEV")
    return await asyncpg.connect(database_url)

# PDF Generation Helper Functions
async def get_cms_content(module_name: str, content_key: str) -> str:
    """Get CMS content for PDF generation"""
    try:
        conn = await get_db_connection()
        content_query = """
            SELECT content FROM cms_content 
            WHERE module_name = $1 AND content_key = $2 AND is_active = true
        """
        result = await conn.fetchval(content_query, module_name, content_key)
        await conn.close()
        
        if result:
            content_data = json.loads(result) if isinstance(result, str) else result
            return content_data.get('text', '') if isinstance(content_data, dict) else str(content_data)
        return ""
    except Exception as e:
        print(f"Error fetching CMS content: {e}")
        return ""

def create_cover_page(story, cover_title: str, cover_subtitle: str, company_credentials: str, country_name: str, generated_date: str, generated_by: str):
    """Create professional cover page for PDF report"""
    styles = getSampleStyleSheet()
    
    # Custom styles for cover page
    title_style = ParagraphStyle(
        'CustomTitle',
        parent=styles['Title'],
        fontSize=28,
        textColor=colors.HexColor('#1e3a8a'),  # Dark blue
        spaceAfter=12,
        alignment=TA_CENTER,
        fontName='Helvetica-Bold'
    )
    
    subtitle_style = ParagraphStyle(
        'CustomSubtitle',
        parent=styles['Heading2'],
        fontSize=18,
        textColor=colors.HexColor('#3b82f6'),  # Blue
        spaceAfter=24,
        alignment=TA_CENTER,
        fontName='Helvetica'
    )
    
    country_style = ParagraphStyle(
        'CountryTitle',
        parent=styles['Heading1'],
        fontSize=24,
        textColor=colors.HexColor('#dc2626'),  # Red
        spaceAfter=36,
        alignment=TA_CENTER,
        fontName='Helvetica-Bold'
    )
    
    # Add logo placeholder (can be replaced with actual logo)
    story.append(Spacer(1, 72))  # 1 inch from top
    
    # RespectUs Logo placeholder
    logo_para = Paragraph(
        '<font size="32" color="#1e3a8a"><b>RespectUs</b></font>',
        ParagraphStyle('Logo', alignment=TA_CENTER, spaceAfter=24)
    )
    story.append(logo_para)
    
    # Main title
    story.append(Paragraph(cover_title, title_style))
    
    # Subtitle
    story.append(Paragraph(cover_subtitle, subtitle_style))
    
    # Country name
    story.append(Paragraph(f"Country Analysis: {country_name}", country_style))
    
    # Spacer
    story.append(Spacer(1, 48))
    
    # Company credentials box
    credentials_style = ParagraphStyle(
        'Credentials',
        parent=styles['Normal'],
        fontSize=11,
        textColor=colors.HexColor('#374151'),
        spaceAfter=24,
        alignment=TA_JUSTIFY,
        leftIndent=36,
        rightIndent=36
    )
    
    story.append(Paragraph(company_credentials, credentials_style))
    
    # Spacer
    story.append(Spacer(1, 72))
    
    # Report metadata
    metadata_style = ParagraphStyle(
        'Metadata',
        parent=styles['Normal'],
        fontSize=10,
        textColor=colors.HexColor('#6b7280'),
        alignment=TA_CENTER,
        spaceAfter=6
    )
    
    story.append(Paragraph(f"<b>Generated:</b> {generated_date}", metadata_style))
    story.append(Paragraph(f"<b>Generated by:</b> {generated_by}", metadata_style))
    
    # Add page break
    story.append(PageBreak())

def create_disclaimer_page(story, disclaimer_text: str):
    """Create disclaimer page"""
    styles = getSampleStyleSheet()
    
    disclaimer_title_style = ParagraphStyle(
        'DisclaimerTitle',
        parent=styles['Heading1'],
        fontSize=20,
        textColor=colors.HexColor('#dc2626'),
        spaceAfter=24,
        alignment=TA_CENTER,
        fontName='Helvetica-Bold'
    )
    
    disclaimer_style = ParagraphStyle(
        'Disclaimer',
        parent=styles['Normal'],
        fontSize=10,
        textColor=colors.HexColor('#374151'),
        spaceAfter=12,
        alignment=TA_JUSTIFY,
        leftIndent=24,
        rightIndent=24,
        spaceBefore=6
    )
    
    story.append(Paragraph("LEGAL DISCLAIMER", disclaimer_title_style))
    story.append(Spacer(1, 12))
    
    # Split disclaimer into paragraphs
    disclaimer_paragraphs = disclaimer_text.split('\n\n')
    for para in disclaimer_paragraphs:
        if para.strip():
            story.append(Paragraph(para.strip(), disclaimer_style))
    
    story.append(PageBreak())

@router.post("/generate-individual-report")
async def generate_individual_report(
    request: IndividualReportRequest,
    user: AuthorizedUser
) -> Response:
    """Generate PDF report for individual customer screening"""
    try:
        async with get_db_connection() as conn:
            # Get customer data
            customer_query = """
                SELECT id, customer_name, customer_type, legal_name, 
                       country, risk_category, date_of_birth
                FROM customer_profiles 
                WHERE id = $1 AND created_by = $2
            """
            customer_row = await conn.fetchrow(customer_query, request.customer_id, user.sub)
            
            if not customer_row:
                raise HTTPException(status_code=404, detail="Customer not found")
            
            # Get screening data
            screening_query = """
                SELECT id, screening_date, risk_level, total_matches,
                       high_risk_matches, overall_risk_score
                FROM screening_results 
                WHERE id = $1 AND customer_id = $2
            """
            screening_row = await conn.fetchrow(screening_query, request.screening_id, request.customer_id)
            
            if not screening_row:
                raise HTTPException(status_code=404, detail="Screening result not found")
            
            matches = []
            if request.include_matches:
                # Get match data
                matches_query = """
                    SELECT match_type, matched_field, matched_value, match_score,
                           risk_level, reviewed_by as verification_decision, is_false_positive, is_false_positive as false_positive
                    FROM screening_matches 
                    WHERE screening_id = $1
                    ORDER BY match_score DESC
                """
                matches_rows = await conn.fetch(matches_query, request.screening_id)
                matches = [dict(row) for row in matches_rows]
            
            # Prepare data for frontend PDF generation
            customer_data = dict(customer_row)
            screening_data = dict(screening_row)
            
            # Generate report ID
            report_id = f"RPT-{uuid.uuid4().hex[:8].upper()}"
            
            # Get user email for "generated by" field
            user_email = getattr(user, 'email', user.sub)
            
            # Return JSON data that frontend will use to generate PDF
            return {
                "report_id": report_id,
                "customer": customer_data,
                "screening": screening_data,
                "matches": matches,
                "generated_by": user_email,
                "generated_at": datetime.now().isoformat()
            }
            
    except Exception as e:
        print(f"Error generating individual report: {e}")
        raise HTTPException(status_code=500, detail="Failed to generate report")

@router.post("/generate-batch-report")
async def generate_batch_report(
    request: BatchReportRequest,
    user: AuthorizedUser
) -> Response:
    """Generate PDF report for batch customer screening"""
    try:
        async with get_db_connection() as conn:
            batch_data = []
            
            for customer_id in request.customer_ids:
                # Get customer data
                customer_query = """
                    SELECT id, customer_name, customer_type, legal_name, 
                           country, risk_category, date_of_birth
                    FROM customer_profiles 
                    WHERE id = $1 AND created_by = $2
                """
                customer_row = await conn.fetchrow(customer_query, customer_id, user.sub)
                
                if not customer_row:
                    continue  # Skip customers not found
                
                # Get latest screening data for this customer
                screening_query = """
                    SELECT id, screening_date, risk_level, total_matches,
                           high_risk_matches, overall_risk_score
                    FROM screening_results 
                    WHERE customer_id = $1
                    ORDER BY screening_date DESC
                    LIMIT 1
                """
                screening_row = await conn.fetchrow(screening_query, customer_id)
                
                if screening_row:
                    batch_data.append({
                        "customer": dict(customer_row),
                        "screening": dict(screening_row)
                    })
            
            if not batch_data:
                raise HTTPException(status_code=404, detail="No valid customers found for batch report")
            
            # Generate report ID and batch number
            report_id = f"BATCH-{uuid.uuid4().hex[:8].upper()}"
            batch_number = request.batch_name or f"BATCH-{datetime.now().strftime('%Y%m%d-%H%M%S')}"
            
            # Get user email for "generated by" field
            user_email = getattr(user, 'email', user.sub)
            
            # Return JSON data that frontend will use to generate PDF
            return {
                "report_id": report_id,
                "batch_number": batch_number,
                "screening_data": batch_data,
                "generated_by": user_email,
                "generated_at": datetime.now().isoformat()
            }
            
    except Exception as e:
        print(f"Error generating batch report: {e}")
        raise HTTPException(status_code=500, detail="Failed to generate batch report")

@router.post("/generate-country-report")
async def generate_country_report(
    request: CountryReportRequest,
    user: AuthorizedUser
) -> Response:
    """Generate PDF report for country risk analysis"""
    try:
        conn = await get_db_connection()
        try:
            # Get country data
            country_query = """
                SELECT * FROM critical_countries
                WHERE id = $1 AND is_active = true
            """
            country_row = await conn.fetchrow(country_query, request.country_id)
            
            if not country_row:
                raise HTTPException(status_code=404, detail="Country not found")
            
            country_data = dict(country_row)
            
            # Get CMS content for cover page and disclaimer
            cover_title = await get_cms_content("pdf_reports", "cover_page_title") or "Country Risk Analysis Report"
            cover_subtitle = await get_cms_content("pdf_reports", "cover_page_subtitle") or "Comprehensive Export Control Risk Assessment"
            company_credentials = await get_cms_content("pdf_reports", "company_credentials") or "RespectUs - Export Control Compliance Solutions"
            disclaimer_text = await get_cms_content("pdf_reports", "report_disclaimer") or "This report is provided for informational purposes only."
            
            # Get Risk Assessment Methodology from CMS
            risk_assessment_methodology = await get_cms_content("end_use_checks", "risk_assessment_methodology") or "Risk Assessment Methodology not available"
            
            # Create PDF buffer
            buffer = io.BytesIO()
            doc = SimpleDocTemplate(buffer, pagesize=A4, topMargin=72, bottomMargin=72)
            story = []
            styles = getSampleStyleSheet()
            
            # Generate date and user info
            generated_date = datetime.now().strftime("%B %d, %Y at %I:%M %p UTC")
            generated_by = getattr(user, 'email', user.sub)
            country_name = country_data.get('country_name', 'Unknown Country')
            
            # Create cover page
            create_cover_page(story, cover_title, cover_subtitle, company_credentials, country_name, generated_date, generated_by)
            
            # Create disclaimer page
            create_disclaimer_page(story, disclaimer_text)
            
            # Add Risk Assessment Methodology section
            methodology_title_style = ParagraphStyle(
                'MethodologyTitle',
                parent=styles['Heading1'],
                fontSize=18,
                textColor=colors.HexColor('#1e3a8a'),
                spaceAfter=12,
                fontName='Helvetica-Bold'
            )
            
            story.append(Paragraph("Risk Assessment Methodology", methodology_title_style))
            story.append(Spacer(1, 12))
            
            # Parse and add methodology content
            methodology_style = ParagraphStyle(
                'Methodology',
                parent=styles['Normal'],
                fontSize=10,
                spaceAfter=12,
                textColor=colors.HexColor('#374151')
            )
            
            # If methodology contains HTML, strip tags and format as paragraphs
            import re
            clean_methodology = re.sub(r'<[^>]+>', '', risk_assessment_methodology)
            methodology_paragraphs = clean_methodology.split('\n\n')
            
            for para in methodology_paragraphs:
                if para.strip():
                    story.append(Paragraph(para.strip(), methodology_style))
            
            story.append(PageBreak())
            
            # Executive Summary
            if request.include_executive_summary:
                exec_title_style = ParagraphStyle(
                    'ExecTitle',
                    parent=styles['Heading1'],
                    fontSize=18,
                    textColor=colors.HexColor('#1e3a8a'),
                    spaceAfter=12,
                    fontName='Helvetica-Bold'
                )
                
                story.append(Paragraph("Executive Summary", exec_title_style))
                story.append(Spacer(1, 12))
                
                # Country overview table (Tab 1 - Overview)
                overview_data = [
                    ['Country', country_data.get('country_name', 'N/A')],
                    ['ISO Code', country_data.get('abbreviation', 'N/A')],
                    ['Overall Risk Level', country_data.get('risk_level', 'N/A')],
                    ['Last Assessment', country_data.get('last_risk_assessment_date', 'N/A')],
                    ['Status', 'Active' if country_data.get('is_active', False) else 'Inactive'],
                ]
                
                overview_table = Table(overview_data, colWidths=[2*inch, 3*inch])
                overview_table.setStyle(TableStyle([
                    ('BACKGROUND', (0, 0), (0, -1), colors.HexColor('#f3f4f6')),
                    ('TEXTCOLOR', (0, 0), (-1, -1), colors.black),
                    ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                    ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
                    ('FONTNAME', (1, 0), (1, -1), 'Helvetica'),
                    ('FONTSIZE', (0, 0), (-1, -1), 10),
                    ('GRID', (0, 0), (-1, -1), 1, colors.HexColor('#d1d5db')),
                    ('VALIGN', (0, 0), (-1, -1), 'TOP'),
                ]))
                
                story.append(overview_table)
                story.append(Spacer(1, 24))
                
                # Risk Assessment Summary
                risk_summary_style = ParagraphStyle(
                    'RiskSummary',
                    parent=styles['Heading2'],
                    fontSize=14,
                    textColor=colors.HexColor('#374151'),
                    spaceAfter=8,
                    fontName='Helvetica-Bold'
                )
                
                story.append(Paragraph("Risk Assessment Summary", risk_summary_style))
                
                risk_data = [
                    ['Risk Category', 'Level', 'Notes'],
                    ['Export Control', country_data.get('export_control_risk', 'N/A'), country_data.get('export_control_notes', 'No notes available')[:100] + '...' if country_data.get('export_control_notes', '') else 'N/A'],
                    ['Sanctions', country_data.get('sanctions_risk', 'N/A'), country_data.get('sanctions_notes', 'No notes available')[:100] + '...' if country_data.get('sanctions_notes', '') else 'N/A'],
                    ['Arms Control', country_data.get('arms_risk', 'N/A'), 'Various arms control assessments'],
                    ['Chemical Risk', country_data.get('chemical_risk', 'N/A'), 'Chemical weapons convention compliance'],
                    ['Biological Risk', country_data.get('biological_risks', 'N/A'), 'Biological weapons convention compliance'],
                    ['Nuclear Risk', country_data.get('nuclear_risk', 'N/A'), 'Nuclear non-proliferation compliance'],
                    ['Human Rights', country_data.get('human_rights_freedoms_risk', 'N/A'), country_data.get('human_rights_note', 'No notes available')[:100] + '...' if country_data.get('human_rights_note', '') else 'N/A'],
                ]
                
                risk_table = Table(risk_data, colWidths=[1.5*inch, 1*inch, 3*inch])
                risk_table.setStyle(TableStyle([
                    ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#1e3a8a')),
                    ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
                    ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                    ('FONTSIZE', (0, 0), (-1, 0), 10),
                    ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                    ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
                    ('FONTSIZE', (0, 1), (-1, -1), 9),
                    ('GRID', (0, 0), (-1, -1), 1, colors.HexColor('#d1d5db')),
                    ('VALIGN', (0, 0), (-1, -1), 'TOP'),
                ]))
                
                story.append(risk_table)
                story.append(PageBreak())
            
            # Detailed Analysis sections (if requested) - All 8 tabs data
            if request.include_detailed_analysis:
                # Tab 2: Export Controls Section
                section_title_style = ParagraphStyle(
                    'SectionTitle',
                    parent=styles['Heading1'],
                    fontSize=16,
                    textColor=colors.HexColor('#1e3a8a'),
                    spaceAfter=12,
                    fontName='Helvetica-Bold'
                )
                
                story.append(Paragraph("Export Control Analysis", section_title_style))
                
                export_data = [
                    ['Regime', 'Status', 'Notes'],
                    ['Wassenaar Arrangement', 'Yes' if country_data.get('wassenaar_arrangement') else 'No', 'Dual-use goods and technologies'],
                    ['Nuclear Suppliers Group', 'Yes' if country_data.get('nuclear_suppliers_group') else 'No', 'Nuclear-related materials'],
                    ['Australia Group', 'Yes' if country_data.get('australia_group') else 'No', 'Chemical and biological weapons'],
                    ['MTCR', 'Yes' if country_data.get('missile_technology_control_regime') else 'No', 'Missile technology'],
                    ['Zangger Committee', 'Yes' if country_data.get('zangger_committee') else 'No', 'Nuclear export controls'],
                ]
                
                export_table = Table(export_data, colWidths=[2*inch, 1*inch, 2.5*inch])
                export_table.setStyle(TableStyle([
                    ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#3b82f6')),
                    ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
                    ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                    ('FONTSIZE', (0, 0), (-1, 0), 10),
                    ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                    ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
                    ('FONTSIZE', (0, 1), (-1, -1), 9),
                    ('GRID', (0, 0), (-1, -1), 1, colors.HexColor('#d1d5db')),
                ]))
                
                story.append(export_table)
                story.append(Spacer(1, 24))
                
                # Notes style for all sections
                notes_style = ParagraphStyle(
                    'Notes',
                    parent=styles['Normal'],
                    fontSize=9,
                    textColor=colors.HexColor('#6b7280'),
                    spaceAfter=12
                )
                
                if country_data.get('export_control_notes'):
                    story.append(Paragraph(f"<b>Export Control Notes:</b> {country_data.get('export_control_notes')}", notes_style))
                
                story.append(PageBreak())
                
                # Tab 3: Sanctions Analysis
                story.append(Paragraph("Sanctions Analysis", section_title_style))
                
                sanctions_data = [
                    ['Status', country_data.get('sanctions_status', 'No Active Sanctions')],
                    ['Risk Level', country_data.get('sanctions_risk', 'N/A')],
                ]
                
                sanctions_table = Table(sanctions_data, colWidths=[2*inch, 3*inch])
                sanctions_table.setStyle(TableStyle([
                    ('BACKGROUND', (0, 0), (0, -1), colors.HexColor('#f3f4f6')),
                    ('TEXTCOLOR', (0, 0), (-1, -1), colors.black),
                    ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                    ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
                    ('FONTNAME', (1, 0), (1, -1), 'Helvetica'),
                    ('FONTSIZE', (0, 0), (-1, -1), 10),
                    ('GRID', (0, 0), (-1, -1), 1, colors.HexColor('#d1d5db')),
                ]))
                
                story.append(sanctions_table)
                
                if country_data.get('sanctions_notes'):
                    story.append(Spacer(1, 12))
                    story.append(Paragraph(f"<b>Sanctions Notes:</b> {country_data.get('sanctions_notes')}", notes_style))
                
                story.append(PageBreak())
                
                # Tab 4: Arms Embargo Analysis
                story.append(Paragraph("Arms Embargo Analysis", section_title_style))
                
                arms_data = [
                    ['Embargo Type', 'Status', 'Notes'],
                    ['UN Arms Embargo', 'Active' if country_data.get('un_arms_embargo') else 'No Embargo', country_data.get('un_arms_embargo_notes', 'N/A')],
                    ['US Arms Embargo', 'Active' if country_data.get('us_arms_embargo') else 'No Embargo', country_data.get('us_arms_embargo_notes', 'N/A')],
                    ['EU Arms Embargo', 'Active' if country_data.get('eu_arms_embargo') else 'No Embargo', country_data.get('eu_arms_embargo_notes', 'N/A')],
                    ['Other Arms Embargo', 'Active' if country_data.get('other_arms_embargo') else 'No Embargo', country_data.get('other_arms_embargo_notes', 'N/A')],
                ]
                
                arms_table = Table(arms_data, colWidths=[1.5*inch, 1.2*inch, 2.8*inch])
                arms_table.setStyle(TableStyle([
                    ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#dc2626')),
                    ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
                    ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                    ('FONTSIZE', (0, 0), (-1, 0), 10),
                    ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                    ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
                    ('FONTSIZE', (0, 1), (-1, -1), 9),
                    ('GRID', (0, 0), (-1, -1), 1, colors.HexColor('#d1d5db')),
                    ('VALIGN', (0, 0), (-1, -1), 'TOP'),
                ]))
                
                story.append(arms_table)
                story.append(Spacer(1, 12))
                story.append(Paragraph(f"<b>Arms Risk Level:</b> {country_data.get('arms_risk', 'N/A')}", notes_style))
                story.append(PageBreak())
                
                # Tab 5: Chemical Risk Analysis
                story.append(Paragraph("Chemical Weapons Convention Analysis", section_title_style))
                
                chemical_data = [
                    ['Convention Element', 'Status'],
                    ['CWC 1993 Signatory', 'Yes' if country_data.get('cwc_1993_signatory') else 'No'],
                    ['CWC 1993 Ratified', 'Yes' if country_data.get('cwc_1993_ratified') else 'No'],
                    ['CWC Violations', 'Reported' if country_data.get('cwc_violations') else 'None'],
                    ['Chemical Risk Level', country_data.get('chemical_risk', 'N/A')],
                ]
                
                chemical_table = Table(chemical_data, colWidths=[3*inch, 2*inch])
                chemical_table.setStyle(TableStyle([
                    ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#eab308')),
                    ('TEXTCOLOR', (0, 0), (-1, 0), colors.black),
                    ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                    ('FONTSIZE', (0, 0), (-1, 0), 10),
                    ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                    ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
                    ('FONTSIZE', (0, 1), (-1, -1), 9),
                    ('GRID', (0, 0), (-1, -1), 1, colors.HexColor('#d1d5db')),
                ]))
                
                story.append(chemical_table)
                story.append(PageBreak())
                
                # Tab 6: Biological Risk Analysis
                story.append(Paragraph("Biological Weapons Convention Analysis", section_title_style))
                
                biological_data = [
                    ['Convention Element', 'Status'],
                    ['BWC 1972 Signatory', 'Yes' if country_data.get('bwc_1972_signatory') else 'No'],
                    ['BWC 1972 Ratified', 'Yes' if country_data.get('bwc_1972_ratified') else 'No'],
                    ['BWC Violations', 'Reported' if country_data.get('bwc_violations') else 'None'],
                    ['Biological Risk Level', country_data.get('biological_risks', 'N/A')],
                ]
                
                biological_table = Table(biological_data, colWidths=[3*inch, 2*inch])
                biological_table.setStyle(TableStyle([
                    ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#8b5cf6')),
                    ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
                    ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                    ('FONTSIZE', (0, 0), (-1, 0), 10),
                    ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                    ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
                    ('FONTSIZE', (0, 1), (-1, -1), 9),
                    ('GRID', (0, 0), (-1, -1), 1, colors.HexColor('#d1d5db')),
                ]))
                
                story.append(biological_table)
                story.append(PageBreak())
                
                # Tab 7: Nuclear Risk Analysis
                story.append(Paragraph("Nuclear Treaties & Agreements Analysis", section_title_style))
                
                nuclear_data = [
                    ['Treaty/Agreement', 'Signatory', 'Ratified'],
                    ['NPT (Non-Proliferation Treaty)', 'Yes' if country_data.get('npt_signatory') else 'No', 'Yes' if country_data.get('npt_ratified') else 'No'],
                    ['CTBT (Comprehensive Test Ban)', 'Yes' if country_data.get('ctbt_signatory') else 'No', 'Yes' if country_data.get('ctbt_ratified') else 'No'],
                    ['IAEA Safeguards', 'Yes' if country_data.get('iaea_signatory') else 'No', 'Yes' if country_data.get('iaea_ratified') else 'No'],
                    ['NSG (Nuclear Suppliers Group)', 'Yes' if country_data.get('nsg_1974_signatory') else 'No', 'N/A'],
                    ['Convention 1980', 'Yes' if country_data.get('convention_1980_signatory') else 'No', 'N/A'],
                    ['Convention 1994', 'Yes' if country_data.get('convention_1994_signatory') else 'No', 'N/A'],
                ]
                
                nuclear_table = Table(nuclear_data, colWidths=[2.5*inch, 1.25*inch, 1.25*inch])
                nuclear_table.setStyle(TableStyle([
                    ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#f59e0b')),
                    ('TEXTCOLOR', (0, 0), (-1, 0), colors.black),
                    ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                    ('FONTSIZE', (0, 0), (-1, 0), 10),
                    ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                    ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
                    ('FONTSIZE', (0, 1), (-1, -1), 9),
                    ('GRID', (0, 0), (-1, -1), 1, colors.HexColor('#d1d5db')),
                ]))
                
                story.append(nuclear_table)
                story.append(Spacer(1, 12))
                
                nuclear_status_data = [
                    ['Nuclear Violations', 'Reported' if country_data.get('nuclear_violations') else 'None'],
                    ['Nuclear Risk Level', country_data.get('nuclear_risk', 'N/A')],
                ]
                
                nuclear_status_table = Table(nuclear_status_data, colWidths=[2*inch, 3*inch])
                nuclear_status_table.setStyle(TableStyle([
                    ('BACKGROUND', (0, 0), (0, -1), colors.HexColor('#f3f4f6')),
                    ('TEXTCOLOR', (0, 0), (-1, -1), colors.black),
                    ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                    ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
                    ('FONTNAME', (1, 0), (1, -1), 'Helvetica'),
                    ('FONTSIZE', (0, 0), (-1, -1), 10),
                    ('GRID', (0, 0), (-1, -1), 1, colors.HexColor('#d1d5db')),
                ]))
                
                story.append(nuclear_status_table)
                story.append(PageBreak())
                
                # Tab 8: Human Rights & Freedom Analysis
                story.append(Paragraph("Human Rights & Freedom Analysis", section_title_style))
                
                # Human Rights section
                hr_data = [
                    ['Human Rights Metric', 'Score/Status'],
                    ['Human Rights Score', f"{country_data.get('human_rights_score', 'N/A')}/100"],
                    ['Human Rights Risk', country_data.get('human_rights_risk', 'N/A')],
                    ['Political Rights Score', f"{country_data.get('political_rights_score', 'N/A')}/100"],
                    ['Civil Liberties Score', f"{country_data.get('civil_liberties_score', 'N/A')}/100"],
                    ['Freedom Status', country_data.get('freedom_in_the_world', 'N/A')],
                    ['Democracy Status', country_data.get('democracy_status', 'N/A')],
                    ['Freedom Risk Level', country_data.get('freedom_risk', 'N/A')],
                    ['Human Rights & Freedoms Risk', country_data.get('human_rights_freedoms_risk', 'N/A')],
                ]
                
                hr_table = Table(hr_data, colWidths=[3*inch, 2*inch])
                hr_table.setStyle(TableStyle([
                    ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#059669')),
                    ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
                    ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                    ('FONTSIZE', (0, 0), (-1, 0), 10),
                    ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                    ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
                    ('FONTSIZE', (0, 1), (-1, -1), 9),
                    ('GRID', (0, 0), (-1, -1), 1, colors.HexColor('#d1d5db')),
                ]))
                
                story.append(hr_table)
                
                if country_data.get('human_rights_notes'):
                    story.append(Spacer(1, 12))
                    story.append(Paragraph(f"<b>Human Rights Notes:</b> {country_data.get('human_rights_notes')}", notes_style))
                
                if country_data.get('freedom_note'):
                    story.append(Spacer(1, 8))
                    story.append(Paragraph(f"<b>Freedom Note:</b> {country_data.get('freedom_note')}", notes_style))
            
            # Generate report ID
            report_id = f"COUNTRY-{uuid.uuid4().hex[:8].upper()}"
            
            # Build PDF
            doc.build(story)
            
            # Get PDF bytes
            pdf_bytes = buffer.getvalue()
            buffer.close()
            
            # Return PDF response
            return Response(
                content=pdf_bytes,
                media_type="application/pdf",
                headers={
                    "Content-Disposition": f"attachment; filename={country_name.replace(' ', '_')}_Risk_Analysis_{report_id}.pdf"
                }
            )
        finally:
            await conn.close()
            
    except Exception as e:
        print(f"Error generating country report: {e}")
        raise HTTPException(status_code=500, detail="Failed to generate country report")
