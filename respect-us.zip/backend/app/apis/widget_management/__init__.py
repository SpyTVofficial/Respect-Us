from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import List, Dict, Any, Optional
import uuid
from datetime import datetime

router = APIRouter(prefix="/widget-management")

# Pydantic Models for Widget Management
class SearchFieldConfig(BaseModel):
    field_name: str
    field_type: str  # "text", "select", "multiselect", "date", "number"
    label: str
    placeholder: Optional[str] = None
    required: bool = False
    options: Optional[List[str]] = None  # For select/multiselect fields
    validation_rules: Optional[Dict[str, Any]] = None

class DataSourceConfig(BaseModel):
    source_type: str  # "api", "database", "static"
    source_url: Optional[str] = None
    source_query: Optional[str] = None
    static_data: Optional[List[Dict[str, Any]]] = None
    mapping_fields: Dict[str, str]  # Maps display fields to data fields
    authentication: Optional[Dict[str, str]] = None

class DisplayConfig(BaseModel):
    title_field: str
    subtitle_field: Optional[str] = None
    description_field: Optional[str] = None
    badge_field: Optional[str] = None
    badge_color_mapping: Optional[Dict[str, str]] = None
    risk_level_field: Optional[str] = None
    details_fields: List[str] = []

class WidgetTemplate(BaseModel):
    id: Optional[str] = None
    name: str
    description: str
    category: str  # "sanctions", "products", "countries", "custom"
    icon: str
    color_scheme: str
    search_fields: List[SearchFieldConfig]
    data_source: DataSourceConfig
    display_config: DisplayConfig
    advanced_features: Dict[str, Any] = {}
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    is_active: bool = True

class CreateWidgetRequest(BaseModel):
    template: WidgetTemplate

class UpdateWidgetRequest(BaseModel):
    widget_id: str
    template: WidgetTemplate

class WidgetResponse(BaseModel):
    id: str
    template: WidgetTemplate
    status: str
    performance_stats: Optional[Dict[str, Any]] = None

class WidgetTestRequest(BaseModel):
    widget_id: str
    test_query: str
    test_parameters: Dict[str, Any] = {}

class WidgetTestResponse(BaseModel):
    success: bool
    results: List[Dict[str, Any]]
    response_time: float
    errors: Optional[List[str]] = None

# In-memory storage for demo (in production would use database)
widget_storage = {}
widget_templates = {}

# Predefined widget templates
def get_default_templates():
    return {
        "sanctions_template": WidgetTemplate(
            id="sanctions_template",
            name="Sanctions List Search",
            description="Search across multiple sanctions lists for persons and entities",
            category="sanctions",
            icon="shield",
            color_scheme="red",
            search_fields=[
                SearchFieldConfig(
                    field_name="entity_name",
                    field_type="text",
                    label="Entity/Person Name",
                    placeholder="Enter name to search...",
                    required=True
                ),
                SearchFieldConfig(
                    field_name="jurisdiction",
                    field_type="multiselect",
                    label="Jurisdiction",
                    options=["OFAC", "EU", "UN", "UK", "Canada"],
                    required=False
                ),
                SearchFieldConfig(
                    field_name="list_type",
                    field_type="select",
                    label="List Type",
                    options=["SDN", "Sectoral", "Non-SDN", "All"],
                    required=False
                )
            ],
            data_source=DataSourceConfig(
                source_type="api",
                source_url="/api/sanctions/search",
                mapping_fields={
                    "name": "entity_name",
                    "list": "source_list",
                    "risk": "risk_level",
                    "jurisdiction": "jurisdiction"
                }
            ),
            display_config=DisplayConfig(
                title_field="name",
                subtitle_field="list",
                description_field="description",
                badge_field="risk",
                badge_color_mapping={
                    "HIGH": "red",
                    "MEDIUM": "orange",
                    "LOW": "yellow"
                },
                risk_level_field="risk",
                details_fields=["jurisdiction", "date_added", "aliases"]
            ),
            advanced_features={
                "fuzzy_search": True,
                "alias_matching": True,
                "real_time_updates": True
            }
        ),
        "products_template": WidgetTemplate(
            id="products_template",
            name="Product Classification Search",
            description="Search for dual-use items and export control classifications",
            category="products",
            icon="target",
            color_scheme="blue",
            search_fields=[
                SearchFieldConfig(
                    field_name="product_name",
                    field_type="text",
                    label="Product Description",
                    placeholder="Enter product name or description...",
                    required=True
                ),
                SearchFieldConfig(
                    field_name="category",
                    field_type="multiselect",
                    label="Control Category",
                    options=["EAR", "ITAR", "Dual-Use", "Nuclear"],
                    required=False
                ),
                SearchFieldConfig(
                    field_name="technology_level",
                    field_type="select",
                    label="Technology Level",
                    options=["Basic", "Intermediate", "Advanced", "Cutting-edge"],
                    required=False
                )
            ],
            data_source=DataSourceConfig(
                source_type="api",
                source_url="/api/product-classification/search",
                mapping_fields={
                    "name": "product_name",
                    "code": "classification_code",
                    "category": "control_category",
                    "license_required": "license_required"
                }
            ),
            display_config=DisplayConfig(
                title_field="name",
                subtitle_field="code",
                description_field="description",
                badge_field="license_required",
                badge_color_mapping={
                    "Required": "red",
                    "Case-by-case": "orange",
                    "Not Required": "green"
                },
                details_fields=["category", "technical_notes", "exemptions"]
            ),
            advanced_features={
                "technical_search": True,
                "specification_matching": True,
                "license_guidance": True
            }
        )
    }

# Initialize default templates
widget_templates.update(get_default_templates())

@router.get("/templates")
async def list_widget_templates():
    """Get all available widget templates"""
    return {
        "templates": list(widget_templates.values()),
        "total": len(widget_templates)
    }

@router.get("/templates/{template_id}")
async def get_widget_template(template_id: str):
    """Get a specific widget template"""
    if template_id not in widget_templates:
        raise HTTPException(status_code=404, detail="Template not found")
    return widget_templates[template_id]

@router.post("/templates")
async def create_widget_template(request: WidgetTemplate):
    """Create a new widget template"""
    template_id = str(uuid.uuid4())
    request.id = template_id
    request.created_at = datetime.now()
    request.updated_at = datetime.now()
    
    widget_templates[template_id] = request
    
    return {
        "template_id": template_id,
        "template": request,
        "message": "Template created successfully"
    }

@router.put("/templates/{template_id}")
async def update_widget_template(template_id: str, request: WidgetTemplate):
    """Update an existing widget template"""
    if template_id not in widget_templates:
        raise HTTPException(status_code=404, detail="Template not found")
    
    request.id = template_id
    request.updated_at = datetime.now()
    widget_templates[template_id] = request
    
    return {
        "template_id": template_id,
        "template": request,
        "message": "Template updated successfully"
    }

@router.delete("/templates/{template_id}")
async def delete_widget_template(template_id: str):
    """Delete a widget template"""
    if template_id not in widget_templates:
        raise HTTPException(status_code=404, detail="Template not found")
    
    del widget_templates[template_id]
    
    return {"message": "Template deleted successfully"}

@router.get("/widgets")
async def list_custom_widgets():
    """Get all created custom widgets"""
    widgets = []
    for widget_id, widget_data in widget_storage.items():
        widgets.append(WidgetResponse(
            id=widget_id,
            template=widget_data["template"],
            status=widget_data.get("status", "active"),
            performance_stats=widget_data.get("performance_stats", {
                "total_searches": 0,
                "avg_response_time": 0,
                "success_rate": 100
            })
        ))
    
    return {
        "widgets": widgets,
        "total": len(widgets)
    }

@router.post("/widgets")
async def create_custom_widget(request: CreateWidgetRequest):
    """Create a new custom widget from a template"""
    widget_id = str(uuid.uuid4())
    
    widget_data = {
        "template": request.template,
        "status": "active",
        "created_at": datetime.now(),
        "performance_stats": {
            "total_searches": 0,
            "avg_response_time": 0,
            "success_rate": 100
        }
    }
    
    widget_storage[widget_id] = widget_data
    
    return {
        "widget_id": widget_id,
        "widget": WidgetResponse(
            id=widget_id,
            template=request.template,
            status="active",
            performance_stats=widget_data["performance_stats"]
        ),
        "message": "Widget created successfully"
    }

@router.get("/widgets/{widget_id}")
async def get_custom_widget(widget_id: str):
    """Get a specific custom widget"""
    if widget_id not in widget_storage:
        raise HTTPException(status_code=404, detail="Widget not found")
    
    widget_data = widget_storage[widget_id]
    return WidgetResponse(
        id=widget_id,
        template=widget_data["template"],
        status=widget_data.get("status", "active"),
        performance_stats=widget_data.get("performance_stats")
    )

@router.put("/widgets/{widget_id}")
async def update_custom_widget(widget_id: str, request: UpdateWidgetRequest):
    """Update a custom widget"""
    if widget_id not in widget_storage:
        raise HTTPException(status_code=404, detail="Widget not found")
    
    widget_storage[widget_id]["template"] = request.template
    widget_storage[widget_id]["updated_at"] = datetime.now()
    
    return {
        "widget_id": widget_id,
        "message": "Widget updated successfully"
    }

@router.delete("/widgets/{widget_id}")
async def delete_custom_widget(widget_id: str):
    """Delete a custom widget"""
    if widget_id not in widget_storage:
        raise HTTPException(status_code=404, detail="Widget not found")
    
    del widget_storage[widget_id]
    
    return {"message": "Widget deleted successfully"}

@router.post("/widgets/{widget_id}/test")
async def test_widget(widget_id: str, request: WidgetTestRequest):
    """Test a widget with sample data"""
    if widget_id not in widget_storage:
        raise HTTPException(status_code=404, detail="Widget not found")
    
    widget_data = widget_storage[widget_id]
    template = widget_data["template"]
    
    # Simulate widget testing based on category
    if template.category == "sanctions":
        results = [
            {
                "name": f"Test Entity {request.test_query}",
                "list": "OFAC SDN",
                "risk": "HIGH",
                "jurisdiction": "US",
                "description": "Test sanctions entry for widget testing"
            },
            {
                "name": f"Related Entity {request.test_query}",
                "list": "EU Sanctions",
                "risk": "MEDIUM",
                "jurisdiction": "EU",
                "description": "Another test sanctions entry"
            }
        ]
    elif template.category == "products":
        results = [
            {
                "name": f"Test Product {request.test_query}",
                "code": "9A001",
                "category": "EAR",
                "license_required": "Required",
                "description": "Test product classification entry"
            },
            {
                "name": f"Related Product {request.test_query}",
                "code": "9A002",
                "category": "Dual-Use",
                "license_required": "Case-by-case",
                "description": "Another test product entry"
            }
        ]
    else:
        results = [
            {
                "name": f"Test Result {request.test_query}",
                "category": "Custom",
                "description": "Test result for custom widget"
            }
        ]
    
    # Simulate response time
    import time
    start_time = time.time()
    time.sleep(0.1)  # Simulate processing time
    response_time = (time.time() - start_time) * 1000  # Convert to milliseconds
    
    return WidgetTestResponse(
        success=True,
        results=results,
        response_time=response_time,
        errors=None
    )

@router.get("/categories")
async def get_widget_categories():
    """Get available widget categories"""
    return {
        "categories": [
            {"id": "sanctions", "name": "Sanctions & Embargoes", "icon": "shield", "color": "red"},
            {"id": "products", "name": "Product Classification", "icon": "target", "color": "blue"},
            {"id": "countries", "name": "Country Restrictions", "icon": "globe", "color": "amber"},
            {"id": "customers", "name": "Customer Screening", "icon": "users", "color": "purple"},
            {"id": "licenses", "name": "License Management", "icon": "file-text", "color": "green"},
            {"id": "custom", "name": "Custom Search", "icon": "search", "color": "gray"}
        ]
    }

@router.get("/field-types")
async def get_field_types():
    """Get available field types for widget configuration"""
    return {
        "field_types": [
            {"id": "text", "name": "Text Input", "description": "Single line text input"},
            {"id": "textarea", "name": "Text Area", "description": "Multi-line text input"},
            {"id": "select", "name": "Dropdown", "description": "Single selection dropdown"},
            {"id": "multiselect", "name": "Multi-Select", "description": "Multiple selection dropdown"},
            {"id": "date", "name": "Date Picker", "description": "Date selection input"},
            {"id": "number", "name": "Number Input", "description": "Numeric input field"},
            {"id": "checkbox", "name": "Checkbox", "description": "Boolean checkbox input"},
            {"id": "radio", "name": "Radio Buttons", "description": "Single selection radio group"}
        ]
    }
