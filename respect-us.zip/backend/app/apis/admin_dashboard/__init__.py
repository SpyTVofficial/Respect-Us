from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel
from typing import List, Optional, Dict, Any
import asyncpg
import databutton as db
from datetime import datetime, date
from app.auth import AuthorizedUser

router = APIRouter(prefix="/admin-dashboard")

# Database connection
async def get_db_connection():
    return await asyncpg.connect(db.secrets.get("DATABASE_URL_DEV"))

# Admin role check - for now, we'll use user ID, but this could be enhanced with role-based system
ADMIN_USER_IDS = [
    "c9c972bc-3bf9-46b1-9335-d127b2491356",  # Original admin user
    "test-user-id",  # Development user
    "admin-user-123",  # Current authenticated user
    "bf5b8a8b-3ceb-4279-a689-956b80d0513e",  # Current workspace user
    "test-admin-user-001",  # Current authenticated user from logs
    "test-admin-id"  # Additional authenticated user for documents
]

def check_admin_access(user: AuthorizedUser):
    """Check if user has admin access"""
    if user.sub not in ADMIN_USER_IDS:
        raise HTTPException(status_code=403, detail="Admin access required")
    return True

# Pydantic models
class AdminDocumentResponse(BaseModel):
    id: int
    title: str
    description: Optional[str]
    content: Optional[str] = None  # Add content field for editing
    country_jurisdiction: Optional[List[str]]  # Changed to List[str]
    regulation_type: Optional[List[str]]      # Changed to List[str]
    file_name: str
    file_size: Optional[int]
    tags: List[str]
    uploaded_by: Optional[str]
    created_at: datetime
    updated_at: datetime
    publishing_status: Optional[str] = 'draft'
    published_at: Optional[datetime]
    published_by: Optional[str]
    category_ids: List[int] = []
    subject: Optional[List[str]]               # Changed to List[str]
    document_source_type: Optional[str]
    source_url: Optional[str]
    section_count: int
    # Add missing fields from upload dialog
    issuing_authority: Optional[str]
    publication_date: Optional[date]
    effective_date: Optional[date]
    adoption_date: Optional[date]
    expiration_date: Optional[date]
    next_review_date: Optional[date]
    legal_status: Optional[str]
    version: Optional[str]

class AdminStatsResponse(BaseModel):
    total_documents: int
    published_documents: int
    draft_documents: int
    archived_documents: int
    total_categories: int
    recent_uploads: int  # last 7 days
    total_downloads: int
    active_users: int

class PublishDocumentRequest(BaseModel):
    document_ids: List[int]
    action: str  # "publish", "unpublish", "archive"

class CategoryRequest(BaseModel):
    name: str
    description: Optional[str] = None
    parent_id: Optional[int] = None

class CategoryResponse(BaseModel):
    id: int
    name: str
    description: Optional[str]
    parent_id: Optional[int]
    document_count: int

class UpdateDocumentStatusRequest(BaseModel):
    status: str  # "draft", "published", "archived"
    notes: Optional[str] = None

class MetadataOptionRequest(BaseModel):
    category: str  # jurisdiction, type, subject
    value: str
    display_name: str
    display_order: Optional[int] = 0
    is_active: bool = True

class MetadataOptionResponse(BaseModel):
    id: int
    category: str
    value: str
    display_name: str
    display_order: int
    is_active: bool
    created_at: datetime
    updated_at: datetime

class MetadataOptionUpdate(BaseModel):
    value: Optional[str] = None
    display_name: Optional[str] = None
    display_order: Optional[int] = None
    is_active: Optional[bool] = None

class ReorderRequest(BaseModel):
    category: str
    option_orders: List[Dict[str, Any]]  # [{'id': 1, 'display_order': 1}, ...]

@router.get("/stats", response_model=AdminStatsResponse)
async def get_admin_stats(user: AuthorizedUser):
    """
    Get admin dashboard statistics
    """
    check_admin_access(user)
    
    try:
        conn = await get_db_connection()
        
        # Get document counts by status
        stats_query = """
            SELECT 
                COUNT(*) as total_documents,
                COUNT(CASE WHEN publishing_status = 'published' THEN 1 END) as published_documents,
                COUNT(CASE WHEN publishing_status = 'draft' OR publishing_status IS NULL THEN 1 END) as draft_documents,
                COUNT(CASE WHEN publishing_status = 'archived' THEN 1 END) as archived_documents,
                COUNT(CASE WHEN created_at >= NOW() - INTERVAL '7 days' THEN 1 END) as recent_uploads
            FROM kb_documents
        """
        
        stats_row = await conn.fetchrow(stats_query)
        
        # Get category count
        category_count = await conn.fetchval("SELECT COUNT(*) FROM kb_categories")
        
        await conn.close()
        
        return AdminStatsResponse(
            total_documents=stats_row['total_documents'],
            published_documents=stats_row['published_documents'],
            draft_documents=stats_row['draft_documents'],
            archived_documents=stats_row['archived_documents'],
            total_categories=category_count or 0,
            recent_uploads=stats_row['recent_uploads'],
            total_downloads=0,  # TODO: implement download tracking
            active_users=1  # TODO: implement user activity tracking
        )
        
    except Exception as e:
        print(f"Error getting admin stats: {e}")
        raise HTTPException(status_code=500, detail="Failed to get admin statistics")

@router.get("/documents", response_model=List[AdminDocumentResponse])
async def list_admin_documents(
    user: AuthorizedUser,
    status: Optional[str] = Query(None, description="Filter by publishing status"),
    category_id: Optional[int] = Query(None, description="Filter by category"),
    limit: int = Query(50, description="Number of documents to return"),
    offset: int = Query(0, description="Offset for pagination")
):
    """
    List all documents for admin management
    """
    check_admin_access(user)
    
    try:
        conn = await get_db_connection()
        
        # Build query with filters
        where_conditions = []
        params = []
        param_count = 0
        
        if status:
            param_count += 1
            where_conditions.append(f"publishing_status = ${param_count}")
            params.append(status)
            
        # TODO: Add category filter when category system is implemented
        
        where_clause = " WHERE " + " AND ".join(where_conditions) if where_conditions else ""
        
        query = f"""
            SELECT d.id, d.title, d.description, d.content, d.country_jurisdiction, d.regulation_type,
                   d.file_name, d.file_size, d.tags, d.uploaded_by, d.created_at, d.updated_at,
                   d.publishing_status, d.published_at, d.published_by, d.subject, 
                   d.document_source_type, d.source_url,
                   d.issuing_authority, d.publication_date, d.effective_date, d.adoption_date,
                   d.expiration_date, d.next_review_date, d.legal_status, d.version,
                   COALESCE(COUNT(s.id), 0) as section_count
            FROM kb_documents d
            LEFT JOIN document_sections s ON CAST(d.id AS varchar) = s.document_id
            {where_clause}
            GROUP BY d.id, d.title, d.description, d.content, d.country_jurisdiction, d.regulation_type,
                     d.file_name, d.file_size, d.tags, d.uploaded_by, d.created_at, d.updated_at,
                     d.publishing_status, d.published_at, d.published_by, d.subject,
                     d.document_source_type, d.source_url, d.issuing_authority, d.publication_date, 
                     d.effective_date, d.adoption_date, d.expiration_date, d.next_review_date, 
                     d.legal_status, d.version
            ORDER BY d.created_at DESC
            LIMIT ${param_count + 1} OFFSET ${param_count + 2}
        """
        
        params.extend([limit, offset])
        
        rows = await conn.fetch(query, *params)
        await conn.close()
        
        documents = []
        for row in rows:
            documents.append(AdminDocumentResponse(
                id=row['id'],
                title=row['title'],
                description=row['description'],
                content=row['content'],  # Add content field
                country_jurisdiction=row['country_jurisdiction'],
                regulation_type=row['regulation_type'],
                file_name=row['file_name'],
                file_size=row['file_size'],
                tags=row['tags'] or [],
                uploaded_by=row['uploaded_by'],
                created_at=row['created_at'],
                updated_at=row['updated_at'],
                publishing_status=row['publishing_status'] or 'draft',
                published_at=row['published_at'],
                published_by=row['published_by'],
                category_ids=[],  # TODO: implement category associations
                subject=row['subject'],
                document_source_type=row['document_source_type'],
                source_url=row['source_url'],
                section_count=row['section_count'],
                # Add missing fields from upload dialog
                issuing_authority=row['issuing_authority'],
                publication_date=row['publication_date'],
                effective_date=row['effective_date'],
                adoption_date=row['adoption_date'],
                expiration_date=row['expiration_date'],
                next_review_date=row['next_review_date'],
                legal_status=row['legal_status'],
                version=row['version']
            ))
            
        return documents
        
    except Exception as e:
        print(f"Error listing admin documents: {e}")
        raise HTTPException(status_code=500, detail="Failed to list documents")

@router.put("/documents/{document_id}/status", response_model=Dict[str, Any])
async def update_document_status(
    document_id: int,
    request: UpdateDocumentStatusRequest,
    user: AuthorizedUser
):
    """
    Update the publishing status of a document
    """
    check_admin_access(user)
    
    try:
        conn = await get_db_connection()
        
        # Validate status
        valid_statuses = ['draft', 'published', 'archived', 'pending_validation', 'rejected']
        if request.status not in valid_statuses:
            raise HTTPException(status_code=400, detail=f"Invalid status. Must be one of: {valid_statuses}")
        
        # Update document status
        update_query = """
            UPDATE kb_documents 
            SET publishing_status = $1::character varying(20),
                published_at = CASE WHEN $1 = 'published' THEN NOW() ELSE published_at END,
                published_by = CASE WHEN $1 = 'published' THEN $3 ELSE published_by END,
                updated_at = NOW()
            WHERE id = $2
        """
        
        result = await conn.execute(update_query, request.status, document_id, user.sub)
        await conn.close()
        
        if result == "UPDATE 0":
            raise HTTPException(status_code=404, detail="Document not found")
            
        return {
            "success": True,
            "message": f"Document status updated to {request.status}",
            "document_id": document_id,
            "new_status": request.status
        }
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error updating document status: {e}")
        raise HTTPException(status_code=500, detail="Failed to update document status")

@router.post("/documents/publish", response_model=Dict[str, Any])
async def publish_document(
    request: PublishDocumentRequest,
    user: AuthorizedUser
):
    """
    Bulk publish/unpublish documents
    """
    check_admin_access(user)
    
    try:
        conn = await get_db_connection()
        
        valid_actions = ['publish', 'unpublish', 'archive']
        if request.action not in valid_actions:
            raise HTTPException(status_code=400, detail=f"Invalid action. Must be one of: {valid_actions}")
        
        # Map action to status
        status_mapping = {
            'publish': 'published',
            'unpublish': 'draft',
            'archive': 'archived'
        }
        new_status = status_mapping[request.action]
        
        # If publishing documents, check for alert generation and create alerts
        created_alerts = []
        if request.action == 'publish':
            # Get documents that need alerts generated
            alert_docs_query = """
                SELECT id, title, description, generate_alert_type, alert_severity, 
                       alert_jurisdictions, alert_expiration_date
                FROM kb_documents 
                WHERE id = ANY($1::int[]) 
                  AND generate_alert_type IS NOT NULL 
                  AND generate_alert_type != 'none'
            """
            
            alert_docs = await conn.fetch(alert_docs_query, request.document_ids)
            
            # Create alerts for each document that has alert generation enabled
            for doc in alert_docs:
                try:
                    # Create the alert
                    alert_insert_query = """
                        INSERT INTO document_alerts (
                            document_id, alert_type, title, description, severity, 
                            jurisdictions, status, created_by, expires_at
                        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
                        RETURNING id
                    """
                    
                    # Generate alert title and description
                    alert_title = f"New {doc['generate_alert_type'].replace('_', ' ').title()}: {doc['title']}"
                    alert_description = doc['description'] or f"Document '{doc['title']}' has been published and requires attention."
                    
                    alert_id = await conn.fetchval(
                        alert_insert_query,
                        doc['id'],                                    # document_id
                        doc['generate_alert_type'],                   # alert_type
                        alert_title,                                  # title
                        alert_description,                            # description
                        doc['alert_severity'] or 'medium',           # severity
                        doc['alert_jurisdictions'] or [],            # jurisdictions
                        'new',                                        # status
                        user.sub,                                     # created_by
                        doc['alert_expiration_date']                 # expires_at
                    )
                    
                    created_alerts.append({
                        'alert_id': alert_id,
                        'document_id': doc['id'],
                        'alert_type': doc['generate_alert_type'],
                        'title': alert_title
                    })
                    
                    print(f"📢 Created alert {alert_id} for document {doc['id']} ({doc['generate_alert_type']})")
                    
                except Exception as alert_error:
                    print(f"❌ Failed to create alert for document {doc['id']}: {alert_error}")
                    # Continue with other documents even if one alert fails
        
        # Update documents
        update_query = """
            UPDATE kb_documents 
            SET publishing_status = $1::character varying(20),
                published_at = CASE WHEN $1 = 'published' THEN NOW() ELSE published_at END,
                published_by = CASE WHEN $1 = 'published' THEN $2 ELSE published_by END,
                updated_at = NOW()
            WHERE id = ANY($3::int[])
        """
        
        result = await conn.execute(update_query, new_status, user.sub, request.document_ids)
        await conn.close()
        
        response_data = {
            "success": True,
            "message": f"Successfully {request.action}ed {len(request.document_ids)} documents",
            "action": request.action,
            "document_ids": request.document_ids,
            "new_status": new_status
        }
        
        # Include alert information in response if alerts were created
        if created_alerts:
            response_data["alerts_created"] = created_alerts
            response_data["message"] += f" and created {len(created_alerts)} alerts"
        
        return response_data
        
    except Exception as e:
        print(f"Error bulk updating documents: {e}")
        raise HTTPException(status_code=500, detail="Failed to update documents")

@router.post("/documents/bulk-status", response_model=Dict[str, Any])
async def bulk_update_status(
    document_ids: List[int],
    status: str,
    user: AuthorizedUser
):
    """
    Bulk update document statuses
    """
    check_admin_access(user)
    
    try:
        conn = await get_db_connection()
        
        valid_statuses = ['draft', 'published', 'archived', 'pending_validation', 'rejected']
        if status not in valid_statuses:
            raise HTTPException(status_code=400, detail=f"Invalid status. Must be one of: {valid_statuses}")
        
        update_query = """
            UPDATE kb_documents 
            SET publishing_status = $1::character varying(20),
                published_at = CASE WHEN $1 = 'published' THEN NOW() ELSE published_at END,
                published_by = CASE WHEN $1 = 'published' THEN $2 ELSE published_by END,
                updated_at = NOW()
            WHERE id = ANY($3::int[])
        """
        
        result = await conn.execute(update_query, status, user.sub, document_ids)
        await conn.close()
        
        return {
            "success": True,
            "message": f"Successfully updated {len(document_ids)} documents to {status}",
            "updated_count": len(document_ids),
            "new_status": status
        }
        
    except Exception as e:
        print(f"Error bulk updating document status: {e}")
        raise HTTPException(status_code=500, detail="Failed to bulk update documents")

# Category management endpoints
@router.post("/categories", response_model=CategoryResponse)
async def create_category(
    request: CategoryRequest,
    user: AuthorizedUser
):
    """
    Create a new category
    """
    check_admin_access(user)
    
    try:
        conn = await get_db_connection()
        
        # Insert new category directly into existing table
        category_id = await conn.fetchval(
            """
            INSERT INTO kb_categories (name, description, parent_id, created_at)
            VALUES ($1, $2, $3, NOW())
            RETURNING id
            """,
            request.name, request.description, request.parent_id
        )
        
        await conn.close()
        
        return CategoryResponse(
            id=category_id,
            name=request.name,
            description=request.description,
            parent_id=request.parent_id,
            document_count=0
        )
        
    except Exception as e:
        print(f"Error creating category: {e}")
        raise HTTPException(status_code=500, detail="Failed to create category")

@router.put("/categories/{category_id}", response_model=CategoryResponse)
async def update_category(
    category_id: int,
    request: CategoryRequest,
    user: AuthorizedUser
):
    """
    Update a category
    """
    check_admin_access(user)
    
    try:
        conn = await get_db_connection()
        
        # Update category
        result = await conn.execute(
            """
            UPDATE kb_categories 
            SET name = $1, description = $2, parent_id = $3, updated_at = NOW()
            WHERE id = $4
            """,
            request.name, request.description, request.parent_id, category_id
        )
        
        if result == "UPDATE 0":
            await conn.close()
            raise HTTPException(status_code=404, detail="Category not found")
        
        # Get document count for this category
        doc_count = await conn.fetchval(
            "SELECT COUNT(*) FROM kb_documents WHERE $1 = ANY(COALESCE(category_ids, '{}'))",
            category_id
        ) or 0
        
        await conn.close()
        
        return CategoryResponse(
            id=category_id,
            name=request.name,
            description=request.description,
            parent_id=request.parent_id,
            document_count=doc_count
        )
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error updating category: {e}")
        raise HTTPException(status_code=500, detail="Failed to update category")

@router.delete("/categories/{category_id}", response_model=Dict[str, Any])
async def delete_category(
    category_id: int,
    user: AuthorizedUser
):
    """
    Delete a category
    """
    check_admin_access(user)
    
    try:
        conn = await get_db_connection()
        
        # Check if category has documents
        doc_count = await conn.fetchval(
            "SELECT COUNT(*) FROM kb_documents WHERE $1 = ANY(COALESCE(category_ids, '{}'))",
            category_id
        ) or 0
        
        if doc_count > 0:
            await conn.close()
            raise HTTPException(
                status_code=400, 
                detail=f"Cannot delete category with {doc_count} documents. Move documents first."
            )
        
        # Delete category
        result = await conn.execute(
            "DELETE FROM kb_categories WHERE id = $1",
            category_id
        )
        
        await conn.close()
        
        if result == "DELETE 0":
            raise HTTPException(status_code=404, detail="Category not found")
            
        return {
            "success": True,
            "message": "Category deleted successfully",
            "category_id": category_id
        }
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error deleting category: {e}")
        raise HTTPException(status_code=500, detail="Failed to delete category")

# Metadata options management endpoints
@router.get("/metadata-options/{category}", response_model=List[MetadataOptionResponse])
async def get_metadata_options(
    category: str,
    user: AuthorizedUser,
    active_only: bool = Query(True, description="Only return active options")
):
    """
    Get metadata options for a specific category (jurisdiction, type, subject)
    """
    if category not in ['jurisdiction', 'type', 'subject']:
        raise HTTPException(status_code=400, detail="Invalid category. Must be jurisdiction, type, or subject")
    
    try:
        conn = await get_db_connection()
        
        where_clause = "WHERE category = $1"
        params = [category]
        
        if active_only:
            where_clause += " AND is_active = true"
        
        query = f"""
            SELECT id, category, value, display_name, display_order, is_active, created_at, updated_at
            FROM document_metadata_options
            {where_clause}
            ORDER BY display_order ASC, display_name ASC
        """
        
        rows = await conn.fetch(query, *params)
        await conn.close()
        
        options = []
        for row in rows:
            options.append(MetadataOptionResponse(
                id=row['id'],
                category=row['category'],
                value=row['value'],
                display_name=row['display_name'],
                display_order=row['display_order'],
                is_active=row['is_active'],
                created_at=row['created_at'],
                updated_at=row['updated_at']
            ))
        
        return options
        
    except Exception as e:
        print(f"Error getting metadata options: {e}")
        raise HTTPException(status_code=500, detail="Failed to get metadata options")

@router.post("/metadata-options", response_model=MetadataOptionResponse)
async def create_metadata_option(
    request: MetadataOptionRequest,
    user: AuthorizedUser
):
    """
    Create a new metadata option
    """
    check_admin_access(user)
    
    if request.category not in ['jurisdiction', 'type', 'subject']:
        raise HTTPException(status_code=400, detail="Invalid category. Must be: jurisdiction, type, or subject")
    
    try:
        conn = await get_db_connection()
        
        # Check for duplicate value in same category
        existing = await conn.fetchval(
            "SELECT id FROM document_metadata_options WHERE category = $1 AND value = $2",
            request.category, request.value
        )
        
        if existing:
            await conn.close()
            raise HTTPException(status_code=400, detail=f"Option '{request.value}' already exists in {request.category}")
        
        # Insert new option
        option_id = await conn.fetchval(
            """
            INSERT INTO document_metadata_options 
            (category, value, display_name, display_order, is_active)
            VALUES ($1, $2, $3, $4, $5)
            RETURNING id
            """,
            request.category, request.value, request.display_name, 
            request.display_order, request.is_active
        )
        
        # Get the created option
        option_row = await conn.fetchrow(
            "SELECT * FROM document_metadata_options WHERE id = $1",
            option_id
        )
        
        await conn.close()
        
        return MetadataOptionResponse(
            id=option_row['id'],
            category=option_row['category'],
            value=option_row['value'],
            display_name=option_row['display_name'],
            display_order=option_row['display_order'],
            is_active=option_row['is_active'],
            created_at=option_row['created_at'],
            updated_at=option_row['updated_at']
        )
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error creating metadata option: {e}")
        raise HTTPException(status_code=500, detail="Failed to create metadata option")

@router.put("/metadata-options/{option_id}", response_model=MetadataOptionResponse)
async def update_metadata_option(
    option_id: int,
    request: MetadataOptionUpdate,
    user: AuthorizedUser
):
    """
    Update a metadata option
    """
    check_admin_access(user)
    
    try:
        conn = await get_db_connection()
        
        # Get current option
        current = await conn.fetchrow(
            "SELECT * FROM document_metadata_options WHERE id = $1",
            option_id
        )
        
        if not current:
            await conn.close()
            raise HTTPException(status_code=404, detail="Metadata option not found")
        
        # Build update query dynamically
        updates = []
        params = []
        param_count = 0
        
        if request.value is not None:
            param_count += 1
            updates.append(f"value = ${param_count}")
            params.append(request.value)
        
        if request.display_name is not None:
            param_count += 1
            updates.append(f"display_name = ${param_count}")
            params.append(request.display_name)
        
        if request.display_order is not None:
            param_count += 1
            updates.append(f"display_order = ${param_count}")
            params.append(request.display_order)
        
        if request.is_active is not None:
            param_count += 1
            updates.append(f"is_active = ${param_count}")
            params.append(request.is_active)
        
        if not updates:
            await conn.close()
            raise HTTPException(status_code=400, detail="No fields to update")
        
        param_count += 1
        updates.append(f"updated_at = NOW()")
        params.append(option_id)
        
        query = f"""
            UPDATE document_metadata_options 
            SET {', '.join(updates)}
            WHERE id = ${param_count}
        """
        
        await conn.execute(query, *params)
        
        # Get updated option
        updated_row = await conn.fetchrow(
            "SELECT * FROM document_metadata_options WHERE id = $1",
            option_id
        )
        
        await conn.close()
        
        return MetadataOptionResponse(
            id=updated_row['id'],
            category=updated_row['category'],
            value=updated_row['value'],
            display_name=updated_row['display_name'],
            display_order=updated_row['display_order'],
            is_active=updated_row['is_active'],
            created_at=updated_row['created_at'],
            updated_at=updated_row['updated_at']
        )
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error updating metadata option: {e}")
        raise HTTPException(status_code=500, detail="Failed to update metadata option")

@router.delete("/metadata-options/{option_id}", response_model=Dict[str, Any])
async def delete_metadata_option(
    option_id: int,
    user: AuthorizedUser
):
    """
    Delete a metadata option
    """
    check_admin_access(user)
    
    try:
        conn = await get_db_connection()
        
        # Get option details before deletion
        option = await conn.fetchrow(
            "SELECT category, value FROM document_metadata_options WHERE id = $1",
            option_id
        )
        
        if not option:
            await conn.close()
            raise HTTPException(status_code=404, detail="Metadata option not found")
        
        # Check if option is being used in documents
        usage_count = 0
        if option['category'] == 'jurisdiction':
            usage_count = await conn.fetchval(
                "SELECT COUNT(*) FROM kb_documents WHERE country_jurisdiction = $1",
                option['value']
            ) or 0
        elif option['category'] == 'type':
            usage_count = await conn.fetchval(
                "SELECT COUNT(*) FROM kb_documents WHERE regulation_type = $1",
                option['value']
            ) or 0
        elif option['category'] == 'subject':
            usage_count = await conn.fetchval(
                "SELECT COUNT(*) FROM kb_documents WHERE subject = $1",
                option['value']
            ) or 0
        
        if usage_count > 0:
            await conn.close()
            raise HTTPException(
                status_code=400, 
                detail=f"Cannot delete option '{option['value']}' - it is used by {usage_count} documents"
            )
        
        # Delete the option
        result = await conn.execute(
            "DELETE FROM document_metadata_options WHERE id = $1",
            option_id
        )
        
        await conn.close()
        
        if result == "DELETE 0":
            raise HTTPException(status_code=404, detail="Metadata option not found")
        
        return {
            "success": True,
            "message": f"Metadata option '{option['value']}' deleted successfully",
            "option_id": option_id
        }
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error deleting metadata option: {e}")
        raise HTTPException(status_code=500, detail="Failed to delete metadata option")

@router.put("/metadata-options/reorder", response_model=Dict[str, Any])
async def reorder_metadata_options(
    request: ReorderRequest,
    user: AuthorizedUser
):
    """
    Reorder metadata options within a category
    """
    check_admin_access(user)
    
    if request.category not in ['jurisdiction', 'type', 'subject']:
        raise HTTPException(status_code=400, detail="Invalid category. Must be: jurisdiction, type, or subject")
    
    try:
        conn = await get_db_connection()
        
        # Update display orders in a transaction
        await conn.execute("BEGIN")
        
        for item in request.option_orders:
            await conn.execute(
                "UPDATE document_metadata_options SET display_order = $1, updated_at = NOW() WHERE id = $2 AND category = $3",
                item['display_order'], item['id'], request.category
            )
        
        await conn.execute("COMMIT")
        await conn.close()
        
        return {
            "success": True,
            "message": f"Successfully reordered {len(request.option_orders)} {request.category} options",
            "category": request.category,
            "updated_count": len(request.option_orders)
        }
        
    except Exception as e:
        await conn.execute("ROLLBACK")
        await conn.close()
        print(f"Error reordering metadata options: {e}")
        raise HTTPException(status_code=500, detail="Failed to reorder metadata options")
