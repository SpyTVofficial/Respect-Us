from fastapi import APIRouter, HTTPException, BackgroundTasks
from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
from datetime import datetime, timezone, timedelta
import asyncpg
import databutton as db
from app.auth import AuthorizedUser
from app.env import Mode, mode
import json
import asyncio

router = APIRouter(prefix="/background-monitoring")

# Database connection helper
async def get_db_connection():
    if mode == Mode.PROD:
        database_url = db.secrets.get("DATABASE_URL_PROD")
    else:
        database_url = db.secrets.get("DATABASE_URL_DEV")
    return await asyncpg.connect(database_url)

# Pydantic Models
class MonitoringConfiguration(BaseModel):
    id: Optional[int] = None
    user_id: str
    enabled: bool = True
    high_risk_monitoring: bool = True
    medium_risk_monitoring: bool = False
    monitoring_frequency_hours: int = Field(default=24, description="How often to check high-risk customers")
    auto_rescreening: bool = True
    alert_threshold_changes: bool = True
    risk_escalation_enabled: bool = True
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

class CustomerMonitoringStatus(BaseModel):
    customer_id: str
    customer_name: str
    risk_level: str
    last_monitored: Optional[datetime]
    next_monitoring: Optional[datetime]
    monitoring_active: bool
    recent_changes: List[Dict[str, Any]] = Field(default_factory=list)
    alert_count: int = 0
    last_screening_result: Optional[Dict[str, Any]] = None

class MonitoringReport(BaseModel):
    total_monitored_customers: int
    high_risk_customers: int
    customers_requiring_attention: int
    last_monitoring_cycle: Optional[datetime]
    next_monitoring_cycle: Optional[datetime]
    recent_alerts_generated: int
    monitoring_efficiency: float
    customer_statuses: List[CustomerMonitoringStatus]

class BackgroundJobStatus(BaseModel):
    job_id: int
    job_type: str
    customer_id: Optional[str]
    status: str
    started_at: datetime
    completed_at: Optional[datetime]
    result: Optional[Dict[str, Any]]
    error_message: Optional[str]

class TriggerMonitoringRequest(BaseModel):
    customer_ids: Optional[List[str]] = None
    risk_levels: Optional[List[str]] = None
    force_all: bool = False

# Background monitoring logic
async def perform_customer_risk_assessment(customer_id: str, user_id: str) -> Dict[str, Any]:
    """Perform automated risk assessment for a customer"""
    conn = await get_db_connection()
    try:
        # Get customer details
        customer = await conn.fetchrow(
            "SELECT * FROM customer_profiles WHERE id = $1 AND created_by = $2",
            customer_id, user_id
        )
        
        if not customer:
            return {"error": "Customer not found"}
        
        # Simulate risk assessment logic (in real implementation, this would call actual screening APIs)
        risk_factors = {
            "sanctions_check": "clean",  # clean, match, potential_match
            "pep_status": "not_pep",     # pep, not_pep, unknown
            "adverse_media": "none",     # none, minor, significant
            "geographic_risk": "low",   # low, medium, high
            "business_sector_risk": "medium"  # low, medium, high
        }
        
        # Calculate risk score (simplified algorithm)
        risk_score = 0
        
        if risk_factors["sanctions_check"] == "match":
            risk_score += 50
        elif risk_factors["sanctions_check"] == "potential_match":
            risk_score += 25
            
        if risk_factors["pep_status"] == "pep":
            risk_score += 30
            
        if risk_factors["adverse_media"] == "significant":
            risk_score += 20
        elif risk_factors["adverse_media"] == "minor":
            risk_score += 10
            
        if risk_factors["geographic_risk"] == "high":
            risk_score += 15
        elif risk_factors["geographic_risk"] == "medium":
            risk_score += 8
            
        if risk_factors["business_sector_risk"] == "high":
            risk_score += 10
        elif risk_factors["business_sector_risk"] == "medium":
            risk_score += 5
        
        # Determine risk level
        if risk_score >= 70:
            new_risk_level = "high"
        elif risk_score >= 40:
            new_risk_level = "medium"
        else:
            new_risk_level = "low"
        
        # Check if risk level changed
        current_risk_level = customer.get('risk_level', 'low')
        risk_changed = current_risk_level != new_risk_level
        
        # Update customer risk level if changed
        if risk_changed:
            await conn.execute(
                "UPDATE customer_profiles SET risk_level = $1, updated_at = $2 WHERE id = $3",
                new_risk_level, datetime.now(timezone.utc), customer_id
            )
        
        # Log the monitoring activity
        await conn.execute(
            """
            INSERT INTO customer_monitoring_logs (
                customer_id, user_id, monitoring_type, risk_score, 
                risk_level, risk_factors, risk_changed, monitored_at
            ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
            """,
            customer_id, user_id, "automated_assessment", risk_score,
            new_risk_level, json.dumps(risk_factors), risk_changed,
            datetime.now(timezone.utc)
        )
        
        return {
            "customer_id": customer_id,
            "previous_risk_level": current_risk_level,
            "new_risk_level": new_risk_level,
            "risk_score": risk_score,
            "risk_factors": risk_factors,
            "risk_changed": risk_changed,
            "assessment_time": datetime.now(timezone.utc).isoformat()
        }
        
    except Exception as e:
        print(f"Error in risk assessment for customer {customer_id}: {e}")
        return {"error": str(e)}
    finally:
        await conn.close()

async def trigger_alert_for_risk_change(customer_id: str, user_id: str, assessment_result: Dict[str, Any]):
    """Trigger alert when customer risk level changes"""
    if not assessment_result.get("risk_changed"):
        return
    
    conn = await get_db_connection()
    try:
        # Get customer name
        customer = await conn.fetchrow(
            "SELECT customer_name FROM customer_profiles WHERE id = $1",
            customer_id
        )
        
        customer_name = customer['customer_name'] if customer else f"Customer {customer_id}"
        
        # Determine alert severity based on risk change
        prev_risk = assessment_result["previous_risk_level"]
        new_risk = assessment_result["new_risk_level"]
        
        if new_risk == "high":
            severity = "critical"
            alert_type = "high_risk_escalation"
        elif new_risk == "medium" and prev_risk == "low":
            severity = "medium"
            alert_type = "risk_escalation"
        elif new_risk == "low" and prev_risk in ["medium", "high"]:
            severity = "low"
            alert_type = "risk_reduction"
        else:
            severity = "medium"
            alert_type = "risk_change"
        
        # Create alert
        await conn.execute(
            """
            INSERT INTO alerts (
                user_id, alert_type, title, message, severity,
                entity_type, entity_id, metadata, status, created_at
            ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
            """,
            user_id, alert_type,
            f"Risk Level Change: {customer_name}",
            f"Customer {customer_name} risk level changed from {prev_risk} to {new_risk}. Risk score: {assessment_result['risk_score']}",
            severity, "customer", customer_id,
            json.dumps({
                "assessment_result": assessment_result,
                "monitoring_type": "automated_background"
            }),
            "pending", datetime.now(timezone.utc)
        )
        
        print(f"Alert created for customer {customer_name}: {prev_risk} -> {new_risk}")
        
    except Exception as e:
        print(f"Error creating alert for customer {customer_id}: {e}")
    finally:
        await conn.close()

async def run_monitoring_cycle(user_id: str) -> Dict[str, Any]:
    """Run a complete monitoring cycle for a user's high-risk customers"""
    conn = await get_db_connection()
    try:
        # Get monitoring configuration
        config = await conn.fetchrow(
            "SELECT * FROM monitoring_configurations WHERE user_id = $1",
            user_id
        )
        
        if not config or not config['enabled']:
            return {"message": "Monitoring disabled for user", "customers_processed": 0}
        
        # Get customers that need monitoring
        risk_conditions = []
        if config['high_risk_monitoring']:
            risk_conditions.append("'high'")
        if config['medium_risk_monitoring']:
            risk_conditions.append("'medium'")
        
        if not risk_conditions:
            return {"message": "No risk levels configured for monitoring", "customers_processed": 0}
        
        # Find customers that haven't been monitored recently
        monitoring_threshold = datetime.now(timezone.utc) - timedelta(hours=config['monitoring_frequency_hours'])
        
        customers_to_monitor = await conn.fetch(
            f"""
            SELECT cp.id, cp.customer_name, cp.risk_level
            FROM customer_profiles cp
            LEFT JOIN customer_monitoring_logs cml ON cp.id = cml.customer_id 
                AND cml.monitored_at > $2
            WHERE cp.created_by = $1 
                AND cp.risk_level IN ({','.join(risk_conditions)})
                AND cml.id IS NULL
            ORDER BY cp.risk_level DESC, cp.updated_at ASC
            LIMIT 50
            """,
            user_id, monitoring_threshold
        )
        
        results = []
        alerts_created = 0
        
        for customer in customers_to_monitor:
            print(f"Processing customer: {customer['customer_name']} (Risk: {customer['risk_level']})")
            
            # Perform risk assessment
            assessment = await perform_customer_risk_assessment(customer['id'], user_id)
            
            if not assessment.get("error"):
                results.append(assessment)
                
                # Create alert if risk changed
                if assessment.get("risk_changed"):
                    await trigger_alert_for_risk_change(customer['id'], user_id, assessment)
                    alerts_created += 1
            else:
                print(f"Error assessing customer {customer['id']}: {assessment['error']}")
        
        # Update last monitoring cycle time
        await conn.execute(
            """
            UPDATE monitoring_configurations 
            SET last_monitoring_cycle = $2 
            WHERE user_id = $1
            """,
            user_id, datetime.now(timezone.utc)
        )
        
        return {
            "customers_processed": len(results),
            "alerts_created": alerts_created,
            "cycle_completed_at": datetime.now(timezone.utc).isoformat(),
            "results": results
        }
        
    except Exception as e:
        print(f"Error in monitoring cycle for user {user_id}: {e}")
        return {"error": str(e)}
    finally:
        await conn.close()

# API Endpoints
@router.get("/configuration", response_model=MonitoringConfiguration)
async def get_monitoring_configuration(user: AuthorizedUser):
    """Get current monitoring configuration for the user"""
    conn = await get_db_connection()
    try:
        config = await conn.fetchrow(
            "SELECT * FROM monitoring_configurations WHERE user_id = $1",
            user.sub
        )
        
        if config:
            return MonitoringConfiguration(
                id=config['id'],
                user_id=config['user_id'],
                enabled=config['enabled'],
                high_risk_monitoring=config['high_risk_monitoring'],
                medium_risk_monitoring=config['medium_risk_monitoring'],
                monitoring_frequency_hours=config['monitoring_frequency_hours'],
                auto_rescreening=config['auto_rescreening'],
                alert_threshold_changes=config['alert_threshold_changes'],
                risk_escalation_enabled=config['risk_escalation_enabled'],
                created_at=config['created_at'],
                updated_at=config['updated_at']
            )
        else:
            # Return default configuration
            return MonitoringConfiguration(
                user_id=user.sub,
                enabled=True,
                high_risk_monitoring=True,
                medium_risk_monitoring=False,
                monitoring_frequency_hours=24,
                auto_rescreening=True,
                alert_threshold_changes=True,
                risk_escalation_enabled=True
            )
        
    finally:
        await conn.close()

@router.post("/configuration")
async def save_monitoring_configuration(
    config: MonitoringConfiguration,
    user: AuthorizedUser
):
    """Save monitoring configuration"""
    conn = await get_db_connection()
    try:
        # Upsert configuration
        await conn.execute(
            """
            INSERT INTO monitoring_configurations (
                user_id, enabled, high_risk_monitoring, medium_risk_monitoring,
                monitoring_frequency_hours, auto_rescreening, alert_threshold_changes,
                risk_escalation_enabled, created_at, updated_at
            ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
            ON CONFLICT (user_id) DO UPDATE SET
                enabled = EXCLUDED.enabled,
                high_risk_monitoring = EXCLUDED.high_risk_monitoring,
                medium_risk_monitoring = EXCLUDED.medium_risk_monitoring,
                monitoring_frequency_hours = EXCLUDED.monitoring_frequency_hours,
                auto_rescreening = EXCLUDED.auto_rescreening,
                alert_threshold_changes = EXCLUDED.alert_threshold_changes,
                risk_escalation_enabled = EXCLUDED.risk_escalation_enabled,
                updated_at = EXCLUDED.updated_at
            """,
            user.sub, config.enabled, config.high_risk_monitoring,
            config.medium_risk_monitoring, config.monitoring_frequency_hours,
            config.auto_rescreening, config.alert_threshold_changes,
            config.risk_escalation_enabled, datetime.now(timezone.utc), datetime.now(timezone.utc)
        )
        
        return {"message": "Monitoring configuration saved successfully"}
        
    finally:
        await conn.close()

@router.get("/status", response_model=MonitoringReport)
async def get_monitoring_status(user: AuthorizedUser):
    """Get current monitoring status and report"""
    conn = await get_db_connection()
    try:
        # Get configuration
        config = await conn.fetchrow(
            "SELECT * FROM monitoring_configurations WHERE user_id = $1",
            user.sub
        )
        
        # Get customer counts
        total_customers = await conn.fetchval(
            "SELECT COUNT(*) FROM customer_profiles WHERE created_by = $1",
            user.sub
        ) or 0
        
        high_risk_customers = await conn.fetchval(
            "SELECT COUNT(*) FROM customer_profiles WHERE created_by = $1 AND risk_level = 'high'",
            user.sub
        ) or 0
        
        # Get customers requiring attention (monitored in last cycle with changes)
        attention_required = await conn.fetchval(
            """
            SELECT COUNT(DISTINCT cml.customer_id)
            FROM customer_monitoring_logs cml
            JOIN customer_profiles cp ON cml.customer_id = cp.id
            WHERE cp.created_by = $1 
                AND cml.risk_changed = true 
                AND cml.monitored_at >= NOW() - INTERVAL '24 hours'
            """,
            user.sub
        ) or 0
        
        # Get recent alerts
        recent_alerts = await conn.fetchval(
            """
            SELECT COUNT(*) FROM alerts 
            WHERE user_id = $1 
                AND alert_type IN ('high_risk_escalation', 'risk_escalation', 'risk_change')
                AND created_at >= NOW() - INTERVAL '24 hours'
            """,
            user.sub
        ) or 0
        
        # Get customer statuses
        customer_statuses_data = await conn.fetch(
            """
            SELECT 
                cp.id, cp.customer_name, cp.risk_level,
                cml.monitored_at as last_monitored,
                cml.risk_score, cml.risk_factors,
                (SELECT COUNT(*) FROM alerts WHERE entity_id = cp.id AND created_at >= NOW() - INTERVAL '7 days') as alert_count
            FROM customer_profiles cp
            LEFT JOIN LATERAL (
                SELECT * FROM customer_monitoring_logs 
                WHERE customer_id = cp.id 
                ORDER BY monitored_at DESC 
                LIMIT 1
            ) cml ON true
            WHERE cp.created_by = $1 
                AND cp.risk_level IN ('high', 'medium')
            ORDER BY cp.risk_level DESC, cml.monitored_at ASC
            LIMIT 20
            """,
            user.sub
        )
        
        # Calculate next monitoring cycle
        monitoring_frequency = config['monitoring_frequency_hours'] if config else 24
        last_cycle = config['last_monitoring_cycle'] if config else None
        next_cycle = last_cycle + timedelta(hours=monitoring_frequency) if last_cycle else datetime.now(timezone.utc)
        
        # Calculate monitoring efficiency
        monitored_recently = await conn.fetchval(
            f"""
            SELECT COUNT(DISTINCT customer_id)
            FROM customer_monitoring_logs
            WHERE user_id = $1 AND monitored_at >= NOW() - INTERVAL '{monitoring_frequency} hours'
            """,
            user.sub
        ) or 0
        
        efficiency = (monitored_recently / max(high_risk_customers, 1)) * 100 if high_risk_customers > 0 else 100
        
        customer_statuses = [
            CustomerMonitoringStatus(
                customer_id=row['id'],
                customer_name=row['customer_name'],
                risk_level=row['risk_level'],
                last_monitored=row['last_monitored'],
                next_monitoring=row['last_monitored'] + timedelta(hours=monitoring_frequency) if row['last_monitored'] else datetime.now(timezone.utc),
                monitoring_active=config and config['enabled'] if config else False,
                recent_changes=[],  # Could be populated with recent changes
                alert_count=row['alert_count'],
                last_screening_result={
                    "risk_score": row['risk_score'],
                    "risk_factors": row['risk_factors']
                } if row['risk_score'] is not None else None
            )
            for row in customer_statuses_data
        ]
        
        return MonitoringReport(
            total_monitored_customers=total_customers,
            high_risk_customers=high_risk_customers,
            customers_requiring_attention=attention_required,
            last_monitoring_cycle=last_cycle,
            next_monitoring_cycle=next_cycle,
            recent_alerts_generated=recent_alerts,
            monitoring_efficiency=round(efficiency, 1),
            customer_statuses=customer_statuses
        )
        
    finally:
        await conn.close()

@router.post("/trigger")
async def trigger_monitoring(
    request: TriggerMonitoringRequest,
    user: AuthorizedUser,
    background_tasks: BackgroundTasks
):
    """Manually trigger monitoring for specific customers or all"""
    if request.force_all:
        # Trigger full monitoring cycle
        background_tasks.add_task(run_monitoring_cycle, user.sub)
        return {"message": "Full monitoring cycle triggered"}
    
    conn = await get_db_connection()
    try:
        customers_to_process = []
        
        if request.customer_ids:
            # Process specific customers
            customers_data = await conn.fetch(
                "SELECT id, customer_name FROM customer_profiles WHERE id = ANY($1) AND created_by = $2",
                request.customer_ids, user.sub
            )
            customers_to_process = [row['id'] for row in customers_data]
            
        elif request.risk_levels:
            # Process customers by risk level
            customers_data = await conn.fetch(
                "SELECT id FROM customer_profiles WHERE risk_level = ANY($1) AND created_by = $2",
                request.risk_levels, user.sub
            )
            customers_to_process = [row['id'] for row in customers_data]
        
        if not customers_to_process:
            return {"message": "No customers found to monitor", "customers_processed": 0}
        
        # Process each customer in background
        for customer_id in customers_to_process:
            background_tasks.add_task(
                perform_customer_risk_assessment,
                customer_id, user.sub
            )
        
        return {
            "message": f"Monitoring triggered for {len(customers_to_process)} customers",
            "customers_processed": len(customers_to_process)
        }
        
    finally:
        await conn.close()

@router.get("/jobs", response_model=List[BackgroundJobStatus])
async def get_background_jobs(user: AuthorizedUser, limit: int = 20):
    """Get recent background monitoring job statuses"""
    conn = await get_db_connection()
    try:
        jobs_data = await conn.fetch(
            """
            SELECT * FROM automation_jobs 
            WHERE user_id = $1 AND job_type LIKE 'monitoring%'
            ORDER BY started_at DESC 
            LIMIT $2
            """,
            user.sub, limit
        )
        
        return [
            BackgroundJobStatus(
                job_id=row['id'],
                job_type=row['job_type'],
                customer_id=row.get('customer_id'),
                status=row['status'],
                started_at=row['started_at'],
                completed_at=row['completed_at'],
                result=row['result'],
                error_message=row.get('error_message')
            )
            for row in jobs_data
        ]
        
    finally:
        await conn.close()

@router.get("/customer/{customer_id}/history")
async def get_customer_monitoring_history(customer_id: str, user: AuthorizedUser, limit: int = 10):
    """Get monitoring history for a specific customer"""
    conn = await get_db_connection()
    try:
        # Verify customer belongs to user
        customer = await conn.fetchrow(
            "SELECT id, customer_name FROM customer_profiles WHERE id = $1 AND created_by = $2",
            customer_id, user.sub
        )
        
        if not customer:
            raise HTTPException(status_code=404, detail="Customer not found")
        
        # Get monitoring history
        history_data = await conn.fetch(
            """
            SELECT * FROM customer_monitoring_logs 
            WHERE customer_id = $1 AND user_id = $2
            ORDER BY monitored_at DESC 
            LIMIT $3
            """,
            customer_id, user.sub, limit
        )
        
        return {
            "customer_id": customer_id,
            "customer_name": customer['customer_name'],
            "history": [
                {
                    "monitored_at": row['monitored_at'].isoformat(),
                    "monitoring_type": row['monitoring_type'],
                    "risk_score": row['risk_score'],
                    "risk_level": row['risk_level'],
                    "risk_factors": row['risk_factors'],
                    "risk_changed": row['risk_changed']
                }
                for row in history_data
            ]
        }
        
    finally:
        await conn.close()

# System health endpoint
@router.get("/health")
async def get_monitoring_system_health(user: AuthorizedUser):
    """Get monitoring system health metrics"""
    conn = await get_db_connection()
    try:
        # Get configuration status
        config = await conn.fetchrow(
            "SELECT * FROM monitoring_configurations WHERE user_id = $1",
            user.sub
        )
        
        # Get recent monitoring activity
        recent_activity = await conn.fetchval(
            "SELECT COUNT(*) FROM customer_monitoring_logs WHERE user_id = $1 AND monitored_at >= NOW() - INTERVAL '24 hours'",
            user.sub
        ) or 0
        
        # Get failed jobs
        failed_jobs = await conn.fetchval(
            "SELECT COUNT(*) FROM automation_jobs WHERE user_id = $1 AND status = 'failed' AND started_at >= NOW() - INTERVAL '24 hours'",
            user.sub
        ) or 0
        
        # Calculate health score
        health_score = 100
        if not config or not config['enabled']:
            health_score -= 50
        if recent_activity == 0:
            health_score -= 30
        if failed_jobs > 0:
            health_score -= (failed_jobs * 10)
        
        health_score = max(0, health_score)
        
        return {
            "health_score": health_score,
            "monitoring_enabled": config and config['enabled'] if config else False,
            "recent_monitoring_activity": recent_activity,
            "failed_jobs_24h": failed_jobs,
            "last_cycle": config['last_monitoring_cycle'].isoformat() if config and config['last_monitoring_cycle'] else None,
            "next_cycle_due": (config['last_monitoring_cycle'] + timedelta(hours=config['monitoring_frequency_hours'])).isoformat() if config and config['last_monitoring_cycle'] else None,
            "status": "healthy" if health_score >= 80 else "warning" if health_score >= 50 else "critical"
        }
        
    finally:
        await conn.close()
