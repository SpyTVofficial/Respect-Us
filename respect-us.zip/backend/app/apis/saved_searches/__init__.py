from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from typing import List, Optional, Dict, Any
from datetime import datetime
import json
import asyncpg
import databutton as db
from app.auth import AuthorizedUser

router = APIRouter()

class SavedSearchRequest(BaseModel):
    name: str
    description: Optional[str] = None
    search_query: str
    search_mode: str = "simple"  # simple, boolean, phrase, wildcard, fuzzy
    filters: Optional[Dict[str, Any]] = None
    alert_enabled: bool = False
    alert_frequency: str = "daily"  # daily, weekly, monthly, immediate

class SavedSearchResponse(BaseModel):
    id: int
    name: str
    description: Optional[str]
    search_query: str
    search_mode: str
    filters: Optional[Dict[str, Any]]
    alert_enabled: bool
    alert_frequency: str
    created_at: datetime
    updated_at: datetime
    last_run: Optional[datetime]
    result_count: Optional[int]

class SavedSearchUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    search_query: Optional[str] = None
    search_mode: Optional[str] = None
    filters: Optional[Dict[str, Any]] = None
    alert_enabled: Optional[bool] = None
    alert_frequency: Optional[str] = None

class SearchAlertResponse(BaseModel):
    id: int
    saved_search_id: int
    new_documents_count: int
    triggered_at: datetime
    documents: List[Dict[str, Any]]

@router.post("/saved-searches", response_model=SavedSearchResponse)
async def create_saved_search(request: SavedSearchRequest, user: AuthorizedUser):
    """Create a new saved search with optional alerts"""
    try:
        conn = await asyncpg.connect(db.secrets.get("DATABASE_URL_DEV"))
        
        query = """
        INSERT INTO saved_searches (
            user_id, name, description, search_query, search_mode, 
            filters, alert_enabled, alert_frequency, created_at, updated_at
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, NOW(), NOW())
        RETURNING *
        """
        
        filters_json = json.dumps(request.filters) if request.filters else None
        
        row = await conn.fetchrow(
            query, user.sub, request.name, request.description,
            request.search_query, request.search_mode, filters_json,
            request.alert_enabled, request.alert_frequency
        )
        
        await conn.close()
        
        return SavedSearchResponse(
            id=row['id'],
            name=row['name'],
            description=row['description'],
            search_query=row['search_query'],
            search_mode=row['search_mode'],
            filters=json.loads(row['filters']) if row['filters'] else None,
            alert_enabled=row['alert_enabled'],
            alert_frequency=row['alert_frequency'],
            created_at=row['created_at'],
            updated_at=row['updated_at'],
            last_run=row['last_run'],
            result_count=row['result_count']
        )
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to create saved search: {str(e)}")

@router.get("/saved-searches", response_model=List[SavedSearchResponse])
async def list_saved_searches(user: AuthorizedUser):
    """Get all saved searches for the current user"""
    try:
        conn = await asyncpg.connect(db.secrets.get("DATABASE_URL_DEV"))
        
        query = """
        SELECT * FROM saved_searches 
        WHERE user_id = $1 
        ORDER BY created_at DESC
        """
        
        rows = await conn.fetch(query, user.sub)
        await conn.close()
        
        return [
            SavedSearchResponse(
                id=row['id'],
                name=row['name'],
                description=row['description'],
                search_query=row['search_query'],
                search_mode=row['search_mode'],
                filters=json.loads(row['filters']) if row['filters'] else None,
                alert_enabled=row['alert_enabled'],
                alert_frequency=row['alert_frequency'],
                created_at=row['created_at'],
                updated_at=row['updated_at'],
                last_run=row['last_run'],
                result_count=row['result_count']
            )
            for row in rows
        ]
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to fetch saved searches: {str(e)}")

@router.get("/saved-searches/{search_id}", response_model=SavedSearchResponse)
async def get_saved_search(search_id: int, user: AuthorizedUser):
    """Get a specific saved search"""
    try:
        conn = await asyncpg.connect(db.secrets.get("DATABASE_URL_DEV"))
        
        query = """
        SELECT * FROM saved_searches 
        WHERE id = $1 AND user_id = $2
        """
        
        row = await conn.fetchrow(query, search_id, user.sub)
        await conn.close()
        
        if not row:
            raise HTTPException(status_code=404, detail="Saved search not found")
        
        return SavedSearchResponse(
            id=row['id'],
            name=row['name'],
            description=row['description'],
            search_query=row['search_query'],
            search_mode=row['search_mode'],
            filters=json.loads(row['filters']) if row['filters'] else None,
            alert_enabled=row['alert_enabled'],
            alert_frequency=row['alert_frequency'],
            created_at=row['created_at'],
            updated_at=row['updated_at'],
            last_run=row['last_run'],
            result_count=row['result_count']
        )
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to fetch saved search: {str(e)}")

@router.put("/saved-searches/{search_id}", response_model=SavedSearchResponse)
async def update_saved_search(search_id: int, request: SavedSearchUpdate, user: AuthorizedUser):
    """Update a saved search"""
    try:
        conn = await asyncpg.connect(db.secrets.get("DATABASE_URL_DEV"))
        
        # Build dynamic update query
        updates = []
        values = []
        param_count = 1
        
        if request.name is not None:
            updates.append(f"name = ${param_count}")
            values.append(request.name)
            param_count += 1
            
        if request.description is not None:
            updates.append(f"description = ${param_count}")
            values.append(request.description)
            param_count += 1
            
        if request.search_query is not None:
            updates.append(f"search_query = ${param_count}")
            values.append(request.search_query)
            param_count += 1
            
        if request.search_mode is not None:
            updates.append(f"search_mode = ${param_count}")
            values.append(request.search_mode)
            param_count += 1
            
        if request.filters is not None:
            updates.append(f"filters = ${param_count}")
            values.append(json.dumps(request.filters))
            param_count += 1
            
        if request.alert_enabled is not None:
            updates.append(f"alert_enabled = ${param_count}")
            values.append(request.alert_enabled)
            param_count += 1
            
        if request.alert_frequency is not None:
            updates.append(f"alert_frequency = ${param_count}")
            values.append(request.alert_frequency)
            param_count += 1
        
        if not updates:
            raise HTTPException(status_code=400, detail="No fields to update")
        
        updates.append("updated_at = NOW()")
        
        query = f"""
        UPDATE saved_searches 
        SET {', '.join(updates)}
        WHERE id = ${param_count} AND user_id = ${param_count + 1}
        RETURNING *
        """
        
        values.extend([search_id, user.sub])
        
        row = await conn.fetchrow(query, *values)
        await conn.close()
        
        if not row:
            raise HTTPException(status_code=404, detail="Saved search not found")
        
        return SavedSearchResponse(
            id=row['id'],
            name=row['name'],
            description=row['description'],
            search_query=row['search_query'],
            search_mode=row['search_mode'],
            filters=json.loads(row['filters']) if row['filters'] else None,
            alert_enabled=row['alert_enabled'],
            alert_frequency=row['alert_frequency'],
            created_at=row['created_at'],
            updated_at=row['updated_at'],
            last_run=row['last_run'],
            result_count=row['result_count']
        )
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to update saved search: {str(e)}")

@router.delete("/saved-searches/{search_id}")
async def delete_saved_search(search_id: int, user: AuthorizedUser):
    """Delete a saved search"""
    try:
        conn = await asyncpg.connect(db.secrets.get("DATABASE_URL_DEV"))
        
        query = """
        DELETE FROM saved_searches 
        WHERE id = $1 AND user_id = $2
        RETURNING id
        """
        
        row = await conn.fetchrow(query, search_id, user.sub)
        await conn.close()
        
        if not row:
            raise HTTPException(status_code=404, detail="Saved search not found")
        
        return {"message": "Saved search deleted successfully"}
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to delete saved search: {str(e)}")

@router.post("/saved-searches/{search_id}/run")
async def run_saved_search(search_id: int, user: AuthorizedUser):
    """Execute a saved search and return results"""
    try:
        # Import here to avoid circular imports
        from app.apis.knowledge_base import search_documents_internal
        
        conn = await asyncpg.connect(db.secrets.get("DATABASE_URL_DEV"))
        
        # Get the saved search
        query = """
        SELECT * FROM saved_searches 
        WHERE id = $1 AND user_id = $2
        """
        
        search_row = await conn.fetchrow(query, search_id, user.sub)
        
        if not search_row:
            raise HTTPException(status_code=404, detail="Saved search not found")
        
        # Execute the search
        filters = json.loads(search_row['filters']) if search_row['filters'] else {}
        
        results = await search_documents_internal(
            query=search_row['search_query'],
            search_mode=search_row['search_mode'],
            limit=100,
            offset=0,
            **filters
        )
        
        # Update last run and result count
        update_query = """
        UPDATE saved_searches 
        SET last_run = NOW(), result_count = $1, updated_at = NOW()
        WHERE id = $2
        """
        
        await conn.execute(update_query, len(results['documents']), search_id)
        await conn.close()
        
        return results
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to run saved search: {str(e)}")

@router.get("/saved-searches/{search_id}/alerts", response_model=List[SearchAlertResponse])
async def get_search_alerts(search_id: int, user: AuthorizedUser):
    """Get alert history for a saved search"""
    try:
        conn = await asyncpg.connect(db.secrets.get("DATABASE_URL_DEV"))
        
        # Verify ownership
        verify_query = """
        SELECT id FROM saved_searches 
        WHERE id = $1 AND user_id = $2
        """
        
        if not await conn.fetchrow(verify_query, search_id, user.sub):
            raise HTTPException(status_code=404, detail="Saved search not found")
        
        # Get alerts
        query = """
        SELECT * FROM search_alerts 
        WHERE saved_search_id = $1 
        ORDER BY triggered_at DESC
        LIMIT 50
        """
        
        rows = await conn.fetch(query, search_id)
        await conn.close()
        
        return [
            SearchAlertResponse(
                id=row['id'],
                saved_search_id=row['saved_search_id'],
                new_documents_count=row['new_documents_count'],
                triggered_at=row['triggered_at'],
                documents=json.loads(row['documents']) if row['documents'] else []
            )
            for row in rows
        ]
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to fetch search alerts: {str(e)}")
