



from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import List, Optional, Dict, Any
import asyncpg
import databutton as db
from app.auth import AuthorizedUser
from app.env import Mode, mode
from datetime import datetime
import json

router = APIRouter(prefix="/content-management")

# Content Models
class TooltipContent(BaseModel):
    title: str
    sources: List[str]
    confidence_level: str  # "high", "medium", "low"
    update_frequency: str
    additional_info: Optional[str] = None

class MethodologySection(BaseModel):
    title: str
    description: str
    icon: str
    color: str
    details: str

class SourceEntry(BaseModel):
    name: str
    description: str
    url: str
    update_frequency: str
    confidence_level: str
    category: str

class ContentItem(BaseModel):
    id: Optional[int] = None
    content_type: str  # "tooltip", "methodology_section", "source_entry", "methodology_overview"
    module_name: str  # "end_use_checks", "risk_assessment", etc.
    identifier: str  # unique identifier within module
    title: str
    content: Dict[str, Any]  # JSON content specific to each type
    is_active: bool = True
    created_at: Optional[str] = None
    updated_at: Optional[str] = None

class CreateContentRequest(BaseModel):
    content_type: str
    module_name: str
    identifier: str
    title: str
    content: Dict[str, Any]
    is_active: bool = True

class UpdateContentRequest(BaseModel):
    title: Optional[str] = None
    content: Optional[Dict[str, Any]] = None
    is_active: Optional[bool] = None

class ContentListResponse(BaseModel):
    items: List[ContentItem]
    total_count: int

# Database connection helper
async def get_db_connection():
    database_url = db.secrets.get("DATABASE_URL_DEV")
    return await asyncpg.connect(database_url)

# Default content items to initialize
default_content = [
    # Knowledge Base content
    {
        "module_name": "knowledge_base",
        "content_key": "homepage_intro",
        "content_type": "text",
        "title": "Knowledge Base Introduction",
        "content": "Welcome to your comprehensive export control compliance knowledge base. Access regulatory documents, country profiles, and compliance guidelines.",
        "metadata": {"display_location": "homepage"}
    },
    {
        "module_name": "knowledge_base",
        "content_key": "search_placeholder",
        "content_type": "text",
        "title": "Search Placeholder Text",
        "content": "Search regulations, country profiles, or compliance topics...",
        "metadata": {"display_location": "search_bar"}
    },
    
    # Product Classification content
    {
        "module_name": "product_classification",
        "content_key": "module_intro",
        "content_type": "text",
        "title": "Product Classification Introduction",
        "content": "Classify your products according to export control regulations. Get accurate commodity codes and licensing requirements.",
        "metadata": {"display_location": "module_header"}
    },
    
    # Sanctions & Embargoes content
    {
        "module_name": "sanctions_embargoes",
        "content_key": "module_intro",
        "content_type": "text",
        "title": "Sanctions & Embargoes Introduction",
        "content": "Stay updated on current sanctions and embargoes. Screen your transactions against the latest regulatory restrictions.",
        "metadata": {"display_location": "module_header"}
    },
    
    # Credit Package Descriptions
    {
        "module_name": "credit_packages",
        "content_key": "starter_description",
        "content_type": "text",
        "title": "Starter Package Description",
        "content": "Perfect for small businesses getting started with export control compliance. Includes basic access to all modules with essential features.",
        "metadata": {"package_id": 1, "features": ["Basic module access", "Standard support", "Email notifications", "6-month credit validity"]}
    },
    {
        "module_name": "credit_packages",
        "content_key": "professional_description",
        "content_type": "text",
        "title": "Professional Package Description",
        "content": "Ideal for growing companies with regular compliance needs. Enhanced features and priority support for professional operations.",
        "metadata": {"package_id": 2, "features": ["Full module access", "Priority support", "Advanced reporting", "8-month credit validity", "Bulk operations"]}
    },
    {
        "module_name": "credit_packages",
        "content_key": "enterprise_description",
        "content_type": "text",
        "title": "Enterprise Package Description",
        "content": "Comprehensive solution for large enterprises with complex compliance requirements. Includes premium features and dedicated support.",
        "metadata": {"package_id": 3, "features": ["Premium access", "Dedicated support", "Custom integrations", "10-month credit validity", "Advanced analytics", "Team collaboration"]}
    },
    {
        "module_name": "credit_packages",
        "content_key": "enterprise_plus_description",
        "content_type": "text",
        "title": "Enterprise+ Package Description",
        "content": "Ultimate compliance solution for the largest organizations. Maximum credits with extended validity and white-glove service.",
        "metadata": {"package_id": 4, "features": ["Maximum credits", "White-glove service", "Custom development", "12-month credit validity", "Executive reporting", "Unlimited support"]}
    },
    
    # Bank Transfer Payment Option
    {
        "module_name": "payment_options",
        "content_key": "bank_transfer_info",
        "content_type": "text",
        "title": "Bank Transfer Payment Information",
        "content": "Pay securely via bank transfer for any credit amount. Perfect for custom requirements and preferred by many enterprises.",
        "metadata": {"payment_method": "bank_transfer", "supports_custom_amounts": True}
    },
    {
        "module_name": "payment_options",
        "content_key": "custom_credits_info",
        "content_type": "text",
        "title": "Custom Credit Amounts",
        "content": "Need a specific number of credits? Request a custom amount via bank transfer. We'll provide a personalized quote within 24 hours.",
        "metadata": {"payment_method": "bank_transfer", "custom_amounts": True}
    },
    
    # End-Use Checks Module Content
    {
        "module_name": "end_use_checks",
        "content_key": "data_sources_explanation",
        "content_type": "text_content",
        "title": "View Data Sources",
        "content": {
            "text": "Our critical countries assessment draws from multiple authoritative sources to provide comprehensive risk analysis:\n\n**Primary Government Sources:**\n• Bureau of Industry and Security (BIS) - Export Administration Regulations\n• Office of Foreign Assets Control (OFAC) - Sanctions programs\n• State Department - Country Commercial Guides and security assessments\n• European Union - Dual-use export control regulations\n\n**International Organizations:**\n• United Nations - Arms embargoes and sanctions\n• Freedom House - Political rights and civil liberties scores\n• World Bank - Governance indicators\n• SIPRI - Arms trade databases\n\n**Methodology:**\nData is collected monthly from these sources and processed through our risk assessment algorithms. Each country receives composite scores across multiple dimensions including export control compliance, sanctions status, arms embargo restrictions, and human rights considerations.\n\n**Data Confidence:**\nAll data points include confidence levels (High/Medium/Low) based on source reliability and recency. Government sources receive the highest confidence ratings, while NGO assessments are weighted according to their methodological transparency.",
            "description": "Comprehensive explanation of data sources and methodology for critical countries assessment",
            "version": "v1.0"
        },
        "metadata": {"display_location": "sources_dialog", "content_area": "data_sources"}
    },
    {
        "module_name": "end_use_checks",
        "content_key": "access_benefits",
        "content_type": "text_content",
        "title": "Unlock Critical Countries Database",
        "content": {
            "text": "Comprehensive country risk profiles with detailed analysis of export controls, sanctions regimes, and proliferation concerns|Advanced filtering and search capabilities to quickly identify high-risk destinations|Real-time updates from authoritative government sources including BIS, State Department, and EU agencies|Detailed documentation and regulatory guidance for compliance decisions|Historical trend analysis and risk scoring methodologies|Export control treaty participation and compliance status|Arms embargo and sanctions monitoring across multiple jurisdictions",
            "description": "Benefits and features available when accessing the Critical Countries database",
            "version": "v1.0"
        },
        "metadata": {"display_location": "unlock_dialog", "content_area": "access_benefits"}
    },
    # PDF Report Cover Page Content
    {
        "module_name": "pdf_reports",
        "content_key": "cover_page_title",
        "content_type": "text_content",
        "title": "PDF Report Cover Page Title",
        "content": {
            "text": "Country Risk Analysis Report",
            "description": "Main title displayed on PDF report cover pages",
            "version": "v1.0"
        },
        "metadata": {"display_location": "pdf_cover", "content_area": "title"}
    },
    {
        "module_name": "pdf_reports",
        "content_key": "cover_page_subtitle",
        "content_type": "text_content",
        "title": "PDF Report Cover Page Subtitle",
        "content": {
            "text": "Comprehensive Export Control Risk Assessment",
            "description": "Subtitle displayed on PDF report cover pages",
            "version": "v1.0"
        },
        "metadata": {"display_location": "pdf_cover", "content_area": "subtitle"}
    },
    {
        "module_name": "pdf_reports",
        "content_key": "company_credentials",
        "content_type": "text_content",
        "title": "RespectUs Company Credentials",
        "content": {
            "text": "RespectUs is a leading provider of export control compliance solutions, offering comprehensive risk assessment tools and regulatory intelligence to help organizations navigate complex international trade regulations. Our platform combines authoritative government data sources with advanced analytics to deliver actionable compliance insights.",
            "description": "Company credentials and description for PDF cover pages",
            "version": "v1.0"
        },
        "metadata": {"display_location": "pdf_cover", "content_area": "credentials"}
    },
    {
        "module_name": "pdf_reports",
        "content_key": "report_disclaimer",
        "content_type": "disclaimer",
        "title": "PDF Report Legal Disclaimer",
        "content": {
            "text": "**IMPORTANT LEGAL DISCLAIMER**\n\nThis report is provided for informational purposes only and should not be considered as legal advice. The information contained herein is based on publicly available sources and is subject to change without notice. While RespectUs strives to ensure accuracy and completeness, we make no warranties or representations regarding the accuracy, completeness, or reliability of the information presented.\n\n**Compliance Responsibility:** Organizations are solely responsible for ensuring compliance with all applicable export control regulations, sanctions, and other legal requirements. This report should be used as a reference tool only and should not replace consultation with qualified legal counsel or compliance professionals.\n\n**Data Sources:** Information in this report is compiled from various government sources including the U.S. Bureau of Industry and Security (BIS), Office of Foreign Assets Control (OFAC), European Union agencies, and other authoritative sources. Data accuracy depends on the timeliness and accuracy of these source systems.\n\n**No Liability:** RespectUs, its affiliates, and employees shall not be liable for any damages, losses, or consequences arising from the use of this report or reliance on the information contained herein. Users assume full responsibility for any actions taken based on this information.\n\n**Confidentiality:** This report may contain sensitive information and should be treated as confidential. Unauthorized distribution or disclosure may violate applicable laws and regulations.\n\n**Report Validity:** This report reflects information available as of the generation date. Export control regulations and sanctions are subject to frequent changes. Users should verify current requirements with appropriate authorities before making compliance decisions.",
            "description": "Legal disclaimer text for PDF reports",
            "version": "v1.0"
        },
        "metadata": {"display_location": "pdf_disclaimer", "content_area": "legal_text"}
    }
]

# Initialize default content for End-Use Checks
@router.post("/initialize-defaults")
async def initialize_default_content(user: AuthorizedUser):
    """Initialize default content for modules (admin only)"""
    try:
        conn = await get_db_connection()
        
        # The table already exists with the correct structure
        # No need to create it again
        
        # Insert default content
        inserted_count = 0
        for item in default_content:
            try:
                await conn.execute("""
                    INSERT INTO content_management (module_name, content_key, content_type, title, content, metadata)
                    VALUES ($1, $2, $3, $4, $5, $6)
                    ON CONFLICT (module_name, content_key) DO NOTHING
                """, item["module_name"], item["content_key"], item["content_type"], 
                      item["title"], item["content"], item["metadata"])
                inserted_count += 1
            except Exception as e:
                print(f"Error inserting content item: {e}")
                continue
        
        await conn.close()

        return {
            "message": f"Initialized {inserted_count} default content items",
            "items_created": inserted_count
        }
        
    except Exception as e:
        print(f"Error initializing default content: {e}")
        raise HTTPException(status_code=500, detail="Failed to initialize default content")

@router.get("/content/{module_name}")
async def get_content_by_module(module_name: str) -> ContentListResponse:
    """Get all content items for a specific module"""
    conn = await get_db_connection()
    try:
        query = """
            SELECT id, module_name, content_key, content_type, title, content, metadata,
                   created_at, updated_at
            FROM content_management 
            WHERE module_name = $1
            ORDER BY content_key, created_at DESC
        """
        rows = await conn.fetch(query, module_name)
        
        content_items = []
        for row in rows:
            # Parse metadata JSON
            metadata = {}
            if row['metadata']:
                try:
                    metadata = json.loads(row['metadata'])
                except json.JSONDecodeError:
                    metadata = {}
            
            # Handle content based on type - for list types, keep as text
            content_value = row['content']
            if row['content_type'] == 'list':
                # For list content type, keep content as text for frontend parsing
                content_data = {"text": content_value}
            else:
                # For other types, try to parse as JSON or keep as text
                try:
                    content_data = json.loads(content_value) if isinstance(content_value, str) else content_value
                except (json.JSONDecodeError, TypeError):
                    content_data = {"text": content_value}
            
            content_items.append(ContentItem(
                id=row['id'],
                content_type=row['content_type'],
                module_name=row['module_name'],
                identifier=row['content_key'],  # Map content_key to identifier for compatibility
                title=row['title'],
                content=content_data,
                metadata=metadata,
                created_at=row['created_at'].isoformat() if row['created_at'] else None,
                updated_at=row['updated_at'].isoformat() if row['updated_at'] else None
            ))
        
        return ContentListResponse(
            items=content_items,
            total_count=len(content_items)
        )
    except Exception as e:
        print(f"❌ Error getting content: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to get content: {str(e)}")
    finally:
        await conn.close()

@router.post("/content")
async def create_content_item(request: CreateContentRequest, user: AuthorizedUser):
    """Create a new content item"""
    try:
        conn = await get_db_connection()
        
        result = await conn.fetchrow("""
            INSERT INTO content_management (content_type, module_name, content_key, title, content)
            VALUES ($1, $2, $3, $4, $5)
            RETURNING id, created_at
        """, request.content_type, request.module_name, request.identifier, 
              request.title, json.dumps(request.content) if isinstance(request.content, dict) else str(request.content))
        
        await conn.close()
        
        return {
            "id": result['id'],
            "message": "Content item created successfully",
            "created_at": result['created_at']
        }
        
    except Exception as e:
        print(f"Error creating content item: {e}")
        raise HTTPException(status_code=500, detail="Failed to create content item")

@router.put("/content/{content_id}")
async def update_content_item(content_id: int, request: UpdateContentRequest, user: AuthorizedUser):
    """Update an existing content item"""
    try:
        conn = await get_db_connection()
        
        # Build dynamic update query
        updates = []
        values = []
        param_count = 1
        
        if request.title is not None:
            updates.append(f"title = ${param_count}")
            values.append(request.title)
            param_count += 1
            
        if request.content is not None:
            updates.append(f"content = ${param_count}")
            values.append(json.dumps(request.content) if isinstance(request.content, dict) else str(request.content))
            param_count += 1
        
        if not updates:
            raise HTTPException(status_code=400, detail="No fields to update")
        
        updates.append(f"updated_at = NOW()")
        values.append(content_id)
        
        query = f"""
            UPDATE content_management 
            SET {', '.join(updates)}
            WHERE id = ${param_count}
            RETURNING updated_at
        """
        
        result = await conn.fetchrow(query, *values)
        
        if not result:
            raise HTTPException(status_code=404, detail="Content item not found")
        
        await conn.close()
        
        return {
            "message": "Content item updated successfully",
            "updated_at": result['updated_at']
        }
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error updating content item: {e}")
        raise HTTPException(status_code=500, detail="Failed to update content item")

@router.delete("/content/{content_id}")
async def delete_content_item(content_id: int, user: AuthorizedUser):
    """Delete a content item"""
    try:
        conn = await get_db_connection()
        
        result = await conn.execute("""
            DELETE FROM content_management WHERE id = $1
        """, content_id)
        
        await conn.close()
        
        if result == "DELETE 0":
            raise HTTPException(status_code=404, detail="Content item not found")
        
        return {"message": "Content item deleted successfully"}
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error deleting content item: {e}")
        raise HTTPException(status_code=500, detail="Failed to delete content item")

@router.get("/content-item/{content_id}")
async def get_content_item(content_id: int, user: AuthorizedUser):
    """Get a specific content item by ID"""
    try:
        conn = await get_db_connection()
        
        row = await conn.fetchrow("""
            SELECT id, content_type, module_name, content_key, title, content, metadata, 
                   created_at, updated_at
            FROM content_management 
            WHERE id = $1
        """, content_id)
        
        await conn.close()
        
        if not row:
            raise HTTPException(status_code=404, detail="Content item not found")
        
        # Parse metadata if it's a JSON string
        metadata = row['metadata'] 
        if isinstance(metadata, str):
            try:
                metadata = json.loads(metadata)
            except:
                metadata = {}
        
        return ContentItem(
            id=row['id'],
            content_type=row['content_type'],
            module_name=row['module_name'],
            identifier=row['content_key'],  # Map content_key to identifier
            title=row['title'],
            content=row['content'] if isinstance(row['content'], dict) else {"text": row['content']},
            is_active=True
        )
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error getting content item: {e}")
        raise HTTPException(status_code=500, detail="Failed to retrieve content item")
