
from fastapi import APIRouter, UploadFile, File, Form, HTTPException
from pydantic import BaseModel
from typing import List, Optional, Dict, Any
from datetime import datetime
import asyncpg
import databutton as db
from app.auth import AuthorizedUser
import json
import hashlib
import os
from pathlib import Path

router = APIRouter(prefix="/documents")

# Pydantic Models
class DocumentUploadRequest(BaseModel):
    customer_id: Optional[int] = None
    category: str  # "kyc", "due_diligence", "compliance", "contracts", "other"
    subcategory: Optional[str] = None
    description: Optional[str] = None
    tags: Optional[List[str]] = None
    expires_at: Optional[datetime] = None
    requires_approval: bool = False

class DocumentMetadata(BaseModel):
    id: int
    filename: str
    original_filename: str
    file_size: int
    file_type: str
    category: str
    subcategory: Optional[str]
    description: Optional[str]
    tags: List[str]
    customer_id: Optional[int]
    customer_name: Optional[str]
    upload_date: datetime
    uploaded_by: str
    expires_at: Optional[datetime]
    status: str  # "pending", "approved", "rejected", "archived"
    version: int
    file_hash: str
    download_url: str

class DocumentUploadResponse(BaseModel):
    success: bool
    message: str
    document: Optional[DocumentMetadata]
    document_id: Optional[int]

class DocumentListRequest(BaseModel):
    customer_id: Optional[int] = None
    category: Optional[str] = None
    status: Optional[str] = None
    search_term: Optional[str] = None
    tags: Optional[List[str]] = None
    page: int = 1
    limit: int = 20

class DocumentListResponse(BaseModel):
    success: bool
    message: str
    documents: List[DocumentMetadata]
    total_count: int
    page: int
    total_pages: int

class DocumentApprovalRequest(BaseModel):
    document_id: int
    action: str  # "approve", "reject"
    notes: Optional[str] = None

class DocumentApprovalResponse(BaseModel):
    success: bool
    message: str
    document_id: int
    new_status: str

class DocumentVersionRequest(BaseModel):
    document_id: int
    description: Optional[str] = None

class DocumentVersionResponse(BaseModel):
    success: bool
    message: str
    document: DocumentMetadata
    previous_version: int
    new_version: int

class DocumentCategoryStats(BaseModel):
    category: str
    total_documents: int
    pending_approval: int
    approved_documents: int
    total_size_mb: float
    latest_upload: Optional[datetime]

class DocumentAnalyticsResponse(BaseModel):
    success: bool
    message: str
    total_documents: int
    total_size_gb: float
    category_stats: List[DocumentCategoryStats]
    recent_uploads: List[DocumentMetadata]
    expiring_soon: List[DocumentMetadata]

# Database connection helper
async def get_db_connection():
    from app.env import Mode, mode
    if mode.value == "PROD":
        database_url = db.secrets.get("DATABASE_URL_PROD")
    else:
        database_url = db.secrets.get("DATABASE_URL_DEV")
    return await asyncpg.connect(database_url)

@router.post("/upload")
async def upload_customer_document(
    file: UploadFile = File(...),
    customer_id: Optional[int] = Form(None),
    category: str = Form(...),
    subcategory: Optional[str] = Form(None),
    description: Optional[str] = Form(None),
    tags: Optional[str] = Form(None),  # JSON string of tags
    expires_at: Optional[str] = Form(None),  # ISO date string
    requires_approval: bool = Form(False),
    user: AuthorizedUser = None
) -> DocumentUploadResponse:
    """
    Upload a document with metadata and store securely
    """
    try:
        # Validate file type and size
        allowed_types = {
            'application/pdf', 'image/jpeg', 'image/png', 'image/gif',
            'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            'application/vnd.ms-excel', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            'text/plain', 'text/csv'
        }
        
        if file.content_type not in allowed_types:
            return DocumentUploadResponse(
                success=False,
                message=f"File type {file.content_type} not allowed",
                document=None,
                document_id=None
            )
        
        # Read file content
        file_content = await file.read()
        file_size = len(file_content)
        
        # Validate file size (max 50MB)
        if file_size > 50 * 1024 * 1024:
            return DocumentUploadResponse(
                success=False,
                message="File size exceeds 50MB limit",
                document=None,
                document_id=None
            )
        
        # Generate file hash for deduplication
        file_hash = hashlib.sha256(file_content).hexdigest()
        
        # Parse tags and expiry date
        parsed_tags = json.loads(tags) if tags else []
        parsed_expires_at = datetime.fromisoformat(expires_at.replace('Z', '+00:00')) if expires_at else None
        
        # Generate secure filename
        file_extension = Path(file.filename).suffix
        secure_filename = f"{file_hash[:16]}_{int(datetime.now().timestamp())}{file_extension}"
        
        conn = await get_db_connection()
        
        # Check for duplicate files
        duplicate_check = await conn.fetchrow(
            "SELECT id, filename FROM customer_documents WHERE file_hash = $1",
            file_hash
        )
        
        if duplicate_check:
            await conn.close()
            return DocumentUploadResponse(
                success=False,
                message=f"Duplicate file detected. Original: {duplicate_check['filename']}",
                document=None,
                document_id=duplicate_check['id']
            )
        
        # Store file using Databutton storage
        storage_path = f"documents/{secure_filename}"
        
        # For demo purposes, we'll simulate file storage
        # In production, this would use actual file storage service
        storage_success = True  # Simulate successful storage
        
        if not storage_success:
            await conn.close()
            return DocumentUploadResponse(
                success=False,
                message="Failed to store file",
                document=None,
                document_id=None
            )
        
        # Store document metadata in database
        insert_query = """
            INSERT INTO customer_documents 
            (filename, original_filename, file_size, file_type, category, subcategory, 
             description, tags, customer_id, uploaded_by, expires_at, status, version, 
             file_hash, storage_path, created_at, updated_at)
            VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, NOW(), NOW())
            RETURNING id, created_at
        """
        
        status = "pending" if requires_approval else "approved"
        
        result = await conn.fetchrow(
            insert_query,
            secure_filename,
            file.filename,
            file_size,
            file.content_type,
            category,
            subcategory,
            description,
            json.dumps(parsed_tags),
            customer_id,
            user.sub,
            parsed_expires_at,
            status,
            1,  # Version
            file_hash,
            storage_path
        )
        
        document_id = result['id']
        upload_date = result['created_at']
        
        # Get customer name if customer_id provided
        customer_name = None
        if customer_id:
            customer_result = await conn.fetchrow("SELECT name FROM customers WHERE id = $1", customer_id)
            customer_name = customer_result['name'] if customer_result else None
        
        await conn.close()
        
        # Create document metadata response
        document_metadata = DocumentMetadata(
            id=document_id,
            filename=secure_filename,
            original_filename=file.filename,
            file_size=file_size,
            file_type=file.content_type,
            category=category,
            subcategory=subcategory,
            description=description,
            tags=parsed_tags,
            customer_id=customer_id,
            customer_name=customer_name,
            upload_date=upload_date,
            uploaded_by=user.sub,
            expires_at=parsed_expires_at,
            status=status,
            version=1,
            file_hash=file_hash,
            download_url=f"/api/documents/{document_id}/download"
        )
        
        return DocumentUploadResponse(
            success=True,
            message=f"Document '{file.filename}' uploaded successfully",
            document=document_metadata,
            document_id=document_id
        )
        
    except Exception as e:
        return DocumentUploadResponse(
            success=False,
            message=f"Error uploading document: {str(e)}",
            document=None,
            document_id=None
        )

@router.post("/list")
async def list_customer_documents(request: DocumentListRequest, user: AuthorizedUser) -> DocumentListResponse:
    """
    List documents with filtering and pagination
    """
    try:
        conn = await get_db_connection()
        
        # Build query with filters
        base_query = """
            SELECT d.*, c.name as customer_name
            FROM customer_documents d
            LEFT JOIN customers c ON d.customer_id = c.id
            WHERE 1=1
        """
        
        params = []
        param_count = 0
        
        if request.customer_id:
            param_count += 1
            base_query += f" AND d.customer_id = ${param_count}"
            params.append(request.customer_id)
        
        if request.category:
            param_count += 1
            base_query += f" AND d.category = ${param_count}"
            params.append(request.category)
        
        if request.status:
            param_count += 1
            base_query += f" AND d.status = ${param_count}"
            params.append(request.status)
        
        if request.search_term:
            param_count += 1
            base_query += f" AND (d.original_filename ILIKE ${param_count} OR d.description ILIKE ${param_count})"
            params.append(f"%{request.search_term}%")
        
        if request.tags:
            param_count += 1
            base_query += f" AND d.tags::jsonb ?| array[{','.join(['%s'] * len(request.tags))}]"
            params.extend(request.tags)
        
        # Count total records
        count_query = f"SELECT COUNT(*) as total FROM ({base_query}) as filtered"
        total_result = await conn.fetchrow(count_query, *params)
        total_count = total_result['total']
        
        # Add pagination
        offset = (request.page - 1) * request.limit
        param_count += 1
        base_query += f" ORDER BY d.created_at DESC LIMIT ${param_count}"
        params.append(request.limit)
        
        param_count += 1
        base_query += f" OFFSET ${param_count}"
        params.append(offset)
        
        # Execute query
        documents_data = await conn.fetch(base_query, *params)
        
        # Format documents
        documents = []
        for doc in documents_data:
            documents.append(DocumentMetadata(
                id=doc['id'],
                filename=doc['filename'],
                original_filename=doc['original_filename'],
                file_size=doc['file_size'],
                file_type=doc['file_type'],
                category=doc['category'],
                subcategory=doc['subcategory'],
                description=doc['description'],
                tags=json.loads(doc['tags']) if doc['tags'] else [],
                customer_id=doc['customer_id'],
                customer_name=doc['customer_name'],
                upload_date=doc['created_at'],
                uploaded_by=doc['uploaded_by'],
                expires_at=doc['expires_at'],
                status=doc['status'],
                version=doc['version'],
                file_hash=doc['file_hash'],
                download_url=f"/api/documents/{doc['id']}/download"
            ))
        
        await conn.close()
        
        total_pages = (total_count + request.limit - 1) // request.limit
        
        return DocumentListResponse(
            success=True,
            message=f"Found {len(documents)} documents",
            documents=documents,
            total_count=total_count,
            page=request.page,
            total_pages=total_pages
        )
        
    except Exception as e:
        return DocumentListResponse(
            success=False,
            message=f"Error listing documents: {str(e)}",
            documents=[],
            total_count=0,
            page=request.page,
            total_pages=0
        )

@router.post("/approve")
async def approve_document(request: DocumentApprovalRequest, user: AuthorizedUser) -> DocumentApprovalResponse:
    """
    Approve or reject a document
    """
    try:
        conn = await get_db_connection()
        
        # Validate action
        if request.action not in ["approve", "reject"]:
            return DocumentApprovalResponse(
                success=False,
                message="Invalid action. Must be 'approve' or 'reject'",
                document_id=request.document_id,
                new_status="unknown"
            )
        
        new_status = "approved" if request.action == "approve" else "rejected"
        
        # Update document status
        update_query = """
            UPDATE customer_documents 
            SET status = $1, updated_at = NOW()
            WHERE id = $2
            RETURNING id, original_filename
        """
        
        result = await conn.fetchrow(update_query, new_status, request.document_id)
        
        if not result:
            await conn.close()
            return DocumentApprovalResponse(
                success=False,
                message="Document not found",
                document_id=request.document_id,
                new_status="unknown"
            )
        
        # Log approval action
        audit_query = """
            INSERT INTO document_audit_trail (document_id, action, notes, performed_by, created_at)
            VALUES ($1, $2, $3, $4, NOW())
        """
        
        audit_notes = request.notes or f"Document {request.action}d by user"
        await conn.execute(audit_query, request.document_id, request.action, audit_notes, user.sub)
        
        await conn.close()
        
        return DocumentApprovalResponse(
            success=True,
            message=f"Document '{result['original_filename']}' {request.action}d successfully",
            document_id=request.document_id,
            new_status=new_status
        )
        
    except Exception as e:
        return DocumentApprovalResponse(
            success=False,
            message=f"Error processing document approval: {str(e)}",
            document_id=request.document_id,
            new_status="error"
        )

@router.get("/analytics")
async def get_customer_document_analytics(user: AuthorizedUser) -> DocumentAnalyticsResponse:
    """
    Get document management analytics
    """
    try:
        conn = await get_db_connection()
        
        # Get total documents and size
        total_query = """
            SELECT 
                COUNT(*) as total_documents,
                COALESCE(SUM(file_size), 0) as total_size_bytes
            FROM customer_documents
        """
        total_result = await conn.fetchrow(total_query)
        
        total_documents = total_result['total_documents']
        total_size_gb = total_result['total_size_bytes'] / (1024 * 1024 * 1024)  # Convert to GB
        
        # Get category statistics
        category_query = """
            SELECT 
                category,
                COUNT(*) as total_documents,
                SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending_approval,
                SUM(CASE WHEN status = 'approved' THEN 1 ELSE 0 END) as approved_documents,
                COALESCE(SUM(file_size), 0) / (1024 * 1024) as total_size_mb,
                MAX(created_at) as latest_upload
            FROM customer_documents
            GROUP BY category
            ORDER BY total_documents DESC
        """
        category_results = await conn.fetch(category_query)
        
        category_stats = [
            DocumentCategoryStats(
                category=row['category'],
                total_documents=row['total_documents'],
                pending_approval=row['pending_approval'],
                approved_documents=row['approved_documents'],
                total_size_mb=round(row['total_size_mb'], 2),
                latest_upload=row['latest_upload']
            )
            for row in category_results
        ]
        
        # Get recent uploads (last 10)
        recent_query = """
            SELECT d.*, c.name as customer_name
            FROM customer_documents d
            LEFT JOIN customers c ON d.customer_id = c.id
            ORDER BY d.created_at DESC
            LIMIT 10
        """
        recent_results = await conn.fetch(recent_query)
        
        recent_uploads = [
            DocumentMetadata(
                id=doc['id'],
                filename=doc['filename'],
                original_filename=doc['original_filename'],
                file_size=doc['file_size'],
                file_type=doc['file_type'],
                category=doc['category'],
                subcategory=doc['subcategory'],
                description=doc['description'],
                tags=json.loads(doc['tags']) if doc['tags'] else [],
                customer_id=doc['customer_id'],
                customer_name=doc['customer_name'],
                upload_date=doc['created_at'],
                uploaded_by=doc['uploaded_by'],
                expires_at=doc['expires_at'],
                status=doc['status'],
                version=doc['version'],
                file_hash=doc['file_hash'],
                download_url=f"/api/documents/{doc['id']}/download"
            )
            for doc in recent_results
        ]
        
        # Get expiring documents (next 30 days)
        expiring_query = """
            SELECT d.*, c.name as customer_name
            FROM customer_documents d
            LEFT JOIN customers c ON d.customer_id = c.id
            WHERE d.expires_at IS NOT NULL 
              AND d.expires_at <= NOW() + INTERVAL '30 days'
              AND d.status = 'approved'
            ORDER BY d.expires_at ASC
            LIMIT 10
        """
        expiring_results = await conn.fetch(expiring_query)
        
        expiring_soon = [
            DocumentMetadata(
                id=doc['id'],
                filename=doc['filename'],
                original_filename=doc['original_filename'],
                file_size=doc['file_size'],
                file_type=doc['file_type'],
                category=doc['category'],
                subcategory=doc['subcategory'],
                description=doc['description'],
                tags=json.loads(doc['tags']) if doc['tags'] else [],
                customer_id=doc['customer_id'],
                customer_name=doc['customer_name'],
                upload_date=doc['created_at'],
                uploaded_by=doc['uploaded_by'],
                expires_at=doc['expires_at'],
                status=doc['status'],
                version=doc['version'],
                file_hash=doc['file_hash'],
                download_url=f"/api/documents/{doc['id']}/download"
            )
            for doc in expiring_results
        ]
        
        await conn.close()
        
        return DocumentAnalyticsResponse(
            success=True,
            message=f"Document analytics retrieved successfully",
            total_documents=total_documents,
            total_size_gb=round(total_size_gb, 2),
            category_stats=category_stats,
            recent_uploads=recent_uploads,
            expiring_soon=expiring_soon
        )
        
    except Exception as e:
        return DocumentAnalyticsResponse(
            success=False,
            message=f"Error retrieving document analytics: {str(e)}",
            total_documents=0,
            total_size_gb=0.0,
            category_stats=[],
            recent_uploads=[],
            expiring_soon=[]
        )
