

"""VAT Service for EU Tax Compliance

Handles VAT rate lookup, calculation, and compliance logic for EU customers.
"""

from typing import Dict, Optional, Tuple
from enum import Enum


class VATType(Enum):
    """VAT treatment types"""
    B2C = "b2c"  # Business to Consumer - VAT applied
    B2B_REVERSE_CHARGE = "b2b_reverse_charge"  # Business to Business - Reverse charge
    EXPORT = "export"  # Non-EU export - No VAT
    DOMESTIC = "domestic"  # Domestic Luxembourg - Local VAT


class VATService:
    """Service for VAT calculations and compliance"""
    
    # EU VAT rates by country code (2024 standard rates)
    EU_VAT_RATES = {
        "AT": 20.0,  # Austria
        "BE": 21.0,  # Belgium  
        "BG": 20.0,  # Bulgaria
        "HR": 25.0,  # Croatia
        "CY": 19.0,  # Cyprus
        "CZ": 21.0,  # Czech Republic
        "DK": 25.0,  # Denmark
        "EE": 22.0,  # Estonia
        "FI": 24.0,  # Finland
        "FR": 20.0,  # France
        "DE": 19.0,  # Germany
        "GR": 24.0,  # Greece
        "HU": 27.0,  # Hungary
        "IE": 23.0,  # Ireland
        "IT": 22.0,  # Italy
        "LV": 21.0,  # Latvia
        "LT": 21.0,  # Lithuania
        "LU": 17.0,  # Luxembourg (Respectus home country)
        "MT": 18.0,  # Malta
        "NL": 21.0,  # Netherlands
        "PL": 23.0,  # Poland
        "PT": 23.0,  # Portugal
        "RO": 19.0,  # Romania
        "SK": 20.0,  # Slovakia
        "SI": 22.0,  # Slovenia
        "ES": 21.0,  # Spain
        "SE": 25.0,  # Sweden
    }
    
    # Country name to ISO code mapping for convenience
    COUNTRY_MAPPING = {
        "Austria": "AT",
        "Belgium": "BE",
        "Bulgaria": "BG",
        "Croatia": "HR",
        "Cyprus": "CY",
        "Czech Republic": "CZ", 
        "Czechia": "CZ",
        "Denmark": "DK",
        "Estonia": "EE",
        "Finland": "FI",
        "France": "FR",
        "Germany": "DE",
        "Greece": "GR",
        "Hungary": "HU",
        "Ireland": "IE",
        "Italy": "IT",
        "Latvia": "LV",
        "Lithuania": "LT",
        "Luxembourg": "LU",
        "Malta": "MT",
        "Netherlands": "NL",
        "Poland": "PL",
        "Portugal": "PT",
        "Romania": "RO",
        "Slovakia": "SK",
        "Slovenia": "SI",
        "Spain": "ES",
        "Sweden": "SE",
    }
    
    @classmethod
    def get_country_code(cls, country: str) -> Optional[str]:
        """Convert country name to ISO code"""
        if len(country) == 2:
            return country.upper()
        return cls.COUNTRY_MAPPING.get(country)
    
    @classmethod
    def is_eu_country(cls, country: str) -> bool:
        """Check if country is in EU for VAT purposes"""
        country_code = cls.get_country_code(country)
        return country_code in cls.EU_VAT_RATES
    
    @classmethod
    def get_vat_rate(cls, country: str) -> float:
        """Get VAT rate for country (returns 0 for non-EU)"""
        country_code = cls.get_country_code(country)
        return cls.EU_VAT_RATES.get(country_code, 0.0)
    
    @classmethod
    def is_valid_vat_number(cls, vat_number: Optional[str]) -> bool:
        """Basic VAT number validation (format check)"""
        if not vat_number or not vat_number.strip():
            return False
        
        # Remove spaces and make uppercase
        vat = vat_number.replace(" ", "").upper()
        
        # Basic format validation - EU VAT numbers start with country code
        if len(vat) < 4:  # Minimum: country code + 2 digits
            return False
        
        country_code = vat[:2]
        return country_code in cls.EU_VAT_RATES
    
    @classmethod
    def determine_vat_type(
        cls, 
        customer_country: str, 
        vat_number: Optional[str] = None
    ) -> VATType:
        """Determine VAT treatment type based on customer details"""
        
        # Check if EU country
        if not cls.is_eu_country(customer_country):
            return VATType.EXPORT
        
        # Check if domestic (Luxembourg)
        country_code = cls.get_country_code(customer_country)
        if country_code == "LU":
            return VATType.DOMESTIC
        
        # EU customer - check if B2B with valid VAT number
        if cls.is_valid_vat_number(vat_number):
            return VATType.B2B_REVERSE_CHARGE
        
        # EU consumer (B2C)
        return VATType.B2C
    
    @classmethod
    def calculate_vat(
        cls, 
        net_amount: float, 
        customer_country: str, 
        vat_number: Optional[str] = None
    ) -> Dict[str, float]:
        """Calculate VAT breakdown for a transaction
        
        Args:
            net_amount: Base price excluding VAT
            customer_country: Customer's country
            vat_number: Customer's VAT number (if any)
            
        Returns:
            Dict with net_amount, vat_amount, gross_amount, vat_rate, vat_type
        """
        
        vat_type = cls.determine_vat_type(customer_country, vat_number)
        vat_rate = 0.0
        vat_amount = 0.0
        
        if vat_type == VATType.B2C:
            # EU consumer - apply customer's country VAT rate
            vat_rate = cls.get_vat_rate(customer_country)
            vat_amount = net_amount * (vat_rate / 100)
        elif vat_type == VATType.DOMESTIC:
            # Luxembourg customer - apply Luxembourg VAT
            vat_rate = cls.get_vat_rate("Luxembourg")
            vat_amount = net_amount * (vat_rate / 100)
        # For B2B_REVERSE_CHARGE and EXPORT: vat_amount remains 0
        
        gross_amount = net_amount + vat_amount
        
        return {
            "net_amount": round(net_amount, 2),
            "vat_amount": round(vat_amount, 2),
            "gross_amount": round(gross_amount, 2),
            "vat_rate": vat_rate,
            "vat_type": vat_type.value,
            "country_code": cls.get_country_code(customer_country)
        }
    
    @classmethod
    def format_price_display(
        cls, 
        net_amount: float, 
        customer_country: str, 
        vat_number: Optional[str] = None
    ) -> str:
        """Format price for display to customer - always show VAT-excluded with notice"""
        
        vat_calc = cls.calculate_vat(net_amount, customer_country, vat_number)
        
        # Always show net amount first with VAT notice
        base_display = f"€{vat_calc['net_amount']:.2f} + VAT if applicable"
        
        return base_display
