import math
from typing import List, Dict, Tuple, Optional
from datetime import datetime, timedelta

def calculate_moving_average(values: List[float], window_size: int = 5) -> List[float]:
    """
    Calculate moving average for trend smoothing
    """
    if len(values) < window_size:
        return values
    
    moving_averages = []
    for i in range(len(values) - window_size + 1):
        window = values[i:i + window_size]
        moving_averages.append(sum(window) / window_size)
    
    return moving_averages

def calculate_weighted_risk_score(
    sanctions_weight: float = 0.4,
    pep_weight: float = 0.3,
    adverse_media_weight: float = 0.2,
    other_weight: float = 0.1,
    **kwargs
) -> float:
    """
    Calculate weighted risk score based on various factors
    """
    sanctions_score = kwargs.get('sanctions_matches', 0) * sanctions_weight * 20
    pep_score = kwargs.get('pep_matches', 0) * pep_weight * 15
    adverse_media_score = kwargs.get('adverse_media_matches', 0) * adverse_media_weight * 10
    other_score = kwargs.get('other_matches', 0) * other_weight * 5
    
    total_score = sanctions_score + pep_score + adverse_media_score + other_score
    return min(total_score, 100.0)

def detect_anomalies(values: List[float], threshold_std: float = 2.0) -> List[int]:
    """
    Detect anomalies in risk score data using standard deviation
    """
    if len(values) < 3:
        return []
    
    mean = sum(values) / len(values)
    variance = sum((x - mean) ** 2 for x in values) / len(values)
    std_dev = math.sqrt(variance)
    
    anomaly_indices = []
    for i, value in enumerate(values):
        if abs(value - mean) > threshold_std * std_dev:
            anomaly_indices.append(i)
    
    return anomaly_indices

def calculate_risk_velocity(historical_scores: List[Tuple[datetime, float]]) -> Dict[str, float]:
    """
    Calculate the rate of change (velocity) of risk scores over time
    """
    if len(historical_scores) < 2:
        return {'velocity': 0.0, 'acceleration': 0.0}
    
    # Sort by date
    sorted_scores = sorted(historical_scores, key=lambda x: x[0])
    
    velocities = []
    for i in range(1, len(sorted_scores)):
        date_diff = (sorted_scores[i][0] - sorted_scores[i-1][0]).days
        score_diff = sorted_scores[i][1] - sorted_scores[i-1][1]
        
        if date_diff > 0:
            velocity = score_diff / date_diff  # Points per day
            velocities.append(velocity)
    
    avg_velocity = sum(velocities) / len(velocities) if velocities else 0.0
    
    # Calculate acceleration (change in velocity)
    acceleration = 0.0
    if len(velocities) >= 2:
        velocity_changes = [velocities[i] - velocities[i-1] for i in range(1, len(velocities))]
        acceleration = sum(velocity_changes) / len(velocity_changes)
    
    return {
        'velocity': round(avg_velocity, 4),
        'acceleration': round(acceleration, 6)
    }

def predict_future_risk(
    current_score: float,
    velocity: float,
    acceleration: float,
    days_ahead: int
) -> Dict[str, float]:
    """
    Predict future risk score using kinematic equations
    """
    # Use kinematic equation: future_score = current + velocity*time + 0.5*acceleration*time^2
    predicted_score = current_score + (velocity * days_ahead) + (0.5 * acceleration * days_ahead ** 2)
    
    # Bound the prediction between 0 and 100
    predicted_score = max(0.0, min(100.0, predicted_score))
    
    # Calculate confidence based on historical data consistency
    confidence = max(0.1, 1.0 - abs(acceleration) * 0.1)  # Lower confidence for high acceleration
    confidence = min(0.95, confidence)
    
    return {
        'predicted_score': round(predicted_score, 2),
        'confidence': round(confidence, 2)
    }

def calculate_risk_correlation(
    risk_scores: List[float],
    external_factors: List[float]
) -> float:
    """
    Calculate Pearson correlation between risk scores and external factors
    """
    if len(risk_scores) != len(external_factors) or len(risk_scores) < 2:
        return 0.0
    
    n = len(risk_scores)
    sum_x = sum(risk_scores)
    sum_y = sum(external_factors)
    sum_xy = sum(x * y for x, y in zip(risk_scores, external_factors))
    sum_x2 = sum(x * x for x in risk_scores)
    sum_y2 = sum(y * y for y in external_factors)
    
    numerator = n * sum_xy - sum_x * sum_y
    denominator = math.sqrt((n * sum_x2 - sum_x * sum_x) * (n * sum_y2 - sum_y * sum_y))
    
    correlation = numerator / denominator if denominator != 0 else 0.0
    return round(correlation, 3)

def generate_risk_insights(customer_data: Dict) -> List[str]:
    """
    Generate actionable insights based on customer risk data
    """
    insights = []
    
    current_score = customer_data.get('current_risk_score', 0)
    predicted_score = customer_data.get('predicted_risk_score', 0)
    trend = customer_data.get('risk_trend', 'stable')
    
    # Score-based insights
    if current_score >= 80:
        insights.append("CRITICAL: Immediate review required - customer presents significant compliance risk")
    elif current_score >= 60:
        insights.append("HIGH RISK: Enhanced due diligence recommended")
    
    # Trend-based insights
    if trend == 'increasing' and predicted_score > current_score + 10:
        insights.append("RISING RISK: Customer risk trajectory is concerning - consider increased monitoring")
    elif trend == 'decreasing' and current_score > 40:
        insights.append("IMPROVING: Risk trend is positive but continued monitoring advised")
    
    # Velocity-based insights
    velocity = customer_data.get('risk_velocity', 0)
    if abs(velocity) > 2:  # More than 2 points per day change
        insights.append(f"VOLATILE: Risk score changing rapidly ({velocity:.2f} points/day)")
    
    # Factor-specific insights
    sanctions_matches = customer_data.get('sanctions_matches', 0)
    if sanctions_matches > 0:
        insights.append(f"SANCTIONS ALERT: {sanctions_matches} potential sanctions matches detected")
    
    pep_matches = customer_data.get('pep_matches', 0)
    if pep_matches > 0:
        insights.append(f"PEP EXPOSURE: {pep_matches} politically exposed person connections identified")
    
    return insights
