

import asyncpg
import databutton as db
from app.env import Mode, mode
from contextlib import asynccontextmanager
import gc

# Force clear any existing connection pools
_connection_pools = {}

@asynccontextmanager
async def get_db_connection():
    """Get database connection using asyncpg with forced fresh connection"""
    if mode == Mode.PROD:
        database_url = db.secrets.get("DATABASE_URL_PROD")
    else:
        database_url = db.secrets.get("DATABASE_URL_DEV")
    
    # Force fresh connection to bypass all caching
    conn = await asyncpg.connect(
        database_url, 
        statement_cache_size=0,
        command_timeout=60
    )
    try:
        # Clear any cached statement plans
        await conn.execute("DISCARD PLANS")
        yield conn
    finally:
        await conn.close()

@asynccontextmanager
async def get_admin_db_connection():
    """Get admin database connection using asyncpg with forced fresh connection"""
    if mode == Mode.PROD:
        database_url = db.secrets.get("DATABASE_URL_ADMIN_PROD")
    else:
        database_url = db.secrets.get("DATABASE_URL_ADMIN_DEV")
    
    # Force fresh connection to bypass all caching
    conn = await asyncpg.connect(
        database_url, 
        statement_cache_size=0,
        command_timeout=60
    )
    try:
        # Clear any cached statement plans
        await conn.execute("DISCARD PLANS")
        yield conn
    finally:
        await conn.close()
