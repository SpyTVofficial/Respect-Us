import re
import json
from typing import List, Dict, Optional, Tuple, Any
from dataclasses import dataclass
from enum import Enum

class SectionType(Enum):
    """Types of document sections"""
    TITLE = "title"
    CHAPTER = "chapter"
    ARTICLE = "article"
    SECTION = "section"
    SUBSECTION = "subsection"
    PARAGRAPH = "paragraph"
    ANNEX = "annex"
    APPENDIX = "appendix"
    PREAMBLE = "preamble"
    DEFINITIONS = "definitions"
    REFERENCES = "references"
    FOOTNOTE = "footnote"
    TABLE = "table"
    LIST = "list"

@dataclass
class DocumentSection:
    """Enhanced document section with hierarchical structure"""
    id: Optional[str] = None
    section_number: str = ""
    title: str = ""
    content: str = ""
    section_type: SectionType = SectionType.SECTION
    level: int = 1
    parent_id: Optional[str] = None
    children: List['DocumentSection'] = None
    display_order: int = 0
    cross_references: List[str] = None
    citations: List[str] = None
    definitions: List[str] = None
    keywords: List[str] = None
    regulatory_references: List[str] = None
    
    def __post_init__(self):
        if self.children is None:
            self.children = []
        if self.cross_references is None:
            self.cross_references = []
        if self.citations is None:
            self.citations = []
        if self.definitions is None:
            self.definitions = []
        if self.keywords is None:
            self.keywords = []
        if self.regulatory_references is None:
            self.regulatory_references = []

class EnhancedDocumentParser:
    """Advanced document parser with hierarchical section detection and cross-reference linking"""
    
    def __init__(self):
        self.section_patterns = {
            # EU Regulation patterns
            'eu_chapter': r'\b(?:CHAPTER|Chapter)\s+([IVXLCDM]+|\d+)\s*[-:]?\s*([^\n]{1,100})\n',
            'eu_article': r'\b(?:Article|ARTICLE)\s+(\d+[a-z]?)\s*[-:]?\s*([^\n]{1,100})?\n',
            'eu_section': r'\b(?:Section|SECTION)\s+(\d+[a-z]?)\s*[-:]?\s*([^\n]{1,100})?\n',
            
            # US CFR patterns
            'us_part': r'\b(?:PART|Part)\s+(\d+)\s*[-:]?\s*([^\n]{1,100})\n',
            'us_subpart': r'\b(?:Subpart|SUBPART)\s+([A-Z])\s*[-:]?\s*([^\n]{1,100})\n',
            'us_section': r'\b§\s*(\d+\.\d+)\s*([^\n]{1,100})?\n',
            
            # Generic numbered sections
            'numbered_section': r'^\s*(\d+(?:\.\d+)*)\s+([^\n]{10,100})\n',
            'lettered_section': r'^\s*\(([a-z])\)\s+([^\n]{5,100})\n',
            'roman_section': r'^\s*\(([ivxlcdm]+)\)\s+([^\n]{5,100})\n',
            
            # Special sections
            'preamble': r'\b(?:PREAMBLE|Preamble|WHEREAS)\b',
            'definitions': r'\b(?:DEFINITIONS|Definitions|For the purposes of this)\b',
            'annex': r'\b(?:ANNEX|Annex)\s+([IVXLCDM]+|\d+|[A-Z])\s*[-:]?\s*([^\n]{1,100})?\n',
            'appendix': r'\b(?:APPENDIX|Appendix)\s+([IVXLCDM]+|\d+|[A-Z])\s*[-:]?\s*([^\n]{1,100})?\n'
        }
        
        self.cross_reference_patterns = {
            # EU regulation references
            'eu_regulation': r'\b(?:Regulation|REGULATION)\s+\(?(?:EU|EC|EEC)\)?\s+(\d+)/(\d+)\b',
            'eu_directive': r'\b(?:Directive|DIRECTIVE)\s+\(?(?:EU|EC|EEC)\)?\s+(\d+)/(\d+)\b',
            'eu_article_ref': r'\b(?:Article|ARTICLE)\s+(\d+[a-z]?)\b',
            
            # US regulation references
            'us_cfr': r'\b(\d+)\s+CFR\s+(\d+(?:\.\d+)?)\b',
            'us_section_ref': r'\b§\s*(\d+\.\d+)\b',
            'us_usc': r'\b(\d+)\s+U\.?S\.?C\.?\s+§?\s*(\d+[a-z]?)\b',
            
            # Generic references
            'section_ref': r'\b(?:section|Section|SECTION)\s+(\d+(?:\.\d+)*)\b',
            'paragraph_ref': r'\b(?:paragraph|Paragraph|PARAGRAPH)\s+(\d+(?:\.\d+)*|\([a-z]\))\b',
            'annex_ref': r'\b(?:Annex|ANNEX)\s+([IVXLCDM]+|\d+|[A-Z])\b',
            'appendix_ref': r'\b(?:Appendix|APPENDIX)\s+([IVXLCDM]+|\d+|[A-Z])\b'
        }
        
        self.definition_patterns = [
            r'"([^"]{3,50})"\s+means\b',
            r'"([^"]{3,50})"\s+shall mean\b',
            r'\b([A-Z][a-z\s]{3,30})\s+means\b',
            r'For the purposes of this [^,]+,\s+"([^"]{3,50})"'
        ]
    
    def parse_document(self, text: str, document_title: str = "") -> List[DocumentSection]:
        """Parse document into hierarchical sections with enhanced structure detection"""
        
        if not text or not text.strip():
            return []
        
        # Clean and normalize text
        text = self._clean_text(text)
        
        # Detect document structure
        sections = self._detect_sections(text)
        
        # Build hierarchical structure
        hierarchical_sections = self._build_hierarchy(sections)
        
        # Extract cross-references and enhance sections
        self._enhance_sections(hierarchical_sections, text)
        
        return hierarchical_sections
    
    def _clean_text(self, text: str) -> str:
        """Clean and normalize text for processing"""
        # Remove excessive whitespace but preserve structure
        text = re.sub(r'\r\n', '\n', text)
        text = re.sub(r'\r', '\n', text)
        text = re.sub(r'\n{3,}', '\n\n', text)
        text = re.sub(r'[ \t]+', ' ', text)
        
        # Remove page numbers and headers/footers (basic)
        text = re.sub(r'\n\s*Page \d+\s*\n', '\n', text, flags=re.IGNORECASE)
        text = re.sub(r'\n\s*\d+\s*\n(?=\s*[A-Z])', '\n', text)
        
        return text.strip()
    
    def _detect_sections(self, text: str) -> List[DocumentSection]:
        """Detect sections using pattern matching"""
        sections = []
        lines = text.split('\n')
        current_position = 0
        section_id_counter = 1
        
        # Track position in text for content extraction
        text_positions = []
        current_pos = 0
        for line in lines:
            text_positions.append(current_pos)
            current_pos += len(line) + 1  # +1 for newline
        
        i = 0
        while i < len(lines):
            line = lines[i]
            section = None
            
            # Try each pattern
            for pattern_name, pattern in self.section_patterns.items():
                match = re.search(pattern, line + '\n', re.MULTILINE | re.IGNORECASE)
                if match:
                    section = self._create_section_from_match(
                        pattern_name, match, section_id_counter, i
                    )
                    section_id_counter += 1
                    break
            
            if section:
                # Find content for this section
                content_start = i + 1
                content_end = self._find_next_section_start(lines, content_start)
                
                if content_start < len(lines):
                    section.content = '\n'.join(lines[content_start:content_end]).strip()
                
                sections.append(section)
                i = content_end - 1  # Skip to next section
            
            i += 1
        
        # If no sections found, create a single section
        if not sections:
            sections.append(DocumentSection(
                id="section_1",
                section_number="1",
                title="Document Content",
                content=text,
                section_type=SectionType.SECTION,
                level=1,
                display_order=1
            ))
        
        return sections
    
    def _create_section_from_match(self, pattern_name: str, match, section_id: int, line_index: int) -> DocumentSection:
        """Create a DocumentSection from a regex match"""
        
        section_number = match.group(1) if match.groups() else str(section_id)
        title = match.group(2) if len(match.groups()) > 1 and match.group(2) else ""
        
        # Determine section type and level
        section_type, level = self._determine_section_type_and_level(pattern_name, section_number)
        
        return DocumentSection(
            id=f"section_{section_id}",
            section_number=section_number,
            title=title.strip(),
            section_type=section_type,
            level=level,
            display_order=section_id
        )
    
    def _determine_section_type_and_level(self, pattern_name: str, section_number: str) -> Tuple[SectionType, int]:
        """Determine section type and hierarchical level"""
        
        type_mapping = {
            'eu_chapter': (SectionType.CHAPTER, 1),
            'eu_article': (SectionType.ARTICLE, 2),
            'eu_section': (SectionType.SECTION, 3),
            'us_part': (SectionType.CHAPTER, 1),
            'us_subpart': (SectionType.SECTION, 2),
            'us_section': (SectionType.SUBSECTION, 3),
            'numbered_section': (SectionType.SECTION, self._get_numbering_level(section_number)),
            'lettered_section': (SectionType.SUBSECTION, 4),
            'roman_section': (SectionType.SUBSECTION, 4),
            'preamble': (SectionType.PREAMBLE, 1),
            'definitions': (SectionType.DEFINITIONS, 2),
            'annex': (SectionType.ANNEX, 1),
            'appendix': (SectionType.APPENDIX, 1)
        }
        
        return type_mapping.get(pattern_name, (SectionType.SECTION, 2))
    
    def _get_numbering_level(self, section_number: str) -> int:
        """Determine hierarchical level from numbering scheme"""
        if '.' not in section_number:
            return 1
        return len(section_number.split('.')) + 1
    
    def _find_next_section_start(self, lines: List[str], start_index: int) -> int:
        """Find the start of the next section"""
        for i in range(start_index, len(lines)):
            line = lines[i]
            for pattern in self.section_patterns.values():
                if re.search(pattern, line + '\n', re.MULTILINE | re.IGNORECASE):
                    return i
        return len(lines)
    
    def _build_hierarchy(self, sections: List[DocumentSection]) -> List[DocumentSection]:
        """Build hierarchical structure from flat list of sections"""
        if not sections:
            return []
        
        # Sort by display order
        sections.sort(key=lambda s: s.display_order)
        
        # Build parent-child relationships
        root_sections = []
        section_stack = []  # Stack to track current parents at each level
        
        for section in sections:
            # Pop sections from stack that are at same or higher level
            while section_stack and section_stack[-1].level >= section.level:
                section_stack.pop()
            
            # Set parent if we have one in the stack
            if section_stack:
                parent = section_stack[-1]
                section.parent_id = parent.id
                parent.children.append(section)
            else:
                root_sections.append(section)
            
            # Add to stack for potential children
            section_stack.append(section)
        
        return root_sections
    
    def _enhance_sections(self, sections: List[DocumentSection], full_text: str):
        """Enhance sections with cross-references, citations, and other metadata"""
        
        def enhance_section(section: DocumentSection):
            # Extract cross-references
            section.cross_references = self._extract_cross_references(section.content)
            
            # Extract regulatory references
            section.regulatory_references = self._extract_regulatory_references(section.content)
            
            # Extract definitions
            section.definitions = self._extract_definitions(section.content)
            
            # Extract keywords
            section.keywords = self._extract_keywords(section.content)
            
            # Recursively enhance children
            for child in section.children:
                enhance_section(child)
        
        for section in sections:
            enhance_section(section)
    
    def _extract_cross_references(self, text: str) -> List[str]:
        """Extract cross-references from text"""
        references = []
        
        for ref_type, pattern in self.cross_reference_patterns.items():
            matches = re.findall(pattern, text, re.IGNORECASE)
            for match in matches:
                if isinstance(match, tuple):
                    ref = f"{ref_type}: {' '.join(match)}"
                else:
                    ref = f"{ref_type}: {match}"
                references.append(ref)
        
        return list(set(references))  # Remove duplicates
    
    def _extract_regulatory_references(self, text: str) -> List[str]:
        """Extract specific regulatory references"""
        references = []
        
        # Common regulatory references
        patterns = [
            r'\b(?:EAR|ITAR|OFAC|ECCN|USML|CCL)\b',
            r'\b\d+\s+CFR\s+\d+(?:\.\d+)?\b',
            r'\b(?:Regulation|Directive)\s+\(?(?:EU|EC)\)?\s+\d+/\d+\b'
        ]
        
        for pattern in patterns:
            matches = re.findall(pattern, text, re.IGNORECASE)
            references.extend(matches)
        
        return list(set(references))
    
    def _extract_definitions(self, text: str) -> List[str]:
        """Extract defined terms from text"""
        definitions = []
        
        for pattern in self.definition_patterns:
            matches = re.findall(pattern, text, re.IGNORECASE)
            definitions.extend(matches)
        
        return list(set(definitions))
    
    def _extract_keywords(self, text: str) -> List[str]:
        """Extract important keywords from text"""
        # Common export control and regulatory keywords
        keywords = [
            'export', 'import', 'dual-use', 'controlled', 'restricted',
            'license', 'authorization', 'prohibition', 'embargo', 'sanction',
            'technology transfer', 'end-user', 'end-use', 'deemed export',
            'classification', 'compliance', 'violation', 'penalty'
        ]
        
        found_keywords = []
        text_lower = text.lower()
        
        for keyword in keywords:
            if keyword.lower() in text_lower:
                found_keywords.append(keyword)
        
        return found_keywords
    
    def flatten_sections(self, sections: List[DocumentSection]) -> List[Dict[str, Any]]:
        """Flatten hierarchical sections for database storage"""
        
        def flatten_section(section: DocumentSection, result: List[Dict[str, Any]]):
            section_dict = {
                'section_number': section.section_number,
                'section_title': section.title,
                'section_content': section.content,
                'section_type': section.section_type.value,
                'level': section.level,
                'parent_section_id': section.parent_id,
                'display_order': section.display_order,
                'cross_references': json.dumps(section.cross_references),
                'regulatory_references': json.dumps(section.regulatory_references),
                'definitions': json.dumps(section.definitions),
                'keywords': json.dumps(section.keywords)
            }
            result.append(section_dict)
            
            # Recursively flatten children
            for child in section.children:
                flatten_section(child, result)
        
        flattened = []
        for section in sections:
            flatten_section(section, flattened)
        
        return flattened
    
    def create_cross_reference_map(self, sections: List[DocumentSection]) -> Dict[str, List[str]]:
        """Create a map of cross-references between sections"""
        
        cross_ref_map = {}
        
        def process_section(section: DocumentSection):
            if section.cross_references:
                cross_ref_map[section.id] = section.cross_references
            
            for child in section.children:
                process_section(child)
        
        for section in sections:
            process_section(section)
        
        return cross_ref_map
    
    def extract_table_of_contents(self, sections: List[DocumentSection]) -> List[Dict[str, Any]]:
        """Extract table of contents structure"""
        
        def build_toc(section: DocumentSection, toc: List[Dict[str, Any]]):
            toc_entry = {
                'id': section.id,
                'section_number': section.section_number,
                'title': section.title,
                'level': section.level,
                'section_type': section.section_type.value,
                'children': []
            }
            
            # Add children
            for child in section.children:
                build_toc(child, toc_entry['children'])
            
            toc.append(toc_entry)
        
        toc = []
        for section in sections:
            build_toc(section, toc)
        
        return toc
