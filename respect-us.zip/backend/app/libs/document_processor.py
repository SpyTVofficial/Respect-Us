"""
Comprehensive Document Processing Library for Knowledge Base
Supports OCR, text extraction, and multiple document formats
"""

import io
import os
import re
from typing import Dict, List, Optional, Tuple, Any
from datetime import datetime
import json

# Core processing imports
import pytesseract
from PIL import Image
from pdf2image import convert_from_bytes
from pypdf import PdfReader
import docx

# Data structures
from dataclasses import dataclass
from enum import Enum

class DocumentType(Enum):
    PDF = "pdf"
    PDF_SCANNED = "pdf_scanned"
    WORD = "word"
    HTML = "html"
    TEXT = "text"
    IMAGE = "image"
    XML = "xml"
    UNKNOWN = "unknown"

@dataclass
class DocumentSection:
    """Represents a hierarchical section within a document"""
    id: str
    title: str
    content: str
    level: int  # 1=chapter, 2=section, 3=subsection, etc.
    parent_id: Optional[str] = None
    page_number: Optional[int] = None
    order: int = 0
    metadata: Dict[str, Any] = None

@dataclass
class ProcessingResult:
    """Results from document processing"""
    success: bool
    document_type: DocumentType
    full_text: str
    sections: List[DocumentSection]
    metadata: Dict[str, Any]
    processing_time: float
    errors: List[str]
    confidence_score: Optional[float] = None  # OCR confidence

class DocumentProcessor:
    """Main document processing class with OCR capabilities"""
    
    def __init__(self):
        self.supported_formats = {
            'application/pdf': DocumentType.PDF,
            'application/vnd.openxmlformats-officedocument.wordprocessingml.document': DocumentType.WORD,
            'application/msword': DocumentType.WORD,
            'text/html': DocumentType.HTML,
            'text/plain': DocumentType.TEXT,
            'text/xml': DocumentType.XML,
            'application/xml': DocumentType.XML,
            'image/jpeg': DocumentType.IMAGE,
            'image/jpg': DocumentType.IMAGE,
            'image/png': DocumentType.IMAGE,
            'image/tiff': DocumentType.IMAGE,
            'image/bmp': DocumentType.IMAGE
        }
    
    def detect_document_type(self, content: bytes, content_type: str) -> DocumentType:
        """Detect document type from content and MIME type"""
        if content_type in self.supported_formats:
            detected_type = self.supported_formats[content_type]
            
            # Special case: Check if PDF is scanned
            if detected_type == DocumentType.PDF:
                if self._is_scanned_pdf(content):
                    return DocumentType.PDF_SCANNED
            
            return detected_type
        
        return DocumentType.UNKNOWN
    
    def _is_scanned_pdf(self, content: bytes) -> bool:
        """Check if PDF is scanned (image-based) vs text-based"""
        try:
            reader = PdfReader(io.BytesIO(content))
            if len(reader.pages) == 0:
                return False
            
            # Check first few pages for text content
            text_content = ""
            pages_to_check = min(3, len(reader.pages))
            
            for i in range(pages_to_check):
                page_text = reader.pages[i].extract_text().strip()
                text_content += page_text
            
            # If very little text found, likely scanned
            return len(text_content.strip()) < 100
            
        except Exception:
            return True  # Assume scanned if can't read text
    
    def process_document(self, content: bytes, content_type: str, filename: str = None) -> ProcessingResult:
        """Main document processing entry point"""
        start_time = datetime.now()
        errors = []
        
        # Detect document type
        doc_type = self.detect_document_type(content, content_type)
        
        try:
            if doc_type == DocumentType.PDF:
                result = self._process_text_pdf(content)
            elif doc_type == DocumentType.PDF_SCANNED:
                result = self._process_scanned_pdf(content)
            elif doc_type == DocumentType.WORD:
                result = self._process_word_document(content)
            elif doc_type == DocumentType.HTML:
                result = self._process_html_document(content)
            elif doc_type == DocumentType.TEXT:
                result = self._process_text_document(content)
            elif doc_type == DocumentType.IMAGE:
                result = self._process_image_document(content)
            elif doc_type == DocumentType.XML:
                result = self._process_xml_document(content)
            else:
                return ProcessingResult(
                    success=False,
                    document_type=doc_type,
                    full_text="",
                    sections=[],
                    metadata={"filename": filename},
                    processing_time=0,
                    errors=[f"Unsupported document type: {doc_type}"]
                )
            
            # Calculate processing time
            processing_time = (datetime.now() - start_time).total_seconds()
            
            # Parse sections from extracted text
            sections = self._parse_document_sections(result["text"])
            
            return ProcessingResult(
                success=True,
                document_type=doc_type,
                full_text=result["text"],
                sections=sections,
                metadata={
                    "filename": filename,
                    "page_count": result.get("page_count", 0),
                    "language": result.get("language", "unknown"),
                    **result.get("metadata", {})
                },
                processing_time=processing_time,
                errors=result.get("errors", []),
                confidence_score=result.get("confidence", None)
            )
            
        except Exception as e:
            processing_time = (datetime.now() - start_time).total_seconds()
            return ProcessingResult(
                success=False,
                document_type=doc_type,
                full_text="",
                sections=[],
                metadata={"filename": filename},
                processing_time=processing_time,
                errors=[f"Processing error: {str(e)}"]
            )
    
    def _process_text_pdf(self, content: bytes) -> Dict[str, Any]:
        """Process text-based PDF documents"""
        reader = PdfReader(io.BytesIO(content))
        full_text = ""
        
        for page_num, page in enumerate(reader.pages, 1):
            page_text = page.extract_text()
            full_text += f"\n\n[Page {page_num}]\n{page_text}"
        
        return {
            "text": full_text.strip(),
            "page_count": len(reader.pages),
            "metadata": {
                "pdf_metadata": reader.metadata if reader.metadata else {}
            }
        }
    
    def _process_scanned_pdf(self, content: bytes) -> Dict[str, Any]:
        """Process scanned/image-based PDF documents using OCR"""
        try:
            # Convert PDF to images
            images = convert_from_bytes(content, dpi=300)
            
            full_text = ""
            total_confidence = 0
            confidence_count = 0
            
            for page_num, image in enumerate(images, 1):
                # Perform OCR on each page
                ocr_data = pytesseract.image_to_data(image, output_type=pytesseract.Output.DICT)
                
                # Extract text and calculate confidence
                page_text = pytesseract.image_to_string(image, config='--psm 6')
                
                # Calculate average confidence for this page
                confidences = [int(conf) for conf in ocr_data['conf'] if int(conf) > 0]
                if confidences:
                    page_confidence = sum(confidences) / len(confidences)
                    total_confidence += page_confidence
                    confidence_count += 1
                
                full_text += f"\n\n[Page {page_num}]\n{page_text}"
            
            # Calculate overall confidence
            overall_confidence = total_confidence / confidence_count if confidence_count > 0 else 0
            
            return {
                "text": full_text.strip(),
                "page_count": len(images),
                "confidence": overall_confidence,
                "metadata": {
                    "ocr_processed": True,
                    "dpi": 300
                }
            }
            
        except Exception as e:
            raise Exception(f"OCR processing failed: {str(e)}")
    
    def _process_word_document(self, content: bytes) -> Dict[str, Any]:
        """Process Microsoft Word documents"""
        doc = docx.Document(io.BytesIO(content))
        
        full_text = ""
        for paragraph in doc.paragraphs:
            full_text += paragraph.text + "\n"
        
        # Extract tables
        for table in doc.tables:
            for row in table.rows:
                row_text = "\t".join([cell.text for cell in row.cells])
                full_text += row_text + "\n"
        
        return {
            "text": full_text.strip(),
            "metadata": {
                "paragraph_count": len(doc.paragraphs),
                "table_count": len(doc.tables)
            }
        }
    
    def _process_html_document(self, content: bytes) -> Dict[str, Any]:
        """Process HTML documents"""
        try:
            from bs4 import BeautifulSoup
        except ImportError:
            # Fallback: simple HTML tag removal
            text = content.decode('utf-8', errors='ignore')
            text = re.sub(r'<[^>]+>', '', text)
            return {"text": text.strip()}
        
        soup = BeautifulSoup(content, 'html.parser')
        
        # Remove script and style elements
        for script in soup(["script", "style"]):
            script.decompose()
        
        # Extract text
        text = soup.get_text()
        
        # Clean up whitespace
        lines = (line.strip() for line in text.splitlines())
        chunks = (phrase.strip() for line in lines for phrase in line.split("  "))
        text = '\n'.join(chunk for chunk in chunks if chunk)
        
        return {
            "text": text,
            "metadata": {
                "title": soup.title.string if soup.title else None
            }
        }
    
    def _process_text_document(self, content: bytes) -> Dict[str, Any]:
        """Process plain text documents"""
        text = content.decode('utf-8', errors='ignore')
        return {"text": text.strip()}
    
    def _process_image_document(self, content: bytes) -> Dict[str, Any]:
        """Process image documents using OCR"""
        try:
            image = Image.open(io.BytesIO(content))
            
            # Perform OCR
            ocr_data = pytesseract.image_to_data(image, output_type=pytesseract.Output.DICT)
            text = pytesseract.image_to_string(image, config='--psm 6')
            
            # Calculate confidence
            confidences = [int(conf) for conf in ocr_data['conf'] if int(conf) > 0]
            confidence = sum(confidences) / len(confidences) if confidences else 0
            
            return {
                "text": text.strip(),
                "confidence": confidence,
                "metadata": {
                    "image_size": image.size,
                    "image_mode": image.mode,
                    "ocr_processed": True
                }
            }
            
        except Exception as e:
            raise Exception(f"Image OCR processing failed: {str(e)}")
    
    def _process_xml_document(self, content: bytes) -> Dict[str, Any]:
        """Process XML documents"""
        try:
            import xml.etree.ElementTree as ET
        except ImportError:
            # Fallback: treat as text
            return self._process_text_document(content)
        
        try:
            root = ET.fromstring(content)
            
            # Extract all text content
            def extract_text(element):
                text = element.text or ""
                for child in element:
                    text += extract_text(child)
                    if child.tail:
                        text += child.tail
                return text
            
            full_text = extract_text(root)
            
            return {
                "text": full_text.strip(),
                "metadata": {
                    "root_tag": root.tag,
                    "xml_processed": True
                }
            }
            
        except ET.ParseError:
            # Fallback to text processing
            return self._process_text_document(content)
    
    def _parse_document_sections(self, text: str) -> List[DocumentSection]:
        """Parse hierarchical sections from document text"""
        sections = []
        
        # Common regulatory document patterns
        patterns = [
            # Articles, Chapters, Sections
            (r'^(ARTICLE|Article|CHAPTER|Chapter)\s+(\d+|[IVXLCDM]+)[\.:]?\s*(.+)$', 1),
            (r'^(SECTION|Section)\s+(\d+|[IVXLCDM]+)[\.:]?\s*(.+)$', 2),
            (r'^(\d+\.\d+)\s+(.+)$', 3),  # 1.1, 2.3, etc.
            (r'^(\d+\.\d+\.\d+)\s+(.+)$', 4),  # 1.1.1, 2.3.4, etc.
            # Annexes
            (r'^(ANNEX|Annex)\s+(\d+|[A-Z]+)[\.:]?\s*(.+)$', 1),
        ]
        
        lines = text.split('\n')
        current_page = 1
        section_counter = 0
        
        for line_num, line in enumerate(lines):
            line = line.strip()
            
            # Track page numbers
            page_match = re.match(r'\[Page (\d+)\]', line)
            if page_match:
                current_page = int(page_match.group(1))
                continue
            
            # Check for section headers
            for pattern, level in patterns:
                match = re.match(pattern, line, re.IGNORECASE)
                if match:
                    section_counter += 1
                    
                    # Extract section content (next 20 lines or until next section)
                    content_lines = []
                    for i in range(line_num + 1, min(line_num + 21, len(lines))):
                        next_line = lines[i].strip()
                        if any(re.match(p, next_line, re.IGNORECASE) for p, _ in patterns):
                            break
                        if next_line and not re.match(r'\[Page \d+\]', next_line):
                            content_lines.append(next_line)
                    
                    section = DocumentSection(
                        id=f"section_{section_counter}",
                        title=line.strip(),
                        content='\n'.join(content_lines),
                        level=level,
                        page_number=current_page,
                        order=section_counter
                    )
                    sections.append(section)
                    break
        
        return sections
    
    def extract_cross_references(self, text: str) -> List[Dict[str, str]]:
        """Extract cross-references between regulations"""
        references = []
        
        # Common reference patterns
        patterns = [
            r'Article\s+(\d+|[IVXLCDM]+)',
            r'Section\s+(\d+(?:\.\d+)*)',
            r'Regulation\s+\((?:EU|EC)\)\s+(\d+/\d+)',
            r'Directive\s+(\d{4}/\d+/EC)',
            r'see\s+also\s+([^\n\.]+)',
            r'pursuant\s+to\s+([^\n\.]+)',
            r'as\s+defined\s+in\s+([^\n\.]+)'
        ]
        
        for pattern in patterns:
            matches = re.finditer(pattern, text, re.IGNORECASE)
            for match in matches:
                references.append({
                    "type": "cross_reference",
                    "text": match.group(0),
                    "target": match.group(1),
                    "context": text[max(0, match.start()-50):match.end()+50]
                })
        
        return references

# Helper functions for integration
def process_uploaded_document(content: bytes, content_type: str, filename: str = None) -> ProcessingResult:
    """Convenience function for processing uploaded documents"""
    processor = DocumentProcessor()
    return processor.process_document(content, content_type, filename)

def extract_document_metadata(content: bytes, content_type: str) -> Dict[str, Any]:
    """Extract metadata from document without full processing"""
    processor = DocumentProcessor()
    doc_type = processor.detect_document_type(content, content_type)
    
    metadata = {
        "document_type": doc_type.value,
        "file_size": len(content),
        "processing_required": doc_type in [DocumentType.PDF_SCANNED, DocumentType.IMAGE]
    }
    
    return metadata
