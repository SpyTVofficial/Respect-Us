"""
Regulatory Feeds Library for Automated Content Updates
Monitors official regulatory sources for new and updated regulations
"""

import asyncio
import aiohttp
import asyncpg
from typing import Dict, List, Optional, Any, Tuple
from datetime import datetime, timedelta
import json
import re
from dataclasses import dataclass
from enum import Enum

import databutton as db
from app.libs.document_processor import DocumentProcessor, process_uploaded_document

class FeedType(Enum):
    RSS = "rss"
    API = "api"
    WEB_SCRAPING = "web_scraping"
    EMAIL = "email"
    WEBHOOK = "webhook"

class FeedStatus(Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    ERROR = "error"
    PENDING = "pending"

@dataclass
class RegulatoryFeed:
    """Configuration for a regulatory content feed"""
    id: str
    name: str
    jurisdiction: str
    source_url: str
    feed_type: FeedType
    status: FeedStatus
    check_frequency: int  # hours
    last_checked: Optional[datetime]
    last_updated: Optional[datetime]
    metadata: Dict[str, Any]
    
@dataclass
class FeedUpdate:
    """Represents a detected update from a regulatory feed"""
    feed_id: str
    title: str
    description: str
    source_url: str
    document_url: Optional[str]
    publication_date: datetime
    update_type: str  # new, amended, repealed
    jurisdiction: str
    category: str
    confidence: float
    metadata: Dict[str, Any]

class RegulatoryFeedsManager:
    """Manages automated regulatory content feeds"""
    
    def __init__(self):
        self.processor = DocumentProcessor()
        
        # Pre-configured feed sources for major jurisdictions
        self.default_feeds = {
            "EU": {
                "name": "EUR-Lex Official Journal",
                "url": "https://eur-lex.europa.eu/oj/rss.html",
                "type": FeedType.RSS,
                "patterns": [r"export.*control", r"dual.*use", r"strategic.*goods"]
            },
            "US": {
                "name": "Federal Register Export Control",
                "url": "https://www.federalregister.gov/documents/search.rss",
                "type": FeedType.RSS,
                "patterns": [r"export.*administration", r"ITAR", r"dual.*use"]
            },
            "UK": {
                "name": "UK Strategic Export Control",
                "url": "https://www.gov.uk/government/publications.atom",
                "type": FeedType.RSS,
                "patterns": [r"export.*control", r"strategic.*export"]
            },
            "CA": {
                "name": "Canada Export Control List",
                "url": "https://laws-lois.justice.gc.ca/eng/regulations/SOR-89-202/",
                "type": FeedType.WEB_SCRAPING,
                "patterns": [r"export.*control.*list", r"strategic.*goods"]
            }
        }
    
    async def get_db_connection(self):
        """Get database connection"""
        return await asyncpg.connect(db.secrets.get("DATABASE_URL_DEV"))
    
    async def setup_default_feeds(self) -> List[str]:
        """Set up default regulatory feeds for major jurisdictions"""
        conn = await self.get_db_connection()
        feed_ids = []
        
        try:
            for jurisdiction, config in self.default_feeds.items():
                feed_id = f"feed_{jurisdiction.lower()}_{datetime.now().strftime('%Y%m%d')}"
                
                await conn.execute("""
                    INSERT INTO regulatory_feeds 
                    (feed_id, name, jurisdiction, source_url, feed_type, status, 
                     check_frequency, metadata, created_at)
                    VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
                    ON CONFLICT (feed_id) DO UPDATE SET
                    name = EXCLUDED.name,
                    source_url = EXCLUDED.source_url,
                    updated_at = NOW()
                """,
                feed_id, config["name"], jurisdiction, config["url"], 
                config["type"].value, FeedStatus.ACTIVE.value, 24,  # Check daily
                json.dumps({
                    "patterns": config["patterns"],
                    "auto_configured": True
                }),
                datetime.now()
                )
                
                feed_ids.append(feed_id)
                print(f"Configured feed: {config['name']} for {jurisdiction}")
            
            return feed_ids
            
        finally:
            await conn.close()
    
    async def check_all_feeds(self) -> List[FeedUpdate]:
        """Check all active feeds for updates"""
        conn = await self.get_db_connection()
        all_updates = []
        
        try:
            # Get all active feeds
            feeds = await conn.fetch("""
                SELECT feed_id, name, jurisdiction, source_url, feed_type, 
                       check_frequency, last_checked, metadata
                FROM regulatory_feeds 
                WHERE status = 'active'
                AND (last_checked IS NULL OR 
                     last_checked < NOW() - INTERVAL '1 hour' * check_frequency)
            """)
            
            print(f"Checking {len(feeds)} regulatory feeds for updates...")
            
            for feed_row in feeds:
                feed = RegulatoryFeed(
                    id=feed_row['feed_id'],
                    name=feed_row['name'],
                    jurisdiction=feed_row['jurisdiction'],
                    source_url=feed_row['source_url'],
                    feed_type=FeedType(feed_row['feed_type']),
                    status=FeedStatus.ACTIVE,
                    check_frequency=feed_row['check_frequency'],
                    last_checked=feed_row['last_checked'],
                    last_updated=None,
                    metadata=json.loads(feed_row['metadata']) if feed_row['metadata'] else {}
                )
                
                try:
                    updates = await self._check_feed(feed)
                    all_updates.extend(updates)
                    
                    # Update last checked time
                    await conn.execute("""
                        UPDATE regulatory_feeds 
                        SET last_checked = NOW(), 
                            last_updated = CASE WHEN $2 > 0 THEN NOW() ELSE last_updated END
                        WHERE feed_id = $1
                    """, feed.id, len(updates))
                    
                    print(f"Feed {feed.name}: {len(updates)} updates found")
                    
                except Exception as e:
                    print(f"Error checking feed {feed.name}: {str(e)}")
                    await conn.execute("""
                        UPDATE regulatory_feeds 
                        SET status = 'error', last_checked = NOW()
                        WHERE feed_id = $1
                    """, feed.id)
            
            return all_updates
            
        finally:
            await conn.close()
    
    async def _check_feed(self, feed: RegulatoryFeed) -> List[FeedUpdate]:
        """Check a specific feed for updates"""
        if feed.feed_type == FeedType.RSS:
            return await self._check_rss_feed(feed)
        elif feed.feed_type == FeedType.API:
            return await self._check_api_feed(feed)
        elif feed.feed_type == FeedType.WEB_SCRAPING:
            return await self._check_web_scraping_feed(feed)
        else:
            print(f"Feed type {feed.feed_type} not yet implemented")
            return []
    
    async def _check_rss_feed(self, feed: RegulatoryFeed) -> List[FeedUpdate]:
        """Check RSS/Atom feed for updates"""
        try:
            import feedparser
        except ImportError:
            print("feedparser not available, using basic RSS parsing")
            return await self._check_basic_rss(feed)
        
        try:
            # Parse RSS feed
            parsed_feed = feedparser.parse(feed.source_url)
            updates = []
            
            # Get patterns from metadata
            patterns = feed.metadata.get("patterns", [])
            
            for entry in parsed_feed.entries[:10]:  # Check last 10 entries
                # Check if entry matches export control patterns
                title = entry.get('title', '')
                description = entry.get('description', '') or entry.get('summary', '')
                
                if self._matches_patterns(f"{title} {description}", patterns):
                    # Parse publication date
                    pub_date = self._parse_date(entry.get('published', entry.get('updated', '')))
                    
                    # Only process recent updates (last 30 days)
                    if pub_date and pub_date > datetime.now() - timedelta(days=30):
                        update = FeedUpdate(
                            feed_id=feed.id,
                            title=title,
                            description=description,
                            source_url=entry.get('link', feed.source_url),
                            document_url=self._extract_document_url(entry),
                            publication_date=pub_date,
                            update_type=self._classify_update_type(title, description),
                            jurisdiction=feed.jurisdiction,
                            category="export_control",
                            confidence=self._calculate_confidence(title, description, patterns),
                            metadata={
                                "feed_entry_id": entry.get('id', ''),
                                "author": entry.get('author', ''),
                                "tags": entry.get('tags', [])
                            }
                        )
                        updates.append(update)
            
            return updates
            
        except Exception as e:
            print(f"Error parsing RSS feed {feed.source_url}: {str(e)}")
            return []
    
    async def _check_basic_rss(self, feed: RegulatoryFeed) -> List[FeedUpdate]:
        """Basic RSS parsing without feedparser dependency"""
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(feed.source_url) as response:
                    if response.status == 200:
                        content = await response.text()
                        
                        # Basic RSS parsing with regex
                        items = re.findall(r'<item[^>]*>(.*?)</item>', content, re.DOTALL | re.IGNORECASE)
                        updates = []
                        
                        patterns = feed.metadata.get("patterns", [])
                        
                        for item in items[:10]:
                            title_match = re.search(r'<title[^>]*>(.*?)</title>', item, re.IGNORECASE)
                            desc_match = re.search(r'<description[^>]*>(.*?)</description>', item, re.IGNORECASE)
                            link_match = re.search(r'<link[^>]*>(.*?)</link>', item, re.IGNORECASE)
                            date_match = re.search(r'<pubDate[^>]*>(.*?)</pubDate>', item, re.IGNORECASE)
                            
                            if title_match:
                                title = self._clean_html(title_match.group(1))
                                description = self._clean_html(desc_match.group(1)) if desc_match else ""
                                
                                if self._matches_patterns(f"{title} {description}", patterns):
                                    pub_date = self._parse_date(date_match.group(1) if date_match else "")
                                    
                                    if pub_date and pub_date > datetime.now() - timedelta(days=30):
                                        update = FeedUpdate(
                                            feed_id=feed.id,
                                            title=title,
                                            description=description,
                                            source_url=link_match.group(1) if link_match else feed.source_url,
                                            document_url=None,
                                            publication_date=pub_date,
                                            update_type=self._classify_update_type(title, description),
                                            jurisdiction=feed.jurisdiction,
                                            category="export_control",
                                            confidence=self._calculate_confidence(title, description, patterns),
                                            metadata={"basic_rss_parse": True}
                                        )
                                        updates.append(update)
                        
                        return updates
            
        except Exception as e:
            print(f"Error in basic RSS parsing: {str(e)}")
            return []
    
    async def _check_api_feed(self, feed: RegulatoryFeed) -> List[FeedUpdate]:
        """Check API-based feed for updates"""
        # Placeholder for API-based feeds (future implementation)
        return []
    
    async def _check_web_scraping_feed(self, feed: RegulatoryFeed) -> List[FeedUpdate]:
        """Check web scraping-based feed for updates"""
        # Placeholder for web scraping feeds (future implementation)
        return []
    
    def _matches_patterns(self, text: str, patterns: List[str]) -> bool:
        """Check if text matches any of the given patterns"""
        if not patterns:
            return True
        
        text_lower = text.lower()
        for pattern in patterns:
            if re.search(pattern.lower(), text_lower):
                return True
        return False
    
    def _classify_update_type(self, title: str, description: str) -> str:
        """Classify the type of regulatory update"""
        text = f"{title} {description}".lower()
        
        if any(word in text for word in ['amend', 'modify', 'revise', 'update']):
            return "amended"
        elif any(word in text for word in ['repeal', 'revoke', 'cancel']):
            return "repealed"
        elif any(word in text for word in ['new', 'establish', 'introduce']):
            return "new"
        else:
            return "update"
    
    def _calculate_confidence(self, title: str, description: str, patterns: List[str]) -> float:
        """Calculate confidence score for the relevance of the update"""
        text = f"{title} {description}".lower()
        
        # Base confidence
        confidence = 0.5
        
        # Boost for exact pattern matches
        for pattern in patterns:
            if re.search(pattern.lower(), text):
                confidence += 0.2
        
        # Boost for export control keywords
        keywords = ['export control', 'dual use', 'strategic goods', 'itar', 'wassenaar']
        for keyword in keywords:
            if keyword in text:
                confidence += 0.1
        
        return min(confidence, 1.0)
    
    def _parse_date(self, date_str: str) -> Optional[datetime]:
        """Parse various date formats"""
        if not date_str:
            return None
        
        # Common date formats
        formats = [
            '%a, %d %b %Y %H:%M:%S %z',  # RFC 2822
            '%Y-%m-%dT%H:%M:%S%z',        # ISO 8601
            '%Y-%m-%d %H:%M:%S',          # Simple format
            '%Y-%m-%d',                   # Date only
            '%d %b %Y',                   # Day Month Year
        ]
        
        for fmt in formats:
            try:
                return datetime.strptime(date_str.strip(), fmt)
            except ValueError:
                continue
        
        return None
    
    def _clean_html(self, text: str) -> str:
        """Clean HTML tags from text"""
        # Remove CDATA
        text = re.sub(r'<!\[CDATA\[(.*?)\]\]>', r'\1', text)
        # Remove HTML tags
        text = re.sub(r'<[^>]+>', '', text)
        # Decode HTML entities
        text = text.replace('&amp;', '&').replace('&lt;', '<').replace('&gt;', '>').replace('&quot;', '"')
        return text.strip()
    
    def _extract_document_url(self, entry: dict) -> Optional[str]:
        """Extract direct document URL from RSS entry"""
        # Look for PDF or document links
        for link in entry.get('links', []):
            if link.get('type') in ['application/pdf', 'application/msword']:
                return link.get('href')
        
        # Check for attachments or enclosures
        for enclosure in entry.get('enclosures', []):
            if 'pdf' in enclosure.get('type', '').lower():
                return enclosure.get('href')
        
        return None
    
    async def store_feed_update(self, update: FeedUpdate) -> str:
        """Store a feed update in the database"""
        conn = await self.get_db_connection()
        
        try:
            update_id = await conn.fetchval("""
                INSERT INTO regulatory_feed_updates 
                (feed_id, title, description, source_url, document_url, 
                 publication_date, update_type, jurisdiction, category, 
                 confidence, metadata, created_at)
                VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
                RETURNING id
            """,
            update.feed_id, update.title, update.description, update.source_url,
            update.document_url, update.publication_date, update.update_type,
            update.jurisdiction, update.category, update.confidence,
            json.dumps(update.metadata), datetime.now()
            )
            
            return str(update_id)
            
        finally:
            await conn.close()

# Utility functions
async def check_regulatory_feeds() -> List[FeedUpdate]:
    """Convenience function to check all regulatory feeds"""
    manager = RegulatoryFeedsManager()
    return await manager.check_all_feeds()

async def setup_default_regulatory_feeds() -> List[str]:
    """Setup default regulatory feeds for major jurisdictions"""
    manager = RegulatoryFeedsManager()
    return await manager.setup_default_feeds()
