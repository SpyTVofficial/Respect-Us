from typing import List, Dict, Any
from openpyxl import Workbook
from openpyxl.utils import get_column_letter
from openpyxl.styles import Font, Alignment, PatternFill
import io

def create_excel_from_data(data: List[Dict[str, Any]], headers: List[str], sheet_name: str = "Data") -> io.BytesIO:
    """
    Create an Excel file from a list of dictionaries
    
    Args:
        data: List of dictionaries containing the data
        headers: List of column headers
        sheet_name: Name of the Excel sheet
    
    Returns:
        BytesIO object containing the Excel file
    """
    wb = Workbook()
    ws = wb.active
    ws.title = sheet_name
    
    # Style for headers
    header_font = Font(bold=True, color="FFFFFF")
    header_fill = PatternFill(start_color="366092", end_color="366092", fill_type="solid")
    header_alignment = Alignment(horizontal="center", vertical="center")
    
    # Add headers
    for col_num, header in enumerate(headers, 1):
        cell = ws.cell(row=1, column=col_num, value=header)
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = header_alignment
    
    # Add data rows
    for row_num, row_data in enumerate(data, 2):
        for col_num, header in enumerate(headers, 1):
            value = row_data.get(header, '')
            ws.cell(row=row_num, column=col_num, value=value)
    
    # Auto-adjust column widths
    for column in ws.columns:
        max_length = 0
        column_letter = get_column_letter(column[0].column)
        for cell in column:
            try:
                if len(str(cell.value)) > max_length:
                    max_length = len(str(cell.value))
            except Exception:
                pass
        adjusted_width = min(max_length + 2, 50)  # Cap at 50 characters
        ws.column_dimensions[column_letter].width = adjusted_width
    
    # Save to memory
    excel_buffer = io.BytesIO()
    wb.save(excel_buffer)
    excel_buffer.seek(0)
    
    return excel_buffer

def parse_excel_data(file_content: bytes, expected_headers: List[str] = None) -> List[Dict[str, Any]]:
    """
    Parse Excel file content and return list of dictionaries
    
    Args:
        file_content: Excel file as bytes
        expected_headers: Optional list of expected headers for validation
    
    Returns:
        List of dictionaries with parsed data
    """
    from openpyxl import load_workbook
    
    excel_buffer = io.BytesIO(file_content)
    wb = load_workbook(excel_buffer)
    ws = wb.active
    
    # Get headers from first row
    headers = []
    for cell in ws[1]:
        headers.append(cell.value if cell.value else '')
    
    # Validate headers if expected_headers provided
    if expected_headers:
        missing_headers = [h for h in expected_headers if h not in headers]
        if missing_headers:
            raise ValueError(f"Missing required headers: {missing_headers}")
    
    # Parse data rows
    data = []
    for row_num, row in enumerate(ws.iter_rows(min_row=2, values_only=True), start=2):
        row_dict = {}
        for col_num, value in enumerate(row):
            if col_num < len(headers):
                header = headers[col_num]
                row_dict[header] = value if value is not None else ''
        
        # Only add non-empty rows
        if any(str(v).strip() for v in row_dict.values()):
            data.append(row_dict)
    
    return data
