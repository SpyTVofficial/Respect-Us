


"""
Universal Credit Consumption Wrapper System

This module provides decorators and functions to handle credit consumption
for all billable actions across the RespectUs compliance platform.
"""

import asyncpg
import asyncio
from datetime import datetime, timedelta
from typing import Optional, Dict, Any
from contextlib import asynccontextmanager
from functools import wraps
from fastapi import HTTPException
import databutton as db
from app.env import Mode, mode

# Import auto-recharge manager
try:
    from app.libs.auto_recharge_manager import AutoRechargeManager
    auto_recharge_manager = AutoRechargeManager()
except ImportError:
    auto_recharge_manager = None
    print("Auto-recharge manager not available")

class CreditError(Exception):
    """Base exception for credit-related errors"""
    pass

class CreditInsufficient(CreditError):
    """Raised when user has insufficient credits"""
    def __init__(self, required_credits: int, available_credits: int, component: str, action: str):
        self.required_credits = required_credits
        self.available_credits = available_credits
        self.component = component
        self.action = action
        super().__init__(
            f"Insufficient credits: need {required_credits}, have {available_credits} "
            f"for {component}.{action}"
        )

class CreditSystemUnavailable(CreditError):
    """Raised when credit system is temporarily unavailable"""
    pass

class CreditTransactionFailed(CreditError):
    """Raised when credit transaction fails unexpectedly"""
    pass

class CreditConcurrencyError(CreditError):
    """Raised when concurrent credit operations conflict"""
    pass

class CreditManager:
    """Enhanced credit manager with comprehensive error handling and edge case management"""
    
    def __init__(self):
        self.max_retries = 3
        self.retry_delay = 0.5  # seconds
        self.lock_timeout = 30  # seconds
        self.rate_limit_window = 60  # seconds
        self.max_operations_per_window = 100
    
    async def get_db_connection(self) -> asyncpg.Connection:
        """Get database connection with retry logic"""
        for attempt in range(self.max_retries):
            try:
                if mode == Mode.PROD:
                    database_url = db.secrets.get("DATABASE_URL_PROD")
                else:
                    database_url = db.secrets.get("DATABASE_URL_DEV")
                
                connection = await asyncio.wait_for(
                    asyncpg.connect(database_url),
                    timeout=10.0
                )
                return connection
            except (asyncpg.PostgresError, asyncio.TimeoutError, OSError) as e:
                if attempt == self.max_retries - 1:
                    raise CreditSystemUnavailable(f"Database connection failed after {self.max_retries} attempts: {e}") from e
                await asyncio.sleep(self.retry_delay * (2 ** attempt))  # Exponential backoff
        
        raise CreditSystemUnavailable("Failed to establish database connection")
    
    async def check_rate_limit(self, user_id: str, component: str, action: str) -> bool:
        """Check if user is within rate limits for credit operations"""
        try:
            conn = await self.get_db_connection()
            try:
                # Check operations in the last minute
                check_query = """
                    SELECT COUNT(*) FROM credit_transactions 
                    WHERE user_id = $1 
                    AND component_name = $2 
                    AND action_name = $3
                    AND created_at > $4
                """
                
                cutoff_time = datetime.utcnow() - timedelta(seconds=self.rate_limit_window)
                operation_count = await conn.fetchval(
                    check_query, user_id, component, action, cutoff_time
                )
                
                return operation_count < self.max_operations_per_window
            finally:
                await conn.close()
        except Exception as e:
            # If rate limiting check fails, allow the operation but log the error
            print(f"Rate limit check failed for {user_id}: {e}")
            return True
    
    async def acquire_user_lock(self, conn: asyncpg.Connection, user_id: str) -> bool:
        """Acquire an advisory lock for user to prevent concurrent operations"""
        try:
            # Use PostgreSQL advisory locks with timeout
            lock_key = hash(user_id) % 2147483647  # Ensure positive 32-bit int
            
            lock_acquired = await conn.fetchval(
                "SELECT pg_try_advisory_lock($1)", lock_key
            )
            
            if not lock_acquired:
                # Wait a bit and try again
                await asyncio.sleep(0.1)
                lock_acquired = await conn.fetchval(
                    "SELECT pg_try_advisory_lock($1)", lock_key
                )
            
            return lock_acquired
        except Exception as e:
            print(f"Failed to acquire lock for user {user_id}: {e}")
            return False
    
    async def release_user_lock(self, conn: asyncpg.Connection, user_id: str):
        """Release advisory lock for user"""
        try:
            lock_key = hash(user_id) % 2147483647
            await conn.fetchval("SELECT pg_advisory_unlock($1)", lock_key)
        except Exception as e:
            print(f"Failed to release lock for user {user_id}: {e}")
    
    async def get_user_balance_with_lock(self, conn: asyncpg.Connection, user_id: str) -> int:
        """Get user balance with row-level locking to prevent race conditions"""
        try:
            # Use SELECT FOR UPDATE to lock the row
            balance_query = """
                SELECT current_balance FROM user_credits 
                WHERE user_id = $1 
                FOR UPDATE
            """
            
            balance = await conn.fetchval(balance_query, user_id)
            return balance or 0
        except asyncpg.PostgresError as e:
            raise CreditTransactionFailed(f"Failed to get user balance: {e}") from e
    
    async def validate_credit_availability(self, user_id: str, required_credits: int, component: str, action: str) -> Dict[str, Any]:
        """Validate credit availability with comprehensive checks and auto-recharge trigger"""
        # Check rate limiting first
        if not await self.check_rate_limit(user_id, component, action):
            raise HTTPException(
                status_code=429,
                detail={
                    "error": "rate_limit_exceeded",
                    "message": f"Too many {action} operations. Please wait before trying again.",
                    "retry_after": self.rate_limit_window
                }
            )
        
        conn = await self.get_db_connection()
        try:
            # Acquire user lock to prevent concurrent operations
            if not await self.acquire_user_lock(conn, user_id):
                raise CreditConcurrencyError("Another credit operation is in progress. Please try again.")
            
            try:
                # Get current balance with locking
                current_balance = await self.get_user_balance_with_lock(conn, user_id)
                
                # If insufficient credits, try auto-recharge first
                if current_balance < required_credits:
                    # Attempt auto-recharge if available
                    if auto_recharge_manager:
                        try:
                            print(f"Insufficient credits ({current_balance} < {required_credits}). Attempting auto-recharge for user {user_id}")
                            recharge_result = await auto_recharge_manager.check_and_trigger_recharge(user_id)
                            
                            if recharge_result and recharge_result.get('status') == 'success':
                                # Recharge successful, get updated balance
                                await asyncio.sleep(0.1)  # Brief pause for transaction completion
                                updated_balance = await self.get_user_balance_with_lock(conn, user_id)
                                print(f"Auto-recharge successful. New balance: {updated_balance}")
                                
                                # Check again with new balance
                                if updated_balance >= required_credits:
                                    return {
                                        "can_proceed": True,
                                        "current_balance": updated_balance,
                                        "required_credits": required_credits,
                                        "remaining_after": updated_balance - required_credits,
                                        "auto_recharged": True,
                                        "credits_added": recharge_result.get('credits_added', 0)
                                    }
                                else:
                                    # Still insufficient after recharge
                                    raise CreditInsufficient(
                                        required_credits=required_credits,
                                        available_credits=updated_balance,
                                        component=component,
                                        action=action
                                    )
                            else:
                                # Auto-recharge not triggered or failed
                                print(f"Auto-recharge not triggered or failed: {recharge_result}")
                                raise CreditInsufficient(
                                    required_credits=required_credits,
                                    available_credits=current_balance,
                                    component=component,
                                    action=action
                                )
                        except Exception as recharge_error:
                            print(f"Auto-recharge error for user {user_id}: {recharge_error}")
                            # Continue with normal insufficient credits error
                            raise CreditInsufficient(
                                required_credits=required_credits,
                                available_credits=current_balance,
                                component=component,
                                action=action
                            )
                    else:
                        # No auto-recharge manager available
                        raise CreditInsufficient(
                            required_credits=required_credits,
                            available_credits=current_balance,
                            component=component,
                            action=action
                        )
                
                # Sufficient credits available
                return {
                    "can_proceed": True,
                    "current_balance": current_balance,
                    "required_credits": required_credits,
                    "remaining_after": current_balance - required_credits
                }
            finally:
                await self.release_user_lock(conn, user_id)
        finally:
            await conn.close()
    
    async def consume_credits_atomic(self, user_id: str, credits: int, component: str, action: str, resource_id: Optional[str] = None, description: Optional[str] = None) -> Dict[str, Any]:
        """Atomically consume credits with full error handling and rollback support"""
        if credits <= 0:
            raise ValueError("Credit amount must be positive")
        
        conn = await self.get_db_connection()
        transaction_id = None
        
        try:
            # Start transaction with isolation level
            async with conn.transaction(isolation='serializable'):
                # Acquire user lock
                if not await self.acquire_user_lock(conn, user_id):
                    raise CreditConcurrencyError("Unable to acquire user lock for credit operation")
                
                try:
                    # Ensure user record exists
                    ensure_user_query = """
                        INSERT INTO user_credits (user_id) VALUES ($1)
                        ON CONFLICT (user_id) DO NOTHING
                    """
                    await conn.execute(ensure_user_query, user_id)
                    
                    # Get and lock current balance
                    current_balance = await self.get_user_balance_with_lock(conn, user_id)
                    
                    # Final validation
                    if current_balance < credits:
                        raise CreditInsufficient(
                            required_credits=credits,
                            available_credits=current_balance,
                            component=component,
                            action=action
                        )
                    
                    new_balance = current_balance - credits
                    
                    # Update balance
                    update_query = """
                        UPDATE user_credits 
                        SET current_balance = $1, 
                            lifetime_consumed = lifetime_consumed + $2,
                            updated_at = CURRENT_TIMESTAMP
                        WHERE user_id = $3
                    """
                    await conn.execute(update_query, new_balance, credits, user_id)
                    
                    # Record transaction
                    transaction_query = """
                        INSERT INTO credit_transactions 
                        (user_id, transaction_type, amount, balance_after, component_name, action_name, resource_id, description)
                        VALUES ($1, 'consume', $2, $3, $4, $5, $6, $7)
                        RETURNING id
                    """
                    
                    transaction_id = await conn.fetchval(
                        transaction_query,
                        user_id,
                        -credits,  # Negative for consumption
                        new_balance,
                        component,
                        action,
                        resource_id,
                        description or f"{component} - {action}"
                    )
                    
                    return {
                        "success": True,
                        "transaction_id": transaction_id,
                        "credits_consumed": credits,
                        "previous_balance": current_balance,
                        "new_balance": new_balance
                    }
                finally:
                    await self.release_user_lock(conn, user_id)
                    
        except (CreditInsufficient, CreditConcurrencyError):
            # Re-raise known credit errors
            raise
        except asyncpg.SerializationError:
            # Handle serialization failures due to concurrent access
            raise CreditConcurrencyError("Credit operation conflicted with another transaction. Please retry.")
        except asyncpg.PostgresError as e:
            # Database-specific errors
            raise CreditTransactionFailed(f"Database error during credit consumption: {e}") from e
        except Exception as e:
            # Unexpected errors
            raise CreditTransactionFailed(f"Unexpected error during credit consumption: {e}") from e
        finally:
            await conn.close()
    
    async def refund_credits(self, user_id: str, transaction_id: int, reason: str) -> Dict[str, Any]:
        """Refund credits from a failed operation with full audit trail"""
        conn = await self.get_db_connection()
        
        try:
            async with conn.transaction():
                # Get original transaction details
                original_query = """
                    SELECT amount, component_name, action_name, resource_id 
                    FROM credit_transactions 
                    WHERE id = $1 AND user_id = $2 AND transaction_type = 'consume'
                """
                
                original_tx = await conn.fetchrow(original_query, transaction_id, user_id)
                
                if not original_tx:
                    raise ValueError(f"Transaction {transaction_id} not found or not eligible for refund")
                
                # Calculate refund amount (original was negative)
                refund_amount = abs(original_tx['amount'])
                
                # Acquire user lock
                if not await self.acquire_user_lock(conn, user_id):
                    raise CreditConcurrencyError("Unable to acquire user lock for refund operation")
                
                try:
                    # Get current balance
                    current_balance = await self.get_user_balance_with_lock(conn, user_id)
                    new_balance = current_balance + refund_amount
                    
                    # Update balance
                    update_query = """
                        UPDATE user_credits 
                        SET current_balance = $1, 
                            lifetime_consumed = lifetime_consumed - $2,
                            updated_at = CURRENT_TIMESTAMP
                        WHERE user_id = $3
                    """
                    await conn.execute(update_query, new_balance, refund_amount, user_id)
                    
                    # Record refund transaction
                    refund_query = """
                        INSERT INTO credit_transactions 
                        (user_id, transaction_type, amount, balance_after, component_name, action_name, resource_id, description)
                        VALUES ($1, 'refund', $2, $3, $4, $5, $6, $7)
                        RETURNING id
                    """
                    
                    refund_transaction_id = await conn.fetchval(
                        refund_query,
                        user_id,
                        refund_amount,
                        new_balance,
                        original_tx['component_name'],
                        original_tx['action_name'],
                        original_tx['resource_id'],
                        f"Refund for transaction {transaction_id}: {reason}"
                    )
                    
                    return {
                        "success": True,
                        "refund_transaction_id": refund_transaction_id,
                        "original_transaction_id": transaction_id,
                        "credits_refunded": refund_amount,
                        "new_balance": new_balance,
                        "reason": reason
                    }
                finally:
                    await self.release_user_lock(conn, user_id)
                    
        except Exception as e:
            raise CreditTransactionFailed(f"Failed to process refund: {e}") from e
        finally:
            await conn.close()
    
    async def health_check(self) -> Dict[str, Any]:
        """Check credit system health and connectivity"""
        try:
            conn = await self.get_db_connection()
            try:
                # Test basic database connectivity
                await conn.fetchval("SELECT 1")
                
                # Test user_credits table
                await conn.fetchval("SELECT COUNT(*) FROM user_credits LIMIT 1")
                
                # Test credit_transactions table
                await conn.fetchval("SELECT COUNT(*) FROM credit_transactions LIMIT 1")
                
                return {
                    "status": "healthy",
                    "database_connected": True,
                    "tables_accessible": True,
                    "timestamp": datetime.utcnow().isoformat()
                }
            finally:
                await conn.close()
        except Exception as e:
            return {
                "status": "unhealthy",
                "database_connected": False,
                "error": str(e),
                "timestamp": datetime.utcnow().isoformat()
            }

# Global credit manager instance
credit_manager = CreditManager()

@asynccontextmanager
async def CreditTransaction(user_id: str, credits: int, component: str, action: str, resource_id: Optional[str] = None, description: Optional[str] = None):
    """Context manager for credit transactions with automatic refund on failure"""
    transaction_result = None
    
    try:
        # Validate and consume credits
        await credit_manager.validate_credit_availability(user_id, credits, component, action)
        transaction_result = await credit_manager.consume_credits_atomic(
            user_id, credits, component, action, resource_id, description
        )
        
        yield transaction_result
        
    except Exception as e:
        # If we successfully consumed credits but the operation failed, refund them
        if transaction_result and transaction_result.get("success"):
            try:
                await credit_manager.refund_credits(
                    user_id, 
                    transaction_result["transaction_id"], 
                    f"Operation failed: {str(e)}"
                )
                print(f"Auto-refunded {credits} credits to {user_id} due to operation failure")
            except Exception as refund_error:
                print(f"Failed to auto-refund credits: {refund_error}")
        
        # Re-raise the original exception
        raise

def consume_credits_for_action(component: str, action: str, credits: int = None):
    """Enhanced decorator with comprehensive error handling"""
    def decorator(func):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            # Extract user from function arguments
            user = None
            for arg in args:
                if hasattr(arg, 'sub'):  # AuthorizedUser object
                    user = arg
                    break
            
            if not user:
                # If no user found, execute without credit consumption (for open endpoints)
                return await func(*args, **kwargs)
            
            try:
                # Get pricing configuration with error handling
                try:
                    conn = await credit_manager.get_db_connection()
                    try:
                        pricing_query = """
                            SELECT credit_cost FROM component_pricing 
                            WHERE component_name = $1 AND action_name = $2 AND is_active = true
                        """
                        required_credits = await conn.fetchval(pricing_query, component, action)
                        
                        if required_credits is None:
                            required_credits = credits or 0  # Fallback to decorator parameter
                    finally:
                        await conn.close()
                except Exception as e:
                    print(f"Failed to get pricing for {component}.{action}: {e}")
                    required_credits = credits or 0
                
                # If action is free, execute without credit consumption
                if required_credits <= 0:
                    return await func(*args, **kwargs)
                
                # Use credit transaction context manager for automatic refund on failure
                async with CreditTransaction(
                    user.sub, 
                    required_credits, 
                    component, 
                    action,
                    description=f"{component} - {action}"
                ) as transaction:
                    # Execute the actual function
                    result = await func(*args, **kwargs)
                    
                    # If we get here, the operation was successful
                    return result
                    
            except CreditInsufficient as e:
                raise HTTPException(
                    status_code=402,
                    detail={
                        "error": "insufficient_credits",
                        "message": str(e),
                        "required_credits": e.required_credits,
                        "available_credits": e.available_credits,
                        "component": e.component,
                        "action": e.action
                    }
                )
            except CreditConcurrencyError as e:
                raise HTTPException(
                    status_code=409,
                    detail={
                        "error": "credit_operation_conflict",
                        "message": str(e),
                        "retry_after": 1
                    }
                )
            except CreditSystemUnavailable as e:
                raise HTTPException(
                    status_code=503,
                    detail={
                        "error": "credit_system_unavailable",
                        "message": str(e),
                        "retry_after": 30
                    }
                )
            except CreditTransactionFailed as e:
                raise HTTPException(
                    status_code=500,
                    detail={
                        "error": "credit_transaction_failed",
                        "message": str(e)
                    }
                )
            except Exception as e:
                # Log unexpected errors but don't expose internal details
                print(f"Unexpected error in credit consumption for {component}.{action}: {e}")
                raise HTTPException(
                    status_code=500,
                    detail={
                        "error": "internal_server_error",
                        "message": "An unexpected error occurred. Please try again."
                    }
                )
        
        return wrapper
    return decorator
