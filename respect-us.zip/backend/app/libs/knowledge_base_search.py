"""Knowledge Base Search Utilities

Helper functions for search functionality in the knowledge base.
"""

import re
from typing import List, Any, Tuple

def parse_boolean_query(query: str) -> str:
    """Parse and convert user-friendly Boolean query to PostgreSQL tsquery format"""
    # Escape single quotes in the query
    query = query.replace("'", "''")
    
    # Extract phrases (text in quotes) and replace with placeholders
    phrases = []
    phrase_pattern = r'"([^"]+)"'
    for match in re.finditer(phrase_pattern, query):
        phrases.append(match.group(1))
    
    # Replace phrases with placeholders
    for i, phrase in enumerate(phrases):
        placeholder = f"__PHRASE_{i}__"
        query = re.sub(r'"' + re.escape(phrase) + r'"', placeholder, query)
    
    # Convert Boolean operators
    query = re.sub(r'\bAND\b', '&', query, flags=re.IGNORECASE)
    query = re.sub(r'\bOR\b', '|', query, flags=re.IGNORECASE)
    query = re.sub(r'\bNOT\b', '!', query, flags=re.IGNORECASE)
    
    # Restore phrases
    for i, phrase in enumerate(phrases):
        placeholder = f"__PHRASE_{i}__"
        # Escape single quotes and wrap in quotes for exact phrase matching
        escaped_phrase = phrase.replace("'", "''")
        query = query.replace(placeholder, f"'{escaped_phrase}'")
    
    # Clean up extra spaces
    query = re.sub(r'\s+', ' ', query).strip()
    
    return query

def build_search_conditions(request) -> Tuple[List[str], List[Any]]:
    """Build search conditions and parameters"""
    where_conditions = []
    params = []
    param_count = 0
    
    # Filter by status - show published + pending_validation documents for admins
    # This allows uploaded documents to appear in search results before admin review
    where_conditions.append("status IN ('published', 'pending_validation')")
    # Note: No params needed for IN clause with literal values
    
    # Text search with Boolean support
    if request.query:
        search_fields = []
        
        if "title" in request.search_fields:
            search_fields.append("to_tsvector('english', title)")
        if "content" in request.search_fields:
            search_fields.append("to_tsvector('english', COALESCE(content_text, ''))")
        if "description" in request.search_fields:
            search_fields.append("to_tsvector('english', COALESCE(description, ''))")
        
        if search_fields:
            param_count += 1
            
            if request.boolean_mode:
                # Use Boolean query parsing
                parsed_query = parse_boolean_query(request.query)
                if parsed_query:
                    search_condition = f"({' || '.join(search_fields)}) @@ to_tsquery('english', ${param_count})"
                    where_conditions.append(search_condition)
                    params.append(parsed_query)
            else:
                # Use simple text search
                search_condition = f"({' || '.join(search_fields)}) @@ plainto_tsquery('english', ${param_count})"
                where_conditions.append(search_condition)
                params.append(request.query)
    
    # Jurisdiction filter
    if request.jurisdiction:
        param_count += 1
        where_conditions.append(f"country_jurisdiction::text ILIKE ${param_count}")
        params.append(f"%{request.jurisdiction}%")
    
    # Regulation type filter
    if request.regulation_type:
        param_count += 1
        where_conditions.append(f"regulation_type::text ILIKE ${param_count}")
        params.append(f"%{request.regulation_type}%")
    
    # Badge filter
    if request.badge:
        param_count += 1
        where_conditions.append(f"badge::text ILIKE ${param_count}")
        params.append(f"%{request.badge}%")
    
    # Date range filters
    if request.date_from:
        try:
            param_count += 1
            where_conditions.append(f"publication_date >= ${param_count}")
            params.append(request.date_from)
        except ValueError:
            pass  # Skip invalid date
    
    if request.date_to:
        try:
            param_count += 1
            where_conditions.append(f"publication_date <= ${param_count}")
            params.append(request.date_to)
        except ValueError:
            pass  # Skip invalid date
    
    # Category filter
    if request.category_ids:
        # Convert category_ids to array format for PostgreSQL
        category_placeholders = []
        for category_id in request.category_ids:
            param_count += 1
            category_placeholders.append(f"${param_count}")
            params.append(category_id)
        
        if category_placeholders:
            # Check if document's category_ids array contains any of the requested categories
            where_conditions.append(f"category_ids && ARRAY[{','.join(category_placeholders)}]")
    
    return where_conditions, params
