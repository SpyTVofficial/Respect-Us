from typing import List, Dict, Any, Optional, Tuple
import re
import asyncpg
import databutton as db
from app.env import Mode, mode

class CrossReferenceDetector:
    """Detects and manages cross-references between regulatory documents"""
    
    def __init__(self):
        # Patterns for detecting regulatory references
        self.reference_patterns = [
            # US patterns
            r'\b(\d+)\s*CFR\s*(\d+(?:\.\d+)*)\b',  # 15 CFR 774.1
            r'\bEAR\s*§?\s*(\d+(?:\.\d+)*)\b',      # EAR 774.1
            r'\bCCL\s*Category\s*(\d+)\b',           # CCL Category 1
            
            # EU patterns
            r'\bRegulation\s*\(EU\)\s*(\d+/\d+)\b', # Regulation (EU) 2021/821
            r'\bDirective\s*(\d+/\d+/EC)\b',        # Directive 2009/43/EC
            r'\bAnnex\s*([IVX]+)\b',                 # Annex I, II, etc.
            
            # General patterns
            r'\bArticle\s*(\d+(?:\.\d+)*)\b',       # Article 4.1
            r'\bSection\s*(\d+(?:\.\d+)*)\b',       # Section 744.1
            r'\bChapter\s*(\d+(?:\.\d+)*)\b',       # Chapter 7
            r'\bPart\s*(\d+(?:\.\d+)*)\b',          # Part 774
            
            # License requirements
            r'\b(NLR|License Required|License Exception [A-Z]+)\b',
            r'\b(ENC|APP|TMP|GOV|CIV|TSR|BAG|AVS)\b',  # License exceptions
        ]
        
        # Compile patterns for better performance
        self.compiled_patterns = [re.compile(pattern, re.IGNORECASE) for pattern in self.reference_patterns]
    
    async def get_db_connection(self):
        """Get database connection based on environment"""
        if mode == Mode.PROD:
            database_url = db.secrets.get("DATABASE_URL_PROD")
        else:
            database_url = db.secrets.get("DATABASE_URL_DEV")
        return await asyncpg.connect(database_url)
    
    def extract_references(self, text: str) -> List[Dict[str, Any]]:
        """Extract all regulatory references from text"""
        references = []
        
        for pattern in self.compiled_patterns:
            matches = pattern.finditer(text)
            for match in matches:
                ref = {
                    'text': match.group(0),
                    'start': match.start(),
                    'end': match.end(),
                    'type': self._classify_reference(match.group(0)),
                    'groups': match.groups()
                }
                references.append(ref)
        
        return references
    
    def _classify_reference(self, text: str) -> str:
        """Classify the type of reference"""
        text_lower = text.lower()
        
        if 'cfr' in text_lower:
            return 'cfr'
        elif 'ear' in text_lower:
            return 'ear'
        elif 'ccl' in text_lower:
            return 'ccl'
        elif 'regulation' in text_lower and 'eu' in text_lower:
            return 'eu_regulation'
        elif 'directive' in text_lower:
            return 'eu_directive'
        elif 'annex' in text_lower:
            return 'annex'
        elif 'article' in text_lower:
            return 'article'
        elif 'section' in text_lower:
            return 'section'
        elif 'chapter' in text_lower:
            return 'chapter'
        elif 'part' in text_lower:
            return 'part'
        elif any(exc in text_lower for exc in ['nlr', 'enc', 'app', 'tmp', 'gov', 'civ', 'tsr', 'bag', 'avs']):
            return 'license_exception'
        else:
            return 'general'
    
    async def find_related_documents(self, document_id: int, references: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Find documents that contain similar references"""
        conn = await self.get_db_connection()
        try:
            related_docs = []
            
            for ref in references:
                ref_text = ref['text']
                
                # Search for documents containing this reference
                query = """
                    SELECT DISTINCT d.id, d.title, d.description, d.country_jurisdiction, d.regulation_type
                    FROM kb_documents d
                    WHERE d.id != $1
                    AND (
                        d.content_text ILIKE $2 OR
                        d.title ILIKE $2 OR
                        d.description ILIKE $2
                    )
                    LIMIT 5
                """
                
                rows = await conn.fetch(query, document_id, f"%{ref_text}%")
                
                for row in rows:
                    related_doc = {
                        'id': row['id'],
                        'title': row['title'],
                        'description': row['description'],
                        'country_jurisdiction': row['country_jurisdiction'],
                        'regulation_type': row['regulation_type'],
                        'reference_text': ref_text,
                        'reference_type': ref['type'],
                        'relevance_score': self._calculate_relevance(ref, row)
                    }
                    
                    # Avoid duplicates
                    if not any(doc['id'] == related_doc['id'] for doc in related_docs):
                        related_docs.append(related_doc)
            
            # Sort by relevance score
            related_docs.sort(key=lambda x: x['relevance_score'], reverse=True)
            return related_docs[:10]  # Return top 10 most relevant
            
        finally:
            await conn.close()
    
    def _calculate_relevance(self, reference: Dict[str, Any], document_row: dict) -> float:
        """Calculate relevance score between reference and document"""
        score = 0.0
        
        # Base score for having the reference
        score += 1.0
        
        # Bonus for same jurisdiction
        doc_jurisdictions = document_row.get('country_jurisdiction', [])
        if doc_jurisdictions:
            if any(self._is_same_jurisdiction(reference['type'], jurisdiction) for jurisdiction in doc_jurisdictions):
                score += 0.5
        
        # Bonus for same regulation type
        doc_reg_types = document_row.get('regulation_type', [])
        if doc_reg_types:
            if any(self._is_related_regulation_type(reference['type'], reg_type) for reg_type in doc_reg_types):
                score += 0.3
        
        return score
    
    def _is_same_jurisdiction(self, ref_type: str, jurisdiction: str) -> bool:
        """Check if reference type matches jurisdiction"""
        jurisdiction_lower = jurisdiction.lower()
        
        if ref_type in ['cfr', 'ear', 'ccl'] and 'united states' in jurisdiction_lower:
            return True
        elif ref_type in ['eu_regulation', 'eu_directive'] and ('european union' in jurisdiction_lower or 'eu' in jurisdiction_lower):
            return True
        
        return False
    
    def _is_related_regulation_type(self, ref_type: str, reg_type: str) -> bool:
        """Check if reference type is related to regulation type"""
        reg_type_lower = reg_type.lower()
        
        if ref_type in ['ccl', 'ear'] and 'dual-use' in reg_type_lower:
            return True
        elif ref_type == 'license_exception' and any(keyword in reg_type_lower for keyword in ['export', 'control', 'license']):
            return True
        
        return False
    
    async def store_cross_references(self, document_id: int, references: List[Dict[str, Any]], related_docs: List[Dict[str, Any]]):
        """Store cross-references in the database"""
        conn = await self.get_db_connection()
        try:
            # Create cross_references table if it doesn't exist
            await conn.execute("""
                CREATE TABLE IF NOT EXISTS document_cross_references (
                    id SERIAL PRIMARY KEY,
                    source_document_id INTEGER REFERENCES kb_documents(id),
                    target_document_id INTEGER REFERENCES kb_documents(id),
                    reference_text TEXT NOT NULL,
                    reference_type TEXT NOT NULL,
                    relevance_score FLOAT DEFAULT 0.0,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    UNIQUE(source_document_id, target_document_id, reference_text)
                )
            """)
            
            # Clear existing cross-references for this document
            await conn.execute(
                "DELETE FROM document_cross_references WHERE source_document_id = $1",
                document_id
            )
            
            # Insert new cross-references
            for related_doc in related_docs:
                await conn.execute("""
                    INSERT INTO document_cross_references 
                    (source_document_id, target_document_id, reference_text, reference_type, relevance_score)
                    VALUES ($1, $2, $3, $4, $5)
                    ON CONFLICT (source_document_id, target_document_id, reference_text) DO UPDATE SET
                    relevance_score = EXCLUDED.relevance_score,
                    created_at = CURRENT_TIMESTAMP
                """, 
                document_id, 
                related_doc['id'], 
                related_doc['reference_text'],
                related_doc['reference_type'],
                related_doc['relevance_score']
                )
            
        finally:
            await conn.close()
    
    async def get_cross_references(self, document_id: int) -> List[Dict[str, Any]]:
        """Get cross-references for a document"""
        conn = await self.get_db_connection()
        try:
            query = """
                SELECT 
                    cr.target_document_id,
                    cr.reference_text,
                    cr.reference_type,
                    cr.relevance_score,
                    d.title,
                    d.description,
                    d.country_jurisdiction,
                    d.regulation_type
                FROM document_cross_references cr
                JOIN kb_documents d ON cr.target_document_id = d.id
                WHERE cr.source_document_id = $1
                ORDER BY cr.relevance_score DESC
            """
            
            rows = await conn.fetch(query, document_id)
            
            return [{
                'id': row['target_document_id'],
                'title': row['title'],
                'description': row['description'],
                'country_jurisdiction': row['country_jurisdiction'],
                'regulation_type': row['regulation_type'],
                'reference_text': row['reference_text'],
                'reference_type': row['reference_type'],
                'relevance_score': row['relevance_score']
            } for row in rows]
            
        finally:
            await conn.close()
    
    async def process_document_references(self, document_id: int, content: str) -> List[Dict[str, Any]]:
        """Complete pipeline: extract references, find related docs, store cross-references"""
        # Extract references from content
        references = self.extract_references(content)
        
        if not references:
            return []
        
        # Find related documents
        related_docs = await self.find_related_documents(document_id, references)
        
        # Store cross-references
        await self.store_cross_references(document_id, references, related_docs)
        
        return related_docs
