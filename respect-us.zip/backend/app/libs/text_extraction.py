import PyPDF2
import pdfplumber
from docx import Document
import io
import re
from typing import Optional, Dict, Any
from fastapi import UploadFile

class TextExtractor:
    """Enhanced text extraction library for various document formats"""
    
    @staticmethod
    def extract_text_from_file(file: UploadFile, file_content: bytes) -> Dict[str, Any]:
        """
        Extract text content from uploaded file with metadata
        
        Returns:
            Dict containing:
            - content_text: Extracted text content
            - page_count: Number of pages (if applicable)
            - word_count: Approximate word count
            - extraction_method: Method used for extraction
            - success: Whether extraction was successful
            - error: Error message if extraction failed
        """
        
        result = {
            "content_text": "",
            "page_count": 0,
            "word_count": 0,
            "extraction_method": "none",
            "success": False,
            "error": None
        }
        
        try:
            content_type = file.content_type or ""
            filename = file.filename or ""
            
            # PDF extraction
            if content_type == "application/pdf" or filename.lower().endswith('.pdf'):
                result = TextExtractor._extract_from_pdf(file_content)
            
            # Word document extraction
            elif (content_type == "application/vnd.openxmlformats-officedocument.wordprocessingml.document" 
                  or filename.lower().endswith('.docx')):
                result = TextExtractor._extract_from_docx(file_content)
            
            # Plain text extraction
            elif content_type == "text/plain" or filename.lower().endswith('.txt'):
                result = TextExtractor._extract_from_text(file_content)
            
            # HTML extraction
            elif content_type == "text/html" or filename.lower().endswith('.html'):
                result = TextExtractor._extract_from_html(file_content)
            
            # RTF extraction (basic)
            elif content_type == "application/rtf" or filename.lower().endswith('.rtf'):
                result = TextExtractor._extract_from_rtf(file_content)
            
            else:
                # Try to extract as plain text as fallback
                try:
                    text = file_content.decode('utf-8')
                    result = {
                        "content_text": text,
                        "page_count": 1,
                        "word_count": len(text.split()),
                        "extraction_method": "fallback_utf8",
                        "success": True,
                        "error": None
                    }
                except UnicodeDecodeError:
                    result["error"] = f"Unsupported file type: {content_type}"
                    result["extraction_method"] = "unsupported"
            
            # Post-process text
            if result["success"] and result["content_text"]:
                result["content_text"] = TextExtractor._clean_text(result["content_text"])
                result["word_count"] = len(result["content_text"].split())
            
        except Exception as e:
            result["error"] = f"Text extraction failed: {str(e)}"
            result["extraction_method"] = "error"
        
        return result
    
    @staticmethod
    def _extract_from_pdf(file_content: bytes) -> Dict[str, Any]:
        """Extract text from PDF using multiple methods"""
        
        result = {
            "content_text": "",
            "page_count": 0,
            "word_count": 0,
            "extraction_method": "pdf",
            "success": False,
            "error": None
        }
        
        try:
            # Try pdfplumber first (better for complex layouts)
            with pdfplumber.open(io.BytesIO(file_content)) as pdf:
                pages = []
                for page in pdf.pages:
                    text = page.extract_text()
                    if text:
                        pages.append(text)
                
                if pages:
                    result["content_text"] = "\n\n".join(pages)
                    result["page_count"] = len(pdf.pages)
                    result["extraction_method"] = "pdfplumber"
                    result["success"] = True
                    return result
        
        except Exception as e:
            print(f"pdfplumber failed: {e}")
        
        try:
            # Fallback to PyPDF2
            pdf_reader = PyPDF2.PdfReader(io.BytesIO(file_content))
            pages = []
            
            for page in pdf_reader.pages:
                text = page.extract_text()
                if text:
                    pages.append(text)
            
            if pages:
                result["content_text"] = "\n\n".join(pages)
                result["page_count"] = len(pdf_reader.pages)
                result["extraction_method"] = "pypdf2"
                result["success"] = True
            else:
                result["error"] = "No text content found in PDF"
        
        except Exception as e:
            result["error"] = f"PDF extraction failed: {str(e)}"
        
        return result
    
    @staticmethod
    def _extract_from_docx(file_content: bytes) -> Dict[str, Any]:
        """Extract text from Word document"""
        
        result = {
            "content_text": "",
            "page_count": 1,  # Word docs don't have clear page breaks in text extraction
            "word_count": 0,
            "extraction_method": "docx",
            "success": False,
            "error": None
        }
        
        try:
            doc = Document(io.BytesIO(file_content))
            paragraphs = []
            
            for paragraph in doc.paragraphs:
                if paragraph.text.strip():
                    paragraphs.append(paragraph.text)
            
            # Also extract text from tables
            for table in doc.tables:
                for row in table.rows:
                    row_text = []
                    for cell in row.cells:
                        if cell.text.strip():
                            row_text.append(cell.text.strip())
                    if row_text:
                        paragraphs.append(" | ".join(row_text))
            
            if paragraphs:
                result["content_text"] = "\n\n".join(paragraphs)
                result["success"] = True
            else:
                result["error"] = "No text content found in Word document"
        
        except Exception as e:
            result["error"] = f"Word document extraction failed: {str(e)}"
        
        return result
    
    @staticmethod
    def _extract_from_text(file_content: bytes) -> Dict[str, Any]:
        """Extract text from plain text file"""
        
        result = {
            "content_text": "",
            "page_count": 1,
            "word_count": 0,
            "extraction_method": "text",
            "success": False,
            "error": None
        }
        
        try:
            # Try UTF-8 first
            text = file_content.decode('utf-8')
            result["content_text"] = text
            result["success"] = True
        except UnicodeDecodeError:
            try:
                # Fallback to latin-1
                text = file_content.decode('latin-1')
                result["content_text"] = text
                result["extraction_method"] = "text_latin1"
                result["success"] = True
            except Exception as e:
                result["error"] = f"Text encoding detection failed: {str(e)}"
        
        return result
    
    @staticmethod
    def _extract_from_html(file_content: bytes) -> Dict[str, Any]:
        """Extract text from HTML file (basic HTML tag removal)"""
        
        result = {
            "content_text": "",
            "page_count": 1,
            "word_count": 0,
            "extraction_method": "html",
            "success": False,
            "error": None
        }
        
        try:
            html_content = file_content.decode('utf-8')
            
            # Basic HTML tag removal (for more advanced parsing, could use BeautifulSoup)
            text = re.sub(r'<[^>]+>', '', html_content)
            text = re.sub(r'&\w+;', ' ', text)  # Remove HTML entities
            
            result["content_text"] = text
            result["success"] = True
        
        except Exception as e:
            result["error"] = f"HTML extraction failed: {str(e)}"
        
        return result
    
    @staticmethod
    def _extract_from_rtf(file_content: bytes) -> Dict[str, Any]:
        """Extract text from RTF file (basic RTF control code removal)"""
        
        result = {
            "content_text": "",
            "page_count": 1,
            "word_count": 0,
            "extraction_method": "rtf",
            "success": False,
            "error": None
        }
        
        try:
            rtf_content = file_content.decode('utf-8')
            
            # Basic RTF control code removal
            text = re.sub(r'\\[a-zA-Z]+\d*\s?', '', rtf_content)
            text = re.sub(r'[{}]', '', text)
            text = re.sub(r'\\\S', '', text)
            
            result["content_text"] = text
            result["success"] = True
        
        except Exception as e:
            result["error"] = f"RTF extraction failed: {str(e)}"
        
        return result
    
    @staticmethod
    def _clean_text(text: str) -> str:
        """Clean and normalize extracted text"""
        
        # Remove excessive whitespace
        text = re.sub(r'\s+', ' ', text)
        
        # Remove excessive line breaks
        text = re.sub(r'\n\s*\n\s*\n+', '\n\n', text)
        
        # Strip leading/trailing whitespace
        text = text.strip()
        
        return text
    
    @staticmethod
    def extract_metadata_from_text(text: str) -> Dict[str, Any]:
        """Extract potential metadata from document text"""
        
        metadata = {
            "detected_dates": [],
            "detected_regulations": [],
            "detected_jurisdictions": [],
            "detected_authorities": []
        }
        
        # Common date patterns
        date_patterns = [
            r'\b\d{1,2}[/-]\d{1,2}[/-]\d{4}\b',
            r'\b\d{4}[/-]\d{1,2}[/-]\d{1,2}\b',
            r'\b\w+ \d{1,2}, \d{4}\b'
        ]
        
        for pattern in date_patterns:
            dates = re.findall(pattern, text)
            metadata["detected_dates"].extend(dates)
        
        # Common regulation keywords
        regulation_keywords = [
            r'\b(regulation|directive|law|act|decree|order)\s+\d+[/-]\d+\b',
            r'\bEAR\b', r'\bITAR\b', r'\bOFAC\b'
        ]
        
        for pattern in regulation_keywords:
            matches = re.findall(pattern, text, re.IGNORECASE)
            metadata["detected_regulations"].extend(matches)
        
        # Common jurisdiction indicators
        jurisdiction_keywords = [
            r'\b(United States|USA|US|European Union|EU|Germany|France|UK|United Kingdom)\b'
        ]
        
        for pattern in jurisdiction_keywords:
            matches = re.findall(pattern, text, re.IGNORECASE)
            metadata["detected_jurisdictions"].extend(matches)
        
        # Remove duplicates
        for key in metadata:
            metadata[key] = list(set(metadata[key]))
        
        return metadata

    @staticmethod
    def split_into_sections(text: str, max_section_length: int = 2000) -> list:
        """
        Split text content into logical sections for document processing
        
        Args:
            text: The text content to split
            max_section_length: Maximum length of each section
            
        Returns:
            List of dictionaries with 'title' and 'content' keys
        """
        sections = []
        
        if not text or len(text.strip()) == 0:
            return sections
        
        # Clean the text first
        text = TextExtractor._clean_text(text)
        
        # Try to split by headings first (HTML headings or numbered sections)
        heading_patterns = [
            r'\n\s*<h[1-6][^>]*>([^<]+)</h[1-6]>',  # HTML headings
            r'\n\s*(\d+\.\s+[A-Z][^\n]{10,80})\n',  # Numbered sections
            r'\n\s*([A-Z][A-Z\s]{10,80})\n',        # ALL CAPS headings
            r'\n\s*([A-Z][a-z\s]{15,80}:)\s*\n'     # Title: format
        ]
        
        split_points = []
        for pattern in heading_patterns:
            matches = list(re.finditer(pattern, text, re.MULTILINE))
            for match in matches:
                split_points.append({
                    'position': match.start(),
                    'title': match.group(1).strip(),
                    'end': match.end()
                })
        
        # Sort split points by position
        split_points.sort(key=lambda x: x['position'])
        
        if split_points:
            # Create sections based on headings
            for i, point in enumerate(split_points):
                start_pos = point['end']
                end_pos = split_points[i + 1]['position'] if i + 1 < len(split_points) else len(text)
                
                content = text[start_pos:end_pos].strip()
                if content:
                    # Further split if section is too long
                    if len(content) > max_section_length:
                        subsections = TextExtractor._split_long_section(content, max_section_length)
                        for j, subsection in enumerate(subsections):
                            section_title = point['title']
                            if len(subsections) > 1:
                                section_title += f" (Part {j + 1})"
                            sections.append({
                                'title': section_title,
                                'content': subsection
                            })
                    else:
                        sections.append({
                            'title': point['title'],
                            'content': content
                        })
        else:
            # No clear headings found, split by paragraphs or length
            paragraphs = text.split('\n\n')
            current_section = ""
            section_num = 1
            
            for paragraph in paragraphs:
                paragraph = paragraph.strip()
                if not paragraph:
                    continue
                    
                if len(current_section + paragraph) > max_section_length and current_section:
                    # Save current section
                    sections.append({
                        'title': f'Section {section_num}',
                        'content': current_section.strip()
                    })
                    current_section = paragraph + '\n\n'
                    section_num += 1
                else:
                    current_section += paragraph + '\n\n'
            
            # Add final section
            if current_section.strip():
                sections.append({
                    'title': f'Section {section_num}',
                    'content': current_section.strip()
                })
        
        # Ensure we have at least one section
        if not sections and text.strip():
            sections.append({
                'title': 'Document Content',
                'content': text[:max_section_length] if len(text) > max_section_length else text
            })
        
        return sections

    @staticmethod
    def _split_long_section(content: str, max_length: int) -> list:
        """
        Split a long section into smaller chunks
        """
        sections = []
        sentences = re.split(r'(?<=[.!?])\s+', content)
        current_chunk = ""
        
        for sentence in sentences:
            if len(current_chunk + sentence) > max_length and current_chunk:
                sections.append(current_chunk.strip())
                current_chunk = sentence + " "
            else:
                current_chunk += sentence + " "
        
        if current_chunk.strip():
            sections.append(current_chunk.strip())
        
        return sections if sections else [content]

    @staticmethod
    def create_document_sections(text: str, document_id: int) -> list:
        """
        Create document sections with database-ready format
        
        Args:
            text: The text content to split
            document_id: ID of the document
            
        Returns:
            List of dictionaries ready for database insertion
        """
        sections = TextExtractor.split_into_sections(text)
        db_sections = []
        
        for i, section in enumerate(sections):
            db_sections.append({
                'section_number': str(i + 1),
                'section_title': section['title'],
                'section_content': section['content'],
                'display_order': i + 1,
                'word_count': len(section['content'].split())
            })
        
        return db_sections
