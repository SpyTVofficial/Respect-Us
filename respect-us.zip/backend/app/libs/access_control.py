import asyncpg
import databutton as db
from typing import Optional, Dict, Any
from app.auth import AuthorizedUser

class AccessControl:
    """
    Utility class for checking user access to modules and templates
    """
    
    @staticmethod
    async def get_db_connection():
        database_url = db.secrets.get("DATABASE_URL_DEV")
        return await asyncpg.connect(database_url)
    
    @staticmethod
    async def check_module_access(user_id: str, module_name: str) -> bool:
        """
        Check if user has access to a specific module
        """
        try:
            conn = await AccessControl.get_db_connection()
            
            result = await conn.fetchrow(
                """
                SELECT id FROM user_module_access 
                WHERE user_id = $1 AND module_name = $2 AND access_status = 'active'
                AND (expires_at IS NULL OR expires_at > NOW())
                """,
                user_id, module_name
            )
            
            await conn.close()
            return result is not None
            
        except Exception as e:
            print(f"Error checking module access: {e}")
            return False
    
    @staticmethod
    async def check_template_access(user_id: str, template_id: int) -> bool:
        """
        Check if user has access to a specific template
        """
        try:
            conn = await AccessControl.get_db_connection()
            
            result = await conn.fetchrow(
                """
                SELECT id FROM user_module_access 
                WHERE user_id = $1 AND template_id = $2 AND access_status = 'active'
                AND (expires_at IS NULL OR expires_at > NOW())
                """,
                user_id, template_id
            )
            
            await conn.close()
            return result is not None
            
        except Exception as e:
            print(f"Error checking template access: {e}")
            return False
    
    @staticmethod
    async def get_user_template_access(user_id: str, module_name: str) -> Optional[Dict[str, Any]]:
        """
        Get user's template access details for a specific module
        """
        try:
            conn = await AccessControl.get_db_connection()
            
            result = await conn.fetchrow(
                """
                SELECT template_id, access_type, expires_at, created_at
                FROM user_module_access 
                WHERE user_id = $1 AND module_name = $2 AND access_status = 'active'
                AND (expires_at IS NULL OR expires_at > NOW())
                """,
                user_id, module_name
            )
            
            await conn.close()
            
            if result:
                return {
                    "template_id": result['template_id'],
                    "access_type": result['access_type'],
                    "expires_at": result['expires_at'].isoformat() if result['expires_at'] else None,
                    "granted_at": result['created_at'].isoformat()
                }
            
            return None
            
        except Exception as e:
            print(f"Error getting user template access: {e}")
            return None

# Middleware function to check access
async def require_module_access(user: AuthorizedUser, module_name: str):
    """
    Middleware function to check if user has access to a module
    Raises HTTPException if access denied
    """
    from fastapi import HTTPException
    
    has_access = await AccessControl.check_module_access(user.sub, module_name)
    if not has_access:
        raise HTTPException(
            status_code=403, 
            detail=f"Access denied. Please purchase access to {module_name} module."
        )

async def require_template_access(user: AuthorizedUser, template_id: int):
    """
    Middleware function to check if user has access to a template
    Raises HTTPException if access denied
    """
    from fastapi import HTTPException
    
    has_access = await AccessControl.check_template_access(user.sub, template_id)
    if not has_access:
        raise HTTPException(
            status_code=403, 
            detail=f"Access denied. Please purchase access to this template."
        )
