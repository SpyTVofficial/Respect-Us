
from datetime import datetime, timedelta
from typing import Any, Dict, Optional, Union
import json
import hashlib

class PerformanceCache:
    """
    In-memory cache for search results and document content.
    In production, this would be replaced with Redis or similar.
    """
    
    def __init__(self):
        self._cache: Dict[str, Dict[str, Any]] = {}
        self._search_cache_ttl = timedelta(minutes=15)  # Search results cache for 15 minutes
        self._document_cache_ttl = timedelta(hours=2)   # Document content cache for 2 hours
        self._metadata_cache_ttl = timedelta(hours=24)  # Metadata cache for 24 hours
    
    def _generate_cache_key(self, prefix: str, **kwargs) -> str:
        """Generate a unique cache key based on parameters"""
        # Sort kwargs for consistent key generation
        sorted_params = sorted(kwargs.items())
        params_str = json.dumps(sorted_params, sort_keys=True)
        params_hash = hashlib.md5(params_str.encode()).hexdigest()
        return f"{prefix}:{params_hash}"
    
    def _is_expired(self, entry: Dict[str, Any]) -> bool:
        """Check if cache entry is expired"""
        if 'expires_at' not in entry:
            return True
        return datetime.now() > entry['expires_at']
    
    def get_search_results(self, search_query: str, filters: Dict[str, Any], 
                          page: int = 1, per_page: int = 20) -> Optional[Any]:
        """Get cached search results"""
        cache_key = self._generate_cache_key(
            "search", 
            query=search_query,
            filters=filters,
            page=page,
            per_page=per_page
        )
        
        if cache_key in self._cache:
            entry = self._cache[cache_key]
            if not self._is_expired(entry):
                return entry['data']
            else:
                # Remove expired entry
                del self._cache[cache_key]
        
        return None
    
    def set_search_results(self, search_query: str, filters: Dict[str, Any], 
                          page: int, per_page: int, data: Any) -> None:
        """Cache search results"""
        cache_key = self._generate_cache_key(
            "search",
            query=search_query,
            filters=filters,
            page=page,
            per_page=per_page
        )
        
        self._cache[cache_key] = {
            'data': data,
            'expires_at': datetime.now() + self._search_cache_ttl,
            'created_at': datetime.now()
        }
    
    def get_document_content(self, document_id: int) -> Optional[Any]:
        """Get cached document content"""
        cache_key = self._generate_cache_key("document", doc_id=document_id)
        
        if cache_key in self._cache:
            entry = self._cache[cache_key]
            if not self._is_expired(entry):
                return entry['data']
            else:
                del self._cache[cache_key]
        
        return None
    
    def set_document_content(self, document_id: int, data: Any) -> None:
        """Cache document content"""
        cache_key = self._generate_cache_key("document", doc_id=document_id)
        
        self._cache[cache_key] = {
            'data': data,
            'expires_at': datetime.now() + self._document_cache_ttl,
            'created_at': datetime.now()
        }
    
    def get_document_sections(self, document_id: int) -> Optional[Any]:
        """Get cached document sections"""
        cache_key = self._generate_cache_key("sections", doc_id=document_id)
        
        if cache_key in self._cache:
            entry = self._cache[cache_key]
            if not self._is_expired(entry):
                return entry['data']
            else:
                del self._cache[cache_key]
        
        return None
    
    def set_document_sections(self, document_id: int, data: Any) -> None:
        """Cache document sections"""
        cache_key = self._generate_cache_key("sections", doc_id=document_id)
        
        self._cache[cache_key] = {
            'data': data,
            'expires_at': datetime.now() + self._document_cache_ttl,
            'created_at': datetime.now()
        }
    
    def get_metadata(self, cache_type: str, **kwargs) -> Optional[Any]:
        """Get cached metadata (countries, sanctions, etc.)"""
        cache_key = self._generate_cache_key(f"metadata_{cache_type}", **kwargs)
        
        if cache_key in self._cache:
            entry = self._cache[cache_key]
            if not self._is_expired(entry):
                return entry['data']
            else:
                del self._cache[cache_key]
        
        return None
    
    def set_metadata(self, cache_type: str, data: Any, **kwargs) -> None:
        """Cache metadata"""
        cache_key = self._generate_cache_key(f"metadata_{cache_type}", **kwargs)
        
        self._cache[cache_key] = {
            'data': data,
            'expires_at': datetime.now() + self._metadata_cache_ttl,
            'created_at': datetime.now()
        }
    
    def invalidate_document(self, document_id: int) -> None:
        """Invalidate all cache entries for a specific document"""
        keys_to_remove = []
        for key in self._cache.keys():
            if f'"doc_id":"{document_id}"' in key:
                keys_to_remove.append(key)
        
        for key in keys_to_remove:
            del self._cache[key]
    
    def invalidate_search_cache(self) -> None:
        """Invalidate all search cache entries"""
        keys_to_remove = [key for key in self._cache.keys() if key.startswith('search:')]
        for key in keys_to_remove:
            del self._cache[key]
    
    def clear_all(self) -> None:
        """Clear all cache entries"""
        self._cache.clear()
    
    def get_cache_stats(self) -> Dict[str, Any]:
        """Get cache statistics"""
        total_entries = len(self._cache)
        expired_entries = sum(1 for entry in self._cache.values() if self._is_expired(entry))
        
        cache_types = {}
        for key in self._cache.keys():
            cache_type = key.split(':')[0]
            cache_types[cache_type] = cache_types.get(cache_type, 0) + 1
        
        return {
            'total_entries': total_entries,
            'expired_entries': expired_entries,
            'active_entries': total_entries - expired_entries,
            'cache_types': cache_types,
            'cache_hit_potential': (total_entries - expired_entries) / max(total_entries, 1)
        }

# Global cache instance
performance_cache = PerformanceCache()
