import requests
from bs4 import BeautifulSoup
from typing import Dict, Optional, List
import re
from datetime import datetime
from urllib.parse import urljoin, urlparse
import time

class WebContentExtractor:
    """Extract and clean content from web URLs for knowledge base ingestion"""
    
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Respectus Knowledge Base Bot 1.0 (Export Control Compliance Platform)'
        })
        
    def extract_content(self, url: str) -> Dict:
        """Extract content from a web URL
        
        Returns:
            Dict containing:
            - title: Page title
            - content: Main text content
            - publication_date: Extracted publication date (if found)
            - author: Author information (if found)
            - metadata: Additional metadata
            - word_count: Number of words in content
            - success: Boolean indicating extraction success
            - error: Error message if extraction failed
        """
        try:
            print(f"Extracting content from URL: {url}")
            
            # Fetch the webpage
            response = self.session.get(url, timeout=30)
            response.raise_for_status()
            
            # Parse HTML
            soup = BeautifulSoup(response.content, 'html.parser')
            
            # Extract title
            title = self._extract_title(soup, url)
            
            # Extract main content
            content = self._extract_main_content(soup)
            
            # Extract metadata
            publication_date = self._extract_publication_date(soup)
            author = self._extract_author(soup)
            
            # Calculate word count
            word_count = len(content.split()) if content else 0
            
            # Additional metadata
            metadata = {
                'domain': urlparse(url).netloc,
                'extracted_at': datetime.now().isoformat(),
                'content_length': len(content) if content else 0,
                'has_author': bool(author),
                'has_date': bool(publication_date)
            }
            
            return {
                'title': title,
                'content': content,
                'publication_date': publication_date,
                'author': author,
                'metadata': metadata,
                'word_count': word_count,
                'success': True,
                'error': None
            }
            
        except requests.RequestException as e:
            print(f"Request error extracting from {url}: {str(e)}")
            return {
                'success': False,
                'error': f"Failed to fetch URL: {str(e)}",
                'title': None,
                'content': None,
                'publication_date': None,
                'author': None,
                'metadata': {},
                'word_count': 0
            }
        except Exception as e:
            print(f"Error extracting content from {url}: {str(e)}")
            return {
                'success': False,
                'error': f"Content extraction failed: {str(e)}",
                'title': None,
                'content': None,
                'publication_date': None,
                'author': None,
                'metadata': {},
                'word_count': 0
            }
    
    def _extract_title(self, soup: BeautifulSoup, url: str) -> str:
        """Extract page title"""
        # Try multiple title sources
        title_selectors = [
            'h1',
            'title',
            '[property="og:title"]',
            '[name="twitter:title"]',
            '.article-title',
            '.post-title',
            '.entry-title'
        ]
        
        for selector in title_selectors:
            element = soup.select_one(selector)
            if element:
                title = element.get_text(strip=True)
                if title and len(title) > 10:  # Reasonable title length
                    return title
        
        # Fallback to URL-based title
        return f"Document from {urlparse(url).netloc}"
    
    def _extract_main_content(self, soup: BeautifulSoup) -> str:
        """Extract main article/content text"""
        # Remove unwanted elements
        for element in soup(['script', 'style', 'nav', 'header', 'footer', 
                           'aside', 'advertisement', '.ad', '.sidebar']):
            element.decompose()
        
        # Try to find main content areas
        content_selectors = [
            'article',
            '[role="main"]',
            '.content',
            '.article-content',
            '.post-content',
            '.entry-content',
            '.main-content',
            'main',
            '#content'
        ]
        
        main_content = None
        for selector in content_selectors:
            element = soup.select_one(selector)
            if element:
                main_content = element
                break
        
        # If no main content area found, use body
        if not main_content:
            main_content = soup.find('body')
        
        if not main_content:
            return ""
        
        # Extract and clean text
        text = main_content.get_text(separator='\n', strip=True)
        
        # Clean up whitespace and empty lines
        lines = [line.strip() for line in text.split('\n') if line.strip()]
        content = '\n'.join(lines)
        
        # Remove very short content (likely not article content)
        if len(content) < 100:
            return ""
        
        return content
    
    def _extract_publication_date(self, soup: BeautifulSoup) -> Optional[str]:
        """Extract publication date from various sources"""
        date_selectors = [
            '[property="article:published_time"]',
            '[name="dcterms.created"]',
            '[name="DC.date.created"]',
            '[name="date"]',
            '[itemprop="datePublished"]',
            '[class*="date"]',
            '[class*="published"]',
            'time[datetime]'
        ]
        
        for selector in date_selectors:
            element = soup.select_one(selector)
            if element:
                # Try different attribute names
                date_value = (element.get('content') or 
                             element.get('datetime') or 
                             element.get_text(strip=True))
                
                if date_value:
                    # Try to parse and normalize date
                    try:
                        # Basic date parsing - can be enhanced
                        if 'T' in date_value or '-' in date_value:
                            return date_value[:10]  # Return YYYY-MM-DD format
                    except Exception:
                        continue
        
        return None
    
    def _extract_author(self, soup: BeautifulSoup) -> Optional[str]:
        """Extract author information"""
        author_selectors = [
            '[name="author"]',
            '[property="article:author"]',
            '[itemprop="author"]',
            '[rel="author"]',
            '.author',
            '.byline',
            '.article-author'
        ]
        
        for selector in author_selectors:
            element = soup.select_one(selector)
            if element:
                author = element.get('content') or element.get_text(strip=True)
                if author and len(author) < 200:  # Reasonable author length
                    return author
        
        return None
    
    def validate_url(self, url: str) -> Dict[str, any]:
        """Validate if URL is accessible and appears to contain meaningful content"""
        try:
            # Basic URL format validation
            parsed = urlparse(url)
            if not parsed.scheme or not parsed.netloc:
                return {
                    'valid': False,
                    'error': 'Invalid URL format. Please include http:// or https://'
                }
            
            # Test accessibility
            response = self.session.head(url, timeout=10)
            
            # Check content type
            content_type = response.headers.get('content-type', '').lower()
            if 'text/html' not in content_type:
                return {
                    'valid': False,
                    'error': f'URL does not appear to be a webpage (content-type: {content_type})'
                }
            
            return {
                'valid': True,
                'content_type': content_type,
                'status_code': response.status_code
            }
            
        except requests.RequestException as e:
            return {
                'valid': False,
                'error': f'Cannot access URL: {str(e)}'
            }
        except Exception as e:
            return {
                'valid': False,
                'error': f'URL validation failed: {str(e)}'
            }
