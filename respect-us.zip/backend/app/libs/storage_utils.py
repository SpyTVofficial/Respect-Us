import re
from typing import Optional

def sanitize_storage_key(key: str) -> str:
    """
    Sanitize a storage key to only contain valid characters.
    
    Storage keys can only contain:
    - Letters (A-Z, a-z)
    - Digits (0-9) 
    - Symbols: . _ -
    
    Note: Forward slashes are NOT allowed in Databutton storage keys!
    
    Args:
        key: The storage key to sanitize
        
    Returns:
        Sanitized storage key with only valid characters
    """
    if not key:
        return "file"
    
    # Replace ALL invalid characters including forward slashes with underscores
    sanitized = re.sub(r'[^a-zA-Z0-9._-]', '_', key)
    
    # Clean up multiple underscores
    sanitized = re.sub(r'_+', '_', sanitized)
    
    # Remove leading/trailing underscores, dots, or hyphens
    sanitized = sanitized.strip('._-')
    
    # Ensure we don't have an empty result
    if not sanitized:
        return "file"
        
    return sanitized

def sanitize_filename(filename: Optional[str], default_name: str = "file", default_ext: str = "txt") -> str:
    """
    Sanitize a filename to only contain valid characters while preserving extension.
    
    Args:
        filename: The filename to sanitize
        default_name: Default name if filename is invalid
        default_ext: Default extension if no valid extension found
        
    Returns:
        Sanitized filename with valid characters only
    """
    if not filename:
        return f"{default_name}.{default_ext}"
    
    # Split filename and extension
    if '.' in filename:
        name_parts = filename.rsplit('.', 1)
        name_part = name_parts[0]
        ext_part = name_parts[1] if len(name_parts) > 1 else default_ext
    else:
        name_part = filename
        ext_part = default_ext
    
    # Sanitize name part - remove ALL invalid characters (keep first 50 chars for reasonable length)
    safe_name = re.sub(r'[^a-zA-Z0-9_-]', '_', name_part)[:50]
    # Clean up multiple underscores and leading/trailing underscores
    safe_name = re.sub(r'_+', '_', safe_name).strip('_')
    if not safe_name:
        safe_name = default_name
    
    # Sanitize extension (keep first 5 chars)
    safe_ext = re.sub(r'[^a-zA-Z0-9]', '', ext_part)[:5]
    if not safe_ext:
        safe_ext = default_ext
    
    return f"{safe_name}.{safe_ext}"
