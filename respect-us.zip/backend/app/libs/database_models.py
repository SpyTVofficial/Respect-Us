# Database models for Respectus
# This file contains Python models that reflect the database schema

from typing import Optional, List
from uuid import UUID
from datetime import datetime
from pydantic import BaseModel

# =============================================================================
# Classification Trees Models
# =============================================================================

class ClassificationTreeModel(BaseModel):
    """Model for classification trees table"""
    id: UUID
    name: str
    description: Optional[str]
    jurisdiction: str
    category: str
    version: int
    status: str  # 'draft', 'published', 'archived'
    created_by: Optional[str]
    created_at: datetime
    updated_at: datetime
    published_at: Optional[datetime]
    introduction_tree_id: Optional[UUID]  # Links to introduction trees
    is_introduction_template: bool

class TreeNodeModel(BaseModel):
    """Model for tree_nodes table"""
    id: UUID
    tree_id: UUID  # Foreign key to classification_trees
    node_key: str
    title: str
    description: Optional[str]
    question_text: str
    question_type: str  # 'multiple_choice', 'text', etc.
    is_root: bool
    parent_node_id: Optional[UUID]  # Self-referential foreign key
    display_order: int
    created_at: datetime
    updated_at: datetime
    notes: Optional[str]

class NodeOptionModel(BaseModel):
    """Model for node_options table"""
    id: UUID
    node_id: UUID  # Foreign key to tree_nodes
    option_text: str
    option_value: str
    routing_rule: Optional[str]
    regulatory_notes: Optional[List[str]]  # Array of strings
    display_order: int
    created_at: datetime
    note: Optional[str]

# =============================================================================
# Introduction Trees Models (NEW)
# =============================================================================

class IntroductionTreeModel(BaseModel):
    """Model for introduction_trees table"""
    id: UUID
    name: str
    description: Optional[str]
    jurisdiction: str
    category: str
    version: int
    status: str  # 'draft', 'published', 'archived'
    created_by: Optional[str]
    created_at: datetime
    updated_at: datetime
    published_at: Optional[datetime]
    classification_tree_id: Optional[UUID]  # Links to classification trees
    is_classification_template: bool

class IntroductionTreeNodeModel(BaseModel):
    """Model for introduction_tree_nodes table"""
    id: UUID
    tree_id: UUID  # Foreign key to introduction_trees
    node_key: str
    title: str
    description: Optional[str]
    question_text: str
    question_type: str  # 'multiple_choice', 'text', etc.
    is_root: bool
    parent_node_id: Optional[UUID]  # Self-referential foreign key
    display_order: int
    created_at: datetime
    updated_at: datetime
    notes: Optional[str]

class IntroductionNodeOptionModel(BaseModel):
    """Model for introduction_node_options table"""
    id: UUID
    node_id: UUID  # Foreign key to introduction_tree_nodes
    option_text: str
    option_value: str
    routing_rule: Optional[str]
    regulatory_notes: Optional[List[str]]  # Array of strings
    display_order: int
    created_at: datetime
    note: Optional[str]

# =============================================================================
# Knowledge Base Models
# =============================================================================

class KBDocumentModel(BaseModel):
    """Model for kb_documents table"""
    id: int
    title: str
    description: Optional[str]
    content: Optional[str]
    document_type: str
    jurisdiction: str
    category_id: Optional[int]
    file_url: Optional[str]
    status: str  # 'draft', 'published', 'archived'
    created_at: datetime
    updated_at: datetime
    created_by: Optional[str]
    tags: Optional[List[str]]
    metadata: Optional[dict]

class KBCategoryModel(BaseModel):
    """Model for kb_categories table"""
    id: int
    name: str
    description: Optional[str]
    parent_category_id: Optional[int]
    display_order: int
    created_at: datetime
    updated_at: datetime

# =============================================================================
# User and Assessment Models
# =============================================================================

class UserProfileModel(BaseModel):
    """Model for user_profiles table"""
    id: int
    user_id: str  # Stack Auth user ID
    company_name: Optional[str]
    contact_person: Optional[str]
    email: Optional[str]
    phone: Optional[str]
    billing_address: Optional[str]
    city: Optional[str]
    postal_code: Optional[str]
    country: Optional[str]
    tax_id: Optional[str]
    vat_number: Optional[str]
    created_at: datetime
    updated_at: datetime

class SavedAssessmentModel(BaseModel):
    """Model for saved_assessments table"""
    id: int
    assessment_id: str  # Unique identifier
    user_id: str  # Stack Auth user ID
    template_id: int  # Foreign key to risk_assessment_templates
    assessment_data: dict  # JSON data
    company_name: Optional[str]
    created_at: datetime
    updated_at: datetime
    status: str  # 'draft', 'completed', 'submitted'

class ValidationRequestModel(BaseModel):
    """Model for validation_requests table"""
    id: int
    validation_id: str  # Unique identifier
    user_id: str  # Stack Auth user ID
    assessment_id: str
    assessment_data: dict  # JSON data
    company_name: str
    contact_email: str
    priority: str  # 'standard', 'priority'
    status: str  # 'submitted', 'under_review', 'validated', 'needs_revision'
    admin_notes: Optional[str]
    created_at: datetime
    updated_at: datetime

# =============================================================================
# Risk Assessment Models
# =============================================================================

class RiskAssessmentTemplateModel(BaseModel):
    """Model for risk_assessment_templates table"""
    id: int
    title: str
    description: str
    how_it_works: str
    sections: List[dict]  # JSON array of sections
    status: str  # 'active', 'inactive'
    created_at: datetime
    updated_at: datetime
    created_by: str

class CompanyRiskFormModel(BaseModel):
    """Model for company_risk_forms table"""
    id: int
    template_id: int  # Foreign key to risk_assessment_templates
    company_name: str
    customizations: dict  # JSON data
    created_at: datetime
    user_id: str  # Stack Auth user ID

# =============================================================================
# Payment and Subscription Models
# =============================================================================

class CustomerDataModel(BaseModel):
    """Model for customer_data table"""
    customer_id: str
    user_id: str  # Stack Auth user ID
    email: str
    name: Optional[str]
    stripe_customer_id: Optional[str]
    subscription_status: Optional[str]
    modules_access: Optional[List[str]]  # Array of module names
    created_at: datetime
    updated_at: datetime
