# Deprecated: This file is deprecated. Use database_models.py instead.
# All database models have been moved to database_models.py for better organization.

# Import from the new location for backward compatibility
from database_models import *
