"""Routing rule parser for complex routing rules with intermediate outcomes."""

from typing import Dict, Optional, Tuple, Union
import re
import json

class RoutingRule:
    """Represents a parsed routing rule."""
    
    def __init__(self, raw_rule: str):
        self.raw_rule = raw_rule
        self.is_simple = True
        self.is_complex = False
        self.target = None
        self.outcome_code = None
        self.continue_target = None
        self.format_type = None  # 'simple', 'complex_semicolon', 'complex_json'
        
        self._parse()
    
    def _parse(self):
        """Parse the routing rule into its components."""
        if not self.raw_rule:
            return
            
        rule = self.raw_rule.strip()
        
        # Check for complex routing rule formats
        if self._parse_complex_semicolon(rule):
            return
        elif self._parse_complex_json(rule):
            return
        else:
            self._parse_simple(rule)
    
    def _parse_complex_semicolon(self, rule: str) -> bool:
        """Parse semicolon-separated format: outcome: "code"; continue: target"""
        if ';' not in rule or 'outcome:' not in rule or 'continue:' not in rule:
            return False
            
        self.is_simple = False
        self.is_complex = True
        self.format_type = 'complex_semicolon'
        
        # Split by semicolon and parse each part
        parts = rule.split(';')
        
        for part in parts:
            part = part.strip()
            if part.startswith('outcome:'):
                outcome_value = part.replace('outcome:', '').strip()
                # Remove quotes if present
                self.outcome_code = outcome_value.strip('"').strip("'")
            elif part.startswith('continue:'):
                continue_value = part.replace('continue:', '').strip()
                # Remove quotes if present
                self.continue_target = continue_value.strip('"').strip("'")
        
        return True
    
    def _parse_complex_json(self, rule: str) -> bool:
        """Parse JSON format: {"outcome": "code", "continue": "target"}"""
        if not rule.startswith('{') or not rule.endswith('}'):
            return False
            
        try:
            parsed = json.loads(rule)
            if not isinstance(parsed, dict):
                return False
                
            if 'outcome' not in parsed or 'continue' not in parsed:
                return False
                
            self.is_simple = False
            self.is_complex = True
            self.format_type = 'complex_json'
            self.outcome_code = str(parsed['outcome']).strip('"').strip("'")
            self.continue_target = str(parsed['continue']).strip('"').strip("'")
            
            return True
        except (json.JSONDecodeError, KeyError):
            return False
    
    def _parse_simple(self, rule: str):
        """Parse simple format: -> target or target or "target"""
        self.is_simple = True
        self.is_complex = False
        self.format_type = 'simple'
        
        # Remove arrow notation if present
        target = rule.replace('->', '').strip()
        
        # Remove quotes if present
        self.target = target.strip('"').strip("'")
    
    def has_intermediate_outcome(self) -> bool:
        """Check if this routing rule produces an intermediate outcome."""
        return self.is_complex and self.outcome_code is not None
    
    def get_next_target(self) -> Optional[str]:
        """Get the next navigation target."""
        if self.is_complex:
            return self.continue_target
        else:
            return self.target
    
    def __repr__(self):
        return f"RoutingRule(raw='{self.raw_rule}', simple={self.is_simple}, outcome='{self.outcome_code}', target='{self.get_next_target()}')"


def parse_routing_rule(raw_rule: str) -> RoutingRule:
    """Parse a routing rule string into a RoutingRule object.
    
    Supported formats:
    - Simple: "6.4.1" or "-> 6.4.1" or "CLASSIFICATION_START"
    - Complex semicolon: 'outcome: "outcome-eu-ml-no"; continue: 6.4.1'
    - Complex JSON: '{"outcome": "outcome-eu-ml-no", "continue": "6.4.1"}'
    
    Args:
        raw_rule: The raw routing rule string
        
    Returns:
        RoutingRule object with parsed components
    """
    return RoutingRule(raw_rule)


def validate_routing_rule(raw_rule: str) -> Tuple[bool, Optional[str]]:
    """Validate a routing rule and return validation result.
    
    Args:
        raw_rule: The raw routing rule string
        
    Returns:
        Tuple of (is_valid, error_message)
    """
    if not raw_rule or not raw_rule.strip():
        return False, "Routing rule cannot be empty"
    
    try:
        rule = parse_routing_rule(raw_rule)
        
        if rule.is_complex:
            if not rule.outcome_code:
                return False, "Complex routing rule must specify an outcome code"
            if not rule.continue_target:
                return False, "Complex routing rule must specify a continue target"
        elif rule.is_simple:
            if not rule.target:
                return False, "Simple routing rule must specify a target"
        else:
            return False, "Unable to parse routing rule format"
            
        return True, None
        
    except Exception as e:
        return False, f"Error parsing routing rule: {str(e)}"
