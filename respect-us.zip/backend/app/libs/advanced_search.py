"""Advanced Search Library for Knowledge Base

Provides Boolean search, advanced filtering, and section-specific search capabilities.
"""

import re
from typing import List, Dict, Any, Optional, Union
from enum import Enum
import asyncpg
from dataclasses import dataclass

class SearchOperator(Enum):
    AND = "AND"
    OR = "OR"
    NOT = "NOT"
    PHRASE = "PHRASE"
    WILDCARD = "WILDCARD"
    FUZZY = "FUZZY"

@dataclass
class SearchTerm:
    """Represents a single search term with its operator"""
    term: str
    operator: SearchOperator = SearchOperator.AND
    field: Optional[str] = None  # Specific field to search in
    boost: float = 1.0  # Relevance boost

@dataclass
class SearchFilter:
    """Represents a filter to apply to search results"""
    field: str
    value: Union[str, List[str], Dict[str, Any]]
    operator: str = "="  # =, !=, IN, NOT IN, LIKE, BETWEEN

@dataclass
class SearchResult:
    """Enhanced search result with relevance scoring"""
    document_id: int
    title: str
    content_snippet: str
    relevance_score: float
    document_type: Optional[str] = None
    issuing_authority: Optional[str] = None
    publication_date: Optional[str] = None
    tags: Optional[List[str]] = None
    section_matches: Optional[List[Dict[str, Any]]] = None
    highlight_fragments: Optional[List[str]] = None

class AdvancedSearchEngine:
    """Advanced search engine with Boolean operators and filtering"""
    
    def __init__(self, db_connection: asyncpg.Connection):
        self.db = db_connection
        
    def parse_search_query(self, query: str) -> List[SearchTerm]:
        """Parse natural language query into structured search terms
        
        Supports:
        - Boolean operators: term1 AND term2, term1 OR term2, NOT term
        - Phrase search: "exact phrase"
        - Wildcard search: term*
        - Field-specific search: title:term, content:term
        - Fuzzy search: term~
        """
        terms = []
        
        # Remove extra spaces and normalize
        query = re.sub(r'\s+', ' ', query.strip())
        
        # Split by boolean operators while preserving phrases
        pattern = r'"([^"]*)"|([^\s]+)'
        tokens = re.findall(pattern, query)
        
        current_operator = SearchOperator.AND
        i = 0
        
        while i < len(tokens):
            phrase, word = tokens[i]
            term_text = phrase if phrase else word
            
            # Check for boolean operators
            if term_text.upper() in ['AND', 'OR', 'NOT']:
                if term_text.upper() == 'AND':
                    current_operator = SearchOperator.AND
                elif term_text.upper() == 'OR':
                    current_operator = SearchOperator.OR
                elif term_text.upper() == 'NOT':
                    current_operator = SearchOperator.NOT
                i += 1
                continue
            
            # Check for field-specific search (field:term)
            field = None
            if ':' in term_text and not phrase:
                field_parts = term_text.split(':', 1)
                if len(field_parts) == 2:
                    field, term_text = field_parts
            
            # Determine search type
            search_op = SearchOperator.AND
            if phrase:
                search_op = SearchOperator.PHRASE
            elif term_text.endswith('*'):
                search_op = SearchOperator.WILDCARD
                term_text = term_text[:-1]  # Remove asterisk
            elif term_text.endswith('~'):
                search_op = SearchOperator.FUZZY
                term_text = term_text[:-1]  # Remove tilde
            else:
                search_op = current_operator
            
            terms.append(SearchTerm(
                term=term_text,
                operator=search_op,
                field=field
            ))
            
            current_operator = SearchOperator.AND  # Reset to default
            i += 1
        
        return terms
    
    def build_search_conditions(self, terms: List[SearchTerm]) -> tuple[str, List[Any]]:
        """Build SQL WHERE conditions from search terms"""
        conditions = []
        params = []
        param_count = 1
        
        for term in terms:
            if not term.term.strip():
                continue
                
            # Choose search field
            search_fields = []
            if term.field:
                if term.field.lower() in ['title', 'content', 'description']:
                    search_fields = [f'd.{term.field.lower()}']
                elif term.field.lower() == 'tags':
                    search_fields = ['d.tags']
                else:
                    search_fields = ['d.content_text']
            else:
                search_fields = ['d.title', 'd.content_text', 'd.description']
            
            # Build condition based on operator
            field_conditions = []
            
            for field in search_fields:
                if term.operator == SearchOperator.PHRASE:
                    if field == 'd.tags':
                        field_conditions.append(f"${param_count} = ANY({field})")
                    else:
                        field_conditions.append(f"{field} ILIKE ${param_count}")
                    params.append(f"%{term.term}%")
                    
                elif term.operator == SearchOperator.WILDCARD:
                    if field == 'd.tags':
                        field_conditions.append(f"EXISTS(SELECT 1 FROM unnest({field}) AS tag WHERE tag ILIKE ${param_count})")
                    else:
                        field_conditions.append(f"{field} ILIKE ${param_count}")
                    params.append(f"{term.term}%")
                    
                elif term.operator == SearchOperator.FUZZY:
                    if field != 'd.tags':
                        field_conditions.append(f"similarity({field}, ${param_count}) > 0.3")
                        params.append(term.term)
                    
                else:  # AND, OR, NOT - use full-text search
                    if field == 'd.tags':
                        field_conditions.append(f"EXISTS(SELECT 1 FROM unnest({field}) AS tag WHERE tag ILIKE ${param_count})")
                        params.append(f"%{term.term}%")
                    else:
                        field_conditions.append(f"{field} ILIKE ${param_count}")
                        params.append(f"%{term.term}%")
                
                param_count += 1
            
            if field_conditions:
                combined_condition = f"({' OR '.join(field_conditions)})"
                
                if term.operator == SearchOperator.NOT:
                    combined_condition = f"NOT {combined_condition}"
                
                conditions.append(combined_condition)
        
        return ' AND '.join(conditions) if conditions else '1=1', params
    
    def build_filter_conditions(self, filters: List[SearchFilter]) -> tuple[str, List[Any]]:
        """Build SQL WHERE conditions from filters"""
        conditions = []
        params = []
        param_count = 1
        
        for filter_item in filters:
            field = filter_item.field
            value = filter_item.value
            operator = filter_item.operator
            
            # Map filter fields to database columns
            field_mapping = {
                'document_type': 'd.document_type',
                'issuing_authority': 'd.issuing_authority',
                'legal_status': 'd.legal_status',
                'tags': 'd.tags',
                'publication_date': 'd.publication_date',
                'effective_date': 'd.effective_date',
                'country_jurisdiction': 'd.country_jurisdiction',
                'regulation_type': 'd.regulation_type',
                'subject': 'd.subject'
            }
            
            db_field = field_mapping.get(field, f'd.{field}')
            
            if operator == '=':
                if field in ['tags', 'country_jurisdiction', 'regulation_type', 'subject']:
                    conditions.append(f"${param_count} = ANY({db_field})")
                else:
                    conditions.append(f"{db_field} = ${param_count}")
                params.append(value)
                
            elif operator == 'IN':
                if isinstance(value, list):
                    if field in ['tags', 'country_jurisdiction', 'regulation_type', 'subject']:
                        placeholders = ','.join([f'${param_count + i}' for i in range(len(value))])
                        conditions.append(f"{db_field} && ARRAY[{placeholders}]")
                    else:
                        placeholders = ','.join([f'${param_count + i}' for i in range(len(value))])
                        conditions.append(f"{db_field} IN ({placeholders})")
                    params.extend(value)
                    param_count += len(value) - 1
                    
            elif operator == 'LIKE':
                conditions.append(f"{db_field} ILIKE ${param_count}")
                params.append(f"%{value}%")
                
            elif operator == 'BETWEEN' and isinstance(value, dict):
                if 'start' in value and 'end' in value:
                    conditions.append(f"{db_field} BETWEEN ${param_count} AND ${param_count + 1}")
                    params.extend([value['start'], value['end']])
                    param_count += 1
            
            param_count += 1
        
        return ' AND '.join(conditions) if conditions else '1=1', params
    
    async def search_documents(
        self,
        query: str = "",
        filters: Optional[List[SearchFilter]] = None,
        search_sections: bool = False,
        limit: int = 50,
        offset: int = 0,
        sort_by: str = "relevance"
    ) -> Dict[str, Any]:
        """Execute advanced search with Boolean operators and filtering"""
        
        # Parse search terms
        search_terms = self.parse_search_query(query) if query else []
        filters = filters or []
        
        # Build search conditions
        search_condition, search_params = self.build_search_conditions(search_terms)
        filter_condition, filter_params = self.build_filter_conditions(filters)
        
        # Combine all parameters
        all_params = search_params + filter_params
        
        # Build ORDER BY clause
        order_clause = "d.created_at DESC"
        if sort_by == "relevance" and search_terms:
            # Create relevance scoring
            relevance_parts = []
            for i, term in enumerate(search_terms):
                if term.field:
                    field = f'd.{term.field}' if term.field in ['title', 'content_text', 'description'] else 'd.content_text'
                else:
                    field = 'd.title'
                relevance_parts.append(f"CASE WHEN {field} ILIKE '%{term.term}%' THEN {2.0 if field == 'd.title' else 1.0} ELSE 0 END")
            
            if relevance_parts:
                order_clause = f"({' + '.join(relevance_parts)}) DESC, d.created_at DESC"
        elif sort_by == "date":
            order_clause = "d.publication_date DESC NULLS LAST, d.created_at DESC"
        elif sort_by == "title":
            order_clause = "d.title ASC"
        
        # Main query
        base_query = f"""
        SELECT 
            d.id,
            d.title,
            d.description,
            d.document_type,
            d.issuing_authority,
            d.publication_date,
            d.effective_date,
            d.tags,
            d.status,
            CASE 
                WHEN LENGTH(d.content_text) > 300 THEN SUBSTR(d.content_text, 1, 300) || '...'
                ELSE d.content_text
            END as content_snippet,
            d.created_at,
            d.file_name,
            d.file_size,
            d.country_jurisdiction,
            d.regulation_type,
            d.subject
        FROM kb_documents d
        WHERE d.status != 'deleted' 
            AND ({search_condition})
            AND ({filter_condition})
        ORDER BY {order_clause}
        LIMIT ${len(all_params) + 1} OFFSET ${len(all_params) + 2}
        """
        
        # Count query for pagination
        count_query = f"""
        SELECT COUNT(*) as total
        FROM kb_documents d
        WHERE d.status != 'deleted' 
            AND ({search_condition})
            AND ({filter_condition})
        """
        
        try:
            # Execute count query
            count_params = search_params + filter_params
            count_result = await self.db.fetchrow(count_query, *count_params)
            total_count = count_result['total'] if count_result else 0
            
            # Execute main query
            main_params = all_params + [limit, offset]
            documents = await self.db.fetch(base_query, *main_params)
            
            # Convert to SearchResult objects
            results = []
            for doc in documents:
                result = SearchResult(
                    document_id=doc['id'],
                    title=doc['title'],
                    content_snippet=doc['content_snippet'] or '',
                    relevance_score=1.0,  # TODO: Implement proper scoring
                    document_type=doc['document_type'],
                    issuing_authority=doc['issuing_authority'],
                    publication_date=doc['publication_date'].isoformat() if doc['publication_date'] else None,
                    tags=doc['tags'] or []
                )
                results.append(result)
            
            # Search in sections if requested
            section_results = []
            if search_sections and search_terms:
                section_results = await self.search_document_sections(search_terms, filters)
            
            return {
                'documents': [{
                    'id': r.document_id,
                    'title': r.title,
                    'content_snippet': r.content_snippet,
                    'relevance_score': r.relevance_score,
                    'document_type': r.document_type,
                    'issuing_authority': r.issuing_authority,
                    'publication_date': r.publication_date,
                    'tags': r.tags
                } for r in results],
                'sections': section_results,
                'total_count': total_count,
                'has_more': offset + len(results) < total_count,
                'search_terms': [{
                    'term': t.term,
                    'operator': t.operator.value,
                    'field': t.field
                } for t in search_terms],
                'filters_applied': [{
                    'field': f.field,
                    'value': f.value,
                    'operator': f.operator
                } for f in filters]
            }
            
        except Exception as e:
            print(f"Search error: {e}")
            return {
                'documents': [],
                'sections': [],
                'total_count': 0,
                'has_more': False,
                'error': str(e)
            }
    
    async def search_document_sections(
        self,
        search_terms: List[SearchTerm],
        filters: Optional[List[SearchFilter]] = None
    ) -> List[Dict[str, Any]]:
        """Search within document sections"""
        
        if not search_terms:
            return []
        
        # Build search condition for sections
        section_conditions = []
        params = []
        param_count = 1
        
        for term in search_terms:
            if term.operator == SearchOperator.NOT:
                continue  # Skip NOT terms for section search
                
            field_conditions = []
            
            # Search in section title and content
            for field in ['ds.section_title', 'ds.section_content']:
                if term.operator == SearchOperator.PHRASE:
                    field_conditions.append(f"{field} ILIKE ${param_count}")
                    params.append(f"%{term.term}%")
                elif term.operator == SearchOperator.WILDCARD:
                    field_conditions.append(f"{field} ILIKE ${param_count}")
                    params.append(f"{term.term}%")
                else:
                    field_conditions.append(f"{field} ILIKE ${param_count}")
                    params.append(f"%{term.term}%")
                param_count += 1
            
            if field_conditions:
                section_conditions.append(f"({' OR '.join(field_conditions)})")
        
        if not section_conditions:
            return []
        
        query = f"""
        SELECT 
            ds.id as section_id,
            ds.document_id,
            ds.section_number,
            ds.section_title,
            ds.section_type,
            ds.level,
            CASE 
                WHEN LENGTH(ds.section_content) > 200 THEN SUBSTR(ds.section_content, 1, 200) || '...'
                ELSE ds.section_content
            END as section_snippet,
            d.title as document_title,
            d.document_type
        FROM kb_document_sections ds
        JOIN kb_documents d ON ds.document_id = d.id
        WHERE d.status != 'deleted'
            AND ({' AND '.join(section_conditions)})
        ORDER BY d.title, ds.display_order
        LIMIT 20
        """
        
        try:
            sections = await self.db.fetch(query, *params)
            return [{
                'section_id': section['section_id'],
                'document_id': section['document_id'],
                'document_title': section['document_title'],
                'section_number': section['section_number'],
                'section_title': section['section_title'],
                'section_type': section['section_type'],
                'level': section['level'],
                'section_snippet': section['section_snippet'],
                'document_type': section['document_type']
            } for section in sections]
        except Exception as e:
            print(f"Section search error: {e}")
            return []
