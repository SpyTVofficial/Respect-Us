import asyncpg
import stripe
import databutton as db
from datetime import datetime, timedelta
from typing import Optional, Dict, Any
from enum import Enum
import json

class AutoRechargeStatus(Enum):
    ACTIVE = "active"
    PAUSED = "paused"
    FAILED = "failed"
    CANCELLED = "cancelled"

class PaymentStatus(Enum):
    PENDING = "pending"
    COMPLETED = "completed"
    FAILED = "failed"
    REFUNDED = "refunded"

class AutoRechargeManager:
    """Manages automatic credit recharging and subscription billing"""
    
    def __init__(self):
        try:
            stripe_key = db.secrets.get("STRIPE_SECRET_KEY")
            if stripe_key:
                stripe.api_key = stripe_key
            else:
                raise ValueError("STRIPE_SECRET_KEY not found")
        except Exception as e:
            print(f"Stripe configuration error: {e}")
            stripe.api_key = "sk_test_dummy_key_for_testing"
    
    async def get_db_connection(self):
        """Get database connection"""
        try:
            database_url = db.secrets.get("DATABASE_URL_DEV")
            return await asyncpg.connect(database_url)
        except Exception as e:
            print(f"Database connection error: {e}")
            raise
    
    async def setup_auto_recharge(self, user_id: str, recharge_config: Dict[str, Any]) -> Dict[str, Any]:
        """
        Set up auto-recharge for a user
        
        Args:
            user_id: User ID
            recharge_config: {
                'trigger_threshold': int,  # Credits remaining to trigger recharge
                'recharge_amount': int,    # Credits to purchase
                'max_recharges_per_month': int,  # Safety limit
                'payment_method_id': str,  # Stripe payment method ID
                'is_enabled': bool
            }
        """
        conn = await self.get_db_connection()
        try:
            # Create or update auto-recharge configuration
            await conn.execute(
                """
                INSERT INTO auto_recharge_config 
                (user_id, trigger_threshold, recharge_amount, max_recharges_per_month, 
                 payment_method_id, is_enabled, status, created_at, updated_at)
                VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
                ON CONFLICT (user_id) 
                DO UPDATE SET 
                    trigger_threshold = $2,
                    recharge_amount = $3,
                    max_recharges_per_month = $4,
                    payment_method_id = $5,
                    is_enabled = $6,
                    status = $7,
                    updated_at = $9
                """,
                user_id, recharge_config['trigger_threshold'], recharge_config['recharge_amount'],
                recharge_config['max_recharges_per_month'], recharge_config['payment_method_id'],
                recharge_config['is_enabled'], AutoRechargeStatus.ACTIVE.value,
                datetime.now(), datetime.now()
            )
            
            return {
                "status": "success",
                "message": "Auto-recharge configured successfully",
                "config": recharge_config
            }
        finally:
            await conn.close()
    
    async def check_and_trigger_recharge(self, user_id: str) -> Optional[Dict[str, Any]]:
        """
        Check if user needs auto-recharge and trigger if necessary
        
        Returns:
            Dict with recharge details if triggered, None if not needed
        """
        conn = await self.get_db_connection()
        try:
            # Get user's current credit balance and auto-recharge config
            user_data = await conn.fetchrow(
                """
                SELECT 
                    uc.current_balance,
                    arc.trigger_threshold,
                    arc.recharge_amount,
                    arc.max_recharges_per_month,
                    arc.payment_method_id,
                    arc.is_enabled,
                    arc.status
                FROM user_credits uc
                LEFT JOIN auto_recharge_config arc ON uc.user_id = arc.user_id
                WHERE uc.user_id = $1
                """,
                user_id
            )
            
            if not user_data or not user_data['is_enabled'] or user_data['status'] != AutoRechargeStatus.ACTIVE.value:
                return None
            
            # Check if recharge is needed
            if user_data['current_balance'] > user_data['trigger_threshold']:
                return None
            
            # Check monthly recharge limit
            current_month_start = datetime.now().replace(day=1, hour=0, minute=0, second=0, microsecond=0)
            monthly_recharges = await conn.fetchval(
                """
                SELECT COUNT(*) FROM auto_recharge_transactions 
                WHERE user_id = $1 AND created_at >= $2 AND status = $3
                """,
                user_id, current_month_start, PaymentStatus.COMPLETED.value
            )
            
            if monthly_recharges >= user_data['max_recharges_per_month']:
                await self._pause_auto_recharge(conn, user_id, "Monthly limit reached")
                return {
                    "status": "limit_reached",
                    "message": "Monthly auto-recharge limit reached",
                    "monthly_recharges": monthly_recharges,
                    "limit": user_data['max_recharges_per_month']
                }
            
            # Trigger recharge
            return await self._process_auto_recharge(conn, user_id, user_data)
            
        finally:
            await conn.close()
    
    async def _process_auto_recharge(self, conn, user_id: str, user_data) -> Dict[str, Any]:
        """
        Process the actual auto-recharge transaction
        """
        try:
            # Calculate pricing (assuming $0.01 per credit)
            credit_price = 0.01
            amount_cents = int(user_data['recharge_amount'] * credit_price * 100)
            
            # Create transaction record
            transaction_id = f"AUTO_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{user_id[:8]}"
            
            await conn.execute(
                """
                INSERT INTO auto_recharge_transactions 
                (transaction_id, user_id, credit_amount, payment_amount, currency, 
                 payment_method_id, status, stripe_payment_intent_id, created_at)
                VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
                """,
                transaction_id, user_id, user_data['recharge_amount'], 
                amount_cents / 100, 'USD', user_data['payment_method_id'],
                PaymentStatus.PENDING.value, None, datetime.now()
            )
            
            # Process payment with Stripe
            try:
                payment_intent = stripe.PaymentIntent.create(
                    amount=amount_cents,
                    currency='usd',
                    payment_method=user_data['payment_method_id'],
                    confirmation_method='automatic',
                    confirm=True,
                    return_url='https://your-app.com/payment-success',  # Configure this
                    metadata={
                        'user_id': user_id,
                        'transaction_id': transaction_id,
                        'credit_amount': str(user_data['recharge_amount']),
                        'auto_recharge': 'true'
                    }
                )
                
                # Update transaction with Stripe payment intent ID
                await conn.execute(
                    "UPDATE auto_recharge_transactions SET stripe_payment_intent_id = $1 WHERE transaction_id = $2",
                    payment_intent.id, transaction_id
                )
                
                # If payment succeeded immediately
                if payment_intent.status == 'succeeded':
                    await self._complete_auto_recharge(conn, transaction_id, user_id, user_data['recharge_amount'])
                    return {
                        "status": "success",
                        "message": "Auto-recharge completed successfully",
                        "credits_added": user_data['recharge_amount'],
                        "transaction_id": transaction_id
                    }
                else:
                    return {
                        "status": "processing",
                        "message": "Auto-recharge payment processing",
                        "transaction_id": transaction_id,
                        "payment_status": payment_intent.status
                    }
                    
            except stripe.error.CardError as e:
                # Payment failed
                await conn.execute(
                    "UPDATE auto_recharge_transactions SET status = $1, failure_reason = $2 WHERE transaction_id = $3",
                    PaymentStatus.FAILED.value, str(e), transaction_id
                )
                
                # Pause auto-recharge after payment failure
                await self._pause_auto_recharge(conn, user_id, f"Payment failed: {str(e)}")
                
                return {
                    "status": "failed",
                    "message": "Auto-recharge payment failed",
                    "error": str(e),
                    "transaction_id": transaction_id
                }
                
        except Exception as e:
            print(f"Auto-recharge processing error: {e}")
            return {
                "status": "error",
                "message": "Auto-recharge processing failed",
                "error": str(e)
            }
    
    async def _complete_auto_recharge(self, conn, transaction_id: str, user_id: str, credit_amount: int):
        """
        Complete the auto-recharge by adding credits and updating transaction status
        """
        try:
            # Add credits to user account
            await conn.execute(
                """
                UPDATE user_credits 
                SET current_balance = current_balance + $1,
                    lifetime_consumed = lifetime_consumed,
                    last_updated = $2
                WHERE user_id = $3
                """,
                credit_amount, datetime.now(), user_id
            )
            
            # Update transaction status
            await conn.execute(
                "UPDATE auto_recharge_transactions SET status = $1, completed_at = $2 WHERE transaction_id = $3",
                PaymentStatus.COMPLETED.value, datetime.now(), transaction_id
            )
            
            # Log the credit transaction
            await conn.execute(
                """
                INSERT INTO credit_transactions 
                (user_id, transaction_type, amount, description, created_at)
                VALUES ($1, $2, $3, $4, $5)
                """,
                user_id, 'purchase', credit_amount, 
                f"Auto-recharge: {credit_amount} credits", datetime.now()
            )
            
        except Exception as e:
            print(f"Error completing auto-recharge: {e}")
            raise
    
    async def _pause_auto_recharge(self, conn, user_id: str, reason: str):
        """
        Pause auto-recharge for a user
        """
        await conn.execute(
            "UPDATE auto_recharge_config SET status = $1, pause_reason = $2, updated_at = $3 WHERE user_id = $4",
            AutoRechargeStatus.PAUSED.value, reason, datetime.now(), user_id
        )
    
    async def handle_stripe_webhook(self, event_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Handle Stripe webhook events for auto-recharge payments
        """
        event_type = event_data.get('type')
        
        if event_type == 'payment_intent.succeeded':
            return await self._handle_payment_success(event_data)
        elif event_type == 'payment_intent.payment_failed':
            return await self._handle_payment_failure(event_data)
        else:
            return {"status": "ignored", "message": f"Event type {event_type} not handled"}
    
    async def _handle_payment_success(self, event_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Handle successful payment webhook
        """
        payment_intent = event_data['data']['object']
        metadata = payment_intent.get('metadata', {})
        
        if metadata.get('auto_recharge') != 'true':
            return {"status": "ignored", "message": "Not an auto-recharge payment"}
        
        user_id = metadata.get('user_id')
        transaction_id = metadata.get('transaction_id')
        credit_amount = int(metadata.get('credit_amount', 0))
        
        if not all([user_id, transaction_id, credit_amount]):
            return {"status": "error", "message": "Missing required metadata"}
        
        conn = await self.get_db_connection()
        try:
            await self._complete_auto_recharge(conn, transaction_id, user_id, credit_amount)
            return {
                "status": "success",
                "message": "Auto-recharge completed",
                "user_id": user_id,
                "credits_added": credit_amount
            }
        finally:
            await conn.close()
    
    async def _handle_payment_failure(self, event_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Handle failed payment webhook
        """
        payment_intent = event_data['data']['object']
        metadata = payment_intent.get('metadata', {})
        
        if metadata.get('auto_recharge') != 'true':
            return {"status": "ignored", "message": "Not an auto-recharge payment"}
        
        user_id = metadata.get('user_id')
        transaction_id = metadata.get('transaction_id')
        
        if not all([user_id, transaction_id]):
            return {"status": "error", "message": "Missing required metadata"}
        
        conn = await self.get_db_connection()
        try:
            # Mark transaction as failed
            await conn.execute(
                "UPDATE auto_recharge_transactions SET status = $1, failure_reason = $2 WHERE transaction_id = $3",
                PaymentStatus.FAILED.value, payment_intent.get('last_payment_error', {}).get('message', 'Payment failed'), transaction_id
            )
            
            # Pause auto-recharge
            await self._pause_auto_recharge(conn, user_id, "Payment failed")
            
            return {
                "status": "handled",
                "message": "Auto-recharge payment failure handled",
                "user_id": user_id
            }
        finally:
            await conn.close()
    
    async def get_auto_recharge_config(self, user_id: str) -> Optional[Dict[str, Any]]:
        """
        Get user's auto-recharge configuration
        """
        conn = await self.get_db_connection()
        try:
            config = await conn.fetchrow(
                "SELECT * FROM auto_recharge_config WHERE user_id = $1",
                user_id
            )
            
            if config:
                return dict(config)
            return None
        finally:
            await conn.close()
    
    async def get_auto_recharge_history(self, user_id: str, limit: int = 50) -> list:
        """
        Get user's auto-recharge transaction history
        """
        conn = await self.get_db_connection()
        try:
            transactions = await conn.fetch(
                """
                SELECT * FROM auto_recharge_transactions 
                WHERE user_id = $1 
                ORDER BY created_at DESC 
                LIMIT $2
                """,
                user_id, limit
            )
            
            return [dict(transaction) for transaction in transactions]
        finally:
            await conn.close()
