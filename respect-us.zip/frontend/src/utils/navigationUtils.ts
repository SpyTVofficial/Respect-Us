
import { 
  NavigationModule, 
  BreadcrumbItem, 
  NavigationSession, 
  SearchResult, 
  QuickAccessShortcut,
  CrossModuleReference 
} from './navigationTypes';
import { 
  BookOpen, 
  Package, 
  Shield, 
  Users, 
  Target, 
  AlertTriangle, 
  FileText,
  Settings,
  BarChart3,
  Search,
  Globe,
  CheckCircle,
  MessageSquare
} from 'lucide-react';

// Core module definitions
export const NAVIGATION_MODULES: NavigationModule[] = [
  {
    id: 'knowledge_base',
    name: 'knowledge_base',
    title: 'Knowledge Base',
    description: 'Access regulatory documentation and compliance resources from 50+ jurisdictions',
    icon: BookOpen,
    path: '/knowledge-base',
    status: 'free',
    color: 'text-blue-400',
    category: 'core',
    crossReferences: ['product_classification', 'sanctions_embargoes', 'license_determination'],
    features: ['Document Search', 'Regulatory Updates', 'Country Profiles']
  },
  {
    id: 'collaboration',
    name: 'collaboration',
    title: 'Collaboration',
    description: 'Annotate documents, collaborate with team members, and track compliance activities',
    icon: MessageSquare,
    path: '/collaboration-demo',
    status: 'available',
    color: 'text-cyan-400',
    category: 'core',
    crossReferences: ['knowledge_base', 'product_classification', 'risk_assessment'],
    features: ['Document Annotations', 'Team Collaboration', 'Activity Tracking', 'Bookmarks']
  },
  {
    id: 'product_classification',
    name: 'product_classification',
    title: 'Product Classification',
    description: 'Classify products and technologies for export control purposes',
    icon: Package,
    path: '/product-classification',
    status: 'available',
    color: 'text-green-400',
    category: 'core',
    dependencies: ['knowledge_base'],
    crossReferences: ['risk_assessment', 'license_determination'],
    features: ['Decision Trees', 'Classification Codes', 'Regulatory Notes']
  },
  {
    id: 'sanctions_embargoes',
    name: 'sanctions_embargoes',
    title: 'Sanctions & Embargoes',
    description: 'Monitor and manage sanctions compliance across jurisdictions',
    icon: Shield,
    path: '/sanctions-embargoes',
    status: 'available',
    color: 'text-red-400',
    category: 'screening',
    dependencies: ['knowledge_base'],
    crossReferences: ['customer_screening', 'risk_assessment'],
    features: ['Sanctions Lists', 'Country Restrictions', 'Entity Screening']
  },
  {
    id: 'customer_screening',
    name: 'customer_screening',
    title: 'Customer Screening',
    description: 'Screen customers and parties against global watchlists',
    icon: Users,
    path: '/customer-screening',
    status: 'available',
    color: 'text-purple-400',
    category: 'screening',
    dependencies: ['sanctions_embargoes'],
    crossReferences: ['end_use_check', 'risk_assessment'],
    features: ['Watchlist Screening', 'Risk Scoring', 'Due Diligence']
  },
  {
    id: 'end_use_check',
    name: 'end_use_check',
    title: 'End-Use Checks',
    description: 'Verify end-use and end-user compliance requirements',
    icon: Target,
    path: '/end-use-checks',
    status: 'available',
    color: 'text-orange-400',
    category: 'assessment',
    dependencies: ['customer_screening'],
    crossReferences: ['risk_assessment', 'license_determination'],
    features: ['End-User Verification', 'Use Case Analysis', 'Compliance Checks']
  },
  {
    id: 'risk_assessment',
    name: 'risk_assessment',
    title: 'Risk Assessment',
    description: 'Assess and manage comprehensive compliance risks',
    icon: AlertTriangle,
    path: '/risk-assessment',
    status: 'premium',
    color: 'text-yellow-400',
    category: 'assessment',
    dependencies: ['product_classification', 'customer_screening'],
    crossReferences: ['license_determination'],
    pricing: 99,
    features: ['Risk Scoring', 'Compliance Matrix', 'Mitigation Strategies']
  },
  {
    id: 'license_determination',
    name: 'license_determination',
    title: 'License Determination',
    description: 'Determine licensing requirements and obligations',
    icon: FileText,
    path: '/license-determination',
    status: 'coming_soon',
    color: 'text-indigo-400',
    category: 'core',
    dependencies: ['product_classification', 'risk_assessment'],
    features: ['License Requirements', 'Application Guidance', 'Tracking']
  }
];

// Navigation session management
export class NavigationSessionManager {
  private static SESSION_KEY = 'respectus_navigation_session';
  
  static getSession(): NavigationSession {
    const stored = localStorage.getItem(this.SESSION_KEY);
    if (stored) {
      try {
        const session = JSON.parse(stored);
        session.lastActivity = new Date(session.lastActivity);
        return session;
      } catch (e) {
        console.warn('Failed to parse navigation session:', e);
      }
    }
    
    return {
      currentModule: '',
      breadcrumb: [],
      recentModules: [],
      favorites: [],
      lastActivity: new Date()
    };
  }
  
  static updateSession(updates: Partial<NavigationSession>): void {
    const current = this.getSession();
    const updated = {
      ...current,
      ...updates,
      lastActivity: new Date()
    };
    
    localStorage.setItem(this.SESSION_KEY, JSON.stringify(updated));
  }
  
  static addToRecent(moduleId: string): void {
    const session = this.getSession();
    const recent = session.recentModules.filter(id => id !== moduleId);
    recent.unshift(moduleId);
    
    this.updateSession({
      recentModules: recent.slice(0, 10) // Keep last 10
    });
  }
  
  static toggleFavorite(moduleId: string): void {
    const session = this.getSession();
    const favorites = session.favorites.includes(moduleId)
      ? session.favorites.filter(id => id !== moduleId)
      : [...session.favorites, moduleId];
    
    this.updateSession({ favorites });
  }
  
  static setBreadcrumb(breadcrumb: BreadcrumbItem[]): void {
    this.updateSession({ breadcrumb });
  }
  
  static addBreadcrumbItem(item: BreadcrumbItem): void {
    const session = this.getSession();
    const breadcrumb = [...session.breadcrumb, item];
    this.updateSession({ breadcrumb });
  }
  
  static removeBreadcrumbAfter(index: number): void {
    const session = this.getSession();
    const breadcrumb = session.breadcrumb.slice(0, index + 1);
    this.updateSession({ breadcrumb });
  }
  
  static clearBreadcrumb(): void {
    this.updateSession({ breadcrumb: [] });
  }
}

// Module utilities
export function getModuleById(id: string): NavigationModule | undefined {
  return NAVIGATION_MODULES.find(module => module.id === id);
}

export function getModulesByCategory(category: NavigationModule['category']): NavigationModule[] {
  return NAVIGATION_MODULES.filter(module => module.category === category);
}

export function getAvailableModules(): NavigationModule[] {
  return NAVIGATION_MODULES.filter(module => module.status !== 'coming_soon');
}

export function getFreeModules(): NavigationModule[] {
  return NAVIGATION_MODULES.filter(module => module.status === 'free');
}

export function getPremiumModules(): NavigationModule[] {
  return NAVIGATION_MODULES.filter(module => module.status === 'premium');
}

// Cross-module reference utilities
export function getCrossReferences(moduleId: string): CrossModuleReference[] {
  const module = getModuleById(moduleId);
  if (!module?.crossReferences) return [];
  
  return module.crossReferences.map(targetId => {
    const target = getModuleById(targetId);
    return {
      sourceModule: moduleId,
      targetModule: targetId,
      referenceType: 'workflow',
      description: `Access ${target?.title} for related compliance tasks`,
      path: target?.path || '#'
    };
  });
}

// Search functionality
export function searchModules(query: string): SearchResult[] {
  if (!query.trim()) return [];
  
  const normalizedQuery = query.toLowerCase();
  const results: SearchResult[] = [];
  
  NAVIGATION_MODULES.forEach(module => {
    let relevanceScore = 0;
    
    // Title match (highest priority)
    if (module.title.toLowerCase().includes(normalizedQuery)) {
      relevanceScore += 10;
    }
    
    // Description match
    if (module.description.toLowerCase().includes(normalizedQuery)) {
      relevanceScore += 5;
    }
    
    // Features match
    if (module.features?.some(feature => 
      feature.toLowerCase().includes(normalizedQuery)
    )) {
      relevanceScore += 3;
    }
    
    // Name/ID match
    if (module.name.toLowerCase().includes(normalizedQuery)) {
      relevanceScore += 2;
    }
    
    if (relevanceScore > 0) {
      results.push({
        id: module.id,
        title: module.title,
        description: module.description,
        type: 'module',
        module: module.id,
        path: module.path,
        relevanceScore
      });
    }
  });
  
  return results.sort((a, b) => b.relevanceScore - a.relevanceScore);
}

// Quick access shortcuts
export function getQuickAccessShortcuts(): QuickAccessShortcut[] {
  const session = NavigationSessionManager.getSession();
  const shortcuts: QuickAccessShortcut[] = [];
  
  // Recent modules
  session.recentModules.slice(0, 5).forEach(moduleId => {
    const module = getModuleById(moduleId);
    if (module) {
      shortcuts.push({
        id: `recent_${moduleId}`,
        name: module.title,
        description: `Recently used: ${module.title}`,
        path: module.path,
        icon: module.icon,
        module: moduleId,
        category: 'recent'
      });
    }
  });
  
  // Favorite modules
  session.favorites.forEach(moduleId => {
    const module = getModuleById(moduleId);
    if (module) {
      shortcuts.push({
        id: `favorite_${moduleId}`,
        name: module.title,
        description: `Favorite: ${module.title}`,
        path: module.path,
        icon: module.icon,
        module: moduleId,
        category: 'favorite'
      });
    }
  });
  
  return shortcuts;
}

// Navigation analytics utilities
export function trackModuleAccess(moduleId: string): void {
  NavigationSessionManager.addToRecent(moduleId);
  
  // Track in analytics (could be extended to send to analytics service)
  const analytics = getNavigationAnalytics();
  analytics.moduleUsage[moduleId] = (analytics.moduleUsage[moduleId] || 0) + 1;
  localStorage.setItem('respectus_navigation_analytics', JSON.stringify(analytics));
}

export function getNavigationAnalytics() {
  const stored = localStorage.getItem('respectus_navigation_analytics');
  if (stored) {
    try {
      return JSON.parse(stored);
    } catch (e) {
      console.warn('Failed to parse navigation analytics:', e);
    }
  }
  
  return {
    moduleUsage: {},
    pathFrequency: {},
    searchQueries: [],
    workflowPatterns: [],
    avgTimePerModule: {}
  };
}

// Utility to get status badge configuration
export function getStatusBadgeConfig(status: NavigationModule['status']) {
  switch (status) {
    case 'free':
      return {
        text: 'FREE',
        className: 'bg-green-500/20 text-green-400 border-green-500/30'
      };
    case 'premium':
      return {
        text: 'PREMIUM',
        className: 'bg-purple-500/20 text-purple-400 border-purple-500/30'
      };
    case 'available':
      return {
        text: 'AVAILABLE',
        className: 'bg-blue-500/20 text-blue-400 border-blue-500/30'
      };
    case 'coming_soon':
    default:
      return {
        text: 'COMING SOON',
        className: 'bg-gray-500/20 text-gray-400 border-gray-500/30'
      };
  }
}
