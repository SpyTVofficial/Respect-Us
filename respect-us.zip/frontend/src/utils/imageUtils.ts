import { API_URL } from "app";

/**
 * Converts a Databutton external static URL to the app's internal static serving URL
 * Example: https://static.databutton.com/public/project-id/filename -> API_URL/static/filename
 */
export function convertToAppStaticUrl(externalUrl: string): string {
  console.log('🔗 Converting external URL:', externalUrl);
  console.log('🗺️ Current API_URL value:', API_URL);
  
  // Extract filename from external URL
  const filename = externalUrl.split('/').pop();
  if (!filename) {
    console.warn('❌ Could not extract filename from URL:', externalUrl);
    return externalUrl;
  }
  
  // Build internal static serve URL
  // API_URL is: https://api.databutton.com/app/routes  
  // Brain client endpoint is: /routes/static/{image_filename}
  // So the correct URL is: API_URL + /static/ (since API_URL already ends with /routes)
  const internalUrl = `${API_URL}/static/${filename}`;
  
  console.log('✅ Converted to internal URL:', internalUrl);
  return internalUrl;
}

/**
 * Constructs a static image URL for newly uploaded images
 * This should match the format returned by the upload API
 */
export function constructStaticImageUrl(filename: string): string {
  // For new uploads, construct the URL that the upload API returns
  // The upload API returns: `static/${full_filename}`
  // The brain client would then resolve this relative to the API base
  
  // Since we're manually constructing, we need the full URL
  // API_URL is https://api.databutton.com/app/routes
  // Static endpoint is at /routes/static/{filename}
  const staticUrl = `${API_URL}/static/${filename}`;
  
  console.log('🎆 Constructed static URL for new upload:', staticUrl);
  return staticUrl;
}
