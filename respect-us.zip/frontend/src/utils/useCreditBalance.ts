

import { useState, useEffect } from 'react';
import brain from 'brain';
import { useUser } from '@stackframe/react';

export interface CreditBalance {
  user_id: string;
  current_balance: number;
  lifetime_purchased: number;
  lifetime_consumed: number;
}

export interface CreditTransaction {
  id: number;
  transaction_type: 'consumption' | 'purchase' | 'refund' | 'bonus';
  amount: number;
  balance_after: number;
  component_name?: string;
  action_name?: string;
  description?: string;
  resource_id?: string;
  created_at: string;
}

export function useCreditBalance() {
  const [balance, setBalance] = useState<CreditBalance | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isFetching, setIsFetching] = useState(false);
  const user = useUser();

  const fetchBalance = async () => {
    if (!user || isFetching) {
      if (!user) {
        setBalance(null);
        setIsLoading(false);
      }
      return;
    }

    setIsFetching(true);
    try {
      setIsLoading(true);
      const response = await brain.get_credit_balance();
      const data = await response.json();
      setBalance(data);
      setError(null);
    } catch (err) {
      console.error('Failed to fetch credit balance:', err);
      setError('Failed to load credit balance');
    } finally {
      setIsLoading(false);
      setIsFetching(false);
    }
  };

  const refreshBalance = () => {
    fetchBalance();
  };

  useEffect(() => {
    if (user && !isFetching) {
      fetchBalance();
    }
  }, [user?.id]);

  return {
    balance,
    isLoading,
    error,
    refreshBalance
  };
}

export function useCreditTransactionHistory() {
  const [transactions, setTransactions] = useState<CreditTransaction[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const user = useUser();
  const [hasInitialized, setHasInitialized] = useState(false);
  const [isFetching, setIsFetching] = useState(false);

  const fetchTransactions = async (limit: number = 50, offset: number = 0) => {
    if (!user || isFetching) {
      if (!user) {
        setTransactions([]);
      }
      return;
    }

    setIsFetching(true);
    try {
      setIsLoading(true);
      const response = await brain.get_credit_transactions({ limit, offset });
      const data = await response.json();
      setTransactions(data || []);
      setError(null);
    } catch (err) {
      console.error('Failed to fetch credit transactions:', err);
      setError('Failed to load transaction history');
    } finally {
      setIsLoading(false);
      setIsFetching(false);
    }
  };

  useEffect(() => {
    if (user && !hasInitialized && !isFetching) {
      fetchTransactions();
      setHasInitialized(true);
    }
  }, [user?.id, hasInitialized, isFetching]);

  return {
    transactions,
    isLoading,
    error,
    refreshTransactions: fetchTransactions
  };
}
