
import { LucideIcon } from 'lucide-react';

// Core navigation types
export interface NavigationModule {
  id: string;
  name: string;
  title: string;
  description: string;
  icon: LucideIcon;
  path: string;
  status: 'free' | 'available' | 'premium' | 'coming_soon';
  color: string;
  category: 'core' | 'assessment' | 'screening' | 'admin';
  dependencies?: string[]; // Other modules this depends on
  crossReferences?: string[]; // Modules this can reference
  pricing?: number;
  features?: string[];
}

// Breadcrumb navigation
export interface BreadcrumbItem {
  id: string;
  name: string;
  path?: string;
  type: 'module' | 'category' | 'document' | 'section' | 'custom';
  metadata?: Record<string, any>;
}

// Session context for maintaining workflow state
export interface NavigationSession {
  currentModule: string;
  breadcrumb: BreadcrumbItem[];
  workflowContext?: Record<string, any>;
  recentModules: string[];
  favorites: string[];
  lastActivity: Date;
}

// Search result types
export interface SearchResult {
  id: string;
  title: string;
  description: string;
  type: 'module' | 'document' | 'feature' | 'content';
  module: string;
  path: string;
  relevanceScore: number;
  metadata?: Record<string, any>;
}

// Quick access shortcuts
export interface QuickAccessShortcut {
  id: string;
  name: string;
  description: string;
  path: string;
  icon: LucideIcon;
  hotkey?: string;
  category: 'recent' | 'favorite' | 'suggested' | 'custom';
}

// Cross-module reference
export interface CrossModuleReference {
  sourceModule: string;
  targetModule: string;
  referenceType: 'workflow' | 'data' | 'validation' | 'report';
  description: string;
  path: string;
  context?: Record<string, any>;
}

// Navigation analytics
export interface NavigationAnalytics {
  moduleUsage: Record<string, number>;
  pathFrequency: Record<string, number>;
  searchQueries: string[];
  workflowPatterns: string[];
  avgTimePerModule: Record<string, number>;
}

// Navigation preferences
export interface NavigationPreferences {
  defaultView: 'grid' | 'list' | 'compact';
  showDescriptions: boolean;
  enableAnimations: boolean;
  favoriteModules: string[];
  customShortcuts: QuickAccessShortcut[];
  searchFilters: string[];
}
