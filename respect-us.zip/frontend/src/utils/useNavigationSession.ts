
import { useState, useEffect, useCallback, startTransition } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { 
  NavigationSession, 
  BreadcrumbItem as NavBreadcrumbItem,
  NavigationModule 
} from 'utils/navigationTypes';
import { 
  NavigationSessionManager, 
  getModuleById, 
  NAVIGATION_MODULES 
} from 'utils/navigationUtils';

export function useNavigationSession() {
  const [session, setSession] = useState<NavigationSession>(NavigationSessionManager.getSession());
  const location = useLocation();
  const navigate = useNavigate();
  
  // Update session when location changes
  useEffect(() => {
    const currentModule = getCurrentModuleFromPath(location.pathname);
    if (currentModule) {
      // Wrap session updates in startTransition to prevent suspense errors
      startTransition(() => {
        NavigationSessionManager.addToRecent(currentModule.id);
        NavigationSessionManager.updateSession({ currentModule: currentModule.id });
        
        // Auto-build breadcrumb for module navigation
        const breadcrumb = buildAutoBreadcrumb(location.pathname, currentModule);
        if (breadcrumb.length > 0) {
          NavigationSessionManager.setBreadcrumb(breadcrumb);
        }
        
        setSession(NavigationSessionManager.getSession());
      });
    }
  }, [location.pathname]);
  
  const getCurrentModuleFromPath = (pathname: string): NavigationModule | null => {
    return NAVIGATION_MODULES.find(module => 
      pathname.startsWith(module.path) && module.path !== '/'
    ) || null;
  };
  
  const buildAutoBreadcrumb = (pathname: string, module: NavigationModule): NavBreadcrumbItem[] => {
    const breadcrumb: NavBreadcrumbItem[] = [];
    
    // Add module as base
    breadcrumb.push({
      id: module.id,
      name: module.title,
      path: module.path,
      type: 'module'
    });
    
    // Parse path segments for sub-navigation
    const segments = pathname.replace(module.path, '').split('/').filter(Boolean);
    let currentPath = module.path;
    
    segments.forEach((segment, index) => {
      currentPath += `/${segment}`;
      
      // Convert segment to readable name
      const name = segment
        .split('-')
        .map(word => word.charAt(0).toUpperCase() + word.slice(1))
        .join(' ');
      
      breadcrumb.push({
        id: `${module.id}_${segment}`,
        name,
        path: currentPath,
        type: index === segments.length - 1 ? 'section' : 'category'
      });
    });
    
    return breadcrumb;
  };
  
  const addBreadcrumbItem = useCallback((item: NavBreadcrumbItem) => {
    NavigationSessionManager.addBreadcrumbItem(item);
    setSession(NavigationSessionManager.getSession());
  }, []);
  
  const removeBreadcrumbAfter = useCallback((index: number) => {
    NavigationSessionManager.removeBreadcrumbAfter(index);
    setSession(NavigationSessionManager.getSession());
  }, []);
  
  const clearBreadcrumb = useCallback(() => {
    NavigationSessionManager.clearBreadcrumb();
    setSession(NavigationSessionManager.getSession());
  }, []);
  
  const setBreadcrumb = useCallback((breadcrumb: NavBreadcrumbItem[]) => {
    NavigationSessionManager.setBreadcrumb(breadcrumb);
    setSession(NavigationSessionManager.getSession());
  }, []);
  
  const toggleFavorite = useCallback((moduleId: string) => {
    NavigationSessionManager.toggleFavorite(moduleId);
    setSession(NavigationSessionManager.getSession());
  }, []);
  
  const isFavorite = useCallback((moduleId: string): boolean => {
    return session.favorites.includes(moduleId);
  }, [session.favorites]);
  
  const getRecentModules = useCallback((): NavigationModule[] => {
    return session.recentModules
      .map(id => getModuleById(id))
      .filter(Boolean) as NavigationModule[];
  }, [session.recentModules]);
  
  const getFavoriteModules = useCallback((): NavigationModule[] => {
    return session.favorites
      .map(id => getModuleById(id))
      .filter(Boolean) as NavigationModule[];
  }, [session.favorites]);
  
  const navigateToModule = useCallback((moduleId: string, subPath?: string) => {
    const module = getModuleById(moduleId);
    if (module) {
      const path = subPath ? `${module.path}${subPath}` : module.path;
      navigate(path);
    }
  }, [navigate]);
  
  const setWorkflowContext = useCallback((context: Record<string, any>) => {
    NavigationSessionManager.updateSession({ workflowContext: context });
    setSession(NavigationSessionManager.getSession());
  }, []);
  
  return {
    session,
    currentModule: session.currentModule ? getModuleById(session.currentModule) : null,
    breadcrumb: session.breadcrumb,
    recentModules: getRecentModules(),
    favoriteModules: getFavoriteModules(),
    addBreadcrumbItem,
    removeBreadcrumbAfter,
    clearBreadcrumb,
    setBreadcrumb,
    toggleFavorite,
    isFavorite,
    navigateToModule,
    setWorkflowContext,
    workflowContext: session.workflowContext
  };
}
