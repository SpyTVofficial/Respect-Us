import {
  Folder,
  Tag,
  Archive,
  BookOpen,
  Briefcase,
  Star,
  Heart,
  Target,
  Lightbulb,
  FileText,
  Shield,
  Globe,
  TrendingUp,
} from 'lucide-react';

const ICON_MAP: Record<string, React.ComponentType<any>> = {
  'folder': Folder,
  'tag': Tag,
  'archive': Archive,
  'book-open': BookOpen,
  'briefcase': Briefcase,
  'star': Star,
  'heart': Heart,
  'target': Target,
  'lightbulb': Lightbulb,
  'file-text': FileText,
  'shield': Shield,
  'globe': Globe,
  'trending-up': TrendingUp,
};

export const getCategoryIcon = (iconName: string) => {
  return ICON_MAP[iconName] || Folder;
};

export const formatCategoryColor = (color: string, opacity: number = 1) => {
  if (opacity === 1) return color;
  
  // Convert hex to rgba
  const hex = color.replace('#', '');
  const r = parseInt(hex.substr(0, 2), 16);
  const g = parseInt(hex.substr(2, 2), 16);
  const b = parseInt(hex.substr(4, 2), 16);
  
  return `rgba(${r}, ${g}, ${b}, ${opacity})`;
};

export const sortCategoriesByDisplayOrder = <T extends { display_order: number; name: string }>(categories: T[]): T[] => {
  return [...categories].sort((a, b) => {
    if (a.display_order !== b.display_order) {
      return a.display_order - b.display_order;
    }
    return a.name.localeCompare(b.name);
  });
};

export const groupArticlesByCategory = <T extends { categories: Array<{ id: number; name: string }> }>(articles: T[]) => {
  const grouped: Record<string, T[]> = {
    'Uncategorized': []
  };
  
  articles.forEach(article => {
    if (article.categories.length === 0) {
      grouped['Uncategorized'].push(article);
    } else {
      article.categories.forEach(category => {
        if (!grouped[category.name]) {
          grouped[category.name] = [];
        }
        grouped[category.name].push(article);
      });
    }
  });
  
  return grouped;
};
