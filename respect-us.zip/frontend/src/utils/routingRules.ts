/**
 * Utility functions for validating and working with enhanced routing rules
 */

export interface RoutingRuleValidation {
  isValid: boolean;
  type: 'simple_navigation' | 'final_outcome' | 'enhanced_outcome_continue' | 'invalid';
  errors: string[];
}

/**
 * Validates a routing rule according to the enhanced syntax
 * 
 * Supported formats:
 * 1. Simple navigation: "-> node_key"
 * 2. Final outcome: "-> "outcome_code""
 * 3. Enhanced (outcome + continue): "outcome: "code"; continue: target"
 */
export function validateRoutingRule(rule: string): RoutingRuleValidation {
  if (!rule || !rule.trim()) {
    return {
      isValid: true, // Empty rules are valid (optional)
      type: 'invalid',
      errors: []
    };
  }

  const trimmedRule = rule.trim();
  const errors: string[] = [];

  // Check for simple navigation: "-> node_key"
  if (trimmedRule.startsWith('->')) {
    const target = trimmedRule.substring(2).trim();
    
    if (!target) {
      errors.push('Navigation target cannot be empty');
      return { isValid: false, type: 'invalid', errors };
    }

    // Check if it's a quoted outcome (final outcome)
    if (target.startsWith('"') && target.endsWith('"')) {
      const outcomeCode = target.slice(1, -1);
      if (!outcomeCode) {
        errors.push('Outcome code cannot be empty');
        return { isValid: false, type: 'invalid', errors };
      }
      return { isValid: true, type: 'final_outcome', errors: [] };
    }

    // Simple navigation to node
    if (!/^[a-zA-Z0-9_-]+$/.test(target)) {
      errors.push('Node key can only contain letters, numbers, underscores, and hyphens');
      return { isValid: false, type: 'invalid', errors };
    }

    return { isValid: true, type: 'simple_navigation', errors: [] };
  }

  // Check for enhanced syntax: "outcome: "code"; continue: target"
  if (trimmedRule.includes('outcome:') && trimmedRule.includes('continue:')) {
    const parts = trimmedRule.split(';');
    
    if (parts.length !== 2) {
      errors.push('Enhanced syntax must have exactly one semicolon separating outcome and continue parts');
      return { isValid: false, type: 'invalid', errors };
    }

    const outcomePart = parts[0].trim();
    const continuePart = parts[1].trim();

    // Validate outcome part
    if (!outcomePart.startsWith('outcome:')) {
      errors.push('First part must start with "outcome:"');
    } else {
      const outcomeValue = outcomePart.substring(8).trim(); // Remove 'outcome:'
      if (!outcomeValue.startsWith('"') || !outcomeValue.endsWith('"')) {
        errors.push('Outcome code must be quoted');
      } else {
        const outcomeCode = outcomeValue.slice(1, -1);
        if (!outcomeCode) {
          errors.push('Outcome code cannot be empty');
        }
      }
    }

    // Validate continue part
    if (!continuePart.startsWith('continue:')) {
      errors.push('Second part must start with "continue:"');
    } else {
      const continueTarget = continuePart.substring(9).trim(); // Remove 'continue:'
      if (!continueTarget) {
        errors.push('Continue target cannot be empty');
      } else if (continueTarget.startsWith('->')) {
        errors.push('Continue target should not include "->". Use format: "continue: target" not "continue: -> target"');
      } else if (!/^[a-zA-Z0-9_./-]+$/.test(continueTarget)) {
        errors.push('Continue target can only contain letters, numbers, underscores, hyphens, dots, and slashes');
      }
    }

    return {
      isValid: errors.length === 0,
      type: errors.length === 0 ? 'enhanced_outcome_continue' : 'invalid',
      errors
    };
  }

  // If we get here, the rule doesn't match any known format
  errors.push('Invalid routing rule format. Use "-> target", "-> "outcome"" or "outcome: "code"; continue: target"');
  return { isValid: false, type: 'invalid', errors };
}

/**
 * Gets a human-readable description of the routing rule type
 */
export function getRoutingRuleDescription(type: RoutingRuleValidation['type']): string {
  switch (type) {
    case 'simple_navigation':
      return 'Navigate to another decision node';
    case 'final_outcome':
      return 'Show final classification outcome';
    case 'enhanced_outcome_continue':
      return 'Show intermediate outcome and continue to another classification';
    case 'invalid':
    default:
      return 'Invalid routing rule';
  }
}

/**
 * Example routing rules for demonstration
 */
export const EXAMPLE_ROUTING_RULES = {
  simple_navigation: '-> dual_use_check',
  final_outcome: '-> "EU-ML-22a"',
  enhanced_outcome_continue: 'outcome: "not_military_controlled"; continue: dual_use_tree'
};
