import { toast } from 'sonner';

export interface CreditError {
  message: string;
  required_credits: number;
  current_balance: number;
  document_title: string;
}

export interface CreditConfirmationData {
  documentTitle: string;
  requiredCredits: number;
  currentBalance: number;
}

/**
 * Checks if a response is a credit-related error (402 status)
 */
export const isCreditError = (response: Response): boolean => {
  return response.status === 402;
};

/**
 * Extracts credit error information from a 402 response
 */
export const extractCreditError = async (response: Response): Promise<CreditError | null> => {
  if (!isCreditError(response)) return null;
  
  try {
    const errorData = await response.json();
    if (errorData.detail && typeof errorData.detail === 'object') {
      return errorData.detail as CreditError;
    }
  } catch (error) {
    console.error('Failed to parse credit error:', error);
  }
  
  return null;
};

/**
 * Handles credit errors by showing appropriate toasts
 */
export const handleCreditError = (creditError: CreditError): void => {
  const deficit = creditError.required_credits - creditError.current_balance;
  
  if (deficit > 0) {
    toast.error(
      `Insufficient credits. You need ${deficit} more credits to access "${creditError.document_title}".`,
      {
        duration: 5000,
        action: {
          label: 'Buy Credits',
          onClick: () => {
            // TODO: Navigate to credit purchase page
            console.log('Navigate to credit purchase');
          },
        },
      }
    );
  } else {
    toast.error(creditError.message);
  }
};

/**
 * Creates a standardized credit confirmation flow for document access
 */
export const createCreditConfirmation = (creditError: CreditError): CreditConfirmationData => {
  return {
    documentTitle: creditError.document_title,
    requiredCredits: creditError.required_credits,
    currentBalance: creditError.current_balance,
  };
};

/**
 * Wrapper for API calls that handles credit errors automatically
 */
export const handleApiCallWithCredits = async <T>(
  apiCall: () => Promise<Response>,
  onCreditError?: (creditData: CreditConfirmationData) => void,
  onSuccess?: (data: T) => void
): Promise<T | null> => {
  try {
    const response = await apiCall();
    
    if (isCreditError(response)) {
      const creditError = await extractCreditError(response);
      if (creditError && onCreditError) {
        onCreditError(createCreditConfirmation(creditError));
      } else if (creditError) {
        handleCreditError(creditError);
      }
      return null;
    }
    
    if (response.ok) {
      const data = await response.json();
      if (onSuccess) {
        onSuccess(data);
      }
      return data;
    } else {
      throw new Error(`API call failed with status ${response.status}`);
    }
  } catch (error) {
    console.error('API call failed:', error);
    toast.error('Failed to load content');
    return null;
  }
};

/**
 * Hook for managing credit confirmation state
 */
export const useCreditConfirmation = () => {
  const [isOpen, setIsOpen] = React.useState(false);
  const [creditData, setCreditData] = React.useState<CreditConfirmationData | null>(null);
  const [pendingApiCall, setPendingApiCall] = React.useState<(() => Promise<void>) | null>(null);
  
  const showCreditConfirmation = (
    data: CreditConfirmationData,
    onConfirm: () => Promise<void>
  ) => {
    setCreditData(data);
    setPendingApiCall(() => onConfirm);
    setIsOpen(true);
  };
  
  const handleConfirm = async () => {
    if (pendingApiCall) {
      await pendingApiCall();
    }
    handleCancel();
  };
  
  const handleCancel = () => {
    setIsOpen(false);
    setCreditData(null);
    setPendingApiCall(null);
  };
  
  return {
    isOpen,
    creditData,
    showCreditConfirmation,
    handleConfirm,
    handleCancel,
  };
};

// Note: React import needed for the hook
import React from 'react';
