


import { useState, useCallback } from 'react';
import brain from 'brain';
import { 
  CreditConfirmationData,
  isCreditError,
  extractCreditError,
  createCreditConfirmation
} from './creditHandling';
import { toast } from 'sonner';

export interface UseDocumentAccessOptions {
  onSuccess?: (data: any) => void;
  onError?: (error: Error) => void;
  showSuccessToast?: boolean;
}

export const useDocumentAccess = (options: UseDocumentAccessOptions = {}) => {
  const { onSuccess, onError, showSuccessToast = false } = options;
  const [isLoading, setIsLoading] = useState(false);
  const [creditConfirmation, setCreditConfirmation] = useState<CreditConfirmationData | null>(null);
  const [pendingAction, setPendingAction] = useState<(() => Promise<void>) | null>(null);
  
  const accessDocument = useCallback(async (documentId: number) => {
    setIsLoading(true);
    try {
      const response = await brain.get_document({ documentId });
      
      if (isCreditError(response)) {
        const creditError = await extractCreditError(response);
        if (creditError) {
          setCreditConfirmation(createCreditConfirmation(creditError));
          setPendingAction(() => async () => {
            await accessDocument(documentId);
          });
          setIsLoading(false);
          return null;
        }
      }
      
      if (response.ok) {
        const data = await response.json();
        if (showSuccessToast) {
          toast.success('Document loaded successfully');
        }
        if (onSuccess) {
          onSuccess(data);
        }
        return data;
      } else {
        throw new Error(`Failed to load document: ${response.status}`);
      }
    } catch (error) {
      const err = error instanceof Error ? error : new Error('Unknown error');
      if (onError) {
        onError(err);
      } else {
        toast.error(err.message);
      }
      return null;
    } finally {
      setIsLoading(false);
    }
  }, [onSuccess, onError, showSuccessToast]);
  
  const accessDocumentSections = useCallback(async (documentId: number) => {
    setIsLoading(true);
    try {
      const response = await brain.get_document_sections({ documentId });
      
      if (isCreditError(response)) {
        const creditError = await extractCreditError(response);
        if (creditError) {
          setCreditConfirmation(createCreditConfirmation(creditError));
          setPendingAction(() => async () => {
            await accessDocumentSections(documentId);
          });
          setIsLoading(false);
          return null;
        }
      }
      
      if (response.ok) {
        const data = await response.json();
        if (showSuccessToast) {
          toast.success('Document sections loaded successfully');
        }
        if (onSuccess) {
          onSuccess(data);
        }
        return data;
      } else if (response.status === 404) {
        throw new Error('Document sections not found. The document may not have structured sections or may not be published yet.');
      } else if (response.status === 402) {
        // This should be handled by the credit error check above, but just in case
        throw new Error('Insufficient credits to access document sections');
      } else {
        const errorText = await response.text().catch(() => 'Unknown error');
        throw new Error(`Failed to load document sections: ${response.status} ${response.statusText} - ${errorText}`);
      }
    } catch (error) {
      console.error('Raw error in accessDocumentSections:', error);
      const err = error instanceof Error ? error : new Error(`Unknown error: ${String(error)}`);
      if (onError) {
        onError(err);
      } else {
        toast.error(err.message);
      }
      return null;
    } finally {
      setIsLoading(false);
    }
  }, [onSuccess, onError, showSuccessToast]);
  
  const confirmCreditAccess = useCallback(async () => {
    if (pendingAction) {
      await pendingAction();
    }
    setCreditConfirmation(null);
    setPendingAction(null);
  }, [pendingAction]);
  
  const cancelCreditAccess = useCallback(() => {
    setCreditConfirmation(null);
    setPendingAction(null);
  }, []);
  
  return {
    isLoading,
    creditConfirmation,
    accessDocument,
    accessDocumentSections,
    confirmCreditAccess,
    cancelCreditAccess,
  };
};
