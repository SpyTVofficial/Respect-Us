// React polyfill for React 18 compatibility
// This file was required by main.tsx but was missing, causing app loading failure

// Polyfill for React 18 'use' hook if needed
// Currently empty as most React 18 features work without additional polyfills

console.log('React polyfill loaded successfully');

// Export empty object to make this a valid ES module
export {};
