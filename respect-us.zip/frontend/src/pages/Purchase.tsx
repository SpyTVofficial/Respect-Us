

import React, { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { toast } from 'sonner';
import { 
  CreditCard, 
  Check, 
  Star, 
  Shield, 
  Zap, 
  ArrowLeft, 
  Loader2,
  Crown,
  Award,
  Sparkles,
  Building2,
  Banknote
} from 'lucide-react';
import brain from 'brain';
import { useUserGuardContext } from 'app/auth';

interface CreditPackage {
  id: number;
  name: string;
  credits: number;
  price_cents: number;
  currency: string;
  description?: string;
  is_popular?: boolean;
  features?: string[];
}

interface UserProfile {
  id: string;
  company_name?: string;
  industry?: string;
  company_size?: string;
  primary_use_case?: string;
  contact_email?: string;
  contact_phone?: string;
  billing_address?: any;
}

const Purchase = () => {
  const { user } = useUserGuardContext();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const [packages, setPackages] = useState<CreditPackage[]>([]);
  const [selectedPackage, setSelectedPackage] = useState<CreditPackage | null>(null);
  const [loading, setLoading] = useState(true);
  const [processingPayment, setProcessingPayment] = useState(false);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [paymentMethod, setPaymentMethod] = useState<'stripe' | 'bank_transfer'>('stripe');
  const [customAmount, setCustomAmount] = useState<string>('');
  const [showCustomAmount, setShowCustomAmount] = useState(false);
  const [packageDescriptions, setPackageDescriptions] = useState<Record<number, any>>({});
  
  // Check if this is coming from profile completion
  const fromProfile = searchParams.get('from') === 'profile';
  const selectedPackageId = searchParams.get('package');

  useEffect(() => {
    loadCreditPackages();
    loadPackageDescriptions();
    if (fromProfile) {
      loadUserProfile();
    }
  }, [fromProfile]);

  useEffect(() => {
    if (packages.length > 0 && selectedPackageId) {
      const pkg = packages.find(p => p.id.toString() === selectedPackageId);
      if (pkg) {
        setSelectedPackage(pkg);
      }
    }
  }, [packages, selectedPackageId]);

  const loadCreditPackages = async () => {
    try {
      setLoading(true);
      const response = await brain.get_credit_packages();
      if (response.ok) {
        const data = await response.json();
        
        // Enhanced package data with features
        const enhancedPackages = data.map((pkg: CreditPackage) => {
          let features: string[] = [];
          let isPopular = false;
          
          if (pkg.credits <= 100) {
            features = [
              'Basic module access',
              'Standard support',
              'Email notifications',
              '30-day credit validity'
            ];
          } else if (pkg.credits <= 500) {
            features = [
              'Full module access',
              'Priority support',
              'Advanced analytics',
              'Export capabilities',
              '60-day credit validity'
            ];
            isPopular = true;
          } else {
            features = [
              'Premium module access',
              'Dedicated support',
              'Advanced analytics',
              'Unlimited exports',
              'API access',
              '90-day credit validity',
              'Bulk operations'
            ];
          }
          
          return {
            ...pkg,
            features,
            is_popular: isPopular
          };
        });
        
        setPackages(enhancedPackages);
      }
    } catch (error) {
      console.error('Error loading credit packages:', error);
      toast.error('Failed to load credit packages');
    } finally {
      setLoading(false);
    }
  };

  const loadUserProfile = async () => {
    try {
      const response = await brain.get_user_profile();
      if (response.ok) {
        const profile = await response.json();
        setUserProfile(profile);
      }
    } catch (error) {
      console.error('Error loading user profile:', error);
    }
  };

  const loadPackageDescriptions = async () => {
    try {
      const response = await brain.get_content_by_module({ moduleName: 'credit_packages' });
      if (response.ok) {
        const content = await response.json();
        const descriptions: Record<number, any> = {};
        
        // Ensure content is an array
        const contentArray = Array.isArray(content) ? content : (content.items || []);
        
        contentArray.forEach((item: any) => {
          if (item.metadata?.package_id) {
            descriptions[item.metadata.package_id] = {
              description: item.content,
              features: item.metadata.features || []
            };
          }
        });
        
        setPackageDescriptions(descriptions);
      }
    } catch (error) {
      console.error('Error loading package descriptions:', error);
    }
  };

  const handlePurchase = async (packageItem: CreditPackage) => {
    try {
      setProcessingPayment(true);
      
      if (!userProfile && fromProfile) {
        toast.error('Please complete your profile first');
        navigate('/profile-completion');
        return;
      }

      // Use profile data if available, otherwise require user to fill it
      const customerDetails = userProfile ? {
        company_name: userProfile.company_name || '',
        contact_person: user.displayName || '',
        email: userProfile.contact_email || user.primaryEmail || '',
        phone: userProfile.contact_phone || '',
        billing_address: userProfile.billing_address?.street || '',
        city: userProfile.billing_address?.city || '',
        postal_code: userProfile.billing_address?.postal_code || '',
        country: userProfile.billing_address?.country || 'DE',
        tax_id: userProfile.billing_address?.tax_id || '',
        vat_number: userProfile.billing_address?.vat_number || ''
      } : null;

      if (!customerDetails) {
        toast.error('Customer details required. Please complete your profile first.');
        navigate('/profile-completion');
        return;
      }

      if (paymentMethod === 'bank_transfer') {
        // Handle bank transfer payment
        const invoiceRequest = {
          price_amount: packageItem.price_cents / 100,
          currency: packageItem.currency,
          customer_details: customerDetails,
          module_name: null, // For credit packages
          template_id: null,
          custom_credits: showCustomAmount ? parseInt(customAmount) : null
        };

        const response = await brain.request_invoice(invoiceRequest);
        if (response.ok) {
          const invoiceData = await response.json();
          toast.success('Invoice created! Check your email for payment details.');
          // Redirect to success page with invoice details
          navigate(`/purchase-success?invoice_id=${invoiceData.invoice_id}&payment_method=bank_transfer`);
        } else {
          throw new Error('Failed to create invoice');
        }
      } else {
        // Handle Stripe payment (existing logic)
        const paymentRequest = {
          module_name: 'credit_package',
          template_id: null,
          price_amount: packageItem.price_cents / 100,
          currency: packageItem.currency,
          customer_details: customerDetails
        };

        const response = await brain.create_payment_intent(paymentRequest);
        if (response.ok) {
          const paymentData = await response.json();
          toast.success('Redirecting to payment...');
          // Handle Stripe payment flow
          navigate(`/purchase-success?purchase_id=${paymentData.purchase_id}&payment_method=stripe`);
        } else {
          throw new Error('Failed to create payment intent');
        }
      }
    } catch (error) {
      console.error('Purchase error:', error);
      toast.error('Purchase failed. Please try again.');
    } finally {
      setProcessingPayment(false);
    }
  };

  // Handle custom amount purchase via bank transfer
  const handleCustomPurchase = async () => {
    if (customAmount < 10000) {
      toast.error('Minimum custom amount is 10,000 credits');
      return;
    }

    setProcessingPayment(true);
    try {
      const response = await brain.request_invoice({
        credits: customAmount,
        amount: customAmount * 0.05, // €0.05 per credit
        currency: 'EUR'
      });

      const result = await response.json();
      if (response.ok) {
        toast.success('Invoice request submitted successfully! You will receive payment instructions via email.');
        // Optionally redirect or update UI
      } else {
        toast.error(result.detail || 'Failed to create invoice request');
      }
    } catch (error) {
      console.error('Error creating invoice:', error);
      toast.error('Failed to submit invoice request');
    } finally {
      setProcessingPayment(false);
    }
  };

  const formatPrice = (priceCents: number, currency: string) => {
    const price = priceCents / 100;
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: currency.toUpperCase()
    }).format(price);
  };

  const formatPriceWithVAT = (priceCents: number, currency: string) => {
    const price = priceCents / 100;
    const formattedPrice = new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: currency.toUpperCase()
    }).format(price);
    return `${formattedPrice} + VAT if applicable`;
  };

  const getPackageIcon = (credits: number) => {
    if (credits <= 100) return <Zap className="w-8 h-8 text-blue-500" />;
    if (credits <= 500) return <Star className="w-8 h-8 text-purple-500" />;
    return <Crown className="w-8 h-8 text-yellow-500" />;
  };

  if (loading) {
    return (
      <div className="container mx-auto p-6">
        <div className="flex items-center justify-center min-h-[400px]">
          <div className="text-center">
            <Loader2 className="w-8 h-8 animate-spin text-blue-600 mx-auto mb-4" />
            <p className="text-gray-400">Loading credit packages...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6 max-w-6xl">
      {/* Header */}
      <div className="mb-8">
        <div className="flex items-center gap-4 mb-4">
          <Button
            variant="ghost"
            onClick={() => navigate(fromProfile ? '/profile-completion' : '/settings')}
            className="text-gray-400 hover:text-white"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Button>
        </div>
        
        <div className="text-center">
          <h1 className="text-4xl font-bold text-white mb-4">
            {fromProfile ? 'Complete Your Setup' : 'Choose Your Credit Package'}
          </h1>
          <p className="text-xl text-gray-400 max-w-2xl mx-auto">
            {fromProfile 
              ? 'Select a credit package to unlock full access to Respectus compliance tools'
              : 'Unlock powerful compliance tools with flexible credit packages'
            }
          </p>
        </div>
      </div>

      {/* Profile Summary (if from profile completion) */}
      {fromProfile && userProfile && (
        <Card className="bg-gray-800/50 border-gray-700 mb-8">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Award className="w-5 h-5 text-green-400" />
              Profile Setup Complete
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
              <div>
                <span className="text-gray-400">Company:</span>
                <span className="text-white ml-2">{userProfile.company_name || 'Not specified'}</span>
              </div>
              <div>
                <span className="text-gray-400">Industry:</span>
                <span className="text-white ml-2">{userProfile.industry || 'Not specified'}</span>
              </div>
              <div>
                <span className="text-gray-400">Company Size:</span>
                <span className="text-white ml-2">{userProfile.company_size || 'Not specified'}</span>
              </div>
              <div>
                <span className="text-gray-400">Primary Use Case:</span>
                <span className="text-white ml-2">{userProfile.primary_use_case || 'Not specified'}</span>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Payment Method Selection */}
      <Card className="bg-gray-800/50 border-gray-700 mb-8">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <CreditCard className="w-5 h-5" />
            Choose Payment Method
          </CardTitle>
          <CardDescription className="text-gray-400">
            Select your preferred payment method
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
            {/* Stripe Payment */}
            <Card 
              className={`cursor-pointer transition-all duration-200 border-2 ${
                paymentMethod === 'stripe' 
                  ? 'border-blue-500 bg-blue-500/10' 
                  : 'border-gray-600 hover:border-gray-500'
              }`}
              onClick={() => {
                setPaymentMethod('stripe');
                setShowCustomAmount(false);
              }}
            >
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <CreditCard className="w-6 h-6 text-blue-400" />
                  <div>
                    <h3 className="text-white font-semibold">Credit Card</h3>
                    <p className="text-gray-400 text-sm">Instant activation via Stripe</p>
                  </div>
                </div>
                <div className="mt-3 text-xs text-gray-500">
                  • Immediate access
                  • Secure payment processing
                  • Standard package sizes only
                </div>
              </CardContent>
            </Card>

            {/* Bank Transfer */}
            <Card 
              className={`cursor-pointer transition-all duration-200 border-2 ${
                paymentMethod === 'bank_transfer' 
                  ? 'border-green-500 bg-green-500/10' 
                  : 'border-gray-600 hover:border-gray-500'
              }`}
              onClick={() => {
                setPaymentMethod('bank_transfer');
              }}
            >
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <Building2 className="w-6 h-6 text-green-400" />
                  <div>
                    <h3 className="text-white font-semibold">Bank Transfer</h3>
                    <p className="text-gray-400 text-sm">Invoice & wire transfer</p>
                  </div>
                </div>
                <div className="mt-3 text-xs text-gray-500">
                  • Custom credit amounts
                  • Preferred by enterprises
                  • 1-2 day activation
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Custom Amount Input for Bank Transfer */}
          {paymentMethod === 'bank_transfer' && (
            <div className="bg-gray-800/50 border border-gray-700 rounded-lg p-6">
              <h3 className="text-lg font-semibold text-white mb-2 flex items-center">
                <Building2 className="w-5 h-5 mr-2 text-green-400" />
                Custom Credit Package
              </h3>
              <p className="text-gray-300 text-sm mb-4">
                Request a custom amount of credits via bank transfer. Minimum 10,000 credits required.
                Custom amounts are only available through bank transfer payments.
              </p>
              <div className="space-y-4">
                <div>
                  <label htmlFor="customAmount" className="block text-sm font-medium text-gray-300 mb-2">
                    Number of Credits (minimum 10,000)
                  </label>
                  <input
                    id="customAmount"
                    type="number"
                    min="10000"
                    step="1000"
                    value={customAmount}
                    onChange={(e) => setCustomAmount(Number(e.target.value))}
                    className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-md text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="Enter custom amount (min 10,000)"
                  />
                </div>
                {customAmount >= 10000 && (
                  <div className="bg-blue-900/30 border border-blue-700 rounded-lg p-4">
                    <div className="flex justify-between items-center text-white">
                      <span>Total Price:</span>
                      <span className="text-xl font-bold">${(customAmount * 0.001).toFixed(2)}</span>
                    </div>
                    <p className="text-blue-300 text-sm mt-1">
                      Price: $0.001 per credit
                    </p>
                  </div>
                )}
                <Button
                  onClick={handleCustomPurchase}
                  disabled={processingPayment || customAmount < 10000}
                  className="w-full bg-green-600 hover:bg-green-700 text-white disabled:opacity-50"
                >
                  {processingPayment ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Creating Invoice...
                    </>
                  ) : (
                    <>
                      <Building2 className="w-4 h-4 mr-2" />
                      Request Custom Invoice
                    </>
                  )}
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Standard Credit Packages */}
      {!showCustomAmount && (
        <>
          <div className="text-center mb-6">
            <h2 className="text-2xl font-bold text-white mb-2">Standard Credit Packages</h2>
            <p className="text-gray-400">Choose from our pre-configured packages</p>
          </div>

      {/* Credit Packages Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        {packages.map((pkg) => (
          <Card 
            key={pkg.id} 
            className={`relative bg-gray-800/50 border-gray-700 hover:border-blue-500/50 transition-all duration-200 ${
              pkg.is_popular ? 'ring-2 ring-purple-500/30 scale-105' : ''
            } ${
              selectedPackage?.id === pkg.id ? 'ring-2 ring-blue-500/50' : ''
            }`}
          >
            {/* Popular Badge */}
            {pkg.is_popular && (
              <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                <Badge className="bg-purple-600 text-white px-3 py-1 text-xs font-semibold">
                  <Sparkles className="w-3 h-3 mr-1" />
                  Most Popular
                </Badge>
              </div>
            )}
            
            <CardHeader className="text-center pb-4">
              <div className="mx-auto mb-4">
                {getPackageIcon(pkg.credits)}
              </div>
              <CardTitle className="text-white text-xl">{pkg.name}</CardTitle>
              <div className="text-3xl font-bold text-white">
                {formatPriceWithVAT(pkg.price_cents, pkg.currency)}
              </div>
              <CardDescription className="text-gray-400">
                {pkg.credits.toLocaleString()} credits
              </CardDescription>
            </CardHeader>
            
            <CardContent className="pt-0">
              {/* Features List */}
              <div className="space-y-3 mb-6">
                {pkg.features?.map((feature, index) => (
                  <div key={index} className="flex items-center gap-2 text-sm">
                    <Check className="w-4 h-4 text-green-400 flex-shrink-0" />
                    <span className="text-gray-300">{feature}</span>
                  </div>
                ))}
              </div>
              
              <Separator className="bg-gray-700 mb-6" />
              
              {/* Purchase Button */}
              <Button
                onClick={() => handlePurchase(pkg)}
                disabled={processingPayment}
                className={`w-full ${
                  pkg.is_popular 
                    ? 'bg-purple-600 hover:bg-purple-700 text-white' 
                    : paymentMethod === 'bank_transfer'
                    ? 'bg-green-600 hover:bg-green-700 text-white'
                    : 'bg-blue-600 hover:bg-blue-700 text-white'
                }`}
              >
                {processingPayment ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    {paymentMethod === 'bank_transfer' ? 'Creating Invoice...' : 'Processing...'}
                  </>
                ) : (
                  <>
                    {paymentMethod === 'bank_transfer' ? (
                      <>
                        <Building2 className="w-4 h-4 mr-2" />
                        Request Invoice
                      </>
                    ) : (
                      <>
                        <CreditCard className="w-4 h-4 mr-2" />
                        Purchase Now
                      </>
                    )}
                  </>
                )}
              </Button>
              
              {/* Value Proposition */}
              <div className="mt-4 text-center">
                <p className="text-xs text-gray-500">
                  {(pkg.price_cents / pkg.credits).toFixed(3)}¢ per credit
                </p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
        </>
      )}

      {/* Trust & Security Section */}
      <Card className="bg-gray-800/30 border-gray-700">
        <CardContent className="p-6">
          <div className="text-center mb-6">
            <Shield className="w-8 h-8 text-green-400 mx-auto mb-2" />
            <h3 className="text-lg font-semibold text-white mb-2">Secure Payment Processing</h3>
            <p className="text-gray-400 text-sm">
              Your payment information is processed securely through Stripe. We never store your credit card details.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-center">
            <div className="space-y-2">
              <CreditCard className="w-6 h-6 text-blue-400 mx-auto" />
              <h4 className="text-white font-medium">Flexible Payment</h4>
              <p className="text-gray-400 text-xs">Major credit cards accepted</p>
            </div>
            <div className="space-y-2">
              <Shield className="w-6 h-6 text-green-400 mx-auto" />
              <h4 className="text-white font-medium">Bank-Level Security</h4>
              <p className="text-gray-400 text-xs">SSL encrypted transactions</p>
            </div>
            <div className="space-y-2">
              <Award className="w-6 h-6 text-purple-400 mx-auto" />
              <h4 className="text-white font-medium">Instant Access</h4>
              <p className="text-gray-400 text-xs">Credits available immediately</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Help Section */}
      <div className="mt-8 text-center">
        <p className="text-gray-400 text-sm mb-2">
          Questions about pricing or need a custom solution?
        </p>
        <Button 
          variant="outline" 
          className="border-gray-600 text-gray-300 hover:bg-gray-800"
          onClick={() => navigate('/contact')}
        >
          Contact Sales
        </Button>
      </div>
    </div>
  );
};

export default Purchase;
