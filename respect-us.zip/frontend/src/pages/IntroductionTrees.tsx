import React, { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { useUserGuardContext } from 'app/auth';
import { ArrowLeft, Loader2, FileText, Info, Package, ArrowRight, BookOpen, Navigation, CheckCircle, Settings, ExternalLink } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { toast } from 'sonner';
import brain from 'brain';
import { 
  IntroductionTree,
  IntroductionTreeNode,
  IntroductionNodeOption,
  IntroductionNavigationRequest
} from '../brain/data-contracts';

interface IntroductionTreeStartResponse {
  tree: IntroductionTree;
  node: IntroductionTreeNode;
  options: IntroductionNodeOption[];
}

interface IntroductionNavigationResponse {
  type: 'routing' | 'complete';
  routing_rule?: string;
  completion_data?: {
    final_selection: string;
    option_value: string;
  };
  decision_path?: Array<{
    question: string;
    answer: string;
  }>;
}

export default function IntroductionTrees() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [trees, setTrees] = useState<IntroductionTree[]>([]);
  const [selectedTree, setSelectedTree] = useState<IntroductionTree | null>(null);
  const [currentNode, setCurrentNode] = useState<IntroductionTreeNode | null>(null);
  const [currentOptions, setCurrentOptions] = useState<IntroductionNodeOption[]>([]);
  const [selectedOption, setSelectedOption] = useState<string>('');
  const [decisionPath, setDecisionPath] = useState<Array<{question: string, answer: string}>>([]);
  const [itemName, setItemName] = useState('');
  const [itemDescription, setItemDescription] = useState('');
  const [showItemForm, setShowItemForm] = useState(false);
  const [navigating, setNavigating] = useState(false);
  const [isCompleted, setIsCompleted] = useState(false);
  const [routingRule, setRoutingRule] = useState<string | null>(null);

  useEffect(() => {
    loadIntroductionTrees();
  }, []);

  const loadIntroductionTrees = async () => {
    try {
      setLoading(true);
      const response = await brain.list_active_introduction_trees();
      const data: IntroductionTree[] = await response.json();
      setTrees(data);
    } catch (error) {
      console.error('Failed to load introduction trees:', error);
      toast.error('Failed to load introduction trees');
    } finally {
      setLoading(false);
    }
  };

  const startIntroduction = async (tree: IntroductionTree) => {
    if (!itemName.trim() || !itemDescription.trim()) {
      toast.error('Please provide both product name and description before starting.');
      return;
    }

    try {
      setLoading(true);
      const response = await brain.get_introduction_tree_start_node({ treeId: tree.id });
      const startData: IntroductionTreeStartResponse = await response.json();
      
      setSelectedTree(tree);
      setCurrentNode(startData.node);
      setCurrentOptions(startData.options);
      setSelectedOption('');
      setDecisionPath([]);
      setIsCompleted(false);
      setRoutingRule(null);
      setShowItemForm(false);
    } catch (error) {
      console.error('Failed to start introduction:', error);
      toast.error('Failed to start introduction tree');
    } finally {
      setLoading(false);
    }
  };

  const handleNavigation = async () => {
    if (!selectedOption) {
      toast.error('Please select an option before continuing.');
      return;
    }

    const selectedOptionObj = currentOptions.find(opt => opt.id === selectedOption);
    if (!selectedOptionObj) {
      toast.error('Invalid option selected.');
      return;
    }

    try {
      setNavigating(true);
      const navigationRequest: IntroductionNavigationRequest = {
        option_id: selectedOption,
        option_value: selectedOptionObj.option_value
      };

      const response = await brain.navigate_introduction_tree(selectedTree!.id, navigationRequest);
      const navigationData: IntroductionNavigationResponse = await response.json();

      // Update decision path
      const newDecisionPath = [
        ...decisionPath,
        {
          question: currentNode!.question_text,
          answer: selectedOptionObj.option_text
        }
      ];
      setDecisionPath(newDecisionPath);

      if (navigationData.type === 'routing' && navigationData.routing_rule) {
        // Introduction complete, route to classification tree
        setRoutingRule(navigationData.routing_rule);
        setIsCompleted(true);
        toast.success('Introduction completed! You can now proceed to detailed classification.');
      } else if (navigationData.type === 'complete') {
        // Introduction completed without specific routing
        setIsCompleted(true);
        toast.success('Introduction completed!');
      }
    } catch (error) {
      console.error('Navigation failed:', error);
      toast.error('Navigation failed. Please try again.');
    } finally {
      setNavigating(false);
    }
  };

  const proceedToClassification = () => {
    if (routingRule) {
      // Navigate to product classification with the routing rule
      navigate(`/product-classification?introductionComplete=true&routingRule=${encodeURIComponent(routingRule)}&productName=${encodeURIComponent(itemName)}&productDescription=${encodeURIComponent(itemDescription)}`);
    } else {
      // Navigate to general product classification
      navigate(`/product-classification?introductionComplete=true&productName=${encodeURIComponent(itemName)}&productDescription=${encodeURIComponent(itemDescription)}`);
    }
  };

  const resetIntroduction = () => {
    setSelectedTree(null);
    setCurrentNode(null);
    setCurrentOptions([]);
    setSelectedOption('');
    setDecisionPath([]);
    setIsCompleted(false);
    setRoutingRule(null);
    setShowItemForm(false);
    setItemName('');
    setItemDescription('');
  };

  if (loading && trees.length === 0) {
    return (
      <div className="min-h-screen bg-gray-900 text-gray-100">
        <div className="container mx-auto px-4 py-8">
          <div className="flex items-center justify-center h-64">
            <Loader2 className="h-8 w-8 animate-spin" />
            <span className="ml-2">Loading introduction trees...</span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-900 text-gray-100">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-4 mb-4">
            <Button 
              variant="outline" 
              onClick={() => navigate('/')}
              className="border-gray-700 hover:bg-gray-800"
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Dashboard
            </Button>
          </div>
          
          <div className="flex items-center gap-3 mb-2">
            <BookOpen className="h-8 w-8 text-cyan-400" />
            <h1 className="text-3xl font-bold">Product Classification Guidance</h1>
          </div>
          <p className="text-gray-400 text-lg">
            Start with our guided introduction to determine the appropriate classification path for your product.
          </p>
        </div>

        {!selectedTree ? (
          <div className="space-y-6">
            {/* Product Information Form */}
            <Card className="bg-gray-800 border-gray-700">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Package className="h-5 w-5 text-cyan-400" />
                  Product Information
                </CardTitle>
                <CardDescription className="text-gray-400">
                  Please provide basic information about your product before starting the classification process.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="itemName">Product Name</Label>
                  <Input
                    id="itemName"
                    value={itemName}
                    onChange={(e) => setItemName(e.target.value)}
                    placeholder="Enter your product name"
                    className="bg-gray-700 border-gray-600 text-gray-100"
                  />
                </div>
                <div>
                  <Label htmlFor="itemDescription">Product Description</Label>
                  <Textarea
                    id="itemDescription"
                    value={itemDescription}
                    onChange={(e) => setItemDescription(e.target.value)}
                    placeholder="Provide a detailed description of your product, including its purpose, materials, and key features"
                    className="bg-gray-700 border-gray-600 text-gray-100"
                    rows={4}
                  />
                </div>
              </CardContent>
            </Card>

            {/* Introduction Trees Selection */}
            <Card className="bg-gray-800 border-gray-700">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Navigation className="h-5 w-5 text-cyan-400" />
                  Available Introduction Guides
                </CardTitle>
                <CardDescription className="text-gray-400">
                  Choose an introduction guide to help determine the right classification approach for your product.
                </CardDescription>
              </CardHeader>
              <CardContent>
                {trees.length === 0 ? (
                  <Alert className="bg-gray-800 border-gray-600">
                    <Info className="h-4 w-4" />
                    <AlertDescription className="text-gray-300">
                      No introduction guides are currently available. Please contact your administrator.
                    </AlertDescription>
                  </Alert>
                ) : (
                  <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                    {trees.map((tree) => (
                      <Card 
                        key={tree.id} 
                        className="bg-gray-700 border-gray-600 hover:bg-gray-650 transition-colors cursor-pointer"
                        onClick={() => {
                          if (itemName.trim() && itemDescription.trim()) {
                            startIntroduction(tree);
                          } else {
                            toast.error('Please fill in product information first.');
                          }
                        }}
                      >
                        <CardHeader className="pb-3">
                          <CardTitle className="text-lg text-gray-100">{tree.name}</CardTitle>
                          {tree.description && (
                            <CardDescription className="text-gray-400 text-sm">
                              {tree.description}
                            </CardDescription>
                          )}
                        </CardHeader>
                        <CardContent className="pt-0">
                          <div className="flex flex-wrap gap-2 mb-3">
                            {tree.jurisdiction && (
                              <Badge variant="outline" className="border-cyan-600 text-cyan-400">
                                {tree.jurisdiction}
                              </Badge>
                            )}
                            {tree.category && (
                              <Badge variant="outline" className="border-gray-600 text-gray-300">
                                {tree.category}
                              </Badge>
                            )}
                          </div>
                          <Button 
                            size="sm" 
                            className="w-full bg-cyan-600 hover:bg-cyan-700"
                            disabled={false}
                            title={!itemName.trim() || !itemDescription.trim() ? 'Please fill in product information above first' : 'Start the guidance workflow'}
                          >
                            {!itemName.trim() || !itemDescription.trim() ? 'Fill Product Info First' : 'Start Guidance'}
                            <ArrowRight className="h-4 w-4 ml-2" />
                          </Button>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        ) : (
          <div className="space-y-6">
            {/* Progress Header */}
            <Card className="bg-gray-800 border-gray-700">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="text-xl">{selectedTree.name}</CardTitle>
                    <CardDescription className="text-gray-400">
                      Product: {itemName}
                    </CardDescription>
                  </div>
                  <Button 
                    variant="outline" 
                    onClick={resetIntroduction}
                    className="border-gray-700 hover:bg-gray-800"
                  >
                    Start Over
                  </Button>
                </div>
                {decisionPath.length > 0 && (
                  <div className="mt-4">
                    <h4 className="text-sm font-medium text-gray-300 mb-2">Your Path:</h4>
                    <div className="space-y-1">
                      {decisionPath.map((step, index) => (
                        <div key={index} className="text-sm text-gray-400">
                          <span className="font-medium">{step.question}:</span> {step.answer}
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </CardHeader>
            </Card>

            {!isCompleted ? (
              /* Current Question */
              <Card className="bg-gray-800 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-lg">{currentNode?.title}</CardTitle>
                  {currentNode?.description && (
                    <CardDescription className="text-gray-400">
                      {currentNode.description}
                    </CardDescription>
                  )}
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="bg-gray-700 p-4 rounded-lg">
                      <p className="text-gray-100 font-medium">{currentNode?.question_text}</p>
                    </div>
                    
                    <RadioGroup value={selectedOption} onValueChange={setSelectedOption}>
                      {currentOptions.map((option) => (
                        <div key={option.id} className="flex items-start space-x-3 p-3 bg-gray-700 rounded-lg hover:bg-gray-650 transition-colors">
                          <RadioGroupItem value={option.id} id={option.id} className="mt-1" />
                          <div className="flex-1">
                            <Label htmlFor={option.id} className="text-gray-100 cursor-pointer">
                              {option.option_text}
                            </Label>
                            {option.note && (
                              <p className="text-sm text-gray-400 mt-1">{option.note}</p>
                            )}
                            {option.routing_rule && (
                              <Badge variant="outline" className="mt-2 border-cyan-600 text-cyan-400">
                                Routes to: {option.routing_rule}
                              </Badge>
                            )}
                          </div>
                        </div>
                      ))}
                    </RadioGroup>
                    
                    <Button 
                      onClick={handleNavigation}
                      disabled={!selectedOption || navigating}
                      className="w-full bg-cyan-600 hover:bg-cyan-700"
                    >
                      {navigating ? (
                        <>
                          <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                          Processing...
                        </>
                      ) : (
                        <>
                          Continue
                          <ArrowRight className="h-4 w-4 ml-2" />
                        </>
                      )}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ) : (
              /* Completion */
              <Card className="bg-gray-800 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-xl text-green-400">Introduction Complete!</CardTitle>
                  <CardDescription className="text-gray-400">
                    Based on your answers, we've determined the appropriate classification path for your product.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {routingRule && (
                    <Alert className="bg-cyan-900/20 border-cyan-600">
                      <Info className="h-4 w-4" />
                      <AlertDescription className="text-cyan-300">
                        Recommended classification approach: <strong>{routingRule}</strong>
                      </AlertDescription>
                    </Alert>
                  )}
                  
                  <div className="bg-gray-700 p-4 rounded-lg">
                    <h4 className="font-medium text-gray-200 mb-2">Your Decision Path:</h4>
                    <div className="space-y-1">
                      {decisionPath.map((step, index) => (
                        <div key={index} className="text-sm text-gray-300">
                          <span className="font-medium">{step.question}:</span> {step.answer}
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  <div className="flex gap-3">
                    <Button 
                      onClick={proceedToClassification}
                      className="flex-1 bg-cyan-600 hover:bg-cyan-700"
                    >
                      Proceed to Classification
                      <ArrowRight className="h-4 w-4 ml-2" />
                    </Button>
                    <Button 
                      variant="outline"
                      onClick={resetIntroduction}
                      className="border-gray-700 hover:bg-gray-800"
                    >
                      Start Over
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
