



import React, { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  User, Settings, CreditCard, FileText, BarChart3, Target, Globe, Users, Search,
  Shield, TrendingUp, Star, Award, Play, CheckCircle, ArrowRight, Activity,
  Receipt, Clock, Bell, Download, DollarSign, Calendar, Package, Building
} from 'lucide-react';
import { toast } from 'sonner';
import { useUserGuardContext } from 'app/auth';
import brain from 'brain';

// Import extracted components
import TeamManagementTab from 'components/TeamManagementTab';
import BillingHistoryTab from 'components/BillingHistoryTab';
import GettingStartedTab from 'components/GettingStartedTab';
import UserProfileSection from 'components/UserProfileSection';
import CompanyManagementSection from 'components/CompanyManagementSection';
import CompanyManagementTab from 'components/CompanyManagementTab';
import AssessmentManagement from 'components/AssessmentManagement';

interface ModuleAccessInfo {
  name: string;
  title: string;
  description?: string;
  user_has_access: boolean;
  status: string;
  price_eur?: number;
  pricing_type?: string; // 'credit_based' for pay-per-use modules
}

interface UserAccessStatus {
  modules: ModuleAccessInfo[];
  active_subscriptions: number;
}

interface UserCompanyContext {
  company_id: number;
  company_name: string;
  company_domain?: string;
  user_role: string;
  permissions: {
    can_invite: boolean;
    can_remove_members: boolean;
    team_management: boolean;
    billing_management: boolean;
    audit_logs: boolean;
    user_management: boolean;
  };
}

interface OnboardingProgress {
  profile_completed: boolean;
  explored_knowledge_base: boolean;
  completed_tour: boolean;
  tried_risk_assessment: boolean;
  configured_workflow: boolean;
}

interface BusinessFormData {
  company_name: string;
  contact_person: string;
  email: string;
}

export default function UserDashboard() {
  const { user } = useUserGuardContext();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const [activeTab, setActiveTab] = useState('getting-started');
  const [userAccessStatus, setUserAccessStatus] = useState<UserAccessStatus | null>(null);
  const [userCompanyContext, setUserCompanyContext] = useState<UserCompanyContext | null>(null);
  const [showGuidedTour, setShowGuidedTour] = useState(false);
  const [loading, setLoading] = useState(true);

  // Onboarding state
  const [onboardingProgress, setOnboardingProgress] = useState<OnboardingProgress>({
    profile_completed: false,
    explored_knowledge_base: false,
    completed_tour: false,
    tried_risk_assessment: false,
    configured_workflow: false
  });

  // Business signup state
  const [showBusinessSignup, setShowBusinessSignup] = useState(false);
  const [businessFormData, setBusinessFormData] = useState<BusinessFormData>({
    company_name: '',
    contact_person: '',
    email: ''
  });
  const [isSubmittingProfile, setIsSubmittingProfile] = useState(false);

  // Load data on component mount
  useEffect(() => {
    const loadInitialData = async () => {
      await Promise.all([
        loadUserProfile(),
        loadUserAccessStatus(),
        loadOnboardingProgress()
      ]);
      setLoading(false);
    };
    loadInitialData();
  }, []);

  // Handle URL tab parameter
  useEffect(() => {
    const tabParam = searchParams.get('tab');
    if (tabParam && ['getting-started', 'services', 'assessments', 'team', 'management', 'billing', 'profile'].includes(tabParam)) {
      setActiveTab(tabParam);
    }
  }, [searchParams]);

  const loadUserProfile = async () => {
    try {
      const response = await brain.get_enhanced_user_profile();
      if (response.ok) {
        const data = await response.json();
        if (data.company_context) {
          setUserCompanyContext(data.company_context);
        }
        if (data.company_name) {
          setOnboardingProgress(prev => ({ ...prev, profile_completed: true }));
        } else {
          setShowBusinessSignup(true);
        }
      }
    } catch (error) {
      console.error('Error loading user profile:', error);
    }
  };

  const loadUserAccessStatus = async () => {
    try {
      const response = await brain.get_user_access_status();
      if (response.ok) {
        const data = await response.json();
        setUserAccessStatus(data);
      }
    } catch (error) {
      console.error('Error loading user access status:', error);
    }
  };

  const loadOnboardingProgress = () => {
    try {
      const saved = localStorage.getItem(`onboarding_progress_${user.id}`);
      if (saved) {
        setOnboardingProgress(JSON.parse(saved));
      }
    } catch (error) {
      console.error('Error loading onboarding progress:', error);
    }
  };

  const handleModuleAccess = (module: ModuleAccessInfo) => {
    if (module.user_has_access) {
      // Navigate to the module
      switch (module.name) {
        case 'risk_assessment':
          navigate('/RiskAssessment');
          break;
        case 'knowledge_base':
          navigate('/KnowledgeBase');
          break;
        case 'customer_screening':
          navigate('/CustomerScreening');
          break;
        case 'product_classification':
          navigate('/ProductClassification');
          break;
        case 'sanctions_embargoes':
          navigate('/SanctionsEmbargoes');
          break;
        case 'end_use_check':
          navigate('/EndUseCheck');
          break;
        case 'license_determination':
          navigate('/LicenseDetermination');
          break;
        default:
          toast.error('Module not available yet');
      }
    } else {
      // Show pricing/purchase options
      setActiveTab('services');
      toast.info(`${module.title} requires a subscription. Check our pricing plans.`);
    }
  };

  const onCompanyContextUpdate = (newContext: UserCompanyContext) => {
    setUserCompanyContext(newContext);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center space-y-4">
          <div className="w-8 h-8 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto" />
          <p className="text-gray-400">Loading your dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black text-white p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-white">Dashboard</h1>
            <p className="text-gray-400 mt-1">Welcome back, {user.displayName || user.primaryEmail}</p>
          </div>
        </div>

        {/* Main Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-7 bg-gray-800/50 border border-gray-700">
            <TabsTrigger value="getting-started" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white">
              <Star className="w-4 h-4 mr-2" />
              Getting Started
            </TabsTrigger>
            <TabsTrigger value="services" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white">
              <Package className="w-4 h-4 mr-2" />
              Services
            </TabsTrigger>
            <TabsTrigger value="assessments" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white">
              <FileText className="w-4 h-4 mr-2" />
              Saved Assessments
            </TabsTrigger>
            <TabsTrigger value="team" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white">
              <Users className="w-4 h-4 mr-2" />
              Team
            </TabsTrigger>
            <TabsTrigger value="management" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white">
              <Building className="w-4 h-4 mr-2" />
              Management
            </TabsTrigger>
            <TabsTrigger value="billing" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white">
              <CreditCard className="w-4 h-4 mr-2" />
              Billing
            </TabsTrigger>
            <TabsTrigger value="profile" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white">
              <User className="w-4 h-4 mr-2" />
              Profile
            </TabsTrigger>
          </TabsList>

          {/* Getting Started Tab */}
          <TabsContent value="getting-started" className="space-y-6 mt-6">
            <GettingStartedTab
              userAccessStatus={userAccessStatus}
              onboardingProgress={onboardingProgress}
              setOnboardingProgress={setOnboardingProgress}
              showBusinessSignup={showBusinessSignup}
              setShowBusinessSignup={setShowBusinessSignup}
              businessFormData={businessFormData}
              setBusinessFormData={setBusinessFormData}
              isSubmittingProfile={isSubmittingProfile}
              setActiveTab={setActiveTab}
              setShowGuidedTour={setShowGuidedTour}
              handleModuleAccess={handleModuleAccess}
              user={user}
            />
          </TabsContent>

          {/* Services Tab */}
          <TabsContent value="services" className="space-y-6 mt-6">
            <Card className="bg-gray-900/50 border-gray-700 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-white flex items-center">
                  <Package className="w-5 h-5 mr-2 text-blue-400" />
                  Available Services
                </CardTitle>
                <CardDescription className="text-gray-400">
                  Choose from our compliance modules and professional services
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {userAccessStatus?.modules.map((module) => (
                    <div
                      key={module.name}
                      className="group cursor-pointer"
                      onClick={() => handleModuleAccess(module)}
                    >
                      <Card className="bg-gradient-to-br from-gray-800/50 to-gray-900/50 border-gray-600 hover:border-blue-500/50 transition-all duration-200 hover:scale-105">
                        <CardContent className="p-6">
                          <div className="flex items-center justify-between mb-4">
                            <div className="w-12 h-12 bg-blue-600/20 rounded-lg flex items-center justify-center">
                              {module.name === 'knowledge_base' && <FileText className="w-6 h-6 text-blue-400" />}
                              {module.name === 'risk_assessment' && <BarChart3 className="w-6 h-6 text-purple-400" />}
                              {module.name === 'product_classification' && <Target className="w-6 h-6 text-green-400" />}
                              {module.name === 'sanctions_embargoes' && <Globe className="w-6 h-6 text-red-400" />}
                              {module.name === 'customer_screening' && <Users className="w-6 h-6 text-amber-400" />}
                              {module.name === 'end_use_check' && <Search className="w-6 h-6 text-cyan-400" />}
                              {module.name === 'license_determination' && <Shield className="w-6 h-6 text-indigo-400" />}
                            </div>
                            <Badge className={`text-xs ${
                              module.status === 'available'
                                ? 'bg-green-500/20 text-green-400 border-green-500/30'
                                : 'bg-gray-500/20 text-gray-400 border-gray-500/30'
                            }`}>
                              {module.status === 'available' ? 'Active' : 'Soon'}
                            </Badge>
                          </div>
                          <h3 className="text-white font-semibold text-lg mb-2">{module.title}</h3>
                          <p className="text-gray-400 text-sm mb-4">
                            {module.description || 'Comprehensive compliance solution for your business needs'}
                          </p>
                          <div className="flex items-center justify-between">
                            <span className={`text-xs px-2 py-1 rounded-full ${
                              module.status === 'available' ? 'bg-green-500/20 text-green-400' : 'bg-gray-500/20 text-gray-400'
                            }`}>
                              {module.status === 'available' ? 'Available' : 'Coming Soon'}
                            </span>
                            {module.status === 'available' && (
                              <Button size="sm" className="bg-blue-600 hover:bg-blue-700 text-white">
                                Launch
                              </Button>
                            )}
                          </div>
                        </CardContent>
                      </Card>
                    </div>
                  )) || (
                    <div className="col-span-full text-center py-12">
                      <Package className="w-12 h-12 mx-auto mb-4 text-gray-500" />
                      <h3 className="text-lg font-semibold text-white mb-2">Loading Services</h3>
                      <p className="text-gray-400">Please wait while we load your available services</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Saved Assessments Tab */}
          <TabsContent value="assessments" className="space-y-6 mt-6">
            <AssessmentManagement />
          </TabsContent>

          {/* Team Tab */}
          <TabsContent value="team" className="space-y-6 mt-6">
            <TeamManagementTab 
              userCompanyContext={userCompanyContext}
              onCompanyContextUpdate={onCompanyContextUpdate}
            />
          </TabsContent>

          {/* Management Tab */}
          <TabsContent value="management" className="space-y-6 mt-6">
            <CompanyManagementTab 
              userCompanyContext={userCompanyContext}
              onCompanyContextUpdate={onCompanyContextUpdate}
            />
          </TabsContent>

          {/* Billing Tab */}
          <TabsContent value="billing" className="space-y-6 mt-6">
            <BillingHistoryTab 
              userCompanyContext={userCompanyContext}
            />
          </TabsContent>

          {/* Profile Tab */}
          <TabsContent value="profile" className="space-y-6 mt-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="space-y-6">
                <UserProfileSection user={user} />
              </div>
              <div className="space-y-6">
                <CompanyManagementSection
                  userCompanyContext={userCompanyContext}
                  setUserCompanyContext={setUserCompanyContext}
                  loadUserProfile={loadUserProfile}
                />
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
