import React, { useState } from 'react';
import { useUserGuardContext } from 'app/auth';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Separator } from '@/components/ui/separator';
import { 
  ChevronLeft, 
  CheckCircle, 
  AlertTriangle,
  TrendingUp,
  TrendingDown,
  Shield,
  Save,
  Send,
  FileText,
  Calendar,
  Building,
  MapPin,
  Package
} from 'lucide-react';
import { toast } from 'sonner';

interface FormData {
  // General Information
  org_name: string;
  assessment_date: string;
  additional_comments: string;
  
  // Strengths
  strength_governance: boolean;
  strength_training: boolean;
  strength_documentation: boolean;
  
  // Weaknesses
  weakness_resources: boolean;
  weakness_systems: boolean;
  
  // Risk Factors
  risk_geographic: string;
  risk_products: string;
}

const InteractiveAssessmentForm = () => {
  const { user } = useUserGuardContext();
  const navigate = useNavigate();
  
  const [formData, setFormData] = useState<FormData>({
    org_name: '',
    assessment_date: '',
    additional_comments: '',
    strength_governance: false,
    strength_training: false,
    strength_documentation: false,
    weakness_resources: false,
    weakness_systems: false,
    risk_geographic: '',
    risk_products: ''
  });
  
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [currentSection, setCurrentSection] = useState(0);
  
  const sections = [
    { id: 'general', title: 'General Information', icon: Building },
    { id: 'strengths', title: 'Organizational Strengths', icon: TrendingUp },
    { id: 'weaknesses', title: 'Areas for Improvement', icon: TrendingDown },
    { id: 'risk_factors', title: 'Risk Assessment', icon: Shield }
  ];
  
  const progress = ((currentSection + 1) / sections.length) * 100;
  
  const handleInputChange = (field: keyof FormData, value: string | boolean) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };
  
  const handleNext = () => {
    if (currentSection < sections.length - 1) {
      setCurrentSection(currentSection + 1);
    }
  };
  
  const handlePrevious = () => {
    if (currentSection > 0) {
      setCurrentSection(currentSection - 1);
    }
  };
  
  const handleSaveDraft = () => {
    // Auto-save functionality
    localStorage.setItem('assessment_draft', JSON.stringify(formData));
    toast.success('Draft saved successfully');
  };
  
  const handleSubmit = async () => {
    // Validate required fields
    if (!formData.org_name || !formData.assessment_date || !formData.risk_geographic || !formData.risk_products) {
      toast.error('Please complete all required fields');
      return;
    }
    
    setIsSubmitting(true);
    
    try {
      // TODO: Submit to backend API
      await new Promise(resolve => setTimeout(resolve, 2000)); // Simulate submission
      
      // Calculate risk score
      const strengthsCount = [formData.strength_governance, formData.strength_training, formData.strength_documentation].filter(Boolean).length;
      const weaknessesCount = [formData.weakness_resources, formData.weakness_systems].filter(Boolean).length;
      const riskLevel = formData.risk_geographic === 'Critical' || formData.risk_products === 'Critical' ? 'High' : 
                       formData.risk_geographic === 'High' || formData.risk_products === 'High' ? 'Medium' : 'Low';
      
      toast.success(`Assessment completed! Risk Level: ${riskLevel}`);
      
      // Clear draft
      localStorage.removeItem('assessment_draft');
      
      // Navigate back to Risk Assessment main page
      navigate('/RiskAssessment');
      
    } catch (error) {
      console.error('Submission error:', error);
      toast.error('Failed to submit assessment. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };
  
  const renderGeneralSection = () => (
    <div className="space-y-6">
      <div className="space-y-2">
        <Label htmlFor="org_name" className="text-slate-200 font-medium flex items-center gap-2">
          <Building className="w-4 h-4" />
          Organization Name *
        </Label>
        <Input
          id="org_name"
          value={formData.org_name}
          onChange={(e) => handleInputChange('org_name', e.target.value)}
          placeholder="Enter your organization's legal name"
          className="bg-slate-800/50 border-slate-600 text-slate-100 placeholder-slate-400"
          required
        />
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="assessment_date" className="text-slate-200 font-medium flex items-center gap-2">
          <Calendar className="w-4 h-4" />
          Assessment Date *
        </Label>
        <Input
          id="assessment_date"
          type="date"
          value={formData.assessment_date}
          onChange={(e) => handleInputChange('assessment_date', e.target.value)}
          className="bg-slate-800/50 border-slate-600 text-slate-100"
          required
        />
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="additional_comments" className="text-slate-200 font-medium flex items-center gap-2">
          <FileText className="w-4 h-4" />
          Additional Comments
        </Label>
        <Textarea
          id="additional_comments"
          value={formData.additional_comments}
          onChange={(e) => handleInputChange('additional_comments', e.target.value)}
          placeholder="Any additional observations or notes"
          className="bg-slate-800/50 border-slate-600 text-slate-100 placeholder-slate-400 min-h-[100px]"
        />
      </div>
    </div>
  );
  
  const renderStrengthsSection = () => (
    <div className="space-y-6">
      <div className="text-center mb-6">
        <TrendingUp className="w-12 h-12 text-emerald-400 mx-auto mb-2" />
        <p className="text-slate-300">Identify your organization's compliance strengths</p>
      </div>
      
      <div className="space-y-4">
        <div className="flex items-start space-x-3 p-4 rounded-lg bg-slate-800/30 border border-slate-600/30">
          <Checkbox
            id="strength_governance"
            checked={formData.strength_governance}
            onCheckedChange={(checked) => handleInputChange('strength_governance', checked as boolean)}
            className="mt-1"
          />
          <div className="flex-1">
            <Label htmlFor="strength_governance" className="text-slate-200 font-medium cursor-pointer">
              Strong governance structure
            </Label>
            <p className="text-sm text-slate-400 mt-1">
              Organization has well-defined compliance governance
            </p>
          </div>
        </div>
        
        <div className="flex items-start space-x-3 p-4 rounded-lg bg-slate-800/30 border border-slate-600/30">
          <Checkbox
            id="strength_training"
            checked={formData.strength_training}
            onCheckedChange={(checked) => handleInputChange('strength_training', checked as boolean)}
            className="mt-1"
          />
          <div className="flex-1">
            <Label htmlFor="strength_training" className="text-slate-200 font-medium cursor-pointer">
              Regular compliance training programs
            </Label>
            <p className="text-sm text-slate-400 mt-1">
              Systematic training and awareness programs
            </p>
          </div>
        </div>
        
        <div className="flex items-start space-x-3 p-4 rounded-lg bg-slate-800/30 border border-slate-600/30">
          <Checkbox
            id="strength_documentation"
            checked={formData.strength_documentation}
            onCheckedChange={(checked) => handleInputChange('strength_documentation', checked as boolean)}
            className="mt-1"
          />
          <div className="flex-1">
            <Label htmlFor="strength_documentation" className="text-slate-200 font-medium cursor-pointer">
              Comprehensive documentation
            </Label>
            <p className="text-sm text-slate-400 mt-1">
              Well-maintained compliance documentation
            </p>
          </div>
        </div>
      </div>
    </div>
  );
  
  const renderWeaknessesSection = () => (
    <div className="space-y-6">
      <div className="text-center mb-6">
        <TrendingDown className="w-12 h-12 text-amber-400 mx-auto mb-2" />
        <p className="text-slate-300">Identify areas that need improvement</p>
      </div>
      
      <div className="space-y-4">
        <div className="flex items-start space-x-3 p-4 rounded-lg bg-slate-800/30 border border-slate-600/30">
          <Checkbox
            id="weakness_resources"
            checked={formData.weakness_resources}
            onCheckedChange={(checked) => handleInputChange('weakness_resources', checked as boolean)}
            className="mt-1"
          />
          <div className="flex-1">
            <Label htmlFor="weakness_resources" className="text-slate-200 font-medium cursor-pointer">
              Limited compliance resources
            </Label>
            <p className="text-sm text-slate-400 mt-1">
              Insufficient staff or budget for compliance activities
            </p>
          </div>
        </div>
        
        <div className="flex items-start space-x-3 p-4 rounded-lg bg-slate-800/30 border border-slate-600/30">
          <Checkbox
            id="weakness_systems"
            checked={formData.weakness_systems}
            onCheckedChange={(checked) => handleInputChange('weakness_systems', checked as boolean)}
            className="mt-1"
          />
          <div className="flex-1">
            <Label htmlFor="weakness_systems" className="text-slate-200 font-medium cursor-pointer">
              Outdated systems and processes
            </Label>
            <p className="text-sm text-slate-400 mt-1">
              Legacy systems that don't support modern compliance
            </p>
          </div>
        </div>
      </div>
    </div>
  );
  
  const renderRiskFactorsSection = () => (
    <div className="space-y-6">
      <div className="text-center mb-6">
        <Shield className="w-12 h-12 text-red-400 mx-auto mb-2" />
        <p className="text-slate-300">Assess your organization's risk exposure</p>
      </div>
      
      <div className="space-y-6">
        <div className="space-y-2">
          <Label className="text-slate-200 font-medium flex items-center gap-2">
            <MapPin className="w-4 h-4" />
            Geographic risk exposure *
          </Label>
          <p className="text-sm text-slate-400 mb-2">
            Level of risk from operating in high-risk jurisdictions
          </p>
          <Select value={formData.risk_geographic} onValueChange={(value) => handleInputChange('risk_geographic', value)}>
            <SelectTrigger className="bg-slate-800/50 border-slate-600 text-slate-100">
              <SelectValue placeholder="Select risk level" />
            </SelectTrigger>
            <SelectContent className="bg-slate-800 border-slate-600">
              <SelectItem value="Low" className="text-slate-100">Low</SelectItem>
              <SelectItem value="Medium" className="text-slate-100">Medium</SelectItem>
              <SelectItem value="High" className="text-slate-100">High</SelectItem>
              <SelectItem value="Critical" className="text-slate-100">Critical</SelectItem>
            </SelectContent>
          </Select>
        </div>
        
        <div className="space-y-2">
          <Label className="text-slate-200 font-medium flex items-center gap-2">
            <Package className="w-4 h-4" />
            Product/Service risk level *
          </Label>
          <p className="text-sm text-slate-400 mb-2">
            Risk level of products or services offered
          </p>
          <Select value={formData.risk_products} onValueChange={(value) => handleInputChange('risk_products', value)}>
            <SelectTrigger className="bg-slate-800/50 border-slate-600 text-slate-100">
              <SelectValue placeholder="Select risk level" />
            </SelectTrigger>
            <SelectContent className="bg-slate-800 border-slate-600">
              <SelectItem value="Low" className="text-slate-100">Low</SelectItem>
              <SelectItem value="Medium" className="text-slate-100">Medium</SelectItem>
              <SelectItem value="High" className="text-slate-100">High</SelectItem>
              <SelectItem value="Critical" className="text-slate-100">Critical</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
    </div>
  );
  
  const renderCurrentSection = () => {
    switch (currentSection) {
      case 0: return renderGeneralSection();
      case 1: return renderStrengthsSection();
      case 2: return renderWeaknessesSection();
      case 3: return renderRiskFactorsSection();
      default: return renderGeneralSection();
    }
  };
  
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      {/* Header */}
      <div className="border-b border-slate-700/50 backdrop-blur-sm bg-slate-900/80">
        <div className="max-w-6xl mx-auto px-6 py-4">
          <div className="flex items-center gap-4">
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={() => navigate('/RiskAssessment')}
              className="text-slate-400 hover:text-slate-200"
            >
              <ChevronLeft className="w-4 h-4 mr-1" />
              Back to Risk Assessment
            </Button>
            <Separator orientation="vertical" className="h-6 bg-slate-600" />
            <h1 className="text-xl font-semibold text-slate-100">Strengths & Weaknesses Assessment</h1>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-6 py-8">
        {/* Progress Section */}
        <Card className="mb-8 bg-slate-800/30 border-slate-700/50">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-medium text-slate-200">Assessment Progress</h2>
              <Badge variant="outline" className="bg-slate-700/50 text-slate-300 border-slate-600">
                {currentSection + 1} of {sections.length}
              </Badge>
            </div>
            <Progress value={progress} className="h-2 mb-4" />
            <div className="flex justify-between text-sm">
              {sections.map((section, index) => {
                const Icon = section.icon;
                return (
                  <div key={section.id} className={`flex items-center gap-2 ${
                    index === currentSection ? 'text-blue-400' : 
                    index < currentSection ? 'text-emerald-400' : 'text-slate-500'
                  }`}>
                    <Icon className="w-4 h-4" />
                    <span className="hidden sm:inline">{section.title}</span>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {/* Form Section */}
        <Card className="bg-slate-800/30 border-slate-700/50">
          <CardHeader>
            <CardTitle className="text-slate-100 flex items-center gap-3">
              {React.createElement(sections[currentSection].icon, { className: "w-6 h-6" })}
              {sections[currentSection].title}
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            {renderCurrentSection()}
            
            {/* Navigation Buttons */}
            <div className="flex justify-between items-center mt-8 pt-6 border-t border-slate-700/50">
              <div className="flex gap-3">
                <Button
                  variant="outline"
                  onClick={handlePrevious}
                  disabled={currentSection === 0}
                  className="bg-slate-700/50 border-slate-600 text-slate-200 hover:bg-slate-600/50"
                >
                  <ChevronLeft className="w-4 h-4 mr-2" />
                  Previous
                </Button>
                
                <Button
                  variant="outline"
                  onClick={handleSaveDraft}
                  className="bg-slate-700/50 border-slate-600 text-slate-200 hover:bg-slate-600/50"
                >
                  <Save className="w-4 h-4 mr-2" />
                  Save Draft
                </Button>
              </div>
              
              <div>
                {currentSection < sections.length - 1 ? (
                  <Button
                    onClick={handleNext}
                    className="bg-blue-600 hover:bg-blue-700 text-white"
                  >
                    Next Section
                    <ChevronLeft className="w-4 h-4 ml-2 rotate-180" />
                  </Button>
                ) : (
                  <Button
                    onClick={handleSubmit}
                    disabled={isSubmitting}
                    className="bg-emerald-600 hover:bg-emerald-700 text-white"
                  >
                    {isSubmitting ? (
                      <>
                        <div className="w-4 h-4 mr-2 border-2 border-white/20 border-t-white rounded-full animate-spin" />
                        Submitting...
                      </>
                    ) : (
                      <>
                        <Send className="w-4 h-4 mr-2" />
                        Complete Assessment
                      </>
                    )}
                  </Button>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default InteractiveAssessmentForm;