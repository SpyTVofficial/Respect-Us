
import React, { useState, useEffect } from 'react';
import { 
  Calendar, 
  Download, 
  Filter, 
  TrendingUp, 
  Coins, 
  Activity, 
  Clock, 
  ArrowUpDown,
  BarChart3,
  PieChart,
  Search,
  RefreshCw,
  FileText,
  CreditCard,
  AlertCircle
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { DatePickerWithRange } from 'components/DatePickerWithRange';
import { useUserGuardContext } from 'app/auth';
import { useCreditBalance } from 'utils/useCreditBalance';
import brain from 'brain';
import { toast } from 'sonner';
import { format } from 'date-fns';
import { DateRange } from 'react-day-picker';

interface Transaction {
  id: string;
  transaction_type: string;
  amount: number;
  balance_after: number;
  description: string;
  component_name?: string;
  action_name?: string;
  created_at: string;
  metadata?: Record<string, any>;
}

interface UsageAnalytics {
  total_consumed: number;
  total_purchased: number;
  most_used_module: string;
  average_daily_usage: number;
  usage_by_module: Array<{
    module: string;
    credits_used: number;
    action_count: number;
    percentage: number;
  }>;
  daily_usage: Array<{
    date: string;
    credits_used: number;
    actions_count: number;
  }>;
  cost_trends: Array<{
    period: string;
    cost: number;
    savings: number;
  }>;
}

interface BillingPeriod {
  period_start: string;
  period_end: string;
  credits_consumed: number;
  credits_purchased: number;
  net_balance_change: number;
  top_modules: string[];
}

export default function UsageHistoryDashboard() {
  const { user } = useUserGuardContext();
  const { balance, refreshBalance } = useCreditBalance();
  
  // State management
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [analytics, setAnalytics] = useState<UsageAnalytics | null>(null);
  const [billingPeriods, setBillingPeriods] = useState<BillingPeriod[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('overview');
  
  // Filters
  const [dateRange, setDateRange] = useState<DateRange | undefined>({
    from: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000), // 30 days ago
    to: new Date()
  });
  const [transactionTypeFilter, setTransactionTypeFilter] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<'date' | 'amount' | 'type'>('date');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('desc');
  
  // Pagination
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 20;

  useEffect(() => {
    fetchUsageData();
  }, [dateRange, transactionTypeFilter]);

  const fetchUsageData = async () => {
    try {
      setIsLoading(true);
      
      // Fetch transactions
      const transactionsResponse = await brain.get_user_transactions({
        start_date: dateRange?.from?.toISOString(),
        end_date: dateRange?.to?.toISOString(),
        transaction_type: transactionTypeFilter === 'all' ? undefined : transactionTypeFilter,
        limit: 100
      });
      const transactionsData = await transactionsResponse.json();
      setTransactions(transactionsData.transactions || []);
      
      // Fetch analytics
      const analyticsResponse = await brain.get_user_usage_analytics({
        start_date: dateRange?.from?.toISOString(),
        end_date: dateRange?.to?.toISOString()
      });
      const analyticsData = await analyticsResponse.json();
      setAnalytics(analyticsData);
      
      // Fetch billing periods
      const billingResponse = await brain.get_user_billing_periods({ months: 6 });
      const billingData = await billingResponse.json();
      setBillingPeriods(billingData.periods || []);
      
    } catch (error) {
      console.error('Failed to fetch usage data:', error);
      toast.error('Failed to load usage data');
    } finally {
      setIsLoading(false);
    }
  };

  const exportUsageData = async (format: 'csv' | 'excel' | 'pdf') => {
    try {
      const response = await brain.export_usage_report({
        format,
        start_date: dateRange?.from?.toISOString(),
        end_date: dateRange?.to?.toISOString(),
        include_analytics: true
      });
      
      // Handle file download
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `usage-report-${format}-${format(new Date(), 'yyyy-MM-dd')}.${format}`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      
      toast.success(`Usage report exported as ${format.toUpperCase()}`);
    } catch (error) {
      console.error('Export failed:', error);
      toast.error('Failed to export usage data');
    }
  };

  const formatCredits = (amount: number) => {
    return amount.toLocaleString();
  };

  const getTransactionTypeColor = (type: string) => {
    switch (type) {
      case 'consumption': return 'bg-red-500/20 text-red-400 border-red-500/30';
      case 'purchase': return 'bg-green-500/20 text-green-400 border-green-500/30';
      case 'free_tier_welcome': return 'bg-purple-500/20 text-purple-400 border-purple-500/30';
      case 'trial_bonus': return 'bg-blue-500/20 text-blue-400 border-blue-500/30';
      case 'refund': return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30';
      default: return 'bg-gray-500/20 text-gray-400 border-gray-500/30';
    }
  };

  const filteredAndSortedTransactions = transactions
    .filter(t => 
      !searchQuery || 
      t.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.component_name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.action_name?.toLowerCase().includes(searchQuery.toLowerCase())
    )
    .sort((a, b) => {
      let aVal: any, bVal: any;
      
      switch (sortBy) {
        case 'date':
          aVal = new Date(a.created_at);
          bVal = new Date(b.created_at);
          break;
        case 'amount':
          aVal = Math.abs(a.amount);
          bVal = Math.abs(b.amount);
          break;
        case 'type':
          aVal = a.transaction_type;
          bVal = b.transaction_type;
          break;
        default:
          return 0;
      }
      
      if (sortDirection === 'asc') {
        return aVal > bVal ? 1 : -1;
      } else {
        return aVal < bVal ? 1 : -1;
      }
    });

  const paginatedTransactions = filteredAndSortedTransactions.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  const totalPages = Math.ceil(filteredAndSortedTransactions.length / itemsPerPage);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-950 flex items-center justify-center">
        <div className="text-center">
          <RefreshCw className="w-8 h-8 animate-spin text-blue-400 mx-auto mb-4" />
          <p className="text-gray-400">Loading usage data...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-950 text-white p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-white">Usage & Billing Dashboard</h1>
            <p className="text-gray-400 mt-1">
              Track your credit usage, billing history, and compliance activity
            </p>
          </div>
          
          <div className="flex items-center space-x-3">
            <Button 
              variant="outline" 
              onClick={() => fetchUsageData()}
              className="border-gray-700 text-gray-300 hover:bg-gray-800"
            >
              <RefreshCw className="w-4 h-4 mr-2" />
              Refresh
            </Button>
            
            <Select value="csv" onValueChange={(format) => exportUsageData(format as any)}>
              <SelectTrigger className="w-32 bg-gray-800 border-gray-700">
                <Download className="w-4 h-4 mr-2" />
                <SelectValue placeholder="Export" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="csv">CSV</SelectItem>
                <SelectItem value="excel">Excel</SelectItem>
                <SelectItem value="pdf">PDF</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Current Balance Overview */}
        {balance && (
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card className="bg-gray-900 border-gray-800">
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <Coins className="w-5 h-5 text-purple-400" />
                  <span className="text-sm text-gray-400">Current Balance</span>
                </div>
                <div className="text-2xl font-bold text-purple-400 mt-1">
                  {formatCredits(balance.current_balance)}
                </div>
                <div className="text-xs text-gray-500">credits</div>
              </CardContent>
            </Card>
            
            <Card className="bg-gray-900 border-gray-800">
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <TrendingUp className="w-5 h-5 text-green-400" />
                  <span className="text-sm text-gray-400">Lifetime Purchased</span>
                </div>
                <div className="text-2xl font-bold text-green-400 mt-1">
                  {formatCredits(balance.lifetime_purchased)}
                </div>
                <div className="text-xs text-gray-500">credits</div>
              </CardContent>
            </Card>
            
            <Card className="bg-gray-900 border-gray-800">
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <Activity className="w-5 h-5 text-blue-400" />
                  <span className="text-sm text-gray-400">Lifetime Consumed</span>
                </div>
                <div className="text-2xl font-bold text-blue-400 mt-1">
                  {formatCredits(balance.lifetime_consumed)}
                </div>
                <div className="text-xs text-gray-500">credits</div>
              </CardContent>
            </Card>
            
            <Card className="bg-gray-900 border-gray-800">
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <BarChart3 className="w-5 h-5 text-orange-400" />
                  <span className="text-sm text-gray-400">Efficiency Rating</span>
                </div>
                <div className="text-2xl font-bold text-orange-400 mt-1">
                  {balance.lifetime_purchased > 0 
                    ? Math.round((balance.lifetime_consumed / balance.lifetime_purchased) * 100)
                    : 0
                  }%
                </div>
                <div className="text-xs text-gray-500">utilization</div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Filters */}
        <div className="flex flex-wrap items-center gap-4 p-4 bg-gray-900 rounded-lg border border-gray-800">
          <div className="flex items-center space-x-2">
            <Calendar className="w-4 h-4 text-gray-400" />
            <DatePickerWithRange
              date={dateRange}
              onDateChange={setDateRange}
            />
          </div>
          
          <Select value={transactionTypeFilter} onValueChange={setTransactionTypeFilter}>
            <SelectTrigger className="w-48 bg-gray-800 border-gray-700">
              <Filter className="w-4 h-4 mr-2" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Transactions</SelectItem>
              <SelectItem value="consumption">Usage Only</SelectItem>
              <SelectItem value="purchase">Purchases Only</SelectItem>
              <SelectItem value="free_tier_welcome">Free Credits</SelectItem>
              <SelectItem value="refund">Refunds</SelectItem>
            </SelectContent>
          </Select>
          
          <div className="flex items-center space-x-2">
            <Search className="w-4 h-4 text-gray-400" />
            <Input
              placeholder="Search transactions..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-64 bg-gray-800 border-gray-700"
            />
          </div>
        </div>

        {/* Main Content Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="bg-gray-900 border-gray-800">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="transactions">Transaction History</TabsTrigger>
            <TabsTrigger value="analytics">Usage Analytics</TabsTrigger>
            <TabsTrigger value="billing">Billing Periods</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            {analytics && (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Usage by Module */}
                <Card className="bg-gray-900 border-gray-800">
                  <CardHeader>
                    <CardTitle className="text-white flex items-center space-x-2">
                      <PieChart className="w-5 h-5" />
                      <span>Usage by Module</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    {analytics.usage_by_module.map((module, index) => (
                      <div key={index} className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <div 
                            className="w-3 h-3 rounded-full"
                            style={{ backgroundColor: `hsl(${index * 60}, 70%, 50%)` }}
                          />
                          <span className="text-gray-300">{module.module}</span>
                        </div>
                        <div className="text-right">
                          <div className="text-white font-medium">
                            {formatCredits(module.credits_used)} credits
                          </div>
                          <div className="text-xs text-gray-400">
                            {module.percentage.toFixed(1)}% • {module.action_count} actions
                          </div>
                        </div>
                      </div>
                    ))}
                  </CardContent>
                </Card>

                {/* Daily Usage Trend */}
                <Card className="bg-gray-900 border-gray-800">
                  <CardHeader>
                    <CardTitle className="text-white flex items-center space-x-2">
                      <TrendingUp className="w-5 h-5" />
                      <span>Daily Usage Trend</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      {analytics.daily_usage.slice(-7).map((day, index) => (
                        <div key={index} className="flex items-center justify-between">
                          <span className="text-gray-400 text-sm">
                            {format(new Date(day.date), 'MMM dd')}
                          </span>
                          <div className="flex items-center space-x-2">
                            <div className="text-white font-medium">
                              {formatCredits(day.credits_used)} credits
                            </div>
                            <div className="text-xs text-gray-500">
                              ({day.actions_count} actions)
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}
          </TabsContent>

          {/* Transactions Tab */}
          <TabsContent value="transactions" className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <span className="text-gray-400">
                  {filteredAndSortedTransactions.length} transactions
                </span>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc')}
                  className="text-gray-400 hover:text-white"
                >
                  <ArrowUpDown className="w-3 h-3 mr-1" />
                  Sort {sortDirection === 'asc' ? 'Descending' : 'Ascending'}
                </Button>
              </div>
              
              {totalPages > 1 && (
                <div className="flex items-center space-x-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
                    disabled={currentPage === 1}
                    className="border-gray-700"
                  >
                    Previous
                  </Button>
                  <span className="text-gray-400 text-sm">
                    Page {currentPage} of {totalPages}
                  </span>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
                    disabled={currentPage === totalPages}
                    className="border-gray-700"
                  >
                    Next
                  </Button>
                </div>
              )}
            </div>

            <Card className="bg-gray-900 border-gray-800">
              <Table>
                <TableHeader>
                  <TableRow className="border-gray-800">
                    <TableHead 
                      className="text-gray-400 cursor-pointer hover:text-white"
                      onClick={() => setSortBy('date')}
                    >
                      <div className="flex items-center space-x-1">
                        <Clock className="w-3 h-3" />
                        <span>Date & Time</span>
                      </div>
                    </TableHead>
                    <TableHead 
                      className="text-gray-400 cursor-pointer hover:text-white"
                      onClick={() => setSortBy('type')}
                    >
                      Type
                    </TableHead>
                    <TableHead className="text-gray-400">Description</TableHead>
                    <TableHead 
                      className="text-gray-400 text-right cursor-pointer hover:text-white"
                      onClick={() => setSortBy('amount')}
                    >
                      <div className="flex items-center justify-end space-x-1">
                        <Coins className="w-3 h-3" />
                        <span>Credits</span>
                      </div>
                    </TableHead>
                    <TableHead className="text-gray-400 text-right">Balance After</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {paginatedTransactions.map((transaction) => (
                    <TableRow key={transaction.id} className="border-gray-800">
                      <TableCell className="text-gray-300">
                        <div>
                          <div>{format(new Date(transaction.created_at), 'MMM dd, yyyy')}</div>
                          <div className="text-xs text-gray-500">
                            {format(new Date(transaction.created_at), 'HH:mm:ss')}
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge className={getTransactionTypeColor(transaction.transaction_type)}>
                          {transaction.transaction_type.replace('_', ' ')}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-gray-300 max-w-xs">
                        <div className="truncate">{transaction.description}</div>
                        {transaction.component_name && (
                          <div className="text-xs text-gray-500">
                            {transaction.component_name} → {transaction.action_name}
                          </div>
                        )}
                      </TableCell>
                      <TableCell className={`text-right font-medium ${
                        transaction.amount > 0 ? 'text-green-400' : 'text-red-400'
                      }`}>
                        {transaction.amount > 0 ? '+' : ''}{formatCredits(transaction.amount)}
                      </TableCell>
                      <TableCell className="text-right text-gray-300">
                        {formatCredits(transaction.balance_after)}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
              
              {paginatedTransactions.length === 0 && (
                <div className="text-center py-12">
                  <FileText className="w-12 h-12 text-gray-600 mx-auto mb-4" />
                  <p className="text-gray-400">No transactions found for the selected criteria.</p>
                </div>
              )}
            </Card>
          </TabsContent>

          {/* Analytics Tab */}
          <TabsContent value="analytics" className="space-y-6">
            {analytics && (
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <Card className="bg-gray-900 border-gray-800">
                  <CardHeader>
                    <CardTitle className="text-white">Usage Summary</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex justify-between">
                      <span className="text-gray-400">Total Consumed:</span>
                      <span className="text-red-400 font-medium">
                        {formatCredits(analytics.total_consumed)} credits
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Total Purchased:</span>
                      <span className="text-green-400 font-medium">
                        {formatCredits(analytics.total_purchased)} credits
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Daily Average:</span>
                      <span className="text-blue-400 font-medium">
                        {analytics.average_daily_usage.toFixed(1)} credits
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Most Used Module:</span>
                      <span className="text-purple-400 font-medium">
                        {analytics.most_used_module}
                      </span>
                    </div>
                  </CardContent>
                </Card>

                {/* Additional analytics cards would go here */}
                <Card className="bg-gray-900 border-gray-800 lg:col-span-2">
                  <CardHeader>
                    <CardTitle className="text-white">Cost Optimization Tips</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <Alert className="bg-blue-900/20 border-blue-500/30">
                      <AlertCircle className="w-4 h-4" />
                      <AlertDescription className="text-blue-300">
                        <ul className="space-y-2 mt-2">
                          <li>• Consider bulk credit packages for better value</li>
                          <li>• Use tier discounts by maintaining consistent usage</li>
                          <li>• Set up auto-recharge to avoid workflow interruptions</li>
                          <li>• Monitor module efficiency to optimize workflows</li>
                        </ul>
                      </AlertDescription>
                    </Alert>
                  </CardContent>
                </Card>
              </div>
            )}
          </TabsContent>

          {/* Billing Tab */}
          <TabsContent value="billing" className="space-y-4">
            <div className="grid gap-4">
              {billingPeriods.map((period, index) => (
                <Card key={index} className="bg-gray-900 border-gray-800">
                  <CardHeader>
                    <CardTitle className="text-white flex items-center justify-between">
                      <span>
                        {format(new Date(period.period_start), 'MMM yyyy')}
                      </span>
                      <Badge className="bg-gray-700 text-gray-300">
                        {format(new Date(period.period_start), 'MMM dd')} - {format(new Date(period.period_end), 'MMM dd')}
                      </Badge>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                      <div>
                        <div className="text-sm text-gray-400">Credits Consumed</div>
                        <div className="text-lg font-medium text-red-400">
                          {formatCredits(period.credits_consumed)}
                        </div>
                      </div>
                      <div>
                        <div className="text-sm text-gray-400">Credits Purchased</div>
                        <div className="text-lg font-medium text-green-400">
                          {formatCredits(period.credits_purchased)}
                        </div>
                      </div>
                      <div>
                        <div className="text-sm text-gray-400">Net Change</div>
                        <div className={`text-lg font-medium ${
                          period.net_balance_change >= 0 ? 'text-green-400' : 'text-red-400'
                        }`}>
                          {period.net_balance_change >= 0 ? '+' : ''}{formatCredits(period.net_balance_change)}
                        </div>
                      </div>
                      <div>
                        <div className="text-sm text-gray-400">Top Modules</div>
                        <div className="text-sm text-gray-300">
                          {period.top_modules.slice(0, 2).join(', ')}
                          {period.top_modules.length > 2 && ` +${period.top_modules.length - 2} more`}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
