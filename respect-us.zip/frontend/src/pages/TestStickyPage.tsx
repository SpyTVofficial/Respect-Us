import React from 'react';
import TestStickyTable from 'components/TestStickyTable';

function TestStickyPage() {
  return (
    <div className="min-h-screen bg-gray-900 p-8">
      <TestStickyTable />
    </div>
  );
}

export default TestStickyPage;
