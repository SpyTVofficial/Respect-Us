import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { toast } from 'sonner';
import {
  Search,
  Download,
  Upload,
  Filter,
  X,
  MapPin,
  Calendar,
  AlertTriangle,
  AlertCircle,
  FileText,
  Eye,
  ExternalLink,
  Trash2,
  Plus,
  Edit,
  Globe,
  Users,
  TrendingUp,
  BarChart3,
  Target,
  Shield,
  Zap,
  ChevronRight,
  ChevronUp,
  ChevronDown,
  CreditCard,
  Info,
  Server,
  Beaker,
  Microscope,
  Loader2,
} from 'lucide-react';
import brain from 'brain';
import { useUserGuardContext } from 'app/auth';
import { CreditConfirmationDialog } from 'components/CreditConfirmationDialog';
import CreditDialog from 'components/CreditDialog';
import { Tooltip, TooltipContent, TooltipTrigger, TooltipProvider } from '@/components/ui/tooltip';
import Navigation from 'components/Navigation';

interface Country {
  id: number;
  country_name: string;
  abbreviation?: string;
  iso_code?: string;
  is_active?: boolean;
  risk_level?: string;
  risk_categories?: string;
  risk_description?: string;
  last_risk_assessment_date?: string;
  export_control_risk?: string;
  sanctions_risk?: string;
  arms_risk?: string;
  chemical_risk?: string;
  biological_risk?: string;
  nuclear_risk?: string;
  human_rights_freedoms_risk?: string;
  // Arms embargo fields
  un_arms_embargo?: boolean;
  us_arms_embargo?: boolean;
  eu_arms_embargo?: boolean;
  other_arms_embargo?: boolean;
  // Freedom scores
  political_rights_score?: number;
  human_rights_risk_score?: number;
  freedom_note?: string;
  // Legacy support
  name?: string; // For compatibility
  human_rights_risk?: string; // For compatibility
}

interface CreditPackage {
  id: number;
  name: string;
  credits: number;
  price_cents: number;
  currency: string;
}

interface ContentItem {
  id: number;
  content_type: string;
  module_name: string;
  identifier: string;
  title: string;
  content: any;
  metadata?: any;
}

interface TeaserContent {
  title: string;
  content: string;
  metadata?: any;
}

const isTerritory = (countryName: string): boolean => {
  const name = countryName.toLowerCase();
  
  // Exact list of territories as defined by the user
  const territories = [
    'abkhazia',
    'gaza strip',
    'hong kong',
    'indian kashmir',
    'northern cyprus',
    'pakistani kashmir',
    'russian-occupied territories of ukraine',
    'south ossetia',
    'transnistria',
    'west bank',
    'western sahara'
  ];
  
  return territories.includes(name);
};

const getRiskLevelColor = (riskLevel: string | undefined): string => {
  switch (riskLevel?.toLowerCase()) {
    case 'high':
      return 'bg-red-600 border-red-500';
    case 'medium':
      return 'bg-orange-600 border-orange-500';
    case 'low':
      return 'bg-green-600 border-green-500';
    default:
      return 'bg-gray-600 border-gray-500';
  }
};

// Helper function to format risk level display
const formatRiskLevel = (level: string | null | undefined): string => {
  if (!level) return 'N/A';
  return level.toUpperCase();
};

const getRiskLevelTextColor = (riskLevel: string | undefined): string => {
  switch (riskLevel?.toLowerCase()) {
    case 'high':
      return 'text-red-100';
    case 'medium':
      return 'text-orange-100';
    case 'low':
      return 'text-green-100';
    default:
      return 'text-gray-100';
  }
};

const EndUseChecks = () => {
  const { user } = useUserGuardContext();
  const [countries, setCountries] = useState<Country[]>([]);
  const [filteredCountries, setFilteredCountries] = useState<Country[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [riskFilter, setRiskFilter] = useState('all');
  const [sanctionsFilter, setSanctionsFilter] = useState('all');
  const [exportControlFilter, setExportControlFilter] = useState('all');
  const [armsFilter, setArmsFilter] = useState('all');
  const [loading, setLoading] = useState(true);
  const [creditDialogOpen, setCreditDialogOpen] = useState(false);
  const [pendingAction, setPendingAction] = useState<string>('');
  const [creditPackages, setCreditPackages] = useState<CreditPackage[]>([]);
  const [hasAccess, setHasAccess] = useState(false);
  const [accessBenefits, setAccessBenefits] = useState<string[]>([]);
  const [contentLoading, setContentLoading] = useState(true);
  const [teaserContent, setTeaserContent] = useState<TeaserContent | null>(null);
  const [viewCreditInfo, setViewCreditInfo] = useState<any>(null);
  const [exportCreditInfo, setExportCreditInfo] = useState<any>(null);
  const [loadingCreditInfo, setLoadingCreditInfo] = useState(true);
  const [hasUnlockedView, setHasUnlockedView] = useState(false);
  const [isUnlocking, setIsUnlocking] = useState(false);
  const [isExporting, setIsExporting] = useState(false);
  const [showCreditDialog, setShowCreditDialog] = useState(false);
  const [showExportOptions, setShowExportOptions] = useState(false);
  const [exportFormat, setExportFormat] = useState<'csv' | 'pdf'>('csv');
  const [includeDetailedData, setIncludeDetailedData] = useState(false);
  const [activeTab, setActiveTab] = useState('critical-countries');
  const [selectedCountry, setSelectedCountry] = useState<Country | null>(null);
  const [showCountryDetails, setShowCountryDetails] = useState(false);
  const [showSourcesDialog, setShowSourcesDialog] = useState(false);
  const [sortField, setSortField] = useState('country_name');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');
  const [showMethodology, setShowMethodology] = useState(false);
  const [stats, setStats] = useState<any>(null);
  const [isExportingPDF, setIsExportingPDF] = useState(false);
  const [riskOptions] = useState([
    { value: 'all', label: 'All Risk Levels' },
    { value: 'High', label: 'High Risk' },
    { value: 'Medium', label: 'Medium Risk' },
    { value: 'Low', label: 'Low Risk' }
  ]);

  // Dynamic content from content management
  const [dataSourcesContent, setDataSourcesContent] = useState<any>(null);
  const [methodologyContent, setMethodologyContent] = useState<any>(null);
  const [dynamicContentLoading, setDynamicContentLoading] = useState(true);
  const [accessBenefitsContent, setAccessBenefitsContent] = useState<string>('');
  const [criticalCountriesTeaser, setCriticalCountriesTeaser] = useState<string>('');

  // Load access benefits content
  useEffect(() => {
    const loadAccessBenefits = async () => {
      try {
        const response = await brain.get_content_by_module({ moduleName: 'end_use_checks' });
        const content = await response.json();
        
        // Find the access_benefits content
        const accessContent = content.items?.find((item: ContentItem) => 
          item.identifier === 'access_benefits' || 
          item.content?.text?.includes('Comprehensive country risk profiles')
        );
        
        // Find the critical countries teaser content
        const teaserItem = content.items?.find((item: ContentItem) => 
          item.identifier === 'critical_countries_teaser' || item.content_key === 'critical_countries_teaser'
        );
        
        if (teaserItem) {
          setTeaserContent({
            title: teaserItem.title || 'About Critical Countries Assessment',
            content: teaserItem.content || 'The Critical Countries table provides comprehensive risk assessment data.',
            metadata: teaserItem.metadata
          });
        }
        
        if (accessContent) {
          let benefitsList: string[] = [];
          
          // Handle different content formats
          if (typeof accessContent.content === 'string') {
            // Pipe-separated format
            benefitsList = accessContent.content.split('|').map((item: string) => item.trim());
          } else if (accessContent.content?.text) {
            // Text property with pipe separation
            benefitsList = accessContent.content.text.split('|').map((item: string) => item.trim());
          } else if (Array.isArray(accessContent.content)) {
            // Already an array
            benefitsList = accessContent.content;
          } else {
            // Fallback to default list
            benefitsList = [
              'Comprehensive country risk profiles with detailed analysis',
              'Advanced filtering and search capabilities',
              'Real-time updates from authoritative sources',
              'Detailed documentation and regulatory guidance'
            ];
          }
          
          setAccessBenefits(benefitsList);
        } else {
          // Fallback to default content
          setAccessBenefits([
            'Comprehensive country risk profiles with detailed analysis of export controls, sanctions regimes, and proliferation concerns',
            'Advanced filtering and search capabilities to quickly identify high-risk destinations', 
            'Real-time updates from authoritative government sources including BIS, State Department, and EU agencies',
            'Detailed documentation and regulatory guidance for compliance decisions',
            'Historical trend analysis and risk scoring methodologies',
            'Export control treaty participation and compliance status',
            'Arms embargo and sanctions monitoring across multiple jurisdictions'
          ]);
        }
      } catch (error) {
        console.error('Error loading content:', error);
        // Fallback to default content
        setAccessBenefits([
          'Comprehensive country risk profiles with detailed analysis of export controls, sanctions regimes, and proliferation concerns',
          'Advanced filtering and search capabilities to quickly identify high-risk destinations',
          'Real-time updates from authoritative government sources including BIS, State Department, and EU agencies', 
          'Detailed documentation and regulatory guidance for compliance decisions',
          'Historical trend analysis and risk scoring methodologies',
          'Export control treaty participation and compliance status',
          'Arms embargo and sanctions monitoring across multiple jurisdictions'
        ]);
      } finally {
        setContentLoading(false);
      }
    };

    loadAccessBenefits();
  }, []);

  // Check user access on component mount
  useEffect(() => {
    const checkAccess = async () => {
      try {
        const response = await brain.check_action_pricing({
          componentName: 'end_use_checks',
          actionName: 'view_critical_countries'
        });
        const data = await response.json();
        setHasAccess(data.has_access || false);
      } catch (error) {
        console.error('Error checking access:', error);
        setHasAccess(false);
      }
    };

    checkAccess();
  }, []);

  // Load countries data when component mounts or filters change
  useEffect(() => {
    loadCountries();
    loadCreditInfo();
    loadCreditPackages();
  }, [searchTerm, riskFilter]);

  // Filter countries when search or filters change
  useEffect(() => {
    filterCountries();
  }, [countries, searchTerm, riskFilter, sanctionsFilter, exportControlFilter, armsFilter, sortField, sortDirection]);

  const loadCountries = async () => {
    try {
      setLoading(true);
      const response = await brain.get_critical_countries_list({
        limit: 250, // Increased to ensure we get all countries
        offset: 0,
        search: searchTerm || undefined,
        risk_level: riskFilter === 'all' ? undefined : riskFilter,
        is_active: undefined // Remove status filtering from API call
      });
      const data = await response.json();
      setCountries(data.countries || []);
    } catch (error) {
      console.error('Error loading countries:', error);
      toast.error('Failed to load countries');
    } finally {
      setLoading(false);
    }
  };

  const filterCountries = () => {
    let filtered = countries.filter(country => {
      const matchesSearch = !searchTerm || 
        (country.country_name || country.name || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
        (country.iso_code || '').toLowerCase().includes(searchTerm.toLowerCase());

      const matchesRisk = riskFilter === 'all' || country.risk_level === riskFilter;

      return matchesSearch && matchesRisk;
    });

    // Sort the filtered results
    filtered.sort((a, b) => {
      let aValue = a[sortField] || '';
      let bValue = b[sortField] || '';

      if (sortField === 'country_name') {
        aValue = a.country_name || a.name || '';
        bValue = b.country_name || b.name || '';
      }

      if (typeof aValue === 'string') {
        aValue = aValue.toLowerCase();
        bValue = bValue.toLowerCase();
      }

      if (sortDirection === 'asc') {
        return aValue < bValue ? -1 : aValue > bValue ? 1 : 0;
      } else {
        return aValue > bValue ? -1 : aValue < bValue ? 1 : 0;
      }
    });

    setFilteredCountries(filtered);
  };

  const handleSort = (field: string) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  const handleViewDetails = (country: Country) => {
    setSelectedCountry(country);
    setShowCountryDetails(true);
  };

  const handleExportCountryPDF = async () => {
    if (!selectedCountry) return;
    
    try {
      setIsExportingPDF(true);
      
      const response = await brain.generate_country_report({
        country_id: selectedCountry.id,
        include_executive_summary: true,
        include_detailed_analysis: true,
        include_recommendations: true,
      });
      
      if (response.ok) {
        // Handle binary PDF response
        const blob = await response.blob();
        
        // Create download link
        const url = window.URL.createObjectURL(new Blob([blob], { type: 'application/pdf' }));
        const link = document.createElement('a');
        link.href = url;
        const countryName = selectedCountry.country_name || selectedCountry.name || 'Country';
        link.download = `${countryName.replace(/\s+/g, '_')}_Risk_Analysis_Report.pdf`;
        document.body.appendChild(link);
        link.click();
        
        // Cleanup
        window.URL.revokeObjectURL(url);
        document.body.removeChild(link);
        
        toast.success('Country risk analysis report downloaded successfully');
      } else {
        const errorData = await response.json();
        throw new Error(errorData.detail || 'Export failed');
      }
    } catch (error) {
      console.error('Error exporting PDF:', error);
      toast.error('Failed to export PDF report. Please try again.');
    } finally {
      setIsExportingPDF(false);
    }
  };

  const handleDownload = async () => {
    try {
      // First check if credits are required for this action
      const pricingResponse = await brain.check_action_pricing({
        componentName: 'end_use_checks',
        actionName: 'export_critical_countries'
      });
      
      if (!pricingResponse.ok) {
        toast.error('Failed to check pricing information');
        return;
      }
      
      const pricingData = await pricingResponse.json();
      
      if (pricingData.is_free) {
        // If free, proceed directly with export
        performExport();
      } else {
        // If credits required, show confirmation dialog
        setShowCreditDialog(true);
      }
    } catch (error) {
      console.error('Error checking pricing:', error);
      toast.error('Failed to check pricing information');
    }
  };

  const performExport = async () => {
    try {
      setPendingAction('exporting');
      
      // Use the brain client for the export which handles the correct URL routing
      const exportRequest = {
        format: exportFormat,
        search_term: searchTerm || null,
        risk_categories: null, // Can be extended later
        has_arms_embargo: null, // Can be extended later
        freedom_score_min: null,
        freedom_score_max: null,
        include_all_indicators: includeDetailedData
      };
      
      console.log('🔄 Starting export with format:', exportFormat);
      
      // Use brain client streaming method for file downloads
      const responseIterator = brain.export_critical_countries(exportRequest);
      
      // Collect all chunks into a single array
      const chunks: string[] = [];
      for await (const chunk of responseIterator) {
        chunks.push(chunk);
      }
      
      console.log('📦 Collected chunks:', chunks.length);
      
      // Join all chunks into single content
      const content = chunks.join('');
      
      if (content) {
        // Create appropriate blob based on format
        let blob: Blob;
        let filename = `critical-countries-${new Date().toISOString().split('T')[0]}`;
        
        switch (exportFormat) {
          case 'csv':
            blob = new Blob([content], { type: 'text/csv' });
            filename += '.csv';
            break;
          case 'json':
            blob = new Blob([content], { type: 'application/json' });
            filename += '.json';
            break;
          case 'pdf':
            // For PDF, content should be base64 or binary
            blob = new Blob([content], { type: 'application/pdf' });
            filename += '.pdf';
            break;
          default:
            blob = new Blob([content], { type: 'text/plain' });
            filename += '.txt';
        }
        
        console.log('💾 Triggering download for filename:', filename);
        
        // Create download link and trigger download
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        a.style.display = 'none';
        
        // Add to DOM, click, and clean up
        document.body.appendChild(a);
        a.click();
        
        // Clean up after a short delay to ensure download starts
        setTimeout(() => {
          document.body.removeChild(a);
          URL.revokeObjectURL(url);
          console.log('🧹 Cleanup completed');
        }, 1000);
        
        toast.success(`Critical Countries data exported as ${exportFormat.toUpperCase()} successfully`);
      } else {
        console.error('❌ No content received from export');
        toast.error('No data received from export');
      }
    } catch (error) {
      console.error('💥 Error exporting data:', error);
      toast.error('Failed to export data. Please try again.');
    } finally {
      setPendingAction('');
      setShowExportOptions(false);
    }
  };

  const handleCreditConfirm = async () => {
    try {
      // Consume credits for the export action
      const response = await brain.consume_credits({
        component_name: 'end_use_checks',
        action_name: 'export_critical_countries',
        resource_id: null,
        description: `Export critical countries data (${filteredCountries.length} countries)`
      });
      
      if (response.ok) {
        const result = await response.json();
        if (result.success || result.credits_consumed > 0) {
          setShowCreditDialog(false);
          performExport();
          toast.success(`Export completed. ${result.credits_consumed || 0} credits consumed.`);
        } else {
          toast.error('Failed to consume credits for export');
        }
      } else {
        toast.error('Failed to process credit transaction');
      }
    } catch (error) {
      console.error('Error consuming credits:', error);
      toast.error('Failed to process credit transaction');
    }
  };

  const handleCreditCancel = () => {
    setShowCreditDialog(false);
  }

  // Handle export with credits
  const handleExportWithCredits = async () => {
    if (!exportCreditInfo || isExporting) return;

    try {
      setIsExporting(true);
      setShowExportOptions(false);
      setShowCreditDialog(false);

      // Use the same export method for all formats
      await performExport();

      toast.success('Export completed successfully!');
    } catch (error) {
      console.error('Export error:', error);
      toast.error('Export failed. Please try again.');
    } finally {
      setIsExporting(false);
    }
  };

  // Load credit information when component mounts
  const loadCreditInfo = async () => {
    try {
      setLoadingCreditInfo(true);
      
      // Load both view and export credit info separately
      const [viewResponse, exportResponse] = await Promise.all([
        brain.check_action_pricing({
          componentName: 'end_use_checks',
          actionName: 'view_critical_countries'
        }),
        brain.check_action_pricing({
          componentName: 'end_use_checks',
          actionName: 'export_critical_countries'
        })
      ]);
      
      if (viewResponse.ok) {
        const viewData = await viewResponse.json();
        setViewCreditInfo({
          credit_cost: viewData.credit_cost || 0,
          user_balance: viewData.user_balance || 0,
          is_free: viewData.is_free || false
        });
      }
      
      if (exportResponse.ok) {
        const exportData = await exportResponse.json();
        setExportCreditInfo({
          credit_cost: exportData.credit_cost || 0,
          user_balance: exportData.user_balance || 0,
          is_free: exportData.is_free || false
        });
      }
    } catch (error) {
      console.error('Error loading credit info:', error);
    } finally {
      setLoadingCreditInfo(false);
    }
  };

  useEffect(() => {
    loadCreditInfo();
  }, []);

  // Load view credit information
  const loadViewCreditInfo = async () => {
    try {
      const response = await brain.check_action_pricing({
        componentName: 'end_use_checks',
        actionName: 'view_critical_countries'
      });
      
      if (response.ok) {
        const data = await response.json();
        setViewCreditInfo({
          credit_cost: data.credit_cost || 0,
          user_balance: data.user_balance || 0,
          is_free: data.is_free || false
        });
      }
    } catch (error) {
      console.error('Error loading view credit info:', error);
    }
  };

  // Handle unlocking countries view
  const handleUnlockView = async () => {
    if (!viewCreditInfo || isUnlocking) return;
    
    try {
      setIsUnlocking(true);
      
      // Deduct credits for viewing
      const response = await brain.check_action_pricing({
        componentName: 'end_use_checks',
        actionName: 'view_critical_countries',
        deductCredits: true
      });
      
      if (response.ok) {
        setHasUnlockedView(true);
        setCreditDialogOpen(false); // Close any unlock dialog
        toast.success('Countries list unlocked successfully!');
        // Refresh credit info
        loadViewCreditInfo();
      } else {
        toast.error('Failed to unlock countries view');
      }
    } catch (error) {
      console.error('Error unlocking view:', error);
      toast.error('Failed to unlock countries view');
    } finally {
      setIsUnlocking(false);
    }
  };

  // Initialize all data when component mounts
  useEffect(() => {
    loadCountries();
    loadCreditInfo();
    loadCreditPackages();
  }, []);

  const loadCreditPackages = async () => {
    try {
      const response = await brain.get_credit_packages();
      if (response.ok) {
        const packages = await response.json();
        setCreditPackages(packages);
      }
    } catch (error) {
      console.error('Error loading credit packages:', error);
    }
  };

  // Dynamic content from content management
  useEffect(() => {
    const loadDynamicContent = async () => {
      try {
        const response = await brain.get_content_by_module({ moduleName: 'end_use_checks' });
        const content = await response.json();
        
        // Find the data_sources content
        const dataSourcesItem = content.items?.find((item: ContentItem) => 
          item.identifier === 'data_sources_explanation' || 
          item.content_key === 'data_sources_explanation'
        );
        
        // Find the methodology content
        const methodologyItem = content.items?.find((item: ContentItem) => 
          item.identifier === 'methodology_details' || 
          item.content_key === 'methodology_details'
        );
        
        // Find the access benefits content
        const accessBenefitsItem = content.items?.find((item: ContentItem) => 
          item.identifier === 'access_benefits' || 
          item.content_key === 'access_benefits'
        );
        
        // Find the teaser content
        const teaserItem = content.items?.find((item: ContentItem) => 
          item.identifier === 'critical_countries_teaser' || 
          item.content_key === 'critical_countries_teaser'
        );
        
        if (dataSourcesItem) {
          setDataSourcesContent({
            title: dataSourcesItem.title || 'View Data Sources',
            content: dataSourcesItem.content || {},
            metadata: dataSourcesItem.metadata
          });
        }
        
        if (methodologyItem) {
          setMethodologyContent({
            title: methodologyItem.title || 'Risk Assessment Methodology',
            content: methodologyItem.content || {},
            metadata: methodologyItem.metadata
          });
        }
        
        // Store access benefits and teaser for use in other parts of the component
        if (accessBenefitsItem) {
          setAccessBenefitsContent(accessBenefitsItem.content?.text || '');
        }
        
        if (teaserItem) {
          setCriticalCountriesTeaser(teaserItem.content?.text || '');
        }
        
        setDynamicContentLoading(false);
      } catch (error) {
        console.error('Error loading dynamic content:', error);
        setDynamicContentLoading(false);
      }
    };

    loadDynamicContent();
  }, []);

  return (
    <div className="container mx-auto p-6 space-y-6">
      {/* Navigation Component */}
      <Navigation currentPage="end_use_checks" />
      
      {/* Module Sub-Header */}
      <div className="flex justify-between items-center pt-4">
        <div>
          <h1 className="text-3xl font-bold text-white">End-Use Checks</h1>
          <p className="text-gray-400 mt-1">Comprehensive end-use assessment and monitoring</p>
        </div>
      </div>

      {/* Main Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-2 bg-gray-800">
          <TabsTrigger value="critical-countries" className="data-[state=active]:bg-gray-700 text-gray-300">
            Critical Countries
          </TabsTrigger>
          <TabsTrigger value="catch-all" className="data-[state=active]:bg-gray-700 text-gray-300">
            Catch-All
          </TabsTrigger>
        </TabsList>

        {/* Critical Countries Tab */}
        <TabsContent value="critical-countries" className="space-y-6">
          {/* Critical Countries Teaser Section */}
          {teaserContent && (
            <Card className="bg-gray-900/50 border-gray-700 mb-6">
              <CardContent className="p-6">
                {teaserContent.title && (
                  <h2 className="text-lg font-semibold text-white mb-1">
                    {teaserContent.title}
                  </h2>
                )}
                <div className="prose prose-invert max-w-none text-gray-300">
                  {typeof teaserContent.content === 'object' && teaserContent.content?.text 
                    ? teaserContent.content.text 
                    : teaserContent.content}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Risk Assessment Methodology Card */}
          <Card className="bg-gradient-to-r from-blue-900/50 to-purple-900/50 border border-blue-700/50">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Shield className="h-5 w-5 text-blue-400" />
                  <div>
                    <CardTitle className="text-white text-lg">Risk Assessment Methodology</CardTitle>
                    <CardDescription className="text-gray-300 ">
                      Comprehensive country risk analysis based on multiple authoritative sources
                    </CardDescription>
                  </div>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setShowMethodology(!showMethodology)}
                  className="text-blue-400 hover:text-blue-300 hover:bg-blue-900/30"
                >
                  {showMethodology ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
                  {showMethodology ? 'Hide Details' : 'View Details'}
                </Button>
              </div>
            </CardHeader>
            
            {showMethodology && (
              <CardContent className="pt-0">
                {/* Dynamic Methodology Content */}
                {methodologyContent && methodologyContent.content?.text ? (
                  <div className="space-y-4">
                    <div className="prose prose-invert prose-sm max-w-none">
                      <div 
                        dangerouslySetInnerHTML={{
                          __html: methodologyContent.content.text
                            .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
                            .replace(/\n\n/g, '</p><p>')
                            .replace(/^(.+)$/, '<p>$1</p>')
                            .replace(/• /g, '</li><li>')
                            .replace(/<p><li>/g, '<ul><li>')
                            .replace(/<\/li><\/p>/g, '</li></ul>')
                            .replace(/<li>([^<]+)<\/li>/g, '<li>$1</li>')
                            .replace(/<\/li><li>/g, '</li><li>')
                        }}
                      />
                    </div>
                  </div>
                ) : (
                  // Fallback content when dynamic content is not available
                  <div className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-4">
                      <div className="bg-gray-800/50 p-3 rounded-lg border border-gray-700">
                        <div className="flex items-center gap-2 mb-2">
                          <AlertTriangle className="h-4 w-4 text-orange-400" />
                          <span className="text-white font-medium text-sm">Export Control</span>
                        </div>
                        <p className="text-gray-300 text-xs">OFAC, BIS, EU dual-use regulations</p>
                      </div>
                      
                      <div className="bg-gray-800/50 p-3 rounded-lg border border-gray-700">
                        <div className="flex items-center gap-2 mb-2">
                          <Shield className="h-4 w-4 text-red-400" />
                          <span className="text-white font-medium text-sm">Sanctions</span>
                        </div>
                        <p className="text-gray-300 text-xs">UN,OFAC, EU, UK sanctions databases</p>
                      </div>
                      
                      <div className="bg-gray-800/50 p-3 rounded-lg border border-gray-700">
                        <div className="flex items-center gap-2 mb-2">
                          <Globe className="h-4 w-4 text-yellow-400" />
                          <span className="text-white font-medium text-sm">Arms Control</span>
                        </div>
                        <p className="text-gray-300 text-xs">UN arms embargoes, regional restrictions</p>
                      </div>
                      
                      <div className="bg-gray-800/50 p-3 rounded-lg border border-gray-700">
                        <div className="flex items-center gap-2 mb-1">
                          <FileText className="h-4 w-4 text-purple-400" />
                          <span className="text-white font-medium text-sm">Human Rights</span>
                        </div>
                        <p className="text-gray-300 text-xs">Freedom House, UN Human Rights reports</p>
                      </div>
                    </div>
                  </div>
                )}
                
                <div className="flex items-center justify-between pt-3 border-t border-gray-700">
                  <div className="flex items-center gap-2 text-sm text-gray-300">
                    <span className="w-2 h-2 bg-green-500 rounded-full"></span>
                    Data updated monthly from authoritative sources
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setShowSourcesDialog(true)}
                    className="border-blue-600 text-blue-400 hover:bg-blue-900/30 hover:text-blue-300"
                  >
                    <ExternalLink className="h-3 w-3 mr-1" />
                    View Complete Sources
                  </Button>
                </div>
              </CardContent>
            )}
          </Card>

          {/* Existing Countries Card */}
          {countries.length === 0 && !loading ? (
            <Card className="bg-gray-800 border-gray-700">
              <CardContent className="p-8 text-center">
                <Upload className="w-16 h-16 text-gray-500 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-white mb-2">No Country Data Available</h3>
                <p className="text-gray-400 mb-4">
                  To get started with Critical Countries assessment, you need to upload country risk data.
                </p>
                <div className="space-y-4 max-w-md mx-auto">
                  <div className="bg-gray-700 p-4 rounded-lg text-left">
                    <h4 className="text-white font-medium mb-2">How to Access Data:</h4>
                    <ol className="text-sm text-gray-300 space-y-1">
                      <li>1. Contact your administrator to upload country data</li>
                      <li>2. Data will be uploaded through the admin dashboard</li>
                      <li>3. Once uploaded, data will appear here for assessment</li>
                      <li>4. You can then search, filter, and analyze countries</li>
                    </ol>
                  </div>
                  <div className="text-center">
                    <p className="text-sm text-gray-400">
                      Need access to upload data? Contact your system administrator.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ) : (
            <>
              {/* Stats Cards */}
              {stats && (
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <Card className="bg-gray-800/50 border-gray-700">
                    <CardContent className="p-4">
                      <div className="flex items-center gap-2">
                        <Globe className="h-5 w-5 text-blue-400" />
                        <div>
                          <div className="text-sm text-gray-400">Total Countries</div>
                          <div className="text-xl font-semibold text-white">{stats.total_countries || 0}</div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                  
                  <Card className="bg-gray-800/50 border-gray-700">
                    <CardContent className="p-4">
                      <div className="flex items-center gap-2">
                        <AlertTriangle className="h-5 w-5 text-red-400" />
                        <div>
                          <div className="text-sm text-gray-400">High Risk</div>
                          <div className="text-xl font-semibold text-white">{stats.by_risk_level?.high || 0}</div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                  
                  <Card className="bg-gray-800/50 border-gray-700">
                    <CardContent className="p-4">
                      <div className="flex items-center gap-2">
                        <Shield className="h-5 w-5 text-orange-400" />
                        <div>
                          <div className="text-sm text-gray-400">Arms Embargoes</div>
                          <div className="text-xl font-semibold text-white">{stats.by_arms_embargo?.with_embargo || 0}</div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                  
                  <Card className="bg-gray-800/50 border-gray-700">
                    <CardContent className="p-4">
                      <div className="flex items-center gap-2">
                        <FileText className="h-5 w-5 text-green-400" />
                        <div>
                          <div className="text-sm text-gray-400">Active</div>
                          <div className="text-xl font-semibold text-white">{stats.by_status?.active || 0}</div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              )}

              {/* Search and Filters */}
              <Card className="bg-gray-800 border-gray-700">
                <CardContent className="p-4">
                  <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
                    <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center">
                      <div className="relative">
                        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                        <Input
                          placeholder="Search countries..."
                          value={searchTerm}
                          onChange={(e) => setSearchTerm(e.target.value)}
                          className="pl-10 bg-gray-700 border-gray-600 text-white w-64"
                        />
                      </div>
                      
                      <Select value={riskFilter} onValueChange={setRiskFilter}>
                        <SelectTrigger className="bg-gray-700 border-gray-600 text-white w-48">
                          <SelectValue placeholder="Show Countries by Risk Level" />
                        </SelectTrigger>
                        <SelectContent>
                          {riskOptions.map(option => (
                            <SelectItem key={option.value} value={option.value}>
                              {option.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div className="flex flex-col gap-2">
                      {/* Credit Information Display */}
                      {loadingCreditInfo ? (
                        <div className="flex items-center gap-2 text-sm text-gray-400">
                          <div className="animate-spin rounded-full h-3 w-3 border-b border-blue-600"></div>
                          Loading pricing...
                        </div>
                      ) : exportCreditInfo ? (
                        <div className="flex items-center gap-2 text-sm">
                          {exportCreditInfo.is_free ? (
                            <div className="flex items-center gap-1 text-green-400">
                              <CheckCircle className="w-4 h-4" />
                              <span>Free Export</span>
                            </div>
                          ) : (
                            <div className="flex items-center gap-2">
                              <div className="flex items-center gap-1 text-blue-400">
                                <AlertTriangle className="w-4 h-4" />
                                <span>{exportCreditInfo.credit_cost} credits required</span>
                              </div>
                              <div className="text-gray-400">•</div>
                              <div className="text-gray-300">
                                Balance: <span className={exportCreditInfo.user_balance >= exportCreditInfo.credit_cost ? 'text-green-400' : 'text-red-400'}>
                                  {exportCreditInfo.user_balance} credits
                                </span>
                              </div>
                            </div>
                          )}
                        </div>
                      ) : null}
                      
                      <Button
                        onClick={() => setShowExportOptions(true)}
                        className="bg-blue-600 hover:bg-blue-700"
                        disabled={filteredCountries.length === 0 || isExporting || (exportCreditInfo && !exportCreditInfo.is_free && exportCreditInfo.user_balance < exportCreditInfo.credit_cost)}
                      >
                        <Download className="w-4 h-4 mr-2" />
                        {isExporting ? 'Exportexport...' : 'Export Data'}
                      </Button>
                      
                      {exportCreditInfo && !exportCreditInfo.is_free && exportCreditInfo.user_balance < exportCreditInfo.credit_cost && (
                        <p className="text-xs text-red-400 mt-1">Insufficient credits for export</p>
                      )}
                    </div>
                  </div>

                  <div className="text-sm text-gray-400 mt-4">
                    Showing {filteredCountries.length} of {countries.length} countries
                  </div>
                </CardContent>
              </Card>

              {/* Credit Protection for Viewing Countries */}
              {viewCreditInfo && !viewCreditInfo.is_free && !hasUnlockedView && (
                <Card className="bg-blue-900/20 border-blue-500/30">
                  <CardContent className="p-6">
                    <div className="text-center space-y-4">
                      <div className="bg-blue-500/20 p-3 rounded-lg inline-block">
                        <CreditCard className="w-8 h-8 text-blue-400 mx-auto" />
                      </div>
                      <div>
                        <h3 className="text-xl font-semibold text-white mb-2">Unlock Critical Countries Database</h3>
                        <p className="text-gray-300 mb-4">
                          Access comprehensive risk assessment data for {countries.length} critical countries worldwide
                        </p>
                        <div className="bg-gray-800/50 p-4 rounded-lg mb-1">
                          <p className="text-sm text-gray-300 mb-3 font-medium">What you'll get access to:</p>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-sm text-gray-400">
                            {accessBenefits.map((benefit, index) => (
                              <div key={index} className="flex items-center gap-2">
                                <div className="w-1.5 h-1.5 bg-blue-400 rounded-full"></div>
                                {benefit}
                              </div>
                            ))}
                          </div>
                        </div>
                        <div className="flex items-center justify-center gap-4 mb-1 text-sm">
                          <div className="text-blue-400 font-medium">
                            Cost: {viewCreditInfo.credit_cost} credits
                          </div>
                          <div className="text-gray-400">•</div>
                          <div className="text-gray-300">
                            Your Balance: <span className={viewCreditInfo.user_balance >= viewCreditInfo.credit_cost ? 'text-green-400' : 'text-red-400'}>
                              {viewCreditInfo.user_balance} credits
                            </span>
                          </div>
                        </div>
                        
                        {/* Show unlock button if user has enough credits */}
                        {viewCreditInfo.user_balance >= viewCreditInfo.credit_cost ? (
                          <Button
                            onClick={() => setCreditDialogOpen(true)}
                            disabled={isUnlocking}
                            className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3 text-lg"
                          >
                            {isUnlocking ? 'Unlocking...' : `Unlock for ${viewCreditInfo.credit_cost} Credits`}
                          </Button>
                        ) : (
                          /* Show pricing packages if insufficient credits */
                          <div className="space-y-4">
                            <div className="bg-red-900/20 border border-red-500/30 rounded-lg p-4 mb-4">
                              <div className="flex items-center gap-2 text-red-400 mb-1">
                                <AlertTriangle className="w-4 h-4" />
                                <span className="font-medium">Insufficient Credits</span>
                              </div>
                              <p className="text-red-300 text-sm">
                                You need {viewCreditInfo.credit_cost - viewCreditInfo.user_balance} more credits to unlock this feature.
                              </p>
                            </div>
                            
                            <div className="bg-gray-800/50 p-4 rounded-lg">
                              <h4 className="text-white font-medium mb-3 text-center">Choose a Credit Package</h4>
                              <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
                                {creditPackages.map((pkg, index) => {
                                  const isPopular = pkg.name === 'Professional';
                                  const isEnterprise = pkg.name === 'Enterprise' || pkg.name === 'Enterprise+';
                                  
                                  return (
                                    <div 
                                      key={pkg.id} 
                                      className={`p-3 rounded-lg border ${
                                        isPopular ? 'bg-blue-900/30 border-blue-500/50' :
                                        isEnterprise ? 'bg-purple-900/30 border-purple-500/50' :
                                        'bg-gray-700/50 border-gray-600'
                                      }`}
                                    >
                                      <div className="text-center">
                                        <div className="text-lg font-semibold text-white">{pkg.name}</div>
                                        <div className={`text-2xl font-bold mb-1 ${
                                          isPopular ? 'text-blue-400' :
                                          isEnterprise ? 'text-purple-400' :
                                          'text-blue-400'
                                        }`}>
                                          {pkg.credits.toLocaleString()}
                                        </div>
                                        <div className="text-xs text-gray-400 mb-2">credits</div>
                                        <div className="text-lg text-white mb-1">
                                          €{(pkg.price_cents / 100).toFixed(0)}
                                        </div>
                                        <Button 
                                          size="sm" 
                                          className={`w-full ${
                                            isPopular ? 'bg-blue-600 hover:bg-blue-700' :
                                            isEnterprise ? 'bg-purple-600 hover:bg-purple-700' :
                                            'bg-gray-600 hover:bg-gray-500'
                                          }`}
                                        >
                                          Purchase
                                        </Button>
                                      </div>
                                    </div>
                                  );
                                })}
                              </div>
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Preview Table (Greyed Out) - Temporarily disabled to show full table */}
              {false && viewCreditInfo && !viewCreditInfo.is_free && !hasUnlockedView && viewCreditInfo.user_balance < viewCreditInfo.credit_cost && filteredCountries.length > 0 && (
                <Card className="bg-gray-800/30 border-gray-700 relative">
                  <div className="absolute inset-0 bg-gray-900/70 z-10 rounded-lg flex items-center justify-center">
                    <div className="text-center p-6">
                      <CreditCard className="w-12 h-12 text-gray-500 mx-auto mb-1" />
                      <h1 className="text-lg font-semibold text-gray-300 mb-2">Preview Mode</h1>
                      <p className="text-gray-400 text-sm">
                        Purchase credits above to unlock full access to {filteredCountries.length} countries
                      </p>
                    </div>
                  </div>
                  <div className="opacity-30 pointer-events-none">
                    <div className="overflow-x-auto">
                      <TooltipProvider>
                        <Table>
                          <TableHeader>
                            <TableRow className="border-gray-600">
                              <TableHead className="text-white w-48">
                                <div className="flex items-center gap-2">
                                  Country
                                </div>
                              </TableHead>
                              <TableHead className="text-white text-center w-24">
                                <div className="flex items-center justify-center gap-1">
                                  Overall Risk
                                </div>
                              </TableHead>
                              <TableHead className="text-white text-center w-32">
                                <div className="flex items-center justify-center gap-1">
                                  Export Control
                                </div>
                              </TableHead>
                              <TableHead className="text-white text-center w-24">
                                <div className="flex items-center justify-center gap-1">
                                  Sanctions
                                </div>
                              </TableHead>
                              <TableHead className="text-white text-center w-14">
                                <div className="flex items-center justify-center gap-1">
                                  Arms Embargo
                                </div>
                              </TableHead>
                              <TableHead className="text-white text-center w-32 bg-gray-800">Actions</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {filteredCountries.slice(0, 5).map((country) => (
                              <TableRow key={country.id} className="border-gray-600 hover:bg-gray-700/50">
                                <TableCell className="text-white">
                                  <div className="flex items-center gap-3">
                                    <MapPin className="h-4 w-4 text-gray-400" />
                                    <div>
                                      <div className="font-medium">{country.country_name || country.name}</div>
                                      <div className="text-xs text-gray-400">{country.iso_code}</div>
                                    </div>
                                  </div>
                                </TableCell>
                                <TableCell className="text-center">
                                  <Badge variant="outline" className={`border-red-500 text-red-400`}>
                                    {country.risk_level || 'High'}
                                  </Badge>
                                </TableCell>
                                <TableCell className="text-center">
                                  <Badge variant="outline" className={`border-orange-500 text-orange-400`}>
                                    {country.export_control_risk || 'Medium'}
                                  </Badge>
                                </TableCell>
                                <TableCell className="text-center">
                                  <Badge variant="outline" className={`border-red-500 text-red-400`}>
                                    {country.sanctions_risk || 'Active'}
                                  </Badge>
                                </TableCell>
                                <TableCell className="text-center">
                                  {country.arms_embargo ? (
                                    <Badge variant="outline" className="border-red-500 text-red-400">
                                      <Shield className="h-3 w-3 mr-1" />
                                      Yes
                                    </Badge>
                                  ) : (
                                    <Badge variant="outline" className="border-green-500 text-green-400">
                                      <CheckCircle className="h-3 w-3 mr-1" />
                                      No
                                    </Badge>
                                  )}
                                </TableCell>
                                <TableCell className="text-center">
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    className="text-blue-400 hover:text-blue-300 hover:bg-blue-900/30"
                                  >
                                    <Eye className="h-4 w-4 mr-1" />
                                    View Details
                                  </Button>
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </TooltipProvider>
                    </div>
                    {filteredCountries.length > 5 && (
                      <div className="p-4 text-center text-gray-400 text-sm border-t border-gray-600">
                        + {filteredCountries.length - 5} more countries available after unlock
                      </div>
                    )}
                  </div>
                </Card>
              )}

              {/* Full Countries Table - Force display for debugging */}
              <Card className="bg-gray-800/50 border-gray-700">
                <div className="border border-gray-600 rounded-lg overflow-hidden">
                  <div className="max-h-[70vh] overflow-auto">
                    <TooltipProvider>
                      <table className="w-full text-sm text-left">
                        <thead>
                          <tr>
                            <th 
                              className="px-6 py-3 text-white cursor-pointer hover:text-blue-400 min-w-[12rem] bg-gray-800"
                              style={{ position: 'sticky', top: 0, zIndex: 10 }}
                              onClick={() => handleSort('country_name')}
                            >
                              <div className="flex items-center gap-2">
                                Country
                                {sortField === 'country_name' && (
                                  sortDirection === 'asc' ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />
                                )}
                              </div>
                            </th>
                            <th 
                              className="px-6 py-3 text-white text-center cursor-pointer hover:text-blue-400 w-16 bg-gray-800"
                              style={{ position: 'sticky', top: 0, zIndex: 10 }}
                              onClick={() => handleSort('iso_code')}
                            >
                              <div className="flex items-center justify-center gap-1">
                                ISO
                                {sortField === 'iso_code' && (
                                  sortDirection === 'asc' ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />
                                )}
                              </div>
                            </th>
                            <th 
                              className="px-6 py-3 text-white text-center cursor-pointer hover:text-blue-400 w-24 bg-gray-800"
                              style={{ position: 'sticky', top: 0, zIndex: 10 }}
                              onClick={() => handleSort('risk_level')}
                            >
                              <div className="flex items-center justify-center gap-1">
                                Overall Risk
                                {sortField === 'risk_level' && (
                                  sortDirection === 'asc' ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />
                                )}
                                <Tooltip delayDuration={300}>
                                  <TooltipTrigger asChild>
                                    <button type="button" className="inline-flex items-center">
                                      <Info className="h-4 w-4 text-gray-400 hover:text-blue-400 transition-colors cursor-help" />
                                    </button>
                                  </TooltipTrigger>
                                  <TooltipContent side="top" className="bg-gray-900 border-gray-600 text-white max-w-xs p-3 shadow-xl z-50">
                                    <p className="font-semibold mb-2 text-blue-400">Overall Risk Assessment</p>
                                    <p className="text-sm text-gray-300 mb-2">Comprehensive risk evaluation based on multiple factors:</p>
                                    <ul className="text-sm text-gray-300 space-y-1">
                                      <li>• Export control restrictions</li>
                                      <li>• Sanctions and embargoes</li>
                                      <li>• Proliferation concerns</li>
                                      <li>• Human rights considerations</li>
                                    </ul>
                                    <p className="text-xs text-blue-400 mt-2 flex items-center gap-1">
                                      🟢 High confidence • Updated daily
                                    </p>
                                  </TooltipContent>
                                </Tooltip>
                              </div>
                            </th>
                            <th 
                              className="px-6 py-3 text-white text-center cursor-pointer hover:text-blue-400 w-24 bg-gray-800"
                              style={{ position: 'sticky', top: 0, zIndex: 10 }}
                              onClick={() => handleSort('export_control_risk')}
                            >
                              <div className="flex items-center justify-center gap-1">
                                Export Control
                                {sortField === 'export_control_risk' && (
                                  sortDirection === 'asc' ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />
                                )}
                                <Tooltip delayDuration={300}>
                                  <TooltipTrigger asChild>
                                    <button type="button" className="inline-flex items-center">
                                      <Info className="h-4 w-4 text-gray-400 hover:text-blue-400 transition-colors cursor-help" />
                                    </button>
                                  </TooltipTrigger>
                                  <TooltipContent side="top" className="bg-gray-900 border-gray-600 text-white max-w-xs p-3 shadow-xl z-50">
                                    <p className="font-semibold mb-2 text-blue-400">Export Control Risk</p>
                                    <p className="text-sm text-gray-300 mb-2">Assessment based on:</p>
                                    <ul className="text-sm text-gray-300 space-y-1">
                                      <li>• EAR Country Groups</li>
                                      <li>• ITAR restrictions</li>
                                      <li>• Wassenaar Arrangement</li>
                                      <li>• EU Dual-Use Regulation</li>
                                    </ul>
                                    <p className="text-xs text-blue-400 mt-2">🟢 High confidence • Updated daily</p>
                                  </TooltipContent>
                                </Tooltip>
                              </div>
                            </th>
                            <th 
                              className="px-6 py-3 text-white text-center cursor-pointer hover:text-blue-400 w-24 bg-gray-800"
                              style={{ position: 'sticky', top: 0, zIndex: 10 }}
                              onClick={() => handleSort('sanctions_risk')}
                            >
                              <div className="flex items-center justify-center gap-1">
                                Sanctions
                                {sortField === 'sanctions_risk' && (
                                  sortDirection === 'asc' ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />
                                )}
                                <Tooltip delayDuration={300}>
                                  <TooltipTrigger asChild>
                                    <button type="button" className="inline-flex items-center">
                                      <Info className="h-4 w-4 text-gray-400 hover:text-blue-400 transition-colors cursor-help" />
                                    </button>
                                  </TooltipTrigger>
                                  <TooltipContent side="top" className="bg-gray-900 border-gray-600 text-white max-w-xs p-3 shadow-xl z-50">
                                    <p className="font-semibold mb-2 text-blue-400">Sanctions Assessment</p>
                                    <p className="text-sm text-gray-300 mb-2">Current sanctions status from:</p>
                                    <ul className="text-sm text-gray-300 space-y-1">
                                      <li>• UN Security Council</li>
                                      <li>• US OFAC sanctions</li>
                                      <li>• EU restrictive measures</li>
                                      <li>• UK HMT sanctions</li>
                                    </ul>
                                    <p className="text-xs text-blue-400 mt-2">🟢 High confidence • Updated daily</p>
                                  </TooltipContent>
                                </Tooltip>
                              </div>
                            </th>
                            <th 
                              className="px-6 py-3 text-white text-center cursor-pointer hover:text-blue-400 w-24 bg-gray-800"
                              style={{ position: 'sticky', top: 0, zIndex: 10 }}
                              onClick={() => handleSort('arms_risk')}
                            >
                              <div className="flex items-center justify-center gap-1">
                                Arms Risk
                                {sortField === 'arms_risk' && (
                                  sortDirection === 'asc' ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />
                                )}
                                <Tooltip delayDuration={300}>
                                  <TooltipTrigger asChild>
                                    <button type="button" className="inline-flex items-center">
                                      <Info className="h-4 w-4 text-gray-400 hover:text-blue-400 transition-colors cursor-help" />
                                    </button>
                                  </TooltipTrigger>
                                  <TooltipContent side="top" className="bg-gray-900 border-gray-600 text-white max-w-xs p-3 shadow-xl z-50">
                                    <p className="font-semibold mb-2 text-blue-400">Arms Trade Risk</p>
                                    <p className="text-sm text-gray-300 mb-2">Military and defense-related restrictions:</p>
                                    <ul className="text-sm text-gray-300 space-y-1">
                                      <li>• Arms Trade Treaty compliance</li>
                                      <li>• Regional Arms Control Agreements</li>
                                      <li>• SIPRI Arms Trade Database</li>
                                      <li>• Military equipment embargoes</li>
                                    </ul>
                                    <p className="text-xs text-blue-400 mt-2">🟢 High confidence • Updated monthly</p>
                                  </TooltipContent>
                                </Tooltip>
                              </div>
                            </th>
                            <th 
                              className="px-6 py-3 text-white text-center cursor-pointer hover:text-blue-400 w-24 bg-gray-800"
                              style={{ position: 'sticky', top: 0, zIndex: 10 }}
                              onClick={() => handleSort('nuclear_risk')}
                            >
                              <div className="flex items-center justify-center gap-1">
                                Nuclear
                                {sortField === 'nuclear_risk' && (
                                  sortDirection === 'asc' ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />
                                )}
                                <Tooltip delayDuration={300}>
                                  <TooltipTrigger asChild>
                                    <button type="button" className="inline-flex items-center">
                                      <Info className="h-4 w-4 text-gray-400 hover:text-blue-400 transition-colors cursor-help" />
                                    </button>
                                  </TooltipTrigger>
                                  <TooltipContent side="top" className="bg-gray-900 border-gray-600 text-white max-w-xs p-3 shadow-xl z-50">
                                    <p className="font-semibold mb-2 text-blue-400">Nuclear Risk Assessment</p>
                                    <p className="text-sm text-gray-300 mb-2">Nuclear proliferation concerns:</p>
                                    <ul className="text-sm text-gray-300 space-y-1">
                                      <li>• NPT compliance status</li>
                                      <li>• Nuclear Suppliers Group</li>
                                      <li>• IAEA safeguards</li>
                                      <li>• Nuclear technology controls</li>
                                    </ul>
                                    <p className="text-xs text-blue-400 mt-2">🟢 High confidence • Updated quarterly</p>
                                  </TooltipContent>
                                </Tooltip>
                              </div>
                            </th>
                            <th 
                              className="px-6 py-3 text-white text-center cursor-pointer hover:text-blue-400 w-24 bg-gray-800"
                              style={{ position: 'sticky', top: 0, zIndex: 10 }}
                              onClick={() => handleSort('chemical_risk')}
                            >
                              <div className="flex items-center justify-center gap-1">
                                Chemical
                                {sortField === 'chemical_risk' && (
                                  sortDirection === 'asc' ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />
                                )}
                                <Tooltip delayDuration={300}>
                                  <TooltipTrigger asChild>
                                    <button type="button" className="inline-flex items-center">
                                      <Info className="h-4 w-4 text-gray-400 hover:text-blue-400 transition-colors cursor-help" />
                                    </button>
                                  </TooltipTrigger>
                                  <TooltipContent side="top" className="bg-gray-900 border-gray-600 text-white max-w-xs p-3 shadow-xl z-50">
                                    <p className="font-semibold mb-2 text-blue-400">Chemical Risk Assessment</p>
                                    <p className="text-sm text-gray-300 mb-2">Chemical weapons concerns:</p>
                                    <ul className="text-sm text-gray-300 space-y-1">
                                      <li>• CWC compliance status</li>
                                      <li>• OPCW inspections</li>
                                      <li>• Chemical trade controls</li>
                                      <li>• Dual-use chemical monitoring</li>
                                    </ul>
                                    <p className="text-xs text-blue-400 mt-2">🟢 High confidence • Updated quarterly</p>
                                  </TooltipContent>
                                </Tooltip>
                              </div>
                            </th>
                            <th 
                              className="px-6 py-3 text-white text-center cursor-pointer hover:text-blue-400 w-24 bg-gray-800"
                              style={{ position: 'sticky', top: 0, zIndex: 10 }}
                              onClick={() => handleSort('biological_risks')}
                            >
                              <div className="flex items-center justify-center gap-1">
                                Biological
                                {sortField === 'biological_risks' && (
                                  sortDirection === 'asc' ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />
                                )}
                                <Tooltip delayDuration={300}>
                                  <TooltipTrigger asChild>
                                    <button type="button" className="inline-flex items-center">
                                      <Info className="h-4 w-4 text-gray-400 hover:text-blue-400 transition-colors cursor-help" />
                                    </button>
                                  </TooltipTrigger>
                                  <TooltipContent side="top" className="bg-gray-900 border-gray-600 text-white max-w-xs p-3 shadow-xl z-50">
                                    <p className="font-semibold mb-2 text-blue-400">Biological Risk Assessment</p>
                                    <p className="text-sm text-gray-300 mb-2">Biological weapons concerns:</p>
                                    <ul className="text-sm text-gray-300 space-y-1">
                                      <li>• BWC compliance status</li>
                                      <li>• Dual-use research oversight</li>
                                      <li>• Biosafety frameworks</li>
                                      <li>• Pathogen export controls</li>
                                    </ul>
                                    <p className="text-xs text-blue-400 mt-2">🟢 High confidence • Updated quarterly</p>
                                  </TooltipContent>
                                </Tooltip>
                              </div>
                            </th>
                            <th 
                              className="px-6 py-3 text-white text-center cursor-pointer hover:text-blue-400 w-24 bg-gray-800"
                              style={{ position: 'sticky', top: 0, zIndex: 10 }}
                              onClick={() => handleSort('human_rights_freedoms_risk')}
                            >
                              <div className="flex items-center justify-center gap-1">
                                Human Rights
                                {sortField === 'human_rights_freedoms_risk' && (
                                  sortDirection === 'asc' ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />
                                )}
                                <Tooltip delayDuration={300}>
                                  <TooltipTrigger asChild>
                                    <button type="button" className="inline-flex items-center">
                                      <Info className="h-4 w-4 text-gray-400 hover:text-blue-400 transition-colors cursor-help" />
                                    </button>
                                  </TooltipTrigger>
                                  <TooltipContent side="top" className="bg-gray-900 border-gray-600 text-white max-w-xs p-3 shadow-xl z-50">
                                    <p className="font-semibold mb-2 text-blue-400">Human Rights Risk</p>
                                    <p className="text-sm text-gray-300 mb-2">Assessment of freedom and rights:</p>
                                    <ul className="text-sm text-gray-300 space-y-1">
                                      <li>• Freedom House ratings</li>
                                      <li>• Political rights scores</li>
                                      <li>• Civil liberties status</li>
                                      <li>• Human rights violations</li>
                                    </ul>
                                    <p className="text-xs text-blue-400 mt-2">🟢 High confidence • Updated annually</p>
                                  </TooltipContent>
                                </Tooltip>
                              </div>
                            </th>
                            <th 
                              className="px-6 py-3 text-white text-center w-20 bg-gray-800"
                              style={{ position: 'sticky', top: 0, zIndex: 10 }}
                            >
                              Actions
                            </th>
                          </tr>
                        </thead>
                        <tbody>
                          {filteredCountries.map((country) => (
                            <tr key={country.id} className="border-b border-gray-700 hover:bg-gray-800/50">
                              <td className="px-6 py-4 text-gray-200 min-w-[12rem]">
                                <div className="flex items-center gap-2">
                                  {country.country_name || country.name}
                                  {isTerritory(country.country_name || country.name || '') && (
                                    <div className="flex items-center gap-1 text-xs text-blue-400">
                                      <MapPin className="h-3 w-3" />
                                      <span>Territory</span>
                                    </div>
                                  )}
                                </div>
                              </td>
                              <td className="px-6 py-4 text-center w-16">
                                <span className="text-xs text-gray-300 font-mono">
                                  {country.iso_code || 'N/A'}
                                </span>
                              </td>
                              <td className="px-6 py-4 text-center w-24">
                                <span className={`inline-flex items-center px-3 py-1.5 rounded-full text-xs font-semibold border ${getRiskLevelColor(country.risk_level || '')} ${getRiskLevelTextColor(country.risk_level || '')}`}>
                                  {formatRiskLevel(country.risk_level)}
                                </span>
                              </td>
                              <td className="px-6 py-4 text-center w-24">
                                <span className={`inline-flex items-center px-3 py-1.5 rounded-full text-xs font-semibold border ${getRiskLevelColor(country.export_control_risk || '')} ${getRiskLevelTextColor(country.export_control_risk || '')}`}>
                                  {formatRiskLevel(country.export_control_risk)}
                                </span>
                              </td>
                              <td className="px-6 py-4 text-center w-24">
                                <span className={`inline-flex items-center px-3 py-1.5 rounded-full text-xs font-semibold border ${getRiskLevelColor(country.sanctions_risk || '')} ${getRiskLevelTextColor(country.sanctions_risk || '')}`}>
                                  {formatRiskLevel(country.sanctions_risk)}
                                </span>
                              </td>
                              <td className="px-6 py-4 text-center w-24">
                                <span className={`inline-flex items-center px-3 py-1.5 rounded-full text-xs font-semibold border ${getRiskLevelColor(country.arms_risk || '')} ${getRiskLevelTextColor(country.arms_risk || '')}`}>
                                  {formatRiskLevel(country.arms_risk)}
                                </span>
                              </td>
                              <td className="px-6 py-4 text-center w-24">
                                <span className={`inline-flex items-center px-3 py-1.5 rounded-full text-xs font-semibold border ${getRiskLevelColor(country.nuclear_risk || '')} ${getRiskLevelTextColor(country.nuclear_risk || '')}`}>
                                  {formatRiskLevel(country.nuclear_risk)}
                                </span>
                              </td>
                              <td className="px-6 py-4 text-center w-24">
                                <span className={`inline-flex items-center px-3 py-1.5 rounded-full text-xs font-semibold border ${getRiskLevelColor(country.chemical_risk || '')} ${getRiskLevelTextColor(country.chemical_risk || '')}`}>
                                  {formatRiskLevel(country.chemical_risk)}
                                </span>
                              </td>
                              <td className="px-6 py-4 text-center w-24">
                                <span className={`inline-flex items-center px-3 py-1.5 rounded-full text-xs font-semibold border ${getRiskLevelColor(country.biological_risks || '')} ${getRiskLevelTextColor(country.biological_risks || '')}`}>
                                  {formatRiskLevel(country.biological_risks)}
                                </span>
                              </td>
                              <td className="px-6 py-4 text-center w-24">
                                <span className={`inline-flex items-center px-3 py-1.5 rounded-full text-xs font-semibold border ${getRiskLevelColor(country.human_rights_freedoms_risk || '')} ${getRiskLevelTextColor(country.human_rights_freedoms_risk || '')}`}>
                                  {formatRiskLevel(country.human_rights_freedoms_risk)}
                                </span>
                              </td>
                              <td className="px-6 py-4 text-center w-20">
                                <div className="flex items-center justify-center gap-2">
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    onClick={() => handleViewDetails(country)}
                                    className="text-blue-400 hover:text-blue-300 hover:bg-blue-900/20"
                                  >
                                    <Eye className="h-4 w-4" />
                                  </Button>
                                </div>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </TooltipProvider>
                  </div>
                </div>
              </Card>
            </>
          )}
        </TabsContent>

        {/* Catch-All Tab */}
        <TabsContent value="catch-all" className="space-y-6">
          <Card className="bg-gray-800 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white">Catch-All End-Use Checks</CardTitle>
              <CardDescription className="text-gray-400">
                Comprehensive end-use verification and monitoring system
              </CardDescription>
            </CardHeader>
            <CardContent className="p-6">
              <div className="text-center py-12">
                <Shield className="w-16 h-16 text-gray-500 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-white mb-2">Coming Soon</h3>
                <p className="text-gray-400 max-w-md mx-auto">
                  Advanced catch-all end-use verification system with automated monitoring, 
                  end-user verification, and compliance tracking capabilities.
                </p>
                <div className="mt-6 space-y-2">
                  <p className="text-sm text-gray-500">Features will include:</p>
                  <ul className="text-sm text-gray-400 space-y-1">
                    <li>• End-user verification workflows</li>
                    <li>• Automated compliance monitoring</li>
                    <li>• Risk-based screening protocols</li>
                    <li>• Integration with licensing systems</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Country Details Dialog */}
      <Dialog open={showCountryDetails} onOpenChange={setShowCountryDetails}>
        <DialogContent className="bg-gray-800 border-gray-700 max-w-7xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-white text-xl flex items-center gap-2">
              <Globe className="h-5 w-5 text-blue-400" />
              {selectedCountry?.country_name || selectedCountry?.name} - Comprehensive Risk Analysis
            </DialogTitle>
            <DialogDescription className="text-gray-300">
              Complete risk assessment, compliance information, and regulatory intelligence
            </DialogDescription>
            <div className="flex items-center gap-2 pt-2">
              <Button
                onClick={handleExportCountryPDF}
                disabled={isExportingPDF}
                className="bg-red-600 hover:bg-red-700 text-white flex items-center gap-2"
              >
                {isExportingPDF ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <Download className="h-4 w-4" />
                )}
                {isExportingPDF ? 'Generating PDF...' : 'Export PDF Report'}
              </Button>
            </div>
          </DialogHeader>
          
          {selectedCountry && (
            <Tabs defaultValue="overview" className="w-full">
              <TabsList className="grid w-full grid-cols-8 bg-gray-700">
                <TabsTrigger value="overview">Overview</TabsTrigger>
                <TabsTrigger value="export-controls">Export Controls</TabsTrigger>
                <TabsTrigger value="sanctions">Sanctions</TabsTrigger>
                <TabsTrigger value="arms-risks">Arms Risks</TabsTrigger>
                <TabsTrigger value="chemical-risk">Chemical Risk</TabsTrigger>
                <TabsTrigger value="biological-risks">Biological Risks</TabsTrigger>
                <TabsTrigger value="nuclear-risks">Nuclear Risks</TabsTrigger>
                <TabsTrigger value="human-rights">Human Rights & Freedom</TabsTrigger>
              </TabsList>

              {/* Overview Tab */}
              <TabsContent value="overview" className="space-y-6 mt-4">
                {/* Executive Summary */}
                <div className="bg-gray-900/50 p-4 rounded-lg border border-blue-500/20">
                  <h3 className="text-white font-semibold mb-3 flex items-center gap-2">
                    <BarChart3 className="h-4 w-4 text-blue-400" />
                    Executive Summary
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <div className="bg-gray-800 p-3 rounded-lg">
                      <Label className="text-gray-400 text-sm">Country</Label>
                      <p className="text-white font-medium">{selectedCountry.country_name || selectedCountry.name}</p>
                      {isTerritory(selectedCountry.country_name || selectedCountry.name || '') && (
                        <div className="flex items-center gap-1 text-xs text-blue-400 mt-1">
                          <MapPin className="h-3 w-3" />
                          <span>Territory</span>
                        </div>
                      )}
                    </div>
                    <div className="bg-gray-800 p-3 rounded-lg">
                      <Label className="text-gray-400 text-sm">ISO Code</Label>
                      <p className="text-white font-medium font-mono">{selectedCountry.iso_code || 'N/A'}</p>
                    </div>
                    <div className="bg-gray-800 p-3 rounded-lg">
                      <Label className="text-gray-400 text-sm">Overall Risk Level</Label>
                      <div className="mt-2">
                        <Badge className={`${getRiskLevelColor(selectedCountry.risk_level || '')} ${getRiskLevelTextColor(selectedCountry.risk_level || '')} border`}>
                          {formatRiskLevel(selectedCountry.risk_level)}
                        </Badge>
                      </div>
                    </div>
                    <div className="bg-gray-800 p-3 rounded-lg">
                      <Label className="text-gray-400 text-sm">Status</Label>
                      <p className="text-white text-sm mt-1">
                        {selectedCountry.is_active !== false ? (
                          <Badge className="bg-green-600 text-green-100">Active</Badge>
                        ) : (
                          <Badge className="bg-red-600 text-red-100">Inactive</Badge>
                        )}
                      </p>
                    </div>
                    <div className="bg-gray-800 p-3 rounded-lg">
                      <Label className="text-gray-400 text-sm">Last Assessed</Label>
                      <p className="text-white font-medium">{selectedCountry.last_assessed || 'N/A'}</p>
                    </div>
                  </div>
                </div>

                {/* Risk Assessment Summary */}
                <div className="bg-gray-900/50 p-4 rounded-lg border border-orange-500/20">
                  <h3 className="text-white font-semibold mb-3 flex items-center gap-2">
                    <Shield className="h-4 w-4 text-orange-400" />
                    Risk Assessment Summary
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <div className="bg-gray-800 p-3 rounded-lg">
                      <Label className="text-gray-400 text-sm">Export Control Risk</Label>
                      <div className="mt-2">
                        <Badge className={`${getRiskLevelColor(selectedCountry.export_control_risk || '')} ${getRiskLevelTextColor(selectedCountry.export_control_risk || '')} text-xs`}>
                          {formatRiskLevel(selectedCountry.export_control_risk)}
                        </Badge>
                      </div>
                    </div>
                    <div className="bg-gray-800 p-3 rounded-lg">
                      <Label className="text-gray-400 text-sm">Sanctions Risk</Label>
                      <div className="mt-2">
                        <Badge className={`${getRiskLevelColor(selectedCountry.sanctions_risk || '')} ${getRiskLevelTextColor(selectedCountry.sanctions_risk || '')} text-xs`}>
                          {formatRiskLevel(selectedCountry.sanctions_risk)}
                        </Badge>
                      </div>
                    </div>
                    <div className="bg-gray-800 p-3 rounded-lg">
                      <Label className="text-gray-400 text-sm">Arms Risk</Label>
                      <div className="mt-2">
                        <Badge className={`${getRiskLevelColor(selectedCountry.arms_risk || '')} ${getRiskLevelTextColor(selectedCountry.arms_risk || '')} text-xs`}>
                          {formatRiskLevel(selectedCountry.arms_risk)}
                        </Badge>
                      </div>
                    </div>
                    <div className="bg-gray-800 p-3 rounded-lg">
                      <Label className="text-gray-400 text-sm">Chemical Risk</Label>
                      <div className="mt-2">
                        <Badge className={`${getRiskLevelColor(selectedCountry.chemical_risk || '')} ${getRiskLevelTextColor(selectedCountry.chemical_risk || '')} text-xs`}>
                          {formatRiskLevel(selectedCountry.chemical_risk)}
                        </Badge>
                      </div>
                    </div>
                    <div className="bg-gray-800 p-3 rounded-lg">
                      <Label className="text-gray-400 text-sm">Biological Risk</Label>
                      <div className="mt-2">
                        <Badge className={`${getRiskLevelColor(selectedCountry.biological_risks || '')} ${getRiskLevelTextColor(selectedCountry.biological_risks || '')} text-xs`}>
                          {formatRiskLevel(selectedCountry.biological_risks)}
                        </Badge>
                      </div>
                    </div>
                    <div className="bg-gray-800 p-3 rounded-lg">
                      <Label className="text-gray-400 text-sm">Nuclear Risk</Label>
                      <div className="mt-2">
                        <Badge className={`${getRiskLevelColor(selectedCountry.nuclear_risk || '')} ${getRiskLevelTextColor(selectedCountry.nuclear_risk || '')} text-xs`}>
                          {formatRiskLevel(selectedCountry.nuclear_risk)}
                        </Badge>
                      </div>
                    </div>
                    <div className="bg-gray-800 p-3 rounded-lg">
                      <Label className="text-gray-400 text-sm">Human Rights & Freedoms Risk</Label>
                      <div className="mt-2">
                        <Badge className={`${getRiskLevelColor(selectedCountry.human_rights_freedoms_risk || '')} ${getRiskLevelTextColor(selectedCountry.human_rights_freedoms_risk || '')} text-xs`}>
                          {formatRiskLevel(selectedCountry.human_rights_freedoms_risk)}
                        </Badge>
                      </div>
                    </div>
                  </div>
                </div>
              </TabsContent>

              {/* Export Controls Tab */}
              <TabsContent value="export-controls" className="space-y-6 mt-4">
                <Card className="bg-gray-900/50 border-gray-700">
                  <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                      <Shield className="h-4 w-4 text-blue-400" />
                      Export Control Regimes
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <Label className="text-gray-400">Wassenaar Arrangement (WA)</Label>
                        <p className={`font-medium ${selectedCountry.wassenaar_arrangement ? 'text-green-400' : 'text-red-400'}`}>
                          {selectedCountry.wassenaar_arrangement ? '✓ Member' : '✗ Non-Member'}
                        </p>
                      </div>
                      <div>
                        <Label className="text-gray-400">Nuclear Suppliers Group (NSG)</Label>
                        <p className={`font-medium ${selectedCountry.nuclear_suppliers_group ? 'text-green-400' : 'text-red-400'}`}>
                          {selectedCountry.nuclear_suppliers_group ? '✓ Member' : '✗ Non-Member'}
                        </p>
                      </div>
                      <div>
                        <Label className="text-gray-400">Australia Group (AG)</Label>
                        <p className={`font-medium ${selectedCountry.australia_group ? 'text-green-400' : 'text-red-400'}`}>
                          {selectedCountry.australia_group ? '✓ Member' : '✗ Non-Member'}
                        </p>
                      </div>
                      <div>
                        <Label className="text-gray-400">MTCR</Label>
                        <p className={`font-medium ${selectedCountry.missile_technology_control_regime ? 'text-green-400' : 'text-red-400'}`}>
                          {selectedCountry.missile_technology_control_regime ? '✓ Member' : '✗ Non-Member'}
                        </p>
                      </div>
                      <div>
                        <Label className="text-gray-400">Zangger Committee (ZC)</Label>
                        <p className={`font-medium ${selectedCountry.zangger_committee ? 'text-green-400' : 'text-red-400'}`}>
                          {selectedCountry.zangger_committee ? '✓ Member' : '✗ Non-Member'}
                        </p>
                      </div>
                    </div>
                    {selectedCountry.export_control_notes && (
                      <div className="mt-4 p-3 bg-gray-800 rounded text-xs text-gray-300">
                        <strong>Notes:</strong> {selectedCountry.export_control_notes}
                      </div>
                    )}
                    <div className="mt-4">
                      <Label className="text-gray-400 text-sm">Export Control Risk Level</Label>
                      <div className="mt-2">
                        <Badge className={`${getRiskLevelColor(selectedCountry.export_control_risk || '')} ${getRiskLevelTextColor(selectedCountry.export_control_risk || '')} border`}>
                          {formatRiskLevel(selectedCountry.export_control_risk)}
                        </Badge>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Sanctions Tab */}
              <TabsContent value="sanctions" className="space-y-6 mt-4">
                <Card className="bg-gray-900/50 border-gray-700">
                  <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                      <AlertTriangle className="h-4 w-4 text-red-400" />
                      Sanctions Status
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="bg-gray-800 p-4 rounded-lg">
                      <Label className="text-gray-400 text-sm">Current Sanctions Status</Label>
                      <p className="text-white font-medium mt-1">{selectedCountry.sanctions_status || 'No Active Sanctions'}</p>
                    </div>
                    {selectedCountry.sanctions_notes && (
                      <div className="bg-gray-800 p-3 rounded text-xs text-gray-300">
                        <strong>Notes:</strong> {selectedCountry.sanctions_notes}
                      </div>
                    )}
                    <div>
                      <Label className="text-gray-400 text-sm">Sanctions Risk Level</Label>
                      <div className="mt-2">
                        <Badge className={`${getRiskLevelColor(selectedCountry.sanctions_risk || '')} ${getRiskLevelTextColor(selectedCountry.sanctions_risk || '')} border`}>
                          {formatRiskLevel(selectedCountry.sanctions_risk)}
                        </Badge>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Arms Risks Tab */}
              <TabsContent value="arms-risks" className="space-y-6 mt-4">
                <Card className="bg-gray-900/50 border-gray-700">
                  <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                      <Shield className="h-4 w-4 text-orange-400" />
                      Arms Embargo Status
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div className="bg-gray-800 p-3 rounded-lg">
                        <Label className="text-gray-400">UN Arms Embargo</Label>
                        <p className={`font-medium ${selectedCountry.un_arms_embargo ? 'text-red-400' : 'text-green-400'}`}>
                          {selectedCountry.un_arms_embargo ? '⚠️ Active' : '✓ No Embargo'}
                        </p>
                        {selectedCountry.un_arms_embargo_notes && (
                          <p className="text-xs text-gray-400 mt-1">{selectedCountry.un_arms_embargo_notes}</p>
                        )}
                      </div>
                      <div className="bg-gray-800 p-3 rounded-lg">
                        <Label className="text-gray-400">US Arms Embargo</Label>
                        <p className={`font-medium ${selectedCountry.us_arms_embargo ? 'text-red-400' : 'text-green-400'}`}>
                          {selectedCountry.us_arms_embargo ? '⚠️ Active' : '✓ No Embargo'}
                        </p>
                        {selectedCountry.us_arms_embargo_notes && (
                          <p className="text-xs text-gray-400 mt-1">{selectedCountry.us_arms_embargo_notes}</p>
                        )}
                      </div>
                      <div className="bg-gray-800 p-3 rounded-lg">
                        <Label className="text-gray-400">EU Arms Embargo</Label>
                        <p className={`font-medium ${selectedCountry.eu_arms_embargo ? 'text-red-400' : 'text-green-400'}`}>
                          {selectedCountry.eu_arms_embargo ? '⚠️ Active' : '✓ No Embargo'}
                        </p>
                        {selectedCountry.eu_arms_embargo_notes && (
                          <p className="text-xs text-gray-400 mt-1">{selectedCountry.eu_arms_embargo_notes}</p>
                        )}
                      </div>
                      <div className="bg-gray-800 p-3 rounded-lg">
                        <Label className="text-gray-400">Other Arms Embargo</Label>
                        <p className={`font-medium ${selectedCountry.other_arms_embargo ? 'text-red-400' : 'text-green-400'}`}>
                          {selectedCountry.other_arms_embargo ? '⚠️ Active' : '✓ No Embargo'}
                        </p>
                        {selectedCountry.other_arms_embargo_notes && (
                          <p className="text-xs text-gray-400 mt-1">{selectedCountry.other_arms_embargo_notes}</p>
                        )}
                      </div>
                    </div>
                    <div className="mt-4">
                      <Label className="text-gray-400 text-sm">Arms Risk Level</Label>
                      <div className="mt-2">
                        <Badge className={`${getRiskLevelColor(selectedCountry.arms_risk || '')} ${getRiskLevelTextColor(selectedCountry.arms_risk || '')} border`}>
                          {formatRiskLevel(selectedCountry.arms_risk)}
                        </Badge>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Chemical Risk Tab */}
              <TabsContent value="chemical-risk" className="space-y-6 mt-4">
                <Card className="bg-gray-900/50 border-gray-700">
                  <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                      <Beaker className="h-4 w-4 text-yellow-400" />
                      Chemical Weapons Convention (CWC)
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <Label className="text-gray-400">CWC Signatory</Label>
                        <p className={`font-medium ${selectedCountry.cwc_1993_signatory ? 'text-green-400' : 'text-red-400'}`}>
                          {selectedCountry.cwc_1993_signatory ? '✓ Yes' : '✗ No'}
                        </p>
                      </div>
                      <div>
                        <Label className="text-gray-400">CWC Ratified</Label>
                        <p className={`font-medium ${selectedCountry.cwc_1993_ratified ? 'text-green-400' : 'text-red-400'}`}>
                          {selectedCountry.cwc_1993_ratified ? '✓ Yes' : '✗ No'}
                        </p>
                      </div>
                      <div>
                        <Label className="text-gray-400">Violations</Label>
                        <p className={`font-medium ${selectedCountry.cwc_violations ? 'text-red-400' : 'text-green-400'}`}>
                          {selectedCountry.cwc_violations ? '⚠️ Reported' : '✓ None'}
                        </p>
                      </div>
                    </div>
                    <div className="mt-4">
                      <Label className="text-gray-400 text-sm">Chemical Risk Level</Label>
                      <div className="mt-2">
                        <Badge className={`${getRiskLevelColor(selectedCountry.chemical_risk || '')} ${getRiskLevelTextColor(selectedCountry.chemical_risk || '')} border`}>
                          {formatRiskLevel(selectedCountry.chemical_risk)}
                        </Badge>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Biological Risks Tab */}
              <TabsContent value="biological-risks" className="space-y-6 mt-4">
                <Card className="bg-gray-900/50 border-gray-700">
                  <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                      <Microscope className="h-4 w-4 text-purple-400" />
                      Biological Weapons Convention (BWC)
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <Label className="text-gray-400">BWC Signatory</Label>
                        <p className={`font-medium ${selectedCountry.bwc_1972_signatory ? 'text-green-400' : 'text-red-400'}`}>
                          {selectedCountry.bwc_1972_signatory ? '✓ Yes' : '✗ No'}
                        </p>
                      </div>
                      <div>
                        <Label className="text-gray-400">BWC Ratified</Label>
                        <p className={`font-medium ${selectedCountry.bwc_1972_ratified ? 'text-green-400' : 'text-red-400'}`}>
                          {selectedCountry.bwc_1972_ratified ? '✓ Yes' : '✗ No'}
                        </p>
                      </div>
                      <div>
                        <Label className="text-gray-400">Violations</Label>
                        <p className={`font-medium ${selectedCountry.bwc_violations ? 'text-red-400' : 'text-green-400'}`}>
                          {selectedCountry.bwc_violations ? '⚠️ Reported' : '✓ None'}
                        </p>
                      </div>
                    </div>
                    <div className="mt-4">
                      <Label className="text-gray-400 text-sm">Biological Risk Level</Label>
                      <div className="mt-2">
                        <Badge className={`${getRiskLevelColor(selectedCountry.biological_risks || '')} ${getRiskLevelTextColor(selectedCountry.biological_risks || '')} border`}>
                          {formatRiskLevel(selectedCountry.biological_risks)}
                        </Badge>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Nuclear Risks Tab */}
              <TabsContent value="nuclear-risks" className="space-y-6 mt-4">
                <Card className="bg-gray-900/50 border-gray-700">
                  <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                      <Zap className="h-4 w-4 text-yellow-400" />
                      Nuclear Treaties & Agreements
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <Label className="text-gray-400">NPT Signatory</Label>
                        <p className={`font-medium ${selectedCountry.npt_signatory ? 'text-green-400' : 'text-red-400'}`}>
                          {selectedCountry.npt_signatory ? '✓ Yes' : '✗ No'}
                        </p>
                      </div>
                      <div>
                        <Label className="text-gray-400">NPT Ratified</Label>
                        <p className={`font-medium ${selectedCountry.npt_ratified ? 'text-green-400' : 'text-red-400'}`}>
                          {selectedCountry.npt_ratified ? '✓ Yes' : '✗ No'}
                        </p>
                      </div>
                      <div>
                        <Label className="text-gray-400">CTBT Signatory</Label>
                        <p className={`font-medium ${selectedCountry.ctbt_signatory ? 'text-green-400' : 'text-red-400'}`}>
                          {selectedCountry.ctbt_signatory ? '✓ Yes' : '✗ No'}
                        </p>
                      </div>
                      <div>
                        <Label className="text-gray-400">CTBT Ratified</Label>
                        <p className={`font-medium ${selectedCountry.ctbt_ratified ? 'text-green-400' : 'text-red-400'}`}>
                          {selectedCountry.ctbt_ratified ? '✓ Yes' : '✗ No'}
                        </p>
                      </div>
                      <div>
                        <Label className="text-gray-400">IAEA Signatory</Label>
                        <p className={`font-medium ${selectedCountry.iaea_signatory ? 'text-green-400' : 'text-red-400'}`}>
                          {selectedCountry.iaea_signatory ? '✓ Yes' : '✗ No'}
                        </p>
                      </div>
                      <div>
                        <Label className="text-gray-400">IAEA Ratified</Label>
                        <p className={`font-medium ${selectedCountry.iaea_ratified ? 'text-green-400' : 'text-red-400'}`}>
                          {selectedCountry.iaea_ratified ? '✓ Yes' : '✗ No'}
                        </p>
                      </div>
                      <div>
                        <Label className="text-gray-400">NSG Member</Label>
                        <p className={`font-medium ${selectedCountry.nsg_1974_signatory ? 'text-green-400' : 'text-red-400'}`}>
                          {selectedCountry.nsg_1974_signatory ? '✓ Yes' : '✗ No'}
                        </p>
                      </div>
                      <div>
                        <Label className="text-gray-400">Convention 1980</Label>
                        <p className={`font-medium ${selectedCountry.convention_1980_signatory ? 'text-green-400' : 'text-red-400'}`}>
                          {selectedCountry.convention_1980_signatory ? '✓ Signatory' : '✗ Non-Signatory'}
                        </p>
                      </div>
                      <div>
                        <Label className="text-gray-400">Convention 1994</Label>
                        <p className={`font-medium ${selectedCountry.convention_1994_signatory ? 'text-green-400' : 'text-red-400'}`}>
                          {selectedCountry.convention_1994_signatory ? '✓ Signatory' : '✗ Non-Signatory'}
                        </p>
                      </div>
                      <div>
                        <Label className="text-gray-400">Violations</Label>
                        <p className={`font-medium ${selectedCountry.nuclear_violations ? 'text-red-400' : 'text-green-400'}`}>
                          {selectedCountry.nuclear_violations ? '⚠️ Reported' : '✓ None'}
                        </p>
                      </div>
                    </div>
                    <div className="mt-4">
                      <Label className="text-gray-400 text-sm">Nuclear Risk Level</Label>
                      <div className="mt-2">
                        <Badge className={`${getRiskLevelColor(selectedCountry.nuclear_risk || '')} ${getRiskLevelTextColor(selectedCountry.nuclear_risk || '')} border`}>
                          {formatRiskLevel(selectedCountry.nuclear_risk)}
                        </Badge>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Human Rights & Freedom Tab */}
              <TabsContent value="human-rights" className="space-y-6 mt-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <Card className="bg-gray-900/50 border-gray-700">
                    <CardHeader>
                      <CardTitle className="text-white flex items-center gap-2">
                        <Users className="h-4 w-4 text-green-400" />
                        Human Rights
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div>
                        <Label className="text-gray-400 text-sm">Human Rights Score</Label>
                        <div className="flex items-center gap-2 mt-1">
                          <span className="text-white font-bold text-lg">{selectedCountry.human_rights_score}/100</span>
                          <div className="flex-1 bg-gray-700 rounded-full h-2">
                            <div 
                              className={`h-2 rounded-full ${
                                selectedCountry.human_rights_score >= 70 ? 'bg-green-500' :
                                selectedCountry.human_rights_score >= 40 ? 'bg-yellow-500' : 'bg-red-500'
                              }`}
                              style={{ width: `${selectedCountry.human_rights_score}%` }}
                            ></div>
                          </div>
                        </div>
                      </div>
                      {selectedCountry.human_rights_notes && (
                        <div className="bg-gray-800 p-3 rounded text-xs text-gray-300">
                          <strong>Notes:</strong> {selectedCountry.human_rights_notes}
                        </div>
                      )}
                      <div>
                        <Label className="text-gray-400 text-sm">Human Rights Risk</Label>
                        <div className="mt-2">
                          <Badge className={`${getRiskLevelColor(selectedCountry.human_rights_risk || '')} ${getRiskLevelTextColor(selectedCountry.human_rights_risk || '')} border`}>
                            {formatRiskLevel(selectedCountry.human_rights_risk)}
                          </Badge>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card className="bg-gray-900/50 border-gray-700">
                    <CardHeader>
                      <CardTitle className="text-white flex items-center gap-2">
                        <Shield className="h-4 w-4 text-blue-400" />
                        Freedom Metrics
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div>
                          <Label className="text-gray-400">Political Rights</Label>
                          <p className="text-white font-medium">{selectedCountry.political_rights_score}/100</p>
                        </div>
                        <div>
                          <Label className="text-gray-400">Civil Liberties</Label>
                          <p className="text-white font-medium">{selectedCountry.civil_liberties_score}/100</p>
                        </div>
                        <div>
                          <Label className="text-gray-400">Freedom Status</Label>
                          <p className="text-white font-medium">{selectedCountry.freedom_in_the_world || 'N/A'}</p>
                        </div>
                        <div>
                          <Label className="text-gray-400">Democracy Status</Label>
                          <p className="text-white font-medium">{selectedCountry.democracy_status || 'N/A'}</p>
                        </div>
                      </div>
                      {selectedCountry.freedom_note && (
                        <div className="bg-gray-800 p-3 rounded text-xs text-gray-300">
                          <strong>Freedom Note:</strong> {selectedCountry.freedom_note}
                        </div>
                      )}
                      <div>
                        <Label className="text-gray-400 text-sm">Freedom Risk Level</Label>
                        <div className="mt-2">
                          <Badge className={`${getRiskLevelColor(selectedCountry.freedom_risk || '')} ${getRiskLevelTextColor(selectedCountry.freedom_risk || '')} border`}>
                            {formatRiskLevel(selectedCountry.freedom_risk)}
                          </Badge>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>
            </Tabs>
          )}
        </DialogContent>
      </Dialog>

      {/* Sources Dialog */}
      <Dialog open={showSourcesDialog} onOpenChange={setShowSourcesDialog}>
        <DialogContent className="bg-gray-800 border-gray-700 max-w-4xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-white">
              {dataSourcesContent?.title || 'Data Sources & Methodology'}
            </DialogTitle>
            <DialogDescription className="text-gray-300">
              Comprehensive documentation of sources and methodologies used in our risk assessment
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-6">
            {!dynamicContentLoading && dataSourcesContent ? (
              <div className="prose prose-invert max-w-none">
                {dataSourcesContent.content?.text && (
                  <div dangerouslySetInnerHTML={{ __html: dataSourcesContent.content.text }} />
                )}
                {dataSourcesContent.content?.sections && (
                  <div className="space-y-4">
                    {dataSourcesContent.content.sections.map((section: any, index: number) => (
                      <div key={index} className="bg-gray-700/50 p-4 rounded-lg">
                        {section.title && <h4 className="text-white font-semibold mb-2">{section.title}</h4>}
                        {section.content && <div className="text-gray-300">{section.content}</div>}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            ) : dynamicContentLoading ? (
              <div className="flex items-center justify-center py-8">
                <div className="animate-spin rounded-full h-8 w-8 border-b border-blue-600"></div>
                <span className="ml-2 text-gray-400">Loading content...</span>
              </div>
            ) : (
              // Fallback content when no dynamic content is available
              <div className="space-y-6">
                <div className="bg-gray-700/50 p-4 rounded-lg">
                  <h4 className="text-white font-semibold mb-3 flex items-center gap-2">
                    <Shield className="h-5 w-5 text-blue-400" />
                    Export Control Sources
                  </h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-gray-300">
                    <div>
                      <strong>U.S. Bureau of Industry and Security (BIS)</strong>
                      <ul className="list-disc list-inside mt-1 space-y-1">
                        <li>Export Administration Regulations (EAR)</li>
                        <li>Commerce Control List (CCL)</li>
                        <li>Entity List</li>
                        <li>Denied Persons List</li>
                      </ul>
                    </div>
                    <div>
                      <strong>European Union</strong>
                      <ul className="list-disc list-inside mt-1 space-y-1">
                        <li>EU Dual-Use Regulation 2021/821</li>
                        <li>Common Military List</li>
                        <li>Consolidated List of Sanctions</li>
                      </ul>
                    </div>
                  </div>
                </div>

                <div className="bg-gray-700/50 p-4 rounded-lg">
                  <h4 className="text-white font-semibold mb-3 flex items-center gap-2">
                    <AlertTriangle className="h-5 w-5 text-red-400" />
                    Sanctions Sources
                  </h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-gray-300">
                    <div>
                      <strong>U.S. Office of Foreign Assets Control (OFAC)</strong>
                      <ul className="list-disc list-inside mt-1 space-y-1">
                        <li>Specially Designated Nationals (SDN) List</li>
                        <li>Sectoral Sanctions Identifications List</li>
                        <li>Foreign Sanctions Evaders List</li>
                        <li>Non-SDN Menu-Based Sanctions List</li>
                      </ul>
                    </div>
                    <div>
                      <strong>International Sanctions</strong>
                      <ul className="list-disc list-inside mt-1 space-y-1">
                        <li>UN Security Council Sanctions</li>
                        <li>EU Consolidated Sanctions List</li>
                        <li>UK HM Treasury Financial Sanctions</li>
                        <li>Canadian Special Economic Measures</li>
                      </ul>
                    </div>
                  </div>
                </div>

                <div className="bg-gray-700/50 p-4 rounded-lg">
                  <h4 className="text-white font-semibold mb-3 flex items-center gap-2">
                    <Globe className="h-5 w-5 text-yellow-400" />
                    Arms Control & Human Rights
                  </h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-gray-300">
                    <div>
                      <strong>Arms Control Sources</strong>
                      <ul className="list-disc list-inside mt-1 space-y-1">
                        <li>UN Arms Embargoes Database</li>
                        <li>SIPRI Arms Transfer Database</li>
                        <li>Wassenaar Arrangement Guidelines</li>
                        <li>Australia Group Control Lists</li>
                      </ul>
                    </div>
                    <div>
                      <strong>Human Rights Assessment</strong>
                      <ul className="list-disc list-inside mt-1 space-y-1">
                        <li>Freedom House Country Reports</li>
                        <li>UN Human Rights Council Reports</li>
                        <li>U.S. State Department Human Rights Reports</li>
                        <li>Transparency International Indices</li>
                      </ul>
                    </div>
                  </div>
                </div>

                <div className="bg-gray-700/50 p-4 rounded-lg">
                  <h4 className="text-white font-semibold mb-3 flex items-center gap-2">
                    <BarChart3 className="h-5 w-5 text-purple-400" />
                    Risk Assessment Methodology
                  </h4>
                  <div className="text-sm text-gray-300 space-y-2">
                    <p>
                      Our risk assessment methodology combines quantitative and qualitative analysis across multiple dimensions:
                    </p>
                    <ul className="list-disc list-inside space-y-1">
                      <li><strong>Export Control Risk:</strong> Regulatory complexity, licensing requirements, and enforcement history</li>
                      <li><strong>Sanctions Risk:</strong> Current sanctions regimes, historical violations, and compliance challenges</li>
                      <li><strong>Arms Control Risk:</strong> Military end-use concerns, dual-use technology risks, and proliferation concerns</li>
                      <li><strong>Human Rights Risk:</strong> Political freedom scores, civil liberties indices, and governance quality</li>
                    </ul>
                    <p className="mt-3">
                      <strong>Data Updates:</strong> All sources are monitored daily with formal updates processed monthly. 
                      Critical changes are reflected immediately for high-priority jurisdictions.
                    </p>
                  </div>
                </div>

                <div className="bg-blue-900/20 border border-blue-700/50 p-4 rounded-lg">
                  <div className="flex items-start gap-3">
                    <Info className="h-5 w-5 text-blue-400 mt-0.5" />
                    <div className="text-sm text-blue-200">
                      <strong>Disclaimer:</strong> This information is provided for general guidance only and should not replace 
                      professional legal advice. Always consult with qualified export control counsel for specific compliance decisions.
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* Credit Confirmation Dialog */}
      <Dialog open={showCreditDialog} onOpenChange={setShowCreditDialog}>
        <DialogContent className="bg-gray-800 border-gray-700 max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-white">
              Confirm Export
            </DialogTitle>
            <DialogDescription>
              You are about to export critical countries data. Please confirm your action.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-6">
            <div className="bg-gray-700 p-4 rounded-lg">
              <Label className="text-gray-300">Total Countries</Label>
              <p className="text-white font-medium">{filteredCountries.length}</p>
            </div>
            <div className="bg-gray-700 p-4 rounded-lg">
              <Label className="text-gray-300">Export Data</Label>
              <p className="text-gray-200 mt-2">This action will export critical countries data.</p>
            </div>
          </div>
          
          <div className="flex justify-end pt-4 border-t border-gray-700">
            <Button 
              onClick={handleCreditConfirm}
              className="bg-blue-600 hover:bg-blue-700 text-white"
            >
              Confirm
            </Button>
            <Button 
              onClick={handleCreditCancel}
              className="bg-blue-600 hover:bg-blue-700 text-white"
            >
              Cancel
            </Button>
          </div>
        </DialogContent>
      </Dialog>
      
      {/* Credit Confirmation Dialog */}
      <CreditConfirmationDialog
        open={showCreditDialog}
        onClose={handleCreditCancel}
        onConfirm={handleCreditConfirm}
        componentName="end_use_checks"
        actionName="export_critical_countries"
        resourceId={null}
        description={`Export critical countries data (${filteredCountries.length} countries)`}
      />
      
      {/* Export Options Dialog */}
      <Dialog open={showExportOptions} onOpenChange={setShowExportOptions}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Export Critical Countries</DialogTitle>
            <DialogDescription>
              Choose your export format and options
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium">Export Format</label>
              <Select value={exportFormat} onValueChange={(value: 'csv' | 'pdf') => setExportFormat(value)}>
                <SelectTrigger className="w-full mt-1">
                  <SelectValue placeholder="Select format" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="csv">CSV (Spreadsheet)</SelectItem>
                  <SelectItem value="pdf">PDF (Document)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            {exportFormat === 'pdf' && (
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="detailed-data" 
                  checked={includeDetailedData}
                  onCheckedChange={setIncludeDetailedData}
                />
                <label htmlFor="detailed-data" className="text-sm">
                  Include detailed country information
                </label>
              </div>
            )}
            
            {exportCreditInfo && !exportCreditInfo.is_free && (
              <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3">
                <div className="flex items-center space-x-2">
                  <AlertCircle className="w-4 h-4 text-yellow-600" />
                  <span className="text-sm text-yellow-800">
                    This export costs {exportCreditInfo.credit_cost} credit(s)
                  </span>
                </div>
                <p className="text-xs text-yellow-700 mt-1">
                  Your balance: {exportCreditInfo.user_balance} credits
                </p>
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowExportOptions(false)}>
              Cancel
            </Button>
            <Button 
              onClick={handleExportWithCredits}
              disabled={isExporting || (exportCreditInfo && !exportCreditInfo.is_free && exportCreditInfo.user_balance < exportCreditInfo.credit_cost)}
            >
              {isExporting ? 'Exporting...' : 'Export'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Credit Dialog for Unlock Confirmation */}
      <CreditDialog 
        open={creditDialogOpen}
        onOpenChange={setCreditDialogOpen}
        onConfirm={handleUnlockView}
      />
    </div>
  );
}

export default EndUseChecks;
