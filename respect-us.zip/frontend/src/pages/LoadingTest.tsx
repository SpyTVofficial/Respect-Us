import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

const LoadingTest = () => {
  return (
    <div className="p-6">
      <Card>
        <CardHeader>
          <CardTitle>App Loading Test</CardTitle>
        </CardHeader>
        <CardContent>
          <p>If you can see this page, the app is loading correctly.</p>
          <p className="text-green-600 font-semibold">✅ React Router is working</p>
          <p className="text-green-600 font-semibold">✅ Shadcn components are loading</p>
          <p className="text-green-600 font-semibold">✅ Tailwind CSS is working</p>
        </CardContent>
      </Card>
    </div>
  );
};

export default LoadingTest;
