import React, { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { useUserGuardContext } from 'app/auth';
import { AlertCircle, Loader2, FileText } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { API_URL, auth } from 'app';
import brain from 'brain';

const PDFViewerTab: React.FC = () => {
  const [searchParams] = useSearchParams();
  const { user } = useUserGuardContext();
  const [pdfUrl, setPdfUrl] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [documentTitle, setDocumentTitle] = useState<string>('');

  useEffect(() => {
    const documentId = searchParams.get('documentId');
    const title = searchParams.get('title');
    
    console.log('PDFViewerTab mounted with params:', { documentId, title, searchParams: searchParams.toString() });
    
    if (title) {
      setDocumentTitle(title);
    }
    
    if (!documentId) {
      console.error('No document ID provided in search params');
      setError('No document ID provided');
      setLoading(false);
      return;
    }

    // Load PDF using token-based authentication for new tab compatibility
    const loadPDF = async () => {
      try {
        console.log('Loading PDF for document ID:', documentId);
        
        // Get auth token for URL-based authentication in new tab
        const token = await auth.getAuthToken();
        console.log('Auth token retrieved:', token ? 'Yes' : 'No');
        
        if (!token) {
          throw new Error('Authentication token not available');
        }
        
        // Use the correct API path structure that matches the backend endpoint
        const pdfViewUrl = `https://api.databutton.com/_projects/a180dafe-f6c8-4fb7-917a-f8d4b9bfe1b1/dbtn/devx/app/routes/knowledge-base/file/${documentId}?token=${encodeURIComponent(token)}`;
        console.log('PDF URL constructed:', pdfViewUrl);
        
        setPdfUrl(pdfViewUrl);
        console.log('PDF URL set successfully');
      } catch (err) {
        console.error('Error loading PDF:', err);
        setError(err instanceof Error ? err.message : 'Failed to load PDF');
      } finally {
        setLoading(false);
      }
    };

    loadPDF();
  }, [searchParams]);

  // Show loading state
  if (loading) {
    return (
      <div className="min-h-screen bg-gray-900 flex items-center justify-center">
        <Card className="bg-gray-800 border-gray-700 max-w-md w-full mx-4">
          <CardContent className="pt-8 pb-8">
            <div className="flex flex-col items-center text-center">
              <Loader2 className="h-12 w-12 text-blue-400 animate-spin mb-4" />
              <h2 className="text-xl font-semibold text-white mb-2">Loading PDF...</h2>
              <p className="text-gray-400">
                {documentTitle ? `Loading "${documentTitle}"` : 'Preparing document viewer'}
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Show error state
  if (error) {
    return (
      <div className="min-h-screen bg-gray-900 flex items-center justify-center">
        <Card className="bg-gray-800 border-gray-700 max-w-md w-full mx-4">
          <CardHeader>
            <CardTitle className="flex items-center text-red-400">
              <AlertCircle className="h-6 w-6 mr-2" />
              Error Loading PDF
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-gray-300 mb-4">{error}</p>
            <div className="space-y-2">
              <Button 
                onClick={() => window.location.reload()} 
                className="w-full bg-blue-600 hover:bg-blue-700"
              >
                Retry
              </Button>
              <Button 
                variant="outline" 
                onClick={() => window.close()} 
                className="w-full border-gray-600 text-gray-300 hover:bg-gray-700"
              >
                Close Tab
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Show PDF viewer
  if (pdfUrl) {
    return (
      <div className="min-h-screen bg-gray-900">
        {/* Header with document title */}
        <div className="bg-gray-800 border-b border-gray-700 px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <FileText className="h-6 w-6 text-blue-400" />
              <h1 className="text-xl font-semibold text-white truncate">
                {documentTitle || 'PDF Document'}
              </h1>
            </div>
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => window.close()}
              className="border-gray-600 text-gray-300 hover:bg-gray-700"
            >
              Close
            </Button>
          </div>
        </div>
        
        {/* PDF Viewer */}
        <div className="h-[calc(100vh-80px)]">
          <iframe
            src={pdfUrl}
            className="w-full h-full border-0"
            title={documentTitle || 'PDF Document'}
            style={{ backgroundColor: '#1f2937' }}
            onLoad={() => console.log('PDF iframe loaded successfully')}
            onError={(e) => console.error('PDF iframe error:', e)}
          />
        </div>
      </div>
    );
  }

  return null;
};

export default PDFViewerTab;
