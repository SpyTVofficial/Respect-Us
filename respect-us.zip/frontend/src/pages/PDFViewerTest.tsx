import React from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

const PDFViewerTest: React.FC = () => {
  const [searchParams] = useSearchParams();
  const documentId = searchParams.get('documentId');
  const title = searchParams.get('title');
  
  const testUrls = [
    `/pdf-viewer-tab?documentId=122&title=Test%20PDF`,
    `/pdf-viewer?documentId=122&title=Test%20PDF`,
    `/knowledge-base`
  ];
  
  return (
    <div className="min-h-screen bg-gray-900 p-6">
      <Card className="max-w-2xl mx-auto bg-gray-800 border-gray-700">
        <CardHeader>
          <CardTitle className="text-white">PDF Viewer Test Page</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="text-gray-300">
            <p><strong>Document ID:</strong> {documentId || 'None'}</p>
            <p><strong>Title:</strong> {title || 'None'}</p>
            <p><strong>Current URL:</strong> {window.location.href}</p>
          </div>
          
          <div className="space-y-2">
            <h3 className="text-white font-semibold">Test Navigation:</h3>
            {testUrls.map((url, index) => (
              <div key={index} className="flex gap-2">
                <Link to={url}>
                  <Button variant="outline" className="text-sm">
                    Navigate to {url}
                  </Button>
                </Link>
                <Button 
                  variant="ghost" 
                  className="text-sm"
                  onClick={() => window.open(url, '_blank')}
                >
                  Open in new tab
                </Button>
              </div>
            ))}
          </div>
          
          <div className="mt-6">
            <Link to="/knowledge-base">
              <Button className="w-full">
                Back to Knowledge Base
              </Button>
            </Link>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default PDFViewerTest;
