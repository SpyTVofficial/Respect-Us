import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Separator } from '@/components/ui/separator';
import { useUserGuardContext } from 'app/auth';
import {
  Shield,
  FileText,
  BarChart3,
  Target,
  Globe,
  Users,
  Search,
  CheckCircle2,
  ArrowRight,
  Play,
  Star,
  Award,
  Lightbulb,
  Rocket,
  TrendingUp
} from 'lucide-react';
import { toast } from 'sonner';

interface OnboardingStep {
  id: string;
  title: string;
  description: string;
  completed: boolean;
  action?: () => void;
  actionText?: string;
}

interface OnboardingProgress {
  account_created: boolean;
  profile_completed: boolean;
  explored_knowledge_base: boolean;
  understood_modules: boolean;
  tried_risk_assessment: boolean;
  ready_for_compliance: boolean;
}

export default function Onboarding() {
  const { user } = useUserGuardContext();
  const navigate = useNavigate();
  const [currentStep, setCurrentStep] = useState(0);
  const [progress, setProgress] = useState<OnboardingProgress>({
    account_created: true,
    profile_completed: false,
    explored_knowledge_base: false,
    understood_modules: false,
    tried_risk_assessment: false,
    ready_for_compliance: false
  });

  // Load progress from localStorage
  useEffect(() => {
    const saved = localStorage.getItem(`onboarding_progress_${user.id}`);
    if (saved) {
      try {
        const savedProgress = JSON.parse(saved);
        setProgress(savedProgress);
        // Find current step based on progress
        const steps = Object.values(savedProgress);
        const lastCompletedIndex = steps.lastIndexOf(true);
        setCurrentStep(Math.min(lastCompletedIndex + 1, steps.length - 1));
      } catch (error) {
        console.error('Error loading onboarding progress:', error);
      }
    }
  }, [user.id]);

  const updateProgress = (updates: Partial<OnboardingProgress>) => {
    const newProgress = { ...progress, ...updates };
    setProgress(newProgress);
    localStorage.setItem(`onboarding_progress_${user.id}`, JSON.stringify(newProgress));
  };

  const calculateCompletion = () => {
    const steps = Object.values(progress);
    const completed = steps.filter(Boolean).length;
    return Math.round((completed / steps.length) * 100);
  };

  const onboardingSteps: OnboardingStep[] = [
    {
      id: 'welcome',
      title: 'Welcome to RespectUs!',
      description: 'Your journey to export control compliance excellence starts here. Let\'s get you set up for success.',
      completed: progress.account_created,
    },
    {
      id: 'profile',
      title: 'Complete Your Profile',
      description: 'Tell us about your company and compliance needs so we can personalize your experience.',
      completed: progress.profile_completed,
      action: () => {
        updateProgress({ profile_completed: true });
        toast.success('Profile completed! Moving to next step.');
      },
      actionText: 'Complete Profile'
    },
    {
      id: 'knowledge-base',
      title: 'Explore the Knowledge Base',
      description: 'Start with our free Knowledge Base to access regulatory documents and compliance guidance.',
      completed: progress.explored_knowledge_base,
      action: () => {
        updateProgress({ explored_knowledge_base: true });
        navigate('/KnowledgeBase');
      },
      actionText: 'Explore Knowledge Base'
    },
    {
      id: 'modules',
      title: 'Understand Our Modules',
      description: 'Learn about our 7 comprehensive compliance modules and how they can help your business.',
      completed: progress.understood_modules,
      action: () => {
        updateProgress({ understood_modules: true });
        toast.success('Great! You now understand our module ecosystem.');
      },
      actionText: 'Learn About Modules'
    },
    {
      id: 'risk-assessment',
      title: 'Try Risk Assessment',
      description: 'Experience our powerful Risk Assessment module with a guided walkthrough.',
      completed: progress.tried_risk_assessment,
      action: () => {
        updateProgress({ tried_risk_assessment: true });
        navigate('/RiskAssessment');
      },
      actionText: 'Start Risk Assessment'
    },
    {
      id: 'ready',
      title: 'Ready for Compliance Excellence',
      description: 'You\'re all set! Access your dashboard and start building your compliance program.',
      completed: progress.ready_for_compliance,
      action: () => {
        updateProgress({ ready_for_compliance: true });
        navigate('/UserDashboard');
      },
      actionText: 'Go to Dashboard'
    }
  ];

  const currentStepData = onboardingSteps[currentStep];

  const nextStep = () => {
    if (currentStep < onboardingSteps.length - 1) {
      setCurrentStep(currentStep + 1);
    }
  };

  const prevStep = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-black">
      {/* Header */}
      <header className="bg-gray-900/80 border-b border-gray-800/50 px-6 py-6 backdrop-blur-xl">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <img 
              src="https://static.databutton.com/public/a180dafe-f6c8-4fb7-917a-f8d4b9bfe1b1/Original_jpg.jpg" 
              alt="RespectUs Logo" 
              className="h-10 w-auto"
            />
            <div>
              <h1 className="text-2xl font-bold text-white tracking-tight">RespectUs Onboarding</h1>
              <p className="text-sm text-gray-400">Get started with export control compliance</p>
            </div>
          </div>
          <Badge className="bg-purple-500/20 text-purple-400 border-purple-500/30">
            {calculateCompletion()}% Complete
          </Badge>
        </div>
      </header>

      <div className="max-w-4xl mx-auto px-6 py-8">
        {/* Progress Overview */}
        <Card className="bg-gray-900/50 border-gray-700 backdrop-blur-sm mb-8">
          <CardContent className="p-6">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-semibold text-white">Your Onboarding Progress</h2>
                <span className="text-purple-400 font-medium">{calculateCompletion()}%</span>
              </div>
              <Progress value={calculateCompletion()} className="h-3" />
              <div className="flex items-center justify-between text-sm text-gray-400">
                <span>Step {currentStep + 1} of {onboardingSteps.length}</span>
                <span>{onboardingSteps.filter(step => step.completed).length} steps completed</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Current Step */}
        <Card className="bg-gradient-to-br from-purple-900/30 to-blue-900/30 border-purple-500/30 backdrop-blur-sm mb-8">
          <CardContent className="p-8">
            <div className="text-center space-y-6">
              <div className="mx-auto w-16 h-16 bg-purple-600/20 rounded-full flex items-center justify-center">
                {currentStep === 0 && <Rocket className="w-8 h-8 text-purple-400" />}
                {currentStep === 1 && <Users className="w-8 h-8 text-purple-400" />}
                {currentStep === 2 && <FileText className="w-8 h-8 text-purple-400" />}
                {currentStep === 3 && <Target className="w-8 h-8 text-purple-400" />}
                {currentStep === 4 && <BarChart3 className="w-8 h-8 text-purple-400" />}
                {currentStep === 5 && <Star className="w-8 h-8 text-purple-400" />}
              </div>
              
              <div>
                <h2 className="text-3xl font-bold text-white mb-3">{currentStepData.title}</h2>
                <p className="text-gray-300 text-lg max-w-2xl mx-auto">
                  {currentStepData.description}
                </p>
              </div>

              {currentStepData.action && (
                <Button 
                  onClick={currentStepData.action}
                  className="bg-purple-600 hover:bg-purple-700 text-white px-8 py-3 text-lg"
                >
                  {currentStepData.actionText}
                  <ArrowRight className="w-5 h-5 ml-2" />
                </Button>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Step Navigation */}
        <div className="flex items-center justify-between mb-8">
          <Button 
            variant="outline" 
            onClick={prevStep}
            disabled={currentStep === 0}
            className="border-gray-600 text-gray-300 hover:bg-gray-800"
          >
            Previous Step
          </Button>
          
          <div className="flex space-x-2">
            {onboardingSteps.map((step, index) => (
              <button
                key={step.id}
                onClick={() => setCurrentStep(index)}
                className={`w-3 h-3 rounded-full transition-colors ${
                  index === currentStep
                    ? 'bg-purple-500'
                    : step.completed
                    ? 'bg-green-500'
                    : 'bg-gray-600'
                }`}
              />
            ))}
          </div>

          <Button 
            variant="outline" 
            onClick={nextStep}
            disabled={currentStep === onboardingSteps.length - 1}
            className="border-gray-600 text-gray-300 hover:bg-gray-800"
          >
            Next Step
          </Button>
        </div>

        {/* All Steps Overview */}
        <Card className="bg-gray-900/50 border-gray-700 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="text-white">Onboarding Journey</CardTitle>
            <CardDescription className="text-gray-400">
              Track your progress through each step of the onboarding process
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {onboardingSteps.map((step, index) => (
                <div key={step.id} className="flex items-center space-x-4">
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 ${
                    step.completed 
                      ? 'bg-green-500/20 border-2 border-green-500/30' 
                      : index === currentStep
                      ? 'bg-purple-500/20 border-2 border-purple-500/30'
                      : 'bg-gray-600/20 border-2 border-gray-600/30'
                  }`}>
                    {step.completed ? (
                      <CheckCircle2 className="w-5 h-5 text-green-400" />
                    ) : (
                      <span className={`text-sm font-semibold ${
                        index === currentStep ? 'text-purple-400' : 'text-gray-400'
                      }`}>
                        {index + 1}
                      </span>
                    )}
                  </div>
                  
                  <div className="flex-1">
                    <h3 className={`font-semibold ${
                      step.completed ? 'text-green-400' : index === currentStep ? 'text-purple-400' : 'text-white'
                    }`}>
                      {step.title}
                    </h3>
                    <p className="text-gray-400 text-sm">{step.description}</p>
                  </div>
                  
                  {index === currentStep && !step.completed && step.action && (
                    <Button 
                      onClick={step.action}
                      size="sm"
                      className="bg-purple-600 hover:bg-purple-700 text-white"
                    >
                      {step.actionText}
                    </Button>
                  )}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Completion Celebration */}
        {calculateCompletion() === 100 && (
          <Card className="bg-gradient-to-r from-green-900/30 to-emerald-900/30 border-green-500/30 backdrop-blur-sm mt-8">
            <CardContent className="p-8">
              <div className="text-center space-y-4">
                <div className="mx-auto w-16 h-16 bg-green-600/20 rounded-full flex items-center justify-center">
                  <Award className="w-8 h-8 text-green-400" />
                </div>
                <h2 className="text-3xl font-bold text-white">Congratulations!</h2>
                <p className="text-green-300 text-lg max-w-2xl mx-auto">
                  You've successfully completed the RespectUs onboarding process. You're now ready to build a world-class export control compliance program.
                </p>
                <div className="flex items-center justify-center space-x-4 pt-4">
                  <Button 
                    onClick={() => navigate('/UserDashboard')}
                    className="bg-green-600 hover:bg-green-700 text-white"
                  >
                    <TrendingUp className="w-4 h-4 mr-2" />
                    Go to Dashboard
                  </Button>
                  <Button 
                    variant="outline"
                    onClick={() => navigate('/KnowledgeBase')}
                    className="border-green-500/30 text-green-400 hover:bg-green-500/10"
                  >
                    <FileText className="w-4 h-4 mr-2" />
                    Continue Learning
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}