import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line
} from 'recharts';
import { 
  Activity, 
  AlertTriangle, 
  CheckCircle, 
  Clock, 
  TrendingUp, 
  Users, 
  Shield, 
  Calendar,
  FileText,
  Target,
  Zap,
  Bell,
  BarChart3,
  Settings,
  RefreshCw
} from 'lucide-react';
import brain from 'brain';
import { useUserGuardContext } from 'app/auth';
import { toast } from 'sonner';

interface DashboardData {
  summary: {
    total_customers: number;
    high_risk_customers: number;
    active_schedules: number;
    completed_screenings_today: number;
    pending_alerts: number;
    system_health_score: number;
    last_updated: string;
  };
  customerAnalytics: {
    by_risk_level: Record<string, number>;
    by_type: Record<string, number>;
    by_geography: Record<string, number>;
    screening_success_rate: number;
    average_screening_time: number;
    total_screenings_last_30_days: number;
  };
  screeningMetrics: {
    total_screenings: number;
    successful_screenings: number;
    failed_screenings: number;
    success_rate: number;
    average_processing_time: number;
    screenings_by_day: Array<{
      date: string;
      total: number;
      successful: number;
      success_rate: number;
    }>;
    top_risk_factors: Array<{
      factor: string;
      count: number;
      percentage: number;
    }>;
  };
  automationPerformance: {
    total_schedules: number;
    active_schedules: number;
    completed_jobs_today: number;
    failed_jobs_today: number;
    automation_efficiency: number;
    schedule_performance: Array<{
      schedule_name: string;
      schedule_type: string;
      total_jobs: number;
      successful_jobs: number;
      success_rate: number;
      last_run: string | null;
    }>;
  };
  complianceMetrics: {
    compliance_score: number;
    regulatory_coverage: number;
    documentation_completeness: number;
    audit_readiness_score: number;
    compliance_gaps: Array<{
      area: string;
      severity: string;
      count: number;
    }>;
    recent_compliance_activities: Array<{
      activity: string;
      timestamp: string;
      status: string;
    }>;
  };
}

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8'];

const MonitoringDashboard: React.FC = () => {
  const { user } = useUserGuardContext();
  const [dashboardData, setDashboardData] = useState<DashboardData | null>(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [lastRefresh, setLastRefresh] = useState<Date>(new Date());

  const loadDashboardData = async (showToast = false) => {
    try {
      setRefreshing(true);

      // Load all analytics data concurrently
      const [summaryRes, customerRes, screeningRes, automationRes, complianceRes] = await Promise.all([
        brain.get_monitoring_dashboard_summary(),
        brain.get_customer_monitoring_analytics(),
        brain.get_screening_performance_metrics(),
        brain.get_automation_performance_metrics(),
        brain.get_compliance_regulatory_metrics()
      ]);

      const [summaryData, customerData, screeningData, automationData, complianceData] = await Promise.all([
        summaryRes.json(),
        customerRes.json(),
        screeningRes.json(),
        automationRes.json(),
        complianceRes.json()
      ]);

      setDashboardData({
        summary: summaryData,
        customerAnalytics: customerData,
        screeningMetrics: screeningData,
        automationPerformance: automationData,
        complianceMetrics: complianceData
      });

      setLastRefresh(new Date());
      
      if (showToast) {
        toast.success('Dashboard refreshed successfully');
      }

    } catch (error) {
      console.error('Error loading dashboard data:', error);
      toast.error('Failed to load dashboard data');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    loadDashboardData();
    
    // Auto-refresh every 5 minutes
    const interval = setInterval(() => {
      loadDashboardData();
    }, 300000);

    return () => clearInterval(interval);
  }, []);

  const handleRefresh = () => {
    loadDashboardData(true);
  };

  const getHealthScoreColor = (score: number) => {
    if (score >= 90) return 'text-green-600';
    if (score >= 70) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getSeverityColor = (severity: string) => {
    switch (severity.toLowerCase()) {
      case 'high': return 'destructive';
      case 'medium': return 'default';
      case 'low': return 'secondary';
      default: return 'outline';
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-900 p-6">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-center h-64">
            <div className="flex items-center space-x-2">
              <RefreshCw className="h-6 w-6 animate-spin text-blue-400" />
              <span className="text-gray-300">Loading monitoring dashboard...</span>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!dashboardData) {
    return (
      <div className="min-h-screen bg-gray-900 p-6">
        <div className="max-w-7xl mx-auto">
          <div className="text-center py-12">
            <AlertTriangle className="h-12 w-12 text-yellow-500 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-white mb-2">Failed to Load Dashboard</h3>
            <p className="text-gray-400 mb-4">Unable to load monitoring data</p>
            <Button onClick={handleRefresh} className="bg-blue-600 hover:bg-blue-700">
              <RefreshCw className="h-4 w-4 mr-2" />
              Retry
            </Button>
          </div>
        </div>
      </div>
    );
  }

  const riskLevelData = Object.entries(dashboardData.customerAnalytics.by_risk_level).map(([level, count]) => ({
    name: level.charAt(0).toUpperCase() + level.slice(1),
    value: count,
    color: level === 'high' ? '#FF8042' : level === 'medium' ? '#FFBB28' : '#00C49F'
  }));

  const screeningTrendData = dashboardData.screeningMetrics.screenings_by_day
    .slice(-14)
    .map(day => ({
      date: new Date(day.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
      total: day.total,
      successful: day.successful,
      success_rate: day.success_rate
    }));

  return (
    <div className="min-h-screen bg-gray-900 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-white mb-2">Monitoring Dashboard</h1>
            <p className="text-gray-400">
              Real-time compliance monitoring and analytics
            </p>
          </div>
          <div className="flex items-center space-x-4">
            <div className="text-sm text-gray-400">
              Last updated: {lastRefresh.toLocaleTimeString()}
            </div>
            <Button 
              onClick={handleRefresh} 
              disabled={refreshing}
              className="bg-blue-600 hover:bg-blue-700"
            >
              <RefreshCw className={`h-4 w-4 mr-2 ${refreshing ? 'animate-spin' : ''}`} />
              Refresh
            </Button>
          </div>
        </div>

        {/* System Health Alert */}
        {dashboardData.summary.system_health_score < 70 && (
          <Alert className="border-red-600 bg-red-900/20">
            <AlertTriangle className="h-4 w-4 text-red-400" />
            <AlertTitle className="text-red-300">System Health Warning</AlertTitle>
            <AlertDescription className="text-red-200">
              System health score is {dashboardData.summary.system_health_score}%. 
              Please review automation schedules and address any failures.
            </AlertDescription>
          </Alert>
        )}

        {/* Key Metrics Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card className="bg-gray-800 border-gray-700">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-300">Total Customers</CardTitle>
              <Users className="h-4 w-4 text-blue-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white">
                {dashboardData.summary.total_customers.toLocaleString()}
              </div>
              <p className="text-xs text-gray-400">
                {dashboardData.summary.high_risk_customers} high-risk
              </p>
            </CardContent>
          </Card>

          <Card className="bg-gray-800 border-gray-700">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-300">Active Schedules</CardTitle>
              <Calendar className="h-4 w-4 text-green-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white">
                {dashboardData.summary.active_schedules}
              </div>
              <p className="text-xs text-gray-400">
                Automated monitoring
              </p>
            </CardContent>
          </Card>

          <Card className="bg-gray-800 border-gray-700">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-300">Today's Screenings</CardTitle>
              <Shield className="h-4 w-4 text-purple-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white">
                {dashboardData.summary.completed_screenings_today}
              </div>
              <p className="text-xs text-gray-400">
                Completed successfully
              </p>
            </CardContent>
          </Card>

          <Card className="bg-gray-800 border-gray-700">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-300">System Health</CardTitle>
              <Activity className="h-4 w-4 text-orange-400" />
            </CardHeader>
            <CardContent>
              <div className={`text-2xl font-bold ${getHealthScoreColor(dashboardData.summary.system_health_score)}`}>
                {dashboardData.summary.system_health_score}%
              </div>
              <Progress 
                value={dashboardData.summary.system_health_score} 
                className="mt-2"
              />
            </CardContent>
          </Card>
        </div>

        {/* Main Dashboard Tabs */}
        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="bg-gray-800 border-gray-700">
            <TabsTrigger value="overview" className="data-[state=active]:bg-gray-700">
              <BarChart3 className="h-4 w-4 mr-2" />
              Overview
            </TabsTrigger>
            <TabsTrigger value="customers" className="data-[state=active]:bg-gray-700">
              <Users className="h-4 w-4 mr-2" />
              Customers
            </TabsTrigger>
            <TabsTrigger value="automation" className="data-[state=active]:bg-gray-700">
              <Zap className="h-4 w-4 mr-2" />
              Automation
            </TabsTrigger>
            <TabsTrigger value="compliance" className="data-[state=active]:bg-gray-700">
              <FileText className="h-4 w-4 mr-2" />
              Compliance
            </TabsTrigger>
            <TabsTrigger value="alerts" className="data-[state=active]:bg-gray-700">
              <Bell className="h-4 w-4 mr-2" />
              Alerts
            </TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              
              {/* Screening Trends */}
              <Card className="bg-gray-800 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white">Screening Activity (14 Days)</CardTitle>
                  <CardDescription className="text-gray-400">
                    Daily screening volume and success rates
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <AreaChart data={screeningTrendData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                      <XAxis dataKey="date" stroke="#9CA3AF" />
                      <YAxis stroke="#9CA3AF" />
                      <Tooltip 
                        contentStyle={{ 
                          backgroundColor: '#1F2937', 
                          border: '1px solid #374151',
                          borderRadius: '6px',
                          color: '#F9FAFB'
                        }} 
                      />
                      <Area 
                        type="monotone" 
                        dataKey="total" 
                        stroke="#3B82F6" 
                        fill="#3B82F6" 
                        fillOpacity={0.3} 
                        name="Total Screenings"
                      />
                      <Area 
                        type="monotone" 
                        dataKey="successful" 
                        stroke="#10B981" 
                        fill="#10B981" 
                        fillOpacity={0.3} 
                        name="Successful"
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              {/* Risk Distribution */}
              <Card className="bg-gray-800 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white">Customer Risk Distribution</CardTitle>
                  <CardDescription className="text-gray-400">
                    Breakdown by risk level
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <PieChart>
                      <Pie
                        data={riskLevelData}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                      >
                        {riskLevelData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip 
                        contentStyle={{ 
                          backgroundColor: '#1F2937', 
                          border: '1px solid #374151',
                          borderRadius: '6px',
                          color: '#F9FAFB'
                        }} 
                      />
                    </PieChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>

            {/* Performance Metrics */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card className="bg-gray-800 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white flex items-center">
                    <Target className="h-5 w-5 mr-2 text-blue-400" />
                    Screening Success Rate
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-white mb-2">
                    {dashboardData.screeningMetrics.success_rate}%
                  </div>
                  <Progress value={dashboardData.screeningMetrics.success_rate} className="mb-2" />
                  <p className="text-sm text-gray-400">
                    {dashboardData.screeningMetrics.successful_screenings} of {dashboardData.screeningMetrics.total_screenings} successful
                  </p>
                </CardContent>
              </Card>

              <Card className="bg-gray-800 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white flex items-center">
                    <Clock className="h-5 w-5 mr-2 text-green-400" />
                    Avg Processing Time
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-white mb-2">
                    {dashboardData.screeningMetrics.average_processing_time.toFixed(1)}s
                  </div>
                  <p className="text-sm text-gray-400">
                    Per screening operation
                  </p>
                </CardContent>
              </Card>

              <Card className="bg-gray-800 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white flex items-center">
                    <Zap className="h-5 w-5 mr-2 text-purple-400" />
                    Automation Efficiency
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-white mb-2">
                    {dashboardData.automationPerformance.automation_efficiency}%
                  </div>
                  <Progress value={dashboardData.automationPerformance.automation_efficiency} className="mb-2" />
                  <p className="text-sm text-gray-400">
                    {dashboardData.automationPerformance.completed_jobs_today} jobs completed today
                  </p>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Customer Analytics Tab */}
          <TabsContent value="customers" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="bg-gray-800 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white">Customer Type Distribution</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {Object.entries(dashboardData.customerAnalytics.by_type).map(([type, count]) => (
                      <div key={type} className="flex items-center justify-between">
                        <span className="text-gray-300 capitalize">{type}</span>
                        <div className="flex items-center space-x-2">
                          <div className="bg-gray-700 rounded-full px-3 py-1">
                            <span className="text-white font-medium">{count}</span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gray-800 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white">Top Geographic Regions</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {Object.entries(dashboardData.customerAnalytics.by_geography)
                      .sort(([,a], [,b]) => b - a)
                      .slice(0, 5)
                      .map(([country, count]) => (
                        <div key={country} className="flex items-center justify-between">
                          <span className="text-gray-300">{country}</span>
                          <div className="flex items-center space-x-2">
                            <div className="bg-gray-700 rounded-full px-3 py-1">
                              <span className="text-white font-medium">{count}</span>
                            </div>
                          </div>
                        </div>
                      ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card className="bg-gray-800 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white">Screening Performance Metrics</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-blue-400">
                      {dashboardData.customerAnalytics.screening_success_rate}%
                    </div>
                    <p className="text-sm text-gray-400">Success Rate</p>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-green-400">
                      {dashboardData.customerAnalytics.average_screening_time.toFixed(1)}s
                    </div>
                    <p className="text-sm text-gray-400">Avg Time</p>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-purple-400">
                      {dashboardData.customerAnalytics.total_screenings_last_30_days}
                    </div>
                    <p className="text-sm text-gray-400">Last 30 Days</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Automation Tab */}
          <TabsContent value="automation" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="bg-gray-800 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white">Schedule Performance</CardTitle>
                  <CardDescription className="text-gray-400">
                    Performance metrics for each monitoring schedule
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {dashboardData.automationPerformance.schedule_performance.map((schedule, index) => (
                      <div key={index} className="border border-gray-700 rounded-lg p-4">
                        <div className="flex items-center justify-between mb-2">
                          <h4 className="font-medium text-white">{schedule.schedule_name}</h4>
                          <Badge 
                            variant={schedule.success_rate >= 90 ? 'default' : schedule.success_rate >= 70 ? 'secondary' : 'destructive'}
                          >
                            {schedule.success_rate.toFixed(1)}% success
                          </Badge>
                        </div>
                        <div className="text-sm text-gray-400 space-y-1">
                          <div>Type: {schedule.schedule_type}</div>
                          <div>Jobs: {schedule.successful_jobs}/{schedule.total_jobs}</div>
                          {schedule.last_run && (
                            <div>Last run: {new Date(schedule.last_run).toLocaleString()}</div>
                          )}
                        </div>
                        <Progress value={schedule.success_rate} className="mt-2" />
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gray-800 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white">Automation Overview</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="text-center">
                        <div className="text-3xl font-bold text-blue-400">
                          {dashboardData.automationPerformance.active_schedules}
                        </div>
                        <p className="text-sm text-gray-400">Active Schedules</p>
                      </div>
                      <div className="text-center">
                        <div className="text-3xl font-bold text-green-400">
                          {dashboardData.automationPerformance.completed_jobs_today}
                        </div>
                        <p className="text-sm text-gray-400">Jobs Today</p>
                      </div>
                    </div>
                    
                    <div className="border-t border-gray-700 pt-4">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-gray-300">Overall Efficiency</span>
                        <span className="text-white font-bold">
                          {dashboardData.automationPerformance.automation_efficiency}%
                        </span>
                      </div>
                      <Progress value={dashboardData.automationPerformance.automation_efficiency} />
                    </div>

                    {dashboardData.automationPerformance.failed_jobs_today > 0 && (
                      <Alert className="border-yellow-600 bg-yellow-900/20">
                        <AlertTriangle className="h-4 w-4 text-yellow-400" />
                        <AlertDescription className="text-yellow-200">
                          {dashboardData.automationPerformance.failed_jobs_today} jobs failed today. 
                          Check automation logs for details.
                        </AlertDescription>
                      </Alert>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Compliance Tab */}
          <TabsContent value="compliance" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="bg-gray-800 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white">Compliance Scores</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-gray-300">Overall Compliance</span>
                        <span className="text-white font-bold">
                          {dashboardData.complianceMetrics.compliance_score}%
                        </span>
                      </div>
                      <Progress value={dashboardData.complianceMetrics.compliance_score} />
                    </div>

                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-gray-300">Regulatory Coverage</span>
                        <span className="text-white font-bold">
                          {dashboardData.complianceMetrics.regulatory_coverage}%
                        </span>
                      </div>
                      <Progress value={dashboardData.complianceMetrics.regulatory_coverage} />
                    </div>

                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-gray-300">Documentation</span>
                        <span className="text-white font-bold">
                          {dashboardData.complianceMetrics.documentation_completeness}%
                        </span>
                      </div>
                      <Progress value={dashboardData.complianceMetrics.documentation_completeness} />
                    </div>

                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-gray-300">Audit Readiness</span>
                        <span className="text-white font-bold">
                          {dashboardData.complianceMetrics.audit_readiness_score}%
                        </span>
                      </div>
                      <Progress value={dashboardData.complianceMetrics.audit_readiness_score} />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gray-800 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white">Compliance Gaps</CardTitle>
                  <CardDescription className="text-gray-400">
                    Areas requiring attention
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {dashboardData.complianceMetrics.compliance_gaps.map((gap, index) => (
                      <div key={index} className="border border-gray-700 rounded-lg p-4">
                        <div className="flex items-center justify-between mb-2">
                          <h4 className="font-medium text-white">{gap.area}</h4>
                          <Badge variant={getSeverityColor(gap.severity)}>
                            {gap.severity}
                          </Badge>
                        </div>
                        <p className="text-sm text-gray-400">
                          {gap.count} items requiring attention
                        </p>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card className="bg-gray-800 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white">Recent Compliance Activities</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {dashboardData.complianceMetrics.recent_compliance_activities.map((activity, index) => (
                    <div key={index} className="flex items-center justify-between py-2 border-b border-gray-700 last:border-b-0">
                      <div>
                        <p className="text-white">{activity.activity}</p>
                        <p className="text-sm text-gray-400">
                          {new Date(activity.timestamp).toLocaleString()}
                        </p>
                      </div>
                      <Badge variant={activity.status === 'completed' ? 'default' : 'secondary'}>
                        <CheckCircle className="h-3 w-3 mr-1" />
                        {activity.status}
                      </Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Alerts Tab */}
          <TabsContent value="alerts" className="space-y-6">
            <Card className="bg-gray-800 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white">Alert Management</CardTitle>
                <CardDescription className="text-gray-400">
                  Configure and monitor system alerts
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-red-400">
                      {dashboardData.summary.pending_alerts}
                    </div>
                    <p className="text-sm text-gray-400">Pending Alerts</p>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-orange-400">12</div>
                    <p className="text-sm text-gray-400">Critical</p>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-yellow-400">8</div>
                    <p className="text-sm text-gray-400">Medium</p>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-blue-400">4.2h</div>
                    <p className="text-sm text-gray-400">Avg Response</p>
                  </div>
                </div>

                <div className="text-center py-8">
                  <Bell className="h-12 w-12 text-gray-500 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-gray-300 mb-2">Alert System Configuration</h3>
                  <p className="text-gray-400 mb-4">
                    Set up real-time alerts for high-risk customer matches, compliance violations, and system issues.
                  </p>
                  <Button className="bg-blue-600 hover:bg-blue-700">
                    <Settings className="h-4 w-4 mr-2" />
                    Configure Alerts
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default MonitoringDashboard;
