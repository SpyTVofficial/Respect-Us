
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useUserGuardContext } from 'app/auth';
import CustomerOnboardingForm, { CustomerDetails } from 'components/CustomerOnboardingForm';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { CheckCircle, User, ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';
import brain from 'brain';

export default function ProfileCompletion() {
  const { user } = useUserGuardContext();
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);

  // Check if user already has profile completed
  useEffect(() => {
    const checkProfileStatus = () => {
      const saved = localStorage.getItem(`onboarding_progress_${user.id}`);
      if (saved) {
        const progress = JSON.parse(saved);
        if (progress.profile_completed) {
          // Redirect to dashboard if already completed
          navigate('/user-dashboard');
        }
      }
    };
    
    checkProfileStatus();
  }, [user.id, navigate]);

  const handleProfileSubmit = async (details: CustomerDetails) => {
    setIsLoading(true);
    
    try {
      // Save profile to backend
      const response = await brain.save_user_profile({
        company_name: details.company_name,
        contact_person: details.contact_person,
        email: details.email,
        phone: details.phone || '',
        billing_address: details.billing_address,
        city: details.city,
        postal_code: details.postal_code,
        country: details.country,
        tax_id: details.tax_id || '',
        vat_number: details.vat_number || ''
      });

      if (response.ok) {
        // Update onboarding progress
        const saved = localStorage.getItem(`onboarding_progress_${user.id}`);
        const progress = saved ? JSON.parse(saved) : {
          account_created: true,
          profile_completed: false,
          explored_knowledge_base: false,
          understood_modules: false,
          tried_risk_assessment: false,
          ready_for_compliance: false
        };
        
        progress.profile_completed = true;
        localStorage.setItem(`onboarding_progress_${user.id}`, JSON.stringify(progress));
        
        setIsSubmitted(true);
        toast.success('Profile completed successfully!');
        
        // Redirect to purchase page with profile completion flag
        setTimeout(() => {
          navigate('/purchase?from=profile');
        }, 2000);
      } else {
        throw new Error('Failed to save profile');
      }
    } catch (error) {
      console.error('Profile submission error:', error);
      toast.error('Failed to save profile. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleCancel = () => {
    navigate('/user-dashboard');
  };

  // Success state
  if (isSubmitted) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-gray-900 via-gray-800 to-black flex items-center justify-center p-4">
        <Card className="w-full max-w-md mx-auto bg-gray-900/90 backdrop-blur-sm border-gray-700">
          <CardContent className="pt-6">
            <div className="text-center space-y-4">
              <div className="w-16 h-16 bg-green-600/20 rounded-full flex items-center justify-center mx-auto">
                <CheckCircle className="w-8 h-8 text-green-400" />
              </div>
              <h2 className="text-2xl font-bold text-white">Profile Complete!</h2>
              <p className="text-gray-400">
                Your business profile has been saved successfully. Redirecting you to the dashboard...
              </p>
              <div className="w-8 h-8 border-2 border-blue-400/30 border-t-blue-400 rounded-full animate-spin mx-auto" />
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-900 via-gray-800 to-black">
      {/* Header */}
      <div className="bg-gray-900/50 backdrop-blur-sm border-b border-gray-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-4">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => navigate('/user-dashboard')}
                className="text-gray-400 hover:text-white"
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Dashboard
              </Button>
            </div>
            <div className="flex items-center space-x-2 text-sm text-gray-400">
              <User className="w-4 h-4" />
              <span>Complete Your Profile</span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-white mb-2">Complete Your Business Profile</h1>
          <p className="text-gray-400 max-w-2xl mx-auto">
            To provide you with personalized compliance solutions and ensure regulatory compliance, 
            we need some information about your business. This information will be securely stored 
            and used only for service delivery.
          </p>
        </div>

        <CustomerOnboardingForm
          onSubmit={handleProfileSubmit}
          onCancel={handleCancel}
          isLoading={isLoading}
          title="Business Information"
          description="Please provide your company details to complete your profile setup."
          initialData={{
            email: user.primaryEmail || '',
            contact_person: user.displayName || ''
          }}
        />
      </div>
    </div>
  );
}
