import React, { useEffect, useState } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Download, ArrowLeft, AlertCircle, ExternalLink, RefreshCw, Monitor } from 'lucide-react';
import { auth } from 'app/auth';
import { API_URL } from 'app';
import brain from 'brain';

// Browser detection helper
function getBrowserType(): 'chrome' | 'firefox' | 'safari' | 'other' {
  const userAgent = navigator.userAgent.toLowerCase();
  if (userAgent.includes('chrome') && !userAgent.includes('edg')) return 'chrome';
  if (userAgent.includes('firefox')) return 'firefox';
  if (userAgent.includes('safari') && !userAgent.includes('chrome')) return 'safari';
  return 'other';
}

const PDFViewer: React.FC = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const [pdfBlobUrl, setPdfBlobUrl] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [viewMode, setViewMode] = useState<'iframe' | 'download'>('iframe');
  const [showCompatibilityWarning, setShowCompatibilityWarning] = useState(false);
  
  const documentId = searchParams.get('documentId');
  const documentTitle = searchParams.get('title') || 'Document';
  const browserType = getBrowserType();

  // Add test button state
  const [testResult, setTestResult] = useState<string>('');

  useEffect(() => {
    if (!documentId) {
      setError('No document ID provided');
      setLoading(false);
      return;
    }

    // Show compatibility warning for Chrome
    if (browserType === 'chrome') {
      setShowCompatibilityWarning(true);
    }

    loadPDF();
  }, [documentId, browserType]);

  const loadPDF = async () => {
    try {
      console.log('🔍 Loading PDF for document ID:', documentId);
      
      // Get auth token for the request
      const token = await auth.getAuthToken();
      console.log('🔑 Auth token retrieved:', token ? `${token.substring(0, 10)}...` : 'null');
      if (!token) {
        throw new Error('Authentication token not available');
      }
      
      // Construct the correct API URL for development environment
      const apiUrl = `https://api.databutton.com/_projects/a180dafe-f6c8-4fb7-917a-f8d4b9bfe1b1/dbtn/devx/app/routes/knowledge-base/file/${documentId}`;
      console.log('📡 Making direct fetch to:', apiUrl);
      
      // Make direct fetch request with authentication
      const headers = {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      };
      console.log('📋 Request headers:', { ...headers, Authorization: headers.Authorization.substring(0, 20) + '...' });
      
      const response = await fetch(apiUrl, {
        method: 'GET',
        headers,
        credentials: 'include'
      });
      
      console.log('📡 Direct fetch response:', {
        status: response.status,
        statusText: response.statusText,
        ok: response.ok,
        contentType: response.headers.get('content-type')
      });
      
      if (!response.ok) {
        const errorText = await response.text();
        console.error('❌ Response error:', errorText);
        throw new Error(`Failed to load PDF: ${response.status} ${response.statusText} - ${errorText}`);
      }
      
      const blob = await response.blob();
      console.log('✅ PDF blob loaded:', blob.size, 'bytes', blob.type);
      
      if (blob.size === 0) {
        throw new Error('Received empty PDF file');
      }
      
      // Force content type to ensure browser treats it as PDF for viewing
      const pdfBlob = new Blob([blob], { type: 'application/pdf' });
      const url = URL.createObjectURL(pdfBlob);
      setPdfBlobUrl(url);
      
      console.log('✨ PDF blob URL created successfully:', url.substring(0, 50) + '...');
      
      // Auto-fallback for Chrome if iframe fails to load
      if (browserType === 'chrome') {
        setShowCompatibilityWarning(true);
        setTimeout(() => {
          const iframe = document.querySelector('iframe[title="' + documentTitle + '"]') as HTMLIFrameElement;
          if (iframe && !iframe.contentDocument) {
            console.log('Chrome iframe load failed, switching to download mode');
            setViewMode('download');
          }
        }, 3000);
      }
    } catch (err) {
      console.error('❌ Error loading PDF:', err);
      setError(err instanceof Error ? err.message : 'Failed to load PDF');
    } finally {
      setLoading(false);
    }
  };

  const handleDownload = () => {
    if (pdfBlobUrl) {
      const link = document.createElement('a');
      link.href = pdfBlobUrl;
      link.download = `${documentTitle}.pdf`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  };

  const handleDirectView = async () => {
    // Open the dedicated PDF viewer page in a new tab
    const pdfViewerPath = `pdf-viewer-tab?documentId=${documentId}&title=${encodeURIComponent(documentTitle)}`;
    // Ensure proper URL construction with forward slash
    const fullUrl = `${window.location.origin}${APP_BASE_PATH}/${pdfViewerPath}`;
    
    console.log('Opening PDF in new tab:', {
      origin: window.location.origin,
      APP_BASE_PATH,
      documentId,
      documentTitle,
      encodedTitle: encodeURIComponent(documentTitle),
      pdfViewerPath,
      fullUrl
    });
    
    window.open(fullUrl, '_blank', 'noopener,noreferrer');
  };

  const renderPDFContent = () => {
    if (!pdfBlobUrl) return null;

    if (viewMode === 'download') {
      return (
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center max-w-md">
            <AlertCircle className="w-16 h-16 text-yellow-400 mx-auto mb-6" />
            <h3 className="text-xl font-semibold text-white mb-4">Chrome PDF Viewing Limitation</h3>
            <p className="text-gray-300 mb-6">
              Chrome may block embedded PDF viewing for security reasons. Please use one of the options below to view the document.
            </p>
            <div className="space-y-3">
              <Button
                onClick={handleDirectView}
                className="w-full bg-blue-600 hover:bg-blue-700 text-white"
              >
                <ExternalLink className="w-4 h-4 mr-2" />
                Open PDF in New Tab
              </Button>
              <Button
                onClick={handleDownload}
                variant="outline"
                className="w-full border-gray-600 text-gray-300 hover:bg-gray-700"
              >
                <Download className="w-4 h-4 mr-2" />
                Download PDF
              </Button>
              <Button
                onClick={() => setViewMode('iframe')}
                variant="ghost"
                className="w-full text-gray-400 hover:text-white hover:bg-gray-700"
              >
                <RefreshCw className="w-4 h-4 mr-2" />
                Try Embedded View Again
              </Button>
            </div>
          </div>
        </div>
      );
    }

    return (
      <>
        {/* Chrome compatibility warning */}
        {showCompatibilityWarning && viewMode === 'iframe' && (
          <div className="bg-yellow-900/20 border-yellow-600/30 border p-4 mb-4 rounded-lg flex items-center gap-3">
            <AlertCircle className="w-5 h-5 text-yellow-400 flex-shrink-0" />
            <div className="flex-1">
              <div className="text-yellow-200 font-medium mb-1">Chrome PDF Viewing Notice</div>
              <div className="text-yellow-200/80 text-sm">
                If the PDF doesn't display properly, try opening it in a new tab or downloading it.
              </div>
            </div>
            <div className="flex gap-2">
              <Button
                onClick={handleDirectView}
                size="sm"
                variant="outline"
                className="border-yellow-600/30 text-yellow-200 hover:bg-yellow-600/20"
              >
                <ExternalLink className="w-4 h-4 mr-1" />
                New Tab
              </Button>
              <Button
                onClick={() => setShowCompatibilityWarning(false)}
                size="sm"
                variant="ghost"
                className="text-yellow-200/60 hover:text-yellow-200"
              >
                ×
              </Button>
            </div>
          </div>
        )}
        
        {/* PDF iframe with Chrome-optimized parameters */}
        <iframe
          src={browserType === 'chrome' 
            ? `${pdfBlobUrl}#view=FitH&toolbar=1&navpanes=1&scrollbar=1&statusbar=1&messages=0&zoom=page-fit`
            : `${pdfBlobUrl}#view=FitH&toolbar=1&navpanes=1&scrollbar=1&statusbar=1&messages=0&scrollbar=1`
          }
          className="w-full h-full min-h-[80vh] border border-gray-700 rounded bg-white"
          title={documentTitle}
          style={{ minHeight: 'calc(100vh - 160px)' }}
          onError={() => {
            console.log('PDF iframe failed to load, switching to download mode');
            setViewMode('download');
          }}
        />
      </>
    );
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-900 flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <div className="w-8 h-8 border-2 border-blue-400 border-t-transparent rounded-full animate-spin"></div>
          <div className="text-gray-400">Loading PDF...</div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gray-900 flex items-center justify-center">
        <div className="flex flex-col items-center gap-4 text-center max-w-md">
          <AlertCircle className="w-12 h-12 text-red-400" />
          <div className="text-red-400 font-medium">Failed to load PDF</div>
          <div className="text-gray-400 text-sm">{error}</div>
          <div className="flex gap-2">
            <Button
              variant="outline"
              onClick={() => navigate(-1)}
              className="border-gray-600 text-gray-300 hover:bg-gray-700"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Go Back
            </Button>
            <Button
              variant="outline"
              onClick={loadPDF}
              className="border-gray-600 text-gray-300 hover:bg-gray-700"
            >
              Try Again
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-900 flex flex-col">
      {/* Header */}
      <div className="bg-gray-800 border-b border-gray-700 p-4">
        <div className="flex items-center justify-between max-w-screen-xl mx-auto">
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              onClick={() => navigate(-1)}
              className="text-gray-400 hover:text-white hover:bg-gray-700"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back
            </Button>
            <h1 className="text-white font-medium">{decodeURIComponent(documentTitle)}</h1>
          </div>
          
          <div className="flex items-center gap-2">
            <Button
              onClick={handleDirectView}
              className="bg-blue-600 hover:bg-blue-700 text-white"
            >
              <ExternalLink className="w-4 h-4 mr-2" />
              Open in New Tab
            </Button>
            <Button
              onClick={() => {
                setTestResult('Testing new tab functionality...');
                handleDirectView();
                setTimeout(() => setTestResult('New tab opened! Check if PDF loads properly.'), 1000);
              }}
              variant="outline"
              className="border-green-600 text-green-400 hover:bg-green-600/10"
            >
              <Monitor className="w-4 h-4 mr-2" />
              Test
            </Button>
            <Button
              variant="outline"
              onClick={handleDownload}
              className="border-gray-600 text-gray-300 hover:bg-gray-700"
            >
              <Download className="w-4 h-4 mr-2" />
              Download
            </Button>
          </div>
        </div>
        
        {/* Test result display */}
        {testResult && (
          <div className="mt-3 max-w-screen-xl mx-auto">
            <div className="bg-green-900/20 border-green-600/30 border p-3 rounded-lg">
              <div className="text-green-200 text-sm">{testResult}</div>
            </div>
          </div>
        )}
      </div>

      {/* PDF Viewer */}
      <div className="flex-1 p-4">
        <div className="max-w-screen-xl mx-auto h-full">
          {renderPDFContent()}
        </div>
      </div>
    </div>
  );
};

export default PDFViewer;
