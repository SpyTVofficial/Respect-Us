



import React, { useState, useEffect } from 'react';
import { Bell, Users, BarChart3, FileText, Shield, AlertTriangle, CheckCircle, Clock, UserCheck, Globe, Target, Package, CreditCard, Settings, HelpCircle, ChevronRight, Plus, Search, Filter, Download, Upload, Eye, Trash2, Edit, RefreshCw, Calendar, DollarSign, TrendingUp, Activity, PieChart, XCircle, Mail, Phone, MapPin, Building, Crown, Book } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Progress } from '@/components/ui/progress';
import { Separator } from '@/components/ui/separator';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { useNavigate } from 'react-router-dom';
import { useUserGuardContext } from 'app/auth';
import { toast } from 'sonner';
import brain from 'brain';
import { formatDistanceToNow } from 'date-fns';
import AdminNotificationManager from 'components/AdminNotificationManager';

// Import extracted components
import AdminOverviewTab from 'components/AdminOverviewTab';
import UserManagementTab from 'components/UserManagementTab';
import KnowledgeBaseAdminTab from 'components/KnowledgeBaseAdminTab';
import SystemSettingsTab from 'components/SystemSettingsTab';
import PricingManagementTab from 'components/PricingManagementTab';
import AdminAnalyticsTab from 'components/AdminAnalyticsTab';
import AdminCreditManagementTab from 'components/AdminCreditManagementTab';
import DocumentReferenceText from 'components/DocumentReferenceText';
import ValidationTasks from 'components/ValidationTasks';

import ProductClassificationAdminSimplified from 'components/ProductClassificationAdminSimplified';
import SanctionsManagement from 'components/SanctionsManagement';
import SanctionsListManagement from 'components/SanctionsListManagement';
import RiskAssessmentAdmin from 'components/RiskAssessmentAdmin';
import CriticalCountriesSection from 'components/CriticalCountriesSection';
import AdminAnalyticsDashboard from 'components/AdminAnalyticsDashboard';

function AdminDashboardFixed() {
  const { user } = useUserGuardContext();
  const [activeTab, setActiveTab] = useState('overview');
  const [stats, setStats] = useState<AdminStatsResponse | null>(null);
  const [documents, setDocuments] = useState<AdminDocumentResponse[]>([]);
  const [customers, setCustomers] = useState<CustomerProfile[]>([]);
  const [loading, setLoading] = useState(true);

  // Load admin data
  useEffect(() => {
    const loadAdminData = async () => {
      try {
        setLoading(true);
        
        // Load admin stats
        const statsResponse = await brain.get_admin_stats();
        if (statsResponse.ok) {
          const statsData = await statsResponse.json();
          setStats(statsData);
        }
        
        // Load documents
        const docsResponse = await brain.list_admin_documents({});
        if (docsResponse.ok) {
          const docsData = await docsResponse.json();
          setDocuments(docsData);
        }
        
        // Load customers - properly map the response data
        const customersResponse = await brain.get_all_admin_users();
        if (customersResponse.ok) {
          const customersData = await customersResponse.json();
          // Map admin customers to CustomerProfile format
          const mappedCustomers: CustomerProfile[] = (customersData.customers || []).map((customer: any) => ({
            id: customer.customer_id, // Use customer_id as id
            customer_name: customer.contact_person || customer.company_name || 'Unknown', // Map contact_person to customer_name
            customer_type: customer.company_name !== 'N/A' ? 'company' : 'individual',
            legal_name: customer.company_name !== 'N/A' ? customer.company_name : customer.contact_person,
            address: customer.billing_address,
            city: customer.city,
            country: customer.country,
            postal_code: customer.postal_code,
            tax_id: customer.tax_id,
            phone: customer.phone,
            email: customer.email,
            business_type: customer.company_name !== 'N/A' ? 'company' : 'individual',
            total_purchases: customer.total_purchases,
            total_spent: customer.total_spent
          }));
          setCustomers(mappedCustomers);
        }
        
        console.log('Admin data loaded successfully');
        
      } catch (error) {
        console.error('Error loading admin data:', error);
        toast.error('Failed to load admin data');
      } finally {
        setLoading(false);
      }
    };
    
    loadAdminData();
  }, []);

  const refreshCustomers = async () => {
    try {
      const customersResponse = await brain.get_all_admin_users();
      if (customersResponse.ok) {
        const customersData = await customersResponse.json();
        // Apply the same mapping for refresh
        const mappedCustomers: CustomerProfile[] = (customersData.customers || []).map((customer: any) => ({
          id: customer.customer_id,
          customer_name: customer.contact_person || customer.company_name || 'Unknown',
          customer_type: customer.company_name !== 'N/A' ? 'company' : 'individual',
          legal_name: customer.company_name !== 'N/A' ? customer.company_name : customer.contact_person,
          address: customer.billing_address,
          city: customer.city,
          country: customer.country,
          postal_code: customer.postal_code,
          tax_id: customer.tax_id,
          phone: customer.phone,
          email: customer.email,
          business_type: customer.company_name !== 'N/A' ? 'company' : 'individual',
          total_purchases: customer.total_purchases,
          total_spent: customer.total_spent
        }));
        setCustomers(mappedCustomers);
      }
    } catch (error) {
      console.error('Error refreshing customers:', error);
      toast.error('Failed to refresh customers');
    }
  };

  const refreshDocuments = async () => {
    try {
      const docsResponse = await brain.list_admin_documents({});
      if (docsResponse.ok) {
        const docsData = await docsResponse.json();
        setDocuments(docsData);
      }
    } catch (error) {
      console.error('Error refreshing documents:', error);
      toast.error('Failed to refresh documents');
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-900 text-white flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-white mx-auto mb-4"></div>
          <p className="text-gray-400">Loading admin dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-900 text-white p-6">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-white mb-2">Admin Dashboard</h1>
        <p className="text-gray-400">Manage your export control compliance platform</p>
      </div>

      {/* Main Content Tabs */}
      <div className="bg-gray-800/30 backdrop-blur-sm border border-gray-700 rounded-lg">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="flex flex-wrap w-full bg-gray-800/50 backdrop-blur-sm p-1 gap-1">
            <TabsTrigger 
              value="overview" 
              className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-500 data-[state=active]:to-blue-500 data-[state=active]:text-white"
            >
              <BarChart3 className="h-4 w-4 mr-2" />
              Overview
            </TabsTrigger>
            <TabsTrigger 
              value="users"
              className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-500 data-[state=active]:to-blue-500 data-[state=active]:text-white"
            >
              <Users className="h-4 w-4 mr-2" />
              Users
            </TabsTrigger>
            <TabsTrigger 
              value="tasks"
              className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-500 data-[state=active]:to-blue-500 data-[state=active]:text-white"
            >
              <FileText className="h-4 w-4 mr-2" />
              Tasks
            </TabsTrigger>
            <TabsTrigger 
              value="knowledge-base"
              className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-500 data-[state=active]:to-blue-500 data-[state=active]:text-white"
            >
              <Book className="h-4 w-4 mr-2" />
              Knowledge Base
            </TabsTrigger>
            <TabsTrigger 
              value="product-classification"
              className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-500 data-[state=active]:to-blue-500 data-[state=active]:text-white"
            >
              <Target className="h-4 w-4 mr-2" />
              Product Classification
            </TabsTrigger>
            <TabsTrigger 
              value="sanctions"
              className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-500 data-[state=active]:to-blue-500 data-[state=active]:text-white"
            >
              <Shield className="h-4 w-4 mr-2" />
              Sanctions
            </TabsTrigger>
            <TabsTrigger 
              value="customer-screening"
              className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-500 data-[state=active]:to-blue-500 data-[state=active]:text-white"
            >
              <Users className="h-4 w-4 mr-2" />
              Customer Screening
            </TabsTrigger>
            <TabsTrigger 
              value="end-use-checks"
              className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-500 data-[state=active]:to-blue-500 data-[state=active]:text-white"
            >
              <CheckCircle className="h-4 w-4 mr-2" />
              End-Use Checks
            </TabsTrigger>
            <TabsTrigger 
              value="risk-assessment"
              className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-500 data-[state=active]:to-blue-500 data-[state=active]:text-white"
            >
              <AlertTriangle className="h-4 w-4 mr-2" />
              Risk Assessment
            </TabsTrigger>
            <TabsTrigger 
              value="license-determination"
              className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-500 data-[state=active]:to-blue-500 data-[state=active]:text-white"
            >
              <FileText className="h-4 w-4 mr-2" />
              License Determination
            </TabsTrigger>
            <TabsTrigger 
              value="settings"
              className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-500 data-[state=active]:to-blue-500 data-[state=active]:text-white"
            >
              <Settings className="h-4 w-4 mr-2" />
              Settings
            </TabsTrigger>
            <TabsTrigger 
              value="pricing"
              className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-500 data-[state=active]:to-blue-500 data-[state=active]:text-white"
            >
              <DollarSign className="h-4 w-4 mr-2" />
              Pricing & Credits
            </TabsTrigger>
            <TabsTrigger 
              value="analytics"
              className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-500 data-[state=active]:to-blue-500 data-[state=active]:text-white"
            >
              <TrendingUp className="h-4 w-4 mr-2" />
              Analytics
            </TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            <AdminOverviewTab stats={stats} loading={loading} />
          </TabsContent>

          {/* Users Tab */}
          <TabsContent value="users" className="space-y-6">
            <UserManagementTab 
              users={customers} 
              onRefresh={refreshCustomers}
              loading={loading}
            />
          </TabsContent>

          {/* Tasks Tab */}
          <TabsContent value="tasks" className="space-y-6">
            <div className="bg-gray-800/30 backdrop-blur-sm border border-gray-700 rounded-lg p-6">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h2 className="text-xl font-semibold text-white mb-2">System Tasks & Validation</h2>
                  <p className="text-gray-400">Manage validation tasks and system workflows</p>
                </div>
              </div>
              <ValidationTasks onTaskUpdate={() => console.log('Validation tasks updated')} />
            </div>
          </TabsContent>

          {/* Knowledge Base Tab */}
          <TabsContent value="knowledge-base" className="space-y-6">
            <KnowledgeBaseAdminTab 
              documents={documents} 
              onDocumentsUpdate={refreshDocuments}
              loading={loading}
            />
          </TabsContent>

          {/* Product Classification Tab - Now includes Critical Products as subtab */}
          <TabsContent value="product-classification" className="space-y-6">
            <ProductClassificationAdminSimplified />
          </TabsContent>

          {/* Sanctions & Embargoes Tab */}
          <TabsContent value="sanctions" className="space-y-6">
            <SanctionsManagement onRefresh={() => console.log('Refreshed sanctions')} />
          </TabsContent>

          {/* Customer Screening Tab */}
          <TabsContent value="customer-screening" className="space-y-6">
            <SanctionsListManagement onRefresh={() => console.log('Refreshed sanctions lists')} />
          </TabsContent>

          {/* End-Use Checks Tab */}
          <TabsContent value="end-use-checks" className="space-y-6">
            <div className="bg-gray-800/30 backdrop-blur-sm border border-gray-700 rounded-lg p-6">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h2 className="text-xl font-semibold text-white mb-2">End-Use Checks Management</h2>
                  <p className="text-gray-400">Manage critical countries and end-use compliance checks</p>
                </div>
              </div>
              <CriticalCountriesSection />
            </div>
          </TabsContent>

          {/* Risk Assessment Tab */}
          <TabsContent value="risk-assessment" className="space-y-6">
            <RiskAssessmentAdmin onRefresh={() => console.log('Refreshed risk assessments')} />
          </TabsContent>

          {/* License Determination Tab */}
          <TabsContent value="license-determination" className="space-y-6">
            <div className="bg-gray-800/30 backdrop-blur-sm border border-gray-700 rounded-lg p-6">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h2 className="text-xl font-semibold text-white mb-2">License Determination</h2>
                  <p className="text-gray-400">Manage license requirements and determination workflows</p>
                </div>
              </div>
              
              <div className="text-center py-12">
                <Settings className="h-16 w-16 text-blue-400 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-white mb-2">License Determination Module</h3>
                <p className="text-gray-400 mb-4">
                  License determination functionality will be implemented as part of future development phases.
                </p>
                <p className="text-sm text-gray-500">
                  This module will include automated license requirement analysis, workflow management, and integration with regulatory databases.
                </p>
              </div>
            </div>
          </TabsContent>

          {/* Settings Tab */}
          <TabsContent value="settings" className="space-y-6">
            <SystemSettingsTab loading={loading} />
          </TabsContent>

          {/* Pricing Management Tab */}
          <TabsContent value="pricing" className="space-y-6">
            <AdminCreditManagementTab loading={loading} />
          </TabsContent>

          {/* Analytics Tab */}
          <TabsContent value="analytics" className="space-y-6">
            <AdminAnalyticsTab loading={loading} />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

export default AdminDashboardFixed;
