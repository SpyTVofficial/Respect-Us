import DialogTest from 'components/DialogTest';

export default function DialogTestPage() {
  return (
    <div className="min-h-screen bg-gray-900 text-white">
      <div className="container mx-auto p-8">
        <h1 className="text-2xl font-bold mb-4">Dialog Test Page</h1>
        <DialogTest />
      </div>
    </div>
  );
}
