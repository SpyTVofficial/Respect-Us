import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useUserGuardContext } from 'app/auth';
import brain from 'brain';
import { DocumentResponse } from 'types';

const SearchDebugTest = () => {
  const { user } = useUserGuardContext();
  const [searchQuery, setSearchQuery] = useState('');
  const [results, setResults] = useState<DocumentResponse[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [rawResponse, setRawResponse] = useState<any>(null);

  const testSearch = async () => {
    console.log('Testing search with query:', searchQuery);
    setLoading(true);
    setError(null);
    setRawResponse(null);

    try {
      // Test basic list without search first
      console.log('Testing basic list documents...');
      const basicResponse = await brain.list_documents({ per_page: 5 });
      console.log('Basic response status:', basicResponse.status);
      const basicData = await basicResponse.json();
      console.log('Basic response data:', basicData);

      if (searchQuery.trim()) {
        // Test with search
        console.log('Testing with search query:', searchQuery);
        const searchResponse = await brain.list_documents({ 
          search: searchQuery, 
          per_page: 10 
        });
        console.log('Search response status:', searchResponse.status);
        const searchData = await searchResponse.json();
        console.log('Search response data:', searchData);
        setRawResponse(searchData);
        setResults(searchData.documents || []);
      } else {
        setRawResponse(basicData);
        setResults(basicData.documents || []);
      }
    } catch (err: any) {
      console.error('Search test error:', err);
      setError(err.message || 'Unknown error occurred');
    } finally {
      setLoading(false);
    }
  };

  const testAdvancedSearch = async () => {
    console.log('Testing advanced search...');
    setLoading(true);
    setError(null);

    try {
      const response = await brain.advanced_search_documents({
        query: searchQuery || 'regulation',
        search_mode: 'simple',
        boolean_query: false,
        phrase_query: false,
        wildcard_query: false,
        country_jurisdiction: null,
        regulation_type: null,
        legal_status: null,
        tags: null,
        date_from: null,
        date_to: null,
        limit: 10,
        offset: 0
      });
      
      console.log('Advanced search response status:', response.status);
      const data = await response.json();
      console.log('Advanced search response data:', data);
      setRawResponse(data);
      setResults(data.documents || []);
    } catch (err: any) {
      console.error('Advanced search test error:', err);
      setError(err.message || 'Unknown error occurred');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-950 p-8">
      <div className="max-w-4xl mx-auto space-y-6">
        <Card className="bg-gray-800 border-gray-700">
          <CardHeader>
            <CardTitle className="text-white">Search Debug Test</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex gap-4">
              <Input
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Enter search query (e.g. 'regulation')..."
                className="bg-gray-700 border-gray-600 text-white"
              />
              <Button 
                onClick={testSearch} 
                disabled={loading}
                className="bg-blue-600 hover:bg-blue-700"
              >
                {loading ? 'Testing...' : 'Test Basic Search'}
              </Button>
              <Button 
                onClick={testAdvancedSearch} 
                disabled={loading}
                variant="outline"
                className="border-gray-600 text-gray-300 hover:bg-gray-700"
              >
                Test Advanced Search
              </Button>
            </div>

            {error && (
              <div className="bg-red-900/50 border border-red-700 rounded p-4">
                <p className="text-red-300">Error: {error}</p>
              </div>
            )}

            {rawResponse && (
              <div className="bg-gray-900 border border-gray-600 rounded p-4">
                <h3 className="text-white font-semibold mb-2">Raw API Response:</h3>
                <pre className="text-gray-300 text-sm overflow-x-auto">
                  {JSON.stringify(rawResponse, null, 2)}
                </pre>
              </div>
            )}

            <div className="space-y-4">
              <h3 className="text-white font-semibold">
                Results ({results.length} documents):
              </h3>
              {results.length === 0 ? (
                <p className="text-gray-400">No documents found</p>
              ) : (
                <div className="space-y-2">
                  {results.map((doc) => (
                    <Card key={doc.id} className="bg-gray-700 border-gray-600">
                      <CardContent className="p-4">
                        <h4 className="text-white font-medium">{doc.title}</h4>
                        <p className="text-gray-300 text-sm mt-1">
                          {doc.description?.substring(0, 100)}...
                        </p>
                        <div className="flex gap-2 mt-2">
                          {doc.document_type && (
                            <span className="text-xs bg-blue-600 text-white px-2 py-1 rounded">
                              {doc.document_type}
                            </span>
                          )}
                          {doc.jurisdiction && (
                            <span className="text-xs bg-green-600 text-white px-2 py-1 rounded">
                              {doc.jurisdiction}
                            </span>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default SearchDebugTest;
