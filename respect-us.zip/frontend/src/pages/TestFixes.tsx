import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Loader2, CheckCircle, XCircle, FileText } from 'lucide-react';
import brain from 'brain';
import { PDFViewerButton } from 'components/PDFViewerButton';

const TestFixes = () => {
  const [pdfTest, setPdfTest] = useState<'idle' | 'testing' | 'success' | 'error'>('idle');
  const [pdfError, setPdfError] = useState<string>('');
  const [documentTest, setDocumentTest] = useState<'idle' | 'testing' | 'success' | 'error'>('idle');
  const [documentData, setDocumentData] = useState<any>(null);
  
  // Test PDF loading (document 72)
  const testPdfLoading = async () => {
    setPdfTest('testing');
    setPdfError('');
    
    try {
      console.log('Testing PDF download for document 72...');
      const response = await brain.download_document_file({ documentId: 72 });
      
      if (response.ok) {
        const blob = await response.blob();
        console.log('PDF loaded successfully:', blob.size, 'bytes');
        setPdfTest('success');
      } else {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }
    } catch (error) {
      console.error('PDF test failed:', error);
      setPdfError(error instanceof Error ? error.message : 'Unknown error');
      setPdfTest('error');
    }
  };
  
  // Test unreadable document formatting (document 64)
  const testUnreadableDocument = async () => {
    setDocumentTest('testing');
    setDocumentData(null);
    
    try {
      console.log('Testing unreadable document 64...');
      const response = await brain.get_document({ documentId: 64 });
      
      if (response.ok) {
        const data = await response.json();
        setDocumentData(data);
        setDocumentTest('success');
        console.log('Document data:', data);
      } else {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }
    } catch (error) {
      console.error('Document test failed:', error);
      setDocumentTest('error');
    }
  };
  
  // Helper function to check if content is readable
  const isContentReadable = (content: string) => {
    if (!content || content.length < 100) return false;
    
    const lineBreaks = (content.match(/\n/g) || []).length;
    const sentences = (content.match(/[.!?]/g) || []).length;
    
    const ratio = lineBreaks / (content.length / 100);
    return ratio > 0.5 || sentences > 10;
  };
  
  const shouldShowPDFOnly = documentData && documentData.file_type === 'application/pdf' && 
    (!documentData.content_text || !isContentReadable(documentData.content_text));

  return (
    <div className="min-h-screen bg-gray-900 text-white p-8">
      <div className="max-w-4xl mx-auto space-y-6">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold mb-2">Test PDF & Document Fixes</h1>
          <p className="text-gray-400">Testing the fixes for PDF loading and unreadable document display</p>
        </div>
        
        {/* PDF Loading Test */}
        <Card className="bg-gray-800 border-gray-700">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileText className="w-5 h-5" />
              PDF Loading Test
              {pdfTest === 'success' && <CheckCircle className="w-5 h-5 text-green-500" />}
              {pdfTest === 'error' && <XCircle className="w-5 h-5 text-red-500" />}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-gray-300">
              Testing if PDFs can be loaded using the brain client (Document 72)
            </p>
            
            <div className="flex gap-4">
              <Button 
                onClick={testPdfLoading}
                disabled={pdfTest === 'testing'}
                className="bg-blue-600 hover:bg-blue-700"
              >
                {pdfTest === 'testing' && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                Test PDF Download
              </Button>
              
              {pdfTest === 'success' && (
                <PDFViewerButton
                  documentId={72}
                  documentTitle="Test PDF Document"
                  variant="outline"
                  className="border-green-500 text-green-500 hover:bg-green-600 hover:text-white"
                />
              )}
            </div>
            
            {pdfTest === 'success' && (
              <Badge variant="outline" className="border-green-500 text-green-500">
                ✅ PDF loading works!
              </Badge>
            )}
            
            {pdfTest === 'error' && (
              <div className="text-red-400 text-sm">
                ❌ Error: {pdfError}
              </div>
            )}
          </CardContent>
        </Card>
        
        {/* Unreadable Document Test */}
        <Card className="bg-gray-800 border-gray-700">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileText className="w-5 h-5" />
              Unreadable Document Test
              {documentTest === 'success' && <CheckCircle className="w-5 h-5 text-green-500" />}
              {documentTest === 'error' && <XCircle className="w-5 h-5 text-red-500" />}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-gray-300">
              Testing document with 235k chars but poor formatting (Document 64)
            </p>
            
            <Button 
              onClick={testUnreadableDocument}
              disabled={documentTest === 'testing'}
              className="bg-purple-600 hover:bg-purple-700"
            >
              {documentTest === 'testing' && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
              Test Unreadable Document
            </Button>
            
            {documentData && (
              <div className="space-y-3">
                <div className="text-sm space-y-1">
                  <div><strong>Title:</strong> {documentData.title}</div>
                  <div><strong>File Type:</strong> {documentData.file_type}</div>
                  <div><strong>Content Length:</strong> {documentData.content_text?.length || 0} chars</div>
                  <div><strong>Has Sections:</strong> {documentData.section_count > 0 ? 'Yes' : 'No'}</div>
                </div>
                
                <div className="space-y-2">
                  <div><strong>Readability Test:</strong></div>
                  {documentData.content_text && (
                    <div className="text-sm space-y-1">
                      <div>Line breaks in first 1000 chars: {(documentData.content_text.substring(0, 1000).match(/\n/g) || []).length}</div>
                      <div>Is readable: {isContentReadable(documentData.content_text) ? 'Yes' : 'No'}</div>
                      <div>Should show PDF only: {shouldShowPDFOnly ? 'Yes' : 'No'}</div>
                    </div>
                  )}
                </div>
                
                {shouldShowPDFOnly ? (
                  <div className="space-y-2">
                    <Badge variant="outline" className="border-green-500 text-green-500">
                      ✅ Would trigger PDF-only display!
                    </Badge>
                    <PDFViewerButton
                      documentId={64}
                      documentTitle={documentData.title}
                      variant="default"
                      className="bg-green-600 hover:bg-green-700"
                    />
                  </div>
                ) : (
                  <Badge variant="outline" className="border-yellow-500 text-yellow-500">
                    ⚠️ Would show text content (might still be unreadable)
                  </Badge>
                )}
              </div>
            )}
          </CardContent>
        </Card>
        
        {/* Summary */}
        {(pdfTest === 'success' || pdfTest === 'error') && (documentTest === 'success' || documentTest === 'error') && (
          <Card className="bg-gray-800 border-gray-700">
            <CardHeader>
              <CardTitle>Test Summary</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  {pdfTest === 'success' ? <CheckCircle className="w-4 h-4 text-green-500" /> : <XCircle className="w-4 h-4 text-red-500" />}
                  <span>PDF Loading: {pdfTest === 'success' ? 'Fixed' : 'Still broken'}</span>
                </div>
                <div className="flex items-center gap-2">
                  {shouldShowPDFOnly ? <CheckCircle className="w-4 h-4 text-green-500" /> : <XCircle className="w-4 h-4 text-red-500" />}
                  <span>Unreadable Document Display: {shouldShowPDFOnly ? 'Fixed (PDF-only)' : 'Needs work'}</span>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
};

export default TestFixes;
