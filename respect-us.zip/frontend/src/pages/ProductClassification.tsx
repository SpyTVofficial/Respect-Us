import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Separator } from '@/components/ui/separator';
import { ArrowLeft, Loader2, FileText, Info, Package, CheckCircle, Download, AlertCircle, GitBranch, Shield, Globe, Clock, Users, CheckSquare, ArrowRight, BookOpen, Search, Database, AlertTriangle, Workflow, Target, TreePine, Play, RotateCcw, Eye, FileDown, ChevronRight, User } from 'lucide-react';
import { toast } from 'sonner';
import brain from 'brain';
import WorkflowSelector from 'components/WorkflowSelector';
import DecisionNode from 'components/DecisionNode';
import OutcomeDisplay from 'components/OutcomeDisplay';
import CriticalProductsSearch from 'components/CriticalProductsSearch';
import CriticalProductsSectionContent from 'components/CriticalProductsSectionContent';
import { MultiQuestionAssessment } from 'components/MultiQuestionAssessment';
import { jsPDF } from 'jspdf';
import Navigation from 'components/Navigation';
import type {
  ClassificationWorkflow,
  TreeNode,
  NodeOption,
  ClassificationOutcome,
  DecisionPathItem,
  ClassificationTree,
  NavigationRequest
} from '../brain/data-contracts';

interface ClassificationNode {
  id: string;
  node_key: string;
  title: string;
  description?: string;
  question_text: string;
  question_type: string;
}

interface ClassificationOption {
  id: string;
  option_text: string;
  option_value: string;
  routing_rule?: string;
  regulatory_notes?: string[];
  note?: string;
}

interface NavigationResponse {
  type: 'node' | 'outcome' | 'outcome_with_continuation';
  node?: ClassificationNode;
  options?: ClassificationOption[];
  outcome?: ClassificationOutcome;
  continuation?: {
    type: 'node' | 'tree';
    node?: ClassificationNode;
    options?: ClassificationOption[];
    tree?: {
      id: string;
      name: string;
      description?: string;
      jurisdiction: string;
      category: string;
    };
  };
  decision_path?: Array<{
    node_title: string;
    selected_option: string;
    timestamp: string;
  }>;
}

const ProductClassification = () => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('workflow');
  const tabsRef = React.useRef<HTMLDivElement>(null);
  
  // Classification workflow state
  const [workflows, setWorkflows] = useState<ClassificationWorkflow[]>([]);
  const [selectedWorkflow, setSelectedWorkflow] = useState<ClassificationWorkflow | null>(null);
  const [currentNode, setCurrentNode] = useState<TreeNode | null>(null);
  const [currentOptions, setCurrentOptions] = useState<NodeOption[]>([]);
  const [loading, setLoading] = useState(false);
  const [workflowStarted, setWorkflowStarted] = useState(false);
  const [decisionPath, setDecisionPath] = useState<Array<{ node_title: string; selected_option: string; timestamp: string }>>([]);
  const [currentOutcome, setCurrentOutcome] = useState<ClassificationOutcome | null>(null);
  const [showOutcome, setShowOutcome] = useState(false);
  const [currentTreeName, setCurrentTreeName] = useState<string>('');

  // Auto-scroll to tabs when tab changes
  const scrollToTabs = () => {
    if (tabsRef.current) {
      tabsRef.current.scrollIntoView({ 
        behavior: 'smooth', 
        block: 'start' 
      });
    }
  };

  // Handle tab change with auto-scroll
  const handleTabChange = (value: string) => {
    setActiveTab(value);
    // Small delay to ensure the tab content has rendered
    setTimeout(() => {
      scrollToTabs();
    }, 100);
  };

  // Handle card click - simple and working
  const handleCardClick = (tabValue: string) => {
    // Switch to the correct tab
    setActiveTab(tabValue);
    
    // Small delay to let the tab content render, then scroll
    setTimeout(() => {
      const tabsElement = document.querySelector('[data-tabs-section]');
      if (tabsElement) {
        tabsElement.scrollIntoView({ 
          behavior: 'smooth', 
          block: 'start' 
        });
      }
    }, 150);
  };

  // Load workflows on component mount
  useEffect(() => {
    loadWorkflows();
  }, []);

  const loadWorkflows = async () => {
    try {
      setLoading(true);
      const response = await brain.list_workflows({ workflow_type: 'classification' });
      const data = await response.json();
      // API returns direct array when filtered, not wrapped in {workflows: []}
      const workflowsArray = Array.isArray(data) ? data : data.workflows || [];
      setWorkflows(workflowsArray);
    } catch (error) {
      console.error('Error loading workflows:', error);
      toast.error('Failed to load classification workflows');
    } finally {
      setLoading(false);
    }
  };

  const startWorkflow = async (workflow: ClassificationWorkflow) => {
    try {
      setLoading(true);
      setSelectedWorkflow(workflow);
      
      if (!workflow.introduction_tree_id) {
        toast.error('This workflow does not have an introduction tree configured');
        return;
      }

      const response = await brain.get_published_workflow({
        workflowId: workflow.id
      });
      const workflowData = await response.json();
      
      if (workflowData.introduction_tree) {
        const nodesResponse = await brain.list_introduction_tree_nodes({
          treeId: workflowData.introduction_tree.id
        });
        const nodesData = await nodesResponse.json();
        
        if (nodesData.length > 0) {
          const rootNode = nodesData.find(node => node.is_root) || nodesData[0];
          setCurrentNode(rootNode);
          setCurrentTreeName(workflowData.introduction_tree.name || 'Introduction');
          
          const optionsResponse = await brain.list_introduction_node_options({
            nodeId: rootNode.id
          });
          const optionsData = await optionsResponse.json();
          setCurrentOptions(optionsData);
          
          setWorkflowStarted(true);
          setDecisionPath([]);
        } else {
          toast.error('No nodes found in this introduction tree');
        }
      } else {
        toast.error('Introduction tree data not available for this workflow');
      }
    } catch (error) {
      console.error('Error starting workflow:', error);
      toast.error('Failed to start workflow');
    } finally {
      setLoading(false);
    }
  };

  const handleOptionSelect = async (option: NodeOption) => {
    try {
      setLoading(true);
      
      // Add to decision path
      const newPathEntry = {
        node_title: currentNode?.title || '',
        selected_option: option.option_text,
        timestamp: new Date().toISOString()
      };
      setDecisionPath(prev => [...prev, newPathEntry]);

      const navigationRequest: NavigationRequest = {
        option_id: option.id,
        option_value: option.option_value
      };

      const response = await brain.assess_sanctions_applicability(navigationRequest);
      const result: NavigationResponse = await response.json();

      if (result.type === 'node' && result.node) {
        setCurrentNode(result.node);
        setCurrentOptions(result.options || []);
      } else if (result.type === 'outcome' && result.outcome) {
        setCurrentOutcome(result.outcome);
        setShowOutcome(true);
      } else if (result.type === 'outcome_with_continuation' && result.outcome && result.continuation) {
        setCurrentOutcome(result.outcome);
        setShowOutcome(true);
        
        // Handle continuation logic here if needed
        if (result.continuation.type === 'tree' && result.continuation.tree) {
          // Transition to classification tree
          setCurrentTreeName(result.continuation.tree.name || 'Classification');
        } else if (result.continuation.type === 'node' && result.continuation.node) {
          setCurrentNode(result.continuation.node);
          setCurrentOptions(result.continuation.options || []);
        }
      }
    } catch (error) {
      console.error('Error navigating:', error);
      toast.error('Failed to process selection');
    } finally {
      setLoading(false);
    }
  };

  const resetWorkflow = () => {
    setSelectedWorkflow(null);
    setCurrentNode(null);
    setCurrentOptions([]);
    setWorkflowStarted(false);
    setDecisionPath([]);
    setCurrentOutcome(null);
    setShowOutcome(false);
    setCurrentTreeName('');
  };

  // Method B: Critical Products Database Import Functions
  const handleImportFile = async () => {
    const fileInput = document.getElementById('import-file') as HTMLInputElement;
    const file = fileInput?.files?.[0];
    
    if (!file) {
      toast.error('Please select a file to import');
      return;
    }

    if (!file.name.match(/\.(xlsx|xls|csv)$/i)) {
      toast.error('Please select an Excel (.xlsx, .xls) or CSV file');
      return;
    }

    try {
      setLoading(true);
      const response = await brain.import_critical_products({ file });
      const result = await response.json();
      
      if (response.ok) {
        toast.success(`Successfully imported ${result.imported_count || 0} products. ${result.skipped_count || 0} skipped.`);
        // Clear the file input
        fileInput.value = '';
      } else {
        toast.error(result.detail || 'Import failed');
      }
    } catch (error) {
      console.error('Import error:', error);
      toast.error('Failed to import file. Please check the format and try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleDownloadTemplate = async () => {
    try {
      const response = await brain.download_critical_products_excel_template();
      
      if (response.ok) {
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'critical_products_template.xlsx';
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        document.body.removeChild(a);
        
        toast.success('Excel template downloaded successfully');
      } else {
        toast.error('Failed to download template');
      }
    } catch (error) {
      console.error('Download error:', error);
      toast.error('Failed to download template');
    }
  };

  const exportCurrentData = async () => {
    try {
      setLoading(true);
      // Use the existing export endpoint
      const response = await fetch('/api/critical_products/export?format=xlsx', {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${await import('app/auth').then(m => m.auth.getAuthToken())}`
        }
      });
      
      if (response.ok) {
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = `critical_products_export_${new Date().toISOString().split('T')[0]}.xlsx`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        window.URL.revokeObjectURL(url);
        toast.success('Database export downloaded successfully');
      } else {
        toast.error('Failed to export database');
      }
    } catch (error) {
      console.error('Export error:', error);
      toast.error('Failed to export database');
    } finally {
      setLoading(false);
    }
  };

  const exportToPDF = () => {
    if (!currentOutcome || !selectedWorkflow) return;

    const doc = new jsPDF();
    const pageWidth = doc.internal.pageSize.width;
    const margin = 20;
    let yPosition = 30;

    // Title
    doc.setFontSize(20);
    doc.setFont('helvetica', 'bold');
    doc.text('Product Classification Report', pageWidth / 2, yPosition, { align: 'center' });
    yPosition += 20;

    // Workflow info
    doc.setFontSize(12);
    doc.setFont('helvetica', 'normal');
    doc.text(`Workflow: ${selectedWorkflow.name}`, margin, yPosition);
    yPosition += 10;
    doc.text(`Date: ${new Date().toLocaleDateString()}`, margin, yPosition);
    yPosition += 20;

    // Classification result
    doc.setFontSize(14);
    doc.setFont('helvetica', 'bold');
    doc.text('Classification Result:', margin, yPosition);
    yPosition += 15;

    doc.setFontSize(12);
    doc.setFont('helvetica', 'normal');
    doc.text(`Code: ${currentOutcome.outcome_code}`, margin, yPosition);
    yPosition += 10;
    doc.text(`Title: ${currentOutcome.outcome_title}`, margin, yPosition);
    yPosition += 10;

    if (currentOutcome.description) {
      doc.text('Description:', margin, yPosition);
      yPosition += 8;
      const description = doc.splitTextToSize(currentOutcome.description, pageWidth - 2 * margin);
      doc.text(description, margin, yPosition);
      yPosition += description.length * 6;
    }

    // Decision path
    if (decisionPath.length > 0) {
      yPosition += 10;
      doc.setFont('helvetica', 'bold');
      doc.text('Decision Path:', margin, yPosition);
      yPosition += 10;
      
      doc.setFont('helvetica', 'normal');
      decisionPath.forEach((step, index) => {
        doc.text(`${index + 1}. ${step.node_title}: ${step.selected_option}`, margin + 5, yPosition);
        yPosition += 8;
      });
    }

    doc.save('product-classification-report.pdf');
    toast.success('Classification report exported successfully');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900">
      {/* Uniform Navigation */}
      <Navigation currentPage="product_classification" />
      
      {/* Module-specific Sub-header */}
      <div className="bg-gray-950/80 backdrop-blur-lg border-b border-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-3 py-4">
            <div className="p-2 bg-gradient-to-r from-purple-500 to-blue-500 rounded-lg">
              <Package className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-white">Product Classification</h1>
              <p className="text-sm text-gray-400">Determine export control classifications for your products</p>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        {/* Main Tabs */}
        <div className="container mx-auto px-4" data-tabs-section>
          <Tabs value={activeTab} onValueChange={handleTabChange} className="w-full">
            <TabsList className="grid w-full grid-cols-2 bg-gray-800/50 border-gray-700">
              <TabsTrigger 
                value="workflow" 
                className="data-[state=active]:bg-purple-600 data-[state=active]:text-white text-gray-300"
              >
                <div className="flex items-center gap-2">
                  <Workflow className="h-4 w-4" />
                  Classification Workflow
                </div>
              </TabsTrigger>
              <TabsTrigger 
                value="critical-products" 
                className="data-[state=active]:bg-blue-600 data-[state=active]:text-white text-gray-300"
              >
                <div className="flex items-center gap-2">
                  <Database className="h-4 w-4" />
                  Critical Products Database
                </div>
              </TabsTrigger>
            </TabsList>

            {/* Classification Workflow Tab */}
            <TabsContent value="workflow" className="space-y-6">
              {!workflowStarted ? (
                <>
                  {/* Header */}
                  <div className="text-center py-8">
                    <div className="max-w-4xl mx-auto">
                      <div className="flex justify-center mb-6">
                        <div className="relative">
                          <div className="absolute inset-0 bg-gradient-to-r from-purple-500/20 to-blue-500/20 rounded-full blur-xl transform scale-150"></div>
                          <div className="relative bg-gradient-to-r from-purple-500 to-blue-500 p-6 rounded-2xl">
                            <Package className="h-16 w-16 text-white" />
                          </div>
                        </div>
                      </div>
                      
                      <h1 className="text-4xl font-bold mb-4 bg-gradient-to-r from-purple-400 to-blue-400 bg-clip-text text-transparent">
                        Product Classification
                      </h1>
                      <p className="text-xl text-gray-300 mb-8 leading-relaxed max-w-3xl mx-auto">
                        Determine the correct export control classification for your products. 
                        Our guided workflow helps you navigate complex regulations and ensures compliance.
                      </p>
                    </div>
                  </div>

                  {/* Explanatory Section - After Title and Subtitle */}
                  <CriticalProductsSectionContent 
                    sectionType="product-classification" 
                    className="mb-8"
                  />
                  
                  {/* Workflow Selection */}
                  {loading ? (
                    <div className="flex justify-center py-12">
                      <Loader2 className="h-8 w-8 animate-spin text-purple-400" />
                    </div>
                  ) : (
                    <div className="grid gap-6">
                      <h2 className="text-2xl font-semibold text-white mb-4">Available Classification Workflows</h2>
                      {workflows.map((workflow) => (
                        <Card key={workflow.id} className="bg-gray-800/50 backdrop-blur-sm border-gray-700 hover:border-purple-500/50 transition-colors">
                          <CardHeader>
                            <div className="flex justify-between items-start">
                              <div>
                                <CardTitle className="text-white flex items-center gap-2">
                                  <GitBranch className="h-5 w-5 text-purple-400" />
                                  {workflow.name}
                                </CardTitle>
                                {workflow.description && (
                                  <CardDescription className="text-gray-300 mt-2">
                                    {workflow.description}
                                  </CardDescription>
                                )}
                              </div>
                              <Badge variant="outline" className="border-green-500/50 text-green-400">
                                {workflow.status}
                              </Badge>
                            </div>
                          </CardHeader>
                          <CardContent>
                            <div className="flex justify-between items-center">
                              <div className="flex items-center gap-4 text-sm text-gray-400">
                                {workflow.introduction_tree_name && (
                                  <span className="flex items-center gap-1">
                                    <BookOpen className="h-4 w-4" />
                                    {workflow.introduction_tree_name}
                                  </span>
                                )}
                                {workflow.pricing_tier && (
                                  <Badge variant="secondary" className="bg-blue-500/20 text-blue-400">
                                    {workflow.pricing_tier}
                                  </Badge>
                                )}
                              </div>
                              <Button 
                                onClick={() => startWorkflow(workflow)}
                                className="bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600"
                              >
                                Start Classification
                                <ArrowRight className="h-4 w-4 ml-2" />
                              </Button>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  )}
                </>
              ) : (
                // Active Workflow Content
                <div className="space-y-6">
                  {/* Workflow Header */}
                  <div className="flex justify-between items-center">
                    <div>
                      <h1 className="text-3xl font-bold text-white mb-2">{selectedWorkflow?.name}</h1>
                      <p className="text-gray-400">Current Step: {currentTreeName}</p>
                    </div>
                    <div className="flex gap-3">
                      {showOutcome && currentOutcome && (
                        <Button 
                          onClick={exportToPDF}
                          variant="outline"
                          className="border-green-500/50 text-green-400 hover:bg-green-500/10"
                        >
                          <Download className="h-4 w-4 mr-2" />
                          Export Report
                        </Button>
                      )}
                      <Button 
                        onClick={resetWorkflow}
                        variant="outline"
                        className="border-gray-600 text-gray-300 hover:bg-gray-700"
                      >
                        Reset Workflow
                      </Button>
                    </div>
                  </div>

                  {/* Decision Path */}
                  {decisionPath.length > 0 && (
                    <Card className="bg-gray-800/30 backdrop-blur-sm border-gray-700">
                      <CardHeader>
                        <CardTitle className="text-white text-lg flex items-center gap-2">
                          <GitBranch className="h-5 w-5 text-purple-400" />
                          Decision Path
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-2">
                          {decisionPath.map((step, index) => (
                            <div key={index} className="flex items-center gap-3 text-sm">
                              <Badge variant="outline" className="bg-purple-500/20 text-purple-400 border-purple-500/50">
                                {index + 1}
                              </Badge>
                              <span className="text-gray-300">
                                <span className="font-medium">{step.node_title}:</span>
                                <span className="ml-2 text-blue-400">{step.selected_option}</span>
                              </span>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  )}

                  {/* Classification Outcome */}
                  {showOutcome && currentOutcome ? (
                    <Card className="bg-gradient-to-r from-green-900/20 to-blue-900/20 backdrop-blur-sm border-green-500/30">
                      <CardHeader>
                        <CardTitle className="text-white text-xl flex items-center gap-2">
                          <CheckCircle className="h-6 w-6 text-green-400" />
                          Classification Result
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <div className="grid md:grid-cols-2 gap-4">
                          <div>
                            <Label className="text-sm font-medium text-gray-300">Classification Code</Label>
                            <div className="mt-1">
                              <Badge className="bg-green-500/20 text-green-400 border-green-500/50">
                                {currentOutcome.outcome_code}
                              </Badge>
                            </div>
                          </div>
                          <div>
                            <Label className="text-sm font-medium text-gray-300">Classification Title</Label>
                            <p className="mt-1 text-white font-medium">{currentOutcome.outcome_title}</p>
                          </div>
                        </div>
                        
                        {currentOutcome.description && (
                          <div>
                            <Label className="text-sm font-medium text-gray-300">Description</Label>
                            <p className="mt-1 text-gray-300 leading-relaxed">{currentOutcome.description}</p>
                          </div>
                        )}
                        
                        {currentOutcome.regulatory_basis && (
                          <div>
                            <Label className="text-sm font-medium text-gray-300">Regulatory Basis</Label>
                            <p className="mt-1 text-gray-300 leading-relaxed">{currentOutcome.regulatory_basis}</p>
                          </div>
                        )}
                        
                        {currentOutcome.guidance_notes && currentOutcome.guidance_notes.length > 0 && (
                          <div>
                            <Label className="text-sm font-medium text-gray-300">Guidance Notes</Label>
                            <ul className="mt-1 space-y-1">
                              {currentOutcome.guidance_notes.map((note, index) => (
                                <li key={index} className="text-gray-300 text-sm flex items-start gap-2">
                                  <Info className="h-4 w-4 text-blue-400 mt-0.5 flex-shrink-0" />
                                  {note}
                                </li>
                              ))}
                            </ul>
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  ) : (
                    // Current Question
                    currentNode && (
                      <Card className="bg-gray-800/30 backdrop-blur-sm border-gray-700">
                        <CardHeader>
                          <CardTitle className="text-white text-xl">{currentNode.title}</CardTitle>
                          {currentNode.description && (
                            <CardDescription className="text-gray-300 text-base leading-relaxed">
                              {currentNode.description}
                            </CardDescription>
                          )}
                        </CardHeader>
                        <CardContent>
                          {currentNode.question_type === 'multi_question' ? (
                            <MultiQuestionAssessment
                              node={currentNode}
                              treeId={selectedWorkflow?.introduction_tree_id || ''}
                              onComplete={(responses) => {
                                // Handle multi-question completion
                                console.log('Multi-question responses:', responses);
                              }}
                              treeType="classification"
                            />
                          ) : (
                            <div className="space-y-4">
                              <div className="space-y-3">
                                <Label className="text-lg font-medium text-white">{currentNode.question_text}</Label>
                                {loading ? (
                                  <div className="flex justify-center py-8">
                                    <Loader2 className="h-6 w-6 animate-spin text-purple-400" />
                                  </div>
                                ) : (
                                  <div className="grid gap-3">
                                    {currentOptions.map((option) => (
                                      <Button
                                        key={option.id}
                                        onClick={() => handleOptionSelect(option)}
                                        variant="outline"
                                        className="justify-start text-left h-auto p-4 border-gray-600 hover:border-purple-500/50 hover:bg-purple-500/10 text-white"
                                      >
                                        <div className="space-y-1">
                                          <div className="font-medium">{option.option_text}</div>
                                          {option.note && (
                                            <div className="text-sm text-gray-400">{option.note}</div>
                                          )}
                                        </div>
                                      </Button>
                                    ))}
                                  </div>
                                )}
                              </div>
                            </div>
                          )}
                        </CardContent>
                      </Card>
                    )
                  )}
                </div>
              )}
            </TabsContent>

            {/* Critical Products Database Tab */}
            <TabsContent value="critical-products" className="space-y-6">
              <div className="space-y-6">
                {/* Critical Products Header */}
                <div className="text-center py-8">
                  <div className="max-w-4xl mx-auto">
                    <div className="flex justify-center mb-6">
                      <div className="relative">
                        <div className="absolute inset-0 bg-gradient-to-r from-purple-500/20 to-blue-500/20 rounded-full blur-xl transform scale-150"></div>
                        <div className="relative bg-gradient-to-r from-purple-500 to-blue-500 p-6 rounded-2xl">
                          <Database className="h-16 w-16 text-white" />
                        </div>
                      </div>
                    </div>
                    
                    <h1 className="text-4xl font-bold mb-4 bg-gradient-to-r from-purple-400 to-blue-400 bg-clip-text text-transparent">
                      Critical Products Database
                    </h1>
                    <p className="text-xl text-gray-300 mb-8 leading-relaxed max-w-3xl mx-auto">
                      Search our comprehensive database of critical and sensitive products. 
                      Find detailed information about export control classifications, restrictions, and regulatory requirements.
                    </p>
                  </div>
                </div>

                {/* Critical Products Search Component */}
                <CriticalProductsSearch />
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
};

export default ProductClassification;
