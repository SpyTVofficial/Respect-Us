

import React from "react";
import { UserButton, useUser } from "@stackframe/react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useNavigate } from "react-router-dom";
import Footer from 'components/Footer';
import { 
  BookOpen, 
  Package, 
  Shield, 
  Users, 
  Target, 
  AlertTriangle, 
  FileText,
  CheckCircle,
  ArrowRight,
  Globe,
  Star,
  TrendingUp,
  Lock,
  Zap,
  BarChart3
} from "lucide-react";

interface Country {
  name: string;
  flag: string;
}

interface Module {
  id: string;
  title: string;
  description: string;
  icon: React.ComponentType<any>;
  color: string;
  iconColor: string;
  available: boolean;
  route: string;
  status: string;
  countries?: Country[];
}

const modules: Module[] = [
  {
    id: "knowledge-base",
    title: "Knowledge Base",
    description: "Access regulatory documentation and compliance resources from 50+ jurisdictions",
    icon: FileText,
    color: "bg-blue-500/10 hover:bg-blue-500/20 border border-blue-500/30",
    iconColor: "text-blue-400",
    available: true,
    route: "/knowledge-base",
    status: "ACTIVE"
  },
  {
    id: "product-classification",
    title: "Product Classification",
    description: "Classify products and technologies for export control purposes",
    icon: Package,
    color: "bg-green-500/10 hover:bg-green-500/20 border border-green-500/30",
    iconColor: "text-green-400",
    available: true,
    route: "/product-classification",
    status: "ACTIVE"
  },
  {
    id: "sanctions-embargoes",
    title: "Sanctions & Embargoes",
    description: "Monitor and manage sanctions compliance across jurisdictions",
    icon: Globe,
    color: "bg-red-500/10 hover:bg-red-500/20 border border-red-500/30",
    iconColor: "text-red-400",
    available: true,
    route: "/sanctions-embargoes",
    status: "ACTIVE"
  },
  {
    id: "customer-screening",
    title: "Customer Screening",
    description: "Screen customers and parties against global watchlists",
    icon: Users,
    color: "bg-purple-500/10 hover:bg-purple-500/20 border border-purple-500/30",
    iconColor: "text-purple-400",
    available: true,
    route: "/customer-screening",
    status: "ACTIVE"
  },
  {
    id: "end-use-check",
    title: "End-use Check",
    description: "Verify end-use and end-user compliance requirements",
    icon: Target,
    color: "bg-orange-500/10 hover:bg-orange-500/20 border border-orange-500/30",
    iconColor: "text-orange-400",
    available: true,
    route: "/end-use-checks",
    status: "ACTIVE"
  },
  {
    id: "risk-assessment",
    title: "Risk Assessment",
    description: "Assess and manage comprehensive compliance risks",
    icon: BarChart3,
    color: "bg-yellow-500/10 hover:bg-yellow-500/20 border border-yellow-500/30",
    iconColor: "text-yellow-400",
    available: true,
    route: "/risk-assessment",
    status: "ACTIVE"
  },
  {
    id: "license-determination",
    title: "License Determination",
    description: "Determine licensing requirements and obligations",
    icon: Shield,
    color: "bg-indigo-500/10 hover:bg-indigo-500/20 border border-indigo-500/30",
    iconColor: "text-indigo-400",
    available: false,
    route: "/LicenseDetermination",
    status: "COMING SOON"
  }
];

const features = [
  {
    icon: Globe,
    title: "Global Coverage",
    description: "Comprehensive export control regulations from 50+ jurisdictions worldwide"
  },
  {
    icon: Zap,
    title: "Real-time Updates",
    description: "Live monitoring of regulatory changes and sanctions updates"
  },
  {
    icon: Lock,
    title: "Pay-As-You-Use",
    description: "Flexible credit-based pricing - only pay for what you use with transparent costs"
  },
  {
    icon: TrendingUp,
    title: "Advanced Analytics",
    description: "Comprehensive reporting and risk analytics for informed decisions"
  }
];

export default function App() {
  const navigate = useNavigate();
  const user = useUser();
  
  const handleModuleClick = (module: Module) => {
    if (module.available && module.route) {
      if (user) {
        navigate(module.route);
      } else {
        // Navigate to sign-in if not authenticated
        navigate('/auth/sign-in');
      }
    }
  };

  const handleGetStarted = () => {
    if (user) {
      navigate('/user-dashboard');
    } else {
      navigate('/auth/sign-up');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-black">
      {/* Header with Auth Buttons */}
      <header className="relative z-50">
        <div className="max-w-7xl mx-auto px-6 py-6">
          <div className="flex justify-between items-center">
            {/* Left side - could add navigation links later */}
            <div></div>
            
            {/* Right side - Auth buttons */}
            <div className="flex items-center space-x-4">
              {user ? (
                <div className="flex items-center space-x-4">
                  <Button 
                    onClick={() => navigate('/user-dashboard')}
                    variant="outline" 
                    className="border-gray-600 text-white hover:bg-gray-800/50"
                  >
                    Dashboard
                  </Button>
                  <UserButton />
                </div>
              ) : (
                <>
                  <Button 
                    onClick={() => navigate('/auth/sign-in')}
                    variant="outline" 
                    className="border-gray-600 text-white hover:bg-gray-800/50"
                  >
                    Login
                  </Button>
                  <Button 
                    onClick={() => navigate('/auth/sign-up')}
                    className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white"
                  >
                    Register
                  </Button>
                </>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative overflow-hidden">
        {/* Background gradient */}
        <div className="absolute inset-0 bg-gradient-to-r from-purple-900/20 via-blue-900/20 to-purple-900/20" />
        
        <div className="relative max-w-7xl mx-auto px-6 py-24 lg:py-32">
          <div className="text-center space-y-8">
            {/* Logo at Top */}
            <div className="flex justify-center mb-8">
              <img 
                src="https://static.databutton.com/public/a180dafe-f6c8-4fb7-917a-f8d4b9bfe1b1/White_svg.svg" 
                alt="RespectUs Logo" 
                className="h-32 w-auto lg:h-44"
              />
            </div>
            
            {/* Hero Title */}
            <h1 className="text-4xl lg:text-6xl font-bold text-white leading-tight">
              Export Control Compliance
              <span className="block text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-blue-400">
                Redefined
              </span>
              <span className="block text-2xl lg:text-3xl mt-4 text-gray-300 font-medium">
                by RespectUs
              </span>
            </h1>
            
            {/* Hero Description */}
            <p className="text-xl lg:text-2xl text-gray-300 max-w-4xl mx-auto leading-relaxed">
              Navigate complex export control regulations with confidence. 
              Our comprehensive digital platform provides 7 essential compliance modules 
              for modern export control professionals.
            </p>
            
            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center pt-8">
              <Button 
                onClick={handleGetStarted}
                size="lg" 
                className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white px-8 py-6 text-lg font-semibold"
              >
                {user ? 'Go to Dashboard' : 'Get Started Free'}
                <ArrowRight className="ml-2 w-5 h-5" />
              </Button>
              <Button 
                variant="outline" 
                size="lg" 
                onClick={() => navigate('/KnowledgeBase')}
                className="border-gray-600 text-white hover:bg-gray-800/50 px-8 py-6 text-lg"
              >
                Explore Knowledge Base
              </Button>
            </div>
            
            {/* Trust Indicators */}
            <div className="flex items-center justify-center space-x-8 pt-12 text-gray-400">
              <div className="flex items-center space-x-2">
                <Globe className="w-5 h-5 text-purple-400" />
                <span>50+ Jurisdictions</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-gray-900/50">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-16">
            <h3 className="text-3xl lg:text-4xl font-bold text-white mb-4">
              Built for Compliance Professionals
            </h3>
            <p className="text-xl text-gray-400 max-w-2xl mx-auto">
              Advanced features designed to streamline your export control compliance workflow
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => {
              const IconComponent = feature.icon;
              return (
                <Card key={index} className="bg-gray-800/50 border-gray-700/50 backdrop-blur-sm hover:bg-gray-800/70 transition-all duration-300">
                  <CardContent className="p-6 text-center">
                    <div className="w-16 h-16 bg-gray-700/50 rounded-full flex items-center justify-center mx-auto mb-4">
                      <IconComponent className="w-8 h-8 text-purple-400" />
                    </div>
                    <h4 className="text-lg font-semibold text-white mb-2">{feature.title}</h4>
                    <p className="text-gray-400 text-sm leading-relaxed">{feature.description}</p>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* Modules Section */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-16">
            <h3 className="text-3xl lg:text-4xl font-bold text-white mb-4">
              7 Essential Compliance Modules
            </h3>
            <p className="text-xl text-gray-400 max-w-3xl mx-auto">
              Comprehensive coverage of all export control compliance requirements, 
              from basic documentation to advanced risk assessment
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {modules.map((module) => {
              const IconComponent = module.icon;
              return (
                <Card 
                  key={module.id} 
                  onClick={() => handleModuleClick(module)}
                  className={`${module.color} backdrop-blur-sm transition-all duration-300 hover:shadow-xl hover:shadow-gray-900/50 cursor-pointer group relative overflow-hidden ${!module.available ? 'opacity-80' : ''}`}
                >
                  {/* Glass overlay effect */}
                  <div className="absolute inset-0 bg-gradient-to-br from-white/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                  
                  <CardHeader className="pb-4 relative z-10">
                    <div className="flex items-center justify-between mb-4">
                      {module.id === 'countries' ? (
                        <div className="w-12 h-12 bg-gray-900/50 rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                          <Globe className={`w-6 h-6 ${module.iconColor}`} />
                        </div>
                      ) : (
                        <div className={`w-12 h-12 ${module.iconColor} bg-gray-900/50 rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform duration-300`}>
                          <IconComponent className="w-6 h-6" />
                        </div>
                      )}
                      <Badge 
                        variant="outline"
                        className={`text-xs ${
                          module.status === 'Free' ? 'border-green-500/30 text-green-400 bg-green-500/10' :
                          module.status === 'Premium' ? 'border-purple-500/30 text-purple-400 bg-purple-500/10' :
                          'border-gray-500/30 text-gray-400 bg-gray-500/10'
                        }`}
                      >
                        {module.status}
                      </Badge>
                    </div>
                    <CardTitle className="text-lg font-bold text-white tracking-tight">
                      {module.title}
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="pt-0 relative z-10">
                    <CardDescription className="text-gray-300 mb-6 leading-relaxed text-sm">
                      {module.description}
                    </CardDescription>
                    
                    {/* Special content for Countries module */}
                    {module.id === 'countries' && module.countries && (
                      <div className="mb-6 space-y-2">
                        <div className="text-xs text-gray-400 mb-3">Available Countries:</div>
                        <div className="grid grid-cols-1 gap-2">
                          {module.countries.map((country, index) => (
                            <div key={index} className="flex items-center justify-between p-2 bg-gray-900/30 rounded border border-gray-700/50">
                              <div className="flex items-center space-x-3">
                                <span className="text-lg">{country.flag}</span>
                                <span className="text-sm text-gray-300">{country.name}</span>
                              </div>
                              <Badge variant="outline" className="text-xs border-amber-500/30 text-amber-400 bg-amber-500/10">
                                Coming Soon
                              </Badge>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                    
                    <Button 
                      variant="outline" 
                      size="sm" 
                      disabled={!module.available}
                      className="w-full bg-gray-900/30 hover:bg-gray-800/50 border-gray-600/50 text-white hover:text-white hover:border-gray-500/70 transition-all duration-200"
                    >
                      {module.available ? 'Access Module' : 'Coming Soon'}
                      {module.available && <ArrowRight className="ml-2 w-3 h-3" />}
                    </Button>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-20 bg-gray-900/50">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-16">
            <h3 className="text-3xl lg:text-4xl font-bold text-white mb-4">
              Trusted by Compliance Professionals
            </h3>
            <p className="text-xl text-gray-400">
              Join the growing community of export control experts using RespectUs
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="text-4xl lg:text-5xl font-bold text-purple-400 mb-2">50+</div>
              <div className="text-gray-400">Jurisdictions Covered</div>
            </div>
            <div className="text-center">
              <div className="text-4xl lg:text-5xl font-bold text-blue-400 mb-2">12,500+</div>
              <div className="text-gray-400">Regulatory Documents</div>
            </div>
            <div className="text-center">
              <div className="text-4xl lg:text-5xl font-bold text-green-400 mb-2">99.9%</div>
              <div className="text-gray-400">Uptime Guarantee</div>
            </div>
            <div className="text-center">
              <div className="text-4xl lg:text-5xl font-bold text-yellow-400 mb-2">24/7</div>
              <div className="text-gray-400">Expert Support</div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20">
        <div className="max-w-4xl mx-auto px-6 text-center">
          <Card className="bg-gradient-to-r from-purple-900/30 to-blue-900/30 border-purple-500/30 backdrop-blur-sm">
            <CardContent className="p-12">
              <h3 className="text-3xl lg:text-4xl font-bold text-white mb-4">
                Ready to Transform Your Compliance Workflow?
              </h3>
              <p className="text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
                Start with our free Knowledge Base and explore the power of comprehensive export control compliance
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button 
                  onClick={handleGetStarted}
                  size="lg" 
                  className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white px-8 py-6 text-lg font-semibold"
                >
                  {user ? 'Access Dashboard' : 'Start Free Trial'}
                  <ArrowRight className="ml-2 w-5 h-5" />
                </Button>
                <Button 
                  variant="outline" 
                  size="lg" 
                  onClick={() => window.open('mailto:contact@respectus.com', '_blank')}
                  className="border-gray-600 text-white hover:bg-gray-800/50 px-8 py-6 text-lg"
                >
                  Contact Sales
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      <Footer />
    </div>
  );
}
