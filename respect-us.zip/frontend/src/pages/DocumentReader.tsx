import React, { useState, useEffect, useCallback } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { toast } from 'sonner';
import brain from 'brain';
import {
  ArrowLeft, BookOpen, FileText, Calendar, Clock, User, Tag,
  ExternalLink, Eye, Download, List, ChevronRight, Globe,
  MessageSquare, Bookmark, Activity, BarChart3, Users,
  Share2, Printer, Search, ChevronUp, ChevronDown,
  AlertCircle, CreditCard, Loader2, EyeOff, MapPin, X, Building,
  Newspaper, Star, ArrowRight, TrendingUp
} from 'lucide-react';
import { auth, API_URL } from 'app';
import type {
  DocumentResponse,
  DocumentSection as ApiDocumentSection
} from 'types';
import { MultilingualSupport } from 'components/MultilingualSupport';
import { DocumentAnnotations } from 'components/DocumentAnnotations';
import { DocumentComparison } from 'components/DocumentComparison';
import { useUserGuardContext } from 'app/auth';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { PDFViewerButton, AutoPDFViewer, PDFErrorBoundary } from 'components/PDFComponents';

// Document section interface
interface DocumentSection {
  id: number;
  document_id: number;
  section_number?: string;
  section_title: string;
  section_content: string;
  parent_section_id?: number;
  level: number;
  subsections: DocumentSection[];
}

interface DocumentStructure {
  document_id: number;
  document_title: string;
  sections: DocumentSection[];
  total_sections: number;
  hierarchical_sections: DocumentSection[];
}

// Helper function to detect blog articles
const isBlogArticle = (document: DocumentResponse | null): boolean => {
  return document?.is_blog_article === true;
};

// Helper function to get blog category label
const getBlogCategoryLabel = (articleType: string): string => {
  const categories = {
    'compliance-news': 'Compliance News',
    'regulatory-updates': 'Regulatory Updates', 
    'industry-analysis': 'Industry Analysis',
    'best-practices': 'Best Practices',
    'case-studies': 'Case Studies',
    'thought-leadership': 'Thought Leadership',
    'blog': 'Blog Article'
  };
  return categories[articleType as keyof typeof categories] || articleType;
};

const DocumentReader = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const documentId = searchParams.get('documentId');

  // State
  const [document, setDocument] = useState<DocumentResponse | null>(null);
  const [sections, setSections] = useState<DocumentSection[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [activeSection, setActiveSection] = useState<number | null>(null);
  const [expandedSections, setExpandedSections] = useState<Set<number>>(new Set());
  const [showTableOfContents, setShowTableOfContents] = useState(true);
  const [sectionsLoading, setSectionsLoading] = useState(false);
  const [sectionsNotApplicable, setSectionsNotApplicable] = useState(false);
  const [documentStructure, setDocumentStructure] = useState<DocumentStructure | null>(null);
  const [showMultilingualDialog, setShowMultilingualDialog] = useState(false);
  const [currentLanguage, setCurrentLanguage] = useState('en');
  const [autoOpenPdf, setAutoOpenPdf] = useState(false);

  // Check for auto-open PDF from query params
  useEffect(() => {
    const openPdf = searchParams.get('openPdf');
    setAutoOpenPdf(openPdf === 'true');
  }, [searchParams]);

  // Handle blog article redirect
  const handleBlogArticleRedirect = () => {
    if (document?.is_blog_article && documentId) {
      // Navigate back to the specific blog article
      navigate(`/blog-article?id=${documentId}`);
    } else {
      // Fallback to blog list
      navigate('/blog');
    }
  };

  // Build hierarchical structure from flat sections
  const buildHierarchy = (flatSections: any[]): DocumentSection[] => {
    const sectionMap = new Map<number, DocumentSection>();
    const roots: DocumentSection[] = [];

    // First pass: create all sections with empty subsections
    flatSections.forEach(section => {
      const enhancedSection: DocumentSection = {
        ...section,
        subsections: []
      };
      sectionMap.set(section.id, enhancedSection);
    });

    // Second pass: build parent-child relationships
    flatSections.forEach(section => {
      const enhancedSection = sectionMap.get(section.id);
      if (enhancedSection) {
        if (section.parent_section_id) {
          const parent = sectionMap.get(section.parent_section_id);
          if (parent) {
            parent.subsections.push(enhancedSection);
          }
        } else {
          roots.push(enhancedSection);
        }
      }
    });

    return roots;
  };

  useEffect(() => {
    const fetchDocument = async () => {
      if (!documentId) return;
      
      try {
        setLoading(true);
        setError(null);
        
        // Fetch document details
        const docResponse = await brain.get_document({ documentId: parseInt(documentId) });
        if (!docResponse.ok) {
          throw new Error('Failed to fetch document');
        }
        const docData = await docResponse.json();
        setDocument(docData);
        
        // If this is a blog article accessed directly (like from blog page),
        // skip the intermediary screen and show content directly
        const fromBlog = new URLSearchParams(window.location.search).get('fromBlog');
        if (isBlogArticle(docData) && fromBlog === 'true') {
          setShowTableOfContents(false);
        }
        
        // Fetch document sections
        setSectionsLoading(true);
        try {
          const sectionsResponse = await brain.get_document_sections({ documentId: parseInt(documentId) });
          if (sectionsResponse.ok) {
            const sectionsData = await sectionsResponse.json();
            const hierarchicalSections = buildHierarchy(sectionsData.sections || []);
            setDocumentStructure({
              document_id: parseInt(documentId),
              document_title: docData.title,
              sections: sectionsData.sections || [],
              total_sections: sectionsData.sections?.length || 0,
              hierarchical_sections: hierarchicalSections
            });
            setSections(hierarchicalSections);
            setSectionsNotApplicable(false);
          } else {
            // If sections fail, mark as not applicable but continue
            setSectionsNotApplicable(true);
            setSections([]);
          }
        } catch (sectionsError) {
          console.warn('Failed to load sections:', sectionsError);
          setSectionsNotApplicable(true);
          setSections([]);
        } finally {
          setSectionsLoading(false);
        }
        
      } catch (err) {
        console.error('Error fetching document:', err);
        setError(err instanceof Error ? err.message : 'An error occurred');
      } finally {
        setLoading(false);
      }
    };

    fetchDocument();
  }, [documentId]);

  const toggleSection = (sectionId: number) => {
    const newExpanded = new Set(expandedSections);
    if (newExpanded.has(sectionId)) {
      newExpanded.delete(sectionId);
    } else {
      newExpanded.add(sectionId);
    }
    setExpandedSections(newExpanded);
  };
  
  const scrollToSection = (sectionId: number) => {
    setActiveSection(sectionId);
    const element = document.getElementById(`section-${sectionId}`);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };
  
  const handlePrint = () => {
    window.print();
  };
  
  const handleShare = async () => {
    if (navigator.share && document) {
      try {
        await navigator.share({
          title: document.title,
          text: document.description || '',
          url: window.location.href,
        });
      } catch (error) {
        // Fallback to clipboard
        navigator.clipboard.writeText(window.location.href);
        toast.success('Link copied to clipboard');
      }
    } else {
      navigator.clipboard.writeText(window.location.href);
      toast.success('Link copied to clipboard');
    }
  };
  
  const renderTableOfContents = (sections: DocumentSection[], level = 0) => {
    return sections.map((section) => (
      <div key={section.id} className={`ml-${level * 4}`}>
        <div
          className={`flex items-center justify-between py-2 px-3 rounded-lg cursor-pointer transition-colors ${
            activeSection === section.id
              ? 'bg-blue-600 text-white'
              : 'hover:bg-gray-700 text-gray-300'
          }`}
          onClick={() => scrollToSection(section.id)}
        >
          <div className="flex items-center gap-2 flex-1">
            {section.subsections.length > 0 && (
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  toggleSection(section.id);
                }}
                className="p-1 rounded hover:bg-gray-600"
              >
                {expandedSections.has(section.id) ? (
                  <ChevronDown className="w-3 h-3" />
                ) : (
                  <ChevronRight className="w-3 h-3" />
                )}
              </button>
            )}
            <span className="text-sm font-medium truncate">
              {section.section_number && (
                <span className="text-gray-400 mr-2">{section.section_number}</span>
              )}
              {section.section_title}
            </span>
          </div>
        </div>
        
        {expandedSections.has(section.id) && section.subsections.length > 0 && (
          <div className="mt-1">
            {renderTableOfContents(section.subsections, level + 1)}
          </div>
        )}
      </div>
    ));
  };
  
  const renderDocumentSection = (section: DocumentSection) => {
    return (
      <div
        key={section.id}
        id={`section-${section.id}`}
        className={`mb-8 scroll-mt-20 ${section.level === 0 ? 'border-l-4 border-blue-500 pl-6' : ''}`}
      >
        <div className="mb-4">
          <h2
            className={`font-bold text-slate-100 mb-2 ${
              section.level === 0
                ? 'text-2xl'
                : section.level === 1
                ? 'text-xl'
                : section.level === 2
                ? 'text-lg'
                : 'text-base'
            }`}
          >
            {section.section_number && (
              <span className="text-blue-400 mr-3">{section.section_number}</span>
            )}
            {section.section_title}
          </h2>
        </div>
        
        {section.section_content && (
          <div
            className="prose prose-invert max-w-none mb-6 text-slate-300 leading-relaxed"
            dangerouslySetInnerHTML={{ __html: section.section_content }}
          />
        )}
        
        {/* Render subsections */}
        {section.subsections.map((subsection) => (
          <div key={subsection.id} className="ml-6">
            {renderDocumentSection(subsection)}
          </div>
        ))}
      </div>
    );
  };
  
  // Check if document has content to display
  const hasContentToDisplay = document && (document.content_text || document.content);
  
  // Helper function to format text content better
  const formatTextContent = (content: string) => {
    if (!content) return '';
    
    // Split into paragraphs and clean up
    const paragraphs = content
      .split(/\n\s*\n/) // Split on double line breaks
      .map(p => p.trim())
      .filter(p => p.length > 0);
    
    // If we have very few line breaks, it's probably one big unformatted block
    const isUnformatted = paragraphs.length < 3 && content.length > 1000;
    
    if (isUnformatted) {
      // Try to add some basic formatting
      return content
        .replace(/([.!?])\s+([A-Z])/g, '$1\n\n$2') // Add breaks after sentences before capitals
        .replace(/([a-z])([A-Z][a-z])/g, '$1 $2') // Add spaces between camelCase
        .replace(/\s+/g, ' ') // Clean up multiple spaces
        .trim();
    }
    
    return paragraphs.join('\n\n');
  };
  
  // Check if content is readable (has proper formatting)
  const isContentReadable = (content: string) => {
    if (!content || content.length < 100) return false;
    
    // If content contains HTML tags, it's likely well-formatted
    const hasHTMLTags = /<[^>]+>/.test(content);
    if (hasHTMLTags) {
      // Check for common HTML structure indicators
      const hasParagraphs = /<p[^>]*>/i.test(content);
      const hasLineBreaks = /<br[^>]*>/i.test(content);
      const hasHeaders = /<h[1-6][^>]*>/i.test(content);
      
      // If it has basic HTML structure, consider it readable
      if (hasParagraphs || hasLineBreaks || hasHeaders) {
        return true;
      }
    }
    
    // Look for signs of unreadable PDF extraction:
    // 1. Document reference numbers at start (like "02021R1275 — EN —")
    const hasDocRefPattern = /^\d{5,}[A-Z]\d+\s*[—-]\s*[A-Z]{2}\s*[—-]/.test(content);
    
    // 2. Very long lines without proper breaks
    const lines = content.split('\n');
    const longLineCount = lines.filter(line => line.length > 200).length;
    const longLineRatio = longLineCount / Math.max(lines.length, 1);
    
    // 3. Check for typical PDF extraction patterns
    const hasLegalText = content.includes('This text is meant purely as a documentation tool');
    const hasTimestamps = /\d{2}\.\d{2}\.\d{4}/.test(content.substring(0, 500));
    
    // 4. Calculate line break density
    const lineBreaks = (content.match(/\n/g) || []).length;
    const breakRatio = lineBreaks / (content.length / 100);
    
    // Consider unreadable if:
    // - Has document reference pattern OR
    // - Has legal disclaimer text OR 
    // - Too many long lines OR
    // - Very low line break ratio
    if (hasDocRefPattern || hasLegalText || longLineRatio > 0.3 || breakRatio < 1) {
      return false;
    }
    
    return true;
  };
  
  // Updated logic to detect PDF-only documents - simplified and more reliable
  const shouldShowPDFOnly = document && document.file_type === 'application/pdf' && 
    document.content_text && document.content_text.length > 5000 && 
    sectionsNotApplicable && !isContentReadable(document.content_text);

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-900 text-slate-100">
        <div className="max-w-7xl mx-auto px-6 py-8">
          <div className="text-center py-12">
            <BookOpen className="h-12 w-12 mx-auto mb-4 opacity-50 animate-pulse" />
            <p className="text-slate-400">Loading document...</p>
          </div>
        </div>
      </div>
    );
  }
  
  if (error || !document) {
    return (
      <div className="min-h-screen bg-gray-900 text-slate-100">
        <div className="max-w-7xl mx-auto px-6 py-8">
          <div className="text-center py-12">
            <FileText className="h-12 w-12 mx-auto mb-4 opacity-50" />
            <h2 className="text-xl font-semibold mb-4">Document Not Found</h2>
            <p className="text-slate-400 mb-6">{error || 'The requested document could not be found.'}</p>
            <Button onClick={() => navigate('/knowledge-base')} className="bg-blue-600 hover:bg-blue-700">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Knowledge Base
            </Button>
          </div>
        </div>
      </div>
    );
  }
  
  return (
    <div className="min-h-screen bg-gray-900 text-slate-100">
      {/* Header */}
      <div className="bg-gray-800 border-b border-gray-700 sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            {/* Breadcrumb and Title */}
            <div className="flex items-center gap-4 flex-1">
              <Button
                variant="outline"
                size="sm"
                onClick={() => navigate('/knowledge-base')}
                className="border-gray-600 text-gray-300 hover:bg-gray-700"
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Knowledge Base
              </Button>
              
              <ChevronRight className="w-4 h-4 text-gray-500" />
              
              <div className="flex items-center gap-3">
                <BookOpen className="w-5 h-5 text-blue-400" />
                <h1 className="text-lg font-semibold text-slate-100 truncate">
                  {document.title}
                </h1>
              </div>
            </div>
            
            {/* Actions */}
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowTableOfContents(!showTableOfContents)}
                className="border-gray-600 text-gray-300 hover:bg-gray-700"
              >
                <List className="w-4 h-4 mr-2" />
                Contents
              </Button>
              {document?.file_type === 'application/pdf' && documentId && (
                <PDFViewerButton
                  documentId={parseInt(documentId)}
                  documentTitle={document.title}
                  className="border-gray-600 text-gray-300 hover:bg-gray-700"
                />
              )}
              <Button
                variant="outline"
                size="sm"
                onClick={handleShare}
                className="border-gray-600 text-gray-300 hover:bg-gray-700"
              >
                <Share2 className="w-4 h-4 mr-2" />
                Share
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={handlePrint}
                className="border-gray-600 text-gray-300 hover:bg-gray-700"
              >
                <Printer className="w-4 h-4 mr-2" />
                Print
              </Button>
            </div>
          </div>
        </div>
      </div>
      
      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-6 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Table of Contents */}
          {showTableOfContents && !sectionsNotApplicable && (
            <div className="lg:col-span-3">
              <Card className="bg-gray-800 border-gray-700 sticky top-24">
                <CardHeader className="pb-3">
                  <CardTitle className="text-slate-100 flex items-center gap-2">
                    <List className="w-4 h-4" />
                    Table of Contents
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-[calc(100vh-12rem)]">
                    {sectionsLoading ? (
                      <div className="text-center py-8">
                        <div className="animate-pulse text-gray-400">Loading sections...</div>
                      </div>
                    ) : documentStructure && documentStructure.hierarchical_sections.length > 0 ? (
                      <div className="space-y-1">
                        {renderTableOfContents(documentStructure.hierarchical_sections)}
                      </div>
                    ) : (
                      <div className="text-center py-8 text-gray-400">
                        <FileText className="w-8 h-8 mx-auto mb-2 opacity-50" />
                        <p className="text-sm">No sections available</p>
                      </div>
                    )}
                  </ScrollArea>
                </CardContent>
              </Card>
            </div>
          )}
          
          {/* Document Content */}
          <div className={showTableOfContents && !sectionsNotApplicable ? 'lg:col-span-9' : 'lg:col-span-12'}>
            {/* Document Metadata */}
            <Card className="bg-gray-800 border-gray-700 mb-8">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <CardTitle className="text-2xl font-bold text-slate-100 mb-3">
                      {document.title}
                    </CardTitle>
                    
                    {document.description && (
                      <p className="text-slate-300 text-lg leading-relaxed mb-4">
                        {document.description}
                      </p>
                    )}
                    
                    {/* Metadata badges */}
                    <div className="flex flex-wrap items-center gap-4 text-sm">
                      {document.country_jurisdiction && (
                        <div className="flex items-center gap-2">
                          <Globe className="w-4 h-4 text-blue-400" />
                          <Badge variant="outline" className="border-blue-400 text-blue-400">
                            {document.country_jurisdiction}
                          </Badge>
                        </div>
                      )}
                      
                      {document.regulation_type && (
                        <div className="flex items-center gap-2">
                          <Tag className="w-4 h-4 text-green-400" />
                          <Badge variant="outline" className="border-green-400 text-green-400">
                            {document.regulation_type}
                          </Badge>
                        </div>
                      )}
                      
                      {document.issuing_authority && (
                        <div className="flex items-center gap-2">
                          <Building className="w-4 h-4 text-purple-400" />
                          <span className="text-slate-400">{document.issuing_authority}</span>
                        </div>
                      )}
                      
                      {document.legal_status && (
                        <div className="flex items-center gap-2">
                          <Eye className="w-4 h-4 text-yellow-400" />
                          <Badge 
                            variant="outline" 
                            className={`border-yellow-400 text-yellow-400`}
                          >
                            {document.legal_status}
                          </Badge>
                        </div>
                      )}
                    </div>
                    
                    {/* Dates */}
                    <div className="flex flex-wrap items-center gap-6 mt-4 text-sm text-slate-400">
                      {document.publication_date && (
                        <div className="flex items-center gap-2">
                          <Calendar className="w-4 h-4" />
                          <span>Published: {new Date(document.publication_date).toLocaleDateString()}</span>
                        </div>
                      )}
                      
                      {document.effective_date && (
                        <div className="flex items-center gap-2">
                          <Clock className="w-4 h-4" />
                          <span>Effective: {new Date(document.effective_date).toLocaleDateString()}</span>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </CardHeader>
            </Card>
            
            {/* Blog Article Special Handling */}
            {isBlogArticle(document) && showTableOfContents ? (
              <Card className="bg-gray-800 border-gray-700 mb-8">
                <CardContent className="p-8">
                  <div className="text-center py-12">
                    <div className="mb-6">
                      <Newspaper className="w-16 h-16 mx-auto mb-4 text-blue-400" />
                      <Star className="w-6 h-6 mx-auto mb-4 text-yellow-400" />
                    </div>
                    
                    <h3 className="text-2xl font-semibold mb-4 text-slate-100">
                      Blog Article Detected
                    </h3>
                    
                    <div className="mb-6">
                      <Badge variant="outline" className="text-lg px-4 py-2 border-blue-400 text-blue-400 mb-4">
                        {getBlogCategoryLabel(document.article_type || 'blog')}
                      </Badge>
                    </div>
                    
                    <p className="text-slate-400 mb-6 max-w-2xl mx-auto text-lg leading-relaxed">
                      This is a blog article from our compliance insights collection. 
                      For the best reading experience with related articles and enhanced navigation, 
                      we recommend viewing it in our dedicated blog section.
                    </p>
                    
                    <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
                      <Button 
                        onClick={handleBlogArticleRedirect}
                        className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3 text-lg flex items-center gap-2"
                      >
                        <Newspaper className="w-5 h-5" />
                        View in Blog Section
                        <ArrowRight className="w-4 h-4" />
                      </Button>
                      
                      <Button 
                        variant="outline"
                        onClick={() => setShowTableOfContents(false)}
                        className="border-gray-600 text-gray-300 hover:bg-gray-700 px-6 py-2"
                      >
                        Read Here Instead
                      </Button>
                    </div>
                    
                    {/* Blog article metadata */}
                    {(document.author || document.reading_time || document.view_count) && (
                      <div className="mt-8 pt-8 border-t border-gray-700">
                        <div className="flex flex-wrap justify-center items-center gap-6 text-sm text-slate-400">
                          {document.author && (
                            <div className="flex items-center gap-1">
                              <User className="w-4 h-4" />
                              <span>By {document.author}</span>
                            </div>
                          )}
                          {document.reading_time && (
                            <div className="flex items-center gap-1">
                              <Clock className="w-4 h-4" />
                              <span>{document.reading_time} min read</span>
                            </div>
                          )}
                          {document.view_count && (
                            <div className="flex items-center gap-1">
                              <TrendingUp className="w-4 h-4" />
                              <span>{document.view_count} views</span>
                            </div>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            ) : null}
            
            {/* Document Sections - Only show if not a blog article or user chose to read here */}
            {(!isBlogArticle(document) || !showTableOfContents) && (
              <>
                {/* Document Sections */}
                {sectionsLoading ? (
                  <Card className="bg-gray-800 border-gray-700">
                    <CardContent className="p-8">
                      <div className="text-center">
                        <div className="animate-pulse text-gray-400 mb-4">Loading document content...</div>
                        <div className="space-y-3">
                          {[...Array(5)].map((_, i) => (
                            <div key={i} className="h-4 bg-gray-700 rounded animate-pulse" />
                          ))}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ) : (
                  <Card className="bg-gray-800 border-gray-700">
                    <CardContent className={isBlogArticle(document) ? "p-12 lg:p-16" : "p-8"}>
                      <div className={isBlogArticle(document) 
                        ? "max-w-4xl mx-auto text-slate-200 leading-relaxed space-y-6" 
                        : "prose prose-invert max-w-none text-slate-300 leading-relaxed"
                      }>
                        {document.content_html ? (
                          <div 
                            className={isBlogArticle(document) 
                              ? "blog-content text-lg leading-8 space-y-6" 
                              : ""
                            }
                            dangerouslySetInnerHTML={{ __html: document.content_html }} 
                          />
                        ) : document.content_text ? (
                          <div 
                            className={isBlogArticle(document) 
                              ? "blog-content text-lg leading-8 space-y-6" 
                              : ""
                            }
                            dangerouslySetInnerHTML={{ __html: document.content_text }} 
                          />
                        ) : (
                          <div className="text-center py-12">
                            <FileText className="w-12 h-12 mx-auto mb-4 opacity-50" />
                            <h3 className="text-lg font-semibold mb-2">No Content Available</h3>
                            <p className="text-slate-400">This document does not have readable content.</p>
                          </div>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                )}
              </>
            )}
          </div>
        </div>
      </div>
      
      {/* Auto PDF Viewer - Opens automatically when openPdf=true query param is set */}
      {document && (
        <AutoPDFViewer
          documentId={documentId}
          documentTitle={document.title}
          shouldAutoOpen={autoOpenPdf}
          fileType={document.file_type}
        />
      )}
    </div>
  );
};

export default DocumentReader;
