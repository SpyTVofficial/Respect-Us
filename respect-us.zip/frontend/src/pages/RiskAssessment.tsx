import React, { useState, useEffect, useCallback, startTransition } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { createPortal } from 'react-dom';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import { AlertCircle, FileText, BarChart3, CreditCard, Send, ArrowLeft, ArrowRight, Check, X, Download, Upload, Share2, Trash2, Calendar, User, Building, Target, Zap, Shield, TrendingUp, AlertTriangle, CheckCircle, Clock, Users, MapPin, Globe, BookOpen } from 'lucide-react';
import { toast } from 'sonner';
import brain from 'brain';
import { useUserGuardContext } from 'app/auth';
import { useCreditBalance } from 'utils/useCreditBalance';
import Footer from 'components/Footer';
import Navigation from 'components/Navigation';
import type { 
  RiskAssessmentTemplate, 
  RiskAssessmentResponse, 
  SavedRiskAssessment,
  RiskAssessmentSection,
  RiskAssessmentQuestion,
  CreateRiskAssessmentRequest,
  UpdateRiskAssessmentRequest,
  RiskAssessmentMetrics,
  RiskAssessmentComparisonResult,
  RiskAssessmentSummary,
  CreditAccessInfo,
  ConsumeCreditsRequest
} from 'types';
import { auth } from 'app/auth';
import { API_URL, auth } from 'app';

interface Response {
  questionId: string;
  sectionId: number;
  answer: string | boolean | string[];
  notes?: string;
}

interface CMSContent {
  id: number;
  key: string;
  title: string;
  content: string;
  module_type: string;
  category?: string;
  order_index?: number;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

const RiskAssessment = () => {
  console.log('RiskAssessment mounted');
  
  const { user } = useUserGuardContext();
  // TEMPORARILY DISABLED - const { balance: creditBalance, refreshBalance } = useCreditBalance();
  const creditBalance = null;
  const refreshBalance = () => {};
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  
  // State for assessment management
  const [responses, setResponses] = useState<{ [key: string]: Response }>({});
  const [assessmentId, setAssessmentId] = useState<number | null>(null);
  const [companyName, setCompanyName] = useState('');
  const [assessmentTitle, setAssessmentTitle] = useState('');
  const [selectedTemplate, setSelectedTemplate] = useState<RiskAssessmentTemplate | null>(null);
  const [currentSectionIndex, setCurrentSectionIndex] = useState(0);
  const [showOverview, setShowOverview] = useState(false);
  const [sectionAnswers, setSectionAnswers] = useState<Record<string, any>>({});
  const [pendingAction, setPendingAction] = useState<string>('');
  
  // Template and loading state
  const [templates, setTemplates] = useState<RiskAssessmentTemplate[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadingAssessment, setLoadingAssessment] = useState(false);
  const [loadingCreditInfo, setLoadingCreditInfo] = useState(true);
  const [hasUnlockedTemplates, setHasUnlockedTemplates] = useState(false);
  const [hasUnlockedSave, setHasUnlockedSave] = useState(false);
  const [isUnlockingTemplates, setIsUnlockingTemplates] = useState(false);
  const [templateCreditInfo, setTemplateCreditInfo] = useState<any>(null);
  const [saveCreditInfo, setSaveCreditInfo] = useState<any>(null);
  const [viewMode, setViewMode] = useState<'templates' | 'assessment' | 'pricing'>('templates');
  const [paymentDialogOpen, setPaymentDialogOpen] = useState(false);
  
  // CMS Content state
  const [cmsContent, setCmsContent] = useState<CMSContent[]>([]);
  const [cmsLoading, setCmsLoading] = useState(false);

  // User access status state
  const [userAccessStatus, setUserAccessStatus] = useState<any>(null);
  const [accessLoading, setAccessLoading] = useState(true);

  // Section analysis state
  const [strengthsMode, setStrengthsMode] = useState<'manual' | 'ai'>('manual');
  const [weaknessesMode, setWeaknessessMode] = useState<'manual' | 'ai'>('manual');
  const [sectionAnalysis, setSectionAnalysis] = useState<Record<string, {strengths?: string, weaknesses?: string}>>({});
  const [aiSuggestions, setAiSuggestions] = useState<{strengths?: string, weaknesses?: string}>({});
  const [aiSuggestionLoading, setAiSuggestionLoading] = useState(false);
  const [currentAISuggestion, setCurrentAISuggestion] = useState<'strengths' | 'weaknesses' | null>(null);
  
  // Overall assessment state
  const [overallStrengthsMode, setOverallStrengthsMode] = useState<'manual' | 'ai'>('manual');
  const [overallWeaknessesMode, setOverallWeaknessesMode] = useState<'manual' | 'ai'>('manual');
  const [overallAssessment, setOverallAssessment] = useState<{strengths?: string, weaknesses?: string, recommendations?: string}>({});
  const [overallAiSuggestions, setOverallAiSuggestions] = useState<{strengths?: string, weaknesses?: string}>({});
  
  // Action plan state
  const [actionPlanModes, setActionPlanModes] = useState<{
    high: 'manual' | 'ai',
    medium: 'manual' | 'ai',
    low: 'manual' | 'ai'
  }>({ high: 'manual', medium: 'manual', low: 'manual' });
  const [actionPlan, setActionPlan] = useState<{
    high?: string,
    medium?: string,
    low?: string
  }>({});
  const [actionPlanAiSuggestions, setActionPlanAiSuggestions] = useState<{
    high?: string,
    medium?: string,
    low?: string
  }>({});
  
  // Missing critical state variables
  const [isUnlockingSave, setIsUnlockingSave] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [showTemplateUnlockDialog, setShowTemplateUnlockDialog] = useState(false);
  const [showBuyCreditDialog, setShowBuyCreditDialog] = useState(false);
  
  // High-value credit confirmation state
  const [showHighValueConfirmation, setShowHighValueConfirmation] =
    useState(false);
  const [pendingHighValueAction, setPendingHighValueAction] = useState<{
    type: string;
    creditCost: number;
    callback: () => Promise<void>;
  } | null>(null);

  const [validationRequested, setValidationRequested] = useState<{
    high: boolean,
    medium: boolean,
    low: boolean
  }>({ high: false, medium: false, low: false });
  const [validationStatus, setValidationStatus] = useState<{
    high?: 'pending' | 'validated' | 'rejected',
    medium?: 'pending' | 'validated' | 'rejected',
    low?: 'pending' | 'validated' | 'rejected'
  }>({});
  
  // Assessment completion state
  const [pdfGenerating, setPdfGenerating] = useState(false);
  const [savingToDashboard, setSavingToDashboard] = useState(false);
  const [transmittingToRespectus, setTransmittingToRespectus] = useState(false);
  const [sharingByEmail, setSharingByEmail] = useState(false);
  const [emailRecipient, setEmailRecipient] = useState('');
  const [emailSubject, setEmailSubject] = useState('');
  const [emailMessage, setEmailMessage] = useState('');
  const [showEmailDialog, setShowEmailDialog] = useState(false);
  const [respectusValidationStatus, setRespectusValidationStatus] = useState<'none' | 'pending' | 'validated' | 'needs_revision'>('none');
  const [respectusFeedback, setRespectusFeedback] = useState<string>('');
  const [exportingPdf, setExportingPdf] = useState(false);

  // State for pending assessment data
  const [pendingAssessmentId, setPendingAssessmentId] = useState<string | null>(null);
  
  // Load templates
  const loadTemplates = useCallback(async () => {
    try {
      console.log('🔎 Loading templates...');
      setLoading(true);
      const response = await brain.list_templates();
      const data = await response.json();
      console.log('📦 Templates loaded:', data?.templates?.length || 0);
      console.log('🔍 Template data:', data?.templates);
      setTemplates(data?.templates || []);
    } catch (error) {
      console.error('❌ Error loading templates:', error);
      toast.error('Failed to load assessment templates');
    } finally {
      setLoading(false);
    }
  }, []);
  
  // Load credit information
  const loadCreditInfo = useCallback(async () => {
    try {
      setLoadingCreditInfo(true);
      
      // Check pricing for template access
      const templateResponse = await brain.check_action_pricing({
        componentName: 'risk_assessment',
        actionName: 'access_templates'
      });
      const templatePricing = await templateResponse.json();
      setTemplateCreditInfo(templatePricing);
      setHasUnlockedTemplates(!templatePricing.requires_credits || creditBalance?.current_balance >= templatePricing.credit_cost);
      
      // Make save functionality always free
      setSaveCreditInfo({ requires_credits: false, credit_cost: 0, is_free: true, message: 'Free to use' });
      setHasUnlockedSave(true);
      
    } catch (error) {
      console.error('Error loading credit info:', error);
      setTemplateCreditInfo({ requires_credits: false, credit_cost: 0, is_free: true, message: 'Currently free' });
      setSaveCreditInfo({ requires_credits: false, credit_cost: 0, is_free: true, message: 'Free to use' });
      setHasUnlockedSave(true);
    } finally {
      setLoadingCreditInfo(false);
    }
  }, [creditBalance?.current_balance]);

  // Load user access status for pricing display
  const loadUserAccessStatus = useCallback(async () => {
    try {
      setAccessLoading(true);
      const response = await brain.get_user_access_status();
      const data = await response.json();
      setUserAccessStatus(data);
    } catch (error) {
      console.error('Error loading user access status:', error);
    } finally {
      setAccessLoading(false);
    }
  }, []);
  
  const fetchCMSContent = useCallback(async () => {
    try {
      setCmsLoading(true);
      const response = await brain.list_classification_notes({
        module_type: 'risk_assessment'
      });
      
      if (response.ok) {
        const data = await response.json();
        setCmsContent(data || []);
      }
    } catch (error) {
      console.error('Error fetching CMS content:', error);
    } finally {
      setCmsLoading(false);
    }
  }, []);

  // Load saved assessment
  const loadSavedAssessment = useCallback(async (assessmentId: string) => {
    try {
      console.log('📝 Loading assessment:', assessmentId);
      setLoadingAssessment(true);
      const response = await brain.load_assessment({ assessmentId: assessmentId });
      const assessmentData = await response.json();
      
      if (assessmentData) {
        setAssessmentTitle(assessmentData.assessment_title || '');
        setCompanyName(assessmentData.company_name || '');
        
        // Transform responses
        const formResponses: Record<string, Response> = {};
        if (assessmentData.responses) {
          assessmentData.responses.forEach((response: any) => {
            const responseKey = `${response.section_id}_${response.question_id}`;
            formResponses[responseKey] = {
              questionId: response.question_id,
              sectionId: response.section_id,
              answer: response.answer,
              notes: response.notes
            };
          });
        }
        setResponses(formResponses);
        
        // Find and select the template
        const template = templates.find(t => t.id === assessmentData.template_id);
        if (template) {
          setSelectedTemplate(template);
          setViewMode('assessment');
          console.log('✅ Assessment loaded successfully');
          toast.success('Assessment loaded successfully');
        } else {
          console.log('⚠️ Template not found for assessment');
        }
      }
    } catch (error) {
      console.error('❌ Error loading assessment:', error);
      toast.error('Failed to load saved assessment');
    } finally {
      setLoadingAssessment(false);
    }
  }, [templates]);
  
  // Update response function
  const updateResponse = useCallback((questionId: string, sectionId: number, answer: string | boolean | string[], notes?: string) => {
    const responseKey = `${sectionId}_${questionId}`;
    setResponses(prev => ({
      ...prev,
      [responseKey]: {
        questionId,
        sectionId,
        answer,
        notes: notes || prev[responseKey]?.notes || ''
      }
    }));
  }, []);
  
  // Calculate overall risk score
  const calculateOverallRiskScore = useCallback(() => {
    if (!selectedTemplate || !selectedTemplate.sections) return null;
    
    let totalScore = 0;
    let maxScore = 0;
    let answeredQuestions = 0;
    let notApplicableCount = 0;
    let totalRatingQuestions = 0;
    
    const sectionBreakdowns = selectedTemplate.sections.map((section, sectionIndex) => {
      let sectionScore = 0;
      let sectionMaxScore = 0;
      let sectionAnswered = 0;
      let sectionNotApplicable = 0;
      let sectionRatingQuestions = 0;
      
      section.questions?.forEach((question) => {
        if (question.question_type === 'rating') {
          sectionRatingQuestions++;
          totalRatingQuestions++;
          
          const responseKey = `${section.id}_${question.id}`;
          const response = responses[responseKey];
          
          if (response) {
            if (response.answer === 'N/A' || response.answer === 'not_applicable') {
              sectionNotApplicable++;
              notApplicableCount++;
            } else {
              const score = parseInt(response.answer as string) || 0;
              sectionScore += score;
              totalScore += score;
              sectionAnswered++;
              answeredQuestions++;
            }
            sectionMaxScore += 5;
            maxScore += 5;
          }
        }
      });
      
      const sectionPercentage = sectionMaxScore > 0 ? (sectionScore / sectionMaxScore) * 100 : 0;
      const sectionRiskLevel = sectionPercentage >= 70 ? 'low' : sectionPercentage >= 40 ? 'medium' : 'high';
      
      return {
        sectionIndex,
        sectionTitle: section.title,
        score: sectionScore,
        maxScore: sectionMaxScore,
        percentage: sectionPercentage,
        riskLevel: sectionRiskLevel,
        answeredQuestions: sectionAnswered,
        notApplicableCount: sectionNotApplicable,
        totalRatingQuestions: sectionRatingQuestions
      };
    });
    
    const percentage = maxScore > 0 ? (totalScore / maxScore) * 100 : 0;
    const riskLevel = percentage >= 70 ? 'low' : percentage >= 40 ? 'medium' : 'high';
    
    return {
      totalScore,
      maxScore,
      percentage,
      riskLevel,
      answeredQuestions,
      notApplicableCount,
      totalRatingQuestions,
      sectionBreakdowns
    };
  }, [selectedTemplate, responses]);
  
  // Start new assessment
  const startNewAssessment = useCallback((template: RiskAssessmentTemplate) => {
    setSelectedTemplate(template);
    setViewMode('assessment');
    setCurrentSectionIndex(0);
    setResponses({});
    setCompanyName('');
    setAssessmentTitle('');
    setOverallAssessment({});
    setActionPlan({});
    setSectionAnalysis({});
    setShowOverview(false);
  }, []);
  
  // Load templates on mount
  useEffect(() => {
    console.log('🔥 Loading templates useEffect');
    loadTemplates();
    fetchCMSContent();
    loadUserAccessStatus();
  }, [loadTemplates, fetchCMSContent, loadUserAccessStatus]);
  
  // Load credit info when balance changes
  useEffect(() => {
    if (creditBalance !== null) {
      loadCreditInfo();
    }
  }, [creditBalance, loadCreditInfo]);
  
  // Check for assessment to load after templates are loaded
  useEffect(() => {
    const assessmentId = searchParams.get('load');
    if (assessmentId && templates.length > 0 && !loadingAssessment && !selectedTemplate) {
      console.log('✅ Loading assessment:', assessmentId);
      loadSavedAssessment(assessmentId);
    }
  }, [searchParams, templates.length, loadingAssessment, selectedTemplate, loadSavedAssessment]);
  
  // Submit assessment function
  const submitAssessment = useCallback(async (status: 'draft' | 'completed') => {
    try {
      setSubmitting(true);
      
      const assessmentData = {
        template_id: selectedTemplate?.id || 0,
        assessment_title: assessmentTitle,
        company_name: companyName,
        responses: Object.values(responses),
        status,
        overall_assessment: overallAssessment,
        action_plan: actionPlan,
        section_analysis: sectionAnalysis
      };
      
      let response;
      if (assessmentId) {
        response = await brain.update_assessment({
          assessmentId: assessmentId.toString(),
          ...assessmentData
        });
      } else {
        response = await brain.create_assessment(assessmentData);
      }
      
      const result = await response.json();
      if (response.ok) {
        setAssessmentId(result.id);
        toast.success(`Assessment ${status === 'draft' ? 'saved as draft' : 'completed'} successfully!`);
        return result;
      } else {
        throw new Error(result.detail || 'Failed to save assessment');
      }
    } catch (error) {
      console.error('Error submitting assessment:', error);
      toast.error('Failed to save assessment');
      throw error;
    } finally {
      setSubmitting(false);
    }
  }, [selectedTemplate, assessmentTitle, companyName, responses, overallAssessment, actionPlan, sectionAnalysis, assessmentId]);
  
  // Export assessment as PDF
  const exportAssessmentPdf = useCallback(async () => {
    if (!assessmentId) {
      toast.error('Please save the assessment first before exporting');
      return;
    }
    
    try {
      setExportingPdf(true);
      
      // Use fetch directly since brain method returns a stream iterator
      // Get auth token for the request
      const token = await auth.getAuthToken();
      
      const response = await fetch(`${brain.baseUrl}/routes/risk-assessment/export-pdf/${assessmentId}`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        credentials: 'include'
      });
      
      if (response.ok) {
        // Handle binary PDF response
        const blob = await response.blob();
        
        // Ensure proper MIME type for PDF files
        const pdfBlob = new Blob([blob], { 
          type: 'application/pdf' 
        });
        
        // Create and download PDF
        const url = window.URL.createObjectURL(pdfBlob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `risk_assessment_${assessmentId}_${new Date().toISOString().split('T')[0]}.pdf`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        window.URL.revokeObjectURL(url);
        
        toast.success('Risk assessment PDF exported successfully');
      } else {
        const errorText = await response.text();
        console.error('Export failed:', errorText);
        toast.error('Failed to export assessment PDF');
      }
    } catch (error) {
      console.error('Error exporting PDF:', error);
      toast.error('Failed to export assessment PDF');
    } finally {
      setExportingPdf(false);
    }
  }, [assessmentId, companyName]);
  
  // Generate PDF content with RespectUs branding
  const generatePdfContent = useCallback((reportData: any) => {
    const riskColor = reportData.risk_analysis.overall_risk_level === 'low' ? '#059669' : 
                     reportData.risk_analysis.overall_risk_level === 'medium' ? '#d97706' : '#dc2626';
    
    return `
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Risk Assessment Report - ${reportData.assessment.title}</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            margin: 0;
            padding: 20px;
            color: #333;
            background: #f8fafc;
        }
        .header {
            background: linear-gradient(135deg, ${reportData.branding.colors.primary}, ${reportData.branding.colors.secondary});
            color: white;
            padding: 30px;
            border-radius: 10px;
            margin-bottom: 30px;
            text-align: center;
        }
        .logo {
            font-size: 2.5em;
            font-weight: bold;
            margin-bottom: 10px;
        }
        .tagline {
            font-size: 1.1em;
            opacity: 0.9;
        }
        .report-info {
            background: white;
            padding: 25px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 25px;
        }
        .section {
            background: white;
            margin: 20px 0;
            padding: 25px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .section h2 {
            color: ${reportData.branding.colors.primary};
            border-bottom: 2px solid ${reportData.branding.colors.primary};
            padding-bottom: 10px;
        }
        .risk-score {
            background: ${riskColor};
            color: white;
            padding: 20px;
            border-radius: 8px;
            text-align: center;
            margin: 20px 0;
        }
        .risk-score .score {
            font-size: 3em;
            font-weight: bold;
        }
        .risk-score .level {
            font-size: 1.2em;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        .section-breakdown {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 15px;
            margin: 20px 0;
        }
        .section-card {
            background: #f8fafc;
            padding: 15px;
            border-radius: 6px;
            border-left: 4px solid ${reportData.branding.colors.primary};
        }
        .footer {
            text-align: center;
            margin-top: 40px;
            padding: 20px;
            background: #f1f5f9;
            border-radius: 8px;
            color: #64748b;
        }
        .generated-info {
            background: #f1f5f9;
            padding: 15px;
            border-radius: 6px;
            margin-top: 20px;
            font-size: 0.9em;
            color: #64748b;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 15px 0;
        }
        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #e2e8f0;
        }
        th {
            background: ${reportData.branding.colors.primary};
            color: white;
        }
        .response-item {
            margin: 10px 0;
            padding: 10px;
            background: #f8fafc;
            border-radius: 4px;
        }
        .question {
            font-weight: bold;
            color: #334155;
        }
        .answer {
            margin-top: 5px;
            color: #64748b;
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="logo">${reportData.branding.logo_text}</div>
        <div class="tagline">${reportData.branding.tagline}</div>
    </div>
    
    <div class="report-info">
        <h1>Risk Assessment Report</h1>
        <p><strong>Report ID:</strong> ${reportData.report_id}</p>
        <p><strong>Assessment Title:</strong> ${reportData.assessment.title}</p>
        <p><strong>Company:</strong> ${reportData.assessment.company_name}</p>
        <p><strong>Template:</strong> ${reportData.assessment.template_title}</p>
        <p><strong>Status:</strong> ${reportData.assessment.status}</p>
        <p><strong>Generated:</strong> ${new Date(reportData.generated_at).toLocaleString()}</p>
        <p><strong>Generated by:</strong> ${reportData.generated_by}</p>
    </div>
    
    <div class="section">
        <h2>Executive Summary</h2>
        <div class="risk-score">
            <div class="score">${reportData.risk_analysis.overall_percentage}%</div>
            <div class="level">${reportData.risk_analysis.overall_risk_level} Risk</div>
        </div>
        <p><strong>Overall Assessment:</strong> Based on the responses provided, your organization demonstrates a <strong>${reportData.risk_analysis.overall_risk_level}</strong> risk level for export control compliance with a score of ${reportData.risk_analysis.total_score} out of ${reportData.risk_analysis.max_score} points (${reportData.risk_analysis.overall_percentage}%).</p>
    </div>
    
    <div class="section">
        <h2>Section Breakdown</h2>
        <div class="section-breakdown">
            ${reportData.risk_analysis.section_breakdowns.map((section: any) => `
                <div class="section-card">
                    <h4>${section.title}</h4>
                    <p><strong>Score:</strong> ${section.score}/${section.max_score} (${section.percentage.toFixed(1)}%)</p>
                    <p><strong>Risk Level:</strong> <span style="color: ${section.risk_level === 'low' ? '#059669' : section.risk_level === 'medium' ? '#d97706' : '#dc2626'}">${section.risk_level.toUpperCase()}</span></p>
                </div>
            `).join('')}
        </div>
    </div>
    
    ${reportData.overall_assessment && Object.keys(reportData.overall_assessment).length > 0 ? `
    <div class="section">
        <h2>Overall Assessment</h2>
        ${reportData.overall_assessment.strengths ? `<p><strong>Strengths:</strong> ${reportData.overall_assessment.strengths}</p>` : ''}
        ${reportData.overall_assessment.weaknesses ? `<p><strong>Areas for Improvement:</strong> ${reportData.overall_assessment.weaknesses}</p>` : ''}
        ${reportData.overall_assessment.recommendations ? `<p><strong>Recommendations:</strong> ${reportData.overall_assessment.recommendations}</p>` : ''}
    </div>
    ` : ''}
    
    ${reportData.action_plan && Object.keys(reportData.action_plan).length > 0 ? `
    <div class="section">
        <h2>Action Plan</h2>
        ${reportData.action_plan.high ? `<p><strong>High Priority:</strong> ${reportData.action_plan.high}</p>` : ''}
        ${reportData.action_plan.medium ? `<p><strong>Medium Priority:</strong> ${reportData.action_plan.medium}</p>` : ''}
        ${reportData.action_plan.low ? `<p><strong>Low Priority:</strong> ${reportData.action_plan.low}</p>` : ''}
    </div>
    ` : ''}
    
    <div class="section">
        <h2>Detailed Responses</h2>
        ${reportData.template_sections.map((section: any) => `
            <h3>${section.title}</h3>
            ${section.questions.map((question: any) => {
                const response = reportData.responses.find((r: any) => r.question_id === question.id && r.section_id === section.id);
                return response ? `
                    <div class="response-item">
                        <div class="question">${question.question_text}</div>
                        <div class="answer">${Array.isArray(response.answer) ? response.answer.join(', ') : response.answer}${response.notes ? ` (Notes: ${response.notes})` : ''}</div>
                    </div>
                ` : '';
            }).join('')}
        `).join('')}
    </div>
    
    <div class="footer">
        <p>This report was generated by ${reportData.branding.company_name} - ${reportData.branding.tagline}</p>
        <p>Visit us at ${reportData.branding.website}</p>
        <div class="generated-info">
            <p>Generated on ${new Date(reportData.generated_at).toLocaleString()} by ${reportData.generated_by}</p>
            <p>Report ID: ${reportData.report_id}</p>
        </div>
    </div>
</body>
</html>
    `;
  }, []);
  
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-black text-white">
      {/* Uniform Navigation */}
      <Navigation currentPage="risk_assessment" />
      
      {/* Module-specific Sub-header */}
      <div className="bg-gray-950/80 backdrop-blur-lg border-b border-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-3 py-4">
            <div className="p-2 bg-gradient-to-r from-orange-500 to-red-500 rounded-lg">
              <BarChart3 className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-white">Risk Assessment</h1>
              <p className="text-sm text-gray-400">Evaluate export control compliance risks</p>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        {loading ? (
          <div className="flex items-center justify-center min-h-[400px]">
            <div className="text-center">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mx-auto mb-4"></div>
              <p className="text-gray-300">Loading assessment templates...</p>
            </div>
          </div>
        ) : viewMode === 'templates' ? (
          // Template Selection View
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-12">
              <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent mb-4">
                Risk Assessment
              </h1>
              <p className="text-xl text-gray-300 max-w-3xl mx-auto">
                Evaluate your export control compliance with our comprehensive risk assessment templates.
              </p>
            </div>
            
            {templates.length > 0 ? (
              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                {templates.map((template) => (
                  <Card key={template.id} className="bg-gray-800/50 border-gray-700 hover:border-blue-500/50 transition-all duration-300 hover:shadow-xl hover:shadow-blue-500/10">
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <CardTitle className="text-white text-lg mb-2">{template.title}</CardTitle>
                          <CardDescription className="text-gray-300 text-sm">
                            {template.description}
                          </CardDescription>
                        </div>
                        <Badge variant="secondary" className="ml-2">
                          {template.sections?.length || 0} sections
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        <div className="flex items-center justify-between text-sm text-gray-400">
                          <span>Questions: {template.sections?.reduce((acc, section) => acc + (section.questions?.length || 0), 0) || 0}</span>
                          <span>Est. time: 15-30 min</span>
                        </div>
                        
                        {/* Show template sections preview */}
                        {template.sections && template.sections.length > 0 && (
                          <div className="border-t border-gray-600 pt-3">
                            <p className="text-xs text-gray-400 mb-2 font-medium">Assessment Sections:</p>
                            <div className="space-y-1">
                              {template.sections.map((section, index) => (
                                <div key={`section-${section.id || index}`} className="text-xs text-gray-300">
                                  <span className="font-medium">{index + 1}.</span> {section.title}
                                  {section.information && (
                                    <p className="text-gray-400 ml-4 mt-1">{section.information}</p>
                                  )}
                                  <p className="text-gray-500 ml-4 text-xs">
                                    {section.questions?.length || 0} questions
                                  </p>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}
                        
                        <Button 
                          onClick={() => startNewAssessment(template)}
                          className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
                        >
                          Start Assessment
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <AlertCircle className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-gray-300 mb-2">No Templates Available</h3>
                <p className="text-gray-400">Assessment templates are currently being loaded. Please try refreshing the page.</p>
              </div>
            )}
          </div>
        ) : viewMode === 'assessment' && selectedTemplate ? (
          // Assessment View
          <div className="max-w-6xl mx-auto">
            {!showOverview ? (
              // Assessment Form
              <div className="space-y-6">
                {/* Header */}
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center space-x-4">
                    <Button
                      variant="outline"
                      onClick={() => {
                        setSelectedTemplate(null);
                        setViewMode('templates');
                      }}
                      className="border-gray-600 text-gray-300 hover:bg-gray-700"
                    >
                      <ArrowLeft className="h-4 w-4 mr-2" />
                      Back to Templates
                    </Button>
                    <div>
                      <h1 className="text-2xl font-bold text-white">{selectedTemplate.title}</h1>
                      <p className="text-gray-400">Section {currentSectionIndex + 1} of {selectedTemplate.sections?.length || 0}</p>
                    </div>
                  </div>
                  <Button
                    onClick={() => setShowOverview(true)}
                    variant="outline"
                    className="border-blue-600 text-blue-400 hover:bg-blue-600/10"
                  >
                    <BarChart3 className="h-4 w-4 mr-2" />
                    View Progress
                  </Button>
                </div>
                
                {/* Assessment Info */}
                {currentSectionIndex === 0 && (
                  <Card className="bg-gray-800/50 border-gray-700 mb-6">
                    <CardHeader>
                      <CardTitle className="text-white">Assessment Information</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="grid gap-4 md:grid-cols-2">
                        <div>
                          <Label htmlFor="company-name" className="text-gray-300">Company Name</Label>
                          <Input
                            id="company-name"
                            value={companyName}
                            onChange={(e) => setCompanyName(e.target.value)}
                            placeholder="Enter your company name"
                            className="bg-gray-700 border-gray-600 text-white"
                          />
                        </div>
                        <div>
                          <Label htmlFor="assessment-title" className="text-gray-300">Assessment Title</Label>
                          <Input
                            id="assessment-title"
                            value={assessmentTitle}
                            onChange={(e) => setAssessmentTitle(e.target.value)}
                            placeholder="Enter assessment title"
                            className="bg-gray-700 border-gray-600 text-white"
                          />
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                )}
                
                {/* Current Section */}
                {selectedTemplate.sections && selectedTemplate.sections[currentSectionIndex] && (
                  <Card className="bg-gray-800/50 border-gray-700">
                    <CardHeader>
                      <CardTitle className="text-white text-xl">
                        {selectedTemplate.sections[currentSectionIndex].title}
                      </CardTitle>
                      {selectedTemplate.sections[currentSectionIndex].description && (
                        <CardDescription className="text-gray-300">
                          {selectedTemplate.sections[currentSectionIndex].description}
                        </CardDescription>
                      )}
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-6">
                        {selectedTemplate.sections[currentSectionIndex].questions?.map((question) => {
                          const responseKey = `${selectedTemplate.sections[currentSectionIndex].id}_${question.id}`;
                          const currentResponse = responses[responseKey];
                          
                          return (
                            <div key={question.id} className="p-4 bg-gray-700/30 rounded-lg border border-gray-600">
                              <div className="mb-4">
                                <h3 className="text-lg font-medium text-white mb-2">
                                  {question.question_text}
                                </h3>
                                {question.description && (
                                  <p className="text-sm text-gray-400 mb-3">{question.description}</p>
                                )}
                              </div>
                              
                              {question.question_type === 'rating' && (
                                <RadioGroup
                                  value={currentResponse?.answer as string || ''}
                                  onValueChange={(value) => 
                                    updateResponse(question.id, selectedTemplate.sections[currentSectionIndex].id, value)
                                  }
                                  className="flex flex-wrap gap-4"
                                >
                                  {[1, 2, 3, 4, 5].map((rating) => (
                                    <div key={rating} className="flex items-center space-x-2">
                                      <RadioGroupItem value={rating.toString()} id={`${question.id}-${rating}`} />
                                      <Label htmlFor={`${question.id}-${rating}`} className="text-gray-300">
                                        {rating}
                                      </Label>
                                    </div>
                                  ))}
                                  <div className="flex items-center space-x-2">
                                    <RadioGroupItem value="N/A" id={`${question.id}-na`} />
                                    <Label htmlFor={`${question.id}-na`} className="text-gray-400">
                                      N/A
                                    </Label>
                                  </div>
                                </RadioGroup>
                              )}
                              
                              {question.question_type === 'text' && (
                                <Textarea
                                  value={currentResponse?.answer as string || ''}
                                  onChange={(e) => 
                                    updateResponse(question.id, selectedTemplate.sections[currentSectionIndex].id, e.target.value)
                                  }
                                  placeholder="Enter your response..."
                                  className="bg-gray-700 border-gray-600 text-white"
                                  rows={3}
                                />
                              )}
                              
                              {question.question_type === 'multiple_choice' && question.options && (
                                <RadioGroup
                                  value={currentResponse?.answer as string || ''}
                                  onValueChange={(value) => 
                                    updateResponse(question.id, selectedTemplate.sections[currentSectionIndex].id, value)
                                  }
                                  className="space-y-2"
                                >
                                  {question.options.map((option, optionIndex) => (
                                    <div key={optionIndex} className="flex items-center space-x-2">
                                      <RadioGroupItem value={option} id={`${question.id}-${optionIndex}`} />
                                      <Label htmlFor={`${question.id}-${optionIndex}`} className="text-gray-300">
                                        {option}
                                      </Label>
                                    </div>
                                  ))}
                                </RadioGroup>
                              )}
                              
                              {question.question_type === 'checkbox' && question.options && (
                                <div className="space-y-2">
                                  {question.options.map((option, optionIndex) => {
                                    const currentAnswers = (currentResponse?.answer as string[]) || [];
                                    return (
                                      <div key={optionIndex} className="flex items-center space-x-2">
                                        <Checkbox
                                          id={`${question.id}-${optionIndex}`}
                                          checked={currentAnswers.includes(option)}
                                          onCheckedChange={(checked) => {
                                            const newAnswers = checked 
                                              ? [...currentAnswers, option]
                                              : currentAnswers.filter(a => a !== option);
                                            updateResponse(question.id, selectedTemplate.sections[currentSectionIndex].id, newAnswers);
                                          }}
                                        />
                                        <Label htmlFor={`${question.id}-${optionIndex}`} className="text-gray-300">
                                          {option}
                                        </Label>
                                      </div>
                                    );
                                  })}
                                </div>
                              )}
                              
                              {/* Notes field */}
                              <div className="mt-4">
                                <Label className="text-gray-400 text-sm">Additional Notes (Optional)</Label>
                                <Textarea
                                  value={currentResponse?.notes || ''}
                                  onChange={(e) => {
                                    const responseKey = `${selectedTemplate.sections[currentSectionIndex].id}_${question.id}`;
                                    setResponses(prev => ({
                                      ...prev,
                                      [responseKey]: {
                                        ...prev[responseKey],
                                        questionId: question.id,
                                        sectionId: selectedTemplate.sections[currentSectionIndex].id,
                                        answer: prev[responseKey]?.answer || '',
                                        notes: e.target.value
                                      }
                                    }));
                                  }}
                                  placeholder="Add any additional notes or context..."
                                  className="bg-gray-700/50 border-gray-600 text-gray-300 text-sm"
                                  rows={2}
                                />
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </CardContent>
                  </Card>
                )}
                
                {/* Navigation */}
                <div className="flex items-center justify-between pt-6">
                  <Button
                    onClick={() => setCurrentSectionIndex(Math.max(0, currentSectionIndex - 1))}
                    disabled={currentSectionIndex === 0}
                    variant="outline"
                    className="border-gray-600 text-gray-300 hover:bg-gray-700"
                  >
                    <ArrowLeft className="h-4 w-4 mr-2" />
                    Previous Section
                  </Button>
                  
                  <div className="flex space-x-3">
                    <Button
                      onClick={() => submitAssessment('draft')}
                      disabled={submitting}
                      variant="outline"
                      className="border-gray-600 text-gray-300 hover:bg-gray-700"
                    >
                      Save Draft
                    </Button>
                    
                    {currentSectionIndex < (selectedTemplate.sections?.length || 0) - 1 ? (
                      <Button
                        onClick={() => setCurrentSectionIndex(currentSectionIndex + 1)}
                        className="bg-blue-600 hover:bg-blue-700"
                      >
                        Next Section
                        <ArrowRight className="h-4 w-4 ml-2" />
                      </Button>
                    ) : (
                      <Button
                        onClick={() => setShowOverview(true)}
                        className="bg-green-600 hover:bg-green-700"
                      >
                        Complete Assessment
                        <Check className="h-4 w-4 ml-2" />
                      </Button>
                    )}
                  </div>
                </div>
              </div>
            ) : (
              // Overview/Completion View
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <div>
                    <h1 className="text-3xl font-bold text-white mb-2">Assessment Overview</h1>
                    <p className="text-gray-400">{selectedTemplate.title}</p>
                  </div>
                  <Button
                    onClick={() => setShowOverview(false)}
                    variant="outline"
                    className="border-gray-600 text-gray-300 hover:bg-gray-700"
                  >
                    <ArrowLeft className="h-4 w-4 mr-2" />
                    Back to Assessment
                  </Button>
                </div>
                
                {/* Risk Score Display */}
                {(() => {
                  const riskData = calculateOverallRiskScore();
                  if (!riskData) return null;
                  
                  return (
                    <Card className="bg-gray-800/50 border-gray-700">
                      <CardHeader>
                        <CardTitle className="text-white flex items-center">
                          <Shield className="h-5 w-5 mr-2" />
                          Overall Risk Score
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="flex items-center justify-between">
                          <div className="text-center">
                            <div className={`text-4xl font-bold ${
                              riskData.riskLevel === 'low' ? 'text-green-400' :
                              riskData.riskLevel === 'medium' ? 'text-yellow-400' : 'text-red-400'
                            }`}>
                              {riskData.percentage.toFixed(1)}%
                            </div>
                            <div className={`text-sm font-medium uppercase ${
                              riskData.riskLevel === 'low' ? 'text-green-400' :
                              riskData.riskLevel === 'medium' ? 'text-yellow-400' : 'text-red-400'
                            }`}>
                              {riskData.riskLevel} Risk
                            </div>
                          </div>
                          <div className="text-right text-gray-300">
                            <p>Questions Answered: {riskData.answeredQuestions}/{riskData.totalRatingQuestions}</p>
                            <p>Not Applicable: {riskData.notApplicableCount}</p>
                            <p>Score: {riskData.totalScore}/{riskData.maxScore}</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })()}
                
                {/* Action Buttons */}
                <div className="flex flex-wrap gap-4">
                  <Button
                    onClick={() => submitAssessment('completed')}
                    disabled={submitting}
                    className="bg-green-600 hover:bg-green-700"
                  >
                    {submitting ? 'Saving...' : 'Complete Assessment'}
                  </Button>
                  
                  <Button
                    onClick={() => submitAssessment('draft')}
                    disabled={submitting}
                    variant="outline"
                    className="border-gray-600 text-gray-300 hover:bg-gray-700"
                  >
                    Save as Draft
                  </Button>
                  
                  <Button
                    onClick={exportAssessmentPdf}
                    disabled={exportingPdf || !assessmentId}
                    variant="outline"
                    className="border-blue-600 text-blue-300 hover:bg-blue-700"
                  >
                    {exportingPdf ? (
                      <>
                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                        Exporting...
                      </>
                    ) : (
                      <>
                        <Download className="h-4 w-4 mr-2" />
                        Export PDF
                      </>
                    )}
                  </Button>
                </div>
              </div>
            )}
          </div>
        ) : null}
      </div>
      <Footer />
    </div>
  );
};

export default RiskAssessment;
