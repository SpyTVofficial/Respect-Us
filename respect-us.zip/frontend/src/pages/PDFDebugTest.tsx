import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { APP_BASE_PATH } from 'app';
import { ExternalLink, FileText, TestTube, CheckCircle } from 'lucide-react';
import { toast } from 'sonner';
import brain from 'brain';

const PDFDebugTest: React.FC = () => {
  const [documentId, setDocumentId] = useState('72'); // Default to a known PDF document
  const [documentTitle, setDocumentTitle] = useState('Test PDF Document');
  const [testResults, setTestResults] = useState<Record<string, string>>({});
  
  const testPDFViewer = () => {
    const pdfViewerPath = `pdf-viewer-tab?documentId=${documentId}&title=${encodeURIComponent(documentTitle)}`;
    const fullUrl = `${window.location.origin}${APP_BASE_PATH}/${pdfViewerPath}`;
    
    console.log('Testing PDF viewer:', {
      documentId,
      documentTitle,
      pdfViewerPath,
      APP_BASE_PATH,
      fullUrl
    });
    
    setTestResults(prev => ({ ...prev, pdfViewer: 'opened' }));
    toast.success('PDF viewer tab opened - check new tab');
    
    // Open in new tab
    window.open(fullUrl, '_blank', 'noopener,noreferrer');
  };
  
  const testDirectAPI = async () => {
    try {
      setTestResults(prev => ({ ...prev, directApi: 'testing' }));
      
      const response = await brain.download_document_file({ documentId: parseInt(documentId) });
      
      if (response.ok) {
        const blob = await response.blob();
        console.log('Direct API test successful:', blob.size, 'bytes');
        setTestResults(prev => ({ ...prev, directApi: 'success' }));
        toast.success(`Direct API test successful: ${blob.size} bytes`);
        
        // Also test opening the direct URL
        const apiUrl = `${window.location.origin}${APP_BASE_PATH.replace('/ui/', '/routes/')}knowledge-base/file/${documentId}`;
        window.open(apiUrl, '_blank', 'noopener,noreferrer');
      } else {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }
    } catch (error) {
      console.error('Direct API test failed:', error);
      setTestResults(prev => ({ ...prev, directApi: 'failed' }));
      toast.error(`Direct API test failed: ${error}`);
    }
  };
  
  const testKnowledgeBaseFlow = () => {
    // Simulate the exact flow from Knowledge Base
    const doc = {
      id: parseInt(documentId),
      title: documentTitle,
      file_type: 'application/pdf'
    };
    
    // This mirrors the handleDocumentClick logic
    const pdfViewerPath = `pdf-viewer-tab?documentId=${doc.id}&title=${encodeURIComponent(doc.title)}`;
    const fullUrl = `${window.location.origin}${APP_BASE_PATH}/${pdfViewerPath}`;
    
    console.log('Testing Knowledge Base flow:', {
      doc,
      pdfViewerPath,
      fullUrl
    });
    
    setTestResults(prev => ({ ...prev, knowledgeBaseFlow: 'opened' }));
    toast.info(`Opening: ${doc.title}`);
    window.open(fullUrl, '_blank', 'noopener,noreferrer');
  };
  
  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'success':
      case 'opened':
        return <CheckCircle className="w-4 h-4 text-green-400" />;
      case 'testing':
        return <TestTube className="w-4 h-4 text-yellow-400 animate-pulse" />;
      case 'failed':
        return <ExternalLink className="w-4 h-4 text-red-400" />;
      default:
        return null;
    }
  };
  
  return (
    <div className="min-h-screen bg-gray-900 p-6">
      <Card className="max-w-2xl mx-auto bg-gray-800 border-gray-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <TestTube className="w-6 h-6" />
            PDF Viewer Debug Test
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-4">
            <div>
              <Label htmlFor="documentId" className="text-gray-300">Document ID</Label>
              <Input
                id="documentId"
                value={documentId}
                onChange={(e) => setDocumentId(e.target.value)}
                className="bg-gray-700 border-gray-600 text-white"
                placeholder="Enter document ID"
              />
            </div>
            
            <div>
              <Label htmlFor="documentTitle" className="text-gray-300">Document Title</Label>
              <Input
                id="documentTitle"
                value={documentTitle}
                onChange={(e) => setDocumentTitle(e.target.value)}
                className="bg-gray-700 border-gray-600 text-white"
                placeholder="Enter document title"
              />
            </div>
          </div>
          
          <div className="space-y-3">
            <Button 
              onClick={testPDFViewer}
              className="w-full bg-blue-600 hover:bg-blue-700 text-white flex items-center justify-between"
            >
              <span className="flex items-center">
                <FileText className="w-4 h-4 mr-2" />
                Test PDF Viewer Tab
              </span>
              {getStatusIcon(testResults.pdfViewer)}
            </Button>
            
            <Button 
              onClick={testDirectAPI}
              variant="outline"
              className="w-full border-gray-600 text-gray-300 hover:bg-gray-700 flex items-center justify-between"
            >
              <span className="flex items-center">
                <ExternalLink className="w-4 h-4 mr-2" />
                Test Direct API Access
              </span>
              {getStatusIcon(testResults.directApi)}
            </Button>
            
            <Button 
              onClick={testKnowledgeBaseFlow}
              className="w-full bg-purple-600 hover:bg-purple-700 text-white flex items-center justify-between"
            >
              <span className="flex items-center">
                <FileText className="w-4 h-4 mr-2" />
                Test Knowledge Base Flow
              </span>
              {getStatusIcon(testResults.knowledgeBaseFlow)}
            </Button>
          </div>
          
          <div className="bg-gray-700 p-4 rounded-lg">
            <h3 className="text-white font-semibold mb-2">Debug Info:</h3>
            <pre className="text-xs text-gray-300 whitespace-pre-wrap">
              {JSON.stringify({
                currentOrigin: window.location.origin,
                APP_BASE_PATH,
                constructedPDFPath: `pdf-viewer-tab?documentId=${documentId}&title=${encodeURIComponent(documentTitle)}`,
                fullPDFUrl: `${window.location.origin}${APP_BASE_PATH}/pdf-viewer-tab?documentId=${documentId}&title=${encodeURIComponent(documentTitle)}`,
                directApiUrl: `${window.location.origin}${APP_BASE_PATH.replace('/ui/', '/routes/')}knowledge-base/file/${documentId}`
              }, null, 2)}
            </pre>
          </div>
          
          <div className="bg-yellow-900/30 border border-yellow-600/30 p-4 rounded-lg">
            <h4 className="text-yellow-400 font-semibold mb-2">Known Working Documents:</h4>
            <ul className="text-yellow-300 text-sm space-y-1">
              <li>• Document ID 72: EU Council Regulation (PDF)</li>
              <li>• Document ID 71: EU Council Decision (PDF)</li>
              <li>• Document ID 98: UN Security Council Resolution (PDF)</li>
            </ul>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default PDFDebugTest;
