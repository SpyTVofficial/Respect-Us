
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  MessageSquare, 
  Bookmark, 
  Users, 
  Activity, 
  FileText, 
  Eye,
  ArrowRight,
  Star,
  TrendingUp
} from 'lucide-react';
import { CollaborationDashboard } from 'components/CollaborationDashboard';
import { AnnotationPanel } from 'components/AnnotationPanel';
import { BookmarkManager } from 'components/BookmarkManager';
import { ActivityFeed } from 'components/ActivityFeed';

interface DemoDocument {
  id: number;
  title: string;
  description: string;
  content: string;
  jurisdiction: string;
  category: string;
}

const DEMO_DOCUMENTS: DemoDocument[] = [
  {
    id: 1,
    title: "EU Export Control Regulation (2021/821)",
    description: "Comprehensive regulation on dual-use items export controls",
    content: `Article 3 - Scope and definitions

1. This Regulation shall apply to the export, transit, brokering and technical assistance related to dual-use items.

2. For the purposes of this Regulation, the following definitions apply:

(a) 'dual-use items' means items, including software and technology, which can be used for both civilian and military purposes, and shall include all goods which can be used for both non-explosive uses and assisting in any way in the manufacture of nuclear weapons or other nuclear explosive devices;

(b) 'export' means:
(i) an export procedure within the meaning of Article 269 of Regulation (EU) No 952/2013;
(ii) a re-export within the meaning of Article 270 of that Regulation;
(iii) an exit from the customs territory of the Union following a transit procedure within the meaning of Article 226 of that Regulation, where the goods are not in free circulation;

Article 9 - Individual export authorisations

1. Individual export authorisations shall be valid throughout the customs territory of the Union.

2. Individual export authorisations shall be valid for exports to the end-users and for the end-uses specified therein.

3. Individual export authorisations shall be valid for a period not exceeding four years.

This section contains important provisions regarding the control of dual-use goods that may require licensing for export to certain destinations. The regulation establishes a comprehensive framework for ensuring that sensitive technologies do not fall into the wrong hands while facilitating legitimate trade.

Key compliance requirements include:
- Proper classification of goods
- Destination country analysis
- End-user verification
- License application procedures
- Record keeping obligations`,
    jurisdiction: "European Union",
    category: "Export Control"
  },
  {
    id: 2,
    title: "OFAC Sanctions Compliance Guidelines",
    description: "Guidelines for compliance with US economic sanctions programs",
    content: `Section 1: Overview of OFAC Sanctions Programs

The Office of Foreign Assets Control (OFAC) administers and enforces economic and trade sanctions based on US foreign policy and national security goals.

Key Programs:
- Specially Designated Nationals (SDN) List
- Sectoral Sanctions Identifications (SSI) List
- Foreign Sanctions Evaders (FSE) List
- Non-SDN Palestinian Legislative Council (NS-PLC) List

Section 2: Screening Requirements

All US persons must screen their transactions against OFAC's sanctions lists before conducting business.

Required Actions:
1. Screen all parties to transactions
2. Check beneficial ownership
3. Monitor ongoing relationships
4. Report suspicious activities

Section 3: Compliance Best Practices

- Implement automated screening systems
- Maintain comprehensive documentation
- Establish clear escalation procedures
- Conduct regular compliance training
- Perform periodic compliance audits

Failure to comply with OFAC sanctions can result in severe civil and criminal penalties, including substantial fines and imprisonment.`,
    jurisdiction: "United States",
    category: "Sanctions"
  }
];

export default function CollaborationDemo() {
  const [selectedDocument, setSelectedDocument] = useState<DemoDocument>(DEMO_DOCUMENTS[0]);
  const [selectedText, setSelectedText] = useState<string>('');
  const [selectionData, setSelectionData] = useState<any>(null);
  const [activeTab, setActiveTab] = useState('overview');

  const handleTextSelection = () => {
    const selection = window.getSelection();
    if (selection && selection.toString().length > 0) {
      const text = selection.toString();
      setSelectedText(text);
      setSelectionData({
        start: selection.anchorOffset,
        end: selection.focusOffset,
        text: text
      });
      setActiveTab('annotations');
    }
  };

  const clearSelection = () => {
    setSelectedText('');
    setSelectionData(null);
  };

  return (
    <div className="p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center space-y-4">
          <div className="flex items-center justify-center gap-3">
            <Users className="h-8 w-8 text-blue-400" />
            <h1 className="text-4xl font-bold text-gray-100">Collaboration Features Demo</h1>
          </div>
          <p className="text-gray-400 text-lg max-w-3xl mx-auto">
            Explore RespectUs's advanced annotation and collaboration features. Select text to create annotations, 
            manage bookmarks, and track document activity in real-time.
          </p>
        </div>

        {/* Feature Highlights */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="bg-gradient-to-br from-blue-900/20 to-blue-700/10 border-blue-700/30">
            <CardContent className="p-4 text-center">
              <MessageSquare className="h-8 w-8 text-blue-400 mx-auto mb-2" />
              <h3 className="font-semibold text-gray-100 mb-1">Smart Annotations</h3>
              <p className="text-xs text-gray-400">Create highlights, notes, and threaded comments</p>
            </CardContent>
          </Card>
          
          <Card className="bg-gradient-to-br from-green-900/20 to-green-700/10 border-green-700/30">
            <CardContent className="p-4 text-center">
              <Bookmark className="h-8 w-8 text-green-400 mx-auto mb-2" />
              <h3 className="font-semibold text-gray-100 mb-1">Bookmarking</h3>
              <p className="text-xs text-gray-400">Save and organize important sections</p>
            </CardContent>
          </Card>
          
          <Card className="bg-gradient-to-br from-purple-900/20 to-purple-700/10 border-purple-700/30">
            <CardContent className="p-4 text-center">
              <Activity className="h-8 w-8 text-purple-400 mx-auto mb-2" />
              <h3 className="font-semibold text-gray-100 mb-1">Activity Tracking</h3>
              <p className="text-xs text-gray-400">Monitor all document interactions</p>
            </CardContent>
          </Card>
          
          <Card className="bg-gradient-to-br from-yellow-900/20 to-yellow-700/10 border-yellow-700/30">
            <CardContent className="p-4 text-center">
              <TrendingUp className="h-8 w-8 text-yellow-400 mx-auto mb-2" />
              <h3 className="font-semibold text-gray-100 mb-1">Analytics</h3>
              <p className="text-xs text-gray-400">Collaboration insights and statistics</p>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Document Viewer */}
          <div className="space-y-4">
            <Card className="bg-gray-800/50 border-gray-700">
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center gap-2 text-gray-100">
                  <FileText className="h-5 w-5 text-blue-400" />
                  Document Viewer
                </CardTitle>
                <div className="flex gap-2">
                  {DEMO_DOCUMENTS.map((doc) => (
                    <Button
                      key={doc.id}
                      variant={selectedDocument.id === doc.id ? "default" : "outline"}
                      size="sm"
                      onClick={() => {
                        setSelectedDocument(doc);
                        clearSelection();
                      }}
                      className={`text-xs ${
                        selectedDocument.id === doc.id 
                          ? 'bg-blue-600 hover:bg-blue-700' 
                          : 'border-gray-600 text-gray-300 hover:bg-gray-700'
                      }`}
                    >
                      Doc {doc.id}
                    </Button>
                  ))}
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Document Info */}
                <div className="space-y-2">
                  <h3 className="text-lg font-semibold text-gray-100">{selectedDocument.title}</h3>
                  <p className="text-gray-400 text-sm">{selectedDocument.description}</p>
                  <div className="flex gap-2">
                    <Badge className="bg-blue-600/20 text-blue-300 border-blue-500/30">
                      {selectedDocument.jurisdiction}
                    </Badge>
                    <Badge className="bg-green-600/20 text-green-300 border-green-500/30">
                      {selectedDocument.category}
                    </Badge>
                  </div>
                </div>

                {/* Document Content */}
                <div 
                  className="bg-gray-700/30 p-4 rounded border max-h-96 overflow-y-auto"
                  onMouseUp={handleTextSelection}
                >
                  <div className="prose prose-sm prose-invert max-w-none">
                    {selectedDocument.content.split('\n\n').map((paragraph, index) => (
                      <p key={index} className="text-gray-200 mb-3 leading-relaxed">
                        {paragraph}
                      </p>
                    ))}
                  </div>
                </div>

                {/* Selection Info */}
                {selectedText && (
                  <div className="bg-blue-600/10 border border-blue-500/20 p-3 rounded">
                    <div className="flex items-start justify-between">
                      <div>
                        <p className="text-blue-300 text-sm font-medium mb-1">Text Selected:</p>
                        <p className="text-gray-200 text-sm">"{selectedText}"</p>
                      </div>
                      <Button 
                        size="sm" 
                        onClick={clearSelection}
                        className="bg-blue-600 hover:bg-blue-700"
                      >
                        Clear
                      </Button>
                    </div>
                    <p className="text-blue-400 text-xs mt-2 flex items-center gap-1">
                      <ArrowRight className="h-3 w-3" />
                      Switch to Annotations tab to create an annotation
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Collaboration Panel */}
          <div className="space-y-4">
            <Card className="bg-gray-800/50 border-gray-700">
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center gap-2 text-gray-100">
                  <Users className="h-5 w-5 text-purple-400" />
                  Collaboration Features
                  {selectedText && (
                    <Badge className="bg-green-600 text-white animate-pulse">
                      Ready to Annotate
                    </Badge>
                  )}
                </CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
                  <TabsList className="grid w-full grid-cols-4 bg-gray-700/50 m-4 mb-0">
                    <TabsTrigger value="overview" className="data-[state=active]:bg-gray-600 text-xs">
                      Overview
                    </TabsTrigger>
                    <TabsTrigger value="annotations" className="data-[state=active]:bg-gray-600 text-xs">
                      Annotations
                    </TabsTrigger>
                    <TabsTrigger value="bookmarks" className="data-[state=active]:bg-gray-600 text-xs">
                      Bookmarks
                    </TabsTrigger>
                    <TabsTrigger value="activity" className="data-[state=active]:bg-gray-600 text-xs">
                      Activity
                    </TabsTrigger>
                  </TabsList>

                  <div className="p-4">
                    <TabsContent value="overview" className="mt-0">
                      <CollaborationDashboard documentId={selectedDocument.id} />
                    </TabsContent>

                    <TabsContent value="annotations" className="mt-0">
                      <AnnotationPanel 
                        documentId={selectedDocument.id}
                        selectedText={selectedText}
                        selectionData={selectionData}
                        onAnnotationCreated={() => {
                          clearSelection();
                          // Could refresh other tabs here
                        }}
                      />
                    </TabsContent>

                    <TabsContent value="bookmarks" className="mt-0">
                      <BookmarkManager 
                        documentId={selectedDocument.id}
                        onBookmarkClick={(bookmark) => {
                          // Could navigate to the bookmarked document/section
                          console.log('Navigate to bookmark:', bookmark);
                        }}
                      />
                    </TabsContent>

                    <TabsContent value="activity" className="mt-0">
                      <ActivityFeed 
                        documentId={selectedDocument.id}
                        limit={20}
                      />
                    </TabsContent>
                  </div>
                </Tabs>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Demo Instructions */}
        <Card className="bg-gradient-to-r from-indigo-900/20 to-purple-900/20 border-indigo-700/30">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-gray-100">
              <Star className="h-5 w-5 text-yellow-400" />
              Try These Features
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 text-sm">
              <div className="space-y-2">
                <h4 className="font-medium text-blue-300">1. Create Annotations</h4>
                <p className="text-gray-400">Select any text in the document viewer and switch to the Annotations tab to create highlights, notes, or comments.</p>
              </div>
              
              <div className="space-y-2">
                <h4 className="font-medium text-green-300">2. Manage Bookmarks</h4>
                <p className="text-gray-400">Save important sections with custom tags and descriptions for easy reference later.</p>
              </div>
              
              <div className="space-y-2">
                <h4 className="font-medium text-purple-300">3. Track Activity</h4>
                <p className="text-gray-400">Monitor all document interactions and collaboration activities in real-time.</p>
              </div>
              
              <div className="space-y-2">
                <h4 className="font-medium text-yellow-300">4. View Analytics</h4>
                <p className="text-gray-400">Check collaboration statistics and your personal contribution metrics.</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
