



import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useUserGuardContext } from 'app/auth';
import { List, Copy, Edit3, Eye, CheckCircle2, Plus, Save, ArrowLeft } from 'lucide-react';
import { toast } from 'sonner';
import brain from 'brain';
import { useNavigate } from 'react-router-dom';

interface Question {
  text: string;
  type: string;
  required: boolean;
  options?: string[];
  notes_enabled?: boolean;
}

interface Section {
  title: string;
  questions: Question[];
}

interface Template {
  id: number;
  title: string;
  description: string;
  sections: Section[];
  status: string;
  created_at: string;
}

interface CompanyForm {
  id: number;
  template_id: number;
  template_title: string;
  template_description: string;
  company_name: string;
  customizations: any;
  created_at: string;
}

const RiskAssessmentTemplates = () => {
  const { user } = useUserGuardContext();
  const navigate = useNavigate();
  const [templates, setTemplates] = useState<Template[]>([]);
  const [companyForms, setCompanyForms] = useState<CompanyForm[]>([]);
  const [selectedTemplate, setSelectedTemplate] = useState<Template | null>(null);
  const [isCustomizing, setIsCustomizing] = useState(false);
  const [customizedSections, setCustomizedSections] = useState<Section[]>([]);
  const [companyName, setCompanyName] = useState('');
  const [loading, setLoading] = useState(true);
  const [accessLoading, setAccessLoading] = useState(false);
  const [showCreditDialog, setShowCreditDialog] = useState(false);
  const [creditAction, setCreditAction] = useState<'use' | 'customize' | null>(null);
  const [selectedTemplateForAccess, setSelectedTemplateForAccess] = useState<Template | null>(null);
  const [showHighValueConfirmation, setShowHighValueConfirmation] = useState(false);
  const [pendingHighValueAction, setPendingHighValueAction] = useState<{template: Template, action: 'use' | 'customize', creditCost: number} | null>(null);

  // Load templates and company forms
  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      setLoading(true);
      
      // Load available templates
      const templatesResponse = await brain.list_templates();
      const templatesData = await templatesResponse.json();
      setTemplates(templatesData.templates || []);
      
      // Load company forms
      const formsResponse = await brain.list_company_forms();
      const formsData = await formsResponse.json();
      setCompanyForms(formsData.forms || []);
      
    } catch (error) {
      console.error('Error loading data:', error);
      toast.error('Failed to load templates');
    } finally {
      setLoading(false);
    }
  };

  const handleTemplateAccess = async (template: Template, action: 'use' | 'customize') => {
    try {
      setAccessLoading(true);
      
      // First, check the credit cost by reserving credits
      const reserveResponse = await brain.reserve_credits({
        component_name: 'risk_assessment',
        action_name: 'access_templates',
        resource_id: template.id.toString()
      });
      
      if (reserveResponse.ok) {
        const reserveData = await reserveResponse.json();
        // Use required_credits from reserve response, fallback to 3 credits
        const creditCost = reserveData.required_credits || 3;
        
        // If cost is over 2,000 credits, show confirmation dialog
        if (creditCost > 2000) {
          setPendingHighValueAction({ template, action, creditCost });
          setShowHighValueConfirmation(true);
          setAccessLoading(false);
          return;
        }
        
        // For lower amounts, proceed directly
        await proceedWithCreditConsumption(template, action);
      } else {
        const error = await reserveResponse.json();
        if (reserveResponse.status === 402) {
          // Insufficient credits
          setSelectedTemplateForAccess(template);
          setCreditAction(action);
          setShowCreditDialog(true);
        } else {
          toast.error(error.detail || 'Failed to check template access cost');
        }
      }
    } catch (error) {
      console.error('Error accessing template:', error);
      toast.error('Error accessing template. Please try again.');
    } finally {
      setAccessLoading(false);
    }
  };

  const proceedWithCreditConsumption = async (template: Template, action: 'use' | 'customize') => {
    try {
      // Consume credits for template access
      const consumeResponse = await brain.consume_credits({
        component_name: 'risk_assessment',
        action_name: 'access_templates',
        resource_id: template.id.toString(),
        description: `Template access: ${template.title} (${action})`
      });
      
      if (consumeResponse.ok) {
        const consumeData = await consumeResponse.json();
        toast.success(`Template access granted! ${consumeData.credits_consumed} credits consumed.`);
        
        // Proceed with the template action
        if (action === 'customize') {
          setSelectedTemplate(template);
          setCustomizedSections(template.sections);
          setIsCustomizing(true);
        } else {
          // Navigate to risk assessment with template
          navigate(`/risk-assessment?template=${template.id}`);
        }
      } else {
        const error = await consumeResponse.json();
        if (consumeResponse.status === 402) {
          toast.error('Insufficient credits for template access');
          setSelectedTemplateForAccess(template);
          setCreditAction(action);
          setShowCreditDialog(true);
        } else {
          toast.error(error.detail || 'Failed to consume credits for template access');
        }
      }
    } catch (error) {
      console.error('Error consuming credits for template access:', error);
      toast.error('Error processing template access. Please try again.');
    }
  };

  const startCustomization = (template: Template) => {
    handleTemplateAccess(template, 'customize');
  };
  
  const startUsingTemplate = (template: Template) => {
    handleTemplateAccess(template, 'use');
  };

  const saveCustomization = async () => {
    if (!selectedTemplate || !companyName.trim()) {
      toast.error('Please enter a company name');
      return;
    }

    try {
      const customizations = {
        sections: customizedSections,
        modified_at: new Date().toISOString()
      };

      await brain.customize_template({
        template_id: selectedTemplate.id,
        company_name: companyName,
        customizations
      });

      toast.success('Customized form saved successfully!');
      setIsCustomizing(false);
      setSelectedTemplate(null);
      setCompanyName('');
      loadData(); // Reload to show new form
      
    } catch (error) {
      console.error('Error saving customization:', error);
      toast.error('Failed to save customization');
    }
  };

  const updateQuestion = (sectionIndex: number, questionIndex: number, field: string, value: any) => {
    const updated = [...customizedSections];
    (updated[sectionIndex].questions[questionIndex] as any)[field] = value;
    setCustomizedSections(updated);
  };

  const addQuestion = (sectionIndex: number) => {
    const updated = [...customizedSections];
    updated[sectionIndex].questions.push({
      text: '',
      type: 'text',
      required: true,
      options: []
    });
    setCustomizedSections(updated);
  };

  const removeQuestion = (sectionIndex: number, questionIndex: number) => {
    const updated = [...customizedSections];
    updated[sectionIndex].questions.splice(questionIndex, 1);
    setCustomizedSections(updated);
  };

  const updateSectionTitle = (sectionIndex: number, title: string) => {
    const updated = [...customizedSections];
    updated[sectionIndex].title = title;
    setCustomizedSections(updated);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-black text-white p-6">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-center h-64">
            <div className="text-center">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mx-auto mb-4"></div>
              <p className="text-gray-400">Loading templates...</p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (isCustomizing && selectedTemplate) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-black text-white p-6">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-4">
              <Button
                variant="ghost"
                onClick={() => setIsCustomizing(false)}
                className="text-gray-400 hover:text-white"
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Templates
              </Button>
              <div>
                <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-400 to-purple-500 bg-clip-text text-transparent">
                  Customize Template
                </h1>
                <p className="text-gray-400 mt-1">{selectedTemplate.title}</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <Button
                onClick={saveCustomization}
                className="bg-blue-600 hover:bg-blue-700"
              >
                <Save className="w-4 h-4 mr-2" />
                Save Customization
              </Button>
            </div>
          </div>

          {/* Company Name */}
          <Card className="bg-gray-900/50 border-gray-700 backdrop-blur-sm mb-6">
            <CardHeader>
              <CardTitle className="text-white">Company Information</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="max-w-md">
                <Label className="text-white">Company Name</Label>
                <Input
                  value={companyName}
                  onChange={(e) => setCompanyName(e.target.value)}
                  className="bg-gray-800 border-gray-700 text-white"
                  placeholder="Enter your company name"
                />
              </div>
            </CardContent>
          </Card>

          {/* Customizable Sections */}
          <div className="space-y-6">
            {customizedSections.map((section, sectionIndex) => (
              <Card key={sectionIndex} className="bg-gray-900/50 border-gray-700 backdrop-blur-sm">
                <CardHeader>
                  <div className="flex items-center gap-3">
                    <Input
                      value={section.title}
                      onChange={(e) => updateSectionTitle(sectionIndex, e.target.value)}
                      className="bg-gray-800 border-gray-700 text-white font-medium"
                    />
                    <Button
                      size="sm"
                      onClick={() => addQuestion(sectionIndex)}
                      className="bg-gray-700 hover:bg-gray-600"
                    >
                      <Plus className="w-4 h-4" />
                    </Button>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  {section.questions.map((question, questionIndex) => (
                    <div key={questionIndex} className="p-4 bg-gray-800/30 border border-gray-700 rounded-lg space-y-3">
                      <div className="flex gap-3">
                        <Input
                          value={question.text}
                          onChange={(e) => updateQuestion(sectionIndex, questionIndex, 'text', e.target.value)}
                          className="bg-gray-700 border-gray-600 text-white flex-1"
                          placeholder="Question text"
                        />
                        <Select
                          value={question.type}
                          onValueChange={(value) => updateQuestion(sectionIndex, questionIndex, 'type', value)}
                        >
                          <SelectTrigger className="w-32 bg-gray-700 border-gray-600 text-white">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent className="bg-gray-800 border-gray-700">
                            <SelectItem value="text" className="text-white">Text</SelectItem>
                            <SelectItem value="textarea" className="text-white">Long Text</SelectItem>
                            <SelectItem value="select" className="text-white">Dropdown</SelectItem>
                            <SelectItem value="radio" className="text-white">Radio</SelectItem>
                            <SelectItem value="checkbox" className="text-white">Checkbox</SelectItem>
                            <SelectItem value="multiselect" className="text-white">Multi-select</SelectItem>
                            <SelectItem value="rating" className="text-white">Rating (Colored)</SelectItem>
                          </SelectContent>
                        </Select>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => removeQuestion(sectionIndex, questionIndex)}
                          className="text-red-400 hover:text-red-300"
                        >
                          ×
                        </Button>
                      </div>
                      
                      {['select', 'radio', 'checkbox', 'multiselect'].includes(question.type) && (
                        <div>
                          <Label className="text-sm text-gray-300">Options (one per line)</Label>
                          <Textarea
                            value={question.options?.join('\n') || ''}
                            onChange={(e) => updateQuestion(sectionIndex, questionIndex, 'options', e.target.value.split('\n').filter(opt => opt.trim()))}
                            className="bg-gray-700 border-gray-600 text-white text-sm"
                            placeholder="Option 1\nOption 2\nOption 3"
                            rows={3}
                          />
                        </div>
                      )}
                      
                      {question.type === 'rating' && (
                        <div className="space-y-2">
                          <div className="text-sm text-gray-300">Rating options will be automatically set to:</div>
                          <div className="grid grid-cols-3 gap-2 text-xs">
                            <div className="p-2 bg-green-600 text-white rounded text-center">Strong</div>
                            <div className="p-2 bg-green-400 text-white rounded text-center">Adequate</div>
                            <div className="p-2 bg-orange-300 text-gray-800 rounded text-center">Weak</div>
                            <div className="p-2 bg-orange-500 text-white rounded text-center">Not present</div>
                            <div className="p-2 bg-pink-400 text-white rounded text-center">Not applicable</div>
                            <div className="p-2 bg-gray-500 text-white rounded text-center">I do not know</div>
                          </div>
                        </div>
                      )}
                      
                      <div className="flex items-center gap-2">
                        <input
                          type="checkbox"
                          checked={question.required}
                          onChange={(e) => updateQuestion(sectionIndex, questionIndex, 'required', e.target.checked)}
                          className="rounded border-gray-500 bg-gray-600"
                        />
                        <span className="text-sm text-gray-300">Required field</span>
                      </div>
                      
                      <div className="flex items-center gap-2">
                        <input
                          type="checkbox"
                          checked={question.notes_enabled || false}
                          onChange={(e) => updateQuestion(sectionIndex, questionIndex, 'notes_enabled', e.target.checked)}
                          className="rounded border-gray-500 bg-gray-600"
                        />
                        <span className="text-sm text-gray-300">Enable notes field</span>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-black text-white p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-400 to-purple-500 bg-clip-text text-transparent">
              Risk Assessment Templates
            </h1>
            <p className="text-gray-400 mt-2">
              Browse and customize compliance risk assessment templates for your company
            </p>
          </div>
          <Button
            variant="outline"
            onClick={() => navigate('/dashboard')}
            className="border-gray-600 text-gray-300 hover:bg-gray-700"
          >
            Back to Dashboard
          </Button>
        </div>

        <Tabs defaultValue="available" className="space-y-6">
          <TabsList className="bg-gray-800 border-gray-700">
            <TabsTrigger value="available" className="data-[state=active]:bg-gray-700">Available Templates</TabsTrigger>
            <TabsTrigger value="customized" className="data-[state=active]:bg-gray-700">My Customized Forms</TabsTrigger>
          </TabsList>

          {/* Available Templates */}
          <TabsContent value="available" className="space-y-6">
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {templates.map((template) => (
                <Card key={template.id} className="bg-gray-900/50 border-gray-700 backdrop-blur-sm hover:border-gray-600 transition-colors">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <Badge className="bg-green-500/20 text-green-300 border-green-500/30">
                        {template.status}
                      </Badge>
                      <span className="text-xs text-gray-500">
                        {new Date(template.created_at).toLocaleDateString()}
                      </span>
                    </div>
                    <CardTitle className="text-white">{template.title}</CardTitle>
                    <CardDescription className="text-gray-400">
                      {template.description}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex items-center gap-4 text-sm text-gray-500">
                        <span>{template.sections.length} sections</span>
                        <span>{template.sections.reduce((total, section) => total + section.questions.length, 0)} questions</span>
                      </div>
                      
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          variant="outline"
                          className="border-gray-600 text-gray-300 hover:bg-gray-700 flex-1"
                        >
                          <Eye className="w-4 h-4 mr-2" />
                          Preview
                        </Button>
                        <Button
                          size="sm"
                          onClick={() => startUsingTemplate(template)}
                          disabled={accessLoading}
                          className="bg-green-600 hover:bg-green-700 flex-1"
                        >
                          <CheckCircle2 className="w-4 h-4 mr-2" />
                          Use Template
                        </Button>
                        <Button
                          size="sm"
                          onClick={() => startCustomization(template)}
                          disabled={accessLoading}
                          className="bg-blue-600 hover:bg-blue-700 flex-1"
                        >
                          <Edit3 className="w-4 h-4 mr-2" />
                          Customize
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* My Customized Forms */}
          <TabsContent value="customized" className="space-y-6">
            {companyForms.length === 0 ? (
              <Card className="bg-gray-900/50 border-gray-700 backdrop-blur-sm">
                <CardContent className="flex flex-col items-center justify-center py-12">
                  <List className="w-12 h-12 text-gray-500 mb-4" />
                  <h3 className="text-lg font-medium text-white mb-2">No Customized Forms Yet</h3>
                  <p className="text-gray-400 text-center mb-4">
                    You haven't customized any templates yet. Browse available templates and create your company-specific forms.
                  </p>
                  <Button
                    onClick={() => {
                      const tabs = document.querySelector('[value="available"]') as HTMLElement;
                      tabs?.click();
                    }}
                    className="bg-blue-600 hover:bg-blue-700"
                  >
                    Browse Templates
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                {companyForms.map((form) => (
                  <Card key={form.id} className="bg-gray-900/50 border-gray-700 backdrop-blur-sm hover:border-gray-600 transition-colors">
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <Badge className="bg-blue-500/20 text-blue-300 border-blue-500/30">
                          Customized
                        </Badge>
                        <span className="text-xs text-gray-500">
                          {new Date(form.created_at).toLocaleDateString()}
                        </span>
                      </div>
                      <CardTitle className="text-white">{form.template_title}</CardTitle>
                      <CardDescription className="text-gray-400">
                        {form.company_name}
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <p className="text-sm text-gray-400">{form.template_description}</p>
                        
                        <div className="flex gap-2">
                          <Button
                            size="sm"
                            variant="outline"
                            className="border-gray-600 text-gray-300 hover:bg-gray-700 flex-1"
                          >
                            <Eye className="w-4 h-4 mr-2" />
                            View Form
                          </Button>
                          <Button
                            size="sm"
                            className="bg-green-600 hover:bg-green-700 flex-1"
                          >
                            <CheckCircle2 className="w-4 h-4 mr-2" />
                            Use Form
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>

        {/* High Value Credit Confirmation Dialog */}
        {showHighValueConfirmation && pendingHighValueAction && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
            <div className="bg-gray-900 border border-gray-700 rounded-lg p-6 max-w-md mx-4">
              <h3 className="text-lg font-semibold text-white mb-3">Confirm High-Value Transaction</h3>
              <p className="text-gray-300 mb-4">
                This action will deduct <span className="font-bold text-yellow-400">{pendingHighValueAction.creditCost.toLocaleString()} credits</span> from your account to access the Risk Assessment template "{pendingHighValueAction.template.title}".
              </p>
              <p className="text-sm text-gray-400 mb-6">
                Are you sure you want to proceed with this transaction?
              </p>
              <div className="flex gap-3">
                <Button
                  variant="outline"
                  onClick={() => {
                    setShowHighValueConfirmation(false);
                    setPendingHighValueAction(null);
                  }}
                  className="flex-1"
                >
                  Cancel
                </Button>
                <Button
                  onClick={async () => {
                    setShowHighValueConfirmation(false);
                    const { template, action } = pendingHighValueAction;
                    setPendingHighValueAction(null);
                    setAccessLoading(true);
                    try {
                      await proceedWithCreditConsumption(template, action);
                    } finally {
                      setAccessLoading(false);
                    }
                  }}
                  className="flex-1 bg-yellow-600 hover:bg-yellow-700"
                >
                  Confirm & Proceed
                </Button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default RiskAssessmentTemplates;
