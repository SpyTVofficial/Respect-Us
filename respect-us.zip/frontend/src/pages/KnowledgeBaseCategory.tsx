import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useUserGuardContext } from 'app/auth';
import brain from 'brain';
import { toast } from 'sonner';
import {
  ArrowLeft,
  Search,
  FileText,
  Calendar,
  Building,
  Download,
  Eye,
  Filter,
  Globe,
  BookOpen,
  Clock,
  CheckCircle2,
  Star,
  TrendingUp,
  Users,
  MessageSquare,
  HelpCircle,
  Scale,
  Briefcase,
  AlertTriangle,
  ExternalLink,
  ChevronRight,
  Shield,
  Zap,
  AlertCircle,
  Target,
  Atom,
  FlaskConical,
  Rocket
} from 'lucide-react';

interface Document {
  id: number;
  title: string;
  description?: string;
  file_name?: string;
  file_size?: number;
  content_type?: string;
  jurisdiction?: string;
  country_jurisdiction?: string;
  regulation_type?: string;
  issuing_authority?: string;
  publication_date?: string;
  effective_date?: string;
  legal_status?: string;
  created_at: string;
  updated_at: string;
  tags?: string[];
}

const CATEGORY_INFO = {
  'dual-use': {
    name: 'Dual-Use Items',
    icon: '⚡',
    description: 'Goods, software, and technology that can be used for both civilian and military purposes',
    color: 'text-purple-400',
    bgColor: 'bg-purple-600/20',
    borderColor: 'border-purple-500',
    keywords: ['dual-use', 'civilian', 'military', 'technology', 'software']
  },
  'military': {
    name: 'Military List',
    icon: '🛡️',
    description: 'Weapons, military equipment, and related technology subject to export controls',
    color: 'text-red-400',
    bgColor: 'bg-red-600/20',
    borderColor: 'border-red-500',
    keywords: ['military', 'weapons', 'defense', 'arms', 'munitions']
  },
  'sanctions': {
    name: 'Sanctions & Embargoes',
    icon: '🚫',
    description: 'Trade restrictions and prohibitions on specific countries, entities, or individuals',
    color: 'text-orange-400',
    bgColor: 'bg-orange-600/20',
    borderColor: 'border-orange-500',
    keywords: ['sanctions', 'embargo', 'restrictions', 'prohibited', 'blocked']
  },
  'encryption': {
    name: 'Encryption & Cryptography',
    icon: '🔐',
    description: 'Cryptographic equipment, software, and related technology',
    color: 'text-blue-400',
    bgColor: 'bg-blue-600/20',
    borderColor: 'border-blue-500',
    keywords: ['encryption', 'cryptography', 'security', 'cipher', 'crypto']
  },
  'nuclear': {
    name: 'Nuclear Technology',
    icon: '⚛️',
    description: 'Nuclear materials, equipment, and related technology',
    color: 'text-yellow-400',
    bgColor: 'bg-yellow-600/20',
    borderColor: 'border-yellow-500',
    keywords: ['nuclear', 'radioactive', 'uranium', 'plutonium', 'reactor']
  },
  'chemical': {
    name: 'Chemical Precursors',
    icon: '🧪',
    description: 'Chemical precursors and equipment for chemical weapons',
    color: 'text-green-400',
    bgColor: 'bg-green-600/20',
    borderColor: 'border-green-500',
    keywords: ['chemical', 'precursor', 'toxic', 'agent', 'synthesis']
  },
  'biological': {
    name: 'Biological Agents',
    icon: '🦠',
    description: 'Biological agents, equipment, and related technology',
    color: 'text-pink-400',
    bgColor: 'bg-pink-600/20',
    borderColor: 'border-pink-500',
    keywords: ['biological', 'pathogen', 'bacteria', 'virus', 'toxin']
  },
  'missile': {
    name: 'Missile Technology',
    icon: '🚀',
    description: 'Missile systems, components, and related technology',
    color: 'text-cyan-400',
    bgColor: 'bg-cyan-600/20',
    borderColor: 'border-cyan-500',
    keywords: ['missile', 'rocket', 'propulsion', 'guidance', 'ballistic']
  }
};

const COUNTRIES = [
  'United States', 'European Union', 'United Kingdom', 'Germany', 'France',
  'Japan', 'Canada', 'Australia', 'South Korea', 'Switzerland'
];

const STATUS_OPTIONS = ['active', 'draft', 'archived', 'superseded'];

const KnowledgeBaseCategory = () => {
  const { categoryId } = useParams<{ categoryId: string }>();
  const navigate = useNavigate();
  const { user } = useUserGuardContext();
  
  const categoryInfo = categoryId ? CATEGORY_INFO[categoryId as keyof typeof CATEGORY_INFO] : null;
  
  const [documents, setDocuments] = useState<Document[]>([]);
  const [featuredDocuments, setFeaturedDocuments] = useState<Document[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCountry, setSelectedCountry] = useState<string>('all');
  const [selectedStatus, setSelectedStatus] = useState<string>('all');
  const [sortBy, setSortBy] = useState<string>('date_desc');
  const [totalCount, setTotalCount] = useState(0);
  const [activeTab, setActiveTab] = useState('overview');

  useEffect(() => {
    if (categoryInfo) {
      loadCategoryDocuments();
    }
  }, [categoryId, selectedCountry, selectedStatus, sortBy]);

  const loadCategoryDocuments = async () => {
    if (!categoryInfo) return;
    
    setLoading(true);
    try {
      // Use list_admin_documents to get all available documents
      const response = await brain.list_admin_documents();
      
      if (response.ok) {
        const data = await response.json();
        let allDocuments = data.documents || [];
        
        // Filter documents by category keywords and criteria
        const categoryDocuments = allDocuments.filter((doc: Document) => {
          // Check if document matches category keywords
          const matchesCategory = categoryInfo.keywords.some(keyword => 
            doc.title?.toLowerCase().includes(keyword.toLowerCase()) ||
            doc.description?.toLowerCase().includes(keyword.toLowerCase()) ||
            doc.regulation_type?.toLowerCase().includes(keyword.toLowerCase()) ||
            (doc.tags && doc.tags.some(tag => tag.toLowerCase().includes(keyword.toLowerCase())))
          );
          
          const matchesCountry = selectedCountry === 'all' || 
            doc.country_jurisdiction?.toLowerCase().includes(selectedCountry.toLowerCase()) ||
            doc.jurisdiction?.toLowerCase().includes(selectedCountry.toLowerCase());
          
          const matchesStatus = selectedStatus === 'all' || 
            doc.legal_status === selectedStatus;
          
          return matchesCategory && matchesCountry && matchesStatus;
        });
        
        setDocuments(categoryDocuments);
        setTotalCount(categoryDocuments.length);
        
        // Set featured documents (top 3 most recent)
        setFeaturedDocuments(categoryDocuments.slice(0, 3));
      }
    } catch (error) {
      console.error('Error loading category documents:', error);
      toast.error('Failed to load documents');
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = () => {
    loadCategoryDocuments();
  };

  const handleViewDocument = async (doc: Document) => {
    try {
      const response = await brain.get_document({ documentId: doc.id });
      if (response.ok) {
        toast.success(`Viewing: ${doc.title}`);
        // TODO: Open document in modal or new tab
      }
    } catch (error) {
      console.error('Error viewing document:', error);
      toast.error('Failed to view document');
    }
  };

  const formatDate = (dateString?: string) => {
    if (!dateString) return 'N/A';
    return new Date(dateString).toLocaleDateString();
  };

  const formatFileSize = (bytes?: number) => {
    if (!bytes) return 'N/A';
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(1024));
    return Math.round(bytes / Math.pow(1024, i) * 100) / 100 + ' ' + sizes[i];
  };

  const getStatusBadge = (status?: string) => {
    const statusColors = {
      'active': 'bg-green-600',
      'draft': 'bg-yellow-600',
      'archived': 'bg-gray-600',
      'superseded': 'bg-red-600'
    };
    
    return (
      <Badge className={statusColors[status as keyof typeof statusColors] || 'bg-gray-600'}>
        {status || 'Unknown'}
      </Badge>
    );
  };

  // Mock data for rich content specific to category (would be managed through Admin Dashboard)
  const getCategoryContent = () => {
    if (!categoryInfo) return null;
    
    const categorySpecificContent = {
      'dual-use': {
        summary: 'Dual-use items represent one of the most complex areas of export control, requiring careful assessment of end-use and end-user to prevent diversion to weapons programs.',
        guidelines: [
          {
            title: 'Technical Assessment Guidelines',
            date: '2025-02-15',
            authority: 'Export Control Office',
            type: 'Best Practices'
          },
          {
            title: 'End-Use Monitoring Procedures',
            date: '2025-01-10',
            authority: 'Compliance Division',
            type: 'Operational Guide'
          }
        ],
        keyRegulations: [
          {
            title: 'Wassenaar Arrangement Dual-Use List',
            scope: 'International',
            lastUpdate: '2024-12-01',
            status: 'Active'
          },
          {
            title: 'EAR Category 5 - Telecommunications',
            scope: 'US',
            lastUpdate: '2024-11-15',
            status: 'Active'
          }
        ]
      },
      'sanctions': {
        summary: 'Sanctions and embargoes are legal restrictions imposed to achieve foreign policy and national security objectives through economic pressure.',
        guidelines: [
          {
            title: 'Sanctions Screening Procedures',
            date: '2025-01-20',
            authority: 'OFAC',
            type: 'Compliance Manual'
          },
          {
            title: 'Country-Specific Embargo Guidelines',
            date: '2024-12-30',
            authority: 'Treasury Department',
            type: 'Reference Guide'
          }
        ],
        keyRegulations: [
          {
            title: 'OFAC Specially Designated Nationals List',
            scope: 'US',
            lastUpdate: '2025-01-07',
            status: 'Active'
          },
          {
            title: 'EU Consolidated Sanctions List',
            scope: 'EU',
            lastUpdate: '2025-01-05',
            status: 'Active'
          }
        ]
      }
    };
    
    return categorySpecificContent[categoryId as keyof typeof categorySpecificContent] || {
      summary: `${categoryInfo.description} This category requires specialized knowledge and careful compliance with international export control regimes.`,
      guidelines: [
        {
          title: `${categoryInfo.name} Assessment Framework`,
          date: '2025-01-15',
          authority: 'Regulatory Authority',
          type: 'Technical Guide'
        }
      ],
      keyRegulations: [
        {
          title: `International ${categoryInfo.name} Controls`,
          scope: 'Global',
          lastUpdate: '2024-12-01',
          status: 'Active'
        }
      ]
    };
  };

  const categoryContent = getCategoryContent();

  const commonFAQs = [
    {
      question: 'What documentation is required for exports?',
      answer: 'Export documentation typically includes export licenses, end-user certificates, and technical specifications depending on the controlled item.'
    },
    {
      question: 'How do I determine if my product is controlled?',
      answer: 'Classification involves checking the item against control lists, consulting technical parameters, and potentially seeking official classification from authorities.'
    },
    {
      question: 'What are the penalties for violations?',
      answer: 'Penalties can include significant fines, imprisonment, denial of export privileges, and reputational damage to your organization.'
    },
    {
      question: 'How often are control lists updated?',
      answer: 'Control lists are typically updated annually, but emergency changes can occur at any time based on security developments.'
    }
  ];

  if (!categoryInfo) {
    return (
      <div className="min-h-screen bg-gray-900 text-slate-100 flex items-center justify-center">
        <Card className="bg-gray-800 border-gray-700 p-8">
          <CardContent className="text-center">
            <AlertTriangle className="h-16 w-16 mx-auto mb-4 text-red-400" />
            <h2 className="text-xl font-semibold text-slate-100 mb-2">Category Not Found</h2>
            <p className="text-slate-400 mb-4">The requested category could not be found.</p>
            <Button onClick={() => navigate('/knowledge-base')} className="bg-blue-600 hover:bg-blue-700">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Knowledge Base
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-900 text-slate-100">
      {/* Hero Header */}
      <div className="bg-gradient-to-br from-gray-800 via-gray-900 to-black border-b border-gray-700">
        <div className="max-w-7xl mx-auto px-6 py-8">
          <div className="flex items-center justify-between mb-6">
            <Button
              variant="ghost"
              onClick={() => navigate('/knowledge-base')}
              className="text-gray-400 hover:text-white hover:bg-gray-700/50"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Knowledge Base
            </Button>
          </div>
          
          <div className="flex items-center gap-6 mb-8">
            <div className={`text-7xl drop-shadow-lg p-4 rounded-2xl ${categoryInfo.bgColor} ${categoryInfo.borderColor} border-2`}>
              {categoryInfo.icon}
            </div>
            <div className="flex-1">
              <h1 className="text-4xl font-bold text-slate-100 mb-3">
                {categoryInfo.name}
              </h1>
              <p className="text-xl text-slate-300 mb-4">
                {categoryContent?.summary || categoryInfo.description}
              </p>
              <div className="flex items-center gap-4">
                <Badge className={`${categoryInfo.bgColor} ${categoryInfo.borderColor} border text-white px-3 py-1`}>
                  <CheckCircle2 className="w-4 h-4 mr-2" />
                  Active Category
                </Badge>
                <Badge variant="outline" className="border-blue-500 text-blue-400 px-3 py-1">
                  <Globe className="w-4 h-4 mr-2" />
                  {totalCount} Documents
                </Badge>
                <Badge variant="outline" className="border-purple-500 text-purple-400 px-3 py-1">
                  <TrendingUp className="w-4 h-4 mr-2" />
                  Multi-Jurisdictional
                </Badge>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Featured Documents Section */}
        <div className="mb-12">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold text-slate-100 flex items-center">
              <Star className="w-6 h-6 mr-2 text-yellow-400" />
              Featured {categoryInfo.name} Documents
            </h2>
            <Button 
              variant="outline" 
              onClick={() => setActiveTab('documents')}
              className="border-gray-600 text-gray-300 hover:bg-gray-700"
            >
              View All Documents
              <ChevronRight className="w-4 h-4 ml-1" />
            </Button>
          </div>
          
          {loading ? (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {[1, 2, 3].map(i => (
                <Card key={i} className="bg-gray-800 border-gray-700 animate-pulse">
                  <CardContent className="p-6">
                    <div className="h-4 bg-gray-700 rounded mb-3"></div>
                    <div className="h-3 bg-gray-700 rounded mb-2 w-3/4"></div>
                    <div className="h-3 bg-gray-700 rounded w-1/2"></div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : featuredDocuments.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {featuredDocuments.map((doc) => (
                <Card key={doc.id} className={`bg-gradient-to-br from-gray-800 to-gray-900 ${categoryInfo.borderColor} border hover:border-opacity-70 transition-all duration-300 group cursor-pointer`} onClick={() => handleViewDocument(doc)}>
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div className={`text-3xl mb-2 p-2 rounded-lg ${categoryInfo.bgColor}`}>
                        {categoryInfo.icon}
                      </div>
                      {getStatusBadge(doc.legal_status)}
                    </div>
                    
                    <h3 className={`text-lg font-semibold text-slate-100 mb-2 group-hover:${categoryInfo.color} transition-colors`}>
                      {doc.title}
                    </h3>
                    
                    <p className="text-slate-400 text-sm mb-4 line-clamp-2">
                      {doc.description || `${categoryInfo.name} regulation document`}
                    </p>
                    
                    <div className="flex items-center justify-between text-xs text-slate-500">
                      <div className="flex items-center">
                        <Calendar className="w-3 h-3 mr-1" />
                        {formatDate(doc.updated_at)}
                      </div>
                      <div className="flex items-center">
                        <FileText className="w-3 h-3 mr-1" />
                        {formatFileSize(doc.file_size)}
                      </div>
                    </div>
                    
                    {doc.regulation_type && (
                      <Badge 
                        variant="outline" 
                        className={`mt-3 text-xs ${categoryInfo.color} border-current`}
                      >
                        {doc.regulation_type}
                      </Badge>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <Card className="bg-gray-800 border-gray-700">
              <CardContent className="p-12 text-center">
                <div className={`text-6xl mx-auto mb-4 opacity-50 p-4 rounded-xl ${categoryInfo.bgColor}`}>
                  {categoryInfo.icon}
                </div>
                <h3 className="text-xl font-semibold text-slate-300 mb-2">
                  No {categoryInfo.name} Documents Available
                </h3>
                <p className="text-slate-400">
                  No regulatory documents are currently available for this category.
                </p>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Tabs for different content sections */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="bg-gray-800 border border-gray-700">
            <TabsTrigger value="overview" className="data-[state=active]:bg-blue-600">Overview</TabsTrigger>
            <TabsTrigger value="documents" className="data-[state=active]:bg-blue-600">All Documents</TabsTrigger>
            <TabsTrigger value="guidelines" className="data-[state=active]:bg-blue-600">Guidelines</TabsTrigger>
            <TabsTrigger value="regulations" className="data-[state=active]:bg-blue-600">Key Regulations</TabsTrigger>
            <TabsTrigger value="faq" className="data-[state=active]:bg-blue-600">FAQ</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card className="bg-gray-800 border-gray-700">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-slate-400">Total Documents</p>
                      <p className="text-3xl font-bold text-slate-100">{totalCount}</p>
                    </div>
                    <FileText className="h-10 w-10 text-blue-400" />
                  </div>
                </CardContent>
              </Card>
              
              <Card className="bg-gray-800 border-gray-700">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-slate-400">Jurisdictions</p>
                      <p className="text-3xl font-bold text-slate-100">
                        {new Set(documents.map(d => d.country_jurisdiction).filter(Boolean)).size}
                      </p>
                    </div>
                    <Globe className="h-10 w-10 text-green-400" />
                  </div>
                </CardContent>
              </Card>
              
              <Card className="bg-gray-800 border-gray-700">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-slate-400">Last Updated</p>
                      <p className="text-lg font-semibold text-slate-100">
                        {documents.length > 0 ? formatDate(documents[0]?.updated_at) : 'N/A'}
                      </p>
                    </div>
                    <Clock className="h-10 w-10 text-amber-400" />
                  </div>
                </CardContent>
              </Card>
              
              <Card className="bg-gray-800 border-gray-700">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-slate-400">Category Status</p>
                      <div className="flex items-center gap-1">
                        <CheckCircle2 className={`w-5 h-5 ${categoryInfo.color}`} />
                        <span className={`text-lg font-semibold ${categoryInfo.color}`}>Active</span>
                      </div>
                    </div>
                    <div className={`text-3xl ${categoryInfo.color}`}>{categoryInfo.icon}</div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card className="bg-gray-800 border-gray-700">
              <CardHeader>
                <CardTitle className="text-slate-100 flex items-center">
                  <div className={`text-2xl mr-3 ${categoryInfo.color}`}>{categoryInfo.icon}</div>
                  {categoryInfo.name} Overview
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-slate-300 leading-relaxed mb-4">
                  {categoryContent?.summary || categoryInfo.description}
                </p>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6">
                  <div className={`p-4 rounded-lg ${categoryInfo.bgColor} border ${categoryInfo.borderColor}`}>
                    <Target className="w-6 h-6 mb-2 text-white" />
                    <h4 className="font-semibold text-white mb-1">Control Scope</h4>
                    <p className="text-sm text-gray-200">International export control regimes</p>
                  </div>
                  <div className={`p-4 rounded-lg ${categoryInfo.bgColor} border ${categoryInfo.borderColor}`}>
                    <Scale className="w-6 h-6 mb-2 text-white" />
                    <h4 className="font-semibold text-white mb-1">Legal Framework</h4>
                    <p className="text-sm text-gray-200">Multi-jurisdictional compliance</p>
                  </div>
                  <div className={`p-4 rounded-lg ${categoryInfo.bgColor} border ${categoryInfo.borderColor}`}>
                    <AlertCircle className="w-6 h-6 mb-2 text-white" />
                    <h4 className="font-semibold text-white mb-1">Risk Level</h4>
                    <p className="text-sm text-gray-200">High compliance requirements</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="documents" className="space-y-6">
            {/* Search and Filters */}
            <Card className="bg-gray-800 border-gray-700">
              <CardContent className="p-6">
                <div className="flex flex-col lg:flex-row gap-4">
                  <div className="flex-1">
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                      <Input
                        placeholder={`Search ${categoryInfo.name.toLowerCase()} documents...`}
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
                        className="pl-10 bg-gray-700 border-gray-600 focus:border-blue-500"
                      />
                    </div>
                  </div>
                  
                  <div className="flex gap-3">
                    <Select value={selectedCountry} onValueChange={setSelectedCountry}>
                      <SelectTrigger className="w-48 bg-gray-700 border-gray-600">
                        <Globe className="w-4 h-4 mr-2" />
                        <SelectValue placeholder="Jurisdiction" />
                      </SelectTrigger>
                      <SelectContent className="bg-gray-800 border-gray-600">
                        <SelectItem value="all">All Jurisdictions</SelectItem>
                        {COUNTRIES.map(country => (
                          <SelectItem key={country} value={country}>{country}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    
                    <Select value={selectedStatus} onValueChange={setSelectedStatus}>
                      <SelectTrigger className="w-32 bg-gray-700 border-gray-600">
                        <SelectValue placeholder="Status" />
                      </SelectTrigger>
                      <SelectContent className="bg-gray-800 border-gray-600">
                        <SelectItem value="all">All Status</SelectItem>
                        {STATUS_OPTIONS.map(status => (
                          <SelectItem key={status} value={status}>{status}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    
                    <Select value={sortBy} onValueChange={setSortBy}>
                      <SelectTrigger className="w-40 bg-gray-700 border-gray-600">
                        <SelectValue placeholder="Sort by" />
                      </SelectTrigger>
                      <SelectContent className="bg-gray-800 border-gray-600">
                        <SelectItem value="date_desc">Newest First</SelectItem>
                        <SelectItem value="date_asc">Oldest First</SelectItem>
                        <SelectItem value="title_asc">Title A-Z</SelectItem>
                        <SelectItem value="title_desc">Title Z-A</SelectItem>
                      </SelectContent>
                    </Select>
                    
                    <Button onClick={handleSearch} className="bg-blue-600 hover:bg-blue-700">
                      Search
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* All Documents List */}
            {documents.length > 0 ? (
              <div className="space-y-4">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-xl font-semibold text-slate-100">
                    {categoryInfo.name} Documents ({totalCount})
                  </h3>
                </div>
                
                {documents.map((doc) => (
                  <Card key={doc.id} className="bg-gray-800 border-gray-700 hover:bg-gray-750 transition-colors">
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-2">
                            <div className={`text-lg ${categoryInfo.color}`}>{categoryInfo.icon}</div>
                            <h4 className={`text-lg font-semibold text-slate-100 hover:${categoryInfo.color} cursor-pointer transition-colors`}
                                onClick={() => handleViewDocument(doc)}>
                              {doc.title}
                            </h4>
                            {getStatusBadge(doc.legal_status)}
                            {doc.regulation_type && (
                              <Badge 
                                variant="outline" 
                                className={`border-gray-600 ${categoryInfo.color}`}
                              >
                                {doc.regulation_type}
                              </Badge>
                            )}
                          </div>
                          
                          {doc.description && (
                            <p className="text-slate-400 mb-3 line-clamp-2">
                              {doc.description}
                            </p>
                          )}
                          
                          <div className="flex items-center gap-6 text-sm text-slate-500">
                            {doc.country_jurisdiction && (
                              <div className="flex items-center gap-1">
                                <Globe className="w-4 h-4" />
                                <span>{doc.country_jurisdiction}</span>
                              </div>
                            )}
                            {doc.issuing_authority && (
                              <div className="flex items-center gap-1">
                                <Building className="w-4 h-4" />
                                <span>{doc.issuing_authority}</span>
                              </div>
                            )}
                            {doc.publication_date && (
                              <div className="flex items-center gap-1">
                                <Calendar className="w-4 h-4" />
                                <span>Published: {formatDate(doc.publication_date)}</span>
                              </div>
                            )}
                            {doc.file_size && (
                              <div className="flex items-center gap-1">
                                <FileText className="w-4 h-4" />
                                <span>{formatFileSize(doc.file_size)}</span>
                              </div>
                            )}
                          </div>
                          
                          {doc.tags && doc.tags.length > 0 && (
                            <div className="flex flex-wrap gap-1 mt-3">
                              {doc.tags.slice(0, 5).map((tag, index) => (
                                <Badge key={index} variant="secondary" className="text-xs bg-gray-700 text-gray-300">
                                  {tag}
                                </Badge>
                              ))}
                              {doc.tags.length > 5 && (
                                <Badge variant="secondary" className="text-xs bg-gray-700 text-gray-300">
                                  +{doc.tags.length - 5} more
                                </Badge>
                              )}
                            </div>
                          )}
                        </div>
                        
                        <div className="flex items-center gap-2 ml-4">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleViewDocument(doc)}
                            className="border-gray-600 text-gray-300 hover:bg-gray-700"
                          >
                            <Eye className="w-4 h-4 mr-1" />
                            View
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            className="border-gray-600 text-gray-300 hover:bg-gray-700"
                          >
                            <Download className="w-4 h-4 mr-1" />
                            Download
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <Card className="bg-gray-800 border-gray-700">
                <CardContent className="p-12 text-center">
                  <div className={`text-6xl mx-auto mb-4 opacity-50 p-4 rounded-xl ${categoryInfo.bgColor}`}>
                    {categoryInfo.icon}
                  </div>
                  <h3 className="text-xl font-semibold text-slate-300 mb-2">
                    No {categoryInfo.name} Documents Found
                  </h3>
                  <p className="text-slate-400">
                    No regulatory documents are currently available for this category.
                  </p>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="guidelines" className="space-y-6">
            <Card className="bg-gray-800 border-gray-700">
              <CardHeader>
                <CardTitle className="text-slate-100 flex items-center">
                  <Briefcase className="w-5 h-5 mr-2" />
                  {categoryInfo.name} Guidelines & Best Practices
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {categoryContent?.guidelines?.map((guide, index) => (
                    <div key={index} className="p-4 bg-gray-700/50 rounded-lg hover:bg-gray-700 transition-colors cursor-pointer">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <h4 className="font-semibold text-slate-100 mb-1">{guide.title}</h4>
                          <p className="text-sm text-slate-400 mb-2">{guide.type}</p>
                          <div className="flex items-center gap-4 text-xs text-slate-500">
                            <span className="flex items-center gap-1">
                              <Calendar className="w-3 h-3" />
                              {guide.date}
                            </span>
                            <span className="flex items-center gap-1">
                              <Building className="w-3 h-3" />
                              {guide.authority}
                            </span>
                          </div>
                        </div>
                        <Button variant="outline" size="sm" className="border-gray-600 text-gray-300">
                          <ExternalLink className="w-3 h-3 mr-1" />
                          View
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="regulations" className="space-y-6">
            <Card className="bg-gray-800 border-gray-700">
              <CardHeader>
                <CardTitle className="text-slate-100 flex items-center">
                  <Scale className="w-5 h-5 mr-2" />
                  Key {categoryInfo.name} Regulations
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {categoryContent?.keyRegulations?.map((regulation, index) => (
                    <div key={index} className="p-4 bg-gray-700/50 rounded-lg">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <h4 className="font-semibold text-slate-100 mb-1">{regulation.title}</h4>
                          <p className="text-sm text-slate-400 mb-2">{regulation.scope} Jurisdiction</p>
                          <div className="flex items-center gap-4 text-xs text-slate-500">
                            <span className="flex items-center gap-1">
                              <Calendar className="w-3 h-3" />
                              Last Updated: {regulation.lastUpdate}
                            </span>
                          </div>
                        </div>
                        <Badge className={regulation.status === 'Active' ? 'bg-green-600' : 'bg-gray-600'}>
                          {regulation.status}
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="faq" className="space-y-6">
            <Card className="bg-gray-800 border-gray-700">
              <CardHeader>
                <CardTitle className="text-slate-100 flex items-center">
                  <HelpCircle className="w-5 h-5 mr-2" />
                  {categoryInfo.name} Frequently Asked Questions
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {commonFAQs.map((faq, index) => (
                    <div key={index} className="border-b border-gray-700 pb-4 last:border-b-0">
                      <h4 className="font-semibold text-slate-100 mb-2 flex items-start">
                        <MessageSquare className={`w-4 h-4 mr-2 mt-0.5 ${categoryInfo.color}`} />
                        {faq.question}
                      </h4>
                      <p className="text-slate-300 leading-relaxed pl-6">
                        {faq.answer}
                      </p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default KnowledgeBaseCategory;
