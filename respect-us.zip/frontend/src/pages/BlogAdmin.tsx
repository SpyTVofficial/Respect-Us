import React, { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Separator } from '@/components/ui/separator';
import { Switch } from '@/components/ui/switch';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Skeleton } from '@/components/ui/skeleton';
import { toast } from 'sonner';
import brain from 'brain';
import {
  CreateContentRequest,
  AppApisAdminDashboardCategoryRequest
} from 'types';
import RichTextEditor from 'components/RichTextEditor';
import Navigation from 'components/Navigation';
import Footer from 'components/Footer';
import { API_URL } from 'app';
import { Upload, FileText, ImageIcon, LinkIcon, Tag, Plus, X, Calendar, Clock, User, Eye, Save, Shield, Trash2, ExternalLink, ArrowLeft, BookOpen, UserCheck, Settings, Image, Search, Filter, Edit, MoreHorizontal, Loader2 } from 'lucide-react';
import { convertToAppStaticUrl } from "utils/imageUtils";
import { ContentResponse, CategoryResponse, ContentType, ContentStatus } from 'types';

// Define types locally since they're not properly exported
type BlogContentType = 'ARTICLE' | 'GUIDE' | 'NEWS' | 'CASE_STUDY' | 'REGULATION';
type BlogContentStatus = 'DRAFT' | 'PUBLISHED' | 'ARCHIVED';

interface CategoryResponse {
  category_id: string;
  name: string;
  description?: string;
}

// Simplified - remove complex author management, use admin-only
interface BlogPostForm {
  title: string;
  content: string;
  excerpt: string;
  contentType: BlogContentType;
  status: BlogContentStatus;
  categories: string[];
  tags: string[];
  featuredImage: string;
  videoUrl: string;
  scheduledPublishDate: string;
  seoKeywords: string[];
  externalLinks: string[];
}

export default function BlogAdmin() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const contentId = searchParams.get('id') || searchParams.get('edit');
  const isEditMode = searchParams.has('edit');
  
  // Add new state for managing posts
  const [allPosts, setAllPosts] = useState([]);
  const [filteredPosts, setFilteredPosts] = useState([]);
  const [postsLoading, setPostsLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [activeTab, setActiveTab] = useState('create');
  
  // Form State - simplified to admin-only
  const [formData, setFormData] = useState({
    title: '',
    content: '',
    excerpt: '',
    contentType: 'ARTICLE' as BlogContentType,
    status: 'DRAFT' as BlogContentStatus,
    categories: [] as string[],
    tags: [] as string[],
    scheduledPublishDate: '',
    featuredImage: '',
    videoUrl: '',
    seoKeywords: [] as string[],
    externalLinks: [] as string[]
  });

  // Data State - simplified
  const [categories, setCategories] = useState<CategoryResponse[]>([]);
  
  // UI State
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [previewMode, setPreviewMode] = useState(false);
  const [showImageDialog, setShowImageDialog] = useState(false);
  const [showLinkDialog, setShowLinkDialog] = useState(false);
  const [showSubmitDialog, setShowSubmitDialog] = useState(false);
  const [showCategoryDialog, setShowCategoryDialog] = useState(false);
  const [editingContentId, setEditingContentId] = useState<string | null>(null);

  // File upload state
  const [activeImageTab, setActiveImageTab] = useState('url');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [filePreview, setFilePreview] = useState('');
  const [uploadLoading, setUploadLoading] = useState(false);

  const [content, setContent] = useState<any>(null);
  const [contentLoading, setContentLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [featuredImageUrl, setFeaturedImageUrl] = useState<string>('');
  const [imageUrl, setImageUrl] = useState<string>('');

  // Helper function to get image URL using brain client for proper project path handling
  const getImageUrl = async (filename: string): Promise<string> => {
    try {
      const imageResponse = await brain.serve_static_image({ imageFilename: filename });
      
      if (imageResponse.ok) {
        const imageBlob = await imageResponse.blob();
        return URL.createObjectURL(imageBlob);
      } else {
        console.error('Failed to serve image via brain client:', filename);
        return '';
      }
    } catch (error) {
      console.error('Error serving image via brain client:', error);
      return '';
    }
  };

  // Load the featured image URL when formData.featuredImage changes
  useEffect(() => {
    const loadFeaturedImage = async () => {
      if (formData.featuredImage) {
        console.log('🖼️ Loading featured image:', formData.featuredImage);
        
        // Check if it's already a blob URL (from recent upload)
        if (formData.featuredImage.startsWith('blob:')) {
          setFeaturedImageUrl(formData.featuredImage);
          return;
        }
        
        // Check if it's an external URL that needs conversion
        if (formData.featuredImage.startsWith('https://static.databutton.com/')) {
          const filename = formData.featuredImage.split('/').pop();
          if (filename) {
            const blobUrl = await getImageUrl(filename);
            if (blobUrl) {
              setFeaturedImageUrl(blobUrl);
            }
          }
        }
        // Check if it's a converted internal URL that needs brain client serving
        else if (formData.featuredImage.includes('/static/')) {
          // Extract filename from internal URL: .../static/filename.ext
          const urlParts = formData.featuredImage.split('/static/');
          if (urlParts.length === 2) {
            const filename = urlParts[1];
            const blobUrl = await getImageUrl(filename);
            if (blobUrl) {
              setFeaturedImageUrl(blobUrl);
            }
          }
        }
        // Check if it's just a filename
        else if (!formData.featuredImage.startsWith('http')) {
          const blobUrl = await getImageUrl(formData.featuredImage);
          if (blobUrl) {
            setFeaturedImageUrl(blobUrl);
          }
        }
        // Otherwise use as-is (fallback)
        else {
          setFeaturedImageUrl(formData.featuredImage);
        }
      }
    };
    
    loadFeaturedImage();
  }, [formData.featuredImage]);

  // Helper function to convert media URLs to blob URLs for proper authentication
  const getMediaBlobUrl = async (mediaPath: string): Promise<string> => {
    if (!mediaPath || !mediaPath.startsWith('/api/media/file/')) {
      return '';
    }
    
    try {
      const mediaId = mediaPath.replace('/api/media/file/', '');
      const response = await brain.download_media_file({ mediaId });
      
      if (!response.ok) {
        return '';
      }
      
      const blob = await response.blob();
      const blobUrl = URL.createObjectURL(blob);
      
      return blobUrl;
    } catch (error) {
      return '';
    }
  };

  // Load content when component mounts or contentId changes
  useEffect(() => {
    const loadContent = async (contentId: number) => {
      if (!contentId) {
        toast.error('No content ID provided');
        return;
      }

      try {
        setContentLoading(true);
        const response = await brain.get_content_item({ contentId });
        const rawData = await response.json();
        setContent(rawData);
        
        // Parse the content structure - content is stored as nested JSON in content.text
        let parsedContent = {};
        try {
          console.log('Raw data structure:', rawData);
          console.log('Raw content:', rawData.content);
          
          if (rawData.content && rawData.content.text && typeof rawData.content.text === 'string') {
            console.log('Parsing content.text as JSON:', rawData.content.text);
            parsedContent = JSON.parse(rawData.content.text);
          } else if (rawData.content && typeof rawData.content === 'object') {
            console.log('Using content as object:', rawData.content);
            parsedContent = rawData.content;
          } else if (typeof rawData.content === 'string') {
            console.log('Parsing content as JSON string:', rawData.content);
            parsedContent = JSON.parse(rawData.content);
          }
          
          console.log('Parsed content:', parsedContent);
          console.log('Extracted content text:', (parsedContent as any).content);
        } catch (parseError) {
          console.error('Error parsing content JSON:', parseError);
          parsedContent = {};
        }
        
        // Update form with loaded content
        const featuredImageUrl = (parsedContent as any).featured_image_url || '';
        setFormData({
          title: rawData.title || '',
          excerpt: (parsedContent as any).excerpt || '',
          content: (parsedContent as any).content || '',
          featuredImage: convertToAppStaticUrl(featuredImageUrl),
          categories: (parsedContent as any).categories || [],
          tags: (parsedContent as any).tags || [],
          author: (parsedContent as any).author_email || 'admin@respectus.com',
          status: (parsedContent as any).status || 'DRAFT',
          seoKeywords: ((parsedContent as any).seo_keywords || []).join(', ')
        });
        
        setEditingContentId(contentId);
        setActiveTab('create');
        
      } catch (error) {
        console.error('Error loading content:', error);
        toast.error('Failed to load content');
      } finally {
        setContentLoading(false);
      }
    };

    if (contentId) {
      loadContent(parseInt(contentId));
    } else {
      setContentLoading(false);
    }
  }, [contentId]);

  // Load all posts when on manage tab
  useEffect(() => {
    if (activeTab === 'manage') {
      loadAllPosts();
    }
  }, [activeTab]);

  // Filter posts when search term or status filter changes
  useEffect(() => {
    filterPosts();
  }, [searchTerm, statusFilter, allPosts]);

  // Set active tab based on URL params
  useEffect(() => {
    if (contentId) {
      setActiveTab('create'); // Switch to create tab when editing
    }
  }, [contentId]);

  // Load initial data
  const loadData = async () => {
    try {
      setLoading(true);
      
      // Mock categories for now - these would come from the categories API in production
      const mockCategories = [
        { category_id: 'compliance', name: 'Compliance', description: 'Export control compliance articles', color: '#3B82F6' },
        { category_id: 'regulations', name: 'Regulations', description: 'Regulatory updates and changes', color: '#10B981' },
        { category_id: 'best-practices', name: 'Best Practices', description: 'Industry best practices', color: '#F59E0B' },
        { category_id: 'case-studies', name: 'Case Studies', description: 'Real-world examples', color: '#EF4444' },
        { category_id: 'technology', name: 'Technology', description: 'Technology and tools', color: '#8B5CF6' }
      ];
      
      setCategories(mockCategories);
      
    } catch (error) {
      console.error('Error loading data:', error);
      toast.error('Failed to load categories');
    } finally {
      setLoading(false);
    }
  };

  // Add function to load all blog posts
  const loadAllPosts = async () => {
    try {
      setPostsLoading(true);
      // Use the correct API method that exists in brain
      const response = await brain.get_content_by_module({ moduleName: 'blog' });
      const data = await response.json();
      
      if (response.ok && data.items) {
        setAllPosts(data.items);
        setFilteredPosts(data.items);
      } else {
        console.warn('No blog posts found or API error');
        setAllPosts([]);
        setFilteredPosts([]);
      }
    } catch (error) {
      console.error('Error loading blog posts:', error);
      toast.error('Failed to load blog posts');
      setAllPosts([]);
      setFilteredPosts([]);
    } finally {
      setPostsLoading(false);
    }
  };

  // Filter posts based on search and status
  const filterPosts = () => {
    let filtered = allPosts;
    
    // Filter by status
    if (statusFilter !== 'ALL') {
      filtered = filtered.filter(post => {
        const status = post.content?.status || post.metadata?.status || 'DRAFT';
        return status === statusFilter;
      });
    }
    
    // Filter by search term
    if (searchTerm.trim()) {
      const search = searchTerm.toLowerCase();
      filtered = filtered.filter(post => 
        post.title?.toLowerCase().includes(search) ||
        post.content?.content?.toLowerCase().includes(search) ||
        post.metadata?.excerpt?.toLowerCase().includes(search)
      );
    }
    
    setFilteredPosts(filtered);
  };

  // Handle post actions
  const handleEditPost = (post) => {
    navigate(`/blog-admin?edit=${post.id}`);
  };

  const handlePublishPost = async (post) => {
    try {
      const response = await brain.update_content(
        { contentId: post.id }, 
        {
          ...post,
          content: {
            ...post.content,
            status: 'PUBLISHED'
          }
        }
      );
      
      if (response.ok) {
        toast.success('Post published successfully!');
        loadAllPosts(); // Refresh the list
      } else {
        toast.error('Failed to publish post');
      }
    } catch (error) {
      console.error('Error publishing post:', error);
      toast.error('Failed to publish post');
    }
  };

  const handleDeletePost = async (post) => {
    if (confirm('Are you sure you want to delete this post? This action cannot be undone.')) {
      try {
        const response = await brain.delete_content_item({ contentId: post.id });
        
        if (response.ok) {
          toast.success('Post deleted successfully!');
          loadAllPosts(); // Refresh the list
        } else {
          toast.error('Failed to delete post');
        }
      } catch (error) {
        console.error('Error deleting post:', error);
        toast.error('Failed to delete post');
      }
    }
  };

  // Handle form changes
  const handleInputChange = (field: keyof BlogPostForm, value: any) => {
    console.log(`📝 Blog field changed: ${field} =`, value);
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  // Handle category toggle
  const toggleCategory = (categoryId: string) => {
    setFormData(prev => ({
      ...prev,
      categories: prev.categories.includes(categoryId)
        ? prev.categories.filter(id => id !== categoryId)
        : [...prev.categories, categoryId]
    }));
  };

  // Handle tag management
  const addTag = () => {
    if (newTag.trim() && !formData.tags.includes(newTag.trim())) {
      setFormData(prev => ({ ...prev, tags: [...prev.tags, newTag.trim()] }));
      setNewTag('');
    }
  };

  const removeTag = (tag: string) => {
    setFormData(prev => ({ ...prev, tags: prev.tags.filter(t => t !== tag) }));
  };

  // Handle keyword management
  const addKeyword = () => {
    if (newKeyword.trim() && !formData.seoKeywords.includes(newKeyword.trim())) {
      setFormData(prev => ({ ...prev, seoKeywords: [...prev.seoKeywords, newKeyword.trim()] }));
      setNewKeyword('');
    }
  };

  const removeKeyword = (keyword: string) => {
    setFormData(prev => ({ ...prev, seoKeywords: prev.seoKeywords.filter(k => k !== keyword) }));
  };

  // File upload functionality - implement using brain.upload_image
  const handleFileUpload = async (file: File) => {
    try {
      setUploadLoading(true);
      
      console.log('🔧 DEBUG: Current API_URL value:', API_URL);
      
      // Use the file directly as brain.upload_image expects { file: File }
      const uploadData = { file };
      
      // Upload using brain.upload_image
      const response = await brain.upload_image(uploadData);
      
      if (response.ok) {
        const data = await response.json();
        console.log('🔧 DEBUG: Upload API response:', data);
        
        if (data.image_url) {
          // API returns: "static/e04acffbb19c409c82498825766cbf26_filename.ext"
          // Extract just the filename from the response
          const filename = data.image_url.replace('static/', '');
          console.log('🔧 DEBUG: Extracted filename:', filename);
          
          // Instead of manually constructing URLs, use the brain client to serve the image
          // The brain client will handle the correct project path automatically
          try {
            const imageResponse = await brain.serve_static_image({ imageFilename: filename });
            if (imageResponse.ok) {
              // Use the brain client's URL which includes proper project path
              const imageBlob = await imageResponse.blob();
              const imageUrl = URL.createObjectURL(imageBlob);
              
              console.log('🔧 DEBUG: Created blob URL:', imageUrl);
              
              setFormData(prev => ({ ...prev, featuredImage: imageUrl }));
              setFeaturedImageUrl(imageUrl);
              setSelectedFile(null);
              setFilePreview('');
              setShowImageDialog(false);
              toast.success('Image uploaded successfully!');
            } else {
              throw new Error('Failed to serve uploaded image');
            }
          } catch (serveError) {
            console.error('🔧 DEBUG: Error serving image:', serveError);
            // Fallback: store just the filename and handle serving in the display component
            setFormData(prev => ({ ...prev, featuredImage: filename }));
            setFeaturedImageUrl(filename);
            setSelectedFile(null);
            setFilePreview('');
            setShowImageDialog(false);
            toast.success('Image uploaded successfully!');
          }
        } else {
          throw new Error('No image URL in response');
        }
      } else {
        const errorData = await response.json();
        throw new Error(errorData.detail || 'Failed to upload image');
      }
    } catch (error: any) {
      console.error('Image upload error:', error);
      toast.error(error.message || 'Failed to upload image');
    } finally {
      setUploadLoading(false);
    }
  };

  // Handle image URL input
  const handleImageUrl = (url: string) => {
    if (url) {
      setFormData(prev => ({ ...prev, featuredImage: url }));
      setFeaturedImageUrl(url);
      setShowImageDialog(false);
    }
  };

  // File selection handler
  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setSelectedFile(file);
      
      // Create preview
      const reader = new FileReader();
      reader.onload = (e) => {
        setFilePreview(e.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const addImageFromUpload = () => {
    if (selectedFile) {
      handleFileUpload(selectedFile);
    }
  };

  const createCategory = async () => {
    try {
      if (!newCategoryName.trim()) {
        toast.error('Category name is required');
        return;
      }

      const categoryRequest: AppApisAdminDashboardCategoryRequest = {
        name: newCategoryName.trim(),
        description: newCategoryDescription.trim() || undefined
      };

      const response = await brain.create_category(categoryRequest);
      const result = await response.json();

      if (result.success) {
        toast.success('Category created successfully!');
        setNewCategoryName('');
        setNewCategoryDescription('');
        setNewCategoryColor('#3B82F6');
        setShowCategoryDialog(false);
        loadData();
      } else {
        toast.error('Failed to create category');
      }
    } catch (error) {
      console.error('Error creating category:', error);
      toast.error('Failed to create category');
    }
  };

  const deleteCategory = async (categoryName: string) => {
    try {
      const response = await brain.delete_category({ categoryName });
      const result = await response.json();

      if (result.success) {
        toast.success('Category deleted successfully!');
        setFormData(prev => ({
          ...prev,
          categories: prev.categories.filter(cat => cat !== categoryName)
        }));
        loadData();
      } else {
        toast.error(result.message || 'Failed to delete category');
      }
    } catch (error: any) {
      console.error('Error deleting category:', error);
      if (error.status === 400) {
        toast.error('Category cannot be deleted as it is being used by existing content');
      } else {
        toast.error('Failed to delete category');
      }
    }
  };

  // Handle external links
  const addExternalLink = () => {
    if (newLink.trim() && !formData.externalLinks.includes(newLink.trim())) {
      setFormData(prev => ({ ...prev, externalLinks: [...prev.externalLinks, newLink.trim()] }));
      setNewLink('');
      setShowLinkDialog(false);
    }
  };

  const removeExternalLink = (link: string) => {
    setFormData(prev => ({ ...prev, externalLinks: prev.externalLinks.filter(l => l !== link) }));
  };

  // Handle image upload
  const handleImageUpload = () => {
    if (imageUrl.trim()) {
      setFormData(prev => ({ ...prev, featuredImage: imageUrl.trim() }));
      setImageUrl('');
      setShowImageDialog(false);
      toast.success('Featured image added!');
    }
  };

  // Save and publish (admin can publish directly)
  const saveAndPublish = async () => {
    if (!formData.title.trim() || !formData.content.trim()) {
      toast.error('Title and content are required');
      return;
    }

    try {
      setSaving(true);
      
      const plainText = formData.content.replace(/<[^>]*>/g, '');
      const excerpt = formData.excerpt ? 
        formData.excerpt.substring(0, 500) : 
        plainText.substring(0, 200) + (plainText.length > 200 ? '...' : '');
      
      if (contentId) {
        const contentData = {
          title: formData.title,
          excerpt: excerpt,
          content: formData.content,
          content_type: formData.contentType,
          status: 'PUBLISHED',
          categories: formData.categories,
          tags: formData.tags,
          author_email: 'admin@respectus.com',
          author_name: 'RespectUs Team',
          featured_image_url: formData.featuredImage || undefined,
          video_url: formData.videoUrl || undefined,
          seo_keywords: formData.seoKeywords,
          external_links: formData.externalLinks,
          scheduled_publish_date: formData.scheduledPublishDate ? new Date(formData.scheduledPublishDate) : undefined
        };

        const request = {
          title: formData.title,
          content: contentData
        };

        const response = await brain.update_content_item({ contentId }, request);
        const data = await response.json();
        
        if (data.message) {
          toast.success('Post published successfully!');
          navigate('/blog');
        } else {
          throw new Error(data.message || 'Failed to update post');
        }
      } else {
        const request: CreateContentRequest = {
          content_type: 'blog_post',
          module_name: 'blog',
          identifier: `blog_post_${Date.now()}`,
          title: formData.title,
          content: {
            excerpt: excerpt,
            content: formData.content,
            content_type: formData.contentType,
            status: 'PUBLISHED',
            categories: formData.categories,
            tags: formData.tags,
            author_email: 'admin@respectus.com',
            author_name: 'RespectUs Team',
            featured_image_url: formData.featuredImage || undefined,
            video_url: formData.videoUrl || undefined,
            seo_keywords: formData.seoKeywords,
            external_links: formData.externalLinks,
            scheduled_publish_date: formData.scheduledPublishDate ? new Date(formData.scheduledPublishDate) : undefined
          }
        };

        const response = await brain.create_content_item(request);
        const data = await response.json();
        
        if (data.message) {
          toast.success('Post published successfully!');
          navigate('/blog');
        } else {
          throw new Error(data.message || 'Failed to publish post');
        }
      }
      
    } catch (error) {
      console.error('Error publishing post:', error);
      toast.error('Failed to publish post');
    } finally {
      setSaving(false);
    }
  };

  // Save draft
  const saveDraft = async () => {
    if (!formData.title.trim() || !formData.content.trim()) {
      toast.error('Title and content are required');
      return;
    }

    try {
      setSaving(true);
      
      const plainText = formData.content.replace(/<[^>]*>/g, '');
      const excerpt = formData.excerpt ? 
        formData.excerpt.substring(0, 500) : 
        plainText.substring(0, 200) + (plainText.length > 200 ? '...' : '');
      
      if (contentId) {
        const contentData = {
          title: formData.title,
          excerpt: excerpt,
          content: formData.content,
          content_type: formData.contentType,
          status: 'DRAFT',
          categories: formData.categories,
          tags: formData.tags,
          author_email: 'admin@respectus.com',
          author_name: 'RespectUs Team',
          featured_image_url: formData.featuredImage || undefined,
          video_url: formData.videoUrl || undefined,
          seo_keywords: formData.seoKeywords,
          external_links: formData.externalLinks
        };

        const request = {
          title: formData.title,
          content: contentData
        };

        const response = await brain.update_content_item({ contentId }, request);
        const data = await response.json();
        
        if (data.message) {
          toast.success('Draft updated successfully!');
        } else {
          throw new Error(data.message || 'Failed to update draft');
        }
      } else {
        const request: CreateContentRequest = {
          content_type: 'blog_post',
          module_name: 'blog',
          identifier: `blog_draft_${Date.now()}`,
          title: formData.title,
          content: {
            excerpt: excerpt,
            content: formData.content,
            content_type: formData.contentType,
            status: 'DRAFT',
            categories: formData.categories,
            tags: formData.tags,
            author_email: 'admin@respectus.com',
            author_name: 'RespectUs Team',
            featured_image_url: formData.featuredImage || undefined,
            video_url: formData.videoUrl || undefined,
            seo_keywords: formData.seoKeywords,
            external_links: formData.externalLinks
          }
        };

        const response = await brain.create_content_item(request);
        const data = await response.json();
        
        if (data.message) {
          toast.success('Draft saved successfully!');
        } else {
          throw new Error(data.message || 'Failed to save draft');
        }
      }
      
    } catch (error) {
      console.error('Error saving draft:', error);
      toast.error('Failed to save draft');
    } finally {
      setSaving(false);
    }
  };

  const handleSave = async () => {
    if (!formData.title.trim()) {
      toast.error('Title is required');
      return;
    }

    try {
      setSaving(true);
      
      const metadata = {
        excerpt: formData.excerpt,
        status: formData.status,
        categories: formData.categories,
        tags: formData.tags,
        author_email: 'admin@respectus.com',
        author_name: 'RespectUs Team',
        featured_image_url: featuredImageUrl,
        seo_title: formData.seoTitle,
        seo_description: formData.seoDescription,
        seo_keywords: formData.seoKeywords,
        publish_date: formData.publishDate,
        external_links: formData.externalLinks
      };

      const payload = {
        title: formData.title,
        content: formData.content,
        content_type: formData.contentType,
        module_name: 'blog',
        metadata: metadata
      };

      let response;
      if (contentId && contentId !== 'new') {
        // Update existing content
        response = await brain.update_content_item({ contentId: parseInt(contentId) }, payload);
      } else {
        // Create new content
        response = await brain.create_content_item(payload);
      }

      const data = await response.json();
      
      if (response.ok) {
        toast.success(contentId && contentId !== 'new' ? 'Content updated successfully!' : 'Content created successfully!');
        setContent(data);
        
        // If creating new content, navigate to edit mode
        if (!contentId || contentId === 'new') {
          navigate(`/blog-admin?id=${data.content_id}`);
        }
      } else {
        throw new Error(data.detail || 'Failed to save content');
      }
    } catch (error) {
      console.error('Error saving content:', error);
      toast.error('Failed to save content');
    } finally {
      setSaving(false);
    }
  };

  // Generate excerpt from content
  const generateExcerpt = () => {
    if (formData.content) {
      const plainText = formData.content.replace(/<[^>]*>/g, '');
      const excerpt = plainText.substring(0, 200) + (plainText.length > 200 ? '...' : '');
      setFormData(prev => ({ ...prev, excerpt }));
      toast.success('Excerpt generated from content');
    }
  };

  // Load data on mount
  useEffect(() => {
    loadData();
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600 font-medium">Loading editor...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      <Navigation currentPage="Blog Admin" />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-3">
              <div className="p-3 rounded-xl bg-gradient-to-br from-amber-500/20 to-orange-600/20 border border-amber-500/30">
                <BookOpen className="w-8 h-8 text-amber-400" />
              </div>
              <div>
                <h1 className="text-3xl font-bold text-slate-100">Blog Administration</h1>
                <p className="text-slate-400">Create and manage blog content</p>
              </div>
            </div>
          </div>
          
          {contentId && (
            <Button
              variant="outline"
              onClick={() => navigate('/blog-admin')}
              className="border-slate-600 text-slate-300 hover:bg-slate-800 hover:text-slate-100"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Admin
            </Button>
          )}
        </div>

        {/* Main Content with Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="bg-slate-800/50 border border-slate-700">
            <TabsTrigger 
              value="create" 
              className="data-[state=active]:bg-teal-600 data-[state=active]:text-white text-slate-300"
            >
              <Plus className="w-4 h-4 mr-2" />
              {contentId ? 'Edit Post' : 'Create Post'}
            </TabsTrigger>
            <TabsTrigger 
              value="manage" 
              className="data-[state=active]:bg-teal-600 data-[state=active]:text-white text-slate-300"
            >
              <FileText className="w-4 h-4 mr-2" />
              Manage Posts
            </TabsTrigger>
          </TabsList>

          {/* Create/Edit Post Tab */}
          <TabsContent value="create" className="space-y-6">
            {loading ? (
              <div className="flex items-center justify-center py-12">
                <div className="text-center space-y-4">
                  <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-teal-500 mx-auto"></div>
                  <p className="text-slate-400">Loading...</p>
                </div>
              </div>
            ) : (
              <>
                {/* Header with actions */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <Badge className="bg-amber-500/20 text-amber-300 border border-amber-500/30 flex items-center gap-1">
                      <Shield className="w-3 h-3" />
                      Admin Access
                    </Badge>
                  </div>
                  
                  <div className="flex items-center space-x-3">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setPreviewMode(!previewMode)}
                      className="border-slate-600 bg-slate-800/50 text-slate-200 hover:bg-slate-700/80 hover:border-slate-500"
                    >
                      <Eye className="w-4 h-4 mr-2" />
                      {previewMode ? 'Edit' : 'Preview'}
                    </Button>
                    
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={saveDraft}
                      disabled={saving}
                      className="border-slate-600 bg-slate-800/50 text-slate-200 hover:bg-slate-700/80 hover:border-amber-400"
                    >
                      <Save className="w-4 h-4 mr-2" />
                      Save Draft
                    </Button>
                    
                    <Button 
                      variant="default" 
                      size="sm" 
                      disabled={saving}
                      onClick={saveAndPublish}
                      className="bg-gradient-to-r from-teal-600 to-teal-700 hover:from-teal-700 hover:to-teal-800 text-white shadow-lg border-0"
                    >
                      <Shield className="w-4 h-4 mr-2" />
                      Publish Now
                    </Button>
                  </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                  {/* Main Content Area */}
                  <div className="lg:col-span-2 space-y-6">
                    {previewMode ? (
                      /* Preview Mode */
                      <div className="min-h-screen bg-gray-100 py-8 rounded-lg">
                        <div className="max-w-3xl mx-auto">
                          <div className="bg-white shadow-lg rounded-lg" style={{ 
                            margin: '0 auto',
                            padding: '2rem',
                            fontFamily: 'Inter, system-ui, sans-serif'
                          }}>
                            {formData.featuredImage && (
                              <img 
                                src={formData.featuredImage} 
                                alt="Featured" 
                                className="w-full h-48 object-cover mb-6 rounded"
                                onError={() => {
                                  console.error('Failed to load featured image:', formData.featuredImage);
                                }}
                                onLoad={() => {
                                  console.log('Successfully loaded featured image:', formData.featuredImage);
                                }}
                              />
                            )}
                            
                            <div className="text-center mb-8">
                              <h1 
                                className="font-bold text-gray-900 mb-4 leading-tight"
                                style={{
                                  fontSize: '28px',
                                  fontFamily: 'Inter, system-ui, sans-serif',
                                  lineHeight: '1.2'
                                }}
                              >
                                {formData.title || 'Blog Post Title'}
                              </h1>
                              <div className="text-sm text-gray-500 mb-6">
                                <span>By {selectedAuthor?.full_name || 'Admin'}</span>
                                <span className="mx-2">•</span>
                                <span>{new Date().toLocaleDateString()}</span>
                                <span className="mx-2">•</span>
                                <span>5 min read</span>
                              </div>
                            </div>
                            
                            <div 
                              className="prose prose-lg max-w-none"
                              dangerouslySetInnerHTML={{ __html: formData.content || '<p>Start writing your content...</p>' }}
                            />
                          </div>
                        </div>
                      </div>
                    ) : (
                      /* Edit Mode */
                      <div className="space-y-6">
                        {/* Basic Information Card */}
                        <Card className="shadow-2xl border-slate-700/50 bg-slate-800/60 backdrop-blur-sm">
                          <CardHeader className="bg-gradient-to-r from-slate-800/80 to-slate-700/80 border-b border-slate-600/50">
                            <CardTitle className="text-slate-100 font-semibold">Basic Information</CardTitle>
                          </CardHeader>
                          <CardContent className="space-y-4 p-6">
                            <div>
                              <Label htmlFor="title" className="text-slate-200 font-medium">Title *</Label>
                              <Input
                                id="title"
                                value={formData.title}
                                onChange={(e) => handleInputChange('title', e.target.value)}
                                placeholder="Enter post title..."
                                className="border-slate-600 focus:border-teal-400 focus:ring-teal-400 bg-slate-900/50 text-slate-100 placeholder-slate-400"
                              />
                            </div>
                            
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                              <div>
                                <Label htmlFor="contentType" className="text-slate-200 font-medium">Content Type</Label>
                                <Select 
                                  value={formData.contentType} 
                                  onValueChange={(value) => handleInputChange('contentType', value)}
                                >
                                  <SelectTrigger className="bg-slate-900/50 border-slate-600 text-slate-100 focus:border-teal-400">
                                    <SelectValue />
                                  </SelectTrigger>
                                  <SelectContent className="bg-slate-900 border-slate-700">
                                    <SelectItem value="ARTICLE" className="text-slate-100 hover:bg-slate-800">Article</SelectItem>
                                    <SelectItem value="GUIDE" className="text-slate-100 hover:bg-slate-800">Guide</SelectItem>
                                    <SelectItem value="NEWS" className="text-slate-100 hover:bg-slate-800">News</SelectItem>
                                    <SelectItem value="CASE_STUDY" className="text-slate-100 hover:bg-slate-800">Case Study</SelectItem>
                                    <SelectItem value="REGULATION" className="text-slate-100 hover:bg-slate-800">Regulation</SelectItem>
                                  </SelectContent>
                                </Select>
                              </div>
                              
                              <div>
                                <Label htmlFor="status" className="text-slate-200 font-medium">Status</Label>
                                <Select 
                                  value={formData.status} 
                                  onValueChange={(value) => handleInputChange('status', value)}
                                >
                                  <SelectTrigger className="bg-slate-900/50 border-slate-600 text-slate-100 focus:border-teal-400">
                                    <SelectValue />
                                  </SelectTrigger>
                                  <SelectContent className="bg-slate-900 border-slate-700">
                                    <SelectItem value="DRAFT" className="text-slate-100 hover:bg-slate-800">Draft</SelectItem>
                                    <SelectItem value="PUBLISHED" className="text-slate-100 hover:bg-slate-800">Published</SelectItem>
                                    <SelectItem value="ARCHIVED" className="text-slate-100 hover:bg-slate-800">Archived</SelectItem>
                                  </SelectContent>
                                </Select>
                              </div>
                            </div>
                            
                            <div>
                              <div className="flex items-center justify-between mb-2">
                                <Label htmlFor="excerpt" className="text-slate-200 font-medium">Excerpt</Label>
                                <Button 
                                  variant="outline" 
                                  size="sm" 
                                  onClick={generateExcerpt}
                                  disabled={!formData.content}
                                  className="border-slate-600 bg-slate-700/50 text-slate-200 hover:bg-slate-600/80 hover:border-amber-400"
                                >
                                  Generate from content
                                </Button>
                              </div>
                              <Textarea
                                id="excerpt"
                                value={formData.excerpt}
                                onChange={(e) => handleInputChange('excerpt', e.target.value)}
                                placeholder="Brief description of your post..."
                                rows={3}
                                className="bg-slate-900/50 border-slate-600 text-slate-100 placeholder-slate-400 focus:border-teal-400 focus:ring-teal-400"
                              />
                            </div>
                          </CardContent>
                        </Card>

                        {/* Rich Text Editor Card */}
                        <Card className="shadow-2xl border-slate-700/50 bg-slate-800/60 backdrop-blur-sm">
                          <CardHeader className="bg-gradient-to-r from-slate-800/80 to-slate-700/80 border-b border-slate-600/50">
                            <CardTitle className="text-slate-100 font-semibold">Content *</CardTitle>
                          </CardHeader>
                          <CardContent className="p-6">
                            <RichTextEditor
                              content={formData.content}
                              onChange={(content) => handleInputChange('content', content)}
                              placeholder="Start writing your blog post..."
                              className="min-h-96 border-slate-600 focus:border-teal-400 bg-slate-900/50"
                            />
                          </CardContent>
                        </Card>
                      </div>
                    )}
                  </div>
                  
                  {/* Sidebar */}
                  <div className="lg:col-span-1 space-y-6">
                    {/* Featured Image */}
                    <Card className="shadow-2xl border-slate-700/50 bg-slate-800/60 backdrop-blur-sm">
                      <CardHeader className="bg-gradient-to-r from-slate-800/80 to-slate-700/80 border-b border-slate-600/50">
                        <CardTitle className="flex items-center text-slate-100 font-semibold">
                          <ImageIcon className="w-5 h-5 mr-2 text-teal-400" />
                          Featured Image
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="p-4">
                        {formData.featuredImage ? (
                          <div className="relative">
                            <img 
                              src={formData.featuredImage} 
                              alt="Featured" 
                              className="w-full h-32 object-cover rounded border border-slate-600"
                              onError={() => {
                                console.error('Failed to load featured image:', formData.featuredImage);
                              }}
                              onLoad={() => {
                                console.log('Successfully loaded featured image:', formData.featuredImage);
                              }}
                            />
                            <Button
                              variant="destructive"
                              size="sm"
                              className="absolute top-2 right-2 bg-red-600 hover:bg-red-700"
                              onClick={() => handleInputChange('featuredImage', '')}
                            >
                              <X className="w-4 h-4" />
                            </Button>
                          </div>
                        ) : (
                          <div className="text-center py-8 border-2 border-dashed border-slate-600 rounded">
                            <ImageIcon className="w-8 h-8 text-slate-500 mx-auto mb-2" />
                            <p className="text-slate-400 text-sm mb-3">No featured image</p>
                            <Button 
                              variant="outline" 
                              size="sm"
                              onClick={() => setShowImageDialog(true)}
                              className="border-slate-600 text-slate-300 hover:bg-slate-800 hover:text-slate-100"
                            >
                              <Upload className="w-4 h-4 mr-2" />
                              Add Image
                            </Button>
                          </div>
                        )}
                      </CardContent>
                    </Card>

                    {/* Post Stats */}
                    <Card className="shadow-2xl border-slate-700/50 bg-slate-800/60 backdrop-blur-sm">
                      <CardHeader className="bg-gradient-to-r from-slate-800/80 to-slate-700/80 border-b border-slate-600/50">
                        <CardTitle className="text-slate-100 font-semibold">Post Statistics</CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-2 p-4">
                        <div className="flex justify-between text-sm">
                          <span className="text-slate-300">Characters:</span>
                          <span className="font-medium text-slate-100">{formData.content.length.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span className="text-slate-300">Words:</span>
                          <span className="font-medium text-slate-100">
                            {formData.content ? formData.content.split(/\s+/).filter(word => word.length > 0).length.toLocaleString() : 0}
                          </span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span className="text-slate-300">Read time:</span>
                          <span className="font-medium text-slate-100">
                            {Math.max(1, Math.ceil((formData.content.split(/\s+/).filter(word => word.length > 0).length || 0) / 200))} min
                          </span>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </div>
              </>
            )}
          </TabsContent>

          {/* Manage Posts Tab */}
          <TabsContent value="manage" className="space-y-6">
            {/* Search and Filter Controls */}
            <Card className="border-slate-700/50 bg-slate-800/60 backdrop-blur-sm">
              <CardContent className="p-6">
                <div className="flex flex-col sm:flex-row gap-4">
                  <div className="flex-1">
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
                      <Input
                        placeholder="Search posts by title, content, or excerpt..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="pl-10 bg-slate-900/50 border-slate-600 text-slate-100 placeholder-slate-400 focus:border-teal-400 focus:ring-teal-400"
                      />
                    </div>
                  </div>
                  <div className="w-full sm:w-48">
                    <Select value={statusFilter} onValueChange={setStatusFilter}>
                      <SelectTrigger className="bg-slate-900/50 border-slate-600 text-slate-100">
                        <Filter className="w-4 h-4 mr-2 text-slate-400" />
                        <SelectValue placeholder="Filter by status" />
                      </SelectTrigger>
                      <SelectContent className="bg-slate-800 border-slate-700">
                        <SelectItem value="ALL" className="text-slate-200">All Posts</SelectItem>
                        <SelectItem value="PUBLISHED" className="text-slate-200">Published</SelectItem>
                        <SelectItem value="DRAFT" className="text-slate-200">Drafts</SelectItem>
                        <SelectItem value="ARCHIVED" className="text-slate-200">Archived</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Posts List */}
            {postsLoading ? (
              <div className="flex items-center justify-center py-12">
                <div className="text-center space-y-4">
                  <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-teal-500 mx-auto"></div>
                  <p className="text-slate-400">Loading posts...</p>
                </div>
              </div>
            ) : filteredPosts.length === 0 ? (
              <Card className="border-slate-700/50 bg-slate-800/60 backdrop-blur-sm">
                <CardContent className="p-12 text-center">
                  <FileText className="w-12 h-12 text-slate-500 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-slate-300 mb-2">
                    {allPosts.length === 0 ? 'No blog posts found' : 'No posts match your search'}
                  </h3>
                  <p className="text-slate-400">
                    {allPosts.length === 0 
                      ? 'Create your first blog post to get started.'
                      : 'Try adjusting your search terms or filters.'
                    }
                  </p>
                </CardContent>
              </Card>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredPosts.map((post) => {
                  const status = post.content?.status || post.metadata?.status || 'DRAFT';
                  const featuredImage = post.content?.featured_image_url || post.metadata?.featured_image_url;
                  const convertedFeaturedImage = featuredImage ? convertToAppStaticUrl(featuredImage) : null;
                  const excerpt = post.content?.excerpt || post.metadata?.excerpt || '';
                  const publishDate = post.created_at || post.updated_at;
                  
                  return (
                    <Card key={post.id} className="border-slate-700/50 bg-slate-800/60 backdrop-blur-sm hover:bg-slate-800/80 transition-all duration-200">
                      {post.featured_image_url && (
                        <div className="relative h-48 overflow-hidden rounded-t-lg">
                          <img 
                            src={convertToAppStaticUrl(post.featured_image_url)} 
                            alt="Featured" 
                            className="w-full h-full object-cover"
                            onError={(e) => {
                              console.error('Failed to load featured image:', post.featured_image_url);
                              e.currentTarget.style.display = 'none';
                            }}
                          />
                          <div className="absolute top-3 right-3">
                            <Badge 
                              variant={status === 'PUBLISHED' ? 'default' : 'secondary'}
                              className={`
                                ${status === 'PUBLISHED' 
                                  ? 'bg-green-600 text-white' 
                                  : status === 'DRAFT' 
                                    ? 'bg-yellow-600 text-white'
                                    : 'bg-gray-600 text-white'
                                }
                              `}
                            >
                              {status}
                            </Badge>
                          </div>
                        </div>
                      )}
                      
                      <CardContent className="p-6">
                        <div className="space-y-4">
                          <div>
                            <h3 className="font-semibold text-slate-100 text-lg mb-2 line-clamp-2">
                              {post.title || 'Untitled Post'}
                            </h3>
                            {excerpt && (
                              <p className="text-slate-400 text-sm line-clamp-3">
                                {excerpt}
                              </p>
                            )}
                          </div>
                          
                          {!featuredImage && (
                            <div className="flex justify-between items-center">
                              <Badge 
                                variant={status === 'PUBLISHED' ? 'default' : 'secondary'}
                                className={`
                                  ${status === 'PUBLISHED' 
                                    ? 'bg-green-600 text-white' 
                                    : status === 'DRAFT' 
                                      ? 'bg-yellow-600 text-white'
                                      : 'bg-gray-600 text-white'
                                  }
                                `}
                              >
                                {status}
                              </Badge>
                            </div>
                          )}
                          
                          {publishDate && (
                            <div className="flex items-center text-xs text-slate-500">
                              <Calendar className="w-3 h-3 mr-1" />
                              {new Date(publishDate).toLocaleDateString()}
                            </div>
                          )}
                          
                          {/* Action Buttons */}
                          <div className="flex gap-2 pt-4 border-t border-slate-700">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleEditPost(post)}
                              className="flex-1 border-slate-600 text-slate-300 hover:bg-slate-700 hover:text-slate-100"
                            >
                              <Edit className="w-3 h-3 mr-1" />
                              Edit
                            </Button>
                            
                            {status === 'DRAFT' && (
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => handlePublishPost(post)}
                                className="flex-1 border-green-600 text-green-400 hover:bg-green-600 hover:text-white"
                              >
                                <Eye className="w-3 h-3 mr-1" />
                                Publish
                              </Button>
                            )}
                            
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleDeletePost(post)}
                              className="border-red-600 text-red-400 hover:bg-red-600 hover:text-white"
                            >
                              <Trash2 className="w-3 h-3" />
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
      
      {/* Featured Image Upload Dialog */}
      <Dialog open={showImageDialog} onOpenChange={setShowImageDialog}>
        <DialogContent className="bg-slate-900/95 backdrop-blur-xl border border-slate-700/50 text-white max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-xl font-semibold">
              <div className="w-8 h-8 bg-gradient-to-br from-emerald-500 to-blue-600 rounded-lg flex items-center justify-center">
                <ImageIcon className="w-4 h-4 text-white" />
              </div>
              Add Featured Image
            </DialogTitle>
            <DialogDescription className="text-slate-400">
              Upload an image or provide a URL for the featured image
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-6 py-4">
            <Tabs value={activeImageTab} onValueChange={setActiveImageTab} className="w-full">
              <TabsList className="grid w-full grid-cols-2 bg-slate-800/60">
                <TabsTrigger value="upload" className="text-slate-300 data-[state=active]:bg-slate-700 data-[state=active]:text-white">
                  Upload File
                </TabsTrigger>
                <TabsTrigger value="url" className="text-slate-300 data-[state=active]:bg-slate-700 data-[state=active]:text-white">
                  Image URL
                </TabsTrigger>
              </TabsList>
              
              <TabsContent value="upload" className="space-y-4 mt-4">
                <div className="space-y-4">
                  <Label className="text-slate-300 font-medium">Select Image</Label>
                  <div className="border-2 border-dashed border-slate-600 rounded-lg p-6 text-center hover:border-slate-500 transition-colors">
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleFileSelect}
                      className="hidden"
                      id="image-upload"
                    />
                    <label htmlFor="image-upload" className="cursor-pointer space-y-2">
                      <Upload className="w-8 h-8 text-slate-400 mx-auto" />
                      <p className="text-slate-400">Click to select image</p>
                      <p className="text-xs text-slate-500">PNG, JPG, GIF up to 10MB</p>
                    </label>
                  </div>
                  
                  {filePreview && (
                    <div className="relative">
                      <img src={filePreview} alt="Preview" className="w-full h-48 object-cover rounded-lg" />
                      <Button
                        variant="destructive"
                        size="sm"
                        onClick={() => {
                          setSelectedFile(null);
                          setFilePreview('');
                        }}
                        className="absolute top-2 right-2"
                      >
                        Remove
                      </Button>
                    </div>
                  )}
                </div>
              </TabsContent>
              
              <TabsContent value="url" className="space-y-4 mt-4">
                <div className="space-y-4">
                  <Label className="text-slate-300 font-medium">Image URL</Label>
                  <Input
                    value={imageUrl}
                    onChange={(e) => setImageUrl(e.target.value)}
                    placeholder="https://example.com/image.jpg"
                    className="bg-slate-800/60 border-slate-600 text-slate-100 placeholder-slate-400"
                  />
                </div>
              </TabsContent>
            </Tabs>
          </div>
          
          <DialogFooter className="gap-3">
            <Button
              variant="outline"
              onClick={() => setShowImageDialog(false)}
              className="border-slate-600/50 text-slate-300 hover:bg-slate-700/60"
            >
              Cancel
            </Button>
            {activeImageTab === 'upload' ? (
              <Button
                onClick={addImageFromUpload}
                disabled={!selectedFile || uploadLoading}
                className="bg-gradient-to-r from-emerald-600 to-blue-600 hover:from-emerald-700 hover:to-blue-700 text-white"
              >
                {uploadLoading ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Uploading...
                  </>
                ) : (
                  'Upload Image'
                )}
              </Button>
            ) : (
              <Button
                onClick={() => handleImageUrl(featuredImageUrl)}
                disabled={!featuredImageUrl.trim()}
                className="bg-gradient-to-r from-emerald-600 to-blue-600 hover:from-emerald-700 hover:to-blue-700 text-white"
              >
                Add Image
              </Button>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      <Footer variant="main" />
    </div>
  );
}
