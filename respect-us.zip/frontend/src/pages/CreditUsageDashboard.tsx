import React, { useState } from 'react';
import { Coins, TrendingUp, TrendingDown, Calendar, Filter, Download, RefreshCw } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useUserGuardContext } from 'app/auth';
import { useCreditBalance, useCreditTransactionHistory, type CreditTransaction } from 'utils/useCreditBalance';
import CreditBalanceDisplay from 'components/CreditBalanceDisplay';

interface TransactionsByDate {
  [date: string]: CreditTransaction[];
}

interface ComponentUsage {
  component_name: string;
  total_consumed: number;
  transaction_count: number;
  actions: {
    action_name: string;
    count: number;
    total_credits: number;
  }[];
}

export default function CreditUsageDashboard() {
  const { user } = useUserGuardContext();
  const { balance, isLoading: balanceLoading, refreshBalance } = useCreditBalance();
  const { transactions, isLoading: transactionsLoading, refreshTransactions } = useCreditTransactionHistory();
  const [selectedPeriod, setSelectedPeriod] = useState('30');
  const [selectedType, setSelectedType] = useState('all');

  const handleRefresh = () => {
    refreshBalance();
    refreshTransactions(100, 0);
  };

  const filteredTransactions = transactions.filter(tx => {
    const transactionDate = new Date(tx.created_at);
    const daysAgo = Number.parseInt(selectedPeriod, 10);
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - daysAgo);
    
    const isInPeriod = selectedPeriod === 'all' || transactionDate >= cutoffDate;
    const isOfType = selectedType === 'all' || tx.transaction_type === selectedType;
    
    return isInPeriod && isOfType;
  });

  const transactionsByDate: TransactionsByDate = filteredTransactions.reduce((acc, tx) => {
    const date = new Date(tx.created_at).toLocaleDateString();
    if (!acc[date]) acc[date] = [];
    acc[date].push(tx);
    return acc;
  }, {} as TransactionsByDate);

  const componentUsage: ComponentUsage[] = filteredTransactions
    .filter(tx => tx.component_name && tx.transaction_type === 'consume')
    .reduce((acc, tx) => {
      const existing = acc.find(c => c.component_name === tx.component_name);
      if (existing) {
        existing.total_consumed += Math.abs(tx.amount);
        existing.transaction_count += 1;
        
        const action = existing.actions.find(a => a.action_name === tx.action_name);
        if (action) {
          action.count += 1;
          action.total_credits += Math.abs(tx.amount);
        } else {
          existing.actions.push({
            action_name: tx.action_name || 'Unknown',
            count: 1,
            total_credits: Math.abs(tx.amount)
          });
        }
      } else {
        acc.push({
          component_name: tx.component_name,
          total_consumed: Math.abs(tx.amount),
          transaction_count: 1,
          actions: [{
            action_name: tx.action_name || 'Unknown',
            count: 1,
            total_credits: Math.abs(tx.amount)
          }]
        });
      }
      return acc;
    }, [] as ComponentUsage[])
    .sort((a, b) => b.total_consumed - a.total_consumed);

  const totalConsumed = filteredTransactions
    .filter(tx => tx.transaction_type === 'consume')
    .reduce((sum, tx) => sum + Math.abs(tx.amount), 0);

  const totalPurchased = filteredTransactions
    .filter(tx => tx.transaction_type === 'purchase' || tx.transaction_type === 'bonus')
    .reduce((sum, tx) => sum + tx.amount, 0);

  const getTransactionIcon = (type: string) => {
    switch (type) {
      case 'purchase':
      case 'bonus':
        return <TrendingUp className="w-4 h-4 text-green-400" />;
      case 'consume':
        return <TrendingDown className="w-4 h-4 text-red-400" />;
      default:
        return <Coins className="w-4 h-4 text-gray-400" />;
    }
  };

  const getTransactionColor = (type: string) => {
    switch (type) {
      case 'purchase':
      case 'bonus':
        return 'text-green-400';
      case 'consume':
        return 'text-red-400';
      default:
        return 'text-gray-400';
    }
  };

  if (balanceLoading || transactionsLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gray-950">
        <div className="text-center">
          <RefreshCw className="w-8 h-8 animate-spin text-blue-400 mx-auto mb-4" />
          <p className="text-gray-400">Loading credit usage data...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-950 text-white p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-white mb-2">Credit Usage Dashboard</h1>
            <p className="text-gray-400">Track your credit consumption and manage your account</p>
          </div>
          <div className="flex items-center space-x-4">
            <Button 
              onClick={handleRefresh}
              variant="outline"
              className="border-gray-700 text-gray-300 hover:bg-gray-800"
            >
              <RefreshCw className="w-4 h-4 mr-2" />
              Refresh
            </Button>
            <Button className="bg-purple-600 hover:bg-purple-700">
              <Download className="w-4 h-4 mr-2" />
              Export Data
            </Button>
          </div>
        </div>

        {/* Balance Overview */}
        <CreditBalanceDisplay variant="detailed" className="mb-6" />

        {/* Filters */}
        <Card className="bg-gray-900 border-gray-800">
          <CardHeader>
            <CardTitle className="text-white flex items-center space-x-2">
              <Filter className="w-5 h-5" />
              <span>Filters</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center space-x-4">
              <div>
                <label className="text-sm text-gray-400 mb-2 block">Time Period</label>
                <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
                  <SelectTrigger className="w-40 bg-gray-800 border-gray-700">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-gray-800 border-gray-700">
                    <SelectItem value="7">Last 7 days</SelectItem>
                    <SelectItem value="30">Last 30 days</SelectItem>
                    <SelectItem value="90">Last 90 days</SelectItem>
                    <SelectItem value="365">Last year</SelectItem>
                    <SelectItem value="all">All time</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <label className="text-sm text-gray-400 mb-2 block">Transaction Type</label>
                <Select value={selectedType} onValueChange={setSelectedType}>
                  <SelectTrigger className="w-40 bg-gray-800 border-gray-700">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-gray-800 border-gray-700">
                    <SelectItem value="all">All types</SelectItem>
                    <SelectItem value="consume">Usage</SelectItem>
                    <SelectItem value="purchase">Purchases</SelectItem>
                    <SelectItem value="bonus">Bonuses</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Summary Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card className="bg-gray-900 border-gray-800">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-400">Total Consumed</p>
                  <p className="text-2xl font-bold text-red-400">{totalConsumed.toLocaleString()}</p>
                </div>
                <TrendingDown className="w-8 h-8 text-red-400" />
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-gray-900 border-gray-800">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-400">Total Purchased</p>
                  <p className="text-2xl font-bold text-green-400">{totalPurchased.toLocaleString()}</p>
                </div>
                <TrendingUp className="w-8 h-8 text-green-400" />
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-gray-900 border-gray-800">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-400">Total Transactions</p>
                  <p className="text-2xl font-bold text-blue-400">{filteredTransactions.length}</p>
                </div>
                <Calendar className="w-8 h-8 text-blue-400" />
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-gray-900 border-gray-800">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-400">Modules Used</p>
                  <p className="text-2xl font-bold text-purple-400">{componentUsage.length}</p>
                </div>
                <Coins className="w-8 h-8 text-purple-400" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Detailed Data */}
        <Tabs defaultValue="transactions" className="space-y-6">
          <TabsList className="bg-gray-900 border-gray-800">
            <TabsTrigger value="transactions">Transaction History</TabsTrigger>
            <TabsTrigger value="modules">Module Usage</TabsTrigger>
          </TabsList>
          
          <TabsContent value="transactions" className="space-y-4">
            <Card className="bg-gray-900 border-gray-800">
              <CardHeader>
                <CardTitle className="text-white">Recent Transactions</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {Object.entries(transactionsByDate)
                    .sort(([a], [b]) => new Date(b).getTime() - new Date(a).getTime())
                    .slice(0, 10)
                    .map(([date, dayTransactions]) => (
                      <div key={date} className="space-y-2">
                        <h4 className="text-sm font-medium text-gray-400 border-b border-gray-800 pb-1">
                          {date}
                        </h4>
                        <div className="space-y-2">
                          {dayTransactions.map((tx) => (
                            <div key={tx.id} className="flex items-center justify-between p-3 bg-gray-800 rounded-lg">
                              <div className="flex items-center space-x-3">
                                {getTransactionIcon(tx.transaction_type)}
                                <div>
                                  <p className="text-sm font-medium text-white">
                                    {tx.description || `${tx.component_name} - ${tx.action_name}`}
                                  </p>
                                  <p className="text-xs text-gray-400">
                                    {new Date(tx.created_at).toLocaleTimeString()}
                                  </p>
                                </div>
                              </div>
                              <div className="text-right">
                                <p className={`text-sm font-medium ${getTransactionColor(tx.transaction_type)}`}>
                                  {tx.transaction_type === 'consume' ? '-' : '+'}{Math.abs(tx.amount)} credits
                                </p>
                                <p className="text-xs text-gray-400">
                                  Balance: {tx.balance_after}
                                </p>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    ))}
                  
                  {filteredTransactions.length === 0 && (
                    <div className="text-center py-8">
                      <Coins className="w-12 h-12 text-gray-600 mx-auto mb-4" />
                      <p className="text-gray-400">No transactions found for the selected period</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="modules" className="space-y-4">
            <Card className="bg-gray-900 border-gray-800">
              <CardHeader>
                <CardTitle className="text-white">Module Usage Breakdown</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {componentUsage.map((component) => (
                    <div key={component.component_name} className="p-4 bg-gray-800 rounded-lg">
                      <div className="flex items-center justify-between mb-3">
                        <h4 className="text-lg font-medium text-white capitalize">
                          {component.component_name.replace('_', ' ')}
                        </h4>
                        <Badge className="bg-purple-500/20 text-purple-400 border-purple-500/30">
                          {component.total_consumed} credits
                        </Badge>
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                        {component.actions.map((action) => (
                          <div key={action.action_name} className="p-3 bg-gray-700 rounded">
                            <p className="text-sm font-medium text-white capitalize">
                              {action.action_name.replace('_', ' ')}
                            </p>
                            <p className="text-xs text-gray-400">
                              {action.count} uses • {action.total_credits} credits
                            </p>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                  
                  {componentUsage.length === 0 && (
                    <div className="text-center py-8">
                      <TrendingDown className="w-12 h-12 text-gray-600 mx-auto mb-4" />
                      <p className="text-gray-400">No module usage found for the selected period</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
