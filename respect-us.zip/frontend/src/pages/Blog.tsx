import React, { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Skeleton } from '@/components/ui/skeleton';
import { Search, Calendar, User, ArrowRight, Clock, Tag, Grid3x3, List, ChevronLeft, ChevronRight, FileText, Eye, MessageCircle, Mail, MapPin, Globe } from 'lucide-react';
import Navigation from 'components/Navigation';
import Footer from 'components/Footer';
import BlogComments from 'components/BlogComments';
import brain from 'brain';
import { ContentResponse, CategoryResponse, ContentType, ContentStatus } from 'types';
import { format } from 'date-fns';
import { API_URL } from 'app';

// Local type definitions
type ContentType = 'ARTICLE' | 'GUIDE' | 'NEWS' | 'CASE_STUDY' | 'REGULATION';
type ContentStatus = 'DRAFT' | 'PUBLISHED' | 'ARCHIVED';

interface Category {
  category_id: string;
  name: string;
  description?: string;
}

interface Author {
  user_email: string;
  full_name: string;
  bio?: string;
  location?: string;
  expertise_areas?: string[];
  social_links?: {
    website?: string;
    linkedin?: string;
    twitter?: string;
  };
}

interface BlogPost {
  id: number;
  title: string;
  content: string;
  content_type: ContentType;
  status: ContentStatus;
  author_name?: string;
  author_email?: string;
  featured_image_url?: string;
  published_at?: string;
  created_at: string;
  updated_at?: string;
  excerpt?: string;
  tags?: string[];
  categories?: string[];
  read_time?: number;
  seo_keywords?: string[];
  seo_description?: string;
  external_links?: string[];
  social_media?: {
    facebook?: string;
    twitter?: string;
  };
}

interface FeaturedPost {
  post: BlogPost;
  reason: string;
  priority: number;
}

export default function Blog() {
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  
  // Check if we're viewing a specific post
  const postSlug = searchParams.get('post');
  const [selectedPost, setSelectedPost] = useState<BlogPost | null>(null);
  
  // State
  const [posts, setPosts] = useState<ContentResponse[]>([]);
  const [featuredPosts, setFeaturedPosts] = useState<FeaturedPost[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [authors, setAuthors] = useState<Author[]>([]);
  const [loading, setLoading] = useState(true);
  const [postLoading, setPostLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState(searchParams.get('search') || '');
  const [selectedCategory, setSelectedCategory] = useState(searchParams.get('category') || 'all');
  const [selectedType, setSelectedType] = useState<ContentType | 'all'>((searchParams.get('type') as ContentType) || 'all');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [totalPosts, setTotalPosts] = useState(0);
  
  const pageSize = 12;

  // Helper function to convert media IDs to blob URLs using brain client
  const getMediaBlobUrl = async (imageUrl: string | null): Promise<string | null> => {
    if (!imageUrl) return null;
    
    try {
      // If it's already a blob URL, return as-is
      if (imageUrl.startsWith('blob:')) {
        return imageUrl;
      }
      
      // If it's a full HTTP URL, extract the filename and use static serving
      if (imageUrl.startsWith('http')) {
        // Check if it's an external static URL that needs conversion
        if (imageUrl.startsWith('https://static.databutton.com/')) {
          const filename = imageUrl.split('/').pop();
          if (filename) {
            const imageResponse = await brain.serve_static_image({ imageFilename: filename });
            if (imageResponse.ok) {
              const imageBlob = await imageResponse.blob();
              return URL.createObjectURL(imageBlob);
            }
          }
        }
        // If it's another HTTP URL, return as-is
        return imageUrl;
      }
      
      // If it looks like a filename, use static serving
      if (!imageUrl.includes('/') || imageUrl.includes('.')) {
        const imageResponse = await brain.serve_static_image({ imageFilename: imageUrl });
        if (imageResponse.ok) {
          const imageBlob = await imageResponse.blob();
          return URL.createObjectURL(imageBlob);
        }
      }
      
      // Fallback: try to extract filename and use static serving
      let filename = imageUrl;
      if (imageUrl.includes('/')) {
        filename = imageUrl.split('/').pop() || imageUrl;
      }
      
      const imageResponse = await brain.serve_static_image({ imageFilename: filename });
      if (imageResponse.ok) {
        const imageBlob = await imageResponse.blob();
        return URL.createObjectURL(imageBlob);
      }
      
      return null;
    } catch (error) {
      console.error('Error getting media blob URL:', error);
      return null;
    }
  };

  // Load specific post
  const loadPost = async (slug: string) => {
    try {
      setPostLoading(true);
      const response = await brain.get_content_item({ contentId: parseInt(slug) });
      const data = await response.json();
      
      // Extract featured image URL from the content structure (same logic as post list)
      let featuredImageUrl = null;
      
      // Try different locations for the featured image URL
      if (data.metadata?.featured_image_url) {
        featuredImageUrl = data.metadata.featured_image_url;
      } else if (data.content?.featured_image_url) {
        featuredImageUrl = data.content.featured_image_url;
      } else if (data.content?.text) {
        // Parse the nested JSON content structure (like in BlogAdmin)
        try {
          const contentData = JSON.parse(data.content.text);
          if (contentData.featured_image_url) {
            featuredImageUrl = contentData.featured_image_url;
          }
        } catch (e) {
          // Not JSON, continue with other methods
        }
      }
      
      const blobUrl = await getMediaBlobUrl(featuredImageUrl);
      
      // Get content string for read time calculation
      let contentString = '';
      if (data.content?.text) {
        try {
          const contentData = JSON.parse(data.content.text);
          contentString = contentData.content || '';
        } catch (e) {
          contentString = data.content.text || '';
        }
      } else {
        contentString = data.content?.content || data.content || '';
      }
      
      setSelectedPost({
        ...data,
        featured_image_url: blobUrl, // Use blob URL
        read_time: Math.max(1, Math.ceil((contentString.split(' ').length || 0) / 200))
      });
    } catch (error) {
      console.error('Error loading post:', error);
      setSelectedPost(null);
    } finally {
      setPostLoading(false);
    }
  };

  // Load blog content
  const loadPosts = async (page = 1) => {
    try {
      setLoading(true);
      
      const response = await brain.get_content_by_module({ moduleName: 'blog' });
      const data = await response.json();
      
      // Process posts and convert featured images to blob URLs
      const allPosts = data.items || [];
      
      // Filter posts based on current filters
      let filteredPosts = allPosts.filter((post: any) => {
        // Filter by status - check both locations for status
        const postStatus = post.content?.status || post.metadata?.status || post.status;
        if (postStatus !== 'PUBLISHED' && postStatus !== 'published') return false;
        
        // Filter by content type
        if (selectedType !== 'all' && post.content_type !== selectedType) return false;
        
        // Filter by category
        const categories = post.content?.categories || post.metadata?.categories || [];
        if (selectedCategory !== 'all' && !categories.includes(selectedCategory)) return false;
        
        // Filter by search
        if (searchQuery) {
          const searchLower = searchQuery.toLowerCase();
          const content = post.content?.content || post.content || '';
          return post.title?.toLowerCase().includes(searchLower) || 
                 content.toLowerCase().includes(searchLower);
        }
        
        return true;
      });
      
      // Apply pagination
      const startIndex = (page - 1) * pageSize;
      const paginatedPosts = filteredPosts.slice(startIndex, startIndex + pageSize);
      
      const postsWithBlobUrls = await Promise.all(
        paginatedPosts.map(async (post: any) => {
          // Extract featured image URL from the content structure
          let featuredImageUrl = null;
          
          // Try different locations for the featured image URL
          if (post.metadata?.featured_image_url) {
            featuredImageUrl = post.metadata.featured_image_url;
          } else if (post.content?.featured_image_url) {
            featuredImageUrl = post.content.featured_image_url;
          } else if (post.content?.text) {
            // Parse the nested JSON content structure (like in BlogAdmin)
            try {
              const contentData = JSON.parse(post.content.text);
              if (contentData.featured_image_url) {
                featuredImageUrl = contentData.featured_image_url;
              }
            } catch (e) {
              // Not JSON, continue with other methods
            }
          }
          
          const blobUrl = await getMediaBlobUrl(featuredImageUrl);
          
          // Get content string for read time calculation
          let contentString = '';
          if (post.content?.text) {
            try {
              const contentData = JSON.parse(post.content.text);
              contentString = contentData.content || '';
            } catch (e) {
              contentString = post.content.text || '';
            }
          } else {
            contentString = post.content?.content || post.content || '';
          }
          
          return {
            ...post,
            featured_image_url: blobUrl,
            read_time: Math.max(1, Math.ceil((contentString.split(' ').length || 0) / 200))
          };
        })
      );
      
      setPosts(postsWithBlobUrls);
      setTotalPages(Math.ceil(filteredPosts.length / pageSize));
      setTotalPosts(filteredPosts.length);
      setCurrentPage(page);
      
      // Set featured posts from the first few posts if this is the first page and no filters
      if (page === 1 && selectedCategory === 'all' && selectedType === 'all' && !searchQuery) {
        const featured: FeaturedPost[] = postsWithBlobUrls.slice(0, 3).map((post, index) => ({
          post,
          reason: index === 0 ? 'Latest Post' : index === 1 ? 'Popular' : 'Editor\'s Pick',
          priority: index
        }));
        setFeaturedPosts(featured);
      } else {
        setFeaturedPosts([]);
      }
    } catch (error) {
      console.error('Error loading posts:', error);
      setPosts([]);
    } finally {
      setLoading(false);
    }
  };

  // Load categories and authors
  const loadMetadata = async () => {
    try {
      // Mock categories for now
      const mockCategories = [
        { category_id: 'compliance', name: 'Compliance', description: 'Export control compliance articles', color: '#3B82F6' },
        { category_id: 'regulations', name: 'Regulations', description: 'Regulatory updates and changes', color: '#10B981' },
        { category_id: 'best-practices', name: 'Best Practices', description: 'Industry best practices', color: '#F59E0B' },
        { category_id: 'case-studies', name: 'Case Studies', description: 'Real-world examples', color: '#EF4444' },
        { category_id: 'technology', name: 'Technology', description: 'Technology and tools', color: '#8B5CF6' }
      ];
      
      // Mock authors for now  
      const mockAuthors = [
        { 
          author_id: 'admin', 
          user_email: 'admin@respectus.com', 
          full_name: 'RespectUs Team', 
          bio: 'Expert compliance professionals', 
          is_approved: true 
        }
      ];
      
      setCategories(mockCategories);
      setAuthors(mockAuthors);
    } catch (error) {
      console.error('Error loading metadata:', error);
    }
  };

  // Load categories
  const loadCategories = async () => {
    try {
      // Use the same mock categories as above
      const mockCategories = [
        { category_id: 'compliance', name: 'Compliance', description: 'Export control compliance articles', color: '#3B82F6' },
        { category_id: 'regulations', name: 'Regulations', description: 'Regulatory updates and changes', color: '#10B981' },
        { category_id: 'best-practices', name: 'Best Practices', description: 'Industry best practices', color: '#F59E0B' },
        { category_id: 'case-studies', name: 'Case Studies', description: 'Real-world examples', color: '#EF4444' },
        { category_id: 'technology', name: 'Technology', description: 'Technology and tools', color: '#8B5CF6' }
      ];
      setCategories(mockCategories);
    } catch (error) {
      console.error('Error loading categories:', error);
    }
  };

  // Update URL params when filters change
  const updateSearchParams = (updates: Record<string, string>) => {
    const newParams = new URLSearchParams(searchParams);
    
    Object.entries(updates).forEach(([key, value]) => {
      if (value && value !== 'all') {
        newParams.set(key, value);
      } else {
        newParams.delete(key);
      }
    });
    
    setSearchParams(newParams);
  };

  // Handle search
  const handleSearch = (query: string) => {
    setSearchQuery(query);
    updateSearchParams({ search: query });
    setCurrentPage(1);
  };

  // Handle category filter
  const handleCategoryChange = (category: string) => {
    setSelectedCategory(category);
    updateSearchParams({ category });
    setCurrentPage(1);
  };

  // Handle type filter
  const handleTypeChange = (type: string) => {
    setSelectedType(type as ContentType | 'all');
    updateSearchParams({ type });
    setCurrentPage(1);
  };

  // Handle page change
  const handlePageChange = (page: number) => {
    setCurrentPage(page);
    loadPosts(page);
  };

  // Navigate to post
  const navigateToPost = (post: BlogPost) => {
    // Navigate to dedicated blog article page for clean viewing
    navigate(`/blog-article?id=${post.id}`);
  };

  // Navigate back to blog list
  const navigateToList = () => {
    const newParams = new URLSearchParams(searchParams);
    newParams.delete('post');
    setSearchParams(newParams);
    setSelectedPost(null);
  };

  // Load data on mount and filter changes
  useEffect(() => {
    loadMetadata();
  }, []);

  useEffect(() => {
    if (postSlug) {
      loadPost(postSlug);
    } else {
      setSelectedPost(null);
      loadPosts(currentPage);
    }
  }, [postSlug, selectedCategory, selectedType, searchQuery, currentPage]);

  // Format post date
  const formatPostDate = (dateString: string) => {
    try {
      return format(new Date(dateString), 'MMM dd, yyyy');
    } catch {
      return 'Unknown date';
    }
  };

  // Get post excerpt
  const getPostExcerpt = (post: BlogPost) => {
    if (post.excerpt) return post.excerpt;
    
    // Get content string from the nested structure
    const contentString = post.content?.content || post.content || '';
    
    // Generate excerpt from content
    const text = contentString.replace(/<[^>]*>/g, ''); // Strip HTML
    return text.length > 150 ? text.substring(0, 150) + '...' : text;
  };

  // If viewing a specific post, render the post view
  if (postSlug && selectedPost) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
        <Navigation />
        
        {/* Post Header */}
        <div className="bg-slate-900/50 border-b border-slate-700/50">
          <div className="max-w-4xl mx-auto px-6 py-8">
            <Button 
              variant="ghost" 
              onClick={navigateToList}
              className="mb-6 text-slate-400 hover:text-white hover:bg-slate-800"
            >
              <ArrowRight className="w-4 h-4 mr-2 rotate-180" />
              Back to Blog
            </Button>
            
            <div className="space-y-4">
              <Badge className="bg-amber-500 text-slate-900">
                {selectedPost.content_type || 'Article'}
              </Badge>
              
              <h1 className="text-4xl md:text-5xl font-bold text-white leading-tight">
                {selectedPost.title}
              </h1>
              
              <div className="flex items-center space-x-6 text-slate-400">
                <div className="flex items-center space-x-2">
                  <User className="w-4 h-4" />
                  <span>{selectedPost.author_name || 'Anonymous'}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Calendar className="w-4 h-4" />
                  <span>{formatPostDate(selectedPost.published_at || selectedPost.created_at)}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Clock className="w-4 h-4" />
                  <span>{selectedPost.read_time} min read</span>
                </div>
                {selectedPost.view_count && (
                  <div className="flex items-center space-x-2">
                    <Eye className="w-4 h-4" />
                    <span>{selectedPost.view_count} views</span>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
        
        {/* Post Content */}
        <div className="max-w-4xl mx-auto px-6 py-8">
          {selectedPost.featured_image_url && (
            <div className="mb-8 rounded-lg overflow-hidden">
              <img 
                src={selectedPost.featured_image_url} 
                alt={selectedPost.title}
                className="w-full h-64 md:h-96 object-cover"
              />
            </div>
          )}
          
          <div className="prose prose-lg prose-invert max-w-none">
            <div dangerouslySetInnerHTML={{ __html: selectedPost.content }} />
          </div>
        </div>
        
        {/* Comments Section */}
        <div className="bg-slate-900/50 border-t border-slate-700/50">
          <div className="max-w-4xl mx-auto px-6 py-8">
            <BlogComments 
              contentId={selectedPost.id.toString()} 
              contentTitle={selectedPost.title}
            />
          </div>
        </div>
        
        <Footer />
      </div>
    );
  }

  // Loading state for specific post
  if (postSlug && postLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
        <Navigation />
        <div className="max-w-4xl mx-auto px-6 py-8">
          <Skeleton className="h-8 w-32 mb-6 bg-slate-800/50" />
          <Skeleton className="h-12 w-3/4 mb-4 bg-slate-800/50" />
          <Skeleton className="h-6 w-1/2 mb-8 bg-slate-800/50" />
          <Skeleton className="h-64 w-full mb-8 bg-slate-800/50" />
          <div className="space-y-4">
            <Skeleton className="h-4 w-full bg-slate-800/50" />
            <Skeleton className="h-4 w-full bg-slate-800/50" />
            <Skeleton className="h-4 w-3/4 bg-slate-800/50" />
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  // Main blog listing view
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      {/* Main Navigation */}
      <Navigation />
      
      {/* Hero Section */}
      <div className="relative text-white overflow-hidden min-h-[80vh]" style={{
        backgroundImage: 'linear-gradient(rgba(15, 23, 42, 0.95), rgba(30, 41, 59, 0.95)), url("https://images.unsplash.com/photo-1434030216411-0b793f4b4173?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80")',
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundRepeat: 'no-repeat'
      }}>
        {/* Content */}
        <div className="relative z-10 max-w-7xl mx-auto px-6 py-20 flex items-center min-h-[60vh]">
          <div className="text-center w-full">
            {/* Breadcrumbs */}
            <div className="mb-6">
              <nav className="flex justify-center items-center space-x-2 text-slate-300">
                <button 
                  onClick={() => navigate('/')}
                  className="hover:text-amber-400 transition-colors duration-200"
                >
                  Home
                </button>
                <span>/</span>
                <button 
                  onClick={() => {
                    setSearchQuery('');
                    setSelectedCategory('all');
                    setSelectedType('all');
                    setSearchParams(new URLSearchParams());
                  }}
                  className="hover:text-amber-400 transition-colors duration-200"
                >
                  Blog
                </button>
                {selectedCategory !== 'all' && (
                  <>
                    <span>/</span>
                    <span className="text-amber-400 font-medium">
                      {categories.find(c => c.category_id === selectedCategory)?.name || 'Category'}
                    </span>
                  </>
                )}
              </nav>
            </div>
            
            {/* Dynamic Title */}
            <h1 className="text-6xl md:text-7xl font-bold mb-6 leading-tight" style={{ fontFamily: 'Inter, sans-serif', fontWeight: '800' }}>
              {selectedCategory !== 'all' ? (
                <>
                  <span className="text-amber-400">{categories.find(c => c.category_id === selectedCategory)?.name || 'Category'}</span>
                  <br />
                  <span className="text-4xl md:text-5xl">Posts</span>
                </>
              ) : (
                <>RespectUs <span className="text-amber-400">Blog</span></>
              )}
            </h1>
            
            {/* Dynamic Description */}
            <p className="text-xl md:text-2xl text-slate-200 max-w-4xl mx-auto leading-relaxed mb-8" style={{ fontFamily: 'Inter, sans-serif', fontWeight: '400' }}>
              {selectedCategory !== 'all' ? (
                <>
                  Explore our {categories.find(c => c.category_id === selectedCategory)?.name?.toLowerCase() || 'category'} content.
                  {categories.find(c => c.category_id === selectedCategory)?.description && (
                    <> {categories.find(c => c.category_id === selectedCategory)?.description}</>
                  )}
                </>
              ) : searchQuery ? (
                <>Search results for "<span className="text-amber-400">{searchQuery}</span>" across all our content.</>
              ) : (
                <>
                  Insights, stories, and expertise from our team. 
                  Discover the latest in export control and trade compliance.
                </>
              )}
            </p>
            <div className="flex justify-center">
              <div className="w-24 h-1 bg-amber-400 rounded-full"></div>
            </div>
          </div>
        </div>
        
        {/* Subtab Navigation */}
        <div className="relative z-10 bg-slate-900/30 backdrop-blur-sm border-t border-slate-700/50">
          <div className="max-w-7xl mx-auto px-6">
            <div className="flex items-center space-x-8 py-4">
              <button className="text-slate-200 hover:text-amber-400 transition-colors duration-200 font-medium border-b-2 border-amber-400 pb-1">
                All Posts
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Featured Posts Section */}
        {featuredPosts.length > 0 && (
          <div className="mb-16">
            <div className="text-center mb-12">
              <h2 className="text-4xl md:text-5xl font-bold text-white mb-4" style={{ fontFamily: 'Inter, sans-serif', fontWeight: '700' }}>
                Featured Stories
              </h2>
              <div className="w-16 h-1 bg-amber-400 mx-auto rounded-full"></div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {featuredPosts.map((featured, index) => (
                <Card 
                  key={featured.post.id} 
                  className={`cursor-pointer hover:shadow-2xl transition-all duration-300 hover:-translate-y-1 bg-slate-900/50 border-slate-700/50 backdrop-blur-sm overflow-hidden group ${
                    index === 0 ? 'md:col-span-2 md:row-span-2' : ''
                  }`}
                  onClick={() => navigateToPost(featured.post)}
                >
                  {featured.post.featured_image_url && (
                    <div className={`relative ${
                      index === 0 ? 'h-64 md:h-80' : 'h-48'
                    }`}>
                      <img 
                        src={featured.post.featured_image_url} 
                        alt={featured.post.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-slate-900/80 to-transparent"></div>
                      <Badge className="absolute top-4 left-4 bg-amber-500 text-slate-900 font-semibold hover:bg-amber-400">
                        {featured.reason}
                      </Badge>
                    </div>
                  )}
                  <CardContent className={`p-6 ${
                    index === 0 ? 'space-y-4' : 'space-y-3'
                  }`}>
                    <h3 className={`font-bold text-white line-clamp-2 ${
                      index === 0 ? 'text-2xl md:text-3xl' : 'text-lg md:text-xl'
                    }`}>
                      {featured.post.title}
                    </h3>
                    <p className={`text-slate-200 line-clamp-3 ${
                      index === 0 ? 'text-base' : 'text-sm'
                    }`}>
                      {getPostExcerpt(featured.post)}
                    </p>
                    <div className="flex items-center justify-between text-sm text-slate-300 pt-2 border-t border-slate-700">
                      <div className="flex items-center space-x-4">
                        <span className="flex items-center">
                          <User className="w-4 h-4 mr-1" />
                          {featured.post.author_name || 'Anonymous'}
                        </span>
                        <span className="flex items-center">
                          <Calendar className="w-4 h-4 mr-1" />
                          {formatPostDate(featured.post.published_at || featured.post.created_at)}
                        </span>
                        <span className="flex items-center">
                          <Clock className="w-4 h-4 mr-1" />
                          {featured.post.read_time} min read
                        </span>
                      </div>
                      <ArrowRight className="w-4 h-4 text-amber-400" />
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}

        {/* Search and Filter Section */}
        <Card className="bg-slate-900/50 border-slate-700/50 backdrop-blur-sm mb-12">
          <CardContent className="p-6">
            <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
              {/* Search Input */}
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
                <Input
                  placeholder="Search articles..."
                  value={searchQuery}
                  onChange={(e) => handleSearchChange(e.target.value)}
                  className="pl-10 bg-slate-800/50 border-slate-600 text-white placeholder:text-slate-400 focus:border-amber-400"
                />
              </div>

              {/* Category Filter */}
              <Select value={selectedCategory} onValueChange={handleCategoryChange}>
                <SelectTrigger className="bg-slate-800/50 border-slate-600 text-white">
                  <SelectValue placeholder="Category" />
                </SelectTrigger>
                <SelectContent className="bg-slate-800 border-slate-600">
                  <SelectItem value="all" className="text-white hover:bg-slate-700">All Categories</SelectItem>
                  {categories.map(category => (
                    <SelectItem key={category.category_id} value={category.category_id} className="text-white hover:bg-slate-700">
                      {category.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              {/* Content Type Filter */}
              <Select value={selectedType} onValueChange={(value) => handleTypeChange(value as ContentType | 'all')}>
                <SelectTrigger className="bg-slate-800/50 border-slate-600 text-white">
                  <SelectValue placeholder="Content Type" />
                </SelectTrigger>
                <SelectContent className="bg-slate-800 border-slate-600">
                  <SelectItem value="all" className="text-white hover:bg-slate-700">All Types</SelectItem>
                  <SelectItem value="ARTICLE" className="text-white hover:bg-slate-700">Articles</SelectItem>
                  <SelectItem value="GUIDE" className="text-white hover:bg-slate-700">Guides</SelectItem>
                  <SelectItem value="NEWS" className="text-white hover:bg-slate-700">News</SelectItem>
                  <SelectItem value="CASE_STUDY" className="text-white hover:bg-slate-700">Case Studies</SelectItem>
                  <SelectItem value="REGULATION" className="text-white hover:bg-slate-700">Regulations</SelectItem>
                </SelectContent>
              </Select>

              {/* View Mode Toggle */}
              <div className="flex items-center space-x-2">
                <Button
                  variant={viewMode === 'grid' ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setViewMode('grid')}
                  className={viewMode === 'grid' ? 'bg-amber-500 hover:bg-amber-600 text-slate-900' : 'border-slate-600 text-slate-400 hover:text-white hover:bg-slate-700'}
                >
                  <Grid3x3 className="w-4 h-4" />
                </Button>
                <Button
                  variant={viewMode === 'list' ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setViewMode('list')}
                  className={viewMode === 'list' ? 'bg-amber-500 hover:bg-amber-600 text-slate-900' : 'border-slate-600 text-slate-400 hover:text-white hover:bg-slate-700'}
                >
                  <List className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Posts Grid/List */}
        {loading ? (
          <div className={`grid gap-8 ${
            viewMode === 'grid' 
              ? 'grid-cols-1 md:grid-cols-2 lg:grid-cols-3' 
              : 'grid-cols-1'
          }`}>
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <Card key={i} className="bg-slate-900/50 border-slate-700/50 backdrop-blur-sm">
                <div className="aspect-video">
                  <Skeleton className="w-full h-full bg-slate-800/50" />
                </div>
                <CardContent className="p-6 space-y-3">
                  <Skeleton className="h-6 w-3/4 bg-slate-800/50" />
                  <Skeleton className="h-4 w-full bg-slate-800/50" />
                  <Skeleton className="h-4 w-2/3 bg-slate-800/50" />
                  <div className="flex justify-between items-center pt-2">
                    <Skeleton className="h-4 w-24 bg-slate-800/50" />
                    <Skeleton className="h-4 w-16 bg-slate-800/50" />
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : posts.length === 0 ? (
          <Card className="bg-slate-900/50 border-slate-700/50 backdrop-blur-sm">
            <CardContent className="p-12 text-center">
              <FileText className="w-16 h-16 text-slate-400 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-white mb-2">No posts found</h3>
              <p className="text-slate-400 mb-6">
                {searchQuery || selectedCategory !== 'all' || selectedType !== 'all' 
                  ? 'Try adjusting your search criteria or filters.'
                  : 'No blog posts have been published yet.'}
              </p>
              {(searchQuery || selectedCategory !== 'all' || selectedType !== 'all') && (
                <Button 
                  onClick={() => {
                    setSearchQuery('');
                    setSelectedCategory('all');
                    setSelectedType('all');
                    setSearchParams(new URLSearchParams());
                  }}
                  className="bg-amber-500 hover:bg-amber-600 text-slate-900"
                >
                  Clear filters
                </Button>
              )}
            </CardContent>
          </Card>
        ) : (
          <>
            {viewMode === 'grid' ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {posts.map((post) => {
                  const blogPost = post as BlogPost;
                  return (
                    <Card 
                      key={post.id} 
                      className="cursor-pointer hover:shadow-2xl transition-all duration-300 hover:-translate-y-1 bg-slate-900/50 border-slate-700/50 backdrop-blur-sm overflow-hidden group"
                      onClick={() => navigateToPost(blogPost)}
                    >
                      {post.featured_image_url && (
                        <div className="aspect-video relative overflow-hidden">
                          <img 
                            src={post.featured_image_url} 
                            alt={post.title}
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                          />
                          <div className="absolute inset-0 bg-gradient-to-t from-slate-900/60 to-transparent" />
                          <Badge className="absolute top-4 left-4 bg-amber-500 text-slate-900 font-semibold">
                            {post.content_type}
                          </Badge>
                        </div>
                      )}
                      <CardContent className="p-6 space-y-3">
                        <h3 className="text-xl font-bold text-white line-clamp-2 group-hover:text-amber-400 transition-colors">
                          {post.title}
                        </h3>
                        <p className="text-slate-300 line-clamp-3 text-sm leading-relaxed">
                          {getPostExcerpt(post)}
                        </p>
                        <div className="flex items-center justify-between pt-2 border-t border-slate-700 text-xs text-slate-400">
                          <div className="flex items-center space-x-3">
                            <span className="flex items-center space-x-1">
                              <User className="w-3 h-3" />
                              <span>{post.author_name || 'Anonymous'}</span>
                            </span>
                            <span className="flex items-center space-x-1">
                              <Calendar className="w-3 h-3" />
                              <span>{formatPostDate(post.published_at || post.created_at)}</span>
                            </span>
                          </div>
                          <ArrowRight className="w-4 h-4 text-amber-400 group-hover:translate-x-1 transition-transform" />
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            ) : (
              <div className="space-y-6">
                {posts.map((post) => {
                  const blogPost = post as BlogPost;
                  return (
                    <Card 
                      key={post.id} 
                      className="cursor-pointer hover:shadow-xl transition-all duration-300 bg-slate-900/50 border-slate-700/50 backdrop-blur-sm group"
                      onClick={() => navigateToPost(blogPost)}
                    >
                      <CardContent className="p-6">
                        <div className="flex gap-6">
                          {post.featured_image_url && (
                            <div className="w-48 h-32 flex-shrink-0 rounded-lg overflow-hidden">
                              <img 
                                src={post.featured_image_url} 
                                alt={post.title}
                                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                              />
                            </div>
                          )}
                          <div className="flex-1 space-y-3">
                            <div className="flex items-start justify-between">
                              <h3 className="text-2xl font-bold text-white group-hover:text-amber-400 transition-colors line-clamp-2">
                                {post.title}
                              </h3>
                              <Badge className="ml-4 bg-amber-500 text-slate-900 font-semibold">
                                {post.content_type}
                              </Badge>
                            </div>
                            <p className="text-slate-300 line-clamp-2 leading-relaxed">
                              {getPostExcerpt(post)}
                            </p>
                            <div className="flex items-center justify-between pt-2 text-sm">
                              <div className="flex items-center space-x-4 text-slate-400">
                                <span className="flex items-center space-x-1">
                                  <User className="w-4 h-4" />
                                  <span>{post.author_name || 'Anonymous'}</span>
                                </span>
                                <span className="flex items-center space-x-1">
                                  <Calendar className="w-4 h-4" />
                                  <span>{formatPostDate(post.published_at || post.created_at)}</span>
                                </span>
                                <span className="flex items-center space-x-1">
                                  <Clock className="w-4 h-4" />
                                  <span>{blogPost.read_time || 5} min read</span>
                                </span>
                              </div>
                              <ArrowRight className="w-5 h-5 text-amber-400 group-hover:translate-x-1 transition-transform" />
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            )}
          </>
        )}

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex justify-center items-center space-x-2 mt-12">
            <Button
              variant="outline"
              size="sm"
              onClick={() => handlePageChange(currentPage - 1)}
              disabled={currentPage === 1}
              className="border-slate-600 text-slate-400 hover:bg-slate-700 hover:text-white disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <ChevronLeft className="w-4 h-4 mr-1" />
              Previous
            </Button>
            
            <div className="flex items-center space-x-1">
              {/* First page */}
              {currentPage > 3 && (
                <>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handlePageChange(1)}
                    className="border-slate-600 text-slate-400 hover:bg-slate-700 hover:text-white"
                  >
                    1
                  </Button>
                  {currentPage > 4 && (
                    <span className="px-2 py-1 text-slate-500">...</span>
                  )}
                </>
              )}
              
              {/* Current page and neighbors */}
              {[-2, -1, 0, 1, 2].map(offset => {
                const pageNum = currentPage + offset;
                
                if (pageNum < 1 || pageNum > totalPages) return null;
                
                return (
                  <Button
                    key={pageNum}
                    variant={currentPage === pageNum ? "default" : "outline"}
                    size="sm"
                    onClick={() => handlePageChange(pageNum)}
                    className={currentPage === pageNum 
                      ? "bg-amber-500 text-slate-900 hover:bg-amber-600" 
                      : "border-slate-600 text-slate-400 hover:bg-slate-700 hover:text-white"
                    }
                  >
                    {pageNum}
                  </Button>
                );
              })}
              
              {/* Last page */}
              {currentPage < totalPages - 2 && (
                <>
                  {currentPage < totalPages - 3 && (
                    <span className="px-2 py-1 text-slate-500">...</span>
                  )}
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handlePageChange(totalPages)}
                    className="border-slate-600 text-slate-400 hover:bg-slate-700 hover:text-white"
                  >
                    {totalPages}
                  </Button>
                </>
              )}
            </div>
            
            <Button
              variant="outline"
              size="sm"
              onClick={() => handlePageChange(currentPage + 1)}
              disabled={currentPage === totalPages}
              className="border-slate-600 text-slate-400 hover:bg-slate-700 hover:text-white disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Next
              <ChevronRight className="w-4 h-4 ml-1" />
            </Button>
          </div>
        )}
      </div>
      
      {/* Footer */}
      <Footer />
    </div>
  );
}
