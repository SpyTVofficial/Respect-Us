import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Search, User, Package, Globe, FileText, ExternalLink, CheckCircle, AlertTriangle, Clock } from 'lucide-react';
import { toast } from 'sonner';
import SanctionsSearchWidget from 'components/SanctionsSearchWidget';
import ProductClassificationWidget from 'components/ProductClassificationWidget';
import CountryRestrictionsWidget from 'components/CountryRestrictionsWidget';
import type { SanctionEntity } from 'components/SanctionsSearchWidget';
import type { ProductClassification } from 'components/ProductClassificationWidget';
import type { CountryRestriction } from 'components/CountryRestrictionsWidget';

export default function ComplianceLookups() {
  const [sanctionsOpen, setSanctionsOpen] = useState(false);
  const [productsOpen, setProductsOpen] = useState(false);
  const [countriesOpen, setCountriesOpen] = useState(false);
  
  const [selectedSanctions, setSelectedSanctions] = useState<SanctionEntity[]>([]);
  const [selectedProducts, setSelectedProducts] = useState<ProductClassification[]>([]);
  const [selectedCountries, setSelectedCountries] = useState<CountryRestriction[]>([]);
  
  const [searchQuery, setSearchQuery] = useState('');

  const handleSanctionsSelection = (sanctions: SanctionEntity[]) => {
    setSelectedSanctions(sanctions);
    toast.success(`Selected ${sanctions.length} sanctioned entit${sanctions.length === 1 ? 'y' : 'ies'}`);
  };

  const handleProductsSelection = (products: ProductClassification[]) => {
    setSelectedProducts(products);
    toast.success(`Selected ${products.length} product classification${products.length === 1 ? '' : 's'}`);
  };

  const handleCountriesSelection = (countries: CountryRestriction[]) => {
    setSelectedCountries(countries);
    toast.success(`Selected ${countries.length} country restriction${countries.length === 1 ? '' : 's'}`);
  };

  const clearAllSelections = () => {
    setSelectedSanctions([]);
    setSelectedProducts([]);
    setSelectedCountries([]);
    toast.success('All selections cleared');
  };

  const getTotalSelections = () => {
    return selectedSanctions.length + selectedProducts.length + selectedCountries.length;
  };

  const getRiskLevelColor = (riskLevel: string) => {
    switch (riskLevel) {
      case 'high':
      case 'critical':
        return 'bg-red-600 text-white';
      case 'medium':
        return 'bg-yellow-600 text-white';
      case 'low':
        return 'bg-green-600 text-white';
      case 'unrestricted':
        return 'bg-blue-600 text-white';
      default:
        return 'bg-gray-600 text-white';
    }
  };

  return (
    <div className="min-h-screen bg-gray-900 text-white p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2 flex items-center gap-3">
            <Search className="h-8 w-8 text-blue-400" />
            Compliance Lookup System
          </h1>
          <p className="text-gray-400 text-lg">
            Fast, modal-based searches for sanctions lists, product classifications, and country restrictions.
            Professional compliance software with backup access to full databases.
          </p>
        </div>

        {/* Search Widgets Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
          {/* Sanctions Search Widget */}
          <Card className="bg-gray-800 border-gray-700 hover:border-gray-600 transition-all">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-lg">
                <User className="h-5 w-5 text-red-400" />
                Sanctions Lists
              </CardTitle>
              <p className="text-sm text-gray-400">
                Search for sanctioned persons, entities, vessels, and aircraft across multiple jurisdictions
              </p>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex flex-col gap-2">
                <Button 
                  onClick={() => setSanctionsOpen(true)}
                  className="bg-red-600 hover:bg-red-700 w-full"
                >
                  <Search className="h-4 w-4 mr-2" />
                  Quick Search: Sanctions Lists
                </Button>
                <Button 
                  variant="outline"
                  size="sm"
                  className="border-gray-600 text-gray-300 hover:bg-gray-700 w-full"
                  onClick={() => window.open('/knowledge-base?category=sanctions', '_blank')}
                >
                  <ExternalLink className="h-4 w-4 mr-2" />
                  View Complete Database
                </Button>
              </div>
              
              {selectedSanctions.length > 0 && (
                <div className="mt-4 p-3 bg-gray-900 rounded border border-gray-600">
                  <div className="text-sm font-medium text-red-400 mb-2">
                    Selected Sanctions ({selectedSanctions.length})
                  </div>
                  <div className="space-y-2">
                    {selectedSanctions.slice(0, 3).map((sanction) => (
                      <div key={sanction.id} className="flex items-center justify-between">
                        <span className="text-xs text-gray-300 truncate">{sanction.name}</span>
                        <Badge className={getRiskLevelColor(sanction.risk_level)} variant="secondary">
                          {sanction.risk_level}
                        </Badge>
                      </div>
                    ))}
                    {selectedSanctions.length > 3 && (
                      <div className="text-xs text-gray-500 italic">
                        ... and {selectedSanctions.length - 3} more
                      </div>
                    )}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Product Classification Widget */}
          <Card className="bg-gray-800 border-gray-700 hover:border-gray-600 transition-all">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-lg">
                <Package className="h-5 w-5 text-yellow-400" />
                Product Classifications
              </CardTitle>
              <p className="text-sm text-gray-400">
                Search for dual-use items, restricted products, and export control classifications
              </p>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex flex-col gap-2">
                <Button 
                  onClick={() => setProductsOpen(true)}
                  className="bg-yellow-600 hover:bg-yellow-700 w-full"
                >
                  <Search className="h-4 w-4 mr-2" />
                  Quick Search: Classifications
                </Button>
                <Button 
                  variant="outline"
                  size="sm"
                  className="border-gray-600 text-gray-300 hover:bg-gray-700 w-full"
                  onClick={() => window.open('/knowledge-base?category=product-classification', '_blank')}
                >
                  <ExternalLink className="h-4 w-4 mr-2" />
                  Browse Classification Guide
                </Button>
              </div>
              
              {selectedProducts.length > 0 && (
                <div className="mt-4 p-3 bg-gray-900 rounded border border-gray-600">
                  <div className="text-sm font-medium text-yellow-400 mb-2">
                    Selected Products ({selectedProducts.length})
                  </div>
                  <div className="space-y-2">
                    {selectedProducts.slice(0, 3).map((product) => (
                      <div key={product.id} className="flex items-center justify-between">
                        <span className="text-xs text-gray-300 truncate">{product.product_name}</span>
                        <div className="flex gap-1">
                          <Badge variant="outline" className="text-xs border-yellow-600 text-yellow-300">
                            {product.classification_code}
                          </Badge>
                          <Badge className={getRiskLevelColor(product.risk_level)} variant="secondary">
                            {product.risk_level}
                          </Badge>
                        </div>
                      </div>
                    ))}
                    {selectedProducts.length > 3 && (
                      <div className="text-xs text-gray-500 italic">
                        ... and {selectedProducts.length - 3} more
                      </div>
                    )}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Country Restrictions Widget */}
          <Card className="bg-gray-800 border-gray-700 hover:border-gray-600 transition-all">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-lg">
                <Globe className="h-5 w-5 text-blue-400" />
                Country Restrictions
              </CardTitle>
              <p className="text-sm text-gray-400">
                Search for embargoes, sanctions, and geographic compliance restrictions
              </p>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex flex-col gap-2">
                <Button 
                  onClick={() => setCountriesOpen(true)}
                  className="bg-blue-600 hover:bg-blue-700 w-full"
                >
                  <Search className="h-4 w-4 mr-2" />
                  Quick Search: Restrictions
                </Button>
                <Button 
                  variant="outline"
                  size="sm"
                  className="border-gray-600 text-gray-300 hover:bg-gray-700 w-full"
                  onClick={() => window.open('/knowledge-base?category=country-restrictions', '_blank')}
                >
                  <ExternalLink className="h-4 w-4 mr-2" />
                  View Restricted Items Catalog
                </Button>
              </div>
              
              {selectedCountries.length > 0 && (
                <div className="mt-4 p-3 bg-gray-900 rounded border border-gray-600">
                  <div className="text-sm font-medium text-blue-400 mb-2">
                    Selected Countries ({selectedCountries.length})
                  </div>
                  <div className="space-y-2">
                    {selectedCountries.slice(0, 3).map((country) => (
                      <div key={country.id} className="flex items-center justify-between">
                        <span className="text-xs text-gray-300 truncate">
                          {country.country_name} ({country.country_code})
                        </span>
                        <Badge className={getRiskLevelColor(country.risk_level)} variant="secondary">
                          {country.risk_level}
                        </Badge>
                      </div>
                    ))}
                    {selectedCountries.length > 3 && (
                      <div className="text-xs text-gray-500 italic">
                        ... and {selectedCountries.length - 3} more
                      </div>
                    )}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Selection Summary */}
        {getTotalSelections() > 0 && (
          <Card className="bg-gray-800 border-gray-700 mb-6">
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-5 w-5 text-green-400" />
                  Selection Summary
                </div>
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={clearAllSelections}
                  className="border-gray-600 text-gray-300 hover:bg-gray-700"
                >
                  Clear All
                </Button>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="text-center">
                  <div className="text-2xl font-bold text-red-400">{selectedSanctions.length}</div>
                  <div className="text-sm text-gray-400">Sanctioned Entities</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-yellow-400">{selectedProducts.length}</div>
                  <div className="text-sm text-gray-400">Product Classifications</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-400">{selectedCountries.length}</div>
                  <div className="text-sm text-gray-400">Country Restrictions</div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Features Overview */}
        <Card className="bg-gray-800 border-gray-700">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileText className="h-5 w-5 text-purple-400" />
              System Features
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="text-center">
                <div className="w-12 h-12 bg-blue-600 rounded-lg flex items-center justify-center mx-auto mb-3">
                  <Search className="h-6 w-6 text-white" />
                </div>
                <h4 className="font-medium mb-2">Fast Search</h4>
                <p className="text-sm text-gray-400">Sub-200ms search performance with real-time results</p>
              </div>
              
              <div className="text-center">
                <div className="w-12 h-12 bg-green-600 rounded-lg flex items-center justify-center mx-auto mb-3">
                  <CheckCircle className="h-6 w-6 text-white" />
                </div>
                <h4 className="font-medium mb-2">Modal Interface</h4>
                <p className="text-sm text-gray-400">Clean modal overlays with selection and confirmation</p>
              </div>
              
              <div className="text-center">
                <div className="w-12 h-12 bg-purple-600 rounded-lg flex items-center justify-center mx-auto mb-3">
                  <ExternalLink className="h-6 w-6 text-white" />
                </div>
                <h4 className="font-medium mb-2">Full Database Access</h4>
                <p className="text-sm text-gray-400">Backup links to comprehensive databases</p>
              </div>
              
              <div className="text-center">
                <div className="w-12 h-12 bg-orange-600 rounded-lg flex items-center justify-center mx-auto mb-3">
                  <Clock className="h-6 w-6 text-white" />
                </div>
                <h4 className="font-medium mb-2">Audit Trail</h4>
                <p className="text-sm text-gray-400">Complete logging for compliance requirements</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Search Widget Modals */}
      <SanctionsSearchWidget
        open={sanctionsOpen}
        onClose={() => setSanctionsOpen(false)}
        onSelectionConfirmed={handleSanctionsSelection}
        initialQuery={searchQuery}
        multiSelect={true}
      />
      
      <ProductClassificationWidget
        open={productsOpen}
        onClose={() => setProductsOpen(false)}
        onSelectionConfirmed={handleProductsSelection}
        initialQuery={searchQuery}
        multiSelect={true}
      />
      
      <CountryRestrictionsWidget
        open={countriesOpen}
        onClose={() => setCountriesOpen(false)}
        onSelectionConfirmed={handleCountriesSelection}
        initialQuery={searchQuery}
        multiSelect={true}
      />
    </div>
  );
}
