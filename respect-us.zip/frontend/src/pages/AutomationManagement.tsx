import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { useUserGuardContext } from 'app/auth';
import brain from 'brain';
import { toast } from 'sonner';
import {
  Rss,
  Plus,
  Settings,
  Activity,
  Clock,
  CheckCircle,
  AlertCircle,
  Globe,
  FileText,
  RefreshCw,
  BarChart3,
  TrendingUp,
  Link2,
  GitBranch,
  History,
  Play,
  Pause,
  Eye,
  ChevronRight,
  Calendar,
  Building
} from 'lucide-react';
import type {
  AutomationStats,
  ContentFeed,
  ContentFeedCreate,
  DocumentVersion,
  DocumentReference
} from '../brain/data-contracts';

const AutomationManagement = () => {
  const { user } = useUserGuardContext();
  const [activeTab, setActiveTab] = useState('overview');
  const [stats, setStats] = useState<AutomationStats | null>(null);
  const [contentFeeds, setContentFeeds] = useState<ContentFeed[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [showCreateFeed, setShowCreateFeed] = useState(false);
  const [newFeed, setNewFeed] = useState<ContentFeedCreate>({
    name: '',
    source_url: '',
    feed_type: 'rss',
    jurisdiction: '',
    regulation_type: '',
    fetch_frequency_hours: 24
  });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      setIsLoading(true);
      
      // Load automation stats
      const statsResponse = await brain.get_automation_stats();
      const statsData = await statsResponse.json();
      setStats(statsData);
      
      // Load content feeds
      const feedsResponse = await brain.list_content_feeds({ active_only: false });
      const feedsData = await feedsResponse.json();
      setContentFeeds(feedsData || []);
      
    } catch (error) {
      console.error('Error loading automation data:', error);
      toast.error('Failed to load automation data');
    } finally {
      setIsLoading(false);
    }
  };

  const handleCreateFeed = async () => {
    try {
      if (!newFeed.name || !newFeed.source_url) {
        toast.error('Please fill in all required fields');
        return;
      }

      const response = await brain.create_content_feed(newFeed);
      const data = await response.json();
      
      if (response.status === 200 || response.status === 201) {
        toast.success('Content feed created successfully');
        setShowCreateFeed(false);
        setNewFeed({
          name: '',
          source_url: '',
          feed_type: 'rss',
          jurisdiction: '',
          regulation_type: '',
          fetch_frequency_hours: 24
        });
        loadData();
      } else {
        toast.error('Failed to create content feed');
      }
    } catch (error) {
      console.error('Error creating feed:', error);
      toast.error('Failed to create content feed');
    }
  };

  const handleTriggerFeedCheck = async (feedId: number) => {
    try {
      const response = await brain.trigger_feed_check({ feedId });
      if (response.status === 200) {
        toast.success('Feed check triggered successfully');
        loadData();
      } else {
        toast.error('Failed to trigger feed check');
      }
    } catch (error) {
      console.error('Error triggering feed check:', error);
      toast.error('Failed to trigger feed check');
    }
  };

  const StatCard = ({ title, value, icon: Icon, trend, color = 'blue' }: {
    title: string;
    value: string | number;
    icon: any;
    trend?: string;
    color?: string;
  }) => (
    <Card className="bg-gray-900/50 border-gray-700">
      <CardContent className="p-6">
        <div className="flex items-center space-x-4">
          <div className={`p-3 rounded-lg bg-${color}-600/20`}>
            <Icon className={`h-6 w-6 text-${color}-400`} />
          </div>
          <div className="flex-1">
            <div className="text-2xl font-bold text-white">{value}</div>
            <div className="text-sm text-gray-400">{title}</div>
            {trend && (
              <div className="text-xs text-green-400 mt-1">{trend}</div>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );

  const FeedCard = ({ feed }: { feed: ContentFeed }) => (
    <Card className="bg-gray-900/50 border-gray-700 hover:border-gray-600 transition-colors">
      <CardContent className="p-6">
        <div className="flex items-start justify-between mb-4">
          <div className="flex-1">
            <div className="flex items-center space-x-3 mb-2">
              <h3 className="text-lg font-semibold text-white">{feed.name}</h3>
              <Badge 
                variant={feed.active ? 'default' : 'secondary'}
                className={feed.active ? 'bg-green-600' : 'bg-gray-600'}
              >
                {feed.active ? 'Active' : 'Inactive'}
              </Badge>
            </div>
            <div className="text-sm text-gray-400 space-y-1">
              <div className="flex items-center space-x-2">
                <Globe className="h-3 w-3" />
                <span>{feed.source_url}</span>
              </div>
              {feed.jurisdiction && (
                <div className="flex items-center space-x-2">
                  <Building className="h-3 w-3" />
                  <span>{feed.jurisdiction}</span>
                </div>
              )}
              {feed.regulation_type && (
                <div className="flex items-center space-x-2">
                  <FileText className="h-3 w-3" />
                  <span>{feed.regulation_type}</span>
                </div>
              )}
              <div className="flex items-center space-x-2">
                <Clock className="h-3 w-3" />
                <span>Every {feed.fetch_frequency_hours} hours</span>
              </div>
              {feed.last_checked && (
                <div className="flex items-center space-x-2">
                  <Calendar className="h-3 w-3" />
                  <span>Last checked: {new Date(feed.last_checked).toLocaleString()}</span>
                </div>
              )}
            </div>
          </div>
          <div className="flex space-x-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => handleTriggerFeedCheck(feed.id)}
              className="border-gray-600 text-gray-300 hover:bg-gray-800"
            >
              <Play className="h-4 w-4 mr-1" />
              Check Now
            </Button>
            <Button
              variant="outline"
              size="sm"
              className="border-gray-600 text-gray-300 hover:bg-gray-800"
            >
              <Settings className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );

  if (isLoading) {
    return (
      <div className="min-h-screen bg-black p-6">
        <div className="max-w-7xl mx-auto">
          <div className="text-center py-12">
            <RefreshCw className="h-8 w-8 animate-spin mx-auto mb-4 text-gray-400" />
            <p className="text-gray-400">Loading automation data...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-white mb-2">Automation Management</h1>
            <p className="text-gray-400">Manage automated content feeds, version control, and regulatory monitoring</p>
          </div>
          <Button
            onClick={() => setShowCreateFeed(true)}
            className="bg-blue-600 hover:bg-blue-700"
          >
            <Plus className="h-4 w-4 mr-2" />
            Add Content Feed
          </Button>
        </div>

        {/* Overview Stats */}
        {stats && (
          <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
            <StatCard
              title="Active Feeds"
              value={stats.active_feeds}
              icon={Rss}
              color="blue"
            />
            <StatCard
              title="Pending Items"
              value={stats.pending_items}
              icon={Clock}
              color="amber"
            />
            <StatCard
              title="Processed Today"
              value={stats.processed_today}
              icon={CheckCircle}
              color="green"
            />
            <StatCard
              title="Document Versions"
              value={stats.total_versions}
              icon={GitBranch}
              color="purple"
            />
            <StatCard
              title="Recent References"
              value={stats.recent_references}
              icon={Link2}
              color="cyan"
            />
          </div>
        )}

        {/* Main Content Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="bg-gray-900/50 border-gray-700">
            <TabsTrigger value="overview" className="data-[state=active]:bg-gray-800">
              <Activity className="h-4 w-4 mr-2" />
              Overview
            </TabsTrigger>
            <TabsTrigger value="feeds" className="data-[state=active]:bg-gray-800">
              <Rss className="h-4 w-4 mr-2" />
              Content Feeds
            </TabsTrigger>
            <TabsTrigger value="versions" className="data-[state=active]:bg-gray-800">
              <GitBranch className="h-4 w-4 mr-2" />
              Version Control
            </TabsTrigger>
            <TabsTrigger value="references" className="data-[state=active]:bg-gray-800">
              <Link2 className="h-4 w-4 mr-2" />
              Cross-References
            </TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            <Card className="bg-gray-900/50 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center">
                  <BarChart3 className="h-5 w-5 mr-2" />
                  System Overview
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold text-white">Automation Status</h3>
                    <div className="space-y-3">
                      <div className="flex items-center justify-between p-3 bg-gray-800/50 rounded-lg">
                        <span className="text-gray-300">Content Monitoring</span>
                        <Badge className="bg-green-600">Active</Badge>
                      </div>
                      <div className="flex items-center justify-between p-3 bg-gray-800/50 rounded-lg">
                        <span className="text-gray-300">Version Tracking</span>
                        <Badge className="bg-green-600">Active</Badge>
                      </div>
                      <div className="flex items-center justify-between p-3 bg-gray-800/50 rounded-lg">
                        <span className="text-gray-300">Reference Linking</span>
                        <Badge className="bg-green-600">Active</Badge>
                      </div>
                    </div>
                  </div>
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold text-white">Recent Activity</h3>
                    <div className="space-y-3">
                      <div className="flex items-center space-x-3 p-3 bg-gray-800/50 rounded-lg">
                        <CheckCircle className="h-4 w-4 text-green-400" />
                        <span className="text-gray-300 text-sm">Feed check completed</span>
                        <span className="text-xs text-gray-500 ml-auto">2 min ago</span>
                      </div>
                      <div className="flex items-center space-x-3 p-3 bg-gray-800/50 rounded-lg">
                        <FileText className="h-4 w-4 text-blue-400" />
                        <span className="text-gray-300 text-sm">New document detected</span>
                        <span className="text-xs text-gray-500 ml-auto">15 min ago</span>
                      </div>
                      <div className="flex items-center space-x-3 p-3 bg-gray-800/50 rounded-lg">
                        <Link2 className="h-4 w-4 text-purple-400" />
                        <span className="text-gray-300 text-sm">Cross-reference created</span>
                        <span className="text-xs text-gray-500 ml-auto">1 hour ago</span>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="feeds" className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-semibold text-white">Content Feeds</h2>
              <Button
                onClick={() => setShowCreateFeed(true)}
                variant="outline"
                className="border-gray-600 text-gray-300 hover:bg-gray-800"
              >
                <Plus className="h-4 w-4 mr-2" />
                Add Feed
              </Button>
            </div>
            
            <div className="grid gap-4">
              {contentFeeds.length === 0 ? (
                <Card className="bg-gray-900/50 border-gray-700">
                  <CardContent className="p-12 text-center">
                    <Rss className="h-12 w-12 mx-auto mb-4 text-gray-400" />
                    <p className="text-gray-400">No content feeds configured yet</p>
                    <Button
                      onClick={() => setShowCreateFeed(true)}
                      className="mt-4 bg-blue-600 hover:bg-blue-700"
                    >
                      Create Your First Feed
                    </Button>
                  </CardContent>
                </Card>
              ) : (
                contentFeeds.map(feed => (
                  <FeedCard key={feed.id} feed={feed} />
                ))
              )}
            </div>
          </TabsContent>

          <TabsContent value="versions" className="space-y-6">
            <Card className="bg-gray-900/50 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center">
                  <GitBranch className="h-5 w-5 mr-2" />
                  Document Version Control
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center py-8">
                  <History className="h-12 w-12 mx-auto mb-4 text-gray-400" />
                  <p className="text-gray-400 mb-4">Version control features are integrated into document management</p>
                  <Button 
                    variant="outline"
                    className="border-gray-600 text-gray-300 hover:bg-gray-800"
                    onClick={() => window.location.href = '/knowledge-base'}
                  >
                    Go to Knowledge Base
                    <ChevronRight className="h-4 w-4 ml-2" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="references" className="space-y-6">
            <Card className="bg-gray-900/50 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center">
                  <Link2 className="h-5 w-5 mr-2" />
                  Cross-Reference Management
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center py-8">
                  <Link2 className="h-12 w-12 mx-auto mb-4 text-gray-400" />
                  <p className="text-gray-400 mb-4">Cross-reference features are integrated into document viewing</p>
                  <Button 
                    variant="outline"
                    className="border-gray-600 text-gray-300 hover:bg-gray-800"
                    onClick={() => window.location.href = '/document-comparison'}
                  >
                    Go to Document Comparison
                    <ChevronRight className="h-4 w-4 ml-2" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Create Feed Dialog */}
        <Dialog open={showCreateFeed} onOpenChange={setShowCreateFeed}>
          <DialogContent className="bg-gray-900 border-gray-700 text-white max-w-2xl">
            <DialogHeader>
              <DialogTitle>Create Content Feed</DialogTitle>
            </DialogHeader>
            <div className="space-y-6">
              <div className="grid grid-cols-1 gap-4">
                <div>
                  <Label htmlFor="feed-name" className="text-gray-300">Feed Name *</Label>
                  <Input
                    id="feed-name"
                    value={newFeed.name}
                    onChange={(e) => setNewFeed(prev => ({ ...prev, name: e.target.value }))}
                    placeholder="e.g., EU Export Control Updates"
                    className="bg-gray-800 border-gray-600 text-white mt-1"
                  />
                </div>
                <div>
                  <Label htmlFor="source-url" className="text-gray-300">Source URL *</Label>
                  <Input
                    id="source-url"
                    value={newFeed.source_url}
                    onChange={(e) => setNewFeed(prev => ({ ...prev, source_url: e.target.value }))}
                    placeholder="https://example.com/regulations/feed.xml"
                    className="bg-gray-800 border-gray-600 text-white mt-1"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="feed-type" className="text-gray-300">Feed Type</Label>
                    <Select 
                      value={newFeed.feed_type} 
                      onValueChange={(value) => setNewFeed(prev => ({ ...prev, feed_type: value }))}
                    >
                      <SelectTrigger className="bg-gray-800 border-gray-600 text-white mt-1">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="rss">RSS Feed</SelectItem>
                        <SelectItem value="api">API Endpoint</SelectItem>
                        <SelectItem value="manual">Manual Upload</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="frequency" className="text-gray-300">Check Frequency (hours)</Label>
                    <Input
                      id="frequency"
                      type="number"
                      value={newFeed.fetch_frequency_hours}
                      onChange={(e) => setNewFeed(prev => ({ ...prev, fetch_frequency_hours: parseInt(e.target.value) || 24 }))}
                      min="1"
                      max="168"
                      className="bg-gray-800 border-gray-600 text-white mt-1"
                    />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="jurisdiction" className="text-gray-300">Jurisdiction</Label>
                    <Input
                      id="jurisdiction"
                      value={newFeed.jurisdiction || ''}
                      onChange={(e) => setNewFeed(prev => ({ ...prev, jurisdiction: e.target.value }))}
                      placeholder="e.g., EU, US, UK"
                      className="bg-gray-800 border-gray-600 text-white mt-1"
                    />
                  </div>
                  <div>
                    <Label htmlFor="regulation-type" className="text-gray-300">Regulation Type</Label>
                    <Input
                      id="regulation-type"
                      value={newFeed.regulation_type || ''}
                      onChange={(e) => setNewFeed(prev => ({ ...prev, regulation_type: e.target.value }))}
                      placeholder="e.g., Export Control, Sanctions"
                      className="bg-gray-800 border-gray-600 text-white mt-1"
                    />
                  </div>
                </div>
              </div>
              <div className="flex space-x-3 pt-4">
                <Button
                  onClick={handleCreateFeed}
                  className="bg-blue-600 hover:bg-blue-700 flex-1"
                >
                  Create Feed
                </Button>
                <Button
                  variant="outline"
                  onClick={() => setShowCreateFeed(false)}
                  className="border-gray-600 text-gray-300 hover:bg-gray-800"
                >
                  Cancel
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
};

export default AutomationManagement;
