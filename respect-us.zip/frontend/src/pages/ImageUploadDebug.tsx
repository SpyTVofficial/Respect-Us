import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import brain from 'brain';
import { toast } from 'sonner';

const ImageUploadDebug = () => {
  const [file, setFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);
  const [result, setResult] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile) {
      setFile(selectedFile);
      setResult(null);
      setError(null);
      console.log('File selected:', {
        name: selectedFile.name,
        type: selectedFile.type,
        size: selectedFile.size
      });
    }
  };

  const testUpload = async () => {
    if (!file) {
      toast.error('Please select a file first');
      return;
    }

    setUploading(true);
    setError(null);
    setResult(null);

    try {
      console.log('Starting upload test with file:', file);
      console.log('File details:', {
        name: file.name,
        type: file.type,
        size: file.size,
        lastModified: file.lastModified
      });

      // Test the upload
      const response = await brain.upload_image({ file });
      
      console.log('Response status:', response.status);
      console.log('Response ok:', response.ok);
      
      const responseText = await response.text();
      console.log('Raw response:', responseText);
      
      let responseData;
      try {
        responseData = JSON.parse(responseText);
      } catch (e) {
        responseData = { raw: responseText };
      }
      
      if (response.ok) {
        setResult(responseData);
        toast.success('Upload successful!');
      } else {
        setError(`Upload failed: ${response.status} - ${JSON.stringify(responseData)}`);
        toast.error('Upload failed');
      }
    } catch (error) {
      console.error('Upload error:', error);
      setError(`Error: ${error instanceof Error ? error.message : 'Unknown error'}`);
      toast.error('Upload error');
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="p-8 max-w-2xl mx-auto">
      <h1 className="text-2xl font-bold mb-6">Image Upload Debug Test</h1>
      
      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium mb-2">Select Image File:</label>
          <Input
            type="file"
            accept="image/*"
            onChange={handleFileSelect}
            className="w-full"
          />
        </div>
        
        {file && (
          <div className="p-4 bg-gray-100 dark:bg-gray-800 rounded">
            <h3 className="font-medium">Selected File:</h3>
            <p>Name: {file.name}</p>
            <p>Type: {file.type}</p>
            <p>Size: {(file.size / 1024).toFixed(2)} KB</p>
          </div>
        )}
        
        <Button 
          onClick={testUpload} 
          disabled={!file || uploading}
          className="w-full"
        >
          {uploading ? 'Uploading...' : 'Test Upload'}
        </Button>
        
        {error && (
          <div className="p-4 bg-red-100 dark:bg-red-900/20 text-red-700 dark:text-red-300 rounded">
            <h3 className="font-medium">Error:</h3>
            <pre className="text-sm whitespace-pre-wrap">{error}</pre>
          </div>
        )}
        
        {result && (
          <div className="p-4 bg-green-100 dark:bg-green-900/20 text-green-700 dark:text-green-300 rounded">
            <h3 className="font-medium">Success:</h3>
            <pre className="text-sm whitespace-pre-wrap">{JSON.stringify(result, null, 2)}</pre>
            {result.image_url && (
              <div className="mt-4">
                <img src={result.image_url} alt="Uploaded" className="max-w-xs max-h-48 object-contain" />
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default ImageUploadDebug;
