import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useUserGuardContext } from 'app/auth';
import brain from 'brain';
import { toast } from 'sonner';
import { useDebounce } from 'utils/useDebounce';
import { APP_BASE_PATH } from 'app';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  FileText,
  Search,
  Filter,
  X,
  Download,
  ExternalLink,
  Star,
  MessageSquare,
  PenTool,
  Globe,
  Bookmark,
  BookmarkCheck,
  Upload,
  Plus,
  ChevronRight,
  AlertTriangle,
  Users,
  Package,
  Calendar,
  Eye,
  ChevronDown,
  Building2,
  Mail,
  Target,
  TrendingUp,
  BarChart3,
  Shield,
  Clock,
} from 'lucide-react';
import type {
  Document,
  DocumentListResponse,
  DocumentSearchSuggestionsResponse,
  BlogDocumentResponse,
  BlogDocumentListResponse,
  CountryListResponse,
  SanctionListResponse,
  ChatMessage,
  ChatResponse,
  BodySubmitDocument,
  BodySubmitCaseStudy
} from 'types';
import DocumentUploadDialog from 'components/DocumentUploadDialog';
import CommunityChat from 'components/CommunityChat';
import { SavedArticlesView } from 'components/SavedArticlesView';
import { SaveArticleDialog } from 'components/SaveArticleDialog';
import Navigation from 'components/Navigation';

// Add MetadataOptions interface definition
interface MetadataOptions {
  jurisdiction: DocumentMetadataOption[];
  type: DocumentMetadataOption[];
  subject: DocumentMetadataOption[];
}

const KnowledgeBase: React.FC = () => {
  const { user } = useUserGuardContext();
  const navigate = useNavigate();
  const [currentView, setCurrentView] = useState<'overview' | 'repository' | 'saved' | 'community' | 'blog' | 'countries' | 'contributions'>('overview');
  
  // Document state
  const [documents, setDocuments] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [filteredDocuments, setFilteredDocuments] = useState<any[]>([]);
  const debouncedSearchQuery = useDebounce(searchTerm, 300);
  
  // Blog state
  const [blogDocuments, setBlogDocuments] = useState<Document[]>([]);
  const [blogTotalCount, setBlogTotalCount] = useState(0);
  const [blogLoading, setBlogLoading] = useState(false);
  const [blogSearchQuery, setBlogSearchQuery] = useState('');
  const debouncedBlogSearchQuery = useDebounce(blogSearchQuery, 300);
  
  // Enhanced features state
  const [featuredArticles, setFeaturedArticles] = useState<Document[]>([]);
  const [communityMessages, setCommunityMessages] = useState<any[]>([]);
  const [countriesData, setCountriesData] = useState<any[]>([]);
  const [savedArticles, setSavedArticles] = useState<any[]>([]);
  const [userContributions, setUserContributions] = useState<any[]>([]);
  const [savedDocumentIds, setSavedDocumentIds] = useState<Set<string>>(new Set());
  const [savingStates, setSavingStates] = useState<Record<string, boolean>>({});
  
  // Pagination and display state
  const [showAllDocuments, setShowAllDocuments] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const documentsPerPage = 10; // Reduced from 20 to show pagination working

  // Metadata options
  const [metadataOptions, setMetadataOptions] = useState<MetadataOptions[]>([]);
  const [savedSearches, setSavedSearches] = useState<any[]>([]);
  const [loadingOptions, setLoadingOptions] = useState(false);

  // Dialog and view state
  const [showAdvancedFilters, setShowAdvancedFilters] = useState(false);
  const [showNoteDialog, setShowNoteDialog] = useState(false);
  const [showTranslationDialog, setShowTranslationDialog] = useState(false);
  const [noteText, setNoteText] = useState('');
  const [selectedDocumentForNote, setSelectedDocumentForNote] = useState<Document | null>(null);
  const [viewBlogDetails, setViewBlogDetails] = useState(false);
  const [selectedBlogPost, setSelectedBlogPost] = useState<Document | null>(null);
  
  // SaveArticleDialog state
  const [showSaveArticleDialog, setShowSaveArticleDialog] = useState(false);
  const [selectedDocumentForSave, setSelectedDocumentForSave] = useState<any>(null);

  // Preload metadata options
  useEffect(() => {
    const loadMetadataOptions = async () => {
      try {
        setLoadingOptions(true);
        const response = await brain.get_all_document_metadata_options();
        const data = await response.json();
        setMetadataOptions(data);
      } catch (error) {
        console.error('Error loading metadata options:', error);
      } finally {
        setLoadingOptions(false);
      }
    };

    loadMetadataOptions();
  }, []);

  // Load documents
  const loadDocuments = async () => {
    try {
      setLoading(true);
      const queryParams: any = {
        per_page: 100 // Load more documents to enable "Display All" functionality
      };
      
      if (debouncedSearchQuery) queryParams.search = debouncedSearchQuery;
      
      const response = await brain.list_documents(queryParams);
      const data = await response.json();
      setDocuments(data.documents || []);

      console.log('🔍 Documents Debug:', {
        loading: false,
        documentsLength: data.documents?.length || 0,
        documents: data.documents || []
      });
    } catch (error) {
      console.error('Error loading documents:', error);
      setDocuments([]);
    } finally {
      setLoading(false);
    }
  };

  // Load blog documents
  const loadBlogDocuments = async () => {
    try {
      setBlogLoading(true);
      console.log('Loading blog documents with params:', {});
      // For now, using empty array since we don't have blog API yet
      setBlogDocuments([]);
      console.log('Blog documents loaded:', []);
    } catch (error) {
      console.error('Error loading blog documents:', error);
    } finally {
      setBlogLoading(false);
    }
  };

  // Load countries data
  const loadCountriesData = async () => {
    try {
      const response = await brain.list_countries();
      const data = await response.json();
      setCountriesData(data.countries || data);
    } catch (error) {
      console.error('Error loading countries data:', error);
    }
  };

  // Load saved articles
  const loadSavedArticles = async () => {
    try {
      const response = await brain.get_saved_articles();
      const data = await response.json();
      setSavedArticles(data);
    } catch (error) {
      console.error('Error loading saved articles:', error);
    }
  };

  // Load saved document IDs for quick lookup
  const loadSavedDocumentIds = async () => {
    try {
      const response = await brain.get_saved_articles();
      const data = await response.json();
      const ids = new Set(data.map((article: any) => article.document_id));
      setSavedDocumentIds(ids);
    } catch (error) {
      console.error('Error loading saved document IDs:', error);
    }
  };

  // Load documents and other data
  useEffect(() => {
    loadDocuments();
    loadBlogDocuments();
    loadCountriesData();
    loadSavedArticles();
    loadSavedDocumentIds();
  }, []);

  const totalCount = documents.length;

  // Calculate documents to display based on mode
  const getDocumentsToDisplay = () => {
    if (!showAllDocuments) {
      // Show last 20 documents uploaded (most recent first)
      return filteredDocuments.slice(0, 20);
    } else {
      // Show paginated view
      const startIndex = (currentPage - 1) * documentsPerPage;
      const endIndex = startIndex + documentsPerPage;
      return filteredDocuments.slice(startIndex, endIndex);
    }
  };

  const documentsToDisplay = getDocumentsToDisplay();
  const totalPages = Math.ceil(filteredDocuments.length / documentsPerPage);

  // Reset to first page when switching modes or changing filters
  useEffect(() => {
    setCurrentPage(1);
  }, [showAllDocuments, searchTerm]); // Removed selectedDocumentType since it's not defined

  // Load documents and saved articles on mount and when search changes
  useEffect(() => {
    loadDocuments();
    loadSavedDocumentIds();
  }, [debouncedSearchQuery]);

  const handleDisplayAllClick = () => {
    setShowAllDocuments(true);
    setCurrentPage(1);
  };

  const handleShowRecentClick = () => {
    setShowAllDocuments(false);
    setCurrentPage(1);
  };

  // Handle card clicks to navigate to tabs with auto-scroll
  const handleCardClick = (tab: string) => {
    // Set the current view
    setCurrentView(tab);
    
    // Auto-scroll to tabs section after state update
    setTimeout(() => {
      const tabsSection = document.querySelector('[data-tabs-section="knowledge-base"]');
      if (tabsSection) {
        tabsSection.scrollIntoView({ 
          behavior: 'smooth', 
          block: 'start',
          inline: 'nearest'
        });
      }
    }, 100);
  };

  // Filter documents based on search term
  useEffect(() => {
    if (!searchTerm.trim()) {
      setFilteredDocuments(documents);
    } else {
      const filtered = documents.filter(doc => 
        doc.title?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        doc.description?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        doc.document_type?.toLowerCase().includes(searchTerm.toLowerCase())
      );
      setFilteredDocuments(filtered);
    }
  }, [documents, searchTerm]);

  // User Contributions
  const [showDocumentUploadDialog, setShowDocumentUploadDialog] = useState(false);
  const [showCaseStudyDialog, setShowCaseStudyDialog] = useState(false);
  const [showBlogEditorDialog, setShowBlogEditorDialog] = useState(false);
  const [documentReason, setDocumentReason] = useState('');
  const [caseStudyReason, setCaseStudyReason] = useState('');
  const [blogTitle, setBlogTitle] = useState('');
  const [blogSummary, setBlogSummary] = useState('');
  const [blogContent, setBlogContent] = useState('');
  const [blogTags, setBlogTags] = useState('');
  const [documentFile, setDocumentFile] = useState<File | null>(null);
  const [caseStudyFile, setCaseStudyFile] = useState<File | null>(null);
  const [isSubmittingDocument, setIsSubmittingDocument] = useState(false);
  const [isSubmittingCaseStudy, setIsSubmittingCaseStudy] = useState(false);
  const [isSubmittingBlog, setIsSubmittingBlog] = useState(false);

  const handleDocumentSubmit = async () => {
    if (!documentFile) {
      toast.error('Please select a file to upload');
      return;
    }

    setIsSubmittingDocument(true);
    try {
      const submitData: BodySubmitDocument = {
        file: documentFile,
        reason: documentReason || undefined
      };

      const response = await brain.submit_document(submitData);
      const result = await response.json();
      
      if (response.ok) {
        toast.success('Document submitted successfully for review!');
        setShowDocumentUploadDialog(false);
        setDocumentFile(null);
        setDocumentReason('');
      } else {
        toast.error(result.detail || 'Failed to submit document');
      }
    } catch (error) {
      console.error('Error submitting document:', error);
      toast.error('Failed to submit document');
    } finally {
      setIsSubmittingDocument(false);
    }
  };

  const handleCaseStudySubmit = async () => {
    if (!caseStudyFile) {
      toast.error('Please select a file to upload');
      return;
    }

    setIsSubmittingCaseStudy(true);
    try {
      const submitData: BodySubmitCaseStudy = {
        file: caseStudyFile,
        reason: caseStudyReason || undefined
      };

      const response = await brain.submit_case_study(submitData);
      const result = await response.json();
      
      if (response.ok) {
        toast.success('Case study submitted successfully for review!');
        setShowCaseStudyDialog(false);
        setCaseStudyFile(null);
        setCaseStudyReason('');
      } else {
        toast.error(result.detail || 'Failed to submit case study');
      }
    } catch (error) {
      console.error('Error submitting case study:', error);
      toast.error('Failed to submit case study');
    } finally {
      setIsSubmittingCaseStudy(false);
    }
  };

  const handleBlogSubmit = async () => {
    if (!blogTitle.trim() || !blogContent.trim()) {
      toast.error('Please fill in title and content');
      return;
    }

    setIsSubmittingBlog(true);
    try {
      const response = await brain.submit_blog_article({
        title: blogTitle,
        summary: blogSummary,
        content: blogContent,
        tags: blogTags
      });

      if (response.ok) {
        const result = await response.json();
        toast.success('Blog article submitted successfully for review!');
        setShowBlogEditorDialog(false);
        setBlogTitle('');
        setBlogSummary('');
        setBlogContent('');
        setBlogTags('');
      } else {
        toast.error('Failed to submit blog article');
      }
    } catch (error) {
      console.error('Error submitting blog article:', error);
      toast.error('Failed to submit blog article');
    } finally {
      setIsSubmittingBlog(false);
    }
  };

  const handleViewPDF = async (document: Document) => {
    console.log('Document clicked:', document);
    
    if (document.file_type === 'application/pdf') {
      // Simple approach: navigate to PDF viewer in same tab
      const pdfViewerPath = `/pdf-viewer?documentId=${document.id}&title=${encodeURIComponent(document.title)}`;
      
      console.log('Navigating to PDF viewer:', {
        documentId: document.id,
        documentTitle: document.title,
        pdfViewerPath
      });
      
      navigate(pdfViewerPath);
    } else {
      toast.error('Document is not a PDF');
    }
  };

  // Handle saving/unsaving documents
  const handleSaveDocument = (doc: any) => {
    if (doc) {
      setSelectedDocumentForSave({
        id: doc.id || doc.document_id,
        title: doc.title || doc.document_title || doc.name,
        description: doc.description || doc.document_description,
        type: doc.type || doc.document_type,
        url: doc.url || doc.document_url
      });
      setShowSaveArticleDialog(true);
    }
  };
  
  // Handle successful save from dialog
  const handleSaveSuccess = () => {
    if (currentView === 'saved') {
      // The SavedArticlesView component will auto-refresh
    }
    loadSavedArticles();
    setShowSaveArticleDialog(false);
    setSelectedDocumentForSave(null);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-950 via-gray-900 to-gray-950">
      {/* Uniform Navigation */}
      <Navigation currentPage="knowledge_base" />
      
      {/* Module-specific Sub-header */}
      <div className="bg-gray-950/80 backdrop-blur-lg border-b border-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-3 py-4">
            <div className="p-2 bg-orange-600 rounded-lg">
              <FileText className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-white">Knowledge Base</h1>
              <p className="text-sm text-gray-400">Export Control Resources & Documentation</p>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-6 py-8">
        {/* Intelligence Hub Activity Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
          {/* Document Repository Card */}
          <Card 
            className="bg-gradient-to-r from-blue-900/40 via-blue-800/30 to-blue-900/40 backdrop-blur-md border border-blue-500/40 hover:border-blue-400/60 transition-all duration-500 cursor-pointer group rounded-2xl shadow-2xl hover:shadow-blue-500/20"
            onClick={() => handleCardClick('repository')}
          >
            <CardContent className="p-8">
              <div className="flex items-start gap-6">
                <div className="p-4 bg-blue-500/20 rounded-2xl group-hover:bg-blue-500/30 transition-colors">
                  <FileText className="w-10 h-10 text-blue-400" />
                </div>
                <div className="flex-1">
                  <h3 className="text-2xl font-bold text-white mb-3 group-hover:text-blue-200 transition-colors">
                    Document Repository
                  </h3>
                  <p className="text-blue-200/80 leading-relaxed mb-4">
                    Access our comprehensive collection of regulatory documents, guidance papers, and compliance resources from authorities worldwide.
                  </p>
                  <div className="flex items-center gap-4 text-sm">
                    <span className="text-blue-300 font-medium">Comprehensive Collection</span>
                    <span className="text-blue-400">•</span>
                    <span className="text-blue-300 font-medium">Global Coverage</span>
                  </div>
                </div>
                <ChevronRight className="w-6 h-6 text-blue-400 group-hover:text-blue-300 group-hover:translate-x-1 transition-all" />
              </div>
            </CardContent>
          </Card>

          {/* Expert Insights Card */}
          <Card 
            className="bg-gradient-to-r from-purple-900/40 via-purple-800/30 to-purple-900/40 backdrop-blur-md border border-purple-500/40 hover:border-purple-400/60 transition-all duration-500 cursor-pointer group rounded-2xl shadow-2xl hover:shadow-purple-500/20"
            onClick={() => handleCardClick('blog')}
          >
            <CardContent className="p-8">
              <div className="flex items-start gap-6">
                <div className="p-4 bg-purple-500/20 rounded-2xl group-hover:bg-purple-500/30 transition-colors">
                  <PenTool className="w-10 h-10 text-purple-400" />
                </div>
                <div className="flex-1">
                  <h3 className="text-2xl font-bold text-white mb-3 group-hover:text-purple-200 transition-colors">
                    Expert Insights
                  </h3>
                  <p className="text-purple-200/80 leading-relaxed mb-4">
                    Read analysis and commentary from compliance professionals, legal experts, and regulatory specialists.
                  </p>
                  <div className="flex items-center gap-4 text-sm">
                    <span className="text-purple-300 font-medium">Professional Commentary</span>
                    <span className="text-purple-400">•</span>
                    <span className="text-purple-300 font-medium">Expert Authors</span>
                  </div>
                </div>
                <ChevronRight className="w-6 h-6 text-purple-400 group-hover:text-purple-300 group-hover:translate-x-1 transition-all" />
              </div>
            </CardContent>
          </Card>

          {/* Featured Content Card */}
          <Card 
            className="bg-gradient-to-r from-amber-900/40 via-orange-800/30 to-amber-900/40 backdrop-blur-md border border-amber-500/40 hover:border-amber-400/60 transition-all duration-500 cursor-pointer group rounded-2xl shadow-2xl hover:shadow-amber-500/20"
            onClick={() => handleCardClick('featured')}
          >
            <CardContent className="p-8">
              <div className="flex items-start gap-6">
                <div className="p-4 bg-amber-500/20 rounded-2xl group-hover:bg-amber-500/30 transition-colors">
                  <Star className="w-10 h-10 text-amber-400 fill-current" />
                </div>
                <div className="flex-1">
                  <h3 className="text-2xl font-bold text-white mb-3 group-hover:text-amber-200 transition-colors">
                    Featured Content
                  </h3>
                  <p className="text-amber-200/80 leading-relaxed mb-4">
                    Discover our editorial team's curated selection of the most important and relevant compliance documents.
                  </p>
                  <div className="flex items-center gap-4 text-sm">
                    <span className="text-amber-300 font-medium">Editorial Curation</span>
                    <span className="text-amber-400">•</span>
                    <span className="text-amber-300 font-medium">High Impact</span>
                  </div>
                </div>
                <ChevronRight className="w-6 h-6 text-amber-400 group-hover:text-amber-300 group-hover:translate-x-1 transition-all" />
              </div>
            </CardContent>
          </Card>

          {/* Community Hub Card */}
          <Card 
            className="bg-gradient-to-r from-green-900/40 via-emerald-800/30 to-green-900/40 backdrop-blur-md border border-green-500/40 hover:border-green-400/60 transition-all duration-500 cursor-pointer group rounded-2xl shadow-2xl hover:shadow-green-500/20"
            onClick={() => handleCardClick('community')}
          >
            <CardContent className="p-8">
              <div className="flex items-start gap-6">
                <div className="p-4 bg-green-500/20 rounded-2xl group-hover:bg-green-500/30 transition-colors">
                  <MessageSquare className="w-10 h-10 text-green-400" />
                </div>
                <div className="flex-1">
                  <h3 className="text-2xl font-bold text-white mb-3 group-hover:text-green-200 transition-colors">
                    Community Hub
                  </h3>
                  <p className="text-green-200/80 leading-relaxed mb-4">
                    Connect with fellow compliance professionals, share experiences, and get answers to your questions.
                  </p>
                  <div className="flex items-center gap-4 text-sm">
                    <span className="text-green-300 font-medium">Professional Network</span>
                    <span className="text-green-400">•</span>
                    <span className="text-green-300 font-medium">Expert Support</span>
                  </div>
                </div>
                <ChevronRight className="w-6 h-6 text-green-400 group-hover:text-green-300 group-hover:translate-x-1 transition-all" />
              </div>
            </CardContent>
          </Card>

          {/* Country Guides Card */}
          <Card 
            className="bg-gradient-to-r from-indigo-900/40 via-blue-800/30 to-indigo-900/40 backdrop-blur-md border border-indigo-500/40 hover:border-indigo-400/60 transition-all duration-500 cursor-pointer group rounded-2xl shadow-2xl hover:shadow-indigo-500/20"
            onClick={() => handleCardClick('countries')}
          >
            <CardContent className="p-8">
              <div className="flex items-start gap-6">
                <div className="p-4 bg-indigo-500/20 rounded-2xl group-hover:bg-indigo-500/30 transition-colors">
                  <Globe className="w-10 h-10 text-indigo-400" />
                </div>
                <div className="flex-1">
                  <h3 className="text-2xl font-bold text-white mb-3 group-hover:text-indigo-200 transition-colors">
                    Country Guides
                  </h3>
                  <p className="text-indigo-200/80 leading-relaxed mb-4">
                    Explore jurisdiction-specific compliance requirements, regulations, and enforcement practices.
                  </p>
                  <div className="flex items-center gap-4 text-sm">
                    <span className="text-indigo-300 font-medium">Global Coverage</span>
                    <span className="text-indigo-400">•</span>
                    <span className="text-indigo-300 font-medium">Regional Insights</span>
                  </div>
                </div>
                <ChevronRight className="w-6 h-6 text-indigo-400 group-hover:text-indigo-300 group-hover:translate-x-1 transition-all" />
              </div>
            </CardContent>
          </Card>

          {/* Saved Resources Card */}
          <Card 
            className="bg-gradient-to-r from-rose-900/40 via-pink-800/30 to-rose-900/40 backdrop-blur-md border border-rose-500/40 hover:border-rose-400/60 transition-all duration-500 cursor-pointer group rounded-2xl shadow-2xl hover:shadow-rose-500/20"
            onClick={() => handleCardClick('saved')}
          >
            <CardContent className="p-8">
              <div className="flex items-start gap-6">
                <div className="p-4 bg-rose-500/20 rounded-1xl group-hover:bg-rose-500/30 transition-colors">
                  <Bookmark className="w-10 h-10 text-rose-400" />
                </div>
                <div className="flex-1">
                  <h3 className="text-2xl font-bold text-white mb-1 group-hover:text-rose-200 transition-colors">
                    Saved Resources
                  </h3>
                  <p className="text-rose-200/80 leading-relaxed mb-4">
                    Your personal collection of bookmarked documents.
                  </p>
                  <div className="flex items-center gap-4 text-sm">
                    <span className="text-rose-300 font-medium">
                      {savedArticles.length > 0 ? `${savedArticles.length} Saved ${savedArticles.length === 1 ? 'Item' : 'Items'}` : 'No Saved Items'}
                    </span>
                    <span className="text-rose-400">•</span>
                    <span className="text-rose-300 font-medium">
                      {savedArticles.length > 0 ? 'View Collection' : 'Start Building'}
                    </span>
                  </div>
                </div>
                <div className="self-center">
                  <ChevronRight className="w-6 h-6 text-rose-400 group-hover:text-rose-300 group-hover:translate-x-1 transition-all" />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* User Contributions Card */}
          <Card 
            className="bg-gradient-to-r from-teal-900/40 via-cyan-800/30 to-teal-900/40 backdrop-blur-md border border-teal-500/40 hover:border-teal-400/60 transition-all duration-500 cursor-pointer group rounded-2xl shadow-2xl hover:shadow-teal-500/20"
            onClick={() => handleCardClick('contributions')}
          >
            <CardContent className="p-8">
              <div className="flex items-start gap-6">
                <div className="p-4 bg-teal-500/20 rounded-2xl group-hover:bg-teal-500/30 transition-colors">
                  <Upload className="w-10 h-10 text-teal-400" />
                </div>
                <div className="flex-1">
                  <h3 className="text-2xl font-bold text-white mb-3 group-hover:text-teal-200 transition-colors">
                    User Contributions
                  </h3>
                  <p className="text-teal-200/80 leading-relaxed mb-4">
                    Share your expertise with the community.
                  </p>
                  <div className="flex items-center gap-4 text-sm">
                    <span className="text-teal-300 font-medium">Submit Articles</span>
                    <span className="text-teal-400">•</span>
                    <span className="text-teal-300 font-medium">Upload Documents</span>
                  </div>
                </div>
                <ChevronRight className="w-6 h-6 text-teal-400 group-hover:text-teal-300 group-hover:translate-x-1 transition-all" />
              </div>
            </CardContent>
          </Card>

          {/* Quick Navigation Card */}
          <Card 
            className="bg-gradient-to-r from-gray-800/40 via-gray-700/30 to-gray-800/40 backdrop-blur-md border border-gray-500/40 hover:border-gray-400/60 transition-all duration-500 group rounded-2xl shadow-2xl hover:shadow-gray-500/20"
            onClick={() => handleCardClick('quick-navigation')}
          >
            <CardContent className="p-8">
              <div className="flex items-start gap-6">
                <div className="p-4 bg-gray-500/20 rounded-1xl group-hover:bg-gray-500/30 transition-colors">
                  <Target className="w-10 h-10 text-gray-400" />
                </div>
                <div className="flex-1">
                  <h3 className="text-2xl font-bold text-white mb-3 group-hover:text-gray-200 transition-colors">
                    Quick Navigation
                  </h3>
                  <p className="text-gray-200/80 leading-relaxed mb-4">
                    Jump to other RespectUs modules.
                  </p>
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    <button 
                      onClick={() => navigate('/product-classification')}
                      className="text-gray-300 font-medium hover:text-white hover:bg-gray-700/30 p-2 rounded-lg transition-all text-left"
                    >
                      Product Classification
                    </button>
                    <button 
                      onClick={() => navigate('/sanctions-embargoes')}
                      className="text-gray-300 font-medium hover:text-white hover:bg-gray-700/30 p-2 rounded-lg transition-all text-left"
                    >
                      Sanctions & Embargoes
                    </button>
                    <button 
                      onClick={() => navigate('/customer-screening')}
                      className="text-gray-300 font-medium hover:text-white hover:bg-gray-700/30 p-2 rounded-lg transition-all text-left"
                    >
                      Customer Screening
                    </button>
                    <button 
                      onClick={() => navigate('/end-use-checks')}
                      className="text-gray-300 font-medium hover:text-white hover:bg-gray-700/30 p-1 rounded-lg transition-all text-left"
                    >
                      End-Use Checks
                    </button>
                    <button 
                      onClick={() => navigate('/risk-assessment')}
                      className="text-gray-300 font-medium hover:text-white hover:bg-gray-700/30 p-2 rounded-lg transition-all text-left"
                    >
                      Risk Assessment
                    </button>
                    <button 
                      onClick={() => navigate('/license-determination')}
                      className="text-gray-300 font-medium hover:text-white hover:bg-gray-700/30 p-1 rounded-lg transition-all text-left"
                    >
                      License Determination
                    </button>
                  </div>
                </div>
                <ChevronRight className="w-6 h-6 text-gray-400 group-hover:text-gray-300 transition-all" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Blog Section - Directly displayed after cards */}
        {blogDocuments.length > 0 && (
          <div className="mb-16">
            <div className="text-center mb-8">
              <h3 className="text-2xl font-bold text-white mb-4">Latest Insights</h3>
              <p className="text-gray-400">Expert analysis and regulatory updates from the compliance community</p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {blogDocuments.slice(0, 6).map((blog) => (
                <Card key={blog.id} className="bg-gradient-to-br from-purple-900/40 to-purple-800/20 backdrop-blur-sm border border-purple-500/30 hover:border-purple-400/50 transition-all duration-300 group">
                  <CardContent className="p-6">
                    <div className="flex items-start gap-3 mb-4">
                      <div className="p-1 bg-purple-500/20 rounded-lg">
                        <PenTool className="w-5 h-5 text-purple-400" />
                      </div>
                      <div className="flex-1">
                        <h4 className="text-lg font-semibold text-white group-hover:text-purple-200 transition-colors line-clamp-2">
                          {blog.title}
                        </h4>
                        {blog.summary && (
                          <p className="text-gray-400 text-sm mt-1 line-clamp-3">
                            {blog.summary}
                          </p>
                        )}
                      </div>
                    </div>
                    
                    <div className="flex items-center justify-between text-xs">
                      <div className="flex items-center gap-2">
                        <span className="text-purple-400">{blog.author || 'RespectUs Team'}</span>
                        <span className="text-gray-500">•</span>
                        <span className="text-gray-500">{blog.read.read_time || '5'} min read</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Star className="w-3 h-3 text-amber-400 fill-current" />
                        <span className="text-gray-400">Featured</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}

        {/* Tab Navigation and Content */}
        <div className="mt-12" data-tabs-section="knowledge-base">
          <Tabs value={currentView} onValueChange={setCurrentView} className="w-full">
            <TabsList className="grid w-full grid-cols-7 bg-gray-800/30 backdrop-blur-sm border border-gray-700/50 mb-8">
              <TabsTrigger value="repository" className="data-[state=active]:bg-blue-600/20 data-[state=active]:text-blue-300">
                <FileText className="w-4 h-4 mr-2" />
                Documents
              </TabsTrigger>
              <TabsTrigger value="blog" className="data-[state=active]:bg-purple-600/20 data-[state=active]:text-purple-300">
                <PenTool className="w-4 h-4 mr-1" />
                Blog
              </TabsTrigger>
              <TabsTrigger value="featured" className="data-[state=active]:bg-amber-600/20 data-[state=active]:text-amber-300">
                <Star className="w-4 h-4 mr-1" />
                Featured
              </TabsTrigger>
              <TabsTrigger value="community" className="data-[state=active]:bg-green-600/20 data-[state=active]:text-green-300">
                <MessageSquare className="w-4 h-4 mr-2" />
                Community
              </TabsTrigger>
              <TabsTrigger value="countries" className="data-[state=active]:bg-indigo-600/20 data-[state=active]:text-indigo-300">
                <Globe className="w-4 h-4 mr-1" />
                Countries
              </TabsTrigger>
              <TabsTrigger value="saved" className="data-[state=active]:bg-rose-600/20 data-[state=active]:text-rose-300">
                <Bookmark className="w-4 h-4 mr-2" />
                Saved
              </TabsTrigger>
              <TabsTrigger value="contributions" className="data-[state=active]:bg-teal-600/20 data-[state=active]:text-teal-300">
                <Upload className="w-4 h-4 mr-1" />
                Contribute
              </TabsTrigger>
            </TabsList>

            <TabsContent value="repository" className="space-y-6">
              <div className="bg-gradient-to-br from-blue-900/20 to-blue-800/10 backdrop-blur-sm border border-blue-500/20 rounded-2xl p-8">
                <div className="flex items-center gap-4 mb-1">
                  <div className="p-3 bg-blue-500/20 rounded-xl">
                    <FileText className="w-8 h-8 text-blue-400" />
                  </div>
                  <div className="flex-1">
                    <h2 className="text-2xl font-bold text-white">Document Repository</h2>
                    <p className="text-blue-200/80">Comprehensive collection of regulatory documents and compliance resources</p>
                  </div>
                </div>
                
                {/* Search Field */}
                <div className="mb-6">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-blue-400 h-4 w-4" />
                    <Input
                      placeholder="Search documents by title, description, or type..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10 bg-gray-800/50 border-blue-500/30 text-white placeholder-gray-400 focus:border-blue-400/60"
                    />
                  </div>
                </div>
                
                {loading ? (
                  <div className="text-center py-8">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-400 mx-auto"></div>
                    <p className="text-gray-400 mt-1">Loading documents...</p>
                  </div>
                ) : filteredDocuments.length > 0 ? (
                  <>
                    {/* Display Mode Controls */}
                    <div className="flex items-center justify-between mb-6">
                      <div className="flex items-center gap-4">
                        <span className="text-gray-400 text-sm">
                          {showAllDocuments 
                            ? `Showing ${documentsToDisplay.length} of ${filteredDocuments.length} documents (Page ${currentPage} of ${totalPages})`
                            : `Showing latest ${Math.min(20, filteredDocuments.length)} of ${filteredDocuments.length} documents`
                          }
                        </span>
                      </div>
                      <div className="flex items-center gap-3">
                        {!showAllDocuments && filteredDocuments.length > 20 && (
                          <Button
                            onClick={handleDisplayAllClick}
                            variant="outline"
                            className="border-blue-500/30 text-blue-300 hover:bg-blue-500/10"
                          >
                            Display All
                          </Button>
                        )}
                        {showAllDocuments && (
                          <Button
                            onClick={handleShowRecentClick}
                            variant="outline"
                            className="border-blue-500/30 text-blue-300 hover:bg-blue-500/10"
                          >
                            Show Recent Only
                          </Button>
                        )}
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                      {documentsToDisplay.map((doc) => {
                        const docId = doc.id.toString();
                        const isSaved = savedDocumentIds.has(docId);
                        const isSaving = savingStates[docId];
                        
                        return (
                          <Card 
                            key={doc.id} 
                            className="bg-gray-800/40 backdrop-blur-sm border border-blue-500/20 hover:border-blue-400/40 transition-all group cursor-pointer hover:shadow-lg hover:shadow-blue-500/20 relative"
                            onClick={() => handleViewPDF(doc)}
                          >
                            <CardContent className="p-4">
                              {/* Save Button */}
                              <Button
                                onClick={(e) => handleSaveDocument(doc, e)}
                                disabled={isSaving}
                                size="sm"
                                variant={isSaved ? "destructive" : "secondary"}
                                className={`absolute top-3 right-3 ${isSaving ? 'opacity-50 cursor-not-allowed' : ''}`}
                              >
                                {isSaving ? (
                                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-current mr-1" />
                                ) : null}
                                {isSaving ? 'Saving...' : isSaved ? 'Unsave' : 'Save'}
                              </Button>
                              
                              <h3 className="font-semibold text-white group-hover:text-blue-200 transition-colors line-clamp-2 mb-2 pr-12">
                                {doc.title}
                              </h3>
                              {doc.description && (
                                <p className="text-gray-400 text-sm line-clamp-3 mb-3">
                                  {doc.description}
                                </p>
                              )}
                              
                              {/* Jurisdiction and Document Date */}
                              <div className="mb-3 space-y-1">
                                {doc.country_jurisdiction && doc.country_jurisdiction.length > 0 && (
                                  <div className="flex items-center gap-2 text-xs">
                                    <span className="text-gray-500">Jurisdiction:</span>
                                    <span className="text-blue-300">
                                      {Array.isArray(doc.country_jurisdiction) 
                                        ? doc.country_jurisdiction.join(', ')
                                        : doc.country_jurisdiction}
                                    </span>
                                  </div>
                                )}
                                {doc.publication_date && (
                                  <div className="flex items-center gap-2 text-xs">
                                    <span className="text-gray-500">Document Date:</span>
                                    <span className="text-blue-300">
                                      {new Date(doc.publication_date).toLocaleDateString()}
                                    </span>
                                  </div>
                                )}
                              </div>
                              
                              <div className="flex items-center justify-between text-xs">
                                <span className="text-blue-400">{doc.document_type || 'Document'}</span>
                                <span className="text-gray-500">
                                  {doc.created_at ? `Uploaded: ${new Date(doc.created_at).toLocaleDateString()}` : ''}
                                </span>
                              </div>
                            </CardContent>
                          </Card>
                        );
                      })}
                    </div>

                    {/* Pagination Controls */}
                    {showAllDocuments && totalPages > 1 && (
                      <div className="flex items-center justify-center gap-4 mt-8">
                        <Button
                          onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                          disabled={currentPage === 1}
                          variant="outline"
                          className="border-blue-500/30 text-blue-300 hover:bg-blue-500/10 disabled:opacity-50 disabled:cursor-not-allowed"
                        >
                          Previous
                        </Button>
                        
                        <div className="flex items-center gap-2">
                          {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                            const pageNum = i + 1;
                            const isCurrentPage = pageNum === currentPage;
                            
                            return (
                              <Button
                                key={pageNum}
                                onClick={() => setCurrentPage(pageNum)}
                                variant={isCurrentPage ? "default" : "outline"}
                                className={isCurrentPage 
                                  ? "bg-blue-600 hover:bg-blue-700" 
                                  : "border-blue-500/30 text-blue-300 hover:bg-blue-500/10"
                                }
                                size="sm"
                              >
                                {pageNum}
                              </Button>
                            );
                          })}
                          
                          {totalPages > 5 && (
                            <>
                              <span className="text-gray-500 px-2">...</span>
                              <Button
                                onClick={() => setCurrentPage(totalPages)}
                                variant={currentPage === totalPages ? "default" : "outline"}
                                className={currentPage === totalPages 
                                  ? "bg-blue-600 hover:bg-blue-700" 
                                  : "border-blue-500/30 text-blue-300 hover:bg-blue-500/10"
                                }
                                size="sm"
                              >
                                {totalPages}
                              </Button>
                            </>
                          )}
                        </div>
                        
                        <Button
                          onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                          disabled={currentPage === totalPages}
                          variant="outline"
                          className="border-blue-500/30 text-blue-300 hover:bg-blue-500/10 disabled:opacity-50 disabled:cursor-not-allowed"
                        >
                          Next
                        </Button>
                      </div>
                    )}
                  </>
                ) : (
                  <div className="text-center py-12">
                    <FileText className="w-16 h-16 text-gray-600 mx-auto mb-4" />
                    <h3 className="text-xl font-semibold text-gray-400 mb-2">
                      {searchTerm ? 'No documents found' : 'No documents available'}
                    </h3>
                    <p className="text-gray-500">
                      {searchTerm ? 'Try adjusting your search criteria.' : 'Documents will appear here once they are uploaded.'}
                    </p>
                    {searchTerm && (
                      <Button 
                        onClick={() => setSearchTerm('')}
                        variant="outline" 
                        className="mt-4 border-blue-500/30 text-blue-300 hover:bg-blue-500/10"
                      >
                        Clear Search
                      </Button>
                    )}
                  </div>
                )}
              </div>
            </TabsContent>

            <TabsContent value="blog" className="space-y-6">
              <div className="bg-gradient-to-br from-purple-900/20 to-purple-800/10 backdrop-blur-sm border border-purple-500/20 rounded-2xl p-8">
                <div className="flex items-center gap-4 mb-6">
                  <div className="p-3 bg-purple-500/20 rounded-xl">
                    <PenTool className="w-8 h-8 text-purple-400" />
                  </div>
                  <div>
                    <h2 className="text-2xl font-bold text-white">Expert Insights & Analysis</h2>
                    <p className="text-purple-200/80">Professional commentary and thought leadership from compliance experts</p>
                  </div>
                </div>
                
                <div className="text-center py-12">
                  <PenTool className="w-16 h-16 text-gray-600 mx-auto mb-4" />
                  <h3 className="text-xl font-semibold text-gray-400 mb-2">No blog articles yet</h3>
                  <p className="text-gray-500 mb-4">Be the first to contribute expert insights to our community.</p>
                  <Button onClick={() => handleCardClick('contributions')} className="bg-purple-600 hover:bg-purple-500">
                    <Plus className="w-4 h-4 mr-2" />
                    Submit Article
                  </Button>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="featured" className="space-y-6">
              <div className="bg-gradient-to-br from-amber-900/20 to-orange-800/10 backdrop-blur-sm border border-amber-500/20 rounded-2xl p-8">
                <div className="flex items-center gap-4 mb-6">
                  <div className="p-3 bg-amber-500/20 rounded-xl">
                    <Star className="w-8 h-8 text-amber-400 fill-current" />
                  </div>
                  <div>
                    <h2 className="text-2xl font-bold text-white">Featured Articles</h2>
                    <p className="text-amber-200/80">Curated selection of the most important compliance documents</p>
                  </div>
                </div>
                
                {featuredArticles.length > 0 ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {featuredArticles.map((article) => (
                      <Card key={article.id} className="bg-gray-800/40 backdrop-blur-sm border border-amber-500/20 hover:border-amber-400/40 transition-all group">
                        <CardContent className="p-6">
                          <div className="flex items-start gap-3 mb-4">
                            <Star className="w-5 h-5 text-amber-400 fill-current mt-1 flex-shrink-0" />
                            <div className="flex-1">
                              <h3 className="font-semibold text-white group-hover:text-amber-200 transition-colors line-clamp-2 mb-2">
                                {article.title}
                              </h3>
                              {article.description && (
                                <p className="text-gray-400 text-sm line-clamp-3">
                                  {article.description}
                                </p>
                              )}
                            </div>
                          </div>
                          <div className="flex items-center justify-between text-xs">
                            <Badge variant="secondary" className="bg-amber-500/20 text-amber-300 border-amber-500/30">
                              Featured
                            </Badge>
                            <span className="text-gray-500">{article.created_at ? new Date(article.created_at).toLocaleDateString() : ''}</span>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <Star className="w-16 h-8 text-gray-600 mx-auto mb-4" />
                    <h3 className="text-xl font-semibold text-gray-400 mb-2">No featured articles yet</h3>
                    <p className="text-gray-500">Featured articles will appear here once curated by our editorial team.</p>
                  </div>
                )}
              </div>
            </TabsContent>

            <TabsContent value="community" className="space-y-6">
              <CommunityChat />
            </TabsContent>

            <TabsContent value="countries" className="space-y-6">
              <div className="bg-gradient-to-br from-indigo-900/20 to-blue-800/10 backdrop-blur-sm border border-indigo-500/20 rounded-2xl p-8">
                <div className="flex items-center gap-4 mb-6">
                  <div className="p-3 bg-indigo-500/20 rounded-xl">
                    <Globe className="w-8 h-8 text-indigo-400" />
                  </div>
                  <div>
                    <h2 className="text-2xl font-bold text-white">Countries & Jurisdictions</h2>
                    <p className="text-indigo-200/80">Explore compliance requirements by country and region</p>
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  <div className="text-center py-12">
                    <Globe className="w-16 h-16 text-gray-600 mx-auto mb-4" />
                    <h3 className="text-xl font-semibold text-gray-400 mb-2">Country guides coming soon</h3>
                    <p className="text-gray-500">Comprehensive regulatory guides and compliance requirements by jurisdiction will be available here.</p>
                  </div>
                </div>
              </div>
            </TabsContent>

            {/* Saved Articles Tab */}
            <TabsContent value="saved" className="mt-8">
              <SavedArticlesView 
                onSaveArticle={(doc) => {
                  setSelectedDocumentForSave(doc);
                  setShowSaveArticleDialog(true);
                }}
              />
            </TabsContent>

            <TabsContent value="contributions">
              <div className="space-y-6">
                <div className="text-center">
                  <h3 className="text-2xl font-bold text-white mb-3">User Contributions Portal</h3>
                  <p className="text-gray-400">Share your expertise with the community</p>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Upload Document */}
                  <Card className="bg-gradient-to-br from-teal-900/50 to-cyan-900/30 border-teal-500/30 backdrop-blur-sm">
                    <CardContent className="p-6">
                      <div className="flex items-center gap-3 mb-4">
                        <Upload className="w-8 h-8 text-teal-400" />
                        <h3 className="text-xl font-semibold text-white">Upload Document</h3>
                      </div>
                      <p className="text-gray-300 mb-4">Share a regulatory document with the RespectUs community</p>
                      <Button 
                        onClick={() => setShowDocumentUploadDialog(true)}
                        className="w-full bg-teal-600 hover:bg-teal-700"
                      >
                        Upload Document
                      </Button>
                    </CardContent>
                  </Card>
                  
                  {/* Submit Case Study */}
                  <Card className="bg-gradient-to-br from-purple-900/50 to-indigo-900/30 border-purple-500/30 backdrop-blur-sm">
                    <CardContent className="p-6">
                      <div className="flex items-center gap-3 mb-4">
                        <FileText className="w-8 h-8 text-purple-400" />
                        <h3 className="text-xl font-semibold text-white">Submit Case Study</h3>
                      </div>
                      <p className="text-gray-300 mb-4">Share your compliance experience as a case study</p>
                      <Button 
                        onClick={() => setShowCaseStudyDialog(true)}
                        className="w-full bg-purple-600 hover:bg-purple-700"
                      >
                        Submit Case Study
                      </Button>
                    </CardContent>
                  </Card>
                  
                  {/* Submit Blog Article */}
                  <Card className="bg-gradient-to-br from-orange-900/50 to-red-900/30 border-orange-500/30 backdrop-blur-sm">
                    <CardContent className="p-6">
                      <div className="flex items-center gap-3 mb-4">
                        <PenTool className="w-8 h-8 text-orange-400" />
                        <h3 className="text-xl font-semibold text-white">Submit Blog Article</h3>
                      </div>
                      <p className="text-gray-300 mb-4">Write and share thought leadership articles</p>
                      <Button 
                        onClick={() => setShowBlogEditorDialog(true)}
                        className="w-full bg-orange-600 hover:bg-orange-700"
                      >
                        Write Article
                      </Button>
                    </CardContent>
                  </Card>
                  
                  {/* Join Chat Discussion */}
                  <Card className="bg-gradient-to-br from-green-900/50 to-emerald-900/30 border-green-500/30 backdrop-blur-sm">
                    <CardContent className="p-6">
                      <div className="flex items-center gap-3 mb-4">
                        <MessageSquare className="w-8 h-8 text-green-400" />
                        <h3 className="text-xl font-semibold text-white">Join Discussion</h3>
                      </div>
                      <p className="text-gray-300 mb-4">Participate in community conversations</p>
                      <Button 
                        onClick={() => setCurrentView('community')}
                        className="w-full bg-green-600 hover:bg-green-700"
                      >
                        Join Chat
                      </Button>
                    </CardContent>
                  </Card>
                </div>
                
                {/* Document Upload Dialog */}
                <Dialog open={showDocumentUploadDialog} onOpenChange={setShowDocumentUploadDialog}>
                  <DialogContent className="bg-gray-800 border-gray-700 max-w-md">
                    <DialogHeader>
                      <DialogTitle className="text-white">Upload Document</DialogTitle>
                      <DialogDescription className="text-gray-400">
                        Share a regulatory document with the RespectUs community
                      </DialogDescription>
                    </DialogHeader>
                    <div className="space-y-4">
                      <div>
                        <Label htmlFor="doc-reason" className="text-gray-300">Why do you think RespectUs should publish this? (Optional)</Label>
                        <Textarea
                          id="doc-reason"
                          value={documentReason}
                          onChange={(e) => setDocumentReason(e.target.value)}
                          placeholder="Explain the value this document brings to the community..."
                          className="bg-gray-700 border-gray-600 text-white mt-2"
                          rows={3}
                        />
                      </div>
                      <div>
                        <Label htmlFor="doc-file" className="text-gray-300">Document File</Label>
                        <Input
                          id="doc-file"
                          type="file"
                          onChange={(e) => setDocumentFile(e.target.files?.[0] || null)}
                          className="bg-gray-700 border-gray-600 text-white mt-2"
                          accept=".pdf,.doc,.docx,.txt"
                        />
                      </div>
                      <div className="text-xs text-gray-500">
                        Files are processed in accordance with GDPR. Only approved documents will be published.
                      </div>
                    </div>
                    <DialogFooter>
                      <Button variant="outline" onClick={() => setShowDocumentUploadDialog(false)}>Cancel</Button>
                      <Button 
                        onClick={handleDocumentSubmit}
                        disabled={!documentFile || isSubmittingDocument}
                        className="bg-teal-600 hover:bg-teal-700"
                      >
                        {isSubmittingDocument ? 'Submitting...' : 'Submit Document'}
                      </Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>
                
                {/* Case Study Dialog */}
                <Dialog open={showCaseStudyDialog} onOpenChange={setShowCaseStudyDialog}>
                  <DialogContent className="bg-gray-800 border-gray-700 max-w-md">
                    <DialogHeader>
                      <DialogTitle className="text-white">Submit Case Study</DialogTitle>
                      <DialogDescription className="text-gray-400">
                        Share your compliance experience as a case study
                      </DialogDescription>
                    </DialogHeader>
                    <div className="space-y-4">
                      <div>
                        <Label htmlFor="case-reason" className="text-gray-300">Why do you think RespectUs should publish this? (Optional)</Label>
                        <Textarea
                          id="case-reason"
                          value={caseStudyReason}
                          onChange={(e) => setCaseStudyReason(e.target.value)}
                          placeholder="Explain how this case study will help the community..."
                          className="bg-gray-700 border-gray-600 text-white mt-2"
                          rows={3}
                        />
                      </div>
                      <div>
                        <Label htmlFor="case-file" className="text-gray-300">Case Study File</Label>
                        <Input
                          id="case-file"
                          type="file"
                          onChange={(e) => setCaseStudyFile(e.target.files?.[0] || null)}
                          className="bg-gray-700 border-gray-600 text-white mt-2"
                          accept=".pdf,.doc,.docx,.txt"
                        />
                      </div>
                      <div className="text-xs text-gray-500">
                        Files are processed in accordance with GDPR. Only approved case studies will be published.
                      </div>
                    </div>
                    <DialogFooter>
                      <Button variant="outline" onClick={() => setShowCaseStudyDialog(false)}>Cancel</Button>
                      <Button 
                        onClick={handleCaseStudySubmit}
                        disabled={!caseStudyFile || isSubmittingCaseStudy}
                        className="bg-purple-600 hover:bg-purple-700"
                      >
                        {isSubmittingCaseStudy ? 'Submitting...' : 'Submit Case Study'}
                      </Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>
                
                {/* Blog Editor Dialog */}
                <Dialog open={showBlogEditorDialog} onOpenChange={setShowBlogEditorDialog}>
                  <DialogContent className="bg-gray-800 border-gray-700 max-w-4xl max-h-[90vh] overflow-y-auto">
                    <DialogHeader>
                      <DialogTitle className="text-white">Submit Blog Article</DialogTitle>
                      <DialogDescription className="text-gray-400">
                        Write a thought leadership article for the RespectUs community
                      </DialogDescription>
                    </DialogHeader>
                    <div className="space-y-4">
                      <div>
                        <Label htmlFor="blog-title" className="text-gray-300">Article Title</Label>
                        <Input
                          id="blog-title"
                          value={blogTitle}
                          onChange={(e) => setBlogTitle(e.target.value)}
                          placeholder="Enter your article title..."
                          className="bg-gray-700 border-gray-600 text-white mt-2"
                        />
                      </div>
                      <div>
                        <Label htmlFor="blog-summary" className="text-gray-300">Summary</Label>
                        <Textarea
                          id="blog-summary"
                          value={blogSummary}
                          onChange={(e) => setBlogSummary(e.target.value)}
                          placeholder="Brief summary of your article..."
                          className="bg-gray-700 border-gray-600 text-white mt-2"
                          rows={2}
                        />
                      </div>
                      <div>
                        <Label htmlFor="blog-content" className="text-gray-300">Article Content</Label>
                        <Textarea
                          id="blog-content"
                          value={blogContent}
                          onChange={(e) => setBlogContent(e.target.value)}
                          placeholder="Write your article content here... You can use Markdown formatting."
                          className="bg-gray-700 border-gray-600 text-white mt-2"
                          rows={15}
                        />
                      </div>
                      <div>
                        <Label htmlFor="blog-tags" className="text-gray-300">Tags (comma-separated)</Label>
                        <Input
                          id="blog-tags"
                          value={blogTags}
                          onChange={(e) => setBlogTags(e.target.value)}
                          placeholder="e.g., export control, sanctions, compliance, GDPR"
                          className="bg-gray-700 border-gray-600 text-white mt-2"
                        />
                      </div>
                      <div className="text-xs text-gray-500 ">
                        Your article will be reviewed by our editorial team before publication.
                      </div>
                    </div>
                    <DialogFooter>
                      <Button variant="outline" onClick={() => setShowBlogEditorDialog(false)}>Cancel</Button>
                      <Button 
                        onClick={handleBlogSubmit}
                        disabled={!blogTitle || !blogContent || isSubmittingBlog}
                        className="bg-orange-600 hover:bg-orange-700"
                      >
                        {isSubmittingBlog ? 'Submitting...' : 'Submit Article'}
                      </Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>

      {/* Save Article Dialog */}
      <SaveArticleDialog
        isOpen={showSaveArticleDialog}
        onClose={() => setShowSaveArticleDialog(false)}
        document={selectedDocumentForSave}
        onSaved={handleSaveSuccess}
      />
    </div>
  );
};

export default KnowledgeBase;
