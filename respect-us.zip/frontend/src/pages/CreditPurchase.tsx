
import React, { useState, useEffect } from 'react';
import { Coins, CreditCard, Check, X, Loader2, Star, Gift } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Separator } from '@/components/ui/separator';
import { useUserGuardContext } from 'app/auth';
import { useCreditBalance } from 'utils/useCreditBalance';
import brain from 'brain';
import { toast } from 'sonner';

interface CreditPackage {
  id: number;
  name: string;
  credits: number;
  price_cents: number;
  currency: string;
  discount_percentage: number;
  is_active: boolean;
  expiry_months: number;
}

interface PurchaseState {
  selectedPackage: CreditPackage | null;
  isProcessing: boolean;
  paymentStatus: 'idle' | 'processing' | 'success' | 'error';
  errorMessage: string | null;
}

export default function CreditPurchase() {
  const { user } = useUserGuardContext();
  const { balance, refreshBalance } = useCreditBalance();
  const [packages, setPackages] = useState<CreditPackage[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [purchaseState, setPurchaseState] = useState<PurchaseState>({
    selectedPackage: null,
    isProcessing: false,
    paymentStatus: 'idle',
    errorMessage: null
  });

  useEffect(() => {
    fetchCreditPackages();
  }, []);

  const fetchCreditPackages = async () => {
    try {
      setIsLoading(true);
      const response = await brain.get_credit_packages();
      const data = await response.json();
      setPackages(data);
    } catch (error) {
      console.error('Failed to fetch credit packages:', error);
      toast.error('Failed to load credit packages');
    } finally {
      setIsLoading(false);
    }
  };

  const handlePackageSelect = (pkg: CreditPackage) => {
    setPurchaseState(prev => ({
      ...prev,
      selectedPackage: pkg,
      paymentStatus: 'idle',
      errorMessage: null
    }));
  };

  const processPurchase = async () => {
    if (!purchaseState.selectedPackage) return;

    try {
      setPurchaseState(prev => ({ ...prev, isProcessing: true, paymentStatus: 'processing' }));
      
      // Create payment intent
      const paymentResponse = await brain.create_payment_intent({
        package_id: purchaseState.selectedPackage.id,
        credits: purchaseState.selectedPackage.credits,
        amount_cents: purchaseState.selectedPackage.price_cents
      });
      
      const paymentData = await paymentResponse.json();
      
      if (paymentData.success) {
        // For demo purposes, simulate successful payment
        // In production, this would integrate with Stripe Elements
        await new Promise(resolve => setTimeout(resolve, 2000));
        
        // Process the credit purchase
        const purchaseResponse = await brain.admin_adjust_credits({
          user_id: user.sub,
          amount: purchaseState.selectedPackage.credits,
          reason: `Credit package purchase: ${purchaseState.selectedPackage.name}`
        });
        
        const purchaseResult = await purchaseResponse.json();
        
        if (purchaseResult.success) {
          setPurchaseState(prev => ({ ...prev, paymentStatus: 'success' }));
          toast.success(`Successfully purchased ${purchaseState.selectedPackage.credits} credits!`);
          refreshBalance();
          
          // Reset after success
          setTimeout(() => {
            setPurchaseState({
              selectedPackage: null,
              isProcessing: false,
              paymentStatus: 'idle',
              errorMessage: null
            });
          }, 3000);
        } else {
          throw new Error('Failed to process credit purchase');
        }
      } else {
        throw new Error(paymentData.message || 'Payment failed');
      }
    } catch (error) {
      console.error('Purchase failed:', error);
      setPurchaseState(prev => ({
        ...prev,
        paymentStatus: 'error',
        errorMessage: error instanceof Error ? error.message : 'Purchase failed'
      }));
      toast.error('Purchase failed. Please try again.');
    } finally {
      setPurchaseState(prev => ({ ...prev, isProcessing: false }));
    }
  };

  const formatPrice = (priceInCents: number, currency: string) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: currency,
      minimumFractionDigits: 2
    }).format(priceInCents / 100);
  };

  const formatPriceWithVATNotice = (priceInCents: number, currency: string) => {
    const basePrice = new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: currency,
      minimumFractionDigits: 2
    }).format(priceInCents / 100);
    return `${basePrice} + VAT if applicable`;
  };

  const calculateValuePerCredit = (priceInCents: number, credits: number) => {
    return (priceInCents / 100 / credits).toFixed(4);
  };

  const getMostPopularIndex = () => {
    // Mark the middle package as most popular
    return Math.floor(packages.length / 2);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-950 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-8 h-8 animate-spin text-blue-400 mx-auto mb-4" />
          <p className="text-gray-400">Loading credit packages...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-950 text-white p-6">
      <div className="max-w-6xl mx-auto space-y-8">
        {/* Header */}
        <div className="text-center space-y-4">
          <h1 className="text-4xl font-bold text-white">Purchase Credits</h1>
          <p className="text-xl text-gray-400 max-w-2xl mx-auto">
            Power your compliance workflows with our flexible credit system. 
            Pay only for what you use, when you use it.
          </p>
          
          {balance && (
            <div className="inline-flex items-center space-x-2 bg-gray-800 px-4 py-2 rounded-lg">
              <Coins className="w-5 h-5 text-purple-400" />
              <span className="text-gray-300">Current Balance:</span>
              <span className="font-bold text-purple-400">{balance.current_balance.toLocaleString()}</span>
              <span className="text-gray-400">credits</span>
            </div>
          )}
        </div>

        {/* Payment Status */}
        {purchaseState.paymentStatus === 'processing' && (
          <Alert className="bg-blue-900/20 border-blue-500/30">
            <Loader2 className="w-4 h-4 animate-spin" />
            <AlertDescription className="text-blue-300">
              Processing your payment... Please wait.
            </AlertDescription>
          </Alert>
        )}
        
        {purchaseState.paymentStatus === 'success' && (
          <Alert className="bg-green-900/20 border-green-500/30">
            <Check className="w-4 h-4" />
            <AlertDescription className="text-green-300">
              Payment successful! Your credits have been added to your account.
            </AlertDescription>
          </Alert>
        )}
        
        {purchaseState.paymentStatus === 'error' && (
          <Alert className="bg-red-900/20 border-red-500/30">
            <X className="w-4 h-4" />
            <AlertDescription className="text-red-300">
              {purchaseState.errorMessage}
            </AlertDescription>
          </Alert>
        )}

        {/* Credit Packages */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {packages.map((pkg, index) => {
            const isSelected = purchaseState.selectedPackage?.id === pkg.id;
            const isMostPopular = index === getMostPopularIndex();
            const pricePerCredit = calculateValuePerCredit(pkg.price_cents, pkg.credits);
            
            return (
              <Card 
                key={pkg.id} 
                className={`relative transition-all duration-300 cursor-pointer ${
                  isSelected 
                    ? 'bg-purple-900/30 border-purple-500 ring-2 ring-purple-500/50' 
                    : 'bg-gray-900 border-gray-800 hover:border-gray-700'
                } ${isMostPopular ? 'ring-2 ring-yellow-500/50' : ''}`}
                onClick={() => handlePackageSelect(pkg)}
              >
                {isMostPopular && (
                  <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                    <Badge className="bg-yellow-500 text-black font-medium px-3 py-1">
                      <Star className="w-3 h-3 mr-1" />
                      Most Popular
                    </Badge>
                  </div>
                )}
                
                <CardHeader className="text-center pb-4">
                  <CardTitle className="text-xl font-bold text-white">{pkg.name}</CardTitle>
                  
                  <div className="space-y-2">
                    <div className="text-3xl font-bold text-purple-400">
                      {pkg.credits.toLocaleString()}
                      <span className="text-sm text-gray-400 font-normal ml-1">credits</span>
                    </div>
                    
                    <div className="text-2xl font-bold text-white">
                      {formatPriceWithVATNotice(pkg.price_cents, pkg.currency)}
                    </div>
                    
                    <div className="text-sm text-gray-400">
                      {formatPrice(Number.parseFloat(pricePerCredit) * 100, pkg.currency)} per credit + VAT if applicable
                    </div>
                  </div>
                  
                  {pkg.discount_percentage > 0 && (
                    <Badge className="bg-green-500/20 text-green-400 border-green-500/30">
                      <Gift className="w-3 h-3 mr-1" />
                      {pkg.discount_percentage}% OFF
                    </Badge>
                  )}
                </CardHeader>
                
                <CardContent className="space-y-4">
                  <Separator className="bg-gray-700" />
                  
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between text-gray-300">
                      <span>Credits:</span>
                      <span className="font-medium">{pkg.credits.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between text-gray-300">
                      <span>Valid for:</span>
                      <span className="font-medium">{pkg.expiry_months} months</span>
                    </div>
                    <div className="flex justify-between text-gray-300">
                      <span>Value per credit:</span>
                      <span className="font-medium">{formatPrice(Number.parseFloat(pricePerCredit) * 100, pkg.currency)} + VAT if applicable</span>
                    </div>
                  </div>
                  
                  <Button 
                    className={`w-full transition-all duration-300 ${
                      isSelected 
                        ? 'bg-purple-600 hover:bg-purple-700 text-white' 
                        : 'bg-gray-800 hover:bg-gray-700 text-gray-300'
                    }`}
                    onClick={(e) => {
                      e.stopPropagation();
                      handlePackageSelect(pkg);
                    }}
                  >
                    {isSelected ? (
                      <>
                        <Check className="w-4 h-4 mr-2" />
                        Selected
                      </>
                    ) : (
                      'Select Package'
                    )}
                  </Button>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Purchase Action */}
        {purchaseState.selectedPackage && (
          <Card className="bg-gray-900 border-gray-800">
            <CardHeader>
              <CardTitle className="text-white flex items-center space-x-2">
                <CreditCard className="w-5 h-5" />
                <span>Complete Purchase</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="bg-gray-800 p-4 rounded-lg space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-gray-300">Package:</span>
                  <span className="font-medium text-white">{purchaseState.selectedPackage.name}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-300">Credits:</span>
                  <span className="font-medium text-purple-400">
                    {purchaseState.selectedPackage.credits.toLocaleString()}
                  </span>
                </div>
                <div className="flex justify-between items-center text-lg">
                  <span className="text-gray-300">Total:</span>
                  <span className="font-bold text-white">
                    {formatPriceWithVATNotice(purchaseState.selectedPackage.price_cents, purchaseState.selectedPackage.currency)}
                  </span>
                </div>
              </div>
              
              <div className="flex space-x-4">
                <Button 
                  variant="outline" 
                  className="flex-1 border-gray-700 text-gray-300 hover:bg-gray-800"
                  onClick={() => setPurchaseState(prev => ({ ...prev, selectedPackage: null }))}
                  disabled={purchaseState.isProcessing}
                >
                  Cancel
                </Button>
                <Button 
                  className="flex-1 bg-purple-600 hover:bg-purple-700"
                  onClick={processPurchase}
                  disabled={purchaseState.isProcessing || purchaseState.paymentStatus === 'processing'}
                >
                  {purchaseState.isProcessing ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Processing...
                    </>
                  ) : (
                    <>
                      <CreditCard className="w-4 h-4 mr-2" />
                      Purchase Credits
                    </>
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>
        )}
        
        {/* Help Text */}
        <div className="text-center text-gray-400 text-sm space-y-2">
          <p>Credits never expire and can be used across all compliance modules.</p>
          <p>Secure payment processing powered by Stripe. Your data is protected.</p>
        </div>
      </div>
    </div>
  );
}
