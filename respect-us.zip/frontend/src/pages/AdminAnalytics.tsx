import React from 'react';
import AdminAnalyticsDashboard from 'components/AdminAnalyticsDashboard';

const AdminAnalytics: React.FC = () => {
  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <AdminAnalyticsDashboard />
      </div>
    </div>
  );
};

export default AdminAnalytics;
