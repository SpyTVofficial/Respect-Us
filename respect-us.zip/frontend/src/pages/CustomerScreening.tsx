
import React, { useState, useEffect } from 'react';
import { useUserGuardContext } from "app/auth";
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { toast } from 'sonner';
import CustomerProfiles from '../components/CustomerProfiles';
import TestButton from '../components/TestButton';
import brain from 'brain';
import { CustomerProfile, ScreeningResult, ScreeningAlert } from '../brain/data-contracts';
import Navigation from 'components/Navigation';
import { Users } from 'lucide-react';

// Import all extracted components
import CustomerList from 'components/CustomerList';
import ScreeningResults from 'components/ScreeningResults';
import ScreeningAlerts from 'components/ScreeningAlerts';
import ScreeningAnalytics from 'components/ScreeningAnalytics';
import CustomerDialogs from 'components/CustomerDialogs';
import ScreeningDetails from 'components/ScreeningDetails';

const CustomerScreening = () => {
  console.log('CustomerScreening component loading...');
  const { user } = useUserGuardContext();
  
  // Core state
  const [customers, setCustomers] = useState<CustomerProfile[]>([]);
  const [screeningResults, setScreeningResults] = useState<ScreeningResult[]>([]);
  const [customerScreeningHistory, setCustomerScreeningHistory] = useState<ScreeningResult[]>([]);
  const [alerts, setAlerts] = useState<ScreeningAlert[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('screening'); // Main tab
  const [activeScreeningSubTab, setActiveScreeningSubTab] = useState('results'); // Subtab for screening
  
  // Customer operation loading states
  const [customerOperationLoading, setCustomerOperationLoading] = useState(false);
  
  // Mobile responsiveness state
  const [isMobile, setIsMobile] = useState(false);
  const [showMobileMenu, setShowMobileMenu] = useState(false);
  
  // Selection state
  const [selectedCustomer, setSelectedCustomer] = useState<CustomerProfile | null>(null);
  const [selectedScreening, setSelectedScreening] = useState<ScreeningResult | null>(null);
  const [selectedCustomerIds, setSelectedCustomerIds] = useState<number[]>([]);
  
  // Dialog state
  const [showAddCustomer, setShowAddCustomer] = useState(false);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [showHistoryDialog, setShowHistoryDialog] = useState(false);
  const [showScreeningDetails, setShowScreeningDetails] = useState(false);
  
  // Form state
  const [searchQuery, setSearchQuery] = useState('');
  const [customerForm, setCustomerForm] = useState({
    customer_name: '',
    customer_type: 'individual',
    legal_name: '',
    aliases: [],
    country: '',
    city: '',
    postal_code: '',
    address: '',
    date_of_birth: '',
    incorporation_date: '',
    registration_number: '',
    tax_id: '',
    website: '',
    business_type: '',
    risk_category: 'standard',
    notes: '',
    email: ''
  });
  
  // Screening configuration state
  const [screeningThreshold, setScreeningThreshold] = useState(85);
  const [enableVersionedScreening, setEnableVersionedScreening] = useState(false);
  const [screeningDate, setScreeningDate] = useState('');
  const [forceRescreen, setForceRescreen] = useState(false);
  const [screeningNotes, setScreeningNotes] = useState('');
  const [isGeneratingPdf, setIsGeneratingPdf] = useState(false);

  // Add missing sorting state variables
  const [sortField, setSortField] = useState<string>('customer_name');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');

  // Load data on component mount
  useEffect(() => {
    loadData();
  }, []);

  // Mobile responsiveness detection
  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768);
    };
    
    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  // Close mobile menu when tab changes
  useEffect(() => {
    setShowMobileMenu(false);
  }, [activeTab]);

  const loadData = async () => {
    try {
      setLoading(true);
      console.log('📋 Loading customers...');
      const response = await brain.list_customers({});
      if (response.ok) {
        const data = await response.json();
        setCustomers(data || []);
        console.log('✅ Customers loaded:', data?.length || 0);
      }
    } catch (error) {
      console.error('❌ Error loading customers:', error);
      toast.error('Failed to load customers');
    } finally {
      setLoading(false);
    }
  };

  const loadScreeningResults = async () => {
    try {
      console.log('🔍 Loading screening results...');
      // Note: There's no list_screening_results endpoint, so we'll load an empty array for now
      // In a real implementation, you might get screening results from customer history or another endpoint
      setScreeningResults([]);
      console.log('✅ Screening results loaded: 0 (no endpoint available)');
    } catch (error) {
      console.error('❌ Error loading screening results:', error);
      toast.error('Failed to load screening results');
    } finally {
      setLoading(false);
    }
  };

  const loadAlerts = async () => {
    try {
      console.log('🚨 Loading alerts...');
      const response = await brain.get_screening_alerts({});
      if (response.ok) {
        const data = await response.json();
        setAlerts(data || []);
        console.log('✅ Alerts loaded:', data?.length || 0);
      }
    } catch (error) {
      console.error('❌ Error loading alerts:', error);
    }
  };

  // Customer management handlers
  const handleAddCustomer = async () => {
    try {
      setCustomerOperationLoading(true);
      console.log('👤 Adding customer:', customerForm);
      
      // Prepare customer data, converting empty date strings to null
      const customerData = {
        ...customerForm,
        date_of_birth: customerForm.date_of_birth || null,
        incorporation_date: customerForm.incorporation_date || null,
        legal_name: customerForm.legal_name || null,
        country: customerForm.country || null,
        city: customerForm.city || null,
        postal_code: customerForm.postal_code || null,
        address: customerForm.address || null,
        registration_number: customerForm.registration_number || null,
        tax_id: customerForm.tax_id || null,
        website: customerForm.website || null,
        business_type: customerForm.business_type || null,
        notes: customerForm.notes || null,
        email: customerForm.email || null
      };
      
      const response = await brain.create_customer(customerData);
      if (response.ok) {
        const newCustomer = await response.json();
        setCustomers(prev => [...prev, newCustomer]);
        setCustomerForm({
          customer_name: '',
          customer_type: 'individual',
          legal_name: '',
          aliases: [],
          country: '',
          city: '',
          postal_code: '',
          address: '',
          date_of_birth: '',
          incorporation_date: '',
          registration_number: '',
          tax_id: '',
          website: '',
          business_type: '',
          risk_category: 'standard',
          notes: '',
          email: ''
        });
        setShowAddCustomer(false);
        toast.success('Customer added successfully!');
      }
    } catch (error) {
      console.error('❌ Error adding customer:', error);
      toast.error('Failed to add customer');
    } finally {
      setCustomerOperationLoading(false);
    }
  };

  const handleEditCustomer = (customer: CustomerProfile) => {
    setSelectedCustomer(customer);
    setShowEditDialog(true);
  };

  const handleUpdateCustomer = async () => {
    if (!selectedCustomer) return;
    
    try {
      setCustomerOperationLoading(true);
      console.log('🔄 Updating customer:', selectedCustomer);
      
      // Simulate update (add actual API call when available)
      const updatedCustomer = { ...selectedCustomer };
      setCustomers(prev => prev.map(c => c.id === selectedCustomer.id ? updatedCustomer : c));
      
      setShowEditDialog(false);
      setSelectedCustomer(null);
      toast.success('Customer updated successfully!');
    } catch (error) {
      console.error('❌ Error updating customer:', error);
      toast.error('Failed to update customer');
    } finally {
      setCustomerOperationLoading(false);
    }
  };

  const handleDeleteCustomer = async (customer: CustomerProfile) => {
    if (!confirm(`Are you sure you want to delete ${customer.customer_name}?`)) return;
    
    try {
      setLoading(true);
      console.log('🗑️ Deleting customer:', customer.id);
      
      const response = await brain.delete_customer({ customer_id: customer.id! });
      if (response.ok) {
        setCustomers(prev => prev.filter(c => c.id !== customer.id));
        toast.success('Customer deleted successfully!');
      }
    } catch (error) {
      console.error('❌ Error deleting customer:', error);
      toast.error('Failed to delete customer');
    } finally {
      setLoading(false);
    }
  };

  const handleScreenCustomer = async (customerId: number) => {
    try {
      setLoading(true);
      console.log('🔍 Screening customer:', customerId);
      
      const response = await brain.screen_customer({
        customer_id: customerId,
        threshold: screeningThreshold / 100,
        force_rescreen: forceRescreen,
        screening_date: screeningDate || undefined,
        notes: screeningNotes || undefined
      });
      
      if (response.ok) {
        const result = await response.json();
        setScreeningResults(prev => [result, ...prev]);
        toast.success('Customer screening completed!');
        
        // Reload alerts as new screening may have created alerts
        loadAlerts();
      }
    } catch (error) {
      console.error('❌ Error screening customer:', error);
      toast.error('Failed to screen customer');
    } finally {
      setLoading(false);
    }
  };

  const handleShowHistory = async (customer: CustomerProfile) => {
    try {
      console.log('📊 Loading history for customer:', customer.id);
      const response = await brain.get_customer_screening_history({ customer_id: customer.id! });
      
      if (response.ok) {
        const data = await response.json();
        setCustomerScreeningHistory(data.history || []);
        setSelectedCustomer(customer);
        setShowHistoryDialog(true);
      }
    } catch (error) {
      console.error('❌ Error loading customer history:', error);
      toast.error('Failed to load customer history');
    }
  };

  const handleBulkScreen = async () => {
    if (selectedCustomerIds.length === 0) return;
    
    try {
      setLoading(true);
      console.log('🔍 Bulk screening customers:', selectedCustomerIds);
      
      const response = await brain.bulk_screen_customers({
        customer_ids: selectedCustomerIds,
        threshold: screeningThreshold / 100,
        force_rescreen: forceRescreen
      });
      
      if (response.ok) {
        const results = await response.json();
        setScreeningResults(prev => [...(results.results || []), ...prev]);
        setSelectedCustomerIds([]);
        toast.success(`Successfully screened ${selectedCustomerIds.length} customers!`);
        
        // Reload alerts
        loadAlerts();
      }
    } catch (error) {
      console.error('❌ Error bulk screening:', error);
      toast.error('Failed to screen customers');
    } finally {
      setLoading(false);
    }
  };

  const handleBulkDelete = async () => {
    if (selectedCustomerIds.length === 0) return;
    if (!confirm(`Are you sure you want to delete ${selectedCustomerIds.length} customers?`)) return;
    
    try {
      setLoading(true);
      console.log('🗑️ Bulk deleting customers:', selectedCustomerIds);
      
      const response = await brain.bulk_delete_customers({ customer_ids: selectedCustomerIds });
      if (response.ok) {
        setCustomers(prev => prev.filter(c => !selectedCustomerIds.includes(c.id!)));
        setSelectedCustomerIds([]);
        toast.success(`Successfully deleted ${selectedCustomerIds.length} customers!`);
      }
    } catch (error) {
      console.error('❌ Error bulk deleting:', error);
      toast.error('Failed to delete customers');
    } finally {
      setLoading(false);
    }
  };

  const handleShowScreeningDetails = (result: ScreeningResult) => {
    setSelectedScreening(result);
    setShowScreeningDetails(true);
  };

  const handleQualifyMatch = async (matchIndex: number, qualification: string, notes: string) => {
    if (!selectedScreening) return;
    
    try {
      setLoading(true);
      console.log('✅ Qualifying match:', { matchIndex, qualification, notes });
      
      const response = await brain.qualify_screening_match({
        screening_id: selectedScreening.id!,
        match_index: matchIndex,
        qualification,
        notes
      });
      
      if (response.ok) {
        // Update the screening result with qualified match
        const updatedResult = await response.json();
        setScreeningResults(prev => 
          prev.map(r => r.id === selectedScreening.id ? updatedResult : r)
        );
        toast.success('Match qualification saved!');
      }
    } catch (error) {
      console.error('❌ Error qualifying match:', error);
      toast.error('Failed to save match qualification');
    } finally {
      setLoading(false);
    }
  };

  const downloadIndividualReport = async (customerId: number, screeningId?: number) => {
    setIsGeneratingPdf(true);
    try {
      console.log('📄 Generating individual PDF report for customer:', customerId);
      
      const response = await brain.generate_individual_report({
        customer_id: customerId,
        screening_id: screeningId,
        include_matches: true
      });
      
      if (response.ok) {
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `customer-${customerId}-report.pdf`;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        document.body.removeChild(a);
        toast.success('Report downloaded successfully!');
      }
    } catch (error) {
      console.error('❌ Error generating report:', error);
      toast.error('Failed to generate report');
    } finally {
      setIsGeneratingPdf(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      {/* Uniform Navigation */}
      <Navigation currentPage="customer_screening" />
      
      {/* Module-specific Sub-header */}
      <div className="bg-gray-950/80 backdrop-blur-lg border-b border-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-3 py-4">
            <div className="p-2 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-lg">
              <Users className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-white">Customer Screening</h1>
              <p className="text-sm text-gray-400">Screen customers against sanctions lists</p>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto p-6 space-y-6">
        {/* Debug Test Button */}
        <TestButton />
        
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-4 bg-slate-800/50 border-slate-600/50">
            <TabsTrigger value="screening" className="data-[state=active]:bg-blue-600/50 text-white">
              Customer Screening
            </TabsTrigger>
            <TabsTrigger value="customers" className="data-[state=active]:bg-blue-600/50 text-white">
              Customer Profiles
            </TabsTrigger>
            <TabsTrigger value="analytics" className="data-[state=active]:bg-blue-600/50 text-white">
              Analytics
            </TabsTrigger>
            <TabsTrigger value="alerts" className="data-[state=active]:bg-blue-600/50 text-white">
              Alerts
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="customers" className="space-y-6">
            <CustomerProfiles
              customers={customers}
              loading={loading}
              onRefresh={loadData}
            />
          </TabsContent>
          
          <TabsContent value="screening" className="space-y-6">
            <div className="text-white p-6">Screening content here</div>
          </TabsContent>
          
          <TabsContent value="analytics" className="space-y-6">
            <div className="text-white p-6">Analytics content here</div>
          </TabsContent>
          
          <TabsContent value="alerts" className="space-y-6">
            <div className="text-white p-6">Alerts content here</div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default CustomerScreening;
