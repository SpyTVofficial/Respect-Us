

import React, { useState, useEffect } from 'react';
import { useUserGuardContext } from 'app/auth';
import brain from 'brain';
import { toast } from 'sonner';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Plus, Search, Upload, Download, Edit, Trash2, Eye, FileText } from 'lucide-react';
import type { 
  SanctionEntityResponse, 
  SanctionEntitiesResponse,
  SanctionEntityCreate,
  SanctionSourceResponse,
  BulkImportResponse
} from 'types';

const AdminSanctions = () => {
  const { user } = useUserGuardContext();
  const [entities, setEntities] = useState<SanctionEntityResponse[]>([]);
  const [sources, setSources] = useState<SanctionSourceResponse[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterJurisdiction, setFilterJurisdiction] = useState('all');
  const [filterRiskLevel, setFilterRiskLevel] = useState('all');
  const [filterEntityType, setFilterEntityType] = useState('all');
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [editingEntity, setEditingEntity] = useState<SanctionEntityResponse | null>(null);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [total, setTotal] = useState(0);

  // Form state for creating/editing entities
  const [formData, setFormData] = useState<Partial<SanctionEntityCreate>>({
    name: '',
    entity_type: 'person',
    aliases: [],
    sanctions_program: '',
    jurisdiction: '',
    risk_level: 'medium',
    description: '',
    source_list: '',
    details: {},
    status: 'active'
  });

  // Load sanctions entities
  const loadEntities = async () => {
    try {
      setLoading(true);
      const queryParams: any = {
        page,
        page_size: 20,
        status: 'active'
      };
      
      if (searchTerm) queryParams.search = searchTerm;
      if (filterJurisdiction && filterJurisdiction !== 'all') queryParams.jurisdiction = filterJurisdiction;
      if (filterRiskLevel && filterRiskLevel !== 'all') queryParams.risk_level = filterRiskLevel;
      if (filterEntityType && filterEntityType !== 'all') queryParams.entity_type = filterEntityType;

      const response = await brain.list_sanction_entities(queryParams);
      const data: SanctionEntitiesResponse = await response.json();
      
      setEntities(data.entities);
      setTotalPages(data.total_pages);
      setTotal(data.total);
      
    } catch (error) {
      console.error('Error loading sanctions entities:', error);
      toast.error('Failed to load sanctions entities');
    } finally {
      setLoading(false);
    }
  };

  // Load sanction sources statistics
  const loadSources = async () => {
    try {
      const response = await brain.get_sanction_sources();
      const data: SanctionSourceResponse[] = await response.json();
      setSources(data);
    } catch (error) {
      console.error('Error loading sanction sources:', error);
    }
  };

  useEffect(() => {
    loadEntities();
    loadSources();
  }, [page, searchTerm, filterJurisdiction, filterRiskLevel, filterEntityType]);

  // Handle form submission for create/edit
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      if (editingEntity) {
        // Update existing entity
        const response = await brain.update_sanction_entity(
          { entity_id: editingEntity.id },
          formData as any
        );
        
        if (response.ok) {
          toast.success('Sanction entity updated successfully');
          setEditingEntity(null);
        } else {
          toast.error('Failed to update sanction entity');
        }
      } else {
        // Create new entity
        const response = await brain.create_sanction_entity(formData as SanctionEntityCreate);
        
        if (response.ok) {
          toast.success('Sanction entity created successfully');
          setShowCreateDialog(false);
        } else {
          toast.error('Failed to create sanction entity');
        }
      }
      
      // Reset form and reload
      setFormData({
        name: '',
        entity_type: 'person',
        aliases: [],
        sanctions_program: '',
        jurisdiction: '',
        risk_level: 'medium',
        description: '',
        source_list: '',
        details: {},
        status: 'active'
      });
      
      loadEntities();
      loadSources();
      
    } catch (error) {
      console.error('Error saving sanction entity:', error);
      toast.error('Failed to save sanction entity');
    }
  };

  // Handle delete
  const handleDelete = async (entityId: string, entityName: string) => {
    if (!confirm(`Are you sure you want to deactivate "${entityName}"?`)) {
      return;
    }
    
    try {
      const response = await brain.delete_sanction_entity({
        entityId: entityId,
        hardDelete: false
      });
      
      if (response.ok) {
        toast.success('Sanction entity deactivated successfully');
        loadEntities();
        loadSources();
      } else {
        toast.error('Failed to deactivate sanction entity');
      }
    } catch (error) {
      console.error('Error deleting sanction entity:', error);
      toast.error('Failed to deactivate sanction entity');
    }
  };

  // Handle edit
  const handleEdit = (entity: SanctionEntityResponse) => {
    setEditingEntity(entity);
    setFormData({
      name: entity.name,
      entity_type: entity.entity_type,
      aliases: entity.aliases,
      sanctions_program: entity.sanctions_program,
      jurisdiction: entity.jurisdiction,
      risk_level: entity.risk_level,
      description: entity.description,
      source_list: entity.source_list,
      details: entity.details,
      status: entity.status
    });
  };

  // Handle export
  const handleExport = async (format: 'csv' | 'json') => {
    try {
      const queryParams: any = { format };
      if (filterJurisdiction && filterJurisdiction !== 'all') queryParams.jurisdiction = filterJurisdiction;
      
      const response = await brain.export_sanctions(queryParams);
      
      if (response.ok) {
        // Trigger download
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `sanctions_export_${new Date().toISOString().split('T')[0]}.${format}`;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        document.body.removeChild(a);
        
        toast.success(`Sanctions data exported as ${format.toUpperCase()}`);
      } else {
        toast.error('Failed to export sanctions data');
      }
    } catch (error) {
      console.error('Error exporting sanctions:', error);
      toast.error('Failed to export sanctions data');
    }
  };

  // Get risk level badge color
  const getRiskLevelColor = (riskLevel: string) => {
    switch (riskLevel) {
      case 'high': return 'bg-red-500';
      case 'medium': return 'bg-yellow-500';
      case 'low': return 'bg-green-500';
      default: return 'bg-gray-500';
    }
  };

  // Get entity type icon
  const getEntityTypeIcon = (entityType: string) => {
    switch (entityType) {
      case 'person': return '👤';
      case 'entity': return '🏢';
      case 'vessel': return '🚢';
      case 'aircraft': return '✈️';
      default: return '❓';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-black text-white p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
              Admin Sanctions Management
            </h1>
            <p className="text-gray-400 mt-2">
              Manage sanctions lists and watchlist data for customer screening
            </p>
          </div>
          
          <div className="flex gap-3">
            <Button
              onClick={() => handleExport('csv')}
              variant="outline"
              className="border-gray-600 text-gray-300 hover:bg-gray-700"
            >
              <Download className="w-4 h-4 mr-2" />
              Export CSV
            </Button>
            
            <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
              <DialogTrigger asChild>
                <Button className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700">
                  <Plus className="w-4 h-4 mr-2" />
                  Add Sanction Entity
                </Button>
              </DialogTrigger>
            </Dialog>
          </div>
        </div>

        <Tabs defaultValue="entities" className="space-y-6">
          <TabsList className="bg-gray-800 border-gray-700">
            <TabsTrigger value="entities" className="data-[state=active]:bg-gray-700">
              Sanction Entities ({total})
            </TabsTrigger>
            <TabsTrigger value="sources" className="data-[state=active]:bg-gray-700">
              Sources ({sources.length})
            </TabsTrigger>
          </TabsList>

          <TabsContent value="entities" className="space-y-6">
            {/* Filters */}
            <Card className="bg-gray-800/50 border-gray-700">
              <CardContent className="p-4">
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <div>
                    <Label htmlFor="search" className="text-gray-300 mb-2 block">Search</Label>
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                      <Input
                        id="search"
                        placeholder="Search entities..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="pl-10 bg-gray-700 border-gray-600 text-white"
                      />
                    </div>
                  </div>
                  
                  <div>
                    <Label htmlFor="jurisdiction" className="text-gray-300 mb-2 block">Jurisdiction</Label>
                    <Select value={filterJurisdiction} onValueChange={setFilterJurisdiction}>
                      <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                        <SelectValue placeholder="All jurisdictions" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All jurisdictions</SelectItem>
                        <SelectItem value="US (OFAC)">US (OFAC)</SelectItem>
                        <SelectItem value="EU">EU</SelectItem>
                        <SelectItem value="UK">UK</SelectItem>
                        <SelectItem value="UN">UN</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div>
                    <Label htmlFor="riskLevel" className="text-gray-300 mb-2 block">Risk Level</Label>
                    <Select value={filterRiskLevel} onValueChange={setFilterRiskLevel}>
                      <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                        <SelectValue placeholder="All risk levels" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All risk levels</SelectItem>
                        <SelectItem value="high">High</SelectItem>
                        <SelectItem value="medium">Medium</SelectItem>
                        <SelectItem value="low">Low</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div>
                    <Label htmlFor="entityType" className="text-gray-300 mb-2 block">Entity Type</Label>
                    <Select value={filterEntityType} onValueChange={setFilterEntityType}>
                      <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                        <SelectValue placeholder="All types" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All types</SelectItem>
                        <SelectItem value="person">Person</SelectItem>
                        <SelectItem value="entity">Entity</SelectItem>
                        <SelectItem value="vessel">Vessel</SelectItem>
                        <SelectItem value="aircraft">Aircraft</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Entities Table */}
            <Card className="bg-gray-800/50 border-gray-700">
              <CardContent className="p-0">
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow className="border-gray-700">
                        <TableHead className="text-gray-300">Entity</TableHead>
                        <TableHead className="text-gray-300">Type</TableHead>
                        <TableHead className="text-gray-300">Risk Level</TableHead>
                        <TableHead className="text-gray-300">Jurisdiction</TableHead>
                        <TableHead className="text-gray-300">Program</TableHead>
                        <TableHead className="text-gray-300">Source</TableHead>
                        <TableHead className="text-gray-300">Updated</TableHead>
                        <TableHead className="text-gray-300">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {loading ? (
                        <TableRow>
                          <TableCell colSpan={8} className="text-center py-8 text-gray-400">
                            Loading sanctions entities...
                          </TableCell>
                        </TableRow>
                      ) : entities.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={8} className="text-center py-8 text-gray-400">
                            No sanctions entities found
                          </TableCell>
                        </TableRow>
                      ) : (
                        entities.map((entity) => (
                          <TableRow key={entity.id} className="border-gray-700 hover:bg-gray-700/50">
                            <TableCell>
                              <div>
                                <div className="font-medium text-white">{entity.name}</div>
                                {entity.aliases.length > 0 && (
                                  <div className="text-sm text-gray-400">
                                    Aliases: {entity.aliases.join(', ')}
                                  </div>
                                )}
                              </div>
                            </TableCell>
                            <TableCell>
                              <div className="flex items-center gap-2">
                                <span className="text-lg">{getEntityTypeIcon(entity.entity_type)}</span>
                                <span className="capitalize text-gray-300">{entity.entity_type}</span>
                              </div>
                            </TableCell>
                            <TableCell>
                              <Badge className={`${getRiskLevelColor(entity.risk_level)} text-white`}>
                                {entity.risk_level.toUpperCase()}
                              </Badge>
                            </TableCell>
                            <TableCell className="text-gray-300">{entity.jurisdiction}</TableCell>
                            <TableCell className="text-gray-300 max-w-xs truncate">
                              {entity.sanctions_program}
                            </TableCell>
                            <TableCell className="text-gray-300">{entity.source_list}</TableCell>
                            <TableCell className="text-gray-300">
                              {new Date(entity.last_updated).toLocaleDateString()}
                            </TableCell>
                            <TableCell>
                              <div className="flex gap-2">
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => handleEdit(entity)}
                                  className="border-gray-600 text-gray-300 hover:bg-gray-700"
                                >
                                  <Edit className="w-3 h-3" />
                                </Button>
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => handleDelete(entity.id, entity.name)}
                                  className="border-red-600 text-red-400 hover:bg-red-900/30"
                                >
                                  <Trash2 className="w-3 h-3" />
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        ))
                      )}
                    </TableBody>
                  </Table>
                </div>
                
                {/* Pagination */}
                {totalPages > 1 && (
                  <div className="flex justify-center gap-2 p-4 border-t border-gray-700">
                    <Button
                      variant="outline"
                      disabled={page === 1}
                      onClick={() => setPage(page - 1)}
                      className="border-gray-600 text-gray-300 hover:bg-gray-700"
                    >
                      Previous
                    </Button>
                    <span className="flex items-center px-3 text-gray-300">
                      Page {page} of {totalPages}
                    </span>
                    <Button
                      variant="outline"
                      disabled={page === totalPages}
                      onClick={() => setPage(page + 1)}
                      className="border-gray-600 text-gray-300 hover:bg-gray-700"
                    >
                      Next
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="sources" className="space-y-6">
            {/* Sources Overview */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {sources.map((source) => (
                <Card key={`${source.jurisdiction}-${source.source_list}`} className="bg-gray-800/50 border-gray-700">
                  <CardHeader>
                    <CardTitle className="text-lg text-white">{source.source_list}</CardTitle>
                    <CardDescription className="text-gray-400">{source.jurisdiction}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-gray-400">Entities:</span>
                        <span className="text-white font-medium">{source.entity_count}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-400">Status:</span>
                        <Badge className={source.status === 'active' ? 'bg-green-500' : 'bg-gray-500'}>
                          {source.status}
                        </Badge>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-400">Last Updated:</span>
                        <span className="text-white text-sm">
                          {new Date(source.last_updated).toLocaleDateString()}
                        </span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>
        
        {/* Create/Edit Dialog */}
        <Dialog open={showCreateDialog || !!editingEntity} onOpenChange={(open) => {
          if (!open) {
            setShowCreateDialog(false);
            setEditingEntity(null);
            setFormData({
              name: '',
              entity_type: 'person',
              aliases: [],
              sanctions_program: '',
              jurisdiction: '',
              risk_level: 'medium',
              description: '',
              source_list: '',
              details: {},
              status: 'active'
            });
          }
        }}>
          <DialogContent className="bg-gray-800 border-gray-700 text-white max-w-2xl">
            <DialogHeader>
              <DialogTitle>
                {editingEntity ? 'Edit Sanction Entity' : 'Create Sanction Entity'}
              </DialogTitle>
              <DialogDescription className="text-gray-400">
                {editingEntity ? 'Update the sanction entity details.' : 'Add a new entity to the sanctions list.'}
              </DialogDescription>
            </DialogHeader>
            
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="name" className="text-gray-300">Name *</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="bg-gray-700 border-gray-600 text-white"
                    required
                  />
                </div>
                
                <div>
                  <Label htmlFor="entity_type" className="text-gray-300">Entity Type *</Label>
                  <Select value={formData.entity_type} onValueChange={(value) => setFormData({ ...formData, entity_type: value })}>
                    <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="person">Person</SelectItem>
                      <SelectItem value="entity">Entity</SelectItem>
                      <SelectItem value="vessel">Vessel</SelectItem>
                      <SelectItem value="aircraft">Aircraft</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="jurisdiction" className="text-gray-300">Jurisdiction *</Label>
                  <Input
                    id="jurisdiction"
                    value={formData.jurisdiction}
                    onChange={(e) => setFormData({ ...formData, jurisdiction: e.target.value })}
                    placeholder="e.g., US (OFAC)"
                    className="bg-gray-700 border-gray-600 text-white"
                    required
                  />
                </div>
                
                <div>
                  <Label htmlFor="risk_level" className="text-gray-300">Risk Level *</Label>
                  <Select value={formData.risk_level} onValueChange={(value) => setFormData({ ...formData, risk_level: value })}>
                    <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="high">High</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="low">Low</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="sanctions_program" className="text-gray-300">Sanctions Program *</Label>
                  <Input
                    id="sanctions_program"
                    value={formData.sanctions_program}
                    onChange={(e) => setFormData({ ...formData, sanctions_program: e.target.value })}
                    placeholder="e.g., Ukraine-related sanctions"
                    className="bg-gray-700 border-gray-600 text-white"
                    required
                  />
                </div>
                
                <div>
                  <Label htmlFor="source_list" className="text-gray-300">Source List *</Label>
                  <Input
                    id="source_list"
                    value={formData.source_list}
                    onChange={(e) => setFormData({ ...formData, source_list: e.target.value })}
                    placeholder="e.g., OFAC SDN List"
                    className="bg-gray-700 border-gray-600 text-white"
                    required
                  />
                </div>
              </div>
              
              <div>
                <Label htmlFor="aliases" className="text-gray-300">Aliases (comma-separated)</Label>
                <Input
                  id="aliases"
                  value={Array.isArray(formData.aliases) ? formData.aliases.join(', ') : ''}
                  onChange={(e) => setFormData({ 
                    ...formData, 
                    aliases: e.target.value.split(',').map(alias => alias.trim()).filter(alias => alias) 
                  })}
                  placeholder="e.g., Ivan P., I. Petrov"
                  className="bg-gray-700 border-gray-600 text-white"
                />
              </div>
              
              <div>
                <Label htmlFor="description" className="text-gray-300">Description</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Detailed description of the sanctions entity..."
                  className="bg-gray-700 border-gray-600 text-white"
                  rows={3}
                />
              </div>
              
              <div className="flex justify-end gap-3 pt-4">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => {
                    setShowCreateDialog(false);
                    setEditingEntity(null);
                  }}
                  className="border-gray-600 text-gray-300 hover:bg-gray-700"
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700"
                >
                  {editingEntity ? 'Update Entity' : 'Create Entity'}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
};

export default AdminSanctions;
