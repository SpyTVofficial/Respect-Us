import React, { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import brain from 'brain';
import { toast } from 'sonner';
import {
  ArrowLeft,
  FileText,
  Calendar,
  MapPin,
  TrendingUp,
  AlertTriangle,
  CheckCircle,
  XCircle,
  Plus,
  Search,
  Filter,
  BookOpen,
  Star,
  MoreVertical,
  Eye,
  Share2,
  Bookmark,
  Grid,
  List,
  SortAsc,
  SortDesc,
  RefreshCw,
  Bell,
  Flag,
  Shield,
  Activity,
  BarChart3,
  PieChart,
  Settings,
  ExternalLink,
  ChevronLeft,
  ChevronRight,
  ChevronDown,
  ChevronUp,
  Split,
  GitCompare,
  Download,
  Copy,
  Maximize2,
  Minimize2
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';

interface Document {
  id: number;
  title: string;
  jurisdiction: string;
  regulation_type: string;
  effective_date?: string;
  content: string;
  sections: Array<{
    section_number: string;
    section_title: string;
    section_content: string;
    level: number;
  }>;
  metadata: {
    file_type: string;
    file_size: number;
    status: string;
    priority: string;
    summary?: string;
    keywords?: string[];
  };
}

interface ComparisonDifference {
  type: 'addition' | 'deletion' | 'modification';
  document_id: number;
  section?: string;
  original_text?: string;
  modified_text?: string;
  line_number?: number;
  confidence: number;
}

interface ComparisonResult {
  documents: Document[];
  differences: ComparisonDifference[];
  similarity_score: number;
  comparison_summary: {
    total_documents: number;
    jurisdictions: string[];
    regulation_types: string[];
    total_differences: number;
    similarity_breakdown: {
      high_similarity: number;
      medium_similarity: number;
      low_similarity: number;
    };
  };
  generated_at: string;
}

interface ComparisonSuggestion {
  suggestion_type: string;
  title: string;
  description: string;
  document_pairs: number[][];
  relevance_score: number;
}

const DocumentComparison = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const [selectedDocuments, setSelectedDocuments] = useState<number[]>([]);
  const [availableDocuments, setAvailableDocuments] = useState<Document[]>([]);
  const [comparisonResult, setComparisonResult] = useState<ComparisonResult | null>(null);
  const [suggestions, setSuggestions] = useState<ComparisonSuggestion[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isLoadingDocuments, setIsLoadingDocuments] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterJurisdiction, setFilterJurisdiction] = useState<string>('all');
  const [filterRegType, setFilterRegType] = useState<string>('all');
  const [viewMode, setViewMode] = useState<'side-by-side' | 'unified'>('side-by-side');
  const [expandedSections, setExpandedSections] = useState<Set<string>>(new Set());
  const [highlightDifferences, setHighlightDifferences] = useState(true);

  // Get pre-selected documents from URL params
  useEffect(() => {
    const docIds = searchParams.get('documents');
    if (docIds) {
      const ids = docIds.split(',').map(id => parseInt(id)).filter(id => !isNaN(id));
      setSelectedDocuments(ids);
    }
  }, [searchParams]);

  // Load available documents for selection
  useEffect(() => {
    loadAvailableDocuments();
    loadSuggestions();
  }, []);

  // Auto-compare when documents are pre-selected
  useEffect(() => {
    if (selectedDocuments.length >= 2 && !comparisonResult) {
      handleCompareDocuments();
    }
  }, [selectedDocuments, availableDocuments]);

  const loadAvailableDocuments = async () => {
    try {
      setIsLoadingDocuments(true);
      const response = await brain.list_documents({ 
        limit: 100, 
        status: 'published' 
      });
      const data = await response.json();
      setAvailableDocuments(data.documents || []);
    } catch (error) {
      console.error('Error loading documents:', error);
      toast.error('Failed to load documents');
    } finally {
      setIsLoadingDocuments(false);
    }
  };

  const loadSuggestions = async () => {
    try {
      // Try the newer API first, fallback to older one if needed
      const response = await brain.get_comparison_suggestions2({
        limit: 10
      });
      const data = await response.json();
      setSuggestions(data || []);
    } catch (error) {
      console.error('Error loading suggestions:', error);
      // Suggestions are not critical, so we don't show an error toast
    }
  };

  const handleCompareDocuments = async () => {
    if (selectedDocuments.length < 2) {
      toast.error('Please select at least 2 documents to compare');
      return;
    }

    if (selectedDocuments.length > 5) {
      toast.error('Maximum 5 documents can be compared at once');
      return;
    }

    try {
      setIsLoading(true);
      const response = await brain.compare_documents2({
        document_ids: selectedDocuments,
        comparison_type: 'full',
        highlight_differences: highlightDifferences
      });
      const data = await response.json();
      setComparisonResult(data);
      toast.success('Documents compared successfully');
    } catch (error) {
      console.error('Error comparing documents:', error);
      toast.error('Failed to compare documents');
    } finally {
      setIsLoading(false);
    }
  };

  const handleDocumentSelect = (documentId: number) => {
    setSelectedDocuments(prev => {
      if (prev.includes(documentId)) {
        return prev.filter(id => id !== documentId);
      } else if (prev.length < 5) {
        return [...prev, documentId];
      } else {
        toast.warning('Maximum 5 documents can be selected');
        return prev;
      }
    });
  };

  const handleSuggestionSelect = (suggestion: ComparisonSuggestion) => {
    if (suggestion.document_pairs.length > 0) {
      setSelectedDocuments(suggestion.document_pairs[0]);
    }
  };

  const toggleSectionExpansion = (sectionKey: string) => {
    setExpandedSections(prev => {
      const newSet = new Set(prev);
      if (newSet.has(sectionKey)) {
        newSet.delete(sectionKey);
      } else {
        newSet.add(sectionKey);
      }
      return newSet;
    });
  };

  const exportComparison = () => {
    if (!comparisonResult) return;
    
    const exportData = {
      comparison_result: comparisonResult,
      generated_at: new Date().toISOString(),
      export_type: 'document_comparison'
    };
    
    const blob = new Blob([JSON.stringify(exportData, null, 2)], {
      type: 'application/json'
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `document_comparison_${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const getDifferenceColor = (type: string) => {
    switch (type) {
      case 'addition': return 'bg-green-100 border-green-300 text-green-800';
      case 'deletion': return 'bg-red-100 border-red-300 text-red-800';
      case 'modification': return 'bg-yellow-100 border-yellow-300 text-yellow-800';
      default: return 'bg-gray-100 border-gray-300 text-gray-800';
    }
  };

  const getSimilarityColor = (score: number) => {
    if (score >= 0.8) return 'text-green-600';
    if (score >= 0.5) return 'text-yellow-600';
    return 'text-red-600';
  };

  const filteredDocuments = availableDocuments.filter(doc => {
    const matchesSearch = doc.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         doc.jurisdiction.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesJurisdiction = filterJurisdiction === 'all' || doc.jurisdiction === filterJurisdiction;
    const matchesRegType = filterRegType === 'all' || doc.regulation_type === filterRegType;
    return matchesSearch && matchesJurisdiction && matchesRegType;
  });

  const jurisdictions = Array.from(new Set(availableDocuments.map(doc => doc.jurisdiction)));
  const regulationTypes = Array.from(new Set(availableDocuments.map(doc => doc.regulation_type)));

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-950 via-gray-900 to-black text-white">
      {/* Header */}
      <div className="border-b border-gray-800 bg-gray-900/50 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => navigate('/knowledge-base')}
                className="text-gray-400 hover:text-white"
              >
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Knowledge Base
              </Button>
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-blue-600/20 rounded-lg">
                  <GitCompare className="h-6 w-6 text-blue-400" />
                </div>
                <div>
                  <h1 className="text-2xl font-bold text-white">Document Comparison</h1>
                  <p className="text-gray-400">Compare regulations across jurisdictions and versions</p>
                </div>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              {comparisonResult && (
                <Button
                  onClick={exportComparison}
                  variant="outline"
                  size="sm"
                  className="border-gray-600 text-gray-300 hover:bg-gray-800"
                >
                  <Download className="h-4 w-4 mr-2" />
                  Export
                </Button>
              )}
              <Button
                onClick={handleCompareDocuments}
                disabled={selectedDocuments.length < 2 || isLoading}
                className="bg-blue-600 hover:bg-blue-700"
              >
                {isLoading ? (
                  <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                ) : (
                  <GitCompare className="h-4 w-4 mr-2" />
                )}
                Compare Documents
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-8">
        {!comparisonResult ? (
          /* Document Selection Phase */
          <div className="space-y-8">
            {/* Suggestions */}
            {suggestions.length > 0 && (
              <Card className="bg-gray-900/50 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white flex items-center">
                    <Star className="h-5 w-5 mr-2 text-yellow-500" />
                    Suggested Comparisons
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                    {suggestions.slice(0, 3).map((suggestion, index) => (
                      <Card key={index} className="bg-gray-800/50 border-gray-600 hover:bg-gray-800/70 transition-colors cursor-pointer"
                            onClick={() => handleSuggestionSelect(suggestion)}>
                        <CardContent className="p-4">
                          <div className="flex items-start justify-between mb-2">
                            <h4 className="font-medium text-white">{suggestion.title}</h4>
                            <Badge variant="secondary" className="bg-yellow-600/20 text-yellow-400 text-xs">
                              {Math.round(suggestion.relevance_score * 100)}%
                            </Badge>
                          </div>
                          <p className="text-sm text-gray-400 mb-3">{suggestion.description}</p>
                          <div className="flex items-center text-xs text-gray-500">
                            <FileText className="h-3 w-3 mr-1" />
                            {suggestion.document_pairs.length} comparisons
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Document Selection */}
            <Card className="bg-gray-900/50 border-gray-700">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-white">Select Documents to Compare</CardTitle>
                  <div className="flex items-center space-x-4 text-sm text-gray-400">
                    <span>{selectedDocuments.length}/5 selected</span>
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="highlight-differences"
                        checked={highlightDifferences}
                        onCheckedChange={setHighlightDifferences}
                      />
                      <label htmlFor="highlight-differences" className="text-sm">Highlight differences</label>
                    </div>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                {/* Filters */}
                <div className="flex flex-wrap gap-4 mb-6">
                  <div className="flex-1 min-w-64">
                    <Input
                      placeholder="Search documents..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="bg-gray-800 border-gray-600 text-white"
                    />
                  </div>
                  <Select value={filterJurisdiction} onValueChange={setFilterJurisdiction}>
                    <SelectTrigger className="w-48 bg-gray-800 border-gray-600 text-white">
                      <SelectValue placeholder="All Jurisdictions" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Jurisdictions</SelectItem>
                      {jurisdictions.map(jurisdiction => (
                        <SelectItem key={jurisdiction} value={jurisdiction}>{jurisdiction}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <Select value={filterRegType} onValueChange={setFilterRegType}>
                    <SelectTrigger className="w-48 bg-gray-800 border-gray-600 text-white">
                      <SelectValue placeholder="All Types" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Types</SelectItem>
                      {regulationTypes.map(type => (
                        <SelectItem key={type} value={type}>{type}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Document List */}
                <div className="space-y-3 max-h-96 overflow-y-auto">
                  {isLoadingDocuments ? (
                    <div className="text-center py-8 text-gray-400">
                      <RefreshCw className="h-6 w-6 animate-spin mx-auto mb-2" />
                      Loading documents...
                    </div>
                  ) : filteredDocuments.length === 0 ? (
                    <div className="text-center py-8 text-gray-400">
                      <FileText className="h-12 w-12 mx-auto mb-2 opacity-50" />
                      No documents found matching your criteria
                    </div>
                  ) : (
                    filteredDocuments.map(doc => (
                      <div
                        key={doc.id}
                        className={`p-4 rounded-lg border cursor-pointer transition-all ${
                          selectedDocuments.includes(doc.id)
                            ? 'bg-blue-600/20 border-blue-500'
                            : 'bg-gray-800/50 border-gray-600 hover:bg-gray-800/70'
                        }`}
                        onClick={() => handleDocumentSelect(doc.id)}
                      >
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <div className="flex items-center space-x-2 mb-2">
                              <h4 className="font-medium text-white">{doc.title}</h4>
                              {selectedDocuments.includes(doc.id) && (
                                <CheckCircle className="h-4 w-4 text-blue-400" />
                              )}
                            </div>
                            <div className="flex items-center space-x-4 text-sm text-gray-400">
                              <div className="flex items-center">
                                <MapPin className="h-3 w-3 mr-1" />
                                {doc.jurisdiction}
                              </div>
                              <div className="flex items-center">
                                <BookOpen className="h-3 w-3 mr-1" />
                                {doc.regulation_type}
                              </div>
                              {doc.effective_date && (
                                <div className="flex items-center">
                                  <Calendar className="h-3 w-3 mr-1" />
                                  {new Date(doc.effective_date).toLocaleDateString()}
                                </div>
                              )}
                            </div>
                          </div>
                          <Badge
                            variant={doc.metadata?.status === 'published' ? 'default' : 'secondary'}
                            className={doc.metadata?.status === 'published' ? 'bg-green-600' : ''}
                          >
                            {doc.metadata?.status || 'unknown'}
                          </Badge>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        ) : (
          /* Comparison Results Phase */
          <div className="space-y-6">
            {/* Comparison Summary */}
            <Card className="bg-gray-900/50 border-gray-700">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-white">Comparison Results</CardTitle>
                  <div className="flex items-center space-x-3">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setViewMode(viewMode === 'side-by-side' ? 'unified' : 'side-by-side')}
                      className="border-gray-600 text-gray-300 hover:bg-gray-800"
                    >
                      {viewMode === 'side-by-side' ? <List className="h-4 w-4" /> : <Split className="h-4 w-4" />}
                      {viewMode === 'side-by-side' ? 'Unified View' : 'Side-by-Side'}
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setComparisonResult(null)}
                      className="border-gray-600 text-gray-300 hover:bg-gray-800"
                    >
                      New Comparison
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid gap-4 md:grid-cols-4">
                  <div className="bg-gray-800/50 p-4 rounded-lg">
                    <div className="text-2xl font-bold text-white mb-1">
                      {Math.round(comparisonResult.similarity_score * 100)}%
                    </div>
                    <div className="text-sm text-gray-400">Overall Similarity</div>
                    <Progress 
                      value={comparisonResult.similarity_score * 100} 
                      className="mt-2 h-2"
                    />
                  </div>
                  <div className="bg-gray-800/50 p-4 rounded-lg">
                    <div className="text-2xl font-bold text-white mb-1">
                      {comparisonResult.comparison_summary.total_differences}
                    </div>
                    <div className="text-sm text-gray-400">Total Differences</div>
                  </div>
                  <div className="bg-gray-800/50 p-4 rounded-lg">
                    <div className="text-2xl font-bold text-white mb-1">
                      {comparisonResult.comparison_summary.jurisdictions.length}
                    </div>
                    <div className="text-sm text-gray-400">Jurisdictions</div>
                  </div>
                  <div className="bg-gray-800/50 p-4 rounded-lg">
                    <div className="text-2xl font-bold text-white mb-1">
                      {comparisonResult.comparison_summary.regulation_types.length}
                    </div>
                    <div className="text-sm text-gray-400">Regulation Types</div>
                  </div>
                </div>

                {/* Document Headers */}
                <div className="mt-6 grid gap-4 md:grid-cols-2">
                  {comparisonResult.documents.map(doc => (
                    <Card key={doc.id} className="bg-gray-800/50 border-gray-600">
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between mb-2">
                          <h4 className="font-medium text-white">{doc.title}</h4>
                          <Badge className="bg-blue-600">{doc.jurisdiction}</Badge>
                        </div>
                        <div className="flex items-center space-x-4 text-sm text-gray-400">
                          <span>{doc.regulation_type}</span>
                          {doc.effective_date && (
                            <span>{new Date(doc.effective_date).toLocaleDateString()}</span>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Comparison Content */}
            <Tabs defaultValue="differences" className="space-y-4">
              <TabsList className="bg-gray-800 border-gray-700">
                <TabsTrigger value="differences" className="data-[state=active]:bg-gray-700">Differences</TabsTrigger>
                <TabsTrigger value="side-by-side" className="data-[state=active]:bg-gray-700">Side-by-Side</TabsTrigger>
                <TabsTrigger value="sections" className="data-[state=active]:bg-gray-700">Sections</TabsTrigger>
              </TabsList>

              <TabsContent value="differences">
                <Card className="bg-gray-900/50 border-gray-700">
                  <CardHeader>
                    <CardTitle className="text-white">Key Differences</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ScrollArea className="h-96">
                      <div className="space-y-4">
                        {comparisonResult.differences.length === 0 ? (
                          <div className="text-center py-8 text-gray-400">
                            <CheckCircle className="h-12 w-12 mx-auto mb-2 opacity-50" />
                            No significant differences found
                          </div>
                        ) : (
                          comparisonResult.differences.map((diff, index) => (
                            <div key={index} className={`p-4 rounded-lg border-l-4 ${getDifferenceColor(diff.type)}`}>
                              <div className="flex items-center justify-between mb-2">
                                <Badge variant="outline" className="capitalize">
                                  {diff.type}
                                </Badge>
                                <span className="text-xs text-gray-500">
                                  Confidence: {Math.round(diff.confidence * 100)}%
                                </span>
                              </div>
                              {diff.original_text && (
                                <div className="mb-2">
                                  <div className="text-xs text-gray-500 mb-1">Original:</div>
                                  <div className="text-sm bg-gray-800/50 p-2 rounded text-gray-300">
                                    {diff.original_text}
                                  </div>
                                </div>
                              )}
                              {diff.modified_text && (
                                <div>
                                  <div className="text-xs text-gray-500 mb-1">Modified:</div>
                                  <div className="text-sm bg-gray-800/50 p-2 rounded text-gray-300">
                                    {diff.modified_text}
                                  </div>
                                </div>
                              )}
                            </div>
                          ))
                        )}
                      </div>
                    </ScrollArea>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="side-by-side">
                <div className={`grid gap-4 ${comparisonResult.documents.length === 2 ? 'md:grid-cols-2' : 'grid-cols-1'}`}>
                  {comparisonResult.documents.map(doc => (
                    <Card key={doc.id} className="bg-gray-900/50 border-gray-700">
                      <CardHeader>
                        <CardTitle className="text-white text-lg">{doc.title}</CardTitle>
                        <div className="flex items-center space-x-2 text-sm text-gray-400">
                          <Badge className="bg-blue-600">{doc.jurisdiction}</Badge>
                          <span>{doc.regulation_type}</span>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <ScrollArea className="h-96">
                          <div className="prose prose-sm prose-invert max-w-none">
                            {doc.content || 'No content available'}
                          </div>
                        </ScrollArea>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </TabsContent>

              <TabsContent value="sections">
                <Card className="bg-gray-900/50 border-gray-700">
                  <CardHeader>
                    <CardTitle className="text-white">Document Sections</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ScrollArea className="h-96">
                      <div className="space-y-6">
                        {comparisonResult.documents.map(doc => (
                          <div key={doc.id}>
                            <h4 className="font-medium text-white mb-3">{doc.title}</h4>
                            <div className="space-y-2">
                              {doc.sections.length === 0 ? (
                                <div className="text-gray-400 text-sm">No sections available</div>
                              ) : (
                                doc.sections.map((section, sectionIndex) => {
                                  const sectionKey = `${doc.id}-${sectionIndex}`;
                                  const isExpanded = expandedSections.has(sectionKey);
                                  return (
                                    <div key={sectionIndex} className="bg-gray-800/50 rounded-lg">
                                      <button
                                        onClick={() => toggleSectionExpansion(sectionKey)}
                                        className="w-full flex items-center justify-between p-3 text-left hover:bg-gray-800/70"
                                      >
                                        <div>
                                          <span className="font-medium text-white">
                                            {section.section_number} {section.section_title}
                                          </span>
                                        </div>
                                        {isExpanded ? (
                                          <ChevronUp className="h-4 w-4 text-gray-400" />
                                        ) : (
                                          <ChevronDown className="h-4 w-4 text-gray-400" />
                                        )}
                                      </button>
                                      {isExpanded && (
                                        <div className="px-3 pb-3">
                                          <div className="text-sm text-gray-300 bg-gray-900/50 p-3 rounded">
                                            {section.section_content || 'No content available'}
                                          </div>
                                        </div>
                                      )}
                                    </div>
                                  );
                                })
                              )}
                            </div>
                          </div>
                        ))}
                      </div>
                    </ScrollArea>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        )}
      </div>
    </div>
  );
};

export default DocumentComparison;
