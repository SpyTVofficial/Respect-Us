import React, { useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  Target, 
  Scale, 
  Search, 
  Workflow, 
  AlertTriangle, 
  Shield, 
  Activity, 
  Globe, 
  Users, 
  Clock, 
  Download, 
  CheckCircle, 
  PlayCircle, 
  Eye, 
  ArrowLeft, 
  BookOpen, 
  Calendar, 
  Loader2,
  FileText,
  Building,
  ArrowRight,
  Zap,
  Filter,
  AlertCircle
} from 'lucide-react';
import { toast } from 'sonner';
import brain from 'brain';
import { useNavigate } from 'react-router-dom';
import {
  ProgramsProgram,
  DocumentAlertResponse,
  SanctionsTree as SanctionsTreeType,
  ClassificationWorkflow,
  TreeNode,
  WorkflowExecution
} from 'types';
import Navigation from 'components/Navigation';

interface SanctionProgram {
  id: string;
  name: string;
  jurisdiction: string;
  status: 'active' | 'updated' | 'new' | 'suspended';
  lastUpdated: string;
  entities: number;
  type: 'sectoral' | 'comprehensive' | 'targeted' | 'financial';
  description: string;
  flagEmoji: string;
}

interface SanctionNavigationPath {
  node: SanctionsNode;
  answer: string;
}

const SanctionsEmbargoes: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedJurisdiction, setSelectedJurisdiction] = useState('all');
  const [selectedType, setSelectedType] = useState('all');
  const [selectedStatus, setSelectedStatus] = useState('all');
  const [activeTab, setActiveTab] = useState('overview');
  const [loading, setLoading] = useState(false);
  
  // Document alerts state
  const [documentAlerts, setDocumentAlerts] = useState<DocumentAlertResponse[]>([]);
  const [alertsLoading, setAlertsLoading] = useState(false);
  const [alertFilters, setAlertFilters] = useState({
    status: 'all',
    severity: 'all'
  });
  const [alertStats, setAlertStats] = useState<any>(null);
  
  // Sanctions overview CMS content state
  const [sanctionsContent, setSanctionsContent] = useState<string>('');
  const [loadingContent, setLoadingContent] = useState(false);
  
  // Tree navigation state
  const [sanctionsTrees, setSanctionsTrees] = useState<SanctionsTreeType[]>([]);
  const [selectedTree, setSelectedTree] = useState<SanctionsTreeType | null>(null);
  const [currentNode, setCurrentNode] = useState<TreeNode | null>(null);
  const [currentOptions, setCurrentOptions] = useState<TreeNode[]>([]);
  const [selectedOption, setSelectedOption] = useState<string>('');
  const [navigationPath, setNavigationPath] = useState<SanctionNavigationPath[]>([]);
  const [finalAssessment, setFinalAssessment] = useState<TreeNode | null>(null);
  const [navigating, setNavigating] = useState(false);
  const [showTreeNavigation, setShowTreeNavigation] = useState(false);
  
  const [selectedProgram, setSelectedProgram] = useState<SanctionProgram | null>(null);

  // Workflow state
  const [workflows, setWorkflows] = useState<ClassificationWorkflow[]>([]);
  const [selectedWorkflow, setSelectedWorkflow] = useState<ClassificationWorkflow | null>(null);
  const [workflowLoading, setWorkflowLoading] = useState(false);
  const [workflowProgress, setWorkflowProgress] = useState<{
    currentStep: number;
    totalSteps: number;
    completedSteps: string[];
  } | null>(null);

  // Enhanced workflow execution state
  const [executingTree, setExecutingTree] = useState<any | null>(null);
  const [treeExecutionState, setTreeExecutionState] = useState<{
    currentNode: TreeNode | null;
    currentOptions: TreeNode[];
    selectedOption: string;
    navigationPath: SanctionNavigationPath[];
    treeProgress: number;
  } | null>(null);
  const [workflowResults, setWorkflowResults] = useState<any[]>([]);

  // Additional tree execution state for interactive navigation
  const [executingTreeType, setExecutingTreeType] = useState<'introduction' | 'classification' | null>(null);
  const [isExecutingTree, setIsExecutingTree] = useState(false);
  const [currentTreeNode, setCurrentTreeNode] = useState<any | null>(null);
  const [currentTreeOptions, setCurrentTreeOptions] = useState<any[]>([]);
  const [treeNavigationHistory, setTreeNavigationHistory] = useState<any[]>([]);
  const [treeResult, setTreeResult] = useState<string | null>(null);

  // Load published sanctions trees
  const loadPublishedSanctionsTrees = async () => {
    try {
      setLoading(true);
      const response = await brain.list_published_sanctions_trees();
      const treesData = await response.json();
      console.log('📋 Loaded sanctions trees:', treesData);
      setSanctionsTrees(treesData);
    } catch (error) {
      console.error('❌ Error loading sanctions trees:', error);
      toast.error('Failed to load sanctions trees');
    } finally {
      setLoading(false);
    }
  };

  // Start a sanctions tree assessment
  const startSanctionsTree = async (tree: SanctionsTreeType) => {
    try {
      setLoading(true);
      
      // Get the root nodes for the tree
      const response = await brain.get_published_sanctions_tree_nodes({ treeId: tree.id });
      const nodesData = await response.json();
      console.log('🌳 Tree nodes loaded:', nodesData);
      
      // Find the root node (is_root = true)
      const rootNode = nodesData.find((node: TreeNode) => node.is_root);
      if (!rootNode) {
        toast.error('No root node found for this sanctions tree');
        return;
      }
      
      // Get options for the root node
      const optionsResponse = await brain.get_published_sanctions_node_options({ 
        treeId: tree.id, 
        nodeId: rootNode.id 
      });
      const optionsData = await optionsResponse.json();
      console.log('🔗 Root node options:', optionsData);
      
      // Set up the navigation state
      setSelectedTree(tree);
      setCurrentNode(rootNode);
      setCurrentOptions(optionsData);
      setSelectedOption('');
      setNavigationPath([]);
      setFinalAssessment(null);
      setShowTreeNavigation(true);
      setActiveTab('assessment');
      
      toast.success(`Started sanctions assessment: ${tree.name}`);
    } catch (error) {
      console.error('❌ Error starting sanctions tree:', error);
      toast.error('Failed to start sanctions assessment');
    } finally {
      setLoading(false);
    }
  };

  // Navigate through the tree based on selected option
  const handleTreeNavigation = async () => {
    if (!selectedTree || !currentNode || !selectedOption) return;
    
    try {
      setNavigating(true);
      
      // Find the selected option data
      const selectedOptionData = currentOptions.find(opt => opt.id === selectedOption);
      if (!selectedOptionData) {
        toast.error('Selected option not found');
        return;
      }
      
      console.log('🧭 Navigating with option:', selectedOptionData);
      
      // Add current step to navigation path
      setNavigationPath(prev => [...prev, {
        node: currentNode,
        answer: selectedOptionData.option_text
      }]);
      
      // Check routing rule for next step
      if (selectedOptionData.routing_rule) {
        // Handle different routing rules
        if (selectedOptionData.routing_rule === 'ASSESSMENT_COMPLETE') {
          // Complete the assessment
          await completeAssessment(selectedOptionData);
          return;
        } else if (selectedOptionData.routing_rule.startsWith('NODE_')) {
          // Navigate to specific node
          const targetNodeKey = selectedOptionData.routing_rule.replace('NODE_', '');
          await navigateToNode(targetNodeKey);
          return;
        }
      }
      
      // Default: continue to next logical node or complete assessment
      await completeAssessment(selectedOptionData);
      
    } catch (error) {
      console.error('❌ Error navigating tree:', error);
      toast.error('Failed to navigate to next question');
    } finally {
      setNavigating(false);
    }
  };
  
  // Navigate to a specific node by key
  const navigateToNode = async (nodeKey: string) => {
    if (!selectedTree) return;
    
    try {
      // Get all nodes and find the target node
      const response = await brain.get_published_sanctions_tree_nodes({ treeId: selectedTree.id });
      const nodesData = await response.json();
      
      const targetNode = nodesData.find((node: TreeNode) => node.node_key === nodeKey);
      if (!targetNode) {
        toast.error(`Node ${nodeKey} not found`);
        return;
      }
      
      // Get options for the target node
      const optionsResponse = await brain.get_published_sanctions_node_options({ 
        treeId: selectedTree.id, 
        nodeId: targetNode.id 
      });
      const optionsData = await optionsResponse.json();
      
      // Update navigation state
      setCurrentNode(targetNode);
      setCurrentOptions(optionsData);
      setSelectedOption('');
      
    } catch (error) {
      console.error('❌ Error navigating to node:', error);
      toast.error('Failed to navigate to next question');
    }
  };
  
  // Complete the sanctions assessment
  const completeAssessment = async (finalOption: TreeNode) => {
    if (!selectedTree) return;
    
    try {
      // Create assessment request
      const assessmentRequest: ProgramsProgram = {
        tree_id: selectedTree.id,
        jurisdiction: selectedTree.jurisdiction,
        entity_name: 'Assessment Entity', // Could be made dynamic
        entity_type: 'corporation', // Could be made dynamic
        assessment_path: navigationPath.map(step => ({
          question: step.node.question_text || step.node.title,
          answer: step.answer
        }))
      };
      
      console.log('📊 Completing assessment:', assessmentRequest);
      
      const response = await brain.assess_sanctions_applicability(assessmentRequest);
      const assessmentResult = await response.json();
      
      console.log('✅ Assessment completed:', assessmentResult);
      
      setFinalAssessment(assessmentResult);
      setCurrentNode(null);
      setCurrentOptions([]);
      
      toast.success('Sanctions assessment completed!');
      
    } catch (error) {
      console.error('❌ Error completing assessment:', error);
      toast.error('Failed to complete sanctions assessment');
    }
  };
  
  // Reset tree navigation
  const resetTreeNavigation = () => {
    setSelectedTree(null);
    setCurrentNode(null);
    setCurrentOptions([]);
    setSelectedOption('');
    setNavigationPath([]);
    setFinalAssessment(null);
    setShowTreeNavigation(false);
    setActiveTab('overview');
  };
  
  // Load trees on component mount
  useEffect(() => {
    loadPublishedSanctionsTrees();
    loadPublishedWorkflows();
    loadDocumentAlerts();
    loadSanctionsContent();
  }, []);
  
  // Reload alerts when filters change
  useEffect(() => {
    if (activeTab === 'alerts') {
      loadDocumentAlerts();
    }
  }, [alertFilters, activeTab]);

  // Load published workflows
  const loadPublishedWorkflows = async () => {
    try {
      setWorkflowLoading(true);
      const response = await brain.list_workflows({ workflow_type: 'sanctions' });
      const workflowsData = await response.json();
      console.log('📋 Loaded sanctions workflows:', workflowsData);
      
      // API returns direct array when filtered, not wrapped in {workflows: []}
      const workflowsArray = Array.isArray(workflowsData) ? workflowsData : workflowsData.workflows || [];
      setWorkflows(workflowsArray);
    } catch (error) {
      console.error('❌ Error loading workflows:', error);
      toast.error('Failed to load workflows');
    } finally {
      setWorkflowLoading(false);
    }
  };

  // Start a workflow assessment
  const startWorkflow = async (workflow: ClassificationWorkflow) => {
    try {
      setWorkflowLoading(true);
      
      // Get detailed workflow information
      const response = await brain.get_published_workflow({ workflowId: workflow.id });
      const workflowData = await response.json();
      console.log('🚀 Starting workflow:', workflowData);
      
      setSelectedWorkflow(workflowData);
      setWorkflowProgress({
        currentStep: 1,
        totalSteps: (workflowData.introduction_trees?.length || 0) + (workflowData.classification_trees?.length || 0),
        completedSteps: []
      });
      
      setActiveTab('workflows');
      toast.success(`Started workflow: ${workflow.name}`);
    } catch (error) {
      console.error('❌ Error starting workflow:', error);
      toast.error('Failed to start workflow');
    } finally {
      setWorkflowLoading(false);
    }
  };

  // Reset workflow
  const resetWorkflow = () => {
    setSelectedWorkflow(null);
    setWorkflowProgress(null);
    setExecutingTree(null);
    setTreeExecutionState(null);
    setWorkflowResults([]);
  };

  // Start executing a specific tree in the workflow
  const startTreeExecution = async (tree: any, treeType: 'introduction' | 'classification') => {
    try {
      setLoading(true);
      console.log('🌳 Starting tree execution:', tree.name, 'Type:', treeType);
      
      let nodesResponse;
      let optionsResponse;
      
      if (treeType === 'introduction') {
        // Use introduction tree APIs
        nodesResponse = await brain.list_introduction_tree_nodes({ treeId: tree.id });
      } else {
        // Use sanctions tree APIs  
        nodesResponse = await brain.get_published_sanctions_tree_nodes({ treeId: tree.id });
      }
      
      const nodesData = await nodesResponse.json();
      console.log('📋 Tree nodes loaded:', nodesData);
      
      // Find the root node
      const rootNode = nodesData.find((node: any) => node.is_root);
      if (!rootNode) {
        toast.error('No root node found for this tree');
        return;
      }
      
      // Get options for the root node
      if (treeType === 'introduction') {
        optionsResponse = await brain.list_introduction_node_options({ 
          treeId: tree.id, 
          nodeId: rootNode.id 
        });
      } else {
        optionsResponse = await brain.get_published_sanctions_node_options({ 
          treeId: tree.id, 
          nodeId: rootNode.id 
        });
      }
      
      const optionsData = await optionsResponse.json();
      console.log('🔗 Root node options:', optionsData);
      
      // Set up tree execution state
      setExecutingTree({ ...tree, type: treeType });
      setTreeExecutionState({
        currentNode: rootNode,
        currentOptions: optionsData,
        selectedOption: '',
        navigationPath: [],
        treeProgress: 0
      });
      
      toast.success(`Started tree: ${tree.name}`);
    } catch (error) {
      console.error('❌ Error starting tree execution:', error);
      toast.error('Failed to start tree execution');
    } finally {
      setLoading(false);
    }
  };
  
  // Load document alerts
  const loadDocumentAlerts = async () => {
    setAlertsLoading(true);
    try {
      const response = await brain.get_document_analytics();
      if (response.status === 200) {
        const data = await response.json();
        setDocumentAlerts(data.templates || []);
        console.log('📋 Loaded document alerts:', data);
      }
    } catch (error) {
      console.error('❌ Error loading document alerts:', error);
    } finally {
      setAlertsLoading(false);
    }
  };

  // Load sanctions overview content
  const loadSanctionsContent = async () => {
    setLoadingContent(true);
    try {
      const response = await brain.get_classification_note_by_key({
        noteKey: 'sanctions_overview_explanation'
      });
      if (response.status === 200) {
        const data = await response.json();
        setSanctionsContent(data.content || '');
      }
    } catch (error) {
      console.error('Error loading sanctions content:', error);
    } finally {
      setLoadingContent(false);
    }
  };
  
  // Update alert status (acknowledge or resolve)
  const updateAlertStatus = async (alertId: number, status: 'acknowledged' | 'resolved') => {
    try {
      const statusUpdate: DocumentAlertResponse = {
        status: status,
        comment: `Alert ${status} via Sanctions & Embargoes module`
      };
      
      const response = await brain.update_alert_status({ alertId }, statusUpdate);
      const updatedAlert = await response.json();
      
      // Update the alert in the list
      setDocumentAlerts(prev => prev.map(alert => 
        alert.id === alertId ? updatedAlert : alert
      ));
      
      toast.success(`Alert ${status} successfully`);
      
      // Reload stats
      loadDocumentAlerts();
      
    } catch (error) {
      console.error(`❌ Error updating alert status:`, error);
      toast.error(`Failed to ${status} alert`);
    }
  };
  
  // Navigate to source document
  const viewSourceDocument = (documentId: number) => {
    // This would navigate to the Knowledge Base document
    // For now, we'll just show a toast with the document ID
    toast.info(`Navigate to Knowledge Base document ID: ${documentId}`);
  };
  
  // Sample data for demonstration
  const samplePrograms: SanctionProgram[] = [
    {
      id: '1',
      name: 'Russia Sanctions Program',
      jurisdiction: 'European Union',
      status: 'updated',
      lastUpdated: '2024-01-28',
      entities: 1247,
      type: 'comprehensive',
      description: 'Comprehensive sanctions targeting Russian individuals, entities, and sectors following geopolitical developments.',
      flagEmoji: '🇪🇺'
    },
    {
      id: '2',
      name: 'OFAC SDN List',
      jurisdiction: 'United States',
      status: 'active',
      lastUpdated: '2024-01-27',
      entities: 8932,
      type: 'comprehensive',
      description: 'Specially Designated Nationals and Blocked Persons List maintained by the Office of Foreign Assets Control.',
      flagEmoji: '🇺🇸'
    },
    {
      id: '3',
      name: 'Iran Nuclear Sanctions',
      jurisdiction: 'United Kingdom',
      status: 'active',
      lastUpdated: '2024-01-26',
      entities: 456,
      type: 'sectoral',
      description: 'Targeted sanctions on Iranian nuclear program and related entities.',
      flagEmoji: '🇬🇧'
    },
    {
      id: '4',
      name: 'North Korea Sanctions',
      jurisdiction: 'United Nations',
      status: 'active',
      lastUpdated: '2024-01-25',
      entities: 234,
      type: 'comprehensive',
      description: 'UN Security Council sanctions targeting North Korean nuclear and ballistic missile programs.',
      flagEmoji: '🇺🇳'
    }
  ];

  const sampleAlerts: ComplianceAlert[] = [
    {
      id: '1',
      type: 'new_sanctions',
      title: 'New EU Sanctions Package',
      description: '127 new entities added to EU sanctions list targeting technology sector',
      severity: 'high',
      timestamp: '2 hours ago',
      jurisdiction: 'European Union',
      flagEmoji: '🇪🇺'
    },
    {
      id: '2',
      type: 'entity_added',
      title: 'OFAC Updates SDN List',
      description: '15 individuals and 8 entities added to Specially Designated Nationals list',
      severity: 'medium',
      timestamp: '4 hours ago',
      jurisdiction: 'United States',
      flagEmoji: '🇺🇸'
    },
    {
      id: '3',
      type: 'delisting',
      title: 'Entity Removed from UK List',
      description: '3 entities delisted from UK financial sanctions following legal review',
      severity: 'low',
      timestamp: '1 day ago',
      jurisdiction: 'United Kingdom',
      flagEmoji: '🇬🇧'
    }
  ];

  const jurisdictions = [
    { value: 'all', label: 'All Jurisdictions' },
    { value: 'eu', label: 'European Union', emoji: '🇪🇺' },
    { value: 'us', label: 'United States', emoji: '🇺🇸' },
    { value: 'uk', label: 'United Kingdom', emoji: '🇬🇧' },
    { value: 'un', label: 'United Nations', emoji: '🇺🇳' },
    { value: 'ca', label: 'Canada', emoji: '🇨🇦' },
    { value: 'au', label: 'Australia', emoji: '🇦🇺' }
  ];

  const sanctionTypes = [
    { value: 'all', label: 'All Types' },
    { value: 'comprehensive', label: 'Comprehensive Sanctions' },
    { value: 'sectoral', label: 'Sectoral Sanctions' },
    { value: 'targeted', label: 'Targeted Sanctions' },
    { value: 'financial', label: 'Financial Sanctions' }
  ];

  const statusOptions = [
    { value: 'all', label: 'All Statuses' },
    { value: 'active', label: 'Active' },
    { value: 'updated', label: 'Recently Updated' },
    { value: 'new', label: 'New' },
    { value: 'suspended', label: 'Suspended' }
  ];

  const getStatusBadge = (status: string) => {
    const variants = {
      active: 'bg-green-500/20 text-green-400 border-green-500/30',
      updated: 'bg-amber-500/20 text-amber-400 border-amber-500/30',
      new: 'bg-blue-500/20 text-blue-400 border-blue-500/30',
      suspended: 'bg-red-500/20 text-red-400 border-red-500/30'
    };
    return variants[status as keyof typeof variants] || variants.active;
  };

  const getTypeBadge = (type: string) => {
    const variants = {
      comprehensive: 'bg-red-500/20 text-red-400 border-red-500/30',
      sectoral: 'bg-orange-500/20 text-orange-400 border-orange-500/30',
      targeted: 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30',
      financial: 'bg-purple-500/20 text-purple-400 border-purple-500/30'
    };
    return variants[type as keyof typeof variants] || variants.comprehensive;
  };

  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case 'critical':
        return <AlertTriangle className="h-4 w-4 text-red-400" />;
      case 'high':
        return <AlertTriangle className="h-4 w-4 text-red-400" />;
      case 'medium':
        return <AlertCircle className="h-4 w-4 text-amber-400" />;
      case 'low':
        return <CheckCircle className="h-4 w-4 text-green-400" />;
      default:
        return <AlertCircle className="h-4 w-4 text-gray-400" />;
    }
  };
  
  const getSeverityBadge = (severity: string) => {
    const variants = {
      critical: 'bg-red-500/20 text-red-400 border-red-500/30',
      high: 'bg-red-500/20 text-red-400 border-red-500/30',
      medium: 'bg-amber-500/20 text-amber-400 border-amber-500/30',
      low: 'bg-green-500/20 text-green-400 border-green-500/30'
    };
    return variants[severity as keyof typeof variants] || variants.medium;
  };
  
  const getAlertStatusBadge = (status: string) => {
    const variants = {
      new: 'bg-blue-500/20 text-blue-400 border-blue-500/30',
      acknowledged: 'bg-amber-500/20 text-amber-400 border-amber-500/30',
      resolved: 'bg-green-500/20 text-green-400 border-green-500/30'
    };
    return variants[status as keyof typeof variants] || variants.new;
  };
  
  const formatAlertDate = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
    const diffDays = Math.floor(diffHours / 24);
    
    if (diffHours < 1) {
      return 'Just now';
    } else if (diffHours < 24) {
      return `${diffHours} hour${diffHours > 1 ? 's' : ''} ago`;
    } else if (diffDays < 7) {
      return `${diffDays} day${diffDays > 1 ? 's' : ''} ago`;
    } else {
      return date.toLocaleDateString();
    }
  };

  const filteredPrograms = samplePrograms.filter(program => {
    const matchesSearch = program.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         program.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesJurisdiction = selectedJurisdiction === 'all' || 
                               program.jurisdiction.toLowerCase().includes(selectedJurisdiction);
    const matchesType = selectedType === 'all' || program.type === selectedType;
    const matchesStatus = selectedStatus === 'all' || program.status === selectedStatus;
    
    return matchesSearch && matchesJurisdiction && matchesType && matchesStatus;
  });

  const [explanationLoading, setExplanationLoading] = useState(true);
  const [screeningExplanation, setScreeningExplanation] = useState<{
    title: string;
    content: string;
  } | null>(null);

  // Load screening explanation content
  const loadScreeningExplanation = useCallback(async () => {
    setExplanationLoading(true);
    try {
      const response = await brain.get_classification_note_by_key({ noteKey: 'screening_explanation' });
      const explanation = await response.json();
      setScreeningExplanation(explanation);
    } catch (error) {
      console.error('❌ Error loading screening explanation:', error);
      // Set default content if API fails
      setScreeningExplanation({
        title: 'How are entities and individuals affected by sanctions and restrictive measures',
        content: `Sanctions and restrictive measures are tools used by governments and international organizations to address threats to international peace and security, violations of international law, or other unacceptable behavior.

**Types of Sanctions:**
- **Asset Freezes**: Preventing access to funds and economic resources
- **Travel Bans**: Restrictions on movement and entry to territories
- **Arms Embargoes**: Prohibiting the sale or transfer of weapons
- **Trade Restrictions**: Limiting or prohibiting specific commercial activities

**Who Can Be Affected:**
- Individuals (politicians, military leaders, business people)
- Entities (companies, organizations, government agencies)
- Sectors (banking, energy, technology)
- Entire countries or regions

**Compliance Requirements:**
Businesses must screen their customers, suppliers, and transaction parties against sanctions lists to ensure compliance with applicable laws and regulations. Failure to comply can result in severe penalties, including fines and legal action.`
      });
    } finally {
      setExplanationLoading(false);
    }
  }, []);

  useEffect(() => {
    loadScreeningExplanation();
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-950 via-gray-900 to-black text-white p-6">
      {/* Navigation Component */}
      <Navigation currentPage="sanctions_embargoes" />
      
      {/* Module Sub-Header */}
      <div className="mb-8 pt-4">
        <div className="flex items-center gap-4 mb-4">
          <div className="relative">
            <Shield className="h-12 w-12 text-red-400" />
            <div className="absolute inset-0 bg-red-400/20 blur-xl rounded-full" />
          </div>
          <div>
            <h1 className="text-4xl font-bold bg-gradient-to-r from-red-400 via-amber-400 to-red-600 bg-clip-text text-transparent">
              Sanctions & Embargoes
            </h1>
            <p className="text-gray-400 text-lg mt-1">
              Monitor and manage sanctions compliance across global jurisdictions
            </p>
          </div>
        </div>
        
        {/* Real-time Status Bar */}
        <div className="bg-gray-900/50 backdrop-blur border border-gray-700/50 rounded-xl p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-6">
              <div className="flex items-center gap-2">
                <Activity className="h-5 w-5 text-green-400 animate-pulse" />
                <span className="text-sm text-green-400 font-medium">Live Monitoring Active</span>
              </div>
              <div className="flex items-center gap-2">
                <Globe className="h-4 w-4 text-blue-400" />
                <span className="text-sm text-gray-300">7 Jurisdictions</span>
              </div>
              <div className="flex items-center gap-2">
                <Users className="h-4 w-4 text-purple-400" />
                <span className="text-sm text-gray-300">10,869 Entities</span>
              </div>
              <div className="flex items-center gap-2">
                <Clock className="h-4 w-4 text-amber-400" />
                <span className="text-sm text-gray-300">Last Update: 2h ago</span>
              </div>
            </div>
            <Button 
              size="sm" 
              className="bg-red-500/20 hover:bg-red-500/30 text-red-400 border border-red-500/30"
            >
              <Download className="h-4 w-4 mr-2" />
              Export Report
            </Button>
          </div>
        </div>
      </div>

      {/* Main Content Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-5 bg-gray-900/50 border border-gray-700/50">
          <TabsTrigger value="overview" className="data-[state=active]:bg-red-500/20 data-[state=active]:text-red-400">
            <Target className="h-4 w-4 mr-2" />
            Overview
          </TabsTrigger>
          <TabsTrigger value="programs" className="data-[state=active]:bg-red-500/20 data-[state=active]:text-red-400">
            <Scale className="h-4 w-4 mr-2" />
            Programs
          </TabsTrigger>
          <TabsTrigger value="screening" className="data-[state=active]:bg-red-500/20 data-[state=active]:text-red-400">
            <Search className="h-4 w-4 mr-2" />
            Screening
          </TabsTrigger>
          <TabsTrigger value="workflows" className="data-[state=active]:bg-red-500/20 data-[state=active]:text-red-400">
            <Workflow className="h-4 w-4 mr-2" />
            Checks
          </TabsTrigger>
          <TabsTrigger value="alerts" className="data-[state=active]:bg-red-500/20 data-[state=active]:text-red-400">
            <AlertTriangle className="h-4 w-4 mr-2" />
            Alerts
          </TabsTrigger>
        </TabsList>

        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-6">
          <div className="space-y-6">
            {/* What are Sanctions & Embargoes Section */}
            <Card className="bg-gray-900/50 border-gray-700/50 backdrop-blur">
              <CardHeader>
                <CardTitle className="text-blue-400 flex items-center gap-2">
                  <Shield className="h-5 w-5" />
                  What are Sanctions & Embargoes?
                </CardTitle>
                <CardDescription className="text-gray-400">
                  Understanding the fundamentals of economic sanctions and trade embargoes
                </CardDescription>
              </CardHeader>
              <CardContent>
                {loadingContent ? (
                  <div className="flex items-center justify-center py-8">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-400"></div>
                  </div>
                ) : sanctionsContent ? (
                  <div className="prose prose-invert max-w-none">
                    <div 
                      className="text-gray-300 leading-relaxed"
                      dangerouslySetInnerHTML={{ __html: sanctionsContent }}
                    />
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <p className="text-gray-400 mb-4">No content available yet.</p>
                    <p className="text-sm text-gray-500">
                      Content can be managed through the Admin Dashboard under Classification Notes with key: 
                      <code className="bg-gray-800 px-2 py-1 rounded text-blue-400">sanctions_overview_explanation</code>
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Recent Alerts & Quick Actions */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Recent Alerts */}
              <Card className="bg-gray-900/50 border-gray-700/50 backdrop-blur">
                <CardHeader>
                  <CardTitle className="text-amber-400 flex items-center gap-2">
                    <AlertTriangle className="h-5 w-5" />
                    Recent Alerts
                  </CardTitle>
                  <CardDescription className="text-gray-400">
                    Latest sanctions updates and compliance notifications
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {documentAlerts.slice(0, 3).map((alert) => (
                    <div key={alert.id} className="flex items-start gap-3 p-3 rounded-lg bg-gray-800/50 border border-gray-700/50">
                      <div className="flex-shrink-0 mt-1">
                        {getSeverityIcon(alert.severity)}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-white truncate">{alert.title}</p>
                        <p className="text-xs text-gray-400 mt-1">{alert.description}</p>
                        <div className="flex items-center gap-2 mt-2">
                          <span className="text-xs text-gray-500">{alert.flagEmoji} {alert.jurisdiction}</span>
                          <span className="text-xs text-gray-500">•</span>
                          <span className="text-xs text-gray-500">{formatAlertDate(alert.timestamp)}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    className="w-full text-amber-400 hover:bg-amber-500/10"
                    onClick={() => setActiveTab('alerts')}
                  >
                    View All Alerts
                  </Button>
                </CardContent>
              </Card>

              {/* Quick Actions */}
              <Card className="bg-gray-900/50 border-gray-700/50 backdrop-blur">
                <CardHeader>
                  <CardTitle className="text-blue-400 flex items-center gap-2">
                    <Zap className="h-5 w-5" />
                    Quick Actions
                  </CardTitle>
                  <CardDescription className="text-gray-400">
                    Common sanctions compliance tasks
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  <Button 
                    className="w-full bg-red-500/20 hover:bg-red-500/30 text-red-400 border border-red-500/30 justify-start"
                    onClick={() => setActiveTab('screening')}
                  >
                    <Search className="h-4 w-4 mr-2" />
                    Screen Entity or Individual
                  </Button>
                  <Button 
                    className="w-full bg-purple-500/20 hover:bg-purple-500/30 text-purple-400 border border-purple-500/30 justify-start"
                    onClick={() => setActiveTab('checks')}
                  >
                    <Target className="h-4 w-4 mr-1" />
                    Check your Transaction
                  </Button>
                  <Button 
                    className="w-full bg-blue-500/20 hover:bg-blue-500/30 text-blue-400 border border-blue-500/30 justify-start"
                    onClick={() => setActiveTab('programs')}
                  >
                    <FileText className="h-4 w-4 mr-2" />
                    Browse Sanctions Programs
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        {/* Programs Tab */}
        <TabsContent value="programs" className="space-y-6">
          {/* Coming Soon Placeholder */}
          <Card className="bg-gray-900/50 border-gray-700/50 backdrop-blur">
            <CardContent className="flex flex-col items-center justify-center py-16">
              <div className="text-center max-w-md">
                <Scale className="h-16 w-16 mx-auto mb-6 text-gray-600" />
                <h3 className="text-2xl font-bold text-white mb-4">Coming Soon</h3>
                <p className="text-gray-400 mb-6">
                  Advanced sanctions program management and detailed entity listings are currently under development.
                </p>
                <div className="space-y-2 text-sm text-gray-500">
                  <p>• Comprehensive sanctions program database</p>
                  <p>• Real-time entity monitoring</p>
                  <p>• Advanced filtering and search capabilities</p>
                  <p>• Automated compliance updates</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Screening Tab */}
        <TabsContent value="screening" className="space-y-6">
          {/* CMS-Driven Explanatory Section */}
          {explanationLoading ? (
            <Card className="bg-gray-900/50 border-gray-700/50 backdrop-blur">
              <CardContent className="p-8 text-center">
                <Loader2 className="h-8 w-8 animate-spin text-red-400 mx-auto mb-4" />
                <p className="text-gray-400">Loading explanation content...</p>
              </CardContent>
            </Card>
          ) : screeningExplanation && (
            <Card className="bg-gradient-to-br from-blue-900/20 to-blue-800/10 border-blue-500/30 backdrop-blur">
              <CardHeader>
                <CardTitle className="text-blue-400 flex items-center gap-2">
                  <BookOpen className="h-5 w-5" />
                  {screeningExplanation.title}
                </CardTitle>
                <CardDescription className="text-gray-400">
                  Understanding sanctions and their impact on entities and individuals
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="prose prose-invert prose-blue max-w-none">
                  <div className="text-gray-300 whitespace-pre-line leading-relaxed">
                    {screeningExplanation.content}
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
          
          {/* Customer Screening Redirection Section */}
          <Card className="bg-gradient-to-br from-purple-900/20 to-purple-800/10 border-purple-500/30 backdrop-blur">
            <CardHeader>
              <CardTitle className="text-purple-400 flex items-center gap-2">
                <Users className="h-5 w-5" />
                Advanced Customer Screening Platform
              </CardTitle>
              <CardDescription className="text-gray-400">
                For comprehensive customer due diligence and ongoing monitoring
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-center">
                <div className="space-y-4">
                  <p className="text-gray-300 leading-relaxed">
                    While this screening tool provides basic sanctions checking, for comprehensive customer due diligence, 
                    ongoing monitoring, and detailed risk assessment, visit our dedicated Customer Screening platform.
                  </p>
                  
                  <div className="space-y-2">
                    <h4 className="text-white font-semibold">Advanced Features:</h4>
                    <ul className="text-sm text-gray-400 space-y-1">
                      <li className="flex items-center gap-2">
                        <CheckCircle className="h-4 w-4 text-green-400" />
                        Comprehensive customer profiles
                      </li>
                      <li className="flex items-center gap-2">
                        <CheckCircle className="h-4 w-4 text-green-400" />
                        Ongoing monitoring and alerts
                      </li>
                      <li className="flex items-center gap-2">
                        <CheckCircle className="h-4 w-4 text-green-400" />
                        Risk scoring and assessment
                      </li>
                      <li className="flex items-center gap-2">
                        <CheckCircle className="h-4 w-4 text-green-400" />
                        Batch screening capabilities
                      </li>
                      <li className="flex items-center gap-2">
                        <CheckCircle className="h-4 w-4 text-green-400" />
                        Detailed audit trails
                      </li>
                    </ul>
                  </div>
                </div>
                
                <div className="text-center">
                  <div className="bg-gray-800/50 rounded-xl p-6 border border-gray-700/50">
                    <Users className="h-16 w-16 mx-auto mb-4 text-purple-400" />
                    <h3 className="text-xl font-bold text-white mb-2">Customer Screening</h3>
                    <p className="text-gray-400 mb-6">Professional-grade customer due diligence</p>
                    
                    <Button 
                      size="lg" 
                      className="w-full bg-purple-500/20 hover:bg-purple-500/30 text-purple-400 border border-purple-500/30"
                      onClick={() => {
                        // Navigate to Customer Screening page
                        window.location.href = '/customer-screening';
                      }}
                    >
                      <ArrowRight className="h-5 w-5 mr-2" />
                      Go to Customer Screening
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Workflows Tab */}
        <TabsContent value="workflows" className="space-y-6">
          {!selectedWorkflow ? (
            // Workflow Browser
            <>
              <Card className="bg-gray-900/50 border-gray-700/50 backdrop-blur">
                <CardHeader>
                  <CardTitle className="text-purple-400 flex items-center gap-2">
                    <Workflow className="h-5 w-5" />
                    Sanctions Workflow Library
                  </CardTitle>
                  <CardDescription className="text-gray-400">
                    Browse and execute guided workflow-based sanctions assessments
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {workflowLoading ? (
                    <div className="flex items-center justify-center py-12">
                      <Loader2 className="h-8 w-8 animate-spin text-purple-400" />
                      <span className="ml-3 text-gray-400">Loading workflows...</span>
                    </div>
                  ) : workflows.length === 0 ? (
                    <div className="text-center py-12">
                      <Workflow className="h-16 w-16 mx-auto mb-4 text-gray-600" />
                      <h3 className="text-lg font-semibold text-gray-400 mb-2">No Workflows Available</h3>
                      <p className="text-gray-500">No published workflows are currently available for sanctions assessments.</p>
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                      {workflows.map((workflow) => (
                        <Card key={workflow.id} className="bg-gray-800/50 border-gray-700/50 hover:bg-gray-700/50 transition-colors group">
                          <CardHeader>
                            <div className="flex items-start justify-between">
                              <div>
                                <CardTitle className="text-white group-hover:text-purple-400 transition-colors">
                                  {workflow.name}
                                </CardTitle>
                                <CardDescription className="text-gray-400 mt-1">
                                  {workflow.description || 'Guided workflow assessment'}
                                </CardDescription>
                              </div>
                              <div className="flex flex-col items-end gap-2">
                                <Badge className="bg-purple-500/20 text-purple-400 border-purple-500/30">
                                  {workflow.status}
                                </Badge>
                                {workflow.pricing_tier && (
                                  <Badge className="bg-amber-500/20 text-amber-400 border-amber-500/30">
                                    {workflow.pricing_tier}
                                  </Badge>
                                )}
                              </div>
                            </div>
                          </CardHeader>
                          <CardContent>
                            <div className="space-y-4">
                              <div className="flex items-center gap-4 text-xs text-gray-400">
                                <span className="flex items-center gap-1">
                                  <BookOpen className="h-3 w-3" />
                                  {workflow.introduction_trees?.length || 0} intro steps
                                </span>
                                <span className="flex items-center gap-1">
                                  <Target className="h-3 w-3" />
                                  {workflow.classification_trees?.length || 0} assessment steps
                                </span>
                                <span className="flex items-center gap-1">
                                  <Calendar className="h-3 w-3" />
                                  Updated {new Date(workflow.updated_at).toLocaleDateString()}
                                </span>
                              </div>
                              
                              <div className="flex gap-2">
                                <Button
                                  className="flex-1 bg-purple-500/20 hover:bg-purple-500/30 text-purple-400 border border-purple-500/30"
                                  onClick={() => startWorkflow(workflow)}
                                  disabled={workflowLoading}
                                >
                                  <PlayCircle className="h-4 w-4 mr-2" />
                                  Start Workflow
                                </Button>
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  className="text-gray-400 hover:text-white"
                                >
                                  <Eye className="h-4 w-4" />
                                </Button>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </>
          ) : (
            // Workflow Execution
            <>
              <Card className="bg-gray-900/50 border-gray-700/50 backdrop-blur">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="text-purple-400 flex items-center gap-2">
                        <Workflow className="h-5 w-5" />
                        {selectedWorkflow.name}
                      </CardTitle>
                      <CardDescription className="text-gray-400">
                        {selectedWorkflow.description || 'Guided workflow assessment in progress'}
                      </CardDescription>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={resetWorkflow}
                      className="text-gray-400 hover:text-white"
                    >
                      <ArrowLeft className="h-4 w-4 mr-2" />
                      Back to Workflows
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  {workflowProgress && (
                    <div className="mb-6">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm text-gray-400">Progress</span>
                        <span className="text-sm text-purple-400">
                          Step {workflowProgress.currentStep} of {workflowProgress.totalSteps}
                        </span>
                      </div>
                      <div className="w-full bg-gray-700/50 rounded-full h-2">
                        <div
                          className="bg-purple-500 h-2 rounded-full transition-all duration-300"
                          style={{
                            width: `${(workflowProgress.currentStep / workflowProgress.totalSteps) * 100}%`
                          }}
                        />
                      </div>
                    </div>
                  )}
                  
                  <div className="bg-gray-800/30 rounded-lg p-6 border border-gray-700/50">
                    <h3 className="text-lg font-semibold text-white mb-4">Workflow Execution</h3>
                    
                    {/* Introduction Trees */}
                    {selectedWorkflow.introduction_trees && selectedWorkflow.introduction_trees.length > 0 && (
                      <div className="mb-6">
                        <h4 className="text-md font-medium text-purple-400 mb-3">Introduction Steps</h4>
                        <div className="space-y-3">
                          {selectedWorkflow.introduction_trees.map((tree, index) => (
                            <Card key={tree.id} className="bg-gray-700/30 border-gray-600/50">
                              <CardContent className="p-4">
                                <div className="flex items-center justify-between">
                                  <div>
                                    <h5 className="font-medium text-white">{tree.name}</h5>
                                    <p className="text-sm text-gray-400">{tree.description}</p>
                                  </div>
                                  <Button
                                    size="sm"
                                    className="bg-purple-500/20 hover:bg-purple-500/30 text-purple-400 border border-purple-500/30"
                                  >
                                    <PlayCircle className="h-4 w-4 mr-1" />
                                    Start
                                  </Button>
                                </div>
                              </CardContent>
                            </Card>
                          ))}
                        </div>
                      </div>
                    )}
                    
                    {/* Classification Trees */}
                    {selectedWorkflow.classification_trees && selectedWorkflow.classification_trees.length > 0 && (
                      <div>
                        <h4 className="text-md font-medium text-purple-400 mb-3">Assessment Steps</h4>
                        <div className="space-y-3">
                          {selectedWorkflow.classification_trees.map((tree, index) => (
                            <Card key={tree.id} className="bg-gray-700/30 border-gray-600/50">
                              <CardContent className="p-4">
                                <div className="flex items-center justify-between">
                                  <div>
                                    <h5 className="font-medium text-white">{tree.name}</h5>
                                    <p className="text-sm text-gray-400">{tree.description}</p>
                                    <div className="flex items-center gap-2 mt-1">
                                      <Badge className="bg-blue-500/20 text-blue-400 border-blue-500/30 text-xs">
                                        {tree.jurisdiction}
                                      </Badge>
                                      <Badge className="bg-green-500/20 text-green-400 border-green-500/30 text-xs">
                                        {tree.category}
                                      </Badge>
                                    </div>
                                  </div>
                                  <Button
                                    size="sm"
                                    className="bg-purple-500/20 hover:bg-purple-500/30 text-purple-400 border border-purple-500/30"
                                  >
                                    <PlayCircle className="h-4 w-4 mr-1" />
                                    Start
                                  </Button>
                                </div>
                              </CardContent>
                            </Card>
                          ))}
                        </div>
                      </div>
                    )}
                    
                    {/* No workflow trees */}
                    {(!selectedWorkflow.introduction_trees || selectedWorkflow.introduction_trees.length === 0) &&
                     (!selectedWorkflow.classification_trees || selectedWorkflow.classification_trees.length === 0) && (
                      <div className="text-center py-8">
                        <Workflow className="h-12 w-12 mx-auto mb-4 text-gray-600" />
                        <p className="text-gray-400">This workflow does not contain any assessment steps yet.</p>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </>
          )}
        </TabsContent>

        {/* Alerts Tab */}
        <TabsContent value="alerts" className="space-y-6">
          {/* Alert Statistics */}
          {alertStats && (
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <Card className="bg-gradient-to-br from-blue-900/20 to-blue-800/10 border-blue-500/30 backdrop-blur">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium text-blue-400 flex items-center gap-2">
                    <AlertTriangle className="h-4 w-4" />
                    Active Alerts
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-white mb-1">{alertStats.active_count || 0}</div>
                  <p className="text-xs text-gray-400">Require attention</p>
                </CardContent>
              </Card>
              
              <Card className="bg-gradient-to-br from-red-900/20 to-red-800/10 border-red-500/30 backdrop-blur">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium text-red-400 flex items-center gap-2">
                    <AlertCircle className="h-4 w-4" />
                    High Severity
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-white mb-1">{alertStats.severity_counts?.high || 0}</div>
                  <p className="text-xs text-gray-400">Critical issues</p>
                </CardContent>
              </Card>
              
              <Card className="bg-gradient-to-br from-amber-900/20 to-amber-800/10 border-amber-500/30 backdrop-blur">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium text-amber-400 flex items-center gap-2">
                    <Clock className="h-4 w-4" />
                    Acknowledged
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-white mb-1">{alertStats.status_counts?.acknowledged || 0}</div>
                  <p className="text-xs text-gray-400">In progress</p>
                </CardContent>
              </Card>
              
              <Card className="bg-gradient-to-br from-green-900/20 to-green-800/10 border-green-500/30 backdrop-blur">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium text-green-400 flex items-center gap-2">
                    <CheckCircle className="h-4 w-4" />
                    Resolved
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-white mb-1">{alertStats.status_counts?.resolved || 0}</div>
                  <p className="text-xs text-gray-400">Completed</p>
                </CardContent>
              </Card>
            </div>
          )}
          
          {/* Alert Filters */}
          <Card className="bg-gray-900/50 border-gray-700/50 backdrop-blur">
            <CardContent className="p-4">
              <div className="flex flex-col lg:flex-row gap-4 items-center">
                <div className="flex items-center gap-2">
                  <Filter className="h-4 w-4 text-gray-400" />
                  <span className="text-sm text-gray-400">Filter by:</span>
                </div>
                <div className="flex gap-3">
                  <Select 
                    value={alertFilters.status} 
                    onValueChange={(value) => setAlertFilters(prev => ({ ...prev, status: value }))}
                  >
                    <SelectTrigger className="w-[150px] bg-gray-800/50 border-gray-600 text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-gray-800 border-gray-700">
                      <SelectItem value="all" className="text-white">All Status</SelectItem>
                      <SelectItem value="new" className="text-white">New</SelectItem>
                      <SelectItem value="acknowledged" className="text-white">Acknowledged</SelectItem>
                      <SelectItem value="resolved" className="text-white">Resolved</SelectItem>
                    </SelectContent>
                  </Select>
                  
                  <Select 
                    value={alertFilters.severity} 
                    onValueChange={(value) => setAlertFilters(prev => ({ ...prev, severity: value }))}
                  >
                    <SelectTrigger className="w-[150px] bg-gray-800/50 border-gray-600 text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-gray-800 border-gray-700">
                      <SelectItem value="all" className="text-white">All Severity</SelectItem>
                      <SelectItem value="critical" className="text-white">Critical</SelectItem>
                      <SelectItem value="high" className="text-white">High</SelectItem>
                      <SelectItem value="medium" className="text-white">Medium</SelectItem>
                      <SelectItem value="low" className="text-white">Low</SelectItem>
                    </SelectContent>
                  </Select>
                  
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={loadDocumentAlerts}
                    disabled={alertsLoading}
                    className="text-blue-400 hover:bg-blue-500/10"
                  >
                    {alertsLoading ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      <ArrowRight className="h-4 w-4" />
                    )}
                    Refresh
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
          
          {/* Alerts List */}
          <Card className="bg-gray-900/50 border-gray-700/50 backdrop-blur">
            <CardHeader>
              <CardTitle className="text-amber-400 flex items-center gap-2">
                <AlertTriangle className="h-5 w-5" />
                Document Alerts
              </CardTitle>
              <CardDescription className="text-gray-400">
                Alerts generated from Knowledge Base documents for sanctions compliance
              </CardDescription>
            </CardHeader>
            <CardContent>
              {alertsLoading ? (
                <div className="flex items-center justify-center py-8">
                  <Loader2 className="h-8 w-8 animate-spin text-amber-400" />
                  <span className="ml-2 text-gray-400">Loading alerts...</span>
                </div>
              ) : documentAlerts.length === 0 ? (
                <div className="text-center py-8">
                  <AlertTriangle className="h-12 w-12 mx-auto mb-4 text-gray-600" />
                  <p className="text-gray-400">No sanctions alerts found</p>
                  <p className="text-sm text-gray-500 mt-1">
                    Alerts will appear here when Knowledge Base documents with "Generate Alert: Sanctions & Embargoes" are published
                  </p>
                </div>
              ) : (
                <div className="space-y-4">
                  {documentAlerts.map((alert) => (
                    <div key={alert.id} className="p-4 rounded-lg bg-gray-800/50 border border-gray-700/50 hover:bg-gray-700/50 transition-colors">
                      <div className="flex items-start gap-4">
                        <div className="flex-shrink-0 mt-1">
                          {getSeverityIcon(alert.severity)}
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center justify-between mb-2">
                            <h3 className="font-semibold text-white">{alert.title}</h3>
                            <div className="flex items-center gap-2">
                              <Badge className={getSeverityBadge(alert.severity)}>
                                {alert.severity.toUpperCase()}
                              </Badge>
                              <Badge className={getAlertStatusBadge(alert.status)}>
                                {alert.status.toUpperCase()}
                              </Badge>
                            </div>
                          </div>
                          
                          {alert.description && (
                            <p className="text-gray-300 text-sm mb-3">{alert.description}</p>
                          )}
                          
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-4 text-xs text-gray-400">
                              <span className="flex items-center gap-1">
                                <FileText className="h-3 w-3" />
                                Document ID: {alert.document_id}
                              </span>
                              <span className="flex items-center gap-1">
                                <Calendar className="h-3 w-3" />
                                {formatAlertDate(alert.created_at)}
                              </span>
                              {alert.jurisdictions && alert.jurisdictions.length > 0 && (
                                <span className="flex items-center gap-1">
                                  <Globe className="h-3 w-3" />
                                  {alert.jurisdictions.join(', ')}
                                </span>
                              )}
                              {alert.expires_at && (
                                <span className="flex items-center gap-1">
                                  <Clock className="h-3 w-3" />
                                  Expires: {new Date(alert.expires_at).toLocaleDateString()}
                                </span>
                              )}
                            </div>
                            
                            <div className="flex gap-2">
                              <Button 
                                size="sm" 
                                variant="ghost" 
                                className="text-blue-400 hover:bg-blue-500/10"
                                onClick={() => viewSourceDocument(alert.document_id)}
                              >
                                <Eye className="h-3 w-3 mr-1" />
                                View Source
                              </Button>
                              
                              {alert.status === 'new' && (
                                <Button 
                                  size="sm" 
                                  variant="ghost" 
                                  className="text-amber-400 hover:bg-amber-500/10"
                                  onClick={() => updateAlertStatus(alert.id, 'acknowledged')}
                                >
                                  <CheckCircle className="h-3 w-3 mr-1" />
                                  Acknowledge
                                </Button>
                              )}
                              
                              {(alert.status === 'new' || alert.status === 'acknowledged') && (
                                <Button 
                                  size="sm" 
                                  variant="ghost" 
                                  className="text-green-400 hover:bg-green-500/10"
                                  onClick={() => updateAlertStatus(alert.id, 'resolved')}
                                >
                                  <XCircle className="h-3 w-3 mr-1" />
                                  Resolve
                                </Button>
                              )}
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Program Details Modal */}
      {selectedProgram && (
        <Dialog open={!!selectedProgram} onOpenChange={() => setSelectedProgram(null)}>
          <DialogContent className="bg-gray-900 border-gray-700 text-white max-w-4xl max-h-[85vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="text-red-400 text-xl font-bold flex items-center gap-3">
                <span className="text-2xl">{selectedProgram.flagEmoji}</span>
                {selectedProgram.name}
              </DialogTitle>
              <DialogDescription className="text-gray-400">
                {selectedProgram.jurisdiction} • {selectedProgram.type} sanctions
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-6">
              <div className="grid grid-cols-3 gap-4">
                <div className="bg-gray-800/50 p-4 rounded-lg">
                  <div className="text-2xl font-bold text-white">{selectedProgram.entities.toLocaleString()}</div>
                  <div className="text-sm text-gray-400">Sanctioned Entities</div>
                </div>
                <div className="bg-gray-800/50 p-4 rounded-lg">
                  <div className="text-2xl font-bold text-white">{selectedProgram.lastUpdated}</div>
                  <div className="text-sm text-gray-400">Last Updated</div>
                </div>
                <div className="bg-gray-800/50 p-4 rounded-lg">
                  <Badge className={getStatusBadge(selectedProgram.status)}>
                    {selectedProgram.status}
                  </Badge>
                  <div className="text-sm text-gray-400 mt-1">Current Status</div>
                </div>
              </div>
              
              <div>
                <h3 className="text-lg font-semibold text-white mb-3">Description</h3>
                <p className="text-gray-300">{selectedProgram.description}</p>
              </div>
              
              <div className="flex gap-3">
                <Button className="bg-red-500/20 hover:bg-red-500/30 text-red-400 border border-red-500/30">
                  <FileText className="h-4 w-4 mr-2" />
                  View Full Program
                </Button>
                <Button variant="outline" className="border-gray-600 text-gray-300 hover:bg-gray-800">
                  <Download className="h-4 w-4 mr-2" />
                  Export List
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
};

export default SanctionsEmbargoes;
