import React, { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { useUserGuardContext } from 'app/auth';
import brain from 'brain';
import { toast } from 'sonner';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import {
  ArrowLeft,
  Calendar,
  Clock,
  User,
  Star,
  Eye,
  Bookmark,
  BookmarkCheck,
  Share,
  ThumbsUp,
  MessageSquare,
  Tag,
  ExternalLink,
  Home,
  Share2
} from 'lucide-react';
import { DocumentResponse } from 'types';
import { API_URL } from "app";

// Helper function to convert external Databutton static URLs to our app's serving endpoint
const convertToAppStaticUrl = (externalUrl: string): string => {
  if (!externalUrl) return '';
  
  // Extract filename from Databutton static URL
  // Format: https://static.databutton.com/public/{projectId}/{filename}
  const match = externalUrl.match(/\/([^/]+)$/); // Get the last part after the last slash
  if (!match) return externalUrl; // Return original if can't parse
  
  const filename = match[1];
  
  // Convert to our app's static serving endpoint
  return `${API_URL}/static/${filename}`;
};

const BlogArticle: React.FC = () => {
  const { user } = useUserGuardContext();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const [article, setArticle] = useState<DocumentResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [saved, setSaved] = useState(false);
  const [liked, setLiked] = useState(false);
  const [likes, setLikes] = useState(0);
  const [views, setViews] = useState(0);
  
  const articleId = searchParams.get('id');

  // Load article
  useEffect(() => {
    const loadArticle = async () => {
      if (!articleId) {
        toast.error('No article ID provided');
        navigate('/blog');
        return;
      }

      try {
        setLoading(true);
        console.log('Loading article with ID:', articleId);
        
        const response = await brain.get_content_item({ contentId: parseInt(articleId) });
        const rawData = await response.json();
        console.log('Raw article data:', rawData);
        
        // Parse the content structure - content is stored as JSON string in content column
        let parsedContent = {};
        try {
          if (typeof rawData.content === 'string') {
            parsedContent = JSON.parse(rawData.content);
          } else if (rawData.content && typeof rawData.content === 'object') {
            parsedContent = rawData.content;
          }
        } catch (e) {
          console.warn('Could not parse content JSON:', e);
          parsedContent = {};
        }
        
        console.log('Raw article data from API:', rawData);
        console.log('Parsed content structure:', parsedContent);
        
        // Create a properly structured article object
        const article = {
          ...rawData,
          // Extract from parsed content - content is HTML
          content_text: parsedContent.content || '',
          excerpt: parsedContent.excerpt || '',
          author: parsedContent.author_name || 'RespectUs Team',
          reading_time: parsedContent.reading_time || 5,
          featured_status: parsedContent.featured || false,
          article_type: parsedContent.content_type || 'article',
          publication_date: rawData.created_at || new Date().toISOString(),
          tags: parsedContent.tags || [],
          // Convert featured image URL to use our app's static serving endpoint
          featured_image_url: parsedContent.featured_image_url ? 
            convertToAppStaticUrl(parsedContent.featured_image_url) : '',
          // Keep original fields
          title: rawData.title,
          id: rawData.id
        };
        
        console.log('Processed article:', article);
        console.log('Featured image URL converted:', parsedContent.featured_image_url, '->', article.featured_image_url);
        setArticle(article);
        setLikes(parsedContent.likes_count || 0);
        setViews(parsedContent.view_count || 0);
        
      } catch (error) {
        console.error('Error loading article:', error);
        toast.error('Failed to load article');
        navigate('/blog');
      } finally {
        setLoading(false);
      }
    };

    loadArticle();
  }, [articleId, navigate]);

  // Save article function
  const handleSaveArticle = async () => {
    try {
      // This would need to be implemented in the backend
      // await brain.save_article({ article_id: parseInt(articleId!) });
      setSaved(!saved);
      toast.success(saved ? 'Article removed from collection' : 'Article saved to collection');
    } catch (error) {
      console.error('Error saving article:', error);
      toast.error('Failed to save article');
    }
  };

  // Like article function
  const handleLikeArticle = async () => {
    try {
      // This would need to be implemented in the backend
      // await brain.like_article({ article_id: parseInt(articleId!) });
      setLiked(!liked);
      setLikes(prev => liked ? prev - 1 : prev + 1);
      toast.success(liked ? 'Like removed' : 'Article liked');
    } catch (error) {
      console.error('Error liking article:', error);
      toast.error('Failed to like article');
    }
  };

  // Share article function
  const handleShareArticle = async () => {
    try {
      const url = window.location.href;
      await navigator.clipboard.writeText(url);
      toast.success('Article link copied to clipboard');
    } catch (error) {
      console.error('Error sharing article:', error);
      toast.error('Failed to copy link');
    }
  };

  // Format date
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  // Format reading time
  const formatReadingTime = (minutes: number) => {
    return `${minutes} min read`;
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-black">
        <div className="max-w-4xl mx-auto px-4 py-8">
          <div className="text-center py-12">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-400 mx-auto mb-4"></div>
            <p className="text-gray-400">Loading article...</p>
          </div>
        </div>
      </div>
    );
  }

  if (!article) {
    return (
      <div className="min-h-screen bg-black">
        <div className="max-w-4xl mx-auto px-4 py-8">
          <div className="text-center py-12">
            <p className="text-gray-400 mb-4">Article not found</p>
            <Button onClick={() => navigate('/blog')} variant="outline">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Blog
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black">
      {/* Header Navigation */}
      <div className="border-b border-gray-800 bg-gray-900">
        <div className="max-w-4xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button
                onClick={() => navigate('/blog')}
                variant="ghost"
                size="sm"
                className="text-gray-400 hover:text-white"
              >
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Blog
              </Button>
              <Separator orientation="vertical" className="h-6 bg-gray-700" />
            </div>
            <div className="flex items-center gap-3">
              <Button
                onClick={handleShareArticle}
                variant="outline"
                size="sm"
                className="border-gray-600 text-gray-300 hover:bg-gray-700"
              >
                <Share className="h-4 w-4 mr-2" />
                Share
              </Button>
            </div>
          </div>
        </div>
      </div>
      
      <div className="max-w-4xl mx-auto px-4 py-8">
        {/* Article Header */}
        <header className="mb-12">
          {/* Categories and badges */}
          <div className="flex items-center gap-2 mb-6">
            {article.featured_status && (
              <Badge className="bg-yellow-600/20 text-yellow-400 border-yellow-400/30">
                <Star className="h-3 w-3 mr-1 fill-current" />
                Featured
              </Badge>
            )}
            {article.article_type && (
              <Badge variant="secondary" className="bg-blue-600/20 text-blue-300">
                <Tag className="h-3 w-3 mr-1" />
                {article.article_type.replace('-', ' ').replace(/\b\w/g, l => l.toUpperCase())}
              </Badge>
            )}
          </div>

          {/* Title */}
          <h1 className="text-4xl md:text-5xl font-bold text-white leading-tight mb-6">
            {article.title}
          </h1>

          {/* Excerpt */}
          {article.excerpt && (
            <p className="text-xl text-gray-300 mb-8 leading-relaxed">
              {article.excerpt}
            </p>
          )}

          {/* Meta information */}
          <div className="flex items-center text-sm text-gray-400 gap-6 mb-8">
            <div className="flex items-center gap-2">
              <User className="h-4 w-4" />
              <span>{article.author || 'RespectUs Team'}</span>
            </div>
            {article.publication_date && (
              <div className="flex items-center gap-2">
                <Calendar className="h-4 w-4" />
                <span>{formatDate(article.publication_date)}</span>
              </div>
            )}
            <div className="flex items-center gap-2">
              <Clock className="h-4 w-4" />
              <span>{formatReadingTime(article.reading_time || 5)}</span>
            </div>
            <div className="flex items-center gap-2">
              <Eye className="h-4 w-4" />
              <span>{views.toLocaleString()} views</span>
            </div>
          </div>

          {/* Action buttons */}
          <div className="flex items-center gap-3">
            <Button
              onClick={handleLikeArticle}
              variant={liked ? "default" : "outline"}
              size="sm"
              className={liked ? "bg-red-600 hover:bg-red-700" : "border-gray-600 text-gray-300 hover:bg-gray-700"}
            >
              <ThumbsUp className={`h-4 w-4 mr-2 ${liked ? 'fill-current' : ''}`} />
              {likes}
            </Button>
            
            <Button
              onClick={() => setSaved(!saved)}
              variant="ghost"
              size="sm"
              className={`${saved ? 'text-blue-400' : 'text-gray-400'} hover:text-white`}
            >
              <Bookmark className={`h-4 w-4 mr-2 ${saved ? 'fill-current' : ''}`} />
              {saved ? 'Saved' : 'Save'}
            </Button>
          </div>
        </header>

        {/* Featured Image Section */}
        {article.featured_image_url && (
          <div className="mb-8">
            <img
              src={article.featured_image_url}
              alt={article.title}
              className="w-full h-64 object-cover rounded-lg"
              onError={(e) => {
                console.error('Featured image failed to load:', article.featured_image_url);
                e.currentTarget.style.display = 'none';
              }}
              onLoad={() => {
                console.log('Featured image loaded successfully:', article.featured_image_url);
              }}
            />
          </div>
        )}

        {/* Article Content */}
        <main>
          <article className="prose prose-invert prose-lg max-w-none">
            {article.content_text ? (
              <div 
                className="text-gray-200 leading-relaxed space-y-6 prose prose-invert max-w-none"
                style={{ lineHeight: '1.8' }}
                dangerouslySetInnerHTML={{ __html: article.content_text }}
              />
            ) : (
              <div className="text-center py-12">
                <p className="text-gray-400 italic">Content not available</p>
              </div>
            )}
          </article>
        </main>

        {/* Tags Section */}
        {article.tags && (
          <section className="mt-8">
            <h3 className="text-lg font-semibold text-white mb-4">Tags</h3>
            <div className="flex flex-wrap gap-2">
              {(Array.isArray(article.tags) ? article.tags : article.tags.split(',')).map((tag, index) => (
                <Badge key={index} variant="secondary" className="bg-gray-700 text-gray-300">
                  {tag.trim()}
                </Badge>
              ))}
            </div>
          </section>
        )}

        {/* Back to Blog */}
        <div className="text-center mt-16 pt-8 border-t border-gray-800">
          <Button
            onClick={() => navigate('/blog')}
            variant="outline"
            className="border-gray-600 text-gray-300 hover:bg-gray-700"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to All Articles
          </Button>
        </div>
      </div>
    </div>
  );
};

export default BlogArticle;
