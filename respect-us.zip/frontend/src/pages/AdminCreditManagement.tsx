
import React, { useState, useEffect } from 'react';
import { Settings, Users, CreditCard, DollarSign, Package, Plus, Edit2, Trash2, Save, X, AlertTriangle } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Separator } from '@/components/ui/separator';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { useUserGuardContext } from 'app/auth';
import brain from 'brain';
import { toast } from 'sonner';

interface CreditPackage {
  id: number;
  name: string;
  credits: number;
  price_cents: number;
  currency: string;
  discount_percentage: number;
  is_active: boolean;
  expiry_months: number;
}

interface ComponentPricing {
  id: number;
  component_name: string;
  action_name: string;
  credit_cost: number;
  is_active: boolean;
  description?: string;
}

interface PricingFeatureFlag {
  component_name: string;
  is_pricing_enabled: boolean;
}

export default function AdminCreditManagement() {
  const { user } = useUserGuardContext();
  const [packages, setPackages] = useState<CreditPackage[]>([]);
  const [componentPricing, setComponentPricing] = useState<ComponentPricing[]>([]);
  const [featureFlags, setFeatureFlags] = useState<PricingFeatureFlag[]>([]);
  const [baseCreditPrice, setBaseCreditPrice] = useState<number>(0.10);
  const [isLoading, setIsLoading] = useState(true);
  const [editingPackage, setEditingPackage] = useState<CreditPackage | null>(null);
  const [editingPricing, setEditingPricing] = useState<ComponentPricing | null>(null);
  const [showNewPackageDialog, setShowNewPackageDialog] = useState(false);
  const [showNewPricingDialog, setShowNewPricingDialog] = useState(false);
  const [userAdjustment, setUserAdjustment] = useState({ user_id: '', amount: 0, reason: '' });

  useEffect(() => {
    loadAllData();
  }, []);

  const loadAllData = async () => {
    try {
      setIsLoading(true);
      await Promise.all([
        loadCreditPackages(),
        loadComponentPricing(),
        loadFeatureFlags(),
        loadBaseCreditPrice()
      ]);
    } catch (error) {
      console.error('Failed to load admin data:', error);
      toast.error('Failed to load admin data');
    } finally {
      setIsLoading(false);
    }
  };

  const loadCreditPackages = async () => {
    try {
      const response = await brain.get_all_credit_packages();
      const data = await response.json();
      setPackages(data);
    } catch (error) {
      console.error('Failed to load credit packages:', error);
    }
  };

  const loadComponentPricing = async () => {
    try {
      const response = await brain.get_component_pricing();
      const data = await response.json();
      setComponentPricing(data);
    } catch (error) {
      console.error('Failed to load component pricing:', error);
    }
  };

  const loadFeatureFlags = async () => {
    try {
      const response = await brain.get_pricing_feature_flags();
      const data = await response.json();
      setFeatureFlags(data);
    } catch (error) {
      console.error('Failed to load feature flags:', error);
    }
  };

  const loadBaseCreditPrice = async () => {
    try {
      const response = await brain.get_base_credit_price();
      const data = await response.json();
      setBaseCreditPrice(data.price_eur_per_credit);
    } catch (error) {
      console.error('Failed to load base credit price:', error);
    }
  };

  const handleSavePackage = async (pkg: Partial<CreditPackage>) => {
    try {
      if (pkg.id) {
        const response = await brain.update_credit_package(pkg.id, {
          name: pkg.name!,
          credits: pkg.credits!,
          price_cents: pkg.price_cents!,
          discount_percentage: pkg.discount_percentage || 0,
          is_active: pkg.is_active!,
          expiry_months: pkg.expiry_months!
        });
        const updatedPackage = await response.json();
        setPackages(prev => prev.map(p => p.id === pkg.id ? updatedPackage : p));
        toast.success('Package updated successfully');
      } else {
        const response = await brain.create_credit_package({
          name: pkg.name!,
          credits: pkg.credits!,
          price_cents: pkg.price_cents!,
          currency: pkg.currency || 'EUR',
          discount_percentage: pkg.discount_percentage || 0,
          is_active: pkg.is_active || true,
          expiry_months: pkg.expiry_months || 12
        });
        const newPackage = await response.json();
        setPackages(prev => [...prev, newPackage]);
        toast.success('Package created successfully');
      }
      setEditingPackage(null);
      setShowNewPackageDialog(false);
    } catch (error) {
      console.error('Failed to save package:', error);
      toast.error('Failed to save package');
    }
  };

  const handleDeletePackage = async (packageId: number) => {
    if (!confirm('Are you sure you want to delete this package?')) return;
    
    try {
      await brain.delete_credit_package({ packageId });
      setPackages(prev => prev.filter(p => p.id !== packageId));
      toast.success('Package deleted successfully');
    } catch (error) {
      console.error('Failed to delete package:', error);
      toast.error('Failed to delete package');
    }
  };

  const handleSavePricing = async (pricing: Partial<ComponentPricing>) => {
    try {
      if (pricing.id) {
        const response = await brain.update_component_pricing(
          { pricingId: pricing.id },
          {
            component_name: pricing.component_name!,
            action_name: pricing.action_name!,
            credit_cost: pricing.credit_cost!,
            is_active: pricing.is_active!,
            description: pricing.description
          }
        );
        const updated = await response.json();
        setComponentPricing(prev => prev.map(p => p.id === pricing.id ? updated : p));
        toast.success('Pricing updated successfully');
      } else {
        const response = await brain.create_component_pricing({
          component_name: pricing.component_name!,
          action_name: pricing.action_name!,
          credit_cost: pricing.credit_cost!,
          is_active: pricing.is_active || true,
          description: pricing.description
        });
        const newPricing = await response.json();
        setComponentPricing(prev => [...prev, newPricing]);
        toast.success('Pricing created successfully');
      }
      setEditingPricing(null);
      setShowNewPricingDialog(false);
    } catch (error) {
      console.error('Failed to save pricing:', error);
      toast.error('Failed to save pricing');
    }
  };

  const handleToggleFeatureFlag = async (componentName: string, enabled: boolean) => {
    try {
      await brain.update_pricing_feature_flag(componentName, { is_pricing_enabled: enabled });
      setFeatureFlags(prev => prev.map(f => 
        f.component_name === componentName ? { ...f, is_pricing_enabled: enabled } : f
      ));
      toast.success(`Pricing ${enabled ? 'enabled' : 'disabled'} for ${componentName}`);
    } catch (error) {
      console.error('Failed to toggle feature flag:', error);
      toast.error('Failed to update feature flag');
    }
  };

  const handleUserCreditAdjustment = async () => {
    if (!userAdjustment.user_id || userAdjustment.amount === 0 || !userAdjustment.reason) {
      toast.error('Please fill in all fields');
      return;
    }

    try {
      const response = await brain.admin_adjust_credits({
        user_id: userAdjustment.user_id,
        amount: userAdjustment.amount,
        reason: userAdjustment.reason
      });
      const result = await response.json();
      
      if (result.success) {
        toast.success(`Successfully adjusted credits for user`);
        setUserAdjustment({ user_id: '', amount: 0, reason: '' });
      } else {
        toast.error('Failed to adjust user credits');
      }
    } catch (error) {
      console.error('Failed to adjust user credits:', error);
      toast.error('Failed to adjust user credits');
    }
  };

  const handleUpdateBaseCreditPrice = async () => {
    try {
      await brain.update_base_credit_price({ price_eur_per_credit: baseCreditPrice });
      toast.success('Base credit price updated successfully');
    } catch (error) {
      console.error('Failed to update base credit price:', error);
      toast.error('Failed to update base credit price');
    }
  };

  const formatPrice = (priceInCents: number, currency: string = 'EUR') => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: currency,
      minimumFractionDigits: 2
    }).format(priceInCents / 100);
  };

  const formatPriceWithVATNotice = (priceInCents: number, currency: string = 'EUR') => {
    const basePrice = new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: currency,
      minimumFractionDigits: 2
    }).format(priceInCents / 100);
    return `${basePrice} + VAT if applicable`;
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-950 flex items-center justify-center">
        <div className="text-center">
          <Settings className="w-8 h-8 animate-spin text-blue-400 mx-auto mb-4" />
          <p className="text-gray-400">Loading admin dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-950 text-white p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-white mb-2">Credit Management Admin</h1>
            <p className="text-gray-400">Manage credit packages, pricing configuration, and user adjustments</p>
          </div>
          <Badge className="bg-red-500/20 text-red-400 border-red-500/30">
            <AlertTriangle className="w-3 h-3 mr-1" />
            Admin Access
          </Badge>
        </div>

        <Alert className="bg-yellow-900/20 border-yellow-500/30">
          <AlertTriangle className="w-4 h-4" />
          <AlertDescription className="text-yellow-300">
            You are in admin mode. Changes made here will affect all users and billing operations.
          </AlertDescription>
        </Alert>

        <Tabs defaultValue="packages" className="space-y-6">
          <TabsList className="bg-gray-900 border-gray-800">
            <TabsTrigger value="packages">Credit Packages</TabsTrigger>
            <TabsTrigger value="pricing">Component Pricing</TabsTrigger>
            <TabsTrigger value="features">Feature Flags</TabsTrigger>
            <TabsTrigger value="users">User Management</TabsTrigger>
            <TabsTrigger value="settings">Global Settings</TabsTrigger>
          </TabsList>

          <TabsContent value="packages" className="space-y-4">
            <div className="flex justify-between items-center">
              <h2 className="text-xl font-semibold text-white">Credit Packages</h2>
              <Dialog open={showNewPackageDialog} onOpenChange={setShowNewPackageDialog}>
                <DialogTrigger asChild>
                  <Button className="bg-purple-600 hover:bg-purple-700">
                    <Plus className="w-4 h-4 mr-2" />
                    New Package
                  </Button>
                </DialogTrigger>
                <DialogContent className="bg-gray-900 border-gray-800">
                  <DialogHeader>
                    <DialogTitle className="text-white">Create New Credit Package</DialogTitle>
                  </DialogHeader>
                  <PackageForm 
                    package={null} 
                    onSave={handleSavePackage} 
                    onCancel={() => setShowNewPackageDialog(false)} 
                  />
                </DialogContent>
              </Dialog>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {packages.map((pkg) => (
                <Card key={pkg.id} className="bg-gray-900 border-gray-800">
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <CardTitle className="text-white">{pkg.name}</CardTitle>
                      <div className="flex space-x-2">
                        <Button 
                          size="sm" 
                          variant="outline" 
                          className="border-gray-700"
                          onClick={() => setEditingPackage(pkg)}
                        >
                          <Edit2 className="w-3 h-3" />
                        </Button>
                        <Button 
                          size="sm" 
                          variant="outline" 
                          className="border-red-700 text-red-400"
                          onClick={() => handleDeletePackage(pkg.id)}
                        >
                          <Trash2 className="w-3 h-3" />
                        </Button>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="text-2xl font-bold text-purple-400">
                      {pkg.credits.toLocaleString()} credits
                    </div>
                    <div className="text-xl text-white">
                      {formatPriceWithVATNotice(pkg.price_cents, pkg.currency)}
                    </div>
                    <div className="space-y-1 text-sm text-gray-400">
                      <div>Discount: {pkg.discount_percentage}%</div>
                      <div>Valid for: {pkg.expiry_months} months</div>
                      <div>Status: {pkg.is_active ? 'Active' : 'Inactive'}</div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="pricing" className="space-y-4">
            <div className="flex justify-between items-center">
              <h2 className="text-xl font-semibold text-white">Component Pricing</h2>
              <Dialog open={showNewPricingDialog} onOpenChange={setShowNewPricingDialog}>
                <DialogTrigger asChild>
                  <Button className="bg-purple-600 hover:bg-purple-700">
                    <Plus className="w-4 h-4 mr-2" />
                    New Pricing Rule
                  </Button>
                </DialogTrigger>
                <DialogContent className="bg-gray-900 border-gray-800">
                  <DialogHeader>
                    <DialogTitle className="text-white">Create New Pricing Rule</DialogTitle>
                  </DialogHeader>
                  <PricingForm 
                    pricing={null} 
                    onSave={handleSavePricing} 
                    onCancel={() => setShowNewPricingDialog(false)} 
                  />
                </DialogContent>
              </Dialog>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {componentPricing.map((pricing) => (
                <Card key={pricing.id} className="bg-gray-900 border-gray-800">
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle className="text-white capitalize">
                          {pricing.component_name.replace('_', ' ')}
                        </CardTitle>
                        <p className="text-gray-400 capitalize">
                          {pricing.action_name.replace('_', ' ')}
                        </p>
                      </div>
                      <Button 
                        size="sm" 
                        variant="outline" 
                        className="border-gray-700"
                        onClick={() => setEditingPricing(pricing)}
                      >
                        <Edit2 className="w-3 h-3" />
                      </Button>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <div className="text-2xl font-bold text-purple-400">
                        {pricing.credit_cost} credits
                      </div>
                      <div className="text-sm text-gray-400">
                        {pricing.description || 'No description'}
                      </div>
                      <Badge className={pricing.is_active ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'}>
                        {pricing.is_active ? 'Active' : 'Inactive'}
                      </Badge>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="features" className="space-y-4">
            <h2 className="text-xl font-semibold text-white">Pricing Feature Flags</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {featureFlags.map((flag) => (
                <Card key={flag.component_name} className="bg-gray-900 border-gray-800">
                  <CardContent className="p-6">
                    <div className="flex justify-between items-center">
                      <div>
                        <h3 className="font-medium text-white capitalize">
                          {flag.component_name.replace('_', ' ')}
                        </h3>
                        <p className="text-sm text-gray-400">
                          {flag.is_pricing_enabled ? 'Pricing enabled' : 'Free access'}
                        </p>
                      </div>
                      <Switch
                        checked={flag.is_pricing_enabled}
                        onCheckedChange={(checked) => handleToggleFeatureFlag(flag.component_name, checked)}
                      />
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="users" className="space-y-4">
            <h2 className="text-xl font-semibold text-white">User Credit Management</h2>
            <Card className="bg-gray-900 border-gray-800">
              <CardHeader>
                <CardTitle className="text-white">Adjust User Credits</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <Label className="text-gray-300">User ID</Label>
                    <Input
                      className="bg-gray-800 border-gray-700 text-white"
                      placeholder="Enter user ID"
                      value={userAdjustment.user_id}
                      onChange={(e) => setUserAdjustment(prev => ({ ...prev, user_id: e.target.value }))}
                    />
                  </div>
                  <div>
                    <Label className="text-gray-300">Credit Amount</Label>
                    <Input
                      type="number"
                      className="bg-gray-800 border-gray-700 text-white"
                      placeholder="Credits to add/remove"
                      value={userAdjustment.amount}
                      onChange={(e) => setUserAdjustment(prev => ({ ...prev, amount: Number.parseInt(e.target.value, 10) || 0 }))}
                    />
                  </div>
                  <div>
                    <Label className="text-gray-300">Reason</Label>
                    <Input
                      className="bg-gray-800 border-gray-700 text-white"
                      placeholder="Reason for adjustment"
                      value={userAdjustment.reason}
                      onChange={(e) => setUserAdjustment(prev => ({ ...prev, reason: e.target.value }))}
                    />
                  </div>
                </div>
                <Button 
                  onClick={handleUserCreditAdjustment}
                  className="bg-purple-600 hover:bg-purple-700"
                >
                  <CreditCard className="w-4 h-4 mr-2" />
                  Adjust Credits
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="settings" className="space-y-4">
            <h2 className="text-xl font-semibold text-white">Global Settings</h2>
            <Card className="bg-gray-900 border-gray-800">
              <CardHeader>
                <CardTitle className="text-white">Base Credit Price</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center space-x-4">
                  <div className="flex-1">
                    <Label className="text-gray-300">Price per Credit (EUR)</Label>
                    <Input
                      type="number"
                      step="0.01"
                      className="bg-gray-800 border-gray-700 text-white"
                      value={baseCreditPrice}
                      onChange={(e) => setBaseCreditPrice(Number.parseFloat(e.target.value) || 0)}
                    />
                  </div>
                  <Button 
                    onClick={handleUpdateBaseCreditPrice}
                    className="bg-purple-600 hover:bg-purple-700 mt-6"
                  >
                    <Save className="w-4 h-4 mr-2" />
                    Update Price
                  </Button>
                </div>
                <p className="text-sm text-gray-400">
                  This is the base price used for credit calculations and package pricing.
                </p>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      {/* Edit Package Dialog */}
      {editingPackage && (
        <Dialog open={!!editingPackage} onOpenChange={() => setEditingPackage(null)}>
          <DialogContent className="bg-gray-900 border-gray-800">
            <DialogHeader>
              <DialogTitle className="text-white">Edit Credit Package</DialogTitle>
            </DialogHeader>
            <PackageForm 
              package={editingPackage} 
              onSave={handleSavePackage} 
              onCancel={() => setEditingPackage(null)} 
            />
          </DialogContent>
        </Dialog>
      )}

      {/* Edit Pricing Dialog */}
      {editingPricing && (
        <Dialog open={!!editingPricing} onOpenChange={() => setEditingPricing(null)}>
          <DialogContent className="bg-gray-900 border-gray-800">
            <DialogHeader>
              <DialogTitle className="text-white">Edit Pricing Rule</DialogTitle>
            </DialogHeader>
            <PricingForm 
              pricing={editingPricing} 
              onSave={handleSavePricing} 
              onCancel={() => setEditingPricing(null)} 
            />
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}

// Package Form Component
function PackageForm({ 
  package: pkg, 
  onSave, 
  onCancel 
}: { 
  package: CreditPackage | null; 
  onSave: (pkg: Partial<CreditPackage>) => void; 
  onCancel: () => void; 
}) {
  const [formData, setFormData] = useState<Partial<CreditPackage>>({
    name: pkg?.name || '',
    credits: pkg?.credits || 0,
    price_cents: pkg?.price_cents || 0,
    currency: pkg?.currency || 'EUR',
    discount_percentage: pkg?.discount_percentage || 0,
    is_active: pkg?.is_active ?? true,
    expiry_months: pkg?.expiry_months || 12
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({ ...formData, id: pkg?.id });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label className="text-gray-300">Package Name</Label>
          <Input
            className="bg-gray-800 border-gray-700 text-white"
            value={formData.name}
            onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
            required
          />
        </div>
        <div>
          <Label className="text-gray-300">Credits</Label>
          <Input
            type="number"
            className="bg-gray-800 border-gray-700 text-white"
            value={formData.credits}
            onChange={(e) => setFormData(prev => ({ ...prev, credits: Number.parseInt(e.target.value, 10) || 0 }))}
            required
          />
        </div>
        <div>
          <Label className="text-gray-300">Price (cents)</Label>
          <Input
            type="number"
            className="bg-gray-800 border-gray-700 text-white"
            value={formData.price_cents}
            onChange={(e) => setFormData(prev => ({ ...prev, price_cents: Number.parseInt(e.target.value, 10) || 0 }))}
            required
          />
        </div>
        <div>
          <Label className="text-gray-300">Discount %</Label>
          <Input
            type="number"
            className="bg-gray-800 border-gray-700 text-white"
            value={formData.discount_percentage}
            onChange={(e) => setFormData(prev => ({ ...prev, discount_percentage: Number.parseInt(e.target.value, 10) || 0 }))}
          />
        </div>
        <div>
          <Label className="text-gray-300">Expiry (months)</Label>
          <Input
            type="number"
            className="bg-gray-800 border-gray-700 text-white"
            value={formData.expiry_months}
            onChange={(e) => setFormData(prev => ({ ...prev, expiry_months: Number.parseInt(e.target.value, 10) || 0 }))}
            required
          />
        </div>
        <div className="flex items-center space-x-2">
          <Switch
            checked={formData.is_active}
            onCheckedChange={(checked) => setFormData(prev => ({ ...prev, is_active: checked }))}
          />
          <Label className="text-gray-300">Active</Label>
        </div>
      </div>
      <div className="flex space-x-4">
        <Button type="button" variant="outline" onClick={onCancel} className="border-gray-700">
          <X className="w-4 h-4 mr-2" />
          Cancel
        </Button>
        <Button type="submit" className="bg-purple-600 hover:bg-purple-700">
          <Save className="w-4 h-4 mr-2" />
          Save Package
        </Button>
      </div>
    </form>
  );
}

// Pricing Form Component
function PricingForm({ 
  pricing, 
  onSave, 
  onCancel 
}: { 
  pricing: ComponentPricing | null; 
  onSave: (pricing: Partial<ComponentPricing>) => void; 
  onCancel: () => void; 
}) {
  const [formData, setFormData] = useState<Partial<ComponentPricing>>({
    component_name: pricing?.component_name || '',
    action_name: pricing?.action_name || '',
    credit_cost: pricing?.credit_cost || 0,
    is_active: pricing?.is_active ?? true,
    description: pricing?.description || ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({ ...formData, id: pricing?.id });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label className="text-gray-300">Component Name</Label>
          <Input
            className="bg-gray-800 border-gray-700 text-white"
            value={formData.component_name}
            onChange={(e) => setFormData(prev => ({ ...prev, component_name: e.target.value }))}
            required
          />
        </div>
        <div>
          <Label className="text-gray-300">Action Name</Label>
          <Input
            className="bg-gray-800 border-gray-700 text-white"
            value={formData.action_name}
            onChange={(e) => setFormData(prev => ({ ...prev, action_name: e.target.value }))}
            required
          />
        </div>
        <div>
          <Label className="text-gray-300">Credit Cost</Label>
          <Input
            type="number"
            className="bg-gray-800 border-gray-700 text-white"
            value={formData.credit_cost}
            onChange={(e) => setFormData(prev => ({ ...prev, credit_cost: Number.parseInt(e.target.value, 10) || 0 }))}
            required
          />
        </div>
        <div className="flex items-center space-x-2">
          <Switch
            checked={formData.is_active}
            onCheckedChange={(checked) => setFormData(prev => ({ ...prev, is_active: checked }))}
          />
          <Label className="text-gray-300">Active</Label>
        </div>
      </div>
      <div>
        <Label className="text-gray-300">Description</Label>
        <Input
          className="bg-gray-800 border-gray-700 text-white"
          value={formData.description}
          onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
          placeholder="Optional description"
        />
      </div>
      <div className="flex space-x-4">
        <Button type="button" variant="outline" onClick={onCancel} className="border-gray-700">
          <X className="w-4 h-4 mr-2" />
          Cancel
        </Button>
        <Button type="submit" className="bg-purple-600 hover:bg-purple-700">
          <Save className="w-4 h-4 mr-2" />
          Save Pricing
        </Button>
      </div>
    </form>
  );
}
