import React, { useState, useEffect } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import {
  Rss,
  Globe,
  Activity,
  Clock,
  AlertTriangle,
  CheckCircle,
  XCircle,
  Play,
  Pause,
  Settings,
  Plus,
  Trash2,
  RefreshCw,
  Bell,
  Webhook,
  GitBranch,
  History,
  RotateCcw,
  Download,
  Upload,
  Eye,
  ExternalLink,
  Calendar,
  TrendingUp,
  Database,
  Server,
  Shield,
  Zap,
  Target
} from 'lucide-react';
import { toast } from 'sonner';
import brain from 'brain';

interface RegulatoryFeed {
  id: number;
  name: string;
  jurisdiction: string;
  feed_type: 'rss' | 'api' | 'scraper' | 'manual';
  source_url: string;
  update_frequency: 'hourly' | 'daily' | 'weekly' | 'monthly';
  status: 'active' | 'paused' | 'error' | 'disabled';
  last_checked?: string;
  last_update_found?: string;
  error_count: number;
  configuration: Record<string, any>;
  created_at?: string;
}

interface DocumentVersion {
  id: number;
  document_id: number;
  version_number: number;
  title: string;
  content: string;
  change_summary?: string;
  change_type: string;
  created_by: string;
  created_at: string;
  is_current: boolean;
}

interface WebhookConfig {
  id: number;
  name: string;
  endpoint_url: string;
  event_types: string[];
  is_active: boolean;
  success_count: number;
  failure_count: number;
  created_at: string;
}

const RegulatoryMonitoring: React.FC = () => {
  const [activeTab, setActiveTab] = useState('feeds');
  const [feeds, setFeeds] = useState<RegulatoryFeed[]>([]);
  const [selectedDocument, setSelectedDocument] = useState<number | null>(null);
  const [documentVersions, setDocumentVersions] = useState<DocumentVersion[]>([]);
  const [webhooks, setWebhooks] = useState<WebhookConfig[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [showCreateFeed, setShowCreateFeed] = useState(false);
  const [showCreateWebhook, setShowCreateWebhook] = useState(false);
  const [showRollbackDialog, setShowRollbackDialog] = useState(false);

  // Form states
  const [newFeed, setNewFeed] = useState({
    name: '',
    jurisdiction: '',
    feed_type: 'rss' as const,
    source_url: '',
    update_frequency: 'daily' as const,
    configuration: {}
  });

  const [newWebhook, setNewWebhook] = useState({
    name: '',
    endpoint_url: '',
    event_types: [] as string[],
    secret_key: ''
  });

  const [rollbackData, setRollbackData] = useState({
    target_version: 1,
    reason: ''
  });

  useEffect(() => {
    loadFeeds();
    loadWebhooks();
  }, []);

  const loadFeeds = async () => {
    try {
      const response = await brain.list_regulatory_feeds();
      if (response.ok) {
        const data = await response.json();
        setFeeds(data);
      }
    } catch (error) {
      console.error('Error loading feeds:', error);
      toast.error('Failed to load regulatory feeds');
    }
  };

  const loadDocumentVersions = async (documentId: number) => {
    try {
      setIsLoading(true);
      const response = await brain.get_document_versions({ documentId });
      if (response.ok) {
        const data = await response.json();
        setDocumentVersions(data);
      }
    } catch (error) {
      console.error('Error loading document versions:', error);
      toast.error('Failed to load document versions');
    } finally {
      setIsLoading(false);
    }
  };

  const loadWebhooks = async () => {
    try {
      const response = await brain.list_webhooks();
      if (response.ok) {
        const data = await response.json();
        setWebhooks(data);
      }
    } catch (error) {
      console.error('Error loading webhooks:', error);
      toast.error('Failed to load webhooks');
    }
  };

  const createFeed = async () => {
    try {
      setIsLoading(true);
      const response = await brain.create_regulatory_feed(newFeed);
      if (response.ok) {
        toast.success('Regulatory feed created successfully');
        setShowCreateFeed(false);
        setNewFeed({
          name: '',
          jurisdiction: '',
          feed_type: 'rss',
          source_url: '',
          update_frequency: 'daily',
          configuration: {}
        });
        loadFeeds();
      }
    } catch (error) {
      console.error('Error creating feed:', error);
      toast.error('Failed to create regulatory feed');
    } finally {
      setIsLoading(false);
    }
  };

  const checkFeedForUpdates = async (feedId: number) => {
    try {
      setIsLoading(true);
      const response = await brain.check_feed_for_updates({ feedId });
      if (response.ok) {
        const data = await response.json();
        toast.success(`Feed check completed: ${data.updates_found} updates found`);
        loadFeeds();
      }
    } catch (error) {
      console.error('Error checking feed:', error);
      toast.error('Failed to check feed for updates');
    } finally {
      setIsLoading(false);
    }
  };

  const rollbackDocument = async () => {
    if (!selectedDocument) return;
    
    try {
      setIsLoading(true);
      const response = await brain.rollback_document(
        { documentId: selectedDocument },
        rollbackData
      );
      if (response.ok) {
        const data = await response.json();
        toast.success(`Document rolled back to version ${rollbackData.target_version}`);
        setShowRollbackDialog(false);
        loadDocumentVersions(selectedDocument);
      }
    } catch (error) {
      console.error('Error rolling back document:', error);
      toast.error('Failed to rollback document');
    } finally {
      setIsLoading(false);
    }
  };

  const createWebhook = async () => {
    try {
      setIsLoading(true);
      const response = await brain.create_webhook(newWebhook);
      if (response.ok) {
        toast.success('Webhook created successfully');
        setShowCreateWebhook(false);
        setNewWebhook({
          name: '',
          endpoint_url: '',
          event_types: [],
          secret_key: ''
        });
        loadWebhooks();
      }
    } catch (error) {
      console.error('Error creating webhook:', error);
      toast.error('Failed to create webhook');
    } finally {
      setIsLoading(false);
    }
  };

  const testWebhook = async (webhookId: number) => {
    try {
      const response = await brain.test_webhook({ webhookId });
      if (response.ok) {
        toast.success('Webhook test sent successfully');
      }
    } catch (error) {
      console.error('Error testing webhook:', error);
      toast.error('Failed to test webhook');
    }
  };

  const getFeedTypeIcon = (type: string) => {
    switch (type) {
      case 'rss': return <Rss className="w-4 h-4" />;
      case 'api': return <Database className="w-4 h-4" />;
      case 'scraper': return <Globe className="w-4 h-4" />;
      default: return <Server className="w-4 h-4" />;
    }
  };

  const getStatusBadge = (status: string) => {
    const statusConfig = {
      active: { color: 'bg-green-500', icon: <CheckCircle className="w-3 h-3" /> },
      paused: { color: 'bg-yellow-500', icon: <Pause className="w-3 h-3" /> },
      error: { color: 'bg-red-500', icon: <XCircle className="w-3 h-3" /> },
      disabled: { color: 'bg-gray-500', icon: <XCircle className="w-3 h-3" /> }
    };
    
    const config = statusConfig[status as keyof typeof statusConfig] || statusConfig.disabled;
    
    return (
      <Badge className={`${config.color} text-white flex items-center gap-1`}>
        {config.icon}
        {status}
      </Badge>
    );
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900">
      <div className="container mx-auto px-6 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-white mb-2 flex items-center gap-3">
            <Activity className="w-8 h-8 text-blue-400" />
            Regulatory Monitoring & Automation
          </h1>
          <p className="text-slate-400 text-lg">
            Automated regulatory content feeds, enhanced version control, and webhook integrations
          </p>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="bg-gray-800 border-gray-700">
            <TabsTrigger value="feeds" className="data-[state=active]:bg-blue-600">
              <Rss className="w-4 h-4 mr-2" />
              Content Feeds
            </TabsTrigger>
            <TabsTrigger value="versions" className="data-[state=active]:bg-blue-600">
              <GitBranch className="w-4 h-4 mr-2" />
              Version Control
            </TabsTrigger>
            <TabsTrigger value="webhooks" className="data-[state=active]:bg-blue-600">
              <Webhook className="w-4 h-4 mr-2" />
              Webhooks
            </TabsTrigger>
            <TabsTrigger value="analytics" className="data-[state=active]:bg-blue-600">
              <TrendingUp className="w-4 h-4 mr-2" />
              Analytics
            </TabsTrigger>
          </TabsList>

          {/* Content Feeds Tab */}
          <TabsContent value="feeds" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold text-white">Automated Content Feeds</h2>
              <Dialog open={showCreateFeed} onOpenChange={setShowCreateFeed}>
                <DialogTrigger asChild>
                  <Button className="bg-blue-600 hover:bg-blue-700">
                    <Plus className="w-4 h-4 mr-2" />
                    Add Feed
                  </Button>
                </DialogTrigger>
                <DialogContent className="bg-gray-800 border-gray-700 max-w-md">
                  <DialogHeader>
                    <DialogTitle className="text-white">Create Regulatory Feed</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div>
                      <Label className="text-white">Feed Name</Label>
                      <Input
                        value={newFeed.name}
                        onChange={(e) => setNewFeed({...newFeed, name: e.target.value})}
                        placeholder="EU Export Control Updates"
                        className="bg-gray-700 border-gray-600 text-white"
                      />
                    </div>
                    <div>
                      <Label className="text-white">Jurisdiction</Label>
                      <Input
                        value={newFeed.jurisdiction}
                        onChange={(e) => setNewFeed({...newFeed, jurisdiction: e.target.value})}
                        placeholder="European Union"
                        className="bg-gray-700 border-gray-600 text-white"
                      />
                    </div>
                    <div>
                      <Label className="text-white">Feed Type</Label>
                      <Select value={newFeed.feed_type} onValueChange={(value: any) => setNewFeed({...newFeed, feed_type: value})}>
                        <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent className="bg-gray-700 border-gray-600">
                          <SelectItem value="rss">RSS Feed</SelectItem>
                          <SelectItem value="api">API Endpoint</SelectItem>
                          <SelectItem value="scraper">Web Scraper</SelectItem>
                          <SelectItem value="manual">Manual Updates</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label className="text-white">Source URL</Label>
                      <Input
                        value={newFeed.source_url}
                        onChange={(e) => setNewFeed({...newFeed, source_url: e.target.value})}
                        placeholder="https://eur-lex.europa.eu/rss/"
                        className="bg-gray-700 border-gray-600 text-white"
                      />
                    </div>
                    <div>
                      <Label className="text-white">Update Frequency</Label>
                      <Select value={newFeed.update_frequency} onValueChange={(value: any) => setNewFeed({...newFeed, update_frequency: value})}>
                        <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent className="bg-gray-700 border-gray-600">
                          <SelectItem value="hourly">Hourly</SelectItem>
                          <SelectItem value="daily">Daily</SelectItem>
                          <SelectItem value="weekly">Weekly</SelectItem>
                          <SelectItem value="monthly">Monthly</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="flex gap-2 pt-4">
                      <Button
                        onClick={createFeed}
                        disabled={isLoading}
                        className="flex-1 bg-blue-600 hover:bg-blue-700"
                      >
                        {isLoading ? 'Creating...' : 'Create Feed'}
                      </Button>
                    </div>
                  </div>
                </DialogContent>
              </Dialog>
            </div>

            <div className="grid gap-4">
              {feeds.map((feed) => (
                <Card key={feed.id} className="bg-gray-800 border-gray-700">
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          {getFeedTypeIcon(feed.feed_type)}
                          <h3 className="text-white font-semibold text-lg">{feed.name}</h3>
                          {getStatusBadge(feed.status)}
                        </div>
                        <p className="text-slate-400 mb-3">{feed.jurisdiction}</p>
                        <div className="grid grid-cols-2 gap-4 text-sm">
                          <div>
                            <span className="text-slate-500">Source:</span>
                            <p className="text-slate-300 break-all">{feed.source_url}</p>
                          </div>
                          <div>
                            <span className="text-slate-500">Frequency:</span>
                            <p className="text-slate-300 capitalize">{feed.update_frequency}</p>
                          </div>
                          <div>
                            <span className="text-slate-500">Last Checked:</span>
                            <p className="text-slate-300">
                              {feed.last_checked ? new Date(feed.last_checked).toLocaleString() : 'Never'}
                            </p>
                          </div>
                          <div>
                            <span className="text-slate-500">Error Count:</span>
                            <p className="text-slate-300">{feed.error_count}</p>
                          </div>
                        </div>
                      </div>
                      <div className="flex gap-2 ml-4">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => checkFeedForUpdates(feed.id)}
                          disabled={isLoading}
                          className="border-gray-600 text-slate-300 hover:bg-gray-700"
                        >
                          <RefreshCw className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          className="border-gray-600 text-slate-300 hover:bg-gray-700"
                        >
                          <Settings className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
              
              {feeds.length === 0 && (
                <Card className="bg-gray-800 border-gray-700">
                  <CardContent className="p-8 text-center">
                    <Rss className="w-12 h-12 text-slate-500 mx-auto mb-4" />
                    <h3 className="text-white font-semibold mb-2">No feeds configured</h3>
                    <p className="text-slate-400 mb-4">Set up automated regulatory content feeds to stay updated with the latest regulations.</p>
                    <Button onClick={() => setShowCreateFeed(true)} className="bg-blue-600 hover:bg-blue-700">
                      <Plus className="w-4 h-4 mr-2" />
                      Create Your First Feed
                    </Button>
                  </CardContent>
                </Card>
              )}
            </div>
          </TabsContent>

          {/* Version Control Tab */}
          <TabsContent value="versions" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold text-white">Enhanced Version Control</h2>
              <div className="flex gap-2">
                <Input
                  type="number"
                  placeholder="Document ID"
                  value={selectedDocument || ''}
                  onChange={(e) => setSelectedDocument(Number(e.target.value))}
                  className="w-32 bg-gray-700 border-gray-600 text-white"
                />
                <Button
                  onClick={() => selectedDocument && loadDocumentVersions(selectedDocument)}
                  disabled={!selectedDocument || isLoading}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  <Eye className="w-4 h-4 mr-2" />
                  Load Versions
                </Button>
              </div>
            </div>

            {selectedDocument && (
              <Card className="bg-gray-800 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white flex items-center justify-between">
                    <span className="flex items-center gap-2">
                      <GitBranch className="w-5 h-5" />
                      Document Versions (ID: {selectedDocument})
                    </span>
                    <Dialog open={showRollbackDialog} onOpenChange={setShowRollbackDialog}>
                      <DialogTrigger asChild>
                        <Button variant="outline" className="border-gray-600 text-slate-300">
                          <RotateCcw className="w-4 h-4 mr-2" />
                          Rollback
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="bg-gray-800 border-gray-700">
                        <DialogHeader>
                          <DialogTitle className="text-white">Rollback Document</DialogTitle>
                        </DialogHeader>
                        <div className="space-y-4">
                          <div>
                            <Label className="text-white">Target Version</Label>
                            <Input
                              type="number"
                              value={rollbackData.target_version}
                              onChange={(e) => setRollbackData({...rollbackData, target_version: Number(e.target.value)})}
                              className="bg-gray-700 border-gray-600 text-white"
                            />
                          </div>
                          <div>
                            <Label className="text-white">Rollback Reason</Label>
                            <Textarea
                              value={rollbackData.reason}
                              onChange={(e) => setRollbackData({...rollbackData, reason: e.target.value})}
                              placeholder="Explain why this rollback is necessary..."
                              className="bg-gray-700 border-gray-600 text-white"
                            />
                          </div>
                          <div className="flex gap-2 pt-4">
                            <Button
                              onClick={rollbackDocument}
                              disabled={isLoading}
                              className="flex-1 bg-red-600 hover:bg-red-700"
                            >
                              {isLoading ? 'Rolling back...' : 'Confirm Rollback'}
                            </Button>
                          </div>
                        </div>
                      </DialogContent>
                    </Dialog>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-96">
                    <div className="space-y-3">
                      {documentVersions.map((version) => (
                        <div key={version.id} className="p-4 bg-gray-700/50 rounded-lg border border-gray-600">
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <div className="flex items-center gap-3 mb-2">
                                <Badge className={version.is_current ? 'bg-green-600' : 'bg-gray-600'}>
                                  v{version.version_number}
                                </Badge>
                                <span className="text-white font-medium">{version.title}</span>
                                {version.is_current && (
                                  <Badge className="bg-blue-600 text-white">Current</Badge>
                                )}
                              </div>
                              <p className="text-slate-400 text-sm mb-2">{version.change_summary}</p>
                              <div className="flex items-center gap-4 text-xs text-slate-500">
                                <span>Type: {version.change_type}</span>
                                <span>By: {version.created_by}</span>
                                <span>{new Date(version.created_at).toLocaleString()}</span>
                              </div>
                            </div>
                            <div className="flex gap-2">
                              <Button variant="outline" size="sm" className="border-gray-600 text-slate-300">
                                <Eye className="w-3 h-3" />
                              </Button>
                              <Button variant="outline" size="sm" className="border-gray-600 text-slate-300">
                                <Download className="w-3 h-3" />
                              </Button>
                            </div>
                          </div>
                        </div>
                      ))}
                      
                      {documentVersions.length === 0 && (
                        <div className="text-center py-8">
                          <History className="w-12 h-12 text-slate-500 mx-auto mb-4" />
                          <p className="text-slate-400">No versions found for this document</p>
                        </div>
                      )}
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          {/* Webhooks Tab */}
          <TabsContent value="webhooks" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold text-white">Webhook Integrations</h2>
              <Dialog open={showCreateWebhook} onOpenChange={setShowCreateWebhook}>
                <DialogTrigger asChild>
                  <Button className="bg-blue-600 hover:bg-blue-700">
                    <Plus className="w-4 h-4 mr-2" />
                    Add Webhook
                  </Button>
                </DialogTrigger>
                <DialogContent className="bg-gray-800 border-gray-700">
                  <DialogHeader>
                    <DialogTitle className="text-white">Create Webhook</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div>
                      <Label className="text-white">Webhook Name</Label>
                      <Input
                        value={newWebhook.name}
                        onChange={(e) => setNewWebhook({...newWebhook, name: e.target.value})}
                        placeholder="Document Updates Notification"
                        className="bg-gray-700 border-gray-600 text-white"
                      />
                    </div>
                    <div>
                      <Label className="text-white">Endpoint URL</Label>
                      <Input
                        value={newWebhook.endpoint_url}
                        onChange={(e) => setNewWebhook({...newWebhook, endpoint_url: e.target.value})}
                        placeholder="https://api.example.com/webhooks"
                        className="bg-gray-700 border-gray-600 text-white"
                      />
                    </div>
                    <div>
                      <Label className="text-white">Secret Key (Optional)</Label>
                      <Input
                        value={newWebhook.secret_key}
                        onChange={(e) => setNewWebhook({...newWebhook, secret_key: e.target.value})}
                        placeholder="webhook_secret_key"
                        className="bg-gray-700 border-gray-600 text-white"
                      />
                    </div>
                    <div className="flex gap-2 pt-4">
                      <Button
                        onClick={createWebhook}
                        disabled={isLoading}
                        className="flex-1 bg-blue-600 hover:bg-blue-700"
                      >
                        {isLoading ? 'Creating...' : 'Create Webhook'}
                      </Button>
                    </div>
                  </div>
                </DialogContent>
              </Dialog>
            </div>

            <div className="grid gap-4">
              {webhooks.map((webhook) => (
                <Card key={webhook.id} className="bg-gray-800 border-gray-700">
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <Webhook className="w-5 h-5 text-purple-400" />
                          <h3 className="text-white font-semibold text-lg">{webhook.name}</h3>
                          <Badge className={webhook.is_active ? 'bg-green-600' : 'bg-gray-600'}>
                            {webhook.is_active ? 'Active' : 'Inactive'}
                          </Badge>
                        </div>
                        <p className="text-slate-400 mb-3 break-all">{webhook.endpoint_url}</p>
                        <div className="grid grid-cols-3 gap-4 text-sm">
                          <div>
                            <span className="text-slate-500">Events:</span>
                            <p className="text-slate-300">{webhook.event_types.join(', ')}</p>
                          </div>
                          <div>
                            <span className="text-slate-500">Success:</span>
                            <p className="text-green-400">{webhook.success_count}</p>
                          </div>
                          <div>
                            <span className="text-slate-500">Failures:</span>
                            <p className="text-red-400">{webhook.failure_count}</p>
                          </div>
                        </div>
                      </div>
                      <div className="flex gap-2 ml-4">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => testWebhook(webhook.id)}
                          className="border-gray-600 text-slate-300 hover:bg-gray-700"
                        >
                          <Zap className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          className="border-gray-600 text-slate-300 hover:bg-gray-700"
                        >
                          <Settings className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Analytics Tab */}
          <TabsContent value="analytics" className="space-y-6">
            <h2 className="text-2xl font-bold text-white">Monitoring Analytics</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card className="bg-gray-800 border-gray-700">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-slate-400 text-sm">Active Feeds</p>
                      <p className="text-2xl font-bold text-white">{feeds.filter(f => f.status === 'active').length}</p>
                    </div>
                    <Activity className="w-8 h-8 text-green-400" />
                  </div>
                </CardContent>
              </Card>
              
              <Card className="bg-gray-800 border-gray-700">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-slate-400 text-sm">Total Webhooks</p>
                      <p className="text-2xl font-bold text-white">{webhooks.length}</p>
                    </div>
                    <Webhook className="w-8 h-8 text-purple-400" />
                  </div>
                </CardContent>
              </Card>
              
              <Card className="bg-gray-800 border-gray-700">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-slate-400 text-sm">Webhook Success Rate</p>
                      <p className="text-2xl font-bold text-white">
                        {webhooks.length > 0 
                          ? Math.round((webhooks.reduce((acc, w) => acc + w.success_count, 0) / 
                            (webhooks.reduce((acc, w) => acc + w.success_count + w.failure_count, 0) || 1)) * 100)
                          : 0}%
                      </p>
                    </div>
                    <TrendingUp className="w-8 h-8 text-blue-400" />
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default RegulatoryMonitoring;