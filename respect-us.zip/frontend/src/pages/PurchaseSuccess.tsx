import React, { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import { 
  CheckCircle, 
  CreditCard, 
  ArrowRight, 
  Home,
  Loader2,
  Gift,
  Star,
  Sparkles
} from 'lucide-react';
import brain from 'brain';
import { useUserGuardContext } from 'app/auth';

interface PurchaseDetails {
  package_name: string;
  credits_purchased: number;
  amount_paid: number;
  currency: string;
  transaction_id: string;
  purchase_date: string;
}

const PurchaseSuccess = () => {
  const { user } = useUserGuardContext();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const [loading, setLoading] = useState(true);
  const [purchaseDetails, setPurchaseDetails] = useState<PurchaseDetails | null>(null);
  const [creditsBalance, setCreditsBalance] = useState<number>(0);
  
  const sessionId = searchParams.get('session_id');
  const fromProfile = searchParams.get('from') === 'profile';

  useEffect(() => {
    if (sessionId) {
      verifyPurchase();
    } else {
      // Handle case where there's no session ID (direct navigation)
      setLoading(false);
      toast.error('Invalid purchase session');
    }
  }, [sessionId]);

  const verifyPurchase = async () => {
    try {
      setLoading(true);
      
      // In a real implementation, you would verify the purchase with Stripe
      // For now, we'll simulate a successful purchase verification
      
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Mock purchase details - in real implementation, this would come from your backend
      const mockPurchaseDetails: PurchaseDetails = {
        package_name: 'Professional Package',
        credits_purchased: 500,
        amount_paid: 4999, // in cents
        currency: 'USD',
        transaction_id: sessionId || 'mock_' + Date.now(),
        purchase_date: new Date().toISOString()
      };
      
      setPurchaseDetails(mockPurchaseDetails);
      setCreditsBalance(mockPurchaseDetails.credits_purchased);
      
      // Show success message
      toast.success('Purchase completed successfully!');
      
    } catch (error) {
      console.error('Error verifying purchase:', error);
      toast.error('Failed to verify purchase. Please contact support.');
    } finally {
      setLoading(false);
    }
  };

  const formatPrice = (priceCents: number, currency: string) => {
    const price = priceCents / 100;
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: currency.toUpperCase()
    }).format(price);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  if (loading) {
    return (
      <div className="container mx-auto p-6">
        <div className="flex items-center justify-center min-h-[400px]">
          <div className="text-center">
            <Loader2 className="w-8 h-8 animate-spin text-blue-600 mx-auto mb-4" />
            <p className="text-gray-400">Verifying your purchase...</p>
          </div>
        </div>
      </div>
    );
  }

  if (!purchaseDetails) {
    return (
      <div className="container mx-auto p-6">
        <div className="text-center max-w-md mx-auto">
          <div className="bg-red-900/20 border border-red-500/30 rounded-lg p-6">
            <h1 className="text-xl font-semibold text-white mb-2">Purchase Verification Failed</h1>
            <p className="text-gray-400 mb-4">
              We couldn't verify your purchase. Please contact support if you believe this is an error.
            </p>
            <Button onClick={() => navigate('/purchase')} variant="outline">
              Return to Purchase
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6 max-w-4xl">
      {/* Success Header */}
      <div className="text-center mb-8">
        <div className="inline-flex items-center justify-center w-16 h-16 bg-green-600/20 rounded-full mb-4">
          <CheckCircle className="w-8 h-8 text-green-400" />
        </div>
        <h1 className="text-4xl font-bold text-white mb-2">
          Purchase Successful!
        </h1>
        <p className="text-xl text-gray-400">
          {fromProfile 
            ? 'Welcome to Respectus! Your account is now fully activated.'
            : 'Your credits have been added to your account.'
          }
        </p>
      </div>

      {/* Purchase Details Card */}
      <Card className="bg-gradient-to-br from-green-900/20 to-blue-900/20 border-green-500/30 mb-6">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Gift className="w-5 h-5 text-green-400" />
            Purchase Details
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div>
                <label className="text-sm text-gray-400">Package</label>
                <p className="text-white font-semibold">{purchaseDetails.package_name}</p>
              </div>
              <div>
                <label className="text-sm text-gray-400">Credits Purchased</label>
                <p className="text-white font-semibold flex items-center gap-2">
                  <Star className="w-4 h-4 text-yellow-400" />
                  {purchaseDetails.credits_purchased.toLocaleString()} credits
                </p>
              </div>
              <div>
                <label className="text-sm text-gray-400">Amount Paid</label>
                <p className="text-white font-semibold">
                  {formatPrice(purchaseDetails.amount_paid, purchaseDetails.currency)}
                </p>
              </div>
            </div>
            <div className="space-y-4">
              <div>
                <label className="text-sm text-gray-400">Transaction ID</label>
                <p className="text-white font-mono text-sm">{purchaseDetails.transaction_id}</p>
              </div>
              <div>
                <label className="text-sm text-gray-400">Purchase Date</label>
                <p className="text-white">{formatDate(purchaseDetails.purchase_date)}</p>
              </div>
              <div>
                <label className="text-sm text-gray-400">Current Balance</label>
                <p className="text-white font-semibold flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-blue-400" />
                  {creditsBalance.toLocaleString()} credits
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Next Steps */}
      <Card className="bg-gray-800/50 border-gray-700 mb-6">
        <CardHeader>
          <CardTitle className="text-white">What's Next?</CardTitle>
          <CardDescription className="text-gray-400">
            Start exploring Respectus compliance tools with your new credits
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-gray-700/30 p-4 rounded-lg">
              <h4 className="text-white font-medium mb-2">Knowledge Base</h4>
              <p className="text-gray-400 text-sm mb-3">
                Access comprehensive regulatory documents and guidance
              </p>
              <Button 
                size="sm" 
                variant="outline" 
                onClick={() => navigate('/knowledge-base')}
                className="w-full"
              >
                Explore
              </Button>
            </div>
            
            <div className="bg-gray-700/30 p-4 rounded-lg">
              <h4 className="text-white font-medium mb-2">Product Classification</h4>
              <p className="text-gray-400 text-sm mb-3">
                Classify your products according to export control regulations
              </p>
              <Button 
                size="sm" 
                variant="outline" 
                onClick={() => navigate('/product-classification')}
                className="w-full"
              >
                Start
              </Button>
            </div>
            
            <div className="bg-gray-700/30 p-4 rounded-lg">
              <h4 className="text-white font-medium mb-2">Customer Screening</h4>
              <p className="text-gray-400 text-sm mb-3">
                Screen customers against sanctions and watchlists
              </p>
              <Button 
                size="sm" 
                variant="outline" 
                onClick={() => navigate('/customer-screening')}
                className="w-full"
              >
                Screen
              </Button>
            </div>
            
            <div className="bg-gray-700/30 p-4 rounded-lg">
              <h4 className="text-white font-medium mb-2">End-Use Checks</h4>
              <p className="text-gray-400 text-sm mb-3">
                Assess country risks and end-use compliance
              </p>
              <Button 
                size="sm" 
                variant="outline" 
                onClick={() => navigate('/end-use-checks')}
                className="w-full"
              >
                Assess
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Action Buttons */}
      <div className="flex flex-col sm:flex-row gap-4 justify-center">
        <Button 
          onClick={() => navigate('/')}
          className="bg-blue-600 hover:bg-blue-700 text-white"
          size="lg"
        >
          <Home className="w-4 h-4 mr-2" />
          Go to Dashboard
        </Button>
        
        {fromProfile && (
          <Button 
            onClick={() => navigate('/knowledge-base')}
            variant="outline"
            className="border-gray-600 text-gray-300 hover:bg-gray-800"
            size="lg"
          >
            <ArrowRight className="w-4 h-4 mr-2" />
            Start Exploring
          </Button>
        )}
      </div>

      {/* Receipt Note */}
      <div className="mt-8 text-center">
        <p className="text-gray-400 text-sm">
          A receipt has been sent to your email address. You can also view your purchase history in your account settings.
        </p>
      </div>
    </div>
  );
};

export default PurchaseSuccess;
