import {
  AcceptInvitationData,
  AcceptInvitationRequest,
  ActivateFreeTierCreditsData,
  ActivateFreeTierData,
  AddPaymentMethodData,
  AdminAdjustCreditsData,
  AdminCreditAdjustment,
  AdminNotificationCreate,
  AdminNotificationUpdate,
  AdminRespondToTicketData,
  AdminSupportResponse,
  AdminValidationRequest,
  AdvancedSearchBlogDocumentsData,
  AdvancedSearchDocumentsData,
  AdvancedSearchRequest,
  AnalyzeDocumentReferencesData,
  AnalyzeRiskTrendsData,
  AnalyzeUploadedFormData,
  AnnotationUpdate,
  AppApisAdminDashboardCategoryRequest,
  AppApisDocumentMetadataBulkImportRequest,
  AppApisDocumentSectionsBulkImportRequest,
  AppApisSanctionsListManagementBulkImportRequest,
  AppApisSavedArticlesCategoryRequest,
  ApplyDefaultPricingData,
  ApprovalRequest,
  ApproveDocumentData,
  ApproveOrRejectDocumentData,
  AssessSanctionsApplicabilityData,
  AssignCategoriesRequest,
  AssignCategoriesToArticleData,
  AutoRechargeConfigRequest,
  AutomatedFeedSource,
  BaseCreditPriceRequest,
  BatchProcessDocumentsData,
  BatchProcessRequest,
  BatchProcessingRequest,
  BatchReportRequest,
  BatchScreenCustomersData,
  BatchScreeningRequest,
  BlockUserData,
  BlockUserRequest,
  BlogSubmissionRequest,
  BodyBulkImportSanctions,
  BodyBulkUploadCriticalCountries,
  BodyImportCriticalProducts,
  BodyImportNotesFromExcel,
  BodyImportXmlSanctions,
  BodyProcessDocument,
  BodySubmitCaseStudy,
  BodySubmitDocument,
  BodyUpdateDocument,
  BodyUploadAssessmentForm,
  BodyUploadCustomerDocument,
  BodyUploadDocument,
  BodyUploadDocumentAttachment,
  BodyUploadImage,
  BulkImportEntriesData,
  BulkImportMetadataOptionsData,
  BulkImportSanctionsData,
  BulkImportSectionsData,
  BulkPricingUpdate,
  BulkProcessFeedsData,
  BulkReorderRequest,
  BulkUpdateOrderRequest,
  BulkUpdatePricingData,
  BulkUpdatePricingPayload,
  BulkUpdateStatusData,
  BulkUpdateStatusPayload,
  BulkUploadCriticalCountriesData,
  CancelInvitationData,
  CheckActionPricingData,
  CheckAndTriggerAlertsData,
  CheckDynamicPricingData,
  CheckFreeTierEligibilityData,
  CheckHealthData,
  CheckIfSavedData,
  CheckUserBlockedData,
  ClassificationOutcomeCreate,
  ClassificationOutcomeUpdate,
  ClassificationTreeCreate,
  ClassificationTreeUpdate,
  ClassificationWorkflowCreate,
  ClassificationWorkflowUpdate,
  CleanupExpiredClassificationsData,
  CleanupProcessingHistoryData,
  ClearCriticalProductsDatabaseData,
  CompareDocumentsData,
  ComparisonRequest,
  CompleteTemplateSelectionData,
  ConfigureFeedAlertsData,
  ConfigureFeedAlertsPayload,
  ConfigureFeedSchedulingData,
  ConfigureFeedSchedulingPayload,
  ConfigureSpendingAlertsData,
  ConfigureSpendingAlertsPayload,
  ConsumeCreditsData,
  ConsumeCreditsRequest,
  CountryCreateRequest,
  CountryReportRequest,
  CountrySearchFilters,
  CountrySearchRequest,
  CountryUpdateRequest,
  CreateAdminNotificationData,
  CreateAnnotationCollabData,
  CreateAnnotationData,
  CreateAnnotationRequest,
  CreateArticleCategoryData,
  CreateBadgeData,
  CreateBadgeRequest,
  CreateBookmarkCollabData,
  CreateBookmarkData,
  CreateBookmarkRequest,
  CreateCategoryData,
  CreateChatThreadData,
  CreateClassificationNoteData,
  CreateClassificationOutcomeData,
  CreateClassificationTreeData,
  CreateCompanyData,
  CreateCompanyRequest,
  CreateComponentPricingData,
  CreateContentItemData,
  CreateContentRequest,
  CreateCountryData,
  CreateCreditPackageData,
  CreateCreditPackageRequest,
  CreateCriticalCountryData,
  CreateCriticalProductData,
  CreateCustomWidgetData,
  CreateCustomerData,
  CreateDocumentAlertData,
  CreateDocumentCrossReferenceData,
  CreateDocumentMetadataOptionData,
  CreateDocumentSectionData,
  CreateFeedSourceData,
  CreateGeographicPricingData,
  CreateGeographicPricingPayload,
  CreateHybridPricingModelData,
  CreateHybridPricingModelPayload,
  CreateIntroductionNodeOptionData,
  CreateIntroductionTreeData,
  CreateIntroductionTreeNodeData,
  CreateInvoiceData,
  CreateInvoiceRequest,
  CreateMetadataOptionData,
  CreateMetadataOptionRequest,
  CreateModulePricingConfigurationData,
  CreateMonitoringScheduleData,
  CreateMonitoringScheduleRequest,
  CreateNodeOptionData,
  CreateNoteRequest,
  CreateOrUpdateRiskAssessmentData,
  CreateOrUpdateScreeningExplanationData,
  CreatePaymentIntentData,
  CreatePricingRequest,
  CreateProductData,
  CreateRegulatoryFeedData,
  CreateRegulatoryFeedPayload,
  CreateRestrictiveMeasureData,
  CreateRestrictiveMeasureRequest,
  CreateSanctionEntityData,
  CreateSanctionsListData,
  CreateSanctionsListEntryData,
  CreateSanctionsNodeData,
  CreateSanctionsNodeOptionData,
  CreateSanctionsTreeData,
  CreateSavedSearchData,
  CreateSectionRequest,
  CreateSupportRequestData,
  CreateTemplateData,
  CreateTemplateRequest,
  CreateThreadRequest,
  CreateTradeCodeData,
  CreateTradeCodeRequest,
  CreateTransactionData,
  CreateTreeFormFieldData,
  CreateTreeIndependentOutcomeData,
  CreateTreeNodeData,
  CreateUsageTierPricingData,
  CreateUsageTierPricingPayload,
  CreateUserData,
  CreateUserRequest,
  CreateWebhookData,
  CreateWidgetRequest,
  CreateWidgetTemplateData,
  CreateWorkflowData,
  CriticalCountryCreate,
  CriticalCountryUpdate,
  CrossReferenceRequest,
  CustomerProduct,
  CustomerProfile,
  CustomerTransactionInput,
  CustomizeTemplateData,
  CustomizeTemplateRequest,
  DefaultPricingRule,
  DeleteAdminNotificationData,
  DeleteAnnotationCollabData,
  DeleteAnnotationData,
  DeleteArticleCategoryData,
  DeleteAssessmentData,
  DeleteAttachmentDocumentData,
  DeleteBadgeData,
  DeleteBookmarkCollabData,
  DeleteBookmarkData,
  DeleteCategoryData,
  DeleteChatData,
  DeleteChatRequest,
  DeleteClassificationData,
  DeleteClassificationNoteData,
  DeleteClassificationOutcomeData,
  DeleteClassificationTreeData,
  DeleteComponentPricingData,
  DeleteContentItemData,
  DeleteCountryData,
  DeleteCreditPackageData,
  DeleteCriticalCountryData,
  DeleteCriticalProductData,
  DeleteCustomWidgetData,
  DeleteCustomerData,
  DeleteDocumentAlertData,
  DeleteDocumentData,
  DeleteDocumentMetadataOptionData,
  DeleteDocumentSectionData,
  DeleteImageData,
  DeleteIntroductionNodeOptionData,
  DeleteIntroductionTreeData,
  DeleteIntroductionTreeNodeData,
  DeleteMessageData,
  DeleteMetadataOptionData,
  DeleteModulePricingConfigurationData,
  DeleteMonitoringScheduleData,
  DeleteNodeOptionData,
  DeleteProductData,
  DeleteRiskAssessmentData,
  DeleteSanctionEntityData,
  DeleteSanctionsListData,
  DeleteSanctionsNodeData,
  DeleteSanctionsNodeOptionData,
  DeleteSanctionsTreeData,
  DeleteSavedSearchData,
  DeleteTemplateData,
  DeleteTransactionData,
  DeleteTreeFormFieldData,
  DeleteTreeNodeData,
  DeleteUserData,
  DeleteUserProfileData,
  DeleteWidgetTemplateData,
  DeleteWorkflowData,
  DismissSpendingAlertData,
  DocumentActivity,
  DocumentAlertCreate,
  DocumentAlertStatusUpdate,
  DocumentAlertUpdate,
  DocumentAnnotationInput,
  DocumentApprovalRequest,
  DocumentLinkingRequest,
  DocumentListRequest,
  DocumentPricingUpdate,
  DocumentSearchRequest,
  DownloadCriticalCountriesTemplateData,
  DownloadCriticalProductsExcelTemplateData,
  DownloadCriticalProductsTemplateData,
  DownloadDocumentFileData,
  DownloadInvoiceData,
  DuplicateClassificationTreeData,
  DuplicateIntroductionTreeData,
  DuplicateIntroductionTreeNodeData,
  DuplicateSanctionsNodeData,
  DuplicateSanctionsTreeData,
  EmailRequest,
  EnhancedUserProfileRequest,
  EnterpriseInvoiceRequest,
  ExportAssessmentPdfData,
  ExportCriticalCountriesData,
  ExportCriticalProductsData,
  ExportMetadataOptionsData,
  ExportNotesToExcelData,
  ExportRequest,
  ExportSanctionsData,
  ExportScreeningResultsData,
  ExportSectionsData,
  ExtendTrialCreditsData,
  ExtractReferencesFromTextData,
  ExtractReferencesFromTextEndpointData,
  ExtractReferencesRequest,
  GenerateBatchReportData,
  GenerateCountryReportData,
  GenerateEnterpriseInvoiceData,
  GenerateIndividualReportData,
  GenerateWidgetCodeData,
  GenerateWidgetCodeRequest,
  GetActiveSpendingAlertsData,
  GetAdminCustomersData,
  GetAdminNotificationsData,
  GetAdminRealTimeDashboardData,
  GetAdminSanctionEntityData,
  GetAdminStatsData,
  GetAdminSupportTicketsData,
  GetAdminUsageAnalyticsData,
  GetAdminValidationTasksData,
  GetAlertsSummaryData,
  GetAllAdminUsersData,
  GetAllCreditPackagesData,
  GetAllCriticalCountriesData,
  GetAllDocumentMetadataOptionsData,
  GetArticleCategoriesData,
  GetAuditLogsData,
  GetAutoRechargeConfigData,
  GetAutoRechargeHistoryData,
  GetAutomationAnalyticsData,
  GetAutomationJobData,
  GetAutomationPerformanceMetricsData,
  GetBackgroundJobsData,
  GetBadgeData,
  GetBaseCreditPriceData,
  GetBillingSettingsData,
  GetBillingSummaryData,
  GetBlogDocumentData,
  GetBlogSearchSuggestionsData,
  GetCategoriesData,
  GetCategoriesHierarchyData,
  GetChatMessagesData,
  GetChatPolicyData,
  GetChatThreadsData,
  GetClassificationCategoriesData,
  GetClassificationNoteByKeyData,
  GetClassificationNotificationsData,
  GetClassificationTreeData,
  GetCollaborationStatsCollabData,
  GetCollaborationStatsData,
  GetCompanyProfileData,
  GetComparisonSuggestionsData,
  GetComplianceMetricsData,
  GetComplianceRegulatoryMetricsData,
  GetComponentPricingData,
  GetComponentUsageBreakdownData,
  GetComprehensivePricingAnalyticsData,
  GetContentByModuleData,
  GetContentItemData,
  GetControlRegimesData,
  GetCountryDetailData,
  GetCountryRestrictionData,
  GetCountryRiskLevelsData,
  GetCreditBalanceData,
  GetCreditPackagesData,
  GetCreditTransactionsData,
  GetCriticalCountriesListData,
  GetCriticalCountriesStatsData,
  GetCriticalProductsSectionContentData,
  GetCriticalProductsStatsData,
  GetCrossReferenceStatsData,
  GetCustomWidgetData,
  GetCustomerDocumentAnalyticsData,
  GetCustomerMonitoringAnalyticsData,
  GetCustomerMonitoringHistoryData,
  GetCustomerProductCategoriesData,
  GetDailyUsageChartData,
  GetDashboardSummaryData,
  GetDetailedDocumentAnalyticsData,
  GetDocumentActivityCollabData,
  GetDocumentActivityData,
  GetDocumentAlertData,
  GetDocumentAnalyticsData,
  GetDocumentAnnotationsCollabData,
  GetDocumentAnnotationsData,
  GetDocumentCrossReferencesData,
  GetDocumentCrossReferencesMonitoringData,
  GetDocumentCrossReferencesProcessingData,
  GetDocumentData,
  GetDocumentMetadataOptionsData,
  GetDocumentPricingData,
  GetDocumentPricingDetailData,
  GetDocumentReferenceIdData,
  GetDocumentSectionsAdminData,
  GetDocumentSectionsData,
  GetDocumentTranslationsData,
  GetEnhancedMetadataOptionsData,
  GetEnhancedUserProfileData,
  GetEnterpriseInvoicesData,
  GetEntityTypesData,
  GetFeedHealthMetricsData,
  GetFeedNotificationsData,
  GetFieldTypesData,
  GetFreeTierStatusData,
  GetGeographicPricingData,
  GetGeographicRegionsData,
  GetHybridPricingModelsData,
  GetIntroductionNodeByKeyData,
  GetIntroductionTreeData,
  GetIntroductionTreeStartNodeData,
  GetInvitationDetailsData,
  GetInvoiceHistoryData,
  GetIssuingAuthoritiesData,
  GetJurisdictionsData,
  GetKnowledgeBaseMetadataOptionsData,
  GetListTypesData,
  GetMeasureTypesData,
  GetMetadataOptionsData,
  GetModelPerformanceData,
  GetModulePricingConfigurationData,
  GetModulePricingConfigurationsData,
  GetMonitoringAlertAnalyticsData,
  GetMonitoringConfigurationData,
  GetMonitoringDashboardSummaryData,
  GetMonitoringScheduleData,
  GetMonitoringStatusData,
  GetMonitoringSystemHealthData,
  GetMyCompaniesData,
  GetMySubmissionsData,
  GetNodeByKeyData,
  GetNotificationPreferencesData,
  GetPaymentFailuresData,
  GetPaymentMethodsData,
  GetPendingInvitationsData,
  GetPendingStatsData,
  GetPendingTasksData,
  GetPerformanceMetricsData,
  GetPricingAnalyticsData,
  GetPricingAuditLogData,
  GetPricingFeatureFlagsData,
  GetProcessedDocumentSectionsData,
  GetProcessingStatusData,
  GetProductClassificationData,
  GetProductRiskLevelsData,
  GetPublishedSanctionsNodeOptionsData,
  GetPublishedSanctionsTreeData,
  GetPublishedSanctionsTreeNodesData,
  GetPublishedWorkflowData,
  GetRealTimeMetricsData,
  GetRelatedDocumentsForDocData,
  GetRestrictionTypesData,
  GetRiskCategoriesData,
  GetRiskIndicatorsData,
  GetRiskLevelsData,
  GetRoleDefinitionsData,
  GetSanctionSourcesData,
  GetSanctionsAuditLogData,
  GetSanctionsJurisdictionsData,
  GetSanctionsListData,
  GetSanctionsListEntriesData,
  GetSanctionsListStatsData,
  GetSanctionsNodeData,
  GetSanctionsNodeOptionData,
  GetSanctionsProgramsData,
  GetSanctionsSearchEntityData,
  GetSanctionsTreeData,
  GetSavedArticlesData,
  GetSavedSearchData,
  GetScreeningAlertsData,
  GetScreeningExplanationData,
  GetScreeningHistoryData,
  GetScreeningPerformanceMetricsData,
  GetSearchAlertsData,
  GetSearchAnalyticsData,
  GetSearchSuggestionsData,
  GetSectionsNotApplicableData,
  GetSupportTicketDetailData,
  GetSupportedFormatsData,
  GetSupportedLanguagesData,
  GetSystemMetricsData,
  GetSystemStatusData,
  GetTeamMembersData,
  GetTemplateData,
  GetTreeFormFieldsData,
  GetTreeStartNodeData,
  GetTrendAnalysisData,
  GetTrialUsageStatsData,
  GetUnreadNotificationCountData,
  GetUsageAnalyticsData,
  GetUsageTierPricingData,
  GetUserAccessStatusData,
  GetUserActivitySummaryData,
  GetUserBehaviorAnalyticsData,
  GetUserBookmarksCollabData,
  GetUserBookmarksData,
  GetUserCollaborationSummaryCollabData,
  GetUserCollaborationSummaryData,
  GetUserNotificationsData,
  GetUserProfileData,
  GetUserSupportTicketsData,
  GetUserUsageSummaryData,
  GetUserValidationStatusData,
  GetValidationTaskDetailData,
  GetVatPreviewData,
  GetWidgetCategoriesData,
  GetWidgetTemplateData,
  GetWorkflowByIdData,
  HitVerificationRequest,
  ImportCriticalProductsData,
  ImportNotesFromExcelData,
  ImportXmlSanctionsData,
  IndividualReportRequest,
  InitializeDefaultContentData,
  IntroductionNavigationRequest,
  IntroductionNodeOptionCreate,
  IntroductionNodeOptionUpdate,
  IntroductionTreeCreate,
  IntroductionTreeNodeCreate,
  IntroductionTreeNodeUpdate,
  IntroductionTreeUpdate,
  InviteTeamMemberData,
  InviteUserRequest,
  InvoiceRequest,
  KnowledgeBaseHealthData,
  ListActiveIntroductionTreesData,
  ListActiveTreesData,
  ListAdminDocumentsData,
  ListAdminTasksData,
  ListAdminWorkflowsData,
  ListAllClassificationOutcomesData,
  ListAttachmentDocumentsData,
  ListAutomationJobsData,
  ListBadgeCategoriesData,
  ListBadgesData,
  ListBlogDocumentsData,
  ListClassificationNotesData,
  ListClassificationOutcomesData,
  ListClassificationTreesData,
  ListCompanyFormsData,
  ListCountriesData,
  ListCriticalCountriesData,
  ListCustomWidgetsData,
  ListCustomerDocumentsData,
  ListCustomersData,
  ListDocumentAlertsData,
  ListDocumentsData,
  ListFeedSourcesData,
  ListImagesData,
  ListIntroductionNodeOptionsData,
  ListIntroductionTreeNodesData,
  ListIntroductionTreesData,
  ListMonitoringSchedulesData,
  ListNodeOptionsData,
  ListPendingDocumentsData,
  ListProductsData,
  ListPublishedSanctionsTreesData,
  ListRegulatoryFeedsData,
  ListRestrictiveMeasuresData,
  ListSanctionEntitiesData,
  ListSanctionsData,
  ListSanctionsListsData,
  ListSanctionsNodeOptionsData,
  ListSanctionsNodesData,
  ListSanctionsTreesData,
  ListSavedClassificationsData,
  ListSavedSearchesData,
  ListTemplatesData,
  ListTradeCodesData,
  ListTransactionsData,
  ListTreeNodesData,
  ListUploadedFormsData,
  ListUserAssessmentsData,
  ListWebhooksData,
  ListWidgetTemplatesData,
  ListWorkflowsData,
  LoadAssessmentData,
  LoadClassificationData,
  LogCustomActionData,
  LogCustomActionPayload,
  ManualTriggerRechargeData,
  MarkAllNotificationsReadData,
  MatchQualificationRequest,
  MetadataOptionRequest,
  MetadataOptionUpdate,
  ModelPerformanceRequest,
  ModulePricingCreate,
  ModulePricingUpdate,
  MonitoringConfiguration,
  MultiQuestionAssessmentRequest,
  NavigateIntroductionTreeData,
  NavigateTreeData,
  NavigationRequest,
  NodeOptionCreate,
  NodeOptionUpdate,
  NotificationPreferencesRequest,
  NotificationRequest,
  NotificationStatusUpdate,
  PaymentIntent,
  PaymentMethodRequest,
  PerformFeedHealthCheckData,
  PredictCustomerRisksData,
  PredictiveRiskRequest,
  PreviewWidgetSearchData,
  PreviewWidgetTemplateData,
  ProcessClassificationMultiQuestionAssessmentData,
  ProcessDocumentData,
  ProcessDocumentReferencesData,
  ProcessFeedEnhancedData,
  ProcessIntroductionMultiQuestionAssessmentData,
  ProcessReferenceRequest,
  ProductReviewUpdate,
  ProductSearchRequest,
  PublishDocumentData,
  PublishDocumentRequest,
  QualifyScreeningMatchData,
  ReactToMessageData,
  ReactionRequest,
  RebuildAllCrossReferencesData,
  RebuildDocumentCrossReferencesData,
  RemoveTeamMemberData,
  ReorderDocumentMetadataOptionsData,
  ReorderMetadataOptionsData,
  ReorderRequest,
  ReorderSectionsData,
  RequestInvoiceData,
  RequestTranslationData,
  ResendInvitationData,
  ResendInvitationRequest,
  ReserveCreditsData,
  ReserveCreditsRequest,
  ResolveAnnotationCollabData,
  ResolveAnnotationData,
  ResolveDocumentReferencesData,
  ResolveDocumentReferencesPayload,
  RespondToValidationData,
  RestoreClassificationData,
  RetryFailedPaymentData,
  RiskAssessmentRequest,
  RiskTrendAnalysisRequest,
  RunSavedSearchData,
  SanctionEntityCreate,
  SanctionEntityUpdate,
  SanctionsAssessmentRequest,
  SanctionsListCreate,
  SanctionsListEntryCreate,
  SanctionsListUpdate,
  SanctionsNodeCreate,
  SanctionsNodeOptionCreate,
  SanctionsNodeOptionUpdate,
  SanctionsNodeUpdate,
  SanctionsSearchRequest,
  SanctionsTreeCreate,
  SanctionsTreeUpdate,
  SaveArticleData,
  SaveArticleRequest,
  SaveAssessmentData,
  SaveAssessmentRequest,
  SaveClassificationData,
  SaveEnhancedUserProfileData,
  SaveMonitoringConfigurationData,
  SaveUserProfileData,
  SavedClassificationRequest,
  SavedSearchRequest,
  SavedSearchUpdate,
  ScheduleRiskAssessmentsData,
  ScheduleRiskAssessmentsRequest,
  ScreenCustomerData,
  ScreenCustomerPayload,
  ScreeningExportRequest,
  SearchBlogDocumentsData,
  SearchCountriesData,
  SearchCriticalCountriesData,
  SearchCriticalProductsData,
  SearchCriticalProductsRequest,
  SearchDocumentsData,
  SearchDocumentsForReferenceData,
  SearchProductsData,
  SearchSanctionsData,
  SearchWatchlistsData,
  SearchWidgetDataData,
  SectionsNotApplicableRequest,
  SelectTemplateData,
  SendAssessmentEmailData,
  SendFeedNotificationData,
  SendInvitationEmailManuallyData,
  SendMessageData,
  SendMessageRequest,
  ServeDocumentData,
  ServeImageData,
  ServePublicImageAltData,
  ServePublicImageData,
  ServeStaticImageData,
  SetupAutoRechargeData,
  StripeWebhookData,
  SubmitBlogArticleData,
  SubmitCaseStudyData,
  SubmitDocumentData,
  SubmitForValidationData,
  SupportRequestCreate,
  TaskUpdateRequest,
  TemplateSelectionRequest,
  TestWidgetData,
  ToggleAutoRechargeData,
  TrackDocumentActivityCollabData,
  TrackDocumentActivityData,
  TrackDocumentActivityPayload,
  TranslationRequest,
  TreeFormFieldCreate,
  TreeFormFieldUpdate,
  TreeNodeCreate,
  TreeNodeUpdate,
  TriggerFeedUpdateData,
  TriggerManualScreeningData,
  TriggerMonitoringData,
  TriggerMonitoringRequest,
  UnsaveArticleData,
  UpdateAdminNotificationData,
  UpdateAlertStatusData,
  UpdateAnnotationCollabData,
  UpdateAnnotationData,
  UpdateAnnotationRequest,
  UpdateArticleCategoryData,
  UpdateBadgeData,
  UpdateBadgeRequest,
  UpdateBaseCreditPriceData,
  UpdateBillingSettingsData,
  UpdateBillingSettingsRequest,
  UpdateBulkPricingData,
  UpdateCategoryData,
  UpdateClassificationNoteData,
  UpdateClassificationOutcomeData,
  UpdateClassificationTreeData,
  UpdateCompanyProfileData,
  UpdateCompanyProfileRequest,
  UpdateComponentPricingData,
  UpdateContentItemData,
  UpdateContentRequest,
  UpdateCountryData,
  UpdateCreditPackageData,
  UpdateCreditPackageRequest,
  UpdateCriticalCountryData,
  UpdateCustomWidgetData,
  UpdateCustomerData,
  UpdateDocumentAlertData,
  UpdateDocumentData,
  UpdateDocumentMetadataOptionData,
  UpdateDocumentPricingData,
  UpdateDocumentSectionData,
  UpdateDocumentStatusData,
  UpdateDocumentStatusRequest,
  UpdateFeatureFlagRequest,
  UpdateIntroductionNodeOptionData,
  UpdateIntroductionTreeData,
  UpdateIntroductionTreeNodeData,
  UpdateInvoiceStatusData,
  UpdateMemberRoleData,
  UpdateMemberRoleRequest,
  UpdateMetadataOptionData,
  UpdateMetadataOptionRequest,
  UpdateModulePricingConfigurationData,
  UpdateMonitoringScheduleData,
  UpdateMonitoringScheduleRequest,
  UpdateNodeOptionData,
  UpdateNoteRequest,
  UpdateNotificationPreferencesData,
  UpdateNotificationStatusData,
  UpdatePricingFeatureFlagData,
  UpdatePricingRequest,
  UpdateProductData,
  UpdateProductReviewData,
  UpdateRiskAssessmentsData,
  UpdateRiskAssessmentsRequest,
  UpdateSanctionEntityData,
  UpdateSanctionsListData,
  UpdateSanctionsNodeData,
  UpdateSanctionsNodeOptionData,
  UpdateSanctionsTreeData,
  UpdateSavedSearchData,
  UpdateSectionRequest,
  UpdateSectionsNotApplicableData,
  UpdateTaskData,
  UpdateTemplateData,
  UpdateTemplateRequest,
  UpdateTransactionData,
  UpdateTreeFormFieldData,
  UpdateTreeNodeData,
  UpdateUserData,
  UpdateUserRequest,
  UpdateWidgetRequest,
  UpdateWidgetTemplateData,
  UpdateWorkflowData,
  UploadAssessmentFormData,
  UploadCustomerDocumentData,
  UploadDocumentAttachmentData,
  UploadDocumentData,
  UploadImageData,
  UserBookmarkInput,
  UserProfileRequest,
  VATPreviewRequest,
  ValidationSubmissionRequest,
  VerifyHitData,
  WatchlistSearchRequest,
  WebhookEndpoint,
  WidgetSearchRequest,
  WidgetTemplate,
  WidgetTestRequest,
} from "./data-contracts";

export namespace Brain {
  /**
   * @description Check health of application. Returns 200 when OK, 500 when not.
   * @name check_health
   * @summary Check Health
   * @request GET:/_healthz
   */
  export namespace check_health {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = CheckHealthData;
  }

  /**
   * @description Get hierarchical categories structure with document counts
   * @tags categories, dbtn/module:categories, dbtn/hasAuth
   * @name get_categories_hierarchy
   * @summary Get Categories Hierarchy
   * @request GET:/routes/categories/hierarchy
   */
  export namespace get_categories_hierarchy {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetCategoriesHierarchyData;
  }

  /**
   * @description Get all enhanced metadata options for document upload and editing
   * @tags dbtn/module:enhanced_metadata, dbtn/hasAuth
   * @name get_enhanced_metadata_options
   * @summary Get Enhanced Metadata Options
   * @request GET:/routes/enhanced-metadata/options
   */
  export namespace get_enhanced_metadata_options {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetEnhancedMetadataOptionsData;
  }

  /**
   * @description Perform search using a custom widget configuration
   * @tags dbtn/module:widget_search, dbtn/hasAuth
   * @name search_widget_data
   * @summary Search Widget Data
   * @request POST:/routes/widget-search/search
   */
  export namespace search_widget_data {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = WidgetSearchRequest;
    export type RequestHeaders = {};
    export type ResponseBody = SearchWidgetDataData;
  }

  /**
   * @description Preview search results for a widget without full configuration
   * @tags dbtn/module:widget_search, dbtn/hasAuth
   * @name preview_widget_search
   * @summary Preview Widget Search
   * @request GET:/routes/widget-search/widget/{widget_id}/preview
   */
  export namespace preview_widget_search {
    export type RequestParams = {
      /** Widget Id */
      widgetId: string;
    };
    export type RequestQuery = {
      /**
       * Query
       * @default "test"
       */
      query?: string;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = PreviewWidgetSearchData;
  }

  /**
   * @description Get all available widget templates
   * @tags dbtn/module:widget_management, dbtn/hasAuth
   * @name list_widget_templates
   * @summary List Widget Templates
   * @request GET:/routes/widget-management/templates
   */
  export namespace list_widget_templates {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ListWidgetTemplatesData;
  }

  /**
   * @description Create a new widget template
   * @tags dbtn/module:widget_management, dbtn/hasAuth
   * @name create_widget_template
   * @summary Create Widget Template
   * @request POST:/routes/widget-management/templates
   */
  export namespace create_widget_template {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = WidgetTemplate;
    export type RequestHeaders = {};
    export type ResponseBody = CreateWidgetTemplateData;
  }

  /**
   * @description Get a specific widget template
   * @tags dbtn/module:widget_management, dbtn/hasAuth
   * @name get_widget_template
   * @summary Get Widget Template
   * @request GET:/routes/widget-management/templates/{template_id}
   */
  export namespace get_widget_template {
    export type RequestParams = {
      /** Template Id */
      templateId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetWidgetTemplateData;
  }

  /**
   * @description Update an existing widget template
   * @tags dbtn/module:widget_management, dbtn/hasAuth
   * @name update_widget_template
   * @summary Update Widget Template
   * @request PUT:/routes/widget-management/templates/{template_id}
   */
  export namespace update_widget_template {
    export type RequestParams = {
      /** Template Id */
      templateId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = WidgetTemplate;
    export type RequestHeaders = {};
    export type ResponseBody = UpdateWidgetTemplateData;
  }

  /**
   * @description Delete a widget template
   * @tags dbtn/module:widget_management, dbtn/hasAuth
   * @name delete_widget_template
   * @summary Delete Widget Template
   * @request DELETE:/routes/widget-management/templates/{template_id}
   */
  export namespace delete_widget_template {
    export type RequestParams = {
      /** Template Id */
      templateId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = DeleteWidgetTemplateData;
  }

  /**
   * @description Get all created custom widgets
   * @tags dbtn/module:widget_management, dbtn/hasAuth
   * @name list_custom_widgets
   * @summary List Custom Widgets
   * @request GET:/routes/widget-management/widgets
   */
  export namespace list_custom_widgets {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ListCustomWidgetsData;
  }

  /**
   * @description Create a new custom widget from a template
   * @tags dbtn/module:widget_management, dbtn/hasAuth
   * @name create_custom_widget
   * @summary Create Custom Widget
   * @request POST:/routes/widget-management/widgets
   */
  export namespace create_custom_widget {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = CreateWidgetRequest;
    export type RequestHeaders = {};
    export type ResponseBody = CreateCustomWidgetData;
  }

  /**
   * @description Get a specific custom widget
   * @tags dbtn/module:widget_management, dbtn/hasAuth
   * @name get_custom_widget
   * @summary Get Custom Widget
   * @request GET:/routes/widget-management/widgets/{widget_id}
   */
  export namespace get_custom_widget {
    export type RequestParams = {
      /** Widget Id */
      widgetId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetCustomWidgetData;
  }

  /**
   * @description Update a custom widget
   * @tags dbtn/module:widget_management, dbtn/hasAuth
   * @name update_custom_widget
   * @summary Update Custom Widget
   * @request PUT:/routes/widget-management/widgets/{widget_id}
   */
  export namespace update_custom_widget {
    export type RequestParams = {
      /** Widget Id */
      widgetId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = UpdateWidgetRequest;
    export type RequestHeaders = {};
    export type ResponseBody = UpdateCustomWidgetData;
  }

  /**
   * @description Delete a custom widget
   * @tags dbtn/module:widget_management, dbtn/hasAuth
   * @name delete_custom_widget
   * @summary Delete Custom Widget
   * @request DELETE:/routes/widget-management/widgets/{widget_id}
   */
  export namespace delete_custom_widget {
    export type RequestParams = {
      /** Widget Id */
      widgetId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = DeleteCustomWidgetData;
  }

  /**
   * @description Test a widget with sample data
   * @tags dbtn/module:widget_management, dbtn/hasAuth
   * @name test_widget
   * @summary Test Widget
   * @request POST:/routes/widget-management/widgets/{widget_id}/test
   */
  export namespace test_widget {
    export type RequestParams = {
      /** Widget Id */
      widgetId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = WidgetTestRequest;
    export type RequestHeaders = {};
    export type ResponseBody = TestWidgetData;
  }

  /**
   * @description Get available widget categories
   * @tags dbtn/module:widget_management, dbtn/hasAuth
   * @name get_widget_categories
   * @summary Get Widget Categories
   * @request GET:/routes/widget-management/categories
   */
  export namespace get_widget_categories {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetWidgetCategoriesData;
  }

  /**
   * @description Get available field types for widget configuration
   * @tags dbtn/module:widget_management, dbtn/hasAuth
   * @name get_field_types
   * @summary Get Field Types
   * @request GET:/routes/widget-management/field-types
   */
  export namespace get_field_types {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetFieldTypesData;
  }

  /**
   * @description Generate React component code for a custom widget
   * @tags dbtn/module:widget_generator, dbtn/hasAuth
   * @name generate_widget_code
   * @summary Generate Widget Code
   * @request POST:/routes/widget-generator/generate
   */
  export namespace generate_widget_code {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = GenerateWidgetCodeRequest;
    export type RequestHeaders = {};
    export type ResponseBody = GenerateWidgetCodeData;
  }

  /**
   * @description Preview what a widget template would generate
   * @tags dbtn/module:widget_generator, dbtn/hasAuth
   * @name preview_widget_template
   * @summary Preview Widget Template
   * @request GET:/routes/widget-generator/templates/{template_id}/preview
   */
  export namespace preview_widget_template {
    export type RequestParams = {
      /** Template Id */
      templateId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = PreviewWidgetTemplateData;
  }

  /**
   * @description Get analytics for documents with views, engagement metrics, and trends
   * @tags analytics, dbtn/module:analytics, dbtn/hasAuth
   * @name get_document_analytics
   * @summary Get Document Analytics
   * @request GET:/routes/analytics/documents
   */
  export namespace get_document_analytics {
    export type RequestParams = {};
    export type RequestQuery = {
      /**
       * Limit
       * @max 100
       * @default 50
       */
      limit?: number;
      /**
       * Sort By
       * @default "popularity_score"
       * @pattern ^(views|popularity_score|trending_score|last_accessed)$
       */
      sort_by?: string;
      /** Jurisdiction */
      jurisdiction?: string | null;
      /**
       * Time Range
       * @default "30d"
       */
      time_range?: string | null;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetDocumentAnalyticsData;
  }

  /**
   * @description Get detailed analytics for a specific document
   * @tags analytics, dbtn/module:analytics, dbtn/hasAuth
   * @name get_detailed_document_analytics
   * @summary Get Detailed Document Analytics
   * @request GET:/routes/analytics/documents/{document_id}/detailed
   */
  export namespace get_detailed_document_analytics {
    export type RequestParams = {
      /** Document Id */
      documentId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetDetailedDocumentAnalyticsData;
  }

  /**
   * @description Get user behavior analytics and engagement patterns
   * @tags analytics, dbtn/module:analytics, dbtn/hasAuth
   * @name get_user_behavior_analytics
   * @summary Get User Behavior Analytics
   * @request GET:/routes/analytics/users/behavior
   */
  export namespace get_user_behavior_analytics {
    export type RequestParams = {};
    export type RequestQuery = {
      /**
       * Limit
       * @max 100
       * @default 50
       */
      limit?: number;
      /**
       * Time Range
       * @default "30d"
       */
      time_range?: string;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetUserBehaviorAnalyticsData;
  }

  /**
   * @description Get search query analytics and patterns
   * @tags analytics, dbtn/module:analytics, dbtn/hasAuth
   * @name get_search_analytics
   * @summary Get Search Analytics
   * @request GET:/routes/analytics/search
   */
  export namespace get_search_analytics {
    export type RequestParams = {};
    export type RequestQuery = {
      /**
       * Limit
       * @max 100
       * @default 50
       */
      limit?: number;
      /**
       * Min Frequency
       * @default 1
       */
      min_frequency?: number;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetSearchAnalyticsData;
  }

  /**
   * @description Get overall system performance and usage metrics
   * @tags analytics, dbtn/module:analytics, dbtn/hasAuth
   * @name get_system_metrics
   * @summary Get System Metrics
   * @request GET:/routes/analytics/system/metrics
   */
  export namespace get_system_metrics {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetSystemMetricsData;
  }

  /**
   * @description Get compliance-specific metrics and KPIs
   * @tags analytics, dbtn/module:analytics, dbtn/hasAuth
   * @name get_compliance_metrics
   * @summary Get Compliance Metrics
   * @request GET:/routes/analytics/compliance/metrics
   */
  export namespace get_compliance_metrics {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetComplianceMetricsData;
  }

  /**
   * @description Get system performance metrics and optimization data
   * @tags analytics, dbtn/module:analytics, dbtn/hasAuth
   * @name get_performance_metrics
   * @summary Get Performance Metrics
   * @request GET:/routes/analytics/performance/metrics
   */
  export namespace get_performance_metrics {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetPerformanceMetricsData;
  }

  /**
   * @description Get translation status and available languages for a document
   * @tags analytics, dbtn/module:analytics, dbtn/hasAuth
   * @name get_document_translations
   * @summary Get Document Translations
   * @request GET:/routes/analytics/multilingual/documents/{document_id}
   */
  export namespace get_document_translations {
    export type RequestParams = {
      /** Document Id */
      documentId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetDocumentTranslationsData;
  }

  /**
   * @description Request translation of a document to a target language
   * @tags analytics, dbtn/module:analytics, dbtn/hasAuth
   * @name request_translation
   * @summary Request Translation
   * @request POST:/routes/analytics/multilingual/translate
   */
  export namespace request_translation {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = TranslationRequest;
    export type RequestHeaders = {};
    export type ResponseBody = RequestTranslationData;
  }

  /**
   * @description Get list of supported languages for translation
   * @tags analytics, dbtn/module:analytics, dbtn/hasAuth
   * @name get_supported_languages
   * @summary Get Supported Languages
   * @request GET:/routes/analytics/multilingual/supported-languages
   */
  export namespace get_supported_languages {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetSupportedLanguagesData;
  }

  /**
   * @description Get comprehensive dashboard summary with key metrics
   * @tags analytics, dbtn/module:analytics, dbtn/hasAuth
   * @name get_dashboard_summary
   * @summary Get Dashboard Summary
   * @request GET:/routes/analytics/dashboard/summary
   */
  export namespace get_dashboard_summary {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetDashboardSummaryData;
  }

  /**
   * @description List all introduction trees
   * @tags dbtn/module:introduction, dbtn/hasAuth
   * @name list_introduction_trees
   * @summary List Introduction Trees
   * @request GET:/routes/introduction/admin/trees
   */
  export namespace list_introduction_trees {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ListIntroductionTreesData;
  }

  /**
   * @description Create a new introduction tree
   * @tags dbtn/module:introduction, dbtn/hasAuth
   * @name create_introduction_tree
   * @summary Create Introduction Tree
   * @request POST:/routes/introduction/admin/trees
   */
  export namespace create_introduction_tree {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = IntroductionTreeCreate;
    export type RequestHeaders = {};
    export type ResponseBody = CreateIntroductionTreeData;
  }

  /**
   * @description Get a specific introduction tree
   * @tags dbtn/module:introduction, dbtn/hasAuth
   * @name get_introduction_tree
   * @summary Get Introduction Tree
   * @request GET:/routes/introduction/admin/trees/{tree_id}
   */
  export namespace get_introduction_tree {
    export type RequestParams = {
      /**
       * Tree Id
       * @format uuid
       */
      treeId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetIntroductionTreeData;
  }

  /**
   * @description Update an introduction tree
   * @tags dbtn/module:introduction, dbtn/hasAuth
   * @name update_introduction_tree
   * @summary Update Introduction Tree
   * @request PUT:/routes/introduction/admin/trees/{tree_id}
   */
  export namespace update_introduction_tree {
    export type RequestParams = {
      /**
       * Tree Id
       * @format uuid
       */
      treeId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = IntroductionTreeUpdate;
    export type RequestHeaders = {};
    export type ResponseBody = UpdateIntroductionTreeData;
  }

  /**
   * @description Delete an introduction tree and all its related data
   * @tags dbtn/module:introduction, dbtn/hasAuth
   * @name delete_introduction_tree
   * @summary Delete Introduction Tree
   * @request DELETE:/routes/introduction/admin/trees/{tree_id}
   */
  export namespace delete_introduction_tree {
    export type RequestParams = {
      /**
       * Tree Id
       * @format uuid
       */
      treeId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = DeleteIntroductionTreeData;
  }

  /**
   * @description Duplicate an introduction tree with all its nodes and options
   * @tags dbtn/module:introduction, dbtn/hasAuth
   * @name duplicate_introduction_tree
   * @summary Duplicate Introduction Tree
   * @request POST:/routes/introduction/admin/trees/{tree_id}/duplicate
   */
  export namespace duplicate_introduction_tree {
    export type RequestParams = {
      /**
       * Tree Id
       * @format uuid
       */
      treeId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = DuplicateIntroductionTreeData;
  }

  /**
   * @description List all nodes for an introduction tree
   * @tags dbtn/module:introduction, dbtn/hasAuth
   * @name list_introduction_tree_nodes
   * @summary List Introduction Tree Nodes
   * @request GET:/routes/introduction/admin/trees/{tree_id}/nodes
   */
  export namespace list_introduction_tree_nodes {
    export type RequestParams = {
      /**
       * Tree Id
       * @format uuid
       */
      treeId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ListIntroductionTreeNodesData;
  }

  /**
   * @description Create a new introduction tree node
   * @tags dbtn/module:introduction, dbtn/hasAuth
   * @name create_introduction_tree_node
   * @summary Create Introduction Tree Node
   * @request POST:/routes/introduction/admin/trees/{tree_id}/nodes
   */
  export namespace create_introduction_tree_node {
    export type RequestParams = {
      /**
       * Tree Id
       * @format uuid
       */
      treeId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = IntroductionTreeNodeCreate;
    export type RequestHeaders = {};
    export type ResponseBody = CreateIntroductionTreeNodeData;
  }

  /**
   * @description Update an introduction tree node
   * @tags dbtn/module:introduction, dbtn/hasAuth
   * @name update_introduction_tree_node
   * @summary Update Introduction Tree Node
   * @request PUT:/routes/introduction/admin/nodes/{node_id}
   */
  export namespace update_introduction_tree_node {
    export type RequestParams = {
      /**
       * Node Id
       * @format uuid
       */
      nodeId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = IntroductionTreeNodeUpdate;
    export type RequestHeaders = {};
    export type ResponseBody = UpdateIntroductionTreeNodeData;
  }

  /**
   * @description Delete an introduction tree node
   * @tags dbtn/module:introduction, dbtn/hasAuth
   * @name delete_introduction_tree_node
   * @summary Delete Introduction Tree Node
   * @request DELETE:/routes/introduction/admin/nodes/{node_id}
   */
  export namespace delete_introduction_tree_node {
    export type RequestParams = {
      /**
       * Node Id
       * @format uuid
       */
      nodeId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = DeleteIntroductionTreeNodeData;
  }

  /**
   * @description Duplicate an introduction tree node with all its options
   * @tags dbtn/module:introduction, dbtn/hasAuth
   * @name duplicate_introduction_tree_node
   * @summary Duplicate Introduction Tree Node
   * @request POST:/routes/introduction/admin/nodes/{node_id}/duplicate
   */
  export namespace duplicate_introduction_tree_node {
    export type RequestParams = {
      /**
       * Node Id
       * @format uuid
       */
      nodeId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = DuplicateIntroductionTreeNodeData;
  }

  /**
   * @description List all options for an introduction tree node
   * @tags dbtn/module:introduction, dbtn/hasAuth
   * @name list_introduction_node_options
   * @summary List Introduction Node Options
   * @request GET:/routes/introduction/admin/nodes/{node_id}/options
   */
  export namespace list_introduction_node_options {
    export type RequestParams = {
      /**
       * Node Id
       * @format uuid
       */
      nodeId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ListIntroductionNodeOptionsData;
  }

  /**
   * @description Create a new option for an introduction tree node
   * @tags dbtn/module:introduction, dbtn/hasAuth
   * @name create_introduction_node_option
   * @summary Create Introduction Node Option
   * @request POST:/routes/introduction/admin/nodes/{node_id}/options
   */
  export namespace create_introduction_node_option {
    export type RequestParams = {
      /**
       * Node Id
       * @format uuid
       */
      nodeId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = IntroductionNodeOptionCreate;
    export type RequestHeaders = {};
    export type ResponseBody = CreateIntroductionNodeOptionData;
  }

  /**
   * @description Update an introduction node option
   * @tags dbtn/module:introduction, dbtn/hasAuth
   * @name update_introduction_node_option
   * @summary Update Introduction Node Option
   * @request PUT:/routes/introduction/admin/options/{option_id}
   */
  export namespace update_introduction_node_option {
    export type RequestParams = {
      /**
       * Option Id
       * @format uuid
       */
      optionId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = IntroductionNodeOptionUpdate;
    export type RequestHeaders = {};
    export type ResponseBody = UpdateIntroductionNodeOptionData;
  }

  /**
   * @description Delete an introduction node option
   * @tags dbtn/module:introduction, dbtn/hasAuth
   * @name delete_introduction_node_option
   * @summary Delete Introduction Node Option
   * @request DELETE:/routes/introduction/admin/options/{option_id}
   */
  export namespace delete_introduction_node_option {
    export type RequestParams = {
      /**
       * Option Id
       * @format uuid
       */
      optionId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = DeleteIntroductionNodeOptionData;
  }

  /**
   * @description List all active introduction trees for public use
   * @tags dbtn/module:introduction, dbtn/hasAuth
   * @name list_active_introduction_trees
   * @summary List Active Introduction Trees
   * @request GET:/routes/introduction/trees
   */
  export namespace list_active_introduction_trees {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ListActiveIntroductionTreesData;
  }

  /**
   * @description Get the starting node for an introduction tree - trigger brain regeneration
   * @tags dbtn/module:introduction, dbtn/hasAuth
   * @name get_introduction_tree_start_node
   * @summary Get Introduction Tree Start Node
   * @request GET:/routes/introduction/trees/{tree_id}/start
   */
  export namespace get_introduction_tree_start_node {
    export type RequestParams = {
      /**
       * Tree Id
       * @format uuid
       */
      treeId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetIntroductionTreeStartNodeData;
  }

  /**
   * @description Get a specific introduction node by its key within a tree
   * @tags dbtn/module:introduction, dbtn/hasAuth
   * @name get_introduction_node_by_key
   * @summary Get Introduction Node By Key
   * @request GET:/routes/introduction/trees/{tree_id}/nodes/{node_key}
   */
  export namespace get_introduction_node_by_key {
    export type RequestParams = {
      /**
       * Tree Id
       * @format uuid
       */
      treeId: string;
      /** Node Key */
      nodeKey: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetIntroductionNodeByKeyData;
  }

  /**
   * @description Navigate through an introduction tree based on user selection
   * @tags dbtn/module:introduction, dbtn/hasAuth
   * @name navigate_introduction_tree
   * @summary Navigate Introduction Tree
   * @request POST:/routes/introduction/trees/{tree_id}/navigate
   */
  export namespace navigate_introduction_tree {
    export type RequestParams = {
      /**
       * Tree Id
       * @format uuid
       */
      treeId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = IntroductionNavigationRequest;
    export type RequestHeaders = {};
    export type ResponseBody = NavigateIntroductionTreeData;
  }

  /**
   * @description Process responses to a multi-question assessment and determine routing
   * @tags dbtn/module:introduction, dbtn/hasAuth
   * @name process_introduction_multi_question_assessment
   * @summary Process Introduction Multi Question Assessment
   * @request POST:/routes/introduction/trees/{tree_id}/nodes/{node_key}/assess
   */
  export namespace process_introduction_multi_question_assessment {
    export type RequestParams = {
      /**
       * Tree Id
       * @format uuid
       */
      treeId: string;
      /** Node Key */
      nodeKey: string;
    };
    export type RequestQuery = {};
    export type RequestBody = MultiQuestionAssessmentRequest;
    export type RequestHeaders = {};
    export type ResponseBody = ProcessIntroductionMultiQuestionAssessmentData;
  }

  /**
   * @description Get all form fields for a classification tree
   * @tags dbtn/module:classification, dbtn/hasAuth
   * @name get_tree_form_fields
   * @summary Get Tree Form Fields
   * @request GET:/routes/classification/tree/{tree_id}/form-fields
   */
  export namespace get_tree_form_fields {
    export type RequestParams = {
      /**
       * Tree Id
       * @format uuid
       */
      treeId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetTreeFormFieldsData;
  }

  /**
   * @description Create a new form field for a classification tree
   * @tags dbtn/module:classification, dbtn/hasAuth
   * @name create_tree_form_field
   * @summary Create Tree Form Field
   * @request POST:/routes/classification/tree/{tree_id}/form-fields
   */
  export namespace create_tree_form_field {
    export type RequestParams = {
      /**
       * Tree Id
       * @format uuid
       */
      treeId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = TreeFormFieldCreate;
    export type RequestHeaders = {};
    export type ResponseBody = CreateTreeFormFieldData;
  }

  /**
   * @description Update a form field for a classification tree
   * @tags dbtn/module:classification, dbtn/hasAuth
   * @name update_tree_form_field
   * @summary Update Tree Form Field
   * @request PUT:/routes/classification/tree/{tree_id}/form-fields/{field_id}
   */
  export namespace update_tree_form_field {
    export type RequestParams = {
      /**
       * Tree Id
       * @format uuid
       */
      treeId: string;
      /** Field Id */
      fieldId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = TreeFormFieldUpdate;
    export type RequestHeaders = {};
    export type ResponseBody = UpdateTreeFormFieldData;
  }

  /**
   * @description Delete a form field from a classification tree
   * @tags dbtn/module:classification, dbtn/hasAuth
   * @name delete_tree_form_field
   * @summary Delete Tree Form Field
   * @request DELETE:/routes/classification/tree/{tree_id}/form-fields/{field_id}
   */
  export namespace delete_tree_form_field {
    export type RequestParams = {
      /**
       * Tree Id
       * @format uuid
       */
      treeId: string;
      /** Field Id */
      fieldId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = DeleteTreeFormFieldData;
  }

  /**
   * @description List all classification trees for admin management
   * @tags dbtn/module:classification, dbtn/hasAuth
   * @name list_classification_trees
   * @summary List Classification Trees
   * @request GET:/routes/classification/admin/trees
   */
  export namespace list_classification_trees {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ListClassificationTreesData;
  }

  /**
   * @description Create a new classification tree
   * @tags dbtn/module:classification, dbtn/hasAuth
   * @name create_classification_tree
   * @summary Create Classification Tree
   * @request POST:/routes/classification/admin/trees
   */
  export namespace create_classification_tree {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = ClassificationTreeCreate;
    export type RequestHeaders = {};
    export type ResponseBody = CreateClassificationTreeData;
  }

  /**
   * @description Get a specific classification tree
   * @tags dbtn/module:classification, dbtn/hasAuth
   * @name get_classification_tree
   * @summary Get Classification Tree
   * @request GET:/routes/classification/admin/trees/{tree_id}
   */
  export namespace get_classification_tree {
    export type RequestParams = {
      /**
       * Tree Id
       * @format uuid
       */
      treeId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetClassificationTreeData;
  }

  /**
   * @description Update a classification tree
   * @tags dbtn/module:classification, dbtn/hasAuth
   * @name update_classification_tree
   * @summary Update Classification Tree
   * @request PUT:/routes/classification/admin/trees/{tree_id}
   */
  export namespace update_classification_tree {
    export type RequestParams = {
      /**
       * Tree Id
       * @format uuid
       */
      treeId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = ClassificationTreeUpdate;
    export type RequestHeaders = {};
    export type ResponseBody = UpdateClassificationTreeData;
  }

  /**
   * @description Delete a classification tree and all its related data
   * @tags dbtn/module:classification, dbtn/hasAuth
   * @name delete_classification_tree
   * @summary Delete Classification Tree
   * @request DELETE:/routes/classification/admin/trees/{tree_id}
   */
  export namespace delete_classification_tree {
    export type RequestParams = {
      /**
       * Tree Id
       * @format uuid
       */
      treeId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = DeleteClassificationTreeData;
  }

  /**
   * @description Duplicate a classification tree with all its nodes and options
   * @tags dbtn/module:classification, dbtn/hasAuth
   * @name duplicate_classification_tree
   * @summary Duplicate Classification Tree
   * @request POST:/routes/classification/admin/trees/{tree_id}/duplicate
   */
  export namespace duplicate_classification_tree {
    export type RequestParams = {
      /**
       * Tree Id
       * @format uuid
       */
      treeId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = DuplicateClassificationTreeData;
  }

  /**
   * @description List all nodes for a classification tree
   * @tags dbtn/module:classification, dbtn/hasAuth
   * @name list_tree_nodes
   * @summary List Tree Nodes
   * @request GET:/routes/classification/admin/trees/{tree_id}/nodes
   */
  export namespace list_tree_nodes {
    export type RequestParams = {
      /**
       * Tree Id
       * @format uuid
       */
      treeId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ListTreeNodesData;
  }

  /**
   * @description Create a new tree node
   * @tags dbtn/module:classification, dbtn/hasAuth
   * @name create_tree_node
   * @summary Create Tree Node
   * @request POST:/routes/classification/admin/trees/{tree_id}/nodes
   */
  export namespace create_tree_node {
    export type RequestParams = {
      /**
       * Tree Id
       * @format uuid
       */
      treeId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = TreeNodeCreate;
    export type RequestHeaders = {};
    export type ResponseBody = CreateTreeNodeData;
  }

  /**
   * @description Update a tree node
   * @tags dbtn/module:classification, dbtn/hasAuth
   * @name update_tree_node
   * @summary Update Tree Node
   * @request PUT:/routes/classification/admin/trees/{tree_id}/nodes/{node_id}
   */
  export namespace update_tree_node {
    export type RequestParams = {
      /**
       * Tree Id
       * @format uuid
       */
      treeId: string;
      /**
       * Node Id
       * @format uuid
       */
      nodeId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = TreeNodeUpdate;
    export type RequestHeaders = {};
    export type ResponseBody = UpdateTreeNodeData;
  }

  /**
   * @description Delete a tree node
   * @tags dbtn/module:classification, dbtn/hasAuth
   * @name delete_tree_node
   * @summary Delete Tree Node
   * @request DELETE:/routes/classification/admin/nodes/{node_id}
   */
  export namespace delete_tree_node {
    export type RequestParams = {
      /**
       * Node Id
       * @format uuid
       */
      nodeId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = DeleteTreeNodeData;
  }

  /**
   * @description List all options for a tree node
   * @tags dbtn/module:classification, dbtn/hasAuth
   * @name list_node_options
   * @summary List Node Options
   * @request GET:/routes/classification/admin/nodes/{node_id}/options
   */
  export namespace list_node_options {
    export type RequestParams = {
      /**
       * Node Id
       * @format uuid
       */
      nodeId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ListNodeOptionsData;
  }

  /**
   * @description Create a new node option
   * @tags dbtn/module:classification, dbtn/hasAuth
   * @name create_node_option
   * @summary Create Node Option
   * @request POST:/routes/classification/admin/nodes/{node_id}/options
   */
  export namespace create_node_option {
    export type RequestParams = {
      /**
       * Node Id
       * @format uuid
       */
      nodeId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = NodeOptionCreate;
    export type RequestHeaders = {};
    export type ResponseBody = CreateNodeOptionData;
  }

  /**
   * @description Delete a node option
   * @tags dbtn/module:classification, dbtn/hasAuth
   * @name delete_node_option
   * @summary Delete Node Option
   * @request DELETE:/routes/classification/admin/options/{option_id}
   */
  export namespace delete_node_option {
    export type RequestParams = {
      /**
       * Option Id
       * @format uuid
       */
      optionId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = DeleteNodeOptionData;
  }

  /**
   * @description Update a node option
   * @tags dbtn/module:classification, dbtn/hasAuth
   * @name update_node_option
   * @summary Update Node Option
   * @request PUT:/routes/classification/admin/options/{option_id}
   */
  export namespace update_node_option {
    export type RequestParams = {
      /**
       * Option Id
       * @format uuid
       */
      optionId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = NodeOptionUpdate;
    export type RequestHeaders = {};
    export type ResponseBody = UpdateNodeOptionData;
  }

  /**
   * @description List all outcomes across all classification trees
   * @tags dbtn/module:classification, dbtn/hasAuth
   * @name list_all_classification_outcomes
   * @summary List All Classification Outcomes
   * @request GET:/routes/classification/admin/outcomes
   */
  export namespace list_all_classification_outcomes {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ListAllClassificationOutcomesData;
  }

  /**
   * @description Create a new tree-independent classification outcome
   * @tags dbtn/module:classification, dbtn/hasAuth
   * @name create_tree_independent_outcome
   * @summary Create Tree Independent Outcome
   * @request POST:/routes/classification/admin/outcomes
   */
  export namespace create_tree_independent_outcome {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = ClassificationOutcomeCreate;
    export type RequestHeaders = {};
    export type ResponseBody = CreateTreeIndependentOutcomeData;
  }

  /**
   * @description List all outcomes for a classification tree
   * @tags dbtn/module:classification, dbtn/hasAuth
   * @name list_classification_outcomes
   * @summary List Classification Outcomes
   * @request GET:/routes/classification/admin/trees/{tree_id}/outcomes
   */
  export namespace list_classification_outcomes {
    export type RequestParams = {
      /**
       * Tree Id
       * @format uuid
       */
      treeId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ListClassificationOutcomesData;
  }

  /**
   * @description Create a new classification outcome for a tree
   * @tags dbtn/module:classification, dbtn/hasAuth
   * @name create_classification_outcome
   * @summary Create Classification Outcome
   * @request POST:/routes/classification/admin/trees/{tree_id}/outcomes
   */
  export namespace create_classification_outcome {
    export type RequestParams = {
      /**
       * Tree Id
       * @format uuid
       */
      treeId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = ClassificationOutcomeCreate;
    export type RequestHeaders = {};
    export type ResponseBody = CreateClassificationOutcomeData;
  }

  /**
   * @description Update a classification outcome
   * @tags dbtn/module:classification, dbtn/hasAuth
   * @name update_classification_outcome
   * @summary Update Classification Outcome
   * @request PUT:/routes/classification/admin/outcomes/{outcome_id}
   */
  export namespace update_classification_outcome {
    export type RequestParams = {
      /**
       * Outcome Id
       * @format uuid
       */
      outcomeId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = ClassificationOutcomeUpdate;
    export type RequestHeaders = {};
    export type ResponseBody = UpdateClassificationOutcomeData;
  }

  /**
   * @description Delete a classification outcome
   * @tags dbtn/module:classification, dbtn/hasAuth
   * @name delete_classification_outcome
   * @summary Delete Classification Outcome
   * @request DELETE:/routes/classification/admin/outcomes/{outcome_id}
   */
  export namespace delete_classification_outcome {
    export type RequestParams = {
      /**
       * Outcome Id
       * @format uuid
       */
      outcomeId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = DeleteClassificationOutcomeData;
  }

  /**
   * @description List all active classification trees for public use
   * @tags dbtn/module:classification, dbtn/hasAuth
   * @name list_active_trees
   * @summary List Active Trees
   * @request GET:/routes/classification/trees
   */
  export namespace list_active_trees {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ListActiveTreesData;
  }

  /**
   * @description Get the starting node for a classification tree
   * @tags dbtn/module:classification, dbtn/hasAuth
   * @name get_tree_start_node
   * @summary Get Tree Start Node
   * @request GET:/routes/classification/trees/{tree_id}/start
   */
  export namespace get_tree_start_node {
    export type RequestParams = {
      /**
       * Tree Id
       * @format uuid
       */
      treeId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetTreeStartNodeData;
  }

  /**
   * @description Get a specific node by its key within a tree
   * @tags dbtn/module:classification, dbtn/hasAuth
   * @name get_node_by_key
   * @summary Get Node By Key
   * @request GET:/routes/classification/trees/{tree_id}/nodes/{node_key}
   */
  export namespace get_node_by_key {
    export type RequestParams = {
      /**
       * Tree Id
       * @format uuid
       */
      treeId: string;
      /** Node Key */
      nodeKey: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetNodeByKeyData;
  }

  /**
   * @description Navigate to the next node based on selected option
   * @tags dbtn/module:classification, dbtn/hasAuth
   * @name navigate_tree
   * @summary Navigate Tree
   * @request POST:/routes/classification/trees/{tree_id}/navigate
   */
  export namespace navigate_tree {
    export type RequestParams = {
      /**
       * Tree Id
       * @format uuid
       */
      treeId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = NavigationRequest;
    export type RequestHeaders = {};
    export type ResponseBody = NavigateTreeData;
  }

  /**
   * @description Process responses to a multi-question assessment and determine routing
   * @tags dbtn/module:classification, dbtn/hasAuth
   * @name process_classification_multi_question_assessment
   * @summary Process Classification Multi Question Assessment
   * @request POST:/routes/classification/trees/{tree_id}/nodes/{node_key}/assess
   */
  export namespace process_classification_multi_question_assessment {
    export type RequestParams = {
      /**
       * Tree Id
       * @format uuid
       */
      treeId: string;
      /** Node Key */
      nodeKey: string;
    };
    export type RequestQuery = {};
    export type RequestBody = MultiQuestionAssessmentRequest;
    export type RequestHeaders = {};
    export type ResponseBody = ProcessClassificationMultiQuestionAssessmentData;
  }

  /**
   * @description Search sanctions lists for compliance screening
   * @tags dbtn/module:sanctions_search, dbtn/hasAuth
   * @name search_sanctions
   * @summary Search Sanctions
   * @request POST:/routes/sanctions/search
   */
  export namespace search_sanctions {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = SanctionsSearchRequest;
    export type RequestHeaders = {};
    export type ResponseBody = SearchSanctionsData;
  }

  /**
   * @description Get detailed information about a specific sanctioned entity
   * @tags dbtn/module:sanctions_search, dbtn/hasAuth
   * @name get_sanctions_search_entity
   * @summary Get Sanctions Search Entity
   * @request GET:/routes/entity/{entity_id}
   */
  export namespace get_sanctions_search_entity {
    export type RequestParams = {
      /** Entity Id */
      entityId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetSanctionsSearchEntityData;
  }

  /**
   * @description Get list of available sanctions jurisdictions
   * @tags dbtn/module:sanctions_search, dbtn/hasAuth
   * @name get_sanctions_jurisdictions
   * @summary Get Sanctions Jurisdictions
   * @request GET:/routes/jurisdictions
   */
  export namespace get_sanctions_jurisdictions {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetSanctionsJurisdictionsData;
  }

  /**
   * @description Get list of available sanctions programs
   * @tags dbtn/module:sanctions_search, dbtn/hasAuth
   * @name get_sanctions_programs
   * @summary Get Sanctions Programs
   * @request GET:/routes/programs
   */
  export namespace get_sanctions_programs {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetSanctionsProgramsData;
  }

  /**
   * @description Get list of available entity types
   * @tags dbtn/module:sanctions_search, dbtn/hasAuth
   * @name get_entity_types
   * @summary Get Entity Types
   * @request GET:/routes/entity-types
   */
  export namespace get_entity_types {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetEntityTypesData;
  }

  /**
   * @description Get list of available risk levels for sanctions
   * @tags dbtn/module:sanctions_search, dbtn/hasAuth
   * @name get_risk_levels
   * @summary Get Risk Levels
   * @request GET:/routes/sanctions/risk-levels
   */
  export namespace get_risk_levels {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetRiskLevelsData;
  }

  /**
   * @description Get statistics for sanctions lists overview
   * @tags dbtn/module:sanctions_list_management, dbtn/hasAuth
   * @name get_sanctions_list_stats
   * @summary Get Sanctions List Stats
   * @request GET:/routes/sanctions-lists/stats
   */
  export namespace get_sanctions_list_stats {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetSanctionsListStatsData;
  }

  /**
   * @description List all sanctions lists with filtering
   * @tags dbtn/module:sanctions_list_management, dbtn/hasAuth
   * @name list_sanctions_lists
   * @summary List Sanctions Lists
   * @request GET:/routes/sanctions-lists/lists
   */
  export namespace list_sanctions_lists {
    export type RequestParams = {};
    export type RequestQuery = {
      /**
       * Active Only
       * @default false
       */
      active_only?: boolean;
      /** List Type */
      list_type?: string | null;
      /** Authority */
      authority?: string | null;
      /**
       * Limit
       * @default 100
       */
      limit?: number;
      /**
       * Offset
       * @default 0
       */
      offset?: number;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ListSanctionsListsData;
  }

  /**
   * @description Create a new sanctions list
   * @tags dbtn/module:sanctions_list_management, dbtn/hasAuth
   * @name create_sanctions_list
   * @summary Create Sanctions List
   * @request POST:/routes/sanctions-lists/lists
   */
  export namespace create_sanctions_list {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = SanctionsListCreate;
    export type RequestHeaders = {};
    export type ResponseBody = CreateSanctionsListData;
  }

  /**
   * @description Get a specific sanctions list by ID
   * @tags dbtn/module:sanctions_list_management, dbtn/hasAuth
   * @name get_sanctions_list
   * @summary Get Sanctions List
   * @request GET:/routes/sanctions-lists/lists/{list_id}
   */
  export namespace get_sanctions_list {
    export type RequestParams = {
      /** List Id */
      listId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetSanctionsListData;
  }

  /**
   * @description Update an existing sanctions list
   * @tags dbtn/module:sanctions_list_management, dbtn/hasAuth
   * @name update_sanctions_list
   * @summary Update Sanctions List
   * @request PUT:/routes/sanctions-lists/lists/{list_id}
   */
  export namespace update_sanctions_list {
    export type RequestParams = {
      /** List Id */
      listId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = SanctionsListUpdate;
    export type RequestHeaders = {};
    export type ResponseBody = UpdateSanctionsListData;
  }

  /**
   * @description Delete a sanctions list and all its entries
   * @tags dbtn/module:sanctions_list_management, dbtn/hasAuth
   * @name delete_sanctions_list
   * @summary Delete Sanctions List
   * @request DELETE:/routes/sanctions-lists/lists/{list_id}
   */
  export namespace delete_sanctions_list {
    export type RequestParams = {
      /** List Id */
      listId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = DeleteSanctionsListData;
  }

  /**
   * @description Get entries for a specific sanctions list
   * @tags dbtn/module:sanctions_list_management, dbtn/hasAuth
   * @name get_sanctions_list_entries
   * @summary Get Sanctions List Entries
   * @request GET:/routes/sanctions-lists/lists/{list_id}/entries
   */
  export namespace get_sanctions_list_entries {
    export type RequestParams = {
      /** List Id */
      listId: number;
    };
    export type RequestQuery = {
      /** Entry Type */
      entry_type?: string | null;
      /**
       * Active Only
       * @default true
       */
      active_only?: boolean;
      /** Search */
      search?: string | null;
      /**
       * Limit
       * @default 100
       */
      limit?: number;
      /**
       * Offset
       * @default 0
       */
      offset?: number;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetSanctionsListEntriesData;
  }

  /**
   * @description Add a new entry to a sanctions list
   * @tags dbtn/module:sanctions_list_management, dbtn/hasAuth
   * @name create_sanctions_list_entry
   * @summary Create Sanctions List Entry
   * @request POST:/routes/sanctions-lists/lists/{list_id}/entries
   */
  export namespace create_sanctions_list_entry {
    export type RequestParams = {
      /** List Id */
      listId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = SanctionsListEntryCreate;
    export type RequestHeaders = {};
    export type ResponseBody = CreateSanctionsListEntryData;
  }

  /**
   * @description Bulk import entries into a sanctions list
   * @tags dbtn/module:sanctions_list_management, dbtn/hasAuth
   * @name bulk_import_entries
   * @summary Bulk Import Entries
   * @request POST:/routes/sanctions-lists/lists/{list_id}/bulk-import
   */
  export namespace bulk_import_entries {
    export type RequestParams = {
      /** List Id */
      listId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = AppApisSanctionsListManagementBulkImportRequest;
    export type RequestHeaders = {};
    export type ResponseBody = BulkImportEntriesData;
  }

  /**
   * @description Get available list types
   * @tags dbtn/module:sanctions_list_management, dbtn/hasAuth
   * @name get_list_types
   * @summary Get List Types
   * @request GET:/routes/sanctions-lists/list-types
   */
  export namespace get_list_types {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetListTypesData;
  }

  /**
   * @description Import sanctions from UN Security Council XML file
   * @tags dbtn/module:sanctions_list_management, dbtn/hasAuth
   * @name import_xml_sanctions
   * @summary Import Xml Sanctions
   * @request POST:/routes/sanctions-lists/import-xml
   */
  export namespace import_xml_sanctions {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = BodyImportXmlSanctions;
    export type RequestHeaders = {};
    export type ResponseBody = ImportXmlSanctionsData;
  }

  /**
   * @description Get comprehensive pricing analytics across all components and packages
   * @tags dbtn/module:pricing_analytics, dbtn/hasAuth
   * @name get_comprehensive_pricing_analytics
   * @summary Get Comprehensive Pricing Analytics
   * @request GET:/routes/comprehensive-analytics
   */
  export namespace get_comprehensive_pricing_analytics {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetComprehensivePricingAnalyticsData;
  }

  /**
   * @description Bulk update pricing for multiple components
   * @tags dbtn/module:pricing_analytics, dbtn/hasAuth
   * @name bulk_update_pricing
   * @summary Bulk Update Pricing
   * @request POST:/routes/bulk-pricing-update
   */
  export namespace bulk_update_pricing {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = BulkUpdatePricingPayload;
    export type RequestHeaders = {};
    export type ResponseBody = BulkUpdatePricingData;
  }

  /**
   * @description Get audit log of pricing changes
   * @tags dbtn/module:pricing_analytics, dbtn/hasAuth
   * @name get_pricing_audit_log
   * @summary Get Pricing Audit Log
   * @request GET:/routes/pricing-audit-log
   */
  export namespace get_pricing_audit_log {
    export type RequestParams = {};
    export type RequestQuery = {
      /**
       * Limit
       * @default 50
       */
      limit?: number;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetPricingAuditLogData;
  }

  /**
   * @description Save user profile with company integration
   * @tags dbtn/module:enterprise_profile, dbtn/hasAuth
   * @name save_enhanced_user_profile
   * @summary Save Enhanced User Profile
   * @request POST:/routes/enterprise-profile/save-enhanced-profile
   */
  export namespace save_enhanced_user_profile {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = EnhancedUserProfileRequest;
    export type RequestHeaders = {};
    export type ResponseBody = SaveEnhancedUserProfileData;
  }

  /**
   * @description Get user profile with company information
   * @tags dbtn/module:enterprise_profile, dbtn/hasAuth
   * @name get_enhanced_user_profile
   * @summary Get Enhanced User Profile
   * @request GET:/routes/enterprise-profile/enhanced-profile
   */
  export namespace get_enhanced_user_profile {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetEnhancedUserProfileData;
  }

  /**
   * @description Get audit logs with filtering
   * @tags dbtn/module:enterprise_profile, dbtn/hasAuth
   * @name get_audit_logs
   * @summary Get Audit Logs
   * @request GET:/routes/enterprise-profile/audit-logs
   */
  export namespace get_audit_logs {
    export type RequestParams = {};
    export type RequestQuery = {
      /** Company Id */
      company_id?: number | null;
      /** Action Filter */
      action_filter?: string | null;
      /** User Filter */
      user_filter?: string | null;
      /**
       * Limit
       * @default 100
       */
      limit?: number;
      /**
       * Offset
       * @default 0
       */
      offset?: number;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetAuditLogsData;
  }

  /**
   * @description Get user activity summary for compliance monitoring
   * @tags dbtn/module:enterprise_profile, dbtn/hasAuth
   * @name get_user_activity_summary
   * @summary Get User Activity Summary
   * @request GET:/routes/enterprise-profile/user-activity-summary
   */
  export namespace get_user_activity_summary {
    export type RequestParams = {};
    export type RequestQuery = {
      /** Company Id */
      company_id?: number | null;
      /**
       * Days Back
       * @default 30
       */
      days_back?: number;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetUserActivitySummaryData;
  }

  /**
   * @description Log a custom audit action
   * @tags dbtn/module:enterprise_profile, dbtn/hasAuth
   * @name log_custom_action
   * @summary Log Custom Action
   * @request POST:/routes/enterprise-profile/log-custom-action
   */
  export namespace log_custom_action {
    export type RequestParams = {};
    export type RequestQuery = {
      /** Action */
      action: string;
      /** Resource Type */
      resource_type?: string | null;
      /** Resource Id */
      resource_id?: string | null;
    };
    export type RequestBody = LogCustomActionPayload;
    export type RequestHeaders = {};
    export type ResponseBody = LogCustomActionData;
  }

  /**
   * @description Update customer/user information in the database
   * @tags dbtn/module:user_management, dbtn/hasAuth
   * @name update_user
   * @summary Update User
   * @request PUT:/routes/admin/users/{customer_id}
   */
  export namespace update_user {
    export type RequestParams = {
      /** Customer Id */
      customerId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = UpdateUserRequest;
    export type RequestHeaders = {};
    export type ResponseBody = UpdateUserData;
  }

  /**
   * @description Delete a customer/user from the database
   * @tags dbtn/module:user_management, dbtn/hasAuth
   * @name delete_user
   * @summary Delete User
   * @request DELETE:/routes/admin/users/{customer_id}
   */
  export namespace delete_user {
    export type RequestParams = {
      /** Customer Id */
      customerId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = DeleteUserData;
  }

  /**
   * @description Create a new customer/user in the database
   * @tags dbtn/module:user_management, dbtn/hasAuth
   * @name create_user
   * @summary Create User
   * @request POST:/routes/admin/users
   */
  export namespace create_user {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = CreateUserRequest;
    export type RequestHeaders = {};
    export type ResponseBody = CreateUserData;
  }

  /**
   * @description Get cross-references for a specific document
   * @tags dbtn/module:cross_references, dbtn/hasAuth
   * @name get_document_cross_references
   * @summary Get Document Cross References
   * @request GET:/routes/cross-references/document/{document_id}
   */
  export namespace get_document_cross_references {
    export type RequestParams = {
      /** Document Id */
      documentId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetDocumentCrossReferencesData;
  }

  /**
   * @description Process a document to extract and link cross-references
   * @tags dbtn/module:cross_references, dbtn/hasAuth
   * @name process_document_references
   * @summary Process Document References
   * @request POST:/routes/cross-references/process
   */
  export namespace process_document_references {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = ProcessReferenceRequest;
    export type RequestHeaders = {};
    export type ResponseBody = ProcessDocumentReferencesData;
  }

  /**
   * @description Extract regulatory references from text
   * @tags dbtn/module:cross_references, dbtn/hasAuth
   * @name extract_references_from_text
   * @summary Extract References From Text
   * @request POST:/routes/cross-references/extract
   */
  export namespace extract_references_from_text {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = ExtractReferencesRequest;
    export type RequestHeaders = {};
    export type ResponseBody = ExtractReferencesFromTextData;
  }

  /**
   * @description Rebuild cross-references for a specific document
   * @tags dbtn/module:cross_references, dbtn/hasAuth
   * @name rebuild_document_cross_references
   * @summary Rebuild Document Cross References
   * @request POST:/routes/cross-references/rebuild/{document_id}
   */
  export namespace rebuild_document_cross_references {
    export type RequestParams = {
      /** Document Id */
      documentId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = RebuildDocumentCrossReferencesData;
  }

  /**
   * @description Rebuild cross-references for all documents (admin only)
   * @tags dbtn/module:cross_references, dbtn/hasAuth
   * @name rebuild_all_cross_references
   * @summary Rebuild All Cross References
   * @request POST:/routes/cross-references/rebuild-all
   */
  export namespace rebuild_all_cross_references {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = RebuildAllCrossReferencesData;
  }

  /**
   * @description Get statistics about cross-references in the system
   * @tags dbtn/module:cross_references, dbtn/hasAuth
   * @name get_cross_reference_stats
   * @summary Get Cross Reference Stats
   * @request GET:/routes/cross-references/stats
   */
  export namespace get_cross_reference_stats {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetCrossReferenceStatsData;
  }

  /**
   * @description Get all saved searches for the current user
   * @tags dbtn/module:saved_searches, dbtn/hasAuth
   * @name list_saved_searches
   * @summary List Saved Searches
   * @request GET:/routes/saved-searches
   */
  export namespace list_saved_searches {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ListSavedSearchesData;
  }

  /**
   * @description Create a new saved search with optional alerts
   * @tags dbtn/module:saved_searches, dbtn/hasAuth
   * @name create_saved_search
   * @summary Create Saved Search
   * @request POST:/routes/saved-searches
   */
  export namespace create_saved_search {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = SavedSearchRequest;
    export type RequestHeaders = {};
    export type ResponseBody = CreateSavedSearchData;
  }

  /**
   * @description Get a specific saved search
   * @tags dbtn/module:saved_searches, dbtn/hasAuth
   * @name get_saved_search
   * @summary Get Saved Search
   * @request GET:/routes/saved-searches/{search_id}
   */
  export namespace get_saved_search {
    export type RequestParams = {
      /** Search Id */
      searchId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetSavedSearchData;
  }

  /**
   * @description Update a saved search
   * @tags dbtn/module:saved_searches, dbtn/hasAuth
   * @name update_saved_search
   * @summary Update Saved Search
   * @request PUT:/routes/saved-searches/{search_id}
   */
  export namespace update_saved_search {
    export type RequestParams = {
      /** Search Id */
      searchId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = SavedSearchUpdate;
    export type RequestHeaders = {};
    export type ResponseBody = UpdateSavedSearchData;
  }

  /**
   * @description Delete a saved search
   * @tags dbtn/module:saved_searches, dbtn/hasAuth
   * @name delete_saved_search
   * @summary Delete Saved Search
   * @request DELETE:/routes/saved-searches/{search_id}
   */
  export namespace delete_saved_search {
    export type RequestParams = {
      /** Search Id */
      searchId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = DeleteSavedSearchData;
  }

  /**
   * @description Execute a saved search and return results
   * @tags dbtn/module:saved_searches, dbtn/hasAuth
   * @name run_saved_search
   * @summary Run Saved Search
   * @request POST:/routes/saved-searches/{search_id}/run
   */
  export namespace run_saved_search {
    export type RequestParams = {
      /** Search Id */
      searchId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = RunSavedSearchData;
  }

  /**
   * @description Get alert history for a saved search
   * @tags dbtn/module:saved_searches, dbtn/hasAuth
   * @name get_search_alerts
   * @summary Get Search Alerts
   * @request GET:/routes/saved-searches/{search_id}/alerts
   */
  export namespace get_search_alerts {
    export type RequestParams = {
      /** Search Id */
      searchId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetSearchAlertsData;
  }

  /**
   * @description Create a new company (automatically makes user the owner)
   * @tags dbtn/module:team_management, dbtn/hasAuth
   * @name create_company
   * @summary Create Company
   * @request POST:/routes/team-management/create-company
   */
  export namespace create_company {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = CreateCompanyRequest;
    export type RequestHeaders = {};
    export type ResponseBody = CreateCompanyData;
  }

  /**
   * @description Get all companies where user is a member
   * @tags dbtn/module:team_management, dbtn/hasAuth
   * @name get_my_companies
   * @summary Get My Companies
   * @request GET:/routes/team-management/my-companies
   */
  export namespace get_my_companies {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetMyCompaniesData;
  }

  /**
   * @description Invite a new team member to the company
   * @tags dbtn/module:team_management, dbtn/hasAuth
   * @name invite_team_member
   * @summary Invite Team Member
   * @request POST:/routes/team-management/companies/{company_id}/invite
   */
  export namespace invite_team_member {
    export type RequestParams = {
      /** Company Id */
      companyId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = InviteUserRequest;
    export type RequestHeaders = {};
    export type ResponseBody = InviteTeamMemberData;
  }

  /**
   * @description Get all team members for a company
   * @tags dbtn/module:team_management, dbtn/hasAuth
   * @name get_team_members
   * @summary Get Team Members
   * @request GET:/routes/team-management/companies/{company_id}/members
   */
  export namespace get_team_members {
    export type RequestParams = {
      /** Company Id */
      companyId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetTeamMembersData;
  }

  /**
   * @description Get all pending invitations for a company
   * @tags dbtn/module:team_management, dbtn/hasAuth
   * @name get_pending_invitations
   * @summary Get Pending Invitations
   * @request GET:/routes/team-management/companies/{company_id}/invitations
   */
  export namespace get_pending_invitations {
    export type RequestParams = {
      /** Company Id */
      companyId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetPendingInvitationsData;
  }

  /**
   * @description Update a team member's role
   * @tags dbtn/module:team_management, dbtn/hasAuth
   * @name update_member_role
   * @summary Update Member Role
   * @request PUT:/routes/team-management/companies/{company_id}/members/{member_id}/role
   */
  export namespace update_member_role {
    export type RequestParams = {
      /** Company Id */
      companyId: number;
      /** Member Id */
      memberId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = UpdateMemberRoleRequest;
    export type RequestHeaders = {};
    export type ResponseBody = UpdateMemberRoleData;
  }

  /**
   * @description Remove a team member from the company
   * @tags dbtn/module:team_management, dbtn/hasAuth
   * @name remove_team_member
   * @summary Remove Team Member
   * @request DELETE:/routes/team-management/companies/{company_id}/members/{member_id}
   */
  export namespace remove_team_member {
    export type RequestParams = {
      /** Company Id */
      companyId: number;
      /** Member Id */
      memberId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = RemoveTeamMemberData;
  }

  /**
   * @description Get all available role definitions
   * @tags dbtn/module:team_management, dbtn/hasAuth
   * @name get_role_definitions
   * @summary Get Role Definitions
   * @request GET:/routes/team-management/role-definitions
   */
  export namespace get_role_definitions {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetRoleDefinitionsData;
  }

  /**
   * @description Get company profile details
   * @tags dbtn/module:team_management, dbtn/hasAuth
   * @name get_company_profile
   * @summary Get Company Profile
   * @request GET:/routes/team-management/companies/{company_id}/profile
   */
  export namespace get_company_profile {
    export type RequestParams = {
      /** Company Id */
      companyId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetCompanyProfileData;
  }

  /**
   * @description Update company profile (requires billing management permission)
   * @tags dbtn/module:team_management, dbtn/hasAuth
   * @name update_company_profile
   * @summary Update Company Profile
   * @request PUT:/routes/team-management/companies/{company_id}/profile
   */
  export namespace update_company_profile {
    export type RequestParams = {
      /** Company Id */
      companyId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = UpdateCompanyProfileRequest;
    export type RequestHeaders = {};
    export type ResponseBody = UpdateCompanyProfileData;
  }

  /**
   * @description Get all documents pending admin approval
   * @tags dbtn/module:pending_documents, dbtn/hasAuth
   * @name list_pending_documents
   * @summary List Pending Documents
   * @request GET:/routes/pending-documents/list
   */
  export namespace list_pending_documents {
    export type RequestParams = {};
    export type RequestQuery = {
      /**
       * Limit
       * @default 50
       */
      limit?: number;
      /**
       * Offset
       * @default 0
       */
      offset?: number;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ListPendingDocumentsData;
  }

  /**
   * @description Approve or reject a pending document
   * @tags dbtn/module:pending_documents, dbtn/hasAuth
   * @name approve_or_reject_document
   * @summary Approve Or Reject Document
   * @request POST:/routes/pending-documents/approve
   */
  export namespace approve_or_reject_document {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = ApprovalRequest;
    export type RequestHeaders = {};
    export type ResponseBody = ApproveOrRejectDocumentData;
  }

  /**
   * @description Get statistics for pending documents
   * @tags dbtn/module:pending_documents, dbtn/hasAuth
   * @name get_pending_stats
   * @summary Get Pending Stats
   * @request GET:/routes/pending-documents/stats
   */
  export namespace get_pending_stats {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetPendingStatsData;
  }

  /**
   * @description Save or update user business profile information
   * @tags dbtn/module:user_profile, dbtn/hasAuth
   * @name save_user_profile
   * @summary Save User Profile
   * @request POST:/routes/save-user-profile
   */
  export namespace save_user_profile {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = UserProfileRequest;
    export type RequestHeaders = {};
    export type ResponseBody = SaveUserProfileData;
  }

  /**
   * @description Get user business profile information
   * @tags dbtn/module:user_profile, dbtn/hasAuth
   * @name get_user_profile
   * @summary Get User Profile
   * @request GET:/routes/get-user-profile
   */
  export namespace get_user_profile {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetUserProfileData;
  }

  /**
   * @description Delete user business profile information
   * @tags dbtn/module:user_profile, dbtn/hasAuth
   * @name delete_user_profile
   * @summary Delete User Profile
   * @request DELETE:/routes/delete-user-profile
   */
  export namespace delete_user_profile {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = DeleteUserProfileData;
  }

  /**
   * @description Get all annotations for a document
   * @tags annotations, dbtn/module:annotations, dbtn/hasAuth
   * @name get_document_annotations
   * @summary Get Document Annotations
   * @request GET:/routes/annotations/documents/{document_id}
   */
  export namespace get_document_annotations {
    export type RequestParams = {
      /** Document Id */
      documentId: number;
    };
    export type RequestQuery = {
      /** Annotation Type */
      annotation_type?: string | null;
      /** Visibility */
      visibility?: string | null;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetDocumentAnnotationsData;
  }

  /**
   * @description Create a new annotation
   * @tags annotations, dbtn/module:annotations, dbtn/hasAuth
   * @name create_annotation
   * @summary Create Annotation
   * @request POST:/routes/annotations/documents/{document_id}
   */
  export namespace create_annotation {
    export type RequestParams = {
      /** Document Id */
      documentId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = CreateAnnotationRequest;
    export type RequestHeaders = {};
    export type ResponseBody = CreateAnnotationData;
  }

  /**
   * @description Update an existing annotation
   * @tags annotations, dbtn/module:annotations, dbtn/hasAuth
   * @name update_annotation
   * @summary Update Annotation
   * @request PUT:/routes/annotations/annotations/{annotation_id}
   */
  export namespace update_annotation {
    export type RequestParams = {
      /** Annotation Id */
      annotationId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = UpdateAnnotationRequest;
    export type RequestHeaders = {};
    export type ResponseBody = UpdateAnnotationData;
  }

  /**
   * @description Delete an annotation
   * @tags annotations, dbtn/module:annotations, dbtn/hasAuth
   * @name delete_annotation
   * @summary Delete Annotation
   * @request DELETE:/routes/annotations/annotations/{annotation_id}
   */
  export namespace delete_annotation {
    export type RequestParams = {
      /** Annotation Id */
      annotationId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = DeleteAnnotationData;
  }

  /**
   * @description Mark an annotation as resolved
   * @tags annotations, dbtn/module:annotations, dbtn/hasAuth
   * @name resolve_annotation
   * @summary Resolve Annotation
   * @request POST:/routes/annotations/annotations/{annotation_id}/resolve
   */
  export namespace resolve_annotation {
    export type RequestParams = {
      /** Annotation Id */
      annotationId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ResolveAnnotationData;
  }

  /**
   * @description Get all bookmarks for the current user
   * @tags annotations, dbtn/module:annotations, dbtn/hasAuth
   * @name get_user_bookmarks
   * @summary Get User Bookmarks
   * @request GET:/routes/annotations/bookmarks
   */
  export namespace get_user_bookmarks {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetUserBookmarksData;
  }

  /**
   * @description Create a new bookmark
   * @tags annotations, dbtn/module:annotations, dbtn/hasAuth
   * @name create_bookmark
   * @summary Create Bookmark
   * @request POST:/routes/annotations/bookmarks
   */
  export namespace create_bookmark {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = CreateBookmarkRequest;
    export type RequestHeaders = {};
    export type ResponseBody = CreateBookmarkData;
  }

  /**
   * @description Delete a bookmark
   * @tags annotations, dbtn/module:annotations, dbtn/hasAuth
   * @name delete_bookmark
   * @summary Delete Bookmark
   * @request DELETE:/routes/annotations/bookmarks/{bookmark_id}
   */
  export namespace delete_bookmark {
    export type RequestParams = {
      /** Bookmark Id */
      bookmarkId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = DeleteBookmarkData;
  }

  /**
   * @description Get recent activity for a document
   * @tags annotations, dbtn/module:annotations, dbtn/hasAuth
   * @name get_document_activity
   * @summary Get Document Activity
   * @request GET:/routes/annotations/documents/{document_id}/activity
   */
  export namespace get_document_activity {
    export type RequestParams = {
      /** Document Id */
      documentId: number;
    };
    export type RequestQuery = {
      /**
       * Limit
       * @default 50
       */
      limit?: number;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetDocumentActivityData;
  }

  /**
   * @description Track user activity on a document
   * @tags annotations, dbtn/module:annotations, dbtn/hasAuth
   * @name track_document_activity
   * @summary Track Document Activity
   * @request POST:/routes/annotations/documents/{document_id}/activity
   */
  export namespace track_document_activity {
    export type RequestParams = {
      /** Document Id */
      documentId: number;
    };
    export type RequestQuery = {
      /** Activity Type */
      activity_type: string;
      /** Description */
      description: string;
    };
    export type RequestBody = TrackDocumentActivityPayload;
    export type RequestHeaders = {};
    export type ResponseBody = TrackDocumentActivityData;
  }

  /**
   * @description Get collaboration statistics for a document
   * @tags annotations, dbtn/module:annotations, dbtn/hasAuth
   * @name get_collaboration_stats
   * @summary Get Collaboration Stats
   * @request GET:/routes/annotations/documents/{document_id}/collaboration-stats
   */
  export namespace get_collaboration_stats {
    export type RequestParams = {
      /** Document Id */
      documentId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetCollaborationStatsData;
  }

  /**
   * @description Get collaboration summary for the current user
   * @tags annotations, dbtn/module:annotations, dbtn/hasAuth
   * @name get_user_collaboration_summary
   * @summary Get User Collaboration Summary
   * @request GET:/routes/annotations/user/collaboration-summary
   */
  export namespace get_user_collaboration_summary {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetUserCollaborationSummaryData;
  }

  /**
   * @description List all regulatory feeds with enhanced metadata
   * @tags dbtn/module:regulatory_monitoring, dbtn/hasAuth
   * @name list_regulatory_feeds
   * @summary List Regulatory Feeds
   * @request GET:/routes/feeds
   */
  export namespace list_regulatory_feeds {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ListRegulatoryFeedsData;
  }

  /**
   * @description Create a new regulatory feed with enhanced configuration
   * @tags dbtn/module:regulatory_monitoring, dbtn/hasAuth
   * @name create_regulatory_feed
   * @summary Create Regulatory Feed
   * @request POST:/routes/feeds
   */
  export namespace create_regulatory_feed {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = CreateRegulatoryFeedPayload;
    export type RequestHeaders = {};
    export type ResponseBody = CreateRegulatoryFeedData;
  }

  /**
   * @description Get documents related to a specific document based on content analysis
   * @tags dbtn/module:regulatory_monitoring, dbtn/hasAuth
   * @name get_related_documents_for_doc
   * @summary Get Related Documents For Doc
   * @request GET:/routes/documents/{document_id}/related
   */
  export namespace get_related_documents_for_doc {
    export type RequestParams = {
      /** Document Id */
      documentId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetRelatedDocumentsForDocData;
  }

  /**
   * @description Create a cross-reference between two documents
   * @tags dbtn/module:regulatory_monitoring, dbtn/hasAuth
   * @name create_document_cross_reference
   * @summary Create Document Cross Reference
   * @request POST:/routes/documents/{document_id}/cross-references
   */
  export namespace create_document_cross_reference {
    export type RequestParams = {
      /** Document Id */
      documentId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = CrossReferenceRequest;
    export type RequestHeaders = {};
    export type ResponseBody = CreateDocumentCrossReferenceData;
  }

  /**
   * @description Get all cross-references for a document
   * @tags dbtn/module:regulatory_monitoring, dbtn/hasAuth
   * @name get_document_cross_references_monitoring
   * @summary Get Document Cross References Monitoring
   * @request GET:/routes/documents/{document_id}/cross-references
   */
  export namespace get_document_cross_references_monitoring {
    export type RequestParams = {
      /** Document Id */
      documentId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetDocumentCrossReferencesMonitoringData;
  }

  /**
   * @description Analyze document and create cross-references automatically
   * @tags dbtn/module:regulatory_monitoring, dbtn/hasAuth
   * @name analyze_document_references
   * @summary Analyze Document References
   * @request POST:/routes/documents/{document_id}/analyze-references
   */
  export namespace analyze_document_references {
    export type RequestParams = {
      /** Document Id */
      documentId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = DocumentLinkingRequest;
    export type RequestHeaders = {};
    export type ResponseBody = AnalyzeDocumentReferencesData;
  }

  /**
   * @description Enhanced feed processing with retry logic and error handling
   * @tags dbtn/module:regulatory_monitoring, dbtn/hasAuth
   * @name process_feed_enhanced
   * @summary Process Feed Enhanced
   * @request POST:/routes/feeds/{feed_id}/process-enhanced
   */
  export namespace process_feed_enhanced {
    export type RequestParams = {
      /** Feed Id */
      feedId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ProcessFeedEnhancedData;
  }

  /**
   * @description Process multiple feeds in parallel with error handling
   * @tags dbtn/module:regulatory_monitoring, dbtn/hasAuth
   * @name bulk_process_feeds
   * @summary Bulk Process Feeds
   * @request POST:/routes/feeds/bulk-process
   */
  export namespace bulk_process_feeds {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = BatchProcessingRequest;
    export type RequestHeaders = {};
    export type ResponseBody = BulkProcessFeedsData;
  }

  /**
   * @description Get comprehensive health metrics for a feed
   * @tags dbtn/module:regulatory_monitoring, dbtn/hasAuth
   * @name get_feed_health_metrics
   * @summary Get Feed Health Metrics
   * @request GET:/routes/feeds/{feed_id}/health
   */
  export namespace get_feed_health_metrics {
    export type RequestParams = {
      /** Feed Id */
      feedId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetFeedHealthMetricsData;
  }

  /**
   * @description Perform comprehensive health check on a feed
   * @tags dbtn/module:regulatory_monitoring, dbtn/hasAuth
   * @name perform_feed_health_check
   * @summary Perform Feed Health Check
   * @request POST:/routes/feeds/{feed_id}/health-check
   */
  export namespace perform_feed_health_check {
    export type RequestParams = {
      /** Feed Id */
      feedId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = PerformFeedHealthCheckData;
  }

  /**
   * @description Configure automated scheduling for a feed
   * @tags dbtn/module:regulatory_monitoring, dbtn/hasAuth
   * @name configure_feed_scheduling
   * @summary Configure Feed Scheduling
   * @request POST:/routes/feeds/{feed_id}/schedule
   */
  export namespace configure_feed_scheduling {
    export type RequestParams = {
      /** Feed Id */
      feedId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = ConfigureFeedSchedulingPayload;
    export type RequestHeaders = {};
    export type ResponseBody = ConfigureFeedSchedulingData;
  }

  /**
   * @description Send real-time notification for feed events
   * @tags dbtn/module:regulatory_monitoring, dbtn/hasAuth
   * @name send_feed_notification
   * @summary Send Feed Notification
   * @request POST:/routes/feeds/{feed_id}/notify
   */
  export namespace send_feed_notification {
    export type RequestParams = {
      /** Feed Id */
      feedId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = NotificationRequest;
    export type RequestHeaders = {};
    export type ResponseBody = SendFeedNotificationData;
  }

  /**
   * @description Get recent notifications for a feed
   * @tags dbtn/module:regulatory_monitoring, dbtn/hasAuth
   * @name get_feed_notifications
   * @summary Get Feed Notifications
   * @request GET:/routes/feeds/{feed_id}/notifications
   */
  export namespace get_feed_notifications {
    export type RequestParams = {
      /** Feed Id */
      feedId: number;
    };
    export type RequestQuery = {
      /**
       * Limit
       * @min 1
       * @max 100
       * @default 20
       */
      limit?: number;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetFeedNotificationsData;
  }

  /**
   * @description Configure automated alerts for feed events
   * @tags dbtn/module:regulatory_monitoring, dbtn/hasAuth
   * @name configure_feed_alerts
   * @summary Configure Feed Alerts
   * @request POST:/routes/feeds/{feed_id}/alerts/configure
   */
  export namespace configure_feed_alerts {
    export type RequestParams = {
      /** Feed Id */
      feedId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = ConfigureFeedAlertsPayload;
    export type RequestHeaders = {};
    export type ResponseBody = ConfigureFeedAlertsData;
  }

  /**
   * @description Get overall regulatory feeds system status
   * @tags dbtn/module:regulatory_monitoring, dbtn/hasAuth
   * @name get_system_status
   * @summary Get System Status
   * @request GET:/routes/system/status
   */
  export namespace get_system_status {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetSystemStatusData;
  }

  /**
   * @description Submit an assessment for RespectUs validation review. Creates a task in the admin dashboard for review.
   * @tags dbtn/module:validation, dbtn/hasAuth
   * @name submit_for_validation
   * @summary Submit For Validation
   * @request POST:/routes/validation/submit
   */
  export namespace submit_for_validation {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = ValidationSubmissionRequest;
    export type RequestHeaders = {};
    export type ResponseBody = SubmitForValidationData;
  }

  /**
   * @description Get all validation tasks for admin review. Optionally filter by status: 'submitted', 'under_review', 'validated', 'needs_revision'
   * @tags dbtn/module:validation, dbtn/hasAuth
   * @name get_admin_validation_tasks
   * @summary Get Admin Validation Tasks
   * @request GET:/routes/validation/admin/tasks
   */
  export namespace get_admin_validation_tasks {
    export type RequestParams = {};
    export type RequestQuery = {
      /** Status */
      status?: string | null;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetAdminValidationTasksData;
  }

  /**
   * @description Get detailed information about a specific validation task for admin review.
   * @tags dbtn/module:validation, dbtn/hasAuth
   * @name get_validation_task_detail
   * @summary Get Validation Task Detail
   * @request GET:/routes/validation/admin/task/{validation_id}
   */
  export namespace get_validation_task_detail {
    export type RequestParams = {
      /** Validation Id */
      validationId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetValidationTaskDetailData;
  }

  /**
   * @description Admin responds to a validation request - either approve or request changes. Sends email notification to the user.
   * @tags dbtn/module:validation, dbtn/hasAuth
   * @name respond_to_validation
   * @summary Respond To Validation
   * @request POST:/routes/validation/admin/respond
   */
  export namespace respond_to_validation {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = AdminValidationRequest;
    export type RequestHeaders = {};
    export type ResponseBody = RespondToValidationData;
  }

  /**
   * @description Get validation status for a specific assessment for the current user.
   * @tags dbtn/module:validation, dbtn/hasAuth
   * @name get_user_validation_status
   * @summary Get User Validation Status
   * @request GET:/routes/validation/user/status/{assessment_id}
   */
  export namespace get_user_validation_status {
    export type RequestParams = {
      /** Assessment Id */
      assessmentId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetUserValidationStatusData;
  }

  /**
   * @description Get invitation details for acceptance page (public endpoint)
   * @tags dbtn/module:invitation_system, dbtn/hasAuth
   * @name get_invitation_details
   * @summary Get Invitation Details
   * @request GET:/routes/invitation-system/invitation/{invitation_token}
   */
  export namespace get_invitation_details {
    export type RequestParams = {
      /** Invitation Token */
      invitationToken: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetInvitationDetailsData;
  }

  /**
   * @description Accept a team invitation
   * @tags dbtn/module:invitation_system, dbtn/hasAuth
   * @name accept_invitation
   * @summary Accept Invitation
   * @request POST:/routes/invitation-system/accept-invitation
   */
  export namespace accept_invitation {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = AcceptInvitationRequest;
    export type RequestHeaders = {};
    export type ResponseBody = AcceptInvitationData;
  }

  /**
   * @description Resend a team invitation
   * @tags dbtn/module:invitation_system, dbtn/hasAuth
   * @name resend_invitation
   * @summary Resend Invitation
   * @request POST:/routes/invitation-system/resend-invitation
   */
  export namespace resend_invitation {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = ResendInvitationRequest;
    export type RequestHeaders = {};
    export type ResponseBody = ResendInvitationData;
  }

  /**
   * @description Cancel a pending invitation
   * @tags dbtn/module:invitation_system, dbtn/hasAuth
   * @name cancel_invitation
   * @summary Cancel Invitation
   * @request DELETE:/routes/invitation-system/invitations/{invitation_id}
   */
  export namespace cancel_invitation {
    export type RequestParams = {
      /** Invitation Id */
      invitationId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = CancelInvitationData;
  }

  /**
   * @description Manually send invitation email (for testing or resending)
   * @tags dbtn/module:invitation_system, dbtn/hasAuth
   * @name send_invitation_email_manually
   * @summary Send Invitation Email Manually
   * @request POST:/routes/invitation-system/send-invitation-email
   */
  export namespace send_invitation_email_manually {
    export type RequestParams = {};
    export type RequestQuery = {
      /** Invitation Id */
      invitation_id: number;
      /** Custom Message */
      custom_message?: string | null;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = SendInvitationEmailManuallyData;
  }

  /**
   * @description Create a new customer profile for screening
   * @tags dbtn/module:customer_screening, dbtn/hasAuth
   * @name create_customer
   * @summary Create Customer
   * @request POST:/routes/customer-screening/customers
   */
  export namespace create_customer {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = CustomerProfile;
    export type RequestHeaders = {};
    export type ResponseBody = CreateCustomerData;
  }

  /**
   * @description List customer profiles with filtering and pagination
   * @tags dbtn/module:customer_screening, dbtn/hasAuth
   * @name list_customers
   * @summary List Customers
   * @request GET:/routes/customer-screening/customers
   */
  export namespace list_customers {
    export type RequestParams = {};
    export type RequestQuery = {
      /**
       * Limit
       * @max 1000
       * @default 50
       */
      limit?: number;
      /**
       * Offset
       * @min 0
       * @default 0
       */
      offset?: number;
      /** Search */
      search?: string | null;
      /** Risk Category */
      risk_category?: string | null;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ListCustomersData;
  }

  /**
   * @description Update an existing customer profile
   * @tags dbtn/module:customer_screening, dbtn/hasAuth
   * @name update_customer
   * @summary Update Customer
   * @request PUT:/routes/customer-screening/customers/{customer_id}
   */
  export namespace update_customer {
    export type RequestParams = {
      /** Customer Id */
      customerId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = CustomerProfile;
    export type RequestHeaders = {};
    export type ResponseBody = UpdateCustomerData;
  }

  /**
   * @description Delete a customer profile and associated screening data
   * @tags dbtn/module:customer_screening, dbtn/hasAuth
   * @name delete_customer
   * @summary Delete Customer
   * @request DELETE:/routes/customer-screening/customers/{customer_id}
   */
  export namespace delete_customer {
    export type RequestParams = {
      /** Customer Id */
      customerId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = DeleteCustomerData;
  }

  /**
   * @description Perform batch screening for multiple customers
   * @tags dbtn/module:customer_screening, dbtn/hasAuth
   * @name batch_screen_customers
   * @summary Batch Screen Customers
   * @request POST:/routes/customer-screening/batch-screen
   */
  export namespace batch_screen_customers {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = BatchScreeningRequest;
    export type RequestHeaders = {};
    export type ResponseBody = BatchScreenCustomersData;
  }

  /**
   * @description Export screening results in specified format
   * @tags dbtn/module:customer_screening, dbtn/hasAuth
   * @name export_screening_results
   * @summary Export Screening Results
   * @request POST:/routes/customer-screening/export
   */
  export namespace export_screening_results {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = ScreeningExportRequest;
    export type RequestHeaders = {};
    export type ResponseBody = ExportScreeningResultsData;
  }

  /**
   * @description Perform screening for a specific customer against watchlists (optionally at a specific date)
   * @tags dbtn/module:customer_screening, dbtn/hasAuth
   * @name screen_customer
   * @summary Screen Customer
   * @request POST:/routes/customer-screening/screen/{customer_id}
   */
  export namespace screen_customer {
    export type RequestParams = {
      /** Customer Id */
      customerId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = ScreenCustomerPayload;
    export type RequestHeaders = {};
    export type ResponseBody = ScreenCustomerData;
  }

  /**
   * @description Get screening history for a customer
   * @tags dbtn/module:customer_screening, dbtn/hasAuth
   * @name get_screening_history
   * @summary Get Screening History
   * @request GET:/routes/customer-screening/results/{customer_id}
   */
  export namespace get_screening_history {
    export type RequestParams = {
      /** Customer Id */
      customerId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetScreeningHistoryData;
  }

  /**
   * @description Get screening alerts with filtering
   * @tags dbtn/module:customer_screening, dbtn/hasAuth
   * @name get_screening_alerts
   * @summary Get Screening Alerts
   * @request GET:/routes/customer-screening/alerts
   */
  export namespace get_screening_alerts {
    export type RequestParams = {};
    export type RequestQuery = {
      /** Status */
      status?: string | null;
      /** Priority */
      priority?: string | null;
      /**
       * Limit
       * @max 200
       * @default 50
       */
      limit?: number;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetScreeningAlertsData;
  }

  /**
   * @description Verify a screening match as true positive or false positive
   * @tags dbtn/module:customer_screening, dbtn/hasAuth
   * @name verify_hit
   * @summary Verify Hit
   * @request POST:/routes/customer-screening/verify-hit
   */
  export namespace verify_hit {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = HitVerificationRequest;
    export type RequestHeaders = {};
    export type ResponseBody = VerifyHitData;
  }

  /**
   * @description Search watchlists directly for sanctioned persons, entities, vessels, and aircraft
   * @tags dbtn/module:customer_screening, dbtn/hasAuth
   * @name search_watchlists
   * @summary Search Watchlists
   * @request POST:/routes/customer-screening/search-watchlists
   */
  export namespace search_watchlists {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = WatchlistSearchRequest;
    export type RequestHeaders = {};
    export type ResponseBody = SearchWatchlistsData;
  }

  /**
   * @description Qualify a screening match as true positive or false positive
   * @tags dbtn/module:customer_screening, dbtn/hasAuth
   * @name qualify_screening_match
   * @summary Qualify Screening Match
   * @request PUT:/routes/customer-screening/qualify-match/{match_id}
   */
  export namespace qualify_screening_match {
    export type RequestParams = {
      /** Match Id */
      matchId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = MatchQualificationRequest;
    export type RequestHeaders = {};
    export type ResponseBody = QualifyScreeningMatchData;
  }

  /**
   * @description Get all risk categories
   * @tags dbtn/module:end_use_checks, dbtn/hasAuth
   * @name get_risk_categories
   * @summary Get Risk Categories
   * @request GET:/routes/end-use-checks/risk-categories
   */
  export namespace get_risk_categories {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetRiskCategoriesData;
  }

  /**
   * @description Get risk indicators, optionally filtered by category
   * @tags dbtn/module:end_use_checks, dbtn/hasAuth
   * @name get_risk_indicators
   * @summary Get Risk Indicators
   * @request GET:/routes/end-use-checks/risk-indicators
   */
  export namespace get_risk_indicators {
    export type RequestParams = {};
    export type RequestQuery = {
      /** Category Id */
      category_id?: number | null;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetRiskIndicatorsData;
  }

  /**
   * @description Get critical countries with optional search and filtering
   * @tags dbtn/module:end_use_checks, dbtn/hasAuth
   * @name list_critical_countries
   * @summary List Critical Countries
   * @request GET:/routes/end-use-checks/countries
   */
  export namespace list_critical_countries {
    export type RequestParams = {};
    export type RequestQuery = {
      /** Search */
      search?: string | null;
      /** Category */
      category?: string | null;
      /**
       * Limit
       * @default 100
       */
      limit?: number;
      /**
       * Offset
       * @default 0
       */
      offset?: number;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ListCriticalCountriesData;
  }

  /**
   * @description Create a new critical country
   * @tags dbtn/module:end_use_checks, dbtn/hasAuth
   * @name create_country
   * @summary Create Country
   * @request POST:/routes/end-use-checks/countries
   */
  export namespace create_country {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = CountryCreateRequest;
    export type RequestHeaders = {};
    export type ResponseBody = CreateCountryData;
  }

  /**
   * @description Get detailed information for a specific country
   * @tags dbtn/module:end_use_checks, dbtn/hasAuth
   * @name get_country_detail
   * @summary Get Country Detail
   * @request GET:/routes/end-use-checks/countries/{country_id}
   */
  export namespace get_country_detail {
    export type RequestParams = {
      /** Country Id */
      countryId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetCountryDetailData;
  }

  /**
   * @description Update a critical country
   * @tags dbtn/module:end_use_checks, dbtn/hasAuth
   * @name update_country
   * @summary Update Country
   * @request PUT:/routes/end-use-checks/countries/{country_id}
   */
  export namespace update_country {
    export type RequestParams = {
      /** Country Id */
      countryId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = CountryUpdateRequest;
    export type RequestHeaders = {};
    export type ResponseBody = UpdateCountryData;
  }

  /**
   * @description Delete a critical country
   * @tags dbtn/module:end_use_checks, dbtn/hasAuth
   * @name delete_country
   * @summary Delete Country
   * @request DELETE:/routes/end-use-checks/countries/{country_id}
   */
  export namespace delete_country {
    export type RequestParams = {
      /** Country Id */
      countryId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = DeleteCountryData;
  }

  /**
   * @description Create or update a risk assessment for a country
   * @tags dbtn/module:end_use_checks, dbtn/hasAuth
   * @name create_or_update_risk_assessment
   * @summary Create Or Update Risk Assessment
   * @request POST:/routes/end-use-checks/risk-assessments
   */
  export namespace create_or_update_risk_assessment {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = RiskAssessmentRequest;
    export type RequestHeaders = {};
    export type ResponseBody = CreateOrUpdateRiskAssessmentData;
  }

  /**
   * @description Delete a specific risk assessment
   * @tags dbtn/module:end_use_checks, dbtn/hasAuth
   * @name delete_risk_assessment
   * @summary Delete Risk Assessment
   * @request DELETE:/routes/end-use-checks/risk-assessments/{country_id}/{indicator_id}
   */
  export namespace delete_risk_assessment {
    export type RequestParams = {
      /** Country Id */
      countryId: number;
      /** Indicator Id */
      indicatorId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = DeleteRiskAssessmentData;
  }

  /**
   * @description Advanced search for countries with risk-based filtering
   * @tags dbtn/module:end_use_checks, dbtn/hasAuth
   * @name search_critical_countries
   * @summary Search Critical Countries
   * @request POST:/routes/end-use-checks/countries/search
   */
  export namespace search_critical_countries {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = CountrySearchFilters;
    export type RequestHeaders = {};
    export type ResponseBody = SearchCriticalCountriesData;
  }

  /**
   * @description Get statistics about critical countries data
   * @tags dbtn/module:end_use_checks, dbtn/hasAuth
   * @name get_critical_countries_stats
   * @summary Get Critical Countries Stats
   * @request GET:/routes/end-use-checks/stats
   */
  export namespace get_critical_countries_stats {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetCriticalCountriesStatsData;
  }

  /**
   * @description Bulk upload critical countries from Excel file
   * @tags dbtn/module:end_use_checks, dbtn/hasAuth
   * @name bulk_upload_critical_countries
   * @summary Bulk Upload Critical Countries
   * @request POST:/routes/end-use-checks/critical-countries/bulk-upload
   */
  export namespace bulk_upload_critical_countries {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = BodyBulkUploadCriticalCountries;
    export type RequestHeaders = {};
    export type ResponseBody = BulkUploadCriticalCountriesData;
  }

  /**
   * @description Download Excel template for critical countries bulk upload
   * @tags dbtn/module:end_use_checks, dbtn/hasAuth
   * @name download_critical_countries_template
   * @summary Download Critical Countries Template
   * @request GET:/routes/end-use-checks/critical-countries/download-template
   */
  export namespace download_critical_countries_template {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = DownloadCriticalCountriesTemplateData;
  }

  /**
   * @description List critical countries with filtering and pagination
   * @tags dbtn/module:end_use_checks, dbtn/hasAuth
   * @name get_critical_countries_list
   * @summary Get Critical Countries List
   * @request GET:/routes/end-use-checks/critical-countries
   */
  export namespace get_critical_countries_list {
    export type RequestParams = {};
    export type RequestQuery = {
      /**
       * Limit
       * @default 50
       */
      limit?: number;
      /**
       * Offset
       * @default 0
       */
      offset?: number;
      /** Search */
      search?: string | null;
      /** Risk Level */
      risk_level?: string | null;
      /** Is Active */
      is_active?: boolean | null;
      /** Has Sanctions */
      has_sanctions?: boolean | null;
      /** Export Control Member */
      export_control_member?: boolean | null;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetCriticalCountriesListData;
  }

  /**
   * @description Get comprehensive usage summary for the current user
   * @tags dbtn/module:usage_monitoring, dbtn/hasAuth
   * @name get_user_usage_summary
   * @summary Get User Usage Summary
   * @request GET:/routes/usage/summary
   */
  export namespace get_user_usage_summary {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetUserUsageSummaryData;
  }

  /**
   * @description Get detailed breakdown of usage by component and action
   * @tags dbtn/module:usage_monitoring, dbtn/hasAuth
   * @name get_component_usage_breakdown
   * @summary Get Component Usage Breakdown
   * @request GET:/routes/usage/components
   */
  export namespace get_component_usage_breakdown {
    export type RequestParams = {};
    export type RequestQuery = {
      /**
       * Days
       * Number of days to analyze
       * @default 30
       */
      days?: number;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetComponentUsageBreakdownData;
  }

  /**
   * @description Get daily usage data for charting
   * @tags dbtn/module:usage_monitoring, dbtn/hasAuth
   * @name get_daily_usage_chart
   * @summary Get Daily Usage Chart
   * @request GET:/routes/usage/daily-chart
   */
  export namespace get_daily_usage_chart {
    export type RequestParams = {};
    export type RequestQuery = {
      /**
       * Days
       * Number of days to chart
       * @default 30
       */
      days?: number;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetDailyUsageChartData;
  }

  /**
   * @description Get real-time usage metrics for the current day
   * @tags dbtn/module:usage_monitoring, dbtn/hasAuth
   * @name get_real_time_metrics
   * @summary Get Real Time Metrics
   * @request GET:/routes/usage/real-time-metrics
   */
  export namespace get_real_time_metrics {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetRealTimeMetricsData;
  }

  /**
   * @description Get active spending alerts for the user
   * @tags dbtn/module:usage_monitoring, dbtn/hasAuth
   * @name get_active_spending_alerts
   * @summary Get Active Spending Alerts
   * @request GET:/routes/alerts/active
   */
  export namespace get_active_spending_alerts {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetActiveSpendingAlertsData;
  }

  /**
   * @description Configure spending alert thresholds
   * @tags dbtn/module:usage_monitoring, dbtn/hasAuth
   * @name configure_spending_alerts
   * @summary Configure Spending Alerts
   * @request POST:/routes/alerts/configure
   */
  export namespace configure_spending_alerts {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = ConfigureSpendingAlertsPayload;
    export type RequestHeaders = {};
    export type ResponseBody = ConfigureSpendingAlertsData;
  }

  /**
   * @description Check current usage against thresholds and trigger alerts if needed
   * @tags dbtn/module:usage_monitoring, dbtn/hasAuth
   * @name check_and_trigger_alerts
   * @summary Check And Trigger Alerts
   * @request POST:/routes/alerts/check
   */
  export namespace check_and_trigger_alerts {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = CheckAndTriggerAlertsData;
  }

  /**
   * @description Dismiss a spending alert
   * @tags dbtn/module:usage_monitoring, dbtn/hasAuth
   * @name dismiss_spending_alert
   * @summary Dismiss Spending Alert
   * @request POST:/routes/alerts/{alert_id}/dismiss
   */
  export namespace dismiss_spending_alert {
    export type RequestParams = {
      /** Alert Id */
      alertId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = DismissSpendingAlertData;
  }

  /**
   * @description Get comprehensive usage analytics for admin dashboard
   * @tags dbtn/module:usage_monitoring, dbtn/hasAuth
   * @name get_admin_usage_analytics
   * @summary Get Admin Usage Analytics
   * @request GET:/routes/admin/analytics
   */
  export namespace get_admin_usage_analytics {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetAdminUsageAnalyticsData;
  }

  /**
   * @description Get real-time system-wide metrics for admin dashboard
   * @tags dbtn/module:usage_monitoring, dbtn/hasAuth
   * @name get_admin_real_time_dashboard
   * @summary Get Admin Real Time Dashboard
   * @request GET:/routes/admin/real-time-dashboard
   */
  export namespace get_admin_real_time_dashboard {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetAdminRealTimeDashboardData;
  }

  /**
   * @description Submit a document for admin review and approval
   * @tags dbtn/module:user_submissions, dbtn/hasAuth
   * @name submit_document
   * @summary Submit Document
   * @request POST:/routes/user-submissions/submit-document
   */
  export namespace submit_document {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = BodySubmitDocument;
    export type RequestHeaders = {};
    export type ResponseBody = SubmitDocumentData;
  }

  /**
   * @description Submit a case study for admin review and approval
   * @tags dbtn/module:user_submissions, dbtn/hasAuth
   * @name submit_case_study
   * @summary Submit Case Study
   * @request POST:/routes/user-submissions/submit-case-study
   */
  export namespace submit_case_study {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = BodySubmitCaseStudy;
    export type RequestHeaders = {};
    export type ResponseBody = SubmitCaseStudyData;
  }

  /**
   * @description Submit a blog article for admin review and approval
   * @tags dbtn/module:user_submissions, dbtn/hasAuth
   * @name submit_blog_article
   * @summary Submit Blog Article
   * @request POST:/routes/user-submissions/submit-blog-article
   */
  export namespace submit_blog_article {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = BlogSubmissionRequest;
    export type RequestHeaders = {};
    export type ResponseBody = SubmitBlogArticleData;
  }

  /**
   * @description Get user's submission history
   * @tags dbtn/module:user_submissions, dbtn/hasAuth
   * @name get_my_submissions
   * @summary Get My Submissions
   * @request GET:/routes/user-submissions/my-submissions
   */
  export namespace get_my_submissions {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetMySubmissionsData;
  }

  /**
   * @description Get all admin validation tasks
   * @tags dbtn/module:admin_tasks, dbtn/hasAuth
   * @name list_admin_tasks
   * @summary List Admin Tasks
   * @request GET:/routes/admin-tasks/list
   */
  export namespace list_admin_tasks {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ListAdminTasksData;
  }

  /**
   * @description Get all pending validation tasks
   * @tags dbtn/module:admin_tasks, dbtn/hasAuth
   * @name get_pending_tasks
   * @summary Get Pending Tasks
   * @request GET:/routes/admin-tasks/pending
   */
  export namespace get_pending_tasks {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetPendingTasksData;
  }

  /**
   * @description Update task status (approve/reject)
   * @tags dbtn/module:admin_tasks, dbtn/hasAuth
   * @name update_task
   * @summary Update Task
   * @request POST:/routes/admin-tasks/update/{task_id}
   */
  export namespace update_task {
    export type RequestParams = {
      /** Task Id */
      taskId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = TaskUpdateRequest;
    export type RequestHeaders = {};
    export type ResponseBody = UpdateTaskData;
  }

  /**
   * @description Save or update an assessment with user responses
   * @tags dbtn/module:assessment_management, dbtn/hasAuth
   * @name save_assessment
   * @summary Save Assessment
   * @request POST:/routes/assessment-management/save
   */
  export namespace save_assessment {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = SaveAssessmentRequest;
    export type RequestHeaders = {};
    export type ResponseBody = SaveAssessmentData;
  }

  /**
   * @description Load a specific assessment by ID
   * @tags dbtn/module:assessment_management, dbtn/hasAuth
   * @name load_assessment
   * @summary Load Assessment
   * @request GET:/routes/assessment-management/load/{assessment_id}
   */
  export namespace load_assessment {
    export type RequestParams = {
      /** Assessment Id */
      assessmentId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = LoadAssessmentData;
  }

  /**
   * @description List all assessments for the current user
   * @tags dbtn/module:assessment_management, dbtn/hasAuth
   * @name list_user_assessments
   * @summary List User Assessments
   * @request GET:/routes/assessment-management/list
   */
  export namespace list_user_assessments {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ListUserAssessmentsData;
  }

  /**
   * @description Delete an assessment
   * @tags dbtn/module:assessment_management, dbtn/hasAuth
   * @name delete_assessment
   * @summary Delete Assessment
   * @request DELETE:/routes/assessment-management/delete/{assessment_id}
   */
  export namespace delete_assessment {
    export type RequestParams = {
      /** Assessment Id */
      assessmentId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = DeleteAssessmentData;
  }

  /**
   * @description Get all module pricing configurations
   * @tags dbtn/module:module_pricing, dbtn/hasAuth
   * @name get_module_pricing_configurations
   * @summary Get Module Pricing Configurations
   * @request GET:/routes/module-pricing/configurations
   */
  export namespace get_module_pricing_configurations {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetModulePricingConfigurationsData;
  }

  /**
   * @description Create new module pricing configuration
   * @tags dbtn/module:module_pricing, dbtn/hasAuth
   * @name create_module_pricing_configuration
   * @summary Create Module Pricing Configuration
   * @request POST:/routes/module-pricing/configurations
   */
  export namespace create_module_pricing_configuration {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = ModulePricingCreate;
    export type RequestHeaders = {};
    export type ResponseBody = CreateModulePricingConfigurationData;
  }

  /**
   * @description Update module pricing configuration
   * @tags dbtn/module:module_pricing, dbtn/hasAuth
   * @name update_module_pricing_configuration
   * @summary Update Module Pricing Configuration
   * @request PUT:/routes/module-pricing/configurations/{module_name}
   */
  export namespace update_module_pricing_configuration {
    export type RequestParams = {
      /** Module Name */
      moduleName: string;
    };
    export type RequestQuery = {};
    export type RequestBody = ModulePricingUpdate;
    export type RequestHeaders = {};
    export type ResponseBody = UpdateModulePricingConfigurationData;
  }

  /**
   * @description Delete module pricing configuration
   * @tags dbtn/module:module_pricing, dbtn/hasAuth
   * @name delete_module_pricing_configuration
   * @summary Delete Module Pricing Configuration
   * @request DELETE:/routes/module-pricing/configurations/{module_name}
   */
  export namespace delete_module_pricing_configuration {
    export type RequestParams = {
      /** Module Name */
      moduleName: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = DeleteModulePricingConfigurationData;
  }

  /**
   * @description Get specific module pricing configuration
   * @tags dbtn/module:module_pricing, dbtn/hasAuth
   * @name get_module_pricing_configuration
   * @summary Get Module Pricing Configuration
   * @request GET:/routes/module-pricing/configuration/{module_name}
   */
  export namespace get_module_pricing_configuration {
    export type RequestParams = {
      /** Module Name */
      moduleName: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetModulePricingConfigurationData;
  }

  /**
   * @description Send a risk assessment report via email with PDF attachment. Uses Databutton's email service to send professional assessment reports.
   * @tags dbtn/module:email_service, dbtn/hasAuth
   * @name send_assessment_email
   * @summary Send Assessment Email
   * @request POST:/routes/email/send-assessment
   */
  export namespace send_assessment_email {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = EmailRequest;
    export type RequestHeaders = {};
    export type ResponseBody = SendAssessmentEmailData;
  }

  /**
   * @description Check if user is eligible for free tier credits
   * @tags dbtn/module:free_tier, dbtn/hasAuth
   * @name check_free_tier_eligibility
   * @summary Check Free Tier Eligibility
   * @request GET:/routes/check-eligibility
   */
  export namespace check_free_tier_eligibility {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = CheckFreeTierEligibilityData;
  }

  /**
   * @description Activate free tier credits for eligible users
   * @tags dbtn/module:free_tier, dbtn/hasAuth
   * @name activate_free_tier_credits
   * @summary Activate Free Tier Credits
   * @request POST:/routes/activate
   */
  export namespace activate_free_tier_credits {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ActivateFreeTierCreditsData;
  }

  /**
   * @description Get trial usage statistics for the user
   * @tags dbtn/module:free_tier, dbtn/hasAuth
   * @name get_trial_usage_stats
   * @summary Get Trial Usage Stats
   * @request GET:/routes/trial-stats
   */
  export namespace get_trial_usage_stats {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetTrialUsageStatsData;
  }

  /**
   * @description Award bonus credits for specific trial milestones
   * @tags dbtn/module:free_tier, dbtn/hasAuth
   * @name extend_trial_credits
   * @summary Extend Trial Credits
   * @request POST:/routes/extend-trial
   */
  export namespace extend_trial_credits {
    export type RequestParams = {};
    export type RequestQuery = {
      /**
       * Bonus Credits
       * @default 25
       */
      bonus_credits?: number;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ExtendTrialCreditsData;
  }

  /**
   * @description Upload a form for risk assessment analysis
   * @tags dbtn/module:risk_assessment, dbtn/hasAuth
   * @name upload_assessment_form
   * @summary Upload Assessment Form
   * @request POST:/routes/risk-assessment/upload-form
   */
  export namespace upload_assessment_form {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = BodyUploadAssessmentForm;
    export type RequestHeaders = {};
    export type ResponseBody = UploadAssessmentFormData;
  }

  /**
   * @description Analyze the uploaded form and extract structure
   * @tags dbtn/module:risk_assessment, dbtn/hasAuth
   * @name analyze_uploaded_form
   * @summary Analyze Uploaded Form
   * @request GET:/routes/risk-assessment/analyze-form/{file_id}
   */
  export namespace analyze_uploaded_form {
    export type RequestParams = {
      /** File Id */
      fileId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = AnalyzeUploadedFormData;
  }

  /**
   * @description List all uploaded forms for the current user
   * @tags dbtn/module:risk_assessment, dbtn/hasAuth
   * @name list_uploaded_forms
   * @summary List Uploaded Forms
   * @request GET:/routes/risk-assessment/forms
   */
  export namespace list_uploaded_forms {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ListUploadedFormsData;
  }

  /**
   * @description Export risk assessment as PDF with RespectUs branding
   * @tags stream, dbtn/module:risk_assessment, dbtn/hasAuth
   * @name export_assessment_pdf
   * @summary Export Assessment Pdf
   * @request GET:/routes/risk-assessment/export-pdf/{assessment_id}
   */
  export namespace export_assessment_pdf {
    export type RequestParams = {
      /** Assessment Id */
      assessmentId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ExportAssessmentPdfData;
  }

  /**
   * @description Get all critical countries with comprehensive data
   * @tags dbtn/module:critical_countries, dbtn/hasAuth
   * @name get_all_critical_countries
   * @summary Get All Critical Countries
   * @request GET:/routes/critical-countries
   */
  export namespace get_all_critical_countries {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetAllCriticalCountriesData;
  }

  /**
   * @description Create a new critical country
   * @tags dbtn/module:critical_countries, dbtn/hasAuth
   * @name create_critical_country
   * @summary Create Critical Country
   * @request POST:/routes/critical-countries
   */
  export namespace create_critical_country {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = CriticalCountryCreate;
    export type RequestHeaders = {};
    export type ResponseBody = CreateCriticalCountryData;
  }

  /**
   * @description Update a critical country
   * @tags dbtn/module:critical_countries, dbtn/hasAuth
   * @name update_critical_country
   * @summary Update Critical Country
   * @request PUT:/routes/critical-countries/{countryId}
   */
  export namespace update_critical_country {
    export type RequestParams = {
      /** Countryid */
      countryId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = CriticalCountryUpdate;
    export type RequestHeaders = {};
    export type ResponseBody = UpdateCriticalCountryData;
  }

  /**
   * @description Delete a critical country
   * @tags dbtn/module:critical_countries, dbtn/hasAuth
   * @name delete_critical_country
   * @summary Delete Critical Country
   * @request DELETE:/routes/critical-countries/{countryId}
   */
  export namespace delete_critical_country {
    export type RequestParams = {
      /** Countryid */
      countryId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = DeleteCriticalCountryData;
  }

  /**
   * @description Generate PDF report for individual customer screening
   * @tags dbtn/module:pdf_reports, dbtn/hasAuth
   * @name generate_individual_report
   * @summary Generate Individual Report
   * @request POST:/routes/generate-individual-report
   */
  export namespace generate_individual_report {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = IndividualReportRequest;
    export type RequestHeaders = {};
    export type ResponseBody = GenerateIndividualReportData;
  }

  /**
   * @description Generate PDF report for batch customer screening
   * @tags dbtn/module:pdf_reports, dbtn/hasAuth
   * @name generate_batch_report
   * @summary Generate Batch Report
   * @request POST:/routes/generate-batch-report
   */
  export namespace generate_batch_report {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = BatchReportRequest;
    export type RequestHeaders = {};
    export type ResponseBody = GenerateBatchReportData;
  }

  /**
   * @description Generate PDF report for country risk analysis
   * @tags dbtn/module:pdf_reports, dbtn/hasAuth
   * @name generate_country_report
   * @summary Generate Country Report
   * @request POST:/routes/generate-country-report
   */
  export namespace generate_country_report {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = CountryReportRequest;
    export type RequestHeaders = {};
    export type ResponseBody = GenerateCountryReportData;
  }

  /**
   * @description Export critical countries data in various formats
   * @tags stream, dbtn/module:export, dbtn/hasAuth
   * @name export_critical_countries
   * @summary Export Critical Countries
   * @request POST:/routes/export/critical-countries
   */
  export namespace export_critical_countries {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = ExportRequest;
    export type RequestHeaders = {};
    export type ResponseBody = ExportCriticalCountriesData;
  }

  /**
   * @description Create a new customer transaction
   * @tags dbtn/module:customer_transactions, dbtn/hasAuth
   * @name create_transaction
   * @summary Create Transaction
   * @request POST:/routes/customer-transactions/transactions
   */
  export namespace create_transaction {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = CustomerTransactionInput;
    export type RequestHeaders = {};
    export type ResponseBody = CreateTransactionData;
  }

  /**
   * @description List customer transactions with filtering
   * @tags dbtn/module:customer_transactions, dbtn/hasAuth
   * @name list_transactions
   * @summary List Transactions
   * @request GET:/routes/customer-transactions/transactions
   */
  export namespace list_transactions {
    export type RequestParams = {};
    export type RequestQuery = {
      /** Customer Id */
      customer_id?: number | null;
      /** Transaction Type */
      transaction_type?: string | null;
      /** Status */
      status?: string | null;
      /**
       * Limit
       * @max 1000
       * @default 50
       */
      limit?: number;
      /**
       * Offset
       * @min 0
       * @default 0
       */
      offset?: number;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ListTransactionsData;
  }

  /**
   * @description Update an existing transaction
   * @tags dbtn/module:customer_transactions, dbtn/hasAuth
   * @name update_transaction
   * @summary Update Transaction
   * @request PUT:/routes/customer-transactions/transactions/{transaction_id}
   */
  export namespace update_transaction {
    export type RequestParams = {
      /** Transaction Id */
      transactionId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = CustomerTransactionInput;
    export type RequestHeaders = {};
    export type ResponseBody = UpdateTransactionData;
  }

  /**
   * @description Delete a transaction
   * @tags dbtn/module:customer_transactions, dbtn/hasAuth
   * @name delete_transaction
   * @summary Delete Transaction
   * @request DELETE:/routes/customer-transactions/transactions/{transaction_id}
   */
  export namespace delete_transaction {
    export type RequestParams = {
      /** Transaction Id */
      transactionId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = DeleteTransactionData;
  }

  /**
   * @description Get current monitoring configuration for the user
   * @tags dbtn/module:background_monitoring, dbtn/hasAuth
   * @name get_monitoring_configuration
   * @summary Get Monitoring Configuration
   * @request GET:/routes/background-monitoring/configuration
   */
  export namespace get_monitoring_configuration {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetMonitoringConfigurationData;
  }

  /**
   * @description Save monitoring configuration
   * @tags dbtn/module:background_monitoring, dbtn/hasAuth
   * @name save_monitoring_configuration
   * @summary Save Monitoring Configuration
   * @request POST:/routes/background-monitoring/configuration
   */
  export namespace save_monitoring_configuration {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = MonitoringConfiguration;
    export type RequestHeaders = {};
    export type ResponseBody = SaveMonitoringConfigurationData;
  }

  /**
   * @description Get current monitoring status and report
   * @tags dbtn/module:background_monitoring, dbtn/hasAuth
   * @name get_monitoring_status
   * @summary Get Monitoring Status
   * @request GET:/routes/background-monitoring/status
   */
  export namespace get_monitoring_status {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetMonitoringStatusData;
  }

  /**
   * @description Manually trigger monitoring for specific customers or all
   * @tags dbtn/module:background_monitoring, dbtn/hasAuth
   * @name trigger_monitoring
   * @summary Trigger Monitoring
   * @request POST:/routes/background-monitoring/trigger
   */
  export namespace trigger_monitoring {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = TriggerMonitoringRequest;
    export type RequestHeaders = {};
    export type ResponseBody = TriggerMonitoringData;
  }

  /**
   * @description Get recent background monitoring job statuses
   * @tags dbtn/module:background_monitoring, dbtn/hasAuth
   * @name get_background_jobs
   * @summary Get Background Jobs
   * @request GET:/routes/background-monitoring/jobs
   */
  export namespace get_background_jobs {
    export type RequestParams = {};
    export type RequestQuery = {
      /**
       * Limit
       * @default 20
       */
      limit?: number;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetBackgroundJobsData;
  }

  /**
   * @description Get monitoring history for a specific customer
   * @tags dbtn/module:background_monitoring, dbtn/hasAuth
   * @name get_customer_monitoring_history
   * @summary Get Customer Monitoring History
   * @request GET:/routes/background-monitoring/customer/{customer_id}/history
   */
  export namespace get_customer_monitoring_history {
    export type RequestParams = {
      /** Customer Id */
      customerId: string;
    };
    export type RequestQuery = {
      /**
       * Limit
       * @default 10
       */
      limit?: number;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetCustomerMonitoringHistoryData;
  }

  /**
   * @description Get monitoring system health metrics
   * @tags dbtn/module:background_monitoring, dbtn/hasAuth
   * @name get_monitoring_system_health
   * @summary Get Monitoring System Health
   * @request GET:/routes/background-monitoring/health
   */
  export namespace get_monitoring_system_health {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetMonitoringSystemHealthData;
  }

  /**
   * @description List all monitoring schedules for the current user.
   * @tags dbtn/module:monitoring, dbtn/hasAuth
   * @name list_monitoring_schedules
   * @summary List Monitoring Schedules
   * @request GET:/routes/monitoring/schedules
   */
  export namespace list_monitoring_schedules {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ListMonitoringSchedulesData;
  }

  /**
   * @description Create a new automated monitoring schedule.
   * @tags dbtn/module:monitoring, dbtn/hasAuth
   * @name create_monitoring_schedule
   * @summary Create Monitoring Schedule
   * @request POST:/routes/monitoring/schedules
   */
  export namespace create_monitoring_schedule {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = CreateMonitoringScheduleRequest;
    export type RequestHeaders = {};
    export type ResponseBody = CreateMonitoringScheduleData;
  }

  /**
   * @description Get a specific monitoring schedule.
   * @tags dbtn/module:monitoring, dbtn/hasAuth
   * @name get_monitoring_schedule
   * @summary Get Monitoring Schedule
   * @request GET:/routes/monitoring/schedules/{schedule_id}
   */
  export namespace get_monitoring_schedule {
    export type RequestParams = {
      /** Schedule Id */
      scheduleId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetMonitoringScheduleData;
  }

  /**
   * @description Update a monitoring schedule.
   * @tags dbtn/module:monitoring, dbtn/hasAuth
   * @name update_monitoring_schedule
   * @summary Update Monitoring Schedule
   * @request PUT:/routes/monitoring/schedules/{schedule_id}
   */
  export namespace update_monitoring_schedule {
    export type RequestParams = {
      /** Schedule Id */
      scheduleId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = UpdateMonitoringScheduleRequest;
    export type RequestHeaders = {};
    export type ResponseBody = UpdateMonitoringScheduleData;
  }

  /**
   * @description Delete a monitoring schedule.
   * @tags dbtn/module:monitoring, dbtn/hasAuth
   * @name delete_monitoring_schedule
   * @summary Delete Monitoring Schedule
   * @request DELETE:/routes/monitoring/schedules/{schedule_id}
   */
  export namespace delete_monitoring_schedule {
    export type RequestParams = {
      /** Schedule Id */
      scheduleId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = DeleteMonitoringScheduleData;
  }

  /**
   * @description List automation jobs for the current user.
   * @tags dbtn/module:monitoring, dbtn/hasAuth
   * @name list_automation_jobs
   * @summary List Automation Jobs
   * @request GET:/routes/monitoring/jobs
   */
  export namespace list_automation_jobs {
    export type RequestParams = {};
    export type RequestQuery = {
      /**
       * Limit
       * @default 50
       */
      limit?: number;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ListAutomationJobsData;
  }

  /**
   * @description Get a specific automation job.
   * @tags dbtn/module:monitoring, dbtn/hasAuth
   * @name get_automation_job
   * @summary Get Automation Job
   * @request GET:/routes/monitoring/jobs/{job_id}
   */
  export namespace get_automation_job {
    export type RequestParams = {
      /** Job Id */
      jobId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetAutomationJobData;
  }

  /**
   * @description Get notification preferences for the current user.
   * @tags dbtn/module:monitoring, dbtn/hasAuth
   * @name get_notification_preferences
   * @summary Get Notification Preferences
   * @request GET:/routes/monitoring/notification-preferences
   */
  export namespace get_notification_preferences {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetNotificationPreferencesData;
  }

  /**
   * @description Update notification preferences for the current user.
   * @tags dbtn/module:monitoring, dbtn/hasAuth
   * @name update_notification_preferences
   * @summary Update Notification Preferences
   * @request PUT:/routes/monitoring/notification-preferences
   */
  export namespace update_notification_preferences {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = NotificationPreferencesRequest;
    export type RequestHeaders = {};
    export type ResponseBody = UpdateNotificationPreferencesData;
  }

  /**
   * @description Manually trigger a screening job for a specific schedule.
   * @tags dbtn/module:monitoring, dbtn/hasAuth
   * @name trigger_manual_screening
   * @summary Trigger Manual Screening
   * @request POST:/routes/monitoring/trigger-screening/{schedule_id}
   */
  export namespace trigger_manual_screening {
    export type RequestParams = {
      /** Schedule Id */
      scheduleId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = TriggerManualScreeningData;
  }

  /**
   * @description Update risk assessments for customers based on latest screening results
   * @tags dbtn/module:monitoring, dbtn/hasAuth
   * @name update_risk_assessments
   * @summary Update Risk Assessments
   * @request POST:/routes/monitoring/update-risk-assessments
   */
  export namespace update_risk_assessments {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = UpdateRiskAssessmentsRequest;
    export type RequestHeaders = {};
    export type ResponseBody = UpdateRiskAssessmentsData;
  }

  /**
   * @description Schedule automated risk assessment updates
   * @tags dbtn/module:monitoring, dbtn/hasAuth
   * @name schedule_risk_assessments
   * @summary Schedule Risk Assessments
   * @request POST:/routes/monitoring/schedule-risk-assessments
   */
  export namespace schedule_risk_assessments {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = ScheduleRiskAssessmentsRequest;
    export type RequestHeaders = {};
    export type ResponseBody = ScheduleRiskAssessmentsData;
  }

  /**
   * @description Generate predictive risk scores for customers using historical data patterns
   * @tags dbtn/module:predictive_analytics, dbtn/hasAuth
   * @name predict_customer_risks
   * @summary Predict Customer Risks
   * @request POST:/routes/predictive-analytics/predict-customer-risks
   */
  export namespace predict_customer_risks {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = PredictiveRiskRequest;
    export type RequestHeaders = {};
    export type ResponseBody = PredictCustomerRisksData;
  }

  /**
   * @description Analyze risk trends over time for pattern recognition
   * @tags dbtn/module:predictive_analytics, dbtn/hasAuth
   * @name analyze_risk_trends
   * @summary Analyze Risk Trends
   * @request POST:/routes/predictive-analytics/analyze-risk-trends
   */
  export namespace analyze_risk_trends {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = RiskTrendAnalysisRequest;
    export type RequestHeaders = {};
    export type ResponseBody = AnalyzeRiskTrendsData;
  }

  /**
   * @description Evaluate the performance of the predictive risk model
   * @tags dbtn/module:predictive_analytics, dbtn/hasAuth
   * @name get_model_performance
   * @summary Get Model Performance
   * @request GET:/routes/predictive-analytics/model-performance
   */
  export namespace get_model_performance {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = ModelPerformanceRequest;
    export type RequestHeaders = {};
    export type ResponseBody = GetModelPerformanceData;
  }

  /**
   * @description Upload a document with metadata and store securely
   * @tags dbtn/module:document_management, dbtn/hasAuth
   * @name upload_customer_document
   * @summary Upload Customer Document
   * @request POST:/routes/documents/upload
   */
  export namespace upload_customer_document {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = BodyUploadCustomerDocument;
    export type RequestHeaders = {};
    export type ResponseBody = UploadCustomerDocumentData;
  }

  /**
   * @description List documents with filtering and pagination
   * @tags dbtn/module:document_management, dbtn/hasAuth
   * @name list_customer_documents
   * @summary List Customer Documents
   * @request POST:/routes/documents/list
   */
  export namespace list_customer_documents {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = DocumentListRequest;
    export type RequestHeaders = {};
    export type ResponseBody = ListCustomerDocumentsData;
  }

  /**
   * @description Approve or reject a document
   * @tags dbtn/module:document_management, dbtn/hasAuth
   * @name approve_document
   * @summary Approve Document
   * @request POST:/routes/documents/approve
   */
  export namespace approve_document {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = DocumentApprovalRequest;
    export type RequestHeaders = {};
    export type ResponseBody = ApproveDocumentData;
  }

  /**
   * @description Get document management analytics
   * @tags dbtn/module:document_management, dbtn/hasAuth
   * @name get_customer_document_analytics
   * @summary Get Customer Document Analytics
   * @request GET:/routes/documents/analytics
   */
  export namespace get_customer_document_analytics {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetCustomerDocumentAnalyticsData;
  }

  /**
   * @description List all classification notes, optionally filtered by tree_id and/or module_type
   * @tags dbtn/module:classification_notes, dbtn/hasAuth
   * @name list_classification_notes
   * @summary List Classification Notes
   * @request GET:/routes/classification/notes/list
   */
  export namespace list_classification_notes {
    export type RequestParams = {};
    export type RequestQuery = {
      /** Tree Id */
      tree_id?: string | null;
      /** Module Type */
      module_type?: string | null;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ListClassificationNotesData;
  }

  /**
   * @description Create a new classification note
   * @tags dbtn/module:classification_notes, dbtn/hasAuth
   * @name create_classification_note
   * @summary Create Classification Note
   * @request POST:/routes/classification/notes/create
   */
  export namespace create_classification_note {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = CreateNoteRequest;
    export type RequestHeaders = {};
    export type ResponseBody = CreateClassificationNoteData;
  }

  /**
   * @description Get a classification note by its key
   * @tags dbtn/module:classification_notes, dbtn/hasAuth
   * @name get_classification_note_by_key
   * @summary Get Classification Note By Key
   * @request GET:/routes/classification/notes/get/{note_key}
   */
  export namespace get_classification_note_by_key {
    export type RequestParams = {
      /** Note Key */
      noteKey: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetClassificationNoteByKeyData;
  }

  /**
   * @description Update a classification note
   * @tags dbtn/module:classification_notes, dbtn/hasAuth
   * @name update_classification_note
   * @summary Update Classification Note
   * @request PUT:/routes/classification/notes/update/{note_id}
   */
  export namespace update_classification_note {
    export type RequestParams = {
      /** Note Id */
      noteId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = UpdateNoteRequest;
    export type RequestHeaders = {};
    export type ResponseBody = UpdateClassificationNoteData;
  }

  /**
   * @description Delete a classification note
   * @tags dbtn/module:classification_notes, dbtn/hasAuth
   * @name delete_classification_note
   * @summary Delete Classification Note
   * @request DELETE:/routes/classification/notes/delete/{note_id}
   */
  export namespace delete_classification_note {
    export type RequestParams = {
      /** Note Id */
      noteId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = DeleteClassificationNoteData;
  }

  /**
   * @description Get the screening explanation content for the Sanctions & Embargoes screening tab
   * @tags dbtn/module:classification_notes, dbtn/hasAuth
   * @name get_screening_explanation
   * @summary Get Screening Explanation
   * @request GET:/routes/classification/notes/screening-explanation
   */
  export namespace get_screening_explanation {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetScreeningExplanationData;
  }

  /**
   * @description Create or update the screening explanation content for the Sanctions & Embargoes screening tab
   * @tags dbtn/module:classification_notes, dbtn/hasAuth
   * @name create_or_update_screening_explanation
   * @summary Create Or Update Screening Explanation
   * @request POST:/routes/classification/notes/screening-explanation
   */
  export namespace create_or_update_screening_explanation {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = CreateNoteRequest;
    export type RequestHeaders = {};
    export type ResponseBody = CreateOrUpdateScreeningExplanationData;
  }

  /**
   * @description Create a new customer product/technology record
   * @tags dbtn/module:customer_products, dbtn/hasAuth
   * @name create_product
   * @summary Create Product
   * @request POST:/routes/customer-products/products
   */
  export namespace create_product {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = CustomerProduct;
    export type RequestHeaders = {};
    export type ResponseBody = CreateProductData;
  }

  /**
   * @description List customer products with filtering
   * @tags dbtn/module:customer_products, dbtn/hasAuth
   * @name list_products
   * @summary List Products
   * @request GET:/routes/customer-products/products
   */
  export namespace list_products {
    export type RequestParams = {};
    export type RequestQuery = {
      /** Customer Id */
      customer_id?: number | null;
      /** Product Type */
      product_type?: string | null;
      /** Control Status */
      control_status?: string | null;
      /** Search */
      search?: string | null;
      /**
       * Limit
       * @max 1000
       * @default 50
       */
      limit?: number;
      /**
       * Offset
       * @min 0
       * @default 0
       */
      offset?: number;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ListProductsData;
  }

  /**
   * @description Update an existing product
   * @tags dbtn/module:customer_products, dbtn/hasAuth
   * @name update_product
   * @summary Update Product
   * @request PUT:/routes/customer-products/products/{product_id}
   */
  export namespace update_product {
    export type RequestParams = {
      /** Product Id */
      productId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = CustomerProduct;
    export type RequestHeaders = {};
    export type ResponseBody = UpdateProductData;
  }

  /**
   * @description Delete a product
   * @tags dbtn/module:customer_products, dbtn/hasAuth
   * @name delete_product
   * @summary Delete Product
   * @request DELETE:/routes/customer-products/products/{product_id}
   */
  export namespace delete_product {
    export type RequestParams = {
      /** Product Id */
      productId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = DeleteProductData;
  }

  /**
   * @description Update product review status and compliance information
   * @tags dbtn/module:customer_products, dbtn/hasAuth
   * @name update_product_review
   * @summary Update Product Review
   * @request PATCH:/routes/customer-products/products/{product_id}/review
   */
  export namespace update_product_review {
    export type RequestParams = {
      /** Product Id */
      productId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = ProductReviewUpdate;
    export type RequestHeaders = {};
    export type ResponseBody = UpdateProductReviewData;
  }

  /**
   * @description Get list of unique product categories
   * @tags dbtn/module:customer_products, dbtn/hasAuth
   * @name get_customer_product_categories
   * @summary Get Customer Product Categories
   * @request GET:/routes/customer-products/products/categories
   */
  export namespace get_customer_product_categories {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetCustomerProductCategoriesData;
  }

  /**
   * @description Search product classifications for export control compliance
   * @tags dbtn/module:product_classification, dbtn/hasAuth
   * @name search_products
   * @summary Search Products
   * @request POST:/routes/products/search
   */
  export namespace search_products {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = ProductSearchRequest;
    export type RequestHeaders = {};
    export type ResponseBody = SearchProductsData;
  }

  /**
   * @description Get detailed classification information for a specific product
   * @tags dbtn/module:product_classification, dbtn/hasAuth
   * @name get_product_classification
   * @summary Get Product Classification
   * @request GET:/routes/product/{product_id}
   */
  export namespace get_product_classification {
    export type RequestParams = {
      /** Product Id */
      productId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetProductClassificationData;
  }

  /**
   * @description Get list of available control regimes
   * @tags dbtn/module:product_classification, dbtn/hasAuth
   * @name get_control_regimes
   * @summary Get Control Regimes
   * @request GET:/routes/control-regimes
   */
  export namespace get_control_regimes {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetControlRegimesData;
  }

  /**
   * @description Get list of available product categories
   * @tags dbtn/module:product_classification, dbtn/hasAuth
   * @name get_classification_categories
   * @summary Get Classification Categories
   * @request GET:/routes/classification-categories
   */
  export namespace get_classification_categories {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetClassificationCategoriesData;
  }

  /**
   * @description Get list of available risk levels for products
   * @tags dbtn/module:product_classification, dbtn/hasAuth
   * @name get_product_risk_levels
   * @summary Get Product Risk Levels
   * @request GET:/routes/products/risk-levels
   */
  export namespace get_product_risk_levels {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetProductRiskLevelsData;
  }

  /**
   * @description Get comprehensive monitoring dashboard summary with key metrics
   * @tags dbtn/module:monitoring_analytics, dbtn/hasAuth
   * @name get_monitoring_dashboard_summary
   * @summary Get Monitoring Dashboard Summary
   * @request GET:/routes/monitoring-analytics/dashboard-summary
   */
  export namespace get_monitoring_dashboard_summary {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetMonitoringDashboardSummaryData;
  }

  /**
   * @description Get detailed customer monitoring analytics and distribution metrics
   * @tags dbtn/module:monitoring_analytics, dbtn/hasAuth
   * @name get_customer_monitoring_analytics
   * @summary Get Customer Monitoring Analytics
   * @request GET:/routes/monitoring-analytics/customer-analytics
   */
  export namespace get_customer_monitoring_analytics {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetCustomerMonitoringAnalyticsData;
  }

  /**
   * @description Get detailed screening performance metrics
   * @tags dbtn/module:monitoring_analytics, dbtn/hasAuth
   * @name get_screening_performance_metrics
   * @summary Get Screening Performance Metrics
   * @request GET:/routes/monitoring-analytics/screening-metrics
   */
  export namespace get_screening_performance_metrics {
    export type RequestParams = {};
    export type RequestQuery = {
      /**
       * Days
       * @default 30
       */
      days?: number;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetScreeningPerformanceMetricsData;
  }

  /**
   * @description Get automation system performance metrics
   * @tags dbtn/module:monitoring_analytics, dbtn/hasAuth
   * @name get_automation_performance_metrics
   * @summary Get Automation Performance Metrics
   * @request GET:/routes/monitoring-analytics/automation-performance
   */
  export namespace get_automation_performance_metrics {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetAutomationPerformanceMetricsData;
  }

  /**
   * @description Get compliance and regulatory metrics
   * @tags dbtn/module:monitoring_analytics, dbtn/hasAuth
   * @name get_compliance_regulatory_metrics
   * @summary Get Compliance Regulatory Metrics
   * @request GET:/routes/monitoring-analytics/compliance-metrics
   */
  export namespace get_compliance_regulatory_metrics {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetComplianceRegulatoryMetricsData;
  }

  /**
   * @description Get alert system analytics and metrics
   * @tags dbtn/module:monitoring_analytics, dbtn/hasAuth
   * @name get_monitoring_alert_analytics
   * @summary Get Monitoring Alert Analytics
   * @request GET:/routes/monitoring-analytics/alert-analytics
   */
  export namespace get_monitoring_alert_analytics {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetMonitoringAlertAnalyticsData;
  }

  /**
   * @description Get trend analysis data for various metrics
   * @tags dbtn/module:monitoring_analytics, dbtn/hasAuth
   * @name get_trend_analysis
   * @summary Get Trend Analysis
   * @request GET:/routes/monitoring-analytics/trend-analysis
   */
  export namespace get_trend_analysis {
    export type RequestParams = {};
    export type RequestQuery = {
      /**
       * Days
       * @default 90
       */
      days?: number;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetTrendAnalysisData;
  }

  /**
   * @description Save an article to user's saved collection
   * @tags dbtn/module:saved_articles, dbtn/hasAuth
   * @name save_article
   * @summary Save Article
   * @request POST:/routes/save-article
   */
  export namespace save_article {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = SaveArticleRequest;
    export type RequestHeaders = {};
    export type ResponseBody = SaveArticleData;
  }

  /**
   * @description Remove an article from user's saved collection
   * @tags dbtn/module:saved_articles, dbtn/hasAuth
   * @name unsave_article
   * @summary Unsave Article
   * @request DELETE:/routes/unsave-article/{document_id}
   */
  export namespace unsave_article {
    export type RequestParams = {
      /** Document Id */
      documentId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = UnsaveArticleData;
  }

  /**
   * @description Get all saved articles for the current user, optionally filtered by category
   * @tags dbtn/module:saved_articles, dbtn/hasAuth
   * @name get_saved_articles
   * @summary Get Saved Articles
   * @request GET:/routes/saved-articles
   */
  export namespace get_saved_articles {
    export type RequestParams = {};
    export type RequestQuery = {
      /** Category Id */
      category_id?: number | null;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetSavedArticlesData;
  }

  /**
   * @description Check if a document is saved by the user
   * @tags dbtn/module:saved_articles, dbtn/hasAuth
   * @name check_if_saved
   * @summary Check If Saved
   * @request GET:/routes/check-saved/{document_id}
   */
  export namespace check_if_saved {
    export type RequestParams = {
      /** Document Id */
      documentId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = CheckIfSavedData;
  }

  /**
   * @description Get all categories for the current user with article counts
   * @tags dbtn/module:saved_articles, dbtn/hasAuth
   * @name get_article_categories
   * @summary Get Article Categories
   * @request GET:/routes/categories
   */
  export namespace get_article_categories {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetArticleCategoriesData;
  }

  /**
   * @description Create a new article category for the user
   * @tags dbtn/module:saved_articles, dbtn/hasAuth
   * @name create_article_category
   * @summary Create Article Category
   * @request POST:/routes/categories
   */
  export namespace create_article_category {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = AppApisSavedArticlesCategoryRequest;
    export type RequestHeaders = {};
    export type ResponseBody = CreateArticleCategoryData;
  }

  /**
   * @description Update an existing category
   * @tags dbtn/module:saved_articles, dbtn/hasAuth
   * @name update_article_category
   * @summary Update Article Category
   * @request PUT:/routes/categories/{category_id}
   */
  export namespace update_article_category {
    export type RequestParams = {
      /** Category Id */
      categoryId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = AppApisSavedArticlesCategoryRequest;
    export type RequestHeaders = {};
    export type ResponseBody = UpdateArticleCategoryData;
  }

  /**
   * @description Delete a category (only if it has no articles)
   * @tags dbtn/module:saved_articles, dbtn/hasAuth
   * @name delete_article_category
   * @summary Delete Article Category
   * @request DELETE:/routes/categories/{category_id}
   */
  export namespace delete_article_category {
    export type RequestParams = {
      /** Category Id */
      categoryId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = DeleteArticleCategoryData;
  }

  /**
   * @description Assign categories to an existing saved article
   * @tags dbtn/module:saved_articles, dbtn/hasAuth
   * @name assign_categories_to_article
   * @summary Assign Categories To Article
   * @request PUT:/routes/saved-articles/{article_id}/categories
   */
  export namespace assign_categories_to_article {
    export type RequestParams = {
      /** Article Id */
      articleId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = AssignCategoriesRequest;
    export type RequestHeaders = {};
    export type ResponseBody = AssignCategoriesToArticleData;
  }

  /**
   * @description Create a new support request from a user. This creates a task in the admin dashboard for review.
   * @tags dbtn/module:support_system, dbtn/hasAuth
   * @name create_support_request
   * @summary Create Support Request
   * @request POST:/routes/request
   */
  export namespace create_support_request {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = SupportRequestCreate;
    export type RequestHeaders = {};
    export type ResponseBody = CreateSupportRequestData;
  }

  /**
   * @description Get all support tickets for the current user. Optionally filter by status: 'open', 'in_progress', 'resolved', 'closed'
   * @tags dbtn/module:support_system, dbtn/hasAuth
   * @name get_user_support_tickets
   * @summary Get User Support Tickets
   * @request GET:/routes/my-tickets
   */
  export namespace get_user_support_tickets {
    export type RequestParams = {};
    export type RequestQuery = {
      /** Status */
      status?: string | null;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetUserSupportTicketsData;
  }

  /**
   * @description Get all support tickets for admin review. Optionally filter by status and/or priority.
   * @tags dbtn/module:support_system, dbtn/hasAuth
   * @name get_admin_support_tickets
   * @summary Get Admin Support Tickets
   * @request GET:/routes/admin/tickets
   */
  export namespace get_admin_support_tickets {
    export type RequestParams = {};
    export type RequestQuery = {
      /** Status */
      status?: string | null;
      /** Priority */
      priority?: string | null;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetAdminSupportTicketsData;
  }

  /**
   * @description Admin responds to a support ticket and optionally updates status. Sends email notification to the user.
   * @tags dbtn/module:support_system, dbtn/hasAuth
   * @name admin_respond_to_ticket
   * @summary Admin Respond To Ticket
   * @request POST:/routes/admin/tickets/{ticket_id}/respond
   */
  export namespace admin_respond_to_ticket {
    export type RequestParams = {
      /** Ticket Id */
      ticketId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = AdminSupportResponse;
    export type RequestHeaders = {};
    export type ResponseBody = AdminRespondToTicketData;
  }

  /**
   * @description Get detailed information about a specific support ticket for admin review.
   * @tags dbtn/module:support_system, dbtn/hasAuth
   * @name get_support_ticket_detail
   * @summary Get Support Ticket Detail
   * @request GET:/routes/admin/tickets/{ticket_id}
   */
  export namespace get_support_ticket_detail {
    export type RequestParams = {
      /** Ticket Id */
      ticketId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetSupportTicketDetailData;
  }

  /**
   * @description Get all component pricing configurations
   * @tags dbtn/module:pricing_configuration, dbtn/hasAuth
   * @name get_component_pricing
   * @summary Get Component Pricing
   * @request GET:/routes/admin/pricing/components
   */
  export namespace get_component_pricing {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetComponentPricingData;
  }

  /**
   * @description Create new component pricing
   * @tags dbtn/module:pricing_configuration, dbtn/hasAuth
   * @name create_component_pricing
   * @summary Create Component Pricing
   * @request POST:/routes/admin/pricing/components
   */
  export namespace create_component_pricing {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = CreatePricingRequest;
    export type RequestHeaders = {};
    export type ResponseBody = CreateComponentPricingData;
  }

  /**
   * @description Update component pricing
   * @tags dbtn/module:pricing_configuration, dbtn/hasAuth
   * @name update_component_pricing
   * @summary Update Component Pricing
   * @request PUT:/routes/admin/pricing/components/{pricing_id}
   */
  export namespace update_component_pricing {
    export type RequestParams = {
      /** Pricing Id */
      pricingId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = UpdatePricingRequest;
    export type RequestHeaders = {};
    export type ResponseBody = UpdateComponentPricingData;
  }

  /**
   * @description Delete component pricing configuration
   * @tags dbtn/module:pricing_configuration, dbtn/hasAuth
   * @name delete_component_pricing
   * @summary Delete Component Pricing
   * @request DELETE:/routes/admin/pricing/components/{pricing_id}
   */
  export namespace delete_component_pricing {
    export type RequestParams = {
      /** Pricing Id */
      pricingId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = DeleteComponentPricingData;
  }

  /**
   * @description Get all pricing feature flags
   * @tags dbtn/module:pricing_configuration, dbtn/hasAuth
   * @name get_pricing_feature_flags
   * @summary Get Pricing Feature Flags
   * @request GET:/routes/admin/pricing/feature-flags
   */
  export namespace get_pricing_feature_flags {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetPricingFeatureFlagsData;
  }

  /**
   * @description Update pricing feature flag for a component
   * @tags dbtn/module:pricing_configuration, dbtn/hasAuth
   * @name update_pricing_feature_flag
   * @summary Update Pricing Feature Flag
   * @request PUT:/routes/admin/pricing/feature-flags/{component_name}
   */
  export namespace update_pricing_feature_flag {
    export type RequestParams = {
      /** Component Name */
      componentName: string;
    };
    export type RequestQuery = {};
    export type RequestBody = UpdateFeatureFlagRequest;
    export type RequestHeaders = {};
    export type ResponseBody = UpdatePricingFeatureFlagData;
  }

  /**
   * @description Check if an action requires credits and how much
   * @tags dbtn/module:pricing_configuration, dbtn/hasAuth
   * @name check_action_pricing
   * @summary Check Action Pricing
   * @request GET:/routes/pricing/check/{component_name}/{action_name}
   */
  export namespace check_action_pricing {
    export type RequestParams = {
      /** Component Name */
      componentName: string;
      /** Action Name */
      actionName: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = CheckActionPricingData;
  }

  /**
   * @description Get all usage tier pricing configurations
   * @tags dbtn/module:pricing_configuration, dbtn/hasAuth
   * @name get_usage_tier_pricing
   * @summary Get Usage Tier Pricing
   * @request GET:/routes/admin/pricing/usage-tiers
   */
  export namespace get_usage_tier_pricing {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetUsageTierPricingData;
  }

  /**
   * @description Create new usage tier pricing
   * @tags dbtn/module:pricing_configuration, dbtn/hasAuth
   * @name create_usage_tier_pricing
   * @summary Create Usage Tier Pricing
   * @request POST:/routes/admin/pricing/usage-tiers
   */
  export namespace create_usage_tier_pricing {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = CreateUsageTierPricingPayload;
    export type RequestHeaders = {};
    export type ResponseBody = CreateUsageTierPricingData;
  }

  /**
   * @description Get all geographic pricing configurations
   * @tags dbtn/module:pricing_configuration, dbtn/hasAuth
   * @name get_geographic_pricing
   * @summary Get Geographic Pricing
   * @request GET:/routes/admin/pricing/geographic
   */
  export namespace get_geographic_pricing {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetGeographicPricingData;
  }

  /**
   * @description Create new geographic pricing
   * @tags dbtn/module:pricing_configuration, dbtn/hasAuth
   * @name create_geographic_pricing
   * @summary Create Geographic Pricing
   * @request POST:/routes/admin/pricing/geographic
   */
  export namespace create_geographic_pricing {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = CreateGeographicPricingPayload;
    export type RequestHeaders = {};
    export type ResponseBody = CreateGeographicPricingData;
  }

  /**
   * @description Get all hybrid pricing model configurations
   * @tags dbtn/module:pricing_configuration, dbtn/hasAuth
   * @name get_hybrid_pricing_models
   * @summary Get Hybrid Pricing Models
   * @request GET:/routes/admin/pricing/hybrid-models
   */
  export namespace get_hybrid_pricing_models {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetHybridPricingModelsData;
  }

  /**
   * @description Create new hybrid pricing model
   * @tags dbtn/module:pricing_configuration, dbtn/hasAuth
   * @name create_hybrid_pricing_model
   * @summary Create Hybrid Pricing Model
   * @request POST:/routes/admin/pricing/hybrid-models
   */
  export namespace create_hybrid_pricing_model {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = CreateHybridPricingModelPayload;
    export type RequestHeaders = {};
    export type ResponseBody = CreateHybridPricingModelData;
  }

  /**
   * @description Advanced pricing check with tier, geographic, and hybrid model support
   * @tags dbtn/module:pricing_configuration, dbtn/hasAuth
   * @name check_dynamic_pricing
   * @summary Check Dynamic Pricing
   * @request GET:/routes/pricing/dynamic-check/{component_name}/{action_name}
   */
  export namespace check_dynamic_pricing {
    export type RequestParams = {
      /** Component Name */
      componentName: string;
      /** Action Name */
      actionName: string;
    };
    export type RequestQuery = {
      /** User Country */
      user_country?: string | null;
      /** Monthly Usage */
      monthly_usage?: number | null;
      /** Subscription Tier */
      subscription_tier?: string | null;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = CheckDynamicPricingData;
  }

  /**
   * @description Get comprehensive invoice history with filtering
   * @tags dbtn/module:billing_management, dbtn/hasAuth
   * @name get_invoice_history
   * @summary Get Invoice History
   * @request GET:/routes/billing-management/invoice-history
   */
  export namespace get_invoice_history {
    export type RequestParams = {};
    export type RequestQuery = {
      /** Company Id */
      company_id?: number | null;
      /** Status */
      status?: string | null;
      /**
       * Limit
       * @default 50
       */
      limit?: number;
      /**
       * Offset
       * @default 0
       */
      offset?: number;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetInvoiceHistoryData;
  }

  /**
   * @description Create a new invoice (Admin only)
   * @tags dbtn/module:billing_management, dbtn/hasAuth
   * @name create_invoice
   * @summary Create Invoice
   * @request POST:/routes/billing-management/create-invoice
   */
  export namespace create_invoice {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = CreateInvoiceRequest;
    export type RequestHeaders = {};
    export type ResponseBody = CreateInvoiceData;
  }

  /**
   * @description Get usage analytics for billing insights
   * @tags dbtn/module:billing_management, dbtn/hasAuth
   * @name get_usage_analytics
   * @summary Get Usage Analytics
   * @request GET:/routes/billing-management/usage-analytics
   */
  export namespace get_usage_analytics {
    export type RequestParams = {};
    export type RequestQuery = {
      /** Company Id */
      company_id?: number | null;
      /**
       * Period Days
       * @default 30
       */
      period_days?: number;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetUsageAnalyticsData;
  }

  /**
   * @description Download invoice as PDF
   * @tags dbtn/module:billing_management, dbtn/hasAuth
   * @name download_invoice
   * @summary Download Invoice
   * @request GET:/routes/billing-management/download-invoice/{invoice_id}
   */
  export namespace download_invoice {
    export type RequestParams = {
      /** Invoice Id */
      invoiceId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = DownloadInvoiceData;
  }

  /**
   * @description Update invoice status (Admin only)
   * @tags dbtn/module:billing_management, dbtn/hasAuth
   * @name update_invoice_status
   * @summary Update Invoice Status
   * @request PUT:/routes/billing-management/invoices/{invoice_id}/status
   */
  export namespace update_invoice_status {
    export type RequestParams = {
      /** Invoice Id */
      invoiceId: number;
    };
    export type RequestQuery = {
      /** Status */
      status: string;
      /** Payment Method */
      payment_method?: string | null;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = UpdateInvoiceStatusData;
  }

  /**
   * @description Get billing summary for dashboard
   * @tags dbtn/module:billing_management, dbtn/hasAuth
   * @name get_billing_summary
   * @summary Get Billing Summary
   * @request GET:/routes/billing-management/billing-summary
   */
  export namespace get_billing_summary {
    export type RequestParams = {};
    export type RequestQuery = {
      /** Company Id */
      company_id?: number | null;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetBillingSummaryData;
  }

  /**
   * @description Get billing settings and preferences
   * @tags dbtn/module:billing_management, dbtn/hasAuth
   * @name get_billing_settings
   * @summary Get Billing Settings
   * @request GET:/routes/billing-management/billing-settings
   */
  export namespace get_billing_settings {
    export type RequestParams = {};
    export type RequestQuery = {
      /** Company Id */
      company_id?: number | null;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetBillingSettingsData;
  }

  /**
   * @description Update billing settings and preferences
   * @tags dbtn/module:billing_management, dbtn/hasAuth
   * @name update_billing_settings
   * @summary Update Billing Settings
   * @request PUT:/routes/billing-management/billing-settings
   */
  export namespace update_billing_settings {
    export type RequestParams = {};
    export type RequestQuery = {
      /** Company Id */
      company_id?: number | null;
    };
    export type RequestBody = UpdateBillingSettingsRequest;
    export type RequestHeaders = {};
    export type ResponseBody = UpdateBillingSettingsData;
  }

  /**
   * @description Create a new risk assessment template (Admin only)
   * @tags dbtn/module:risk_templates, dbtn/hasAuth
   * @name create_template
   * @summary Create Template
   * @request POST:/routes/templates/create
   */
  export namespace create_template {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = CreateTemplateRequest;
    export type RequestHeaders = {};
    export type ResponseBody = CreateTemplateData;
  }

  /**
   * @description List all risk assessment templates
   * @tags dbtn/module:risk_templates, dbtn/hasAuth
   * @name list_templates
   * @summary List Templates
   * @request GET:/routes/templates
   */
  export namespace list_templates {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ListTemplatesData;
  }

  /**
   * @description Get a specific template by ID
   * @tags dbtn/module:risk_templates, dbtn/hasAuth
   * @name get_template
   * @summary Get Template
   * @request GET:/routes/template/{template_id}
   */
  export namespace get_template {
    export type RequestParams = {
      /** Template Id */
      templateId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetTemplateData;
  }

  /**
   * @description Update a template (Admin only)
   * @tags dbtn/module:risk_templates, dbtn/hasAuth
   * @name update_template
   * @summary Update Template
   * @request PUT:/routes/template/{template_id}
   */
  export namespace update_template {
    export type RequestParams = {
      /** Template Id */
      templateId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = UpdateTemplateRequest;
    export type RequestHeaders = {};
    export type ResponseBody = UpdateTemplateData;
  }

  /**
   * @description Delete a template (Admin only)
   * @tags dbtn/module:risk_templates, dbtn/hasAuth
   * @name delete_template
   * @summary Delete Template
   * @request DELETE:/routes/template/{template_id}
   */
  export namespace delete_template {
    export type RequestParams = {
      /** Template Id */
      templateId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = DeleteTemplateData;
  }

  /**
   * @description Create a customized version of a template for a company
   * @tags dbtn/module:risk_templates, dbtn/hasAuth
   * @name customize_template
   * @summary Customize Template
   * @request POST:/routes/customize
   */
  export namespace customize_template {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = CustomizeTemplateRequest;
    export type RequestHeaders = {};
    export type ResponseBody = CustomizeTemplateData;
  }

  /**
   * @description List all customized forms for the current user's company
   * @tags dbtn/module:risk_templates, dbtn/hasAuth
   * @name list_company_forms
   * @summary List Company Forms
   * @request GET:/routes/company-forms
   */
  export namespace list_company_forms {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ListCompanyFormsData;
  }

  /**
   * @description Get all metadata options for a specific category (jurisdiction/type/subject)
   * @tags dbtn/module:document_metadata, dbtn/hasAuth
   * @name get_document_metadata_options
   * @summary Get Document Metadata Options
   * @request GET:/routes/doc-metadata/metadata-options/{category}
   */
  export namespace get_document_metadata_options {
    export type RequestParams = {
      /** Category */
      category: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetDocumentMetadataOptionsData;
  }

  /**
   * @description Get all metadata options grouped by category
   * @tags dbtn/module:document_metadata, dbtn/hasAuth
   * @name get_all_document_metadata_options
   * @summary Get All Document Metadata Options
   * @request GET:/routes/doc-metadata/metadata-options
   */
  export namespace get_all_document_metadata_options {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetAllDocumentMetadataOptionsData;
  }

  /**
   * @description Create a new metadata option
   * @tags dbtn/module:document_metadata, dbtn/hasAuth
   * @name create_document_metadata_option
   * @summary Create Document Metadata Option
   * @request POST:/routes/doc-metadata/metadata-options
   */
  export namespace create_document_metadata_option {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = CreateMetadataOptionRequest;
    export type RequestHeaders = {};
    export type ResponseBody = CreateDocumentMetadataOptionData;
  }

  /**
   * @description Update an existing metadata option
   * @tags dbtn/module:document_metadata, dbtn/hasAuth
   * @name update_document_metadata_option
   * @summary Update Document Metadata Option
   * @request PUT:/routes/doc-metadata/metadata-options/{option_id}
   */
  export namespace update_document_metadata_option {
    export type RequestParams = {
      /** Option Id */
      optionId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = UpdateMetadataOptionRequest;
    export type RequestHeaders = {};
    export type ResponseBody = UpdateDocumentMetadataOptionData;
  }

  /**
   * @description Delete a metadata option (soft delete by setting is_active to false)
   * @tags dbtn/module:document_metadata, dbtn/hasAuth
   * @name delete_document_metadata_option
   * @summary Delete Document Metadata Option
   * @request DELETE:/routes/doc-metadata/metadata-options/{option_id}
   */
  export namespace delete_document_metadata_option {
    export type RequestParams = {
      /** Option Id */
      optionId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = DeleteDocumentMetadataOptionData;
  }

  /**
   * @description Bulk update display orders for drag-and-drop reordering
   * @tags dbtn/module:document_metadata, dbtn/hasAuth
   * @name reorder_document_metadata_options
   * @summary Reorder Document Metadata Options
   * @request PUT:/routes/doc-metadata/metadata-options/{category}/reorder
   */
  export namespace reorder_document_metadata_options {
    export type RequestParams = {
      /** Category */
      category: string;
    };
    export type RequestQuery = {};
    export type RequestBody = BulkReorderRequest;
    export type RequestHeaders = {};
    export type ResponseBody = ReorderDocumentMetadataOptionsData;
  }

  /**
   * @description Bulk import metadata options from structured data
   * @tags dbtn/module:document_metadata, dbtn/hasAuth
   * @name bulk_import_metadata_options
   * @summary Bulk Import Metadata Options
   * @request POST:/routes/doc-metadata/metadata-options/{category}/bulk-import
   */
  export namespace bulk_import_metadata_options {
    export type RequestParams = {
      /** Category */
      category: string;
    };
    export type RequestQuery = {};
    export type RequestBody = AppApisDocumentMetadataBulkImportRequest;
    export type RequestHeaders = {};
    export type ResponseBody = BulkImportMetadataOptionsData;
  }

  /**
   * @description Export metadata options in a structured format for backup/transfer
   * @tags dbtn/module:document_metadata, dbtn/hasAuth
   * @name export_metadata_options
   * @summary Export Metadata Options
   * @request GET:/routes/doc-metadata/metadata-options/{category}/export
   */
  export namespace export_metadata_options {
    export type RequestParams = {
      /** Category */
      category: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ExportMetadataOptionsData;
  }

  /**
   * @description Get all sections for a document (admin version with all fields)
   * @tags dbtn/module:document_sections, dbtn/hasAuth
   * @name get_document_sections_admin
   * @summary Get Document Sections Admin
   * @request GET:/routes/doc-sections/documents/{document_id}/sections
   */
  export namespace get_document_sections_admin {
    export type RequestParams = {
      /** Document Id */
      documentId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetDocumentSectionsAdminData;
  }

  /**
   * @description Create a new document section
   * @tags dbtn/module:document_sections, dbtn/hasAuth
   * @name create_document_section
   * @summary Create Document Section
   * @request POST:/routes/doc-sections/documents/{document_id}/sections
   */
  export namespace create_document_section {
    export type RequestParams = {
      /** Document Id */
      documentId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = CreateSectionRequest;
    export type RequestHeaders = {};
    export type ResponseBody = CreateDocumentSectionData;
  }

  /**
   * @description Update an existing document section
   * @tags dbtn/module:document_sections, dbtn/hasAuth
   * @name update_document_section
   * @summary Update Document Section
   * @request PUT:/routes/doc-sections/sections/{section_id}
   */
  export namespace update_document_section {
    export type RequestParams = {
      /** Section Id */
      sectionId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = UpdateSectionRequest;
    export type RequestHeaders = {};
    export type ResponseBody = UpdateDocumentSectionData;
  }

  /**
   * @description Delete a document section
   * @tags dbtn/module:document_sections, dbtn/hasAuth
   * @name delete_document_section
   * @summary Delete Document Section
   * @request DELETE:/routes/doc-sections/sections/{section_id}
   */
  export namespace delete_document_section {
    export type RequestParams = {
      /** Section Id */
      sectionId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = DeleteDocumentSectionData;
  }

  /**
   * @description Bulk update section display orders for drag-and-drop reordering
   * @tags dbtn/module:document_sections, dbtn/hasAuth
   * @name reorder_sections
   * @summary Reorder Sections
   * @request PUT:/routes/doc-sections/documents/{document_id}/sections/reorder
   */
  export namespace reorder_sections {
    export type RequestParams = {
      /** Document Id */
      documentId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = BulkUpdateOrderRequest;
    export type RequestHeaders = {};
    export type ResponseBody = ReorderSectionsData;
  }

  /**
   * @description Bulk import sections from structured data
   * @tags dbtn/module:document_sections, dbtn/hasAuth
   * @name bulk_import_sections
   * @summary Bulk Import Sections
   * @request POST:/routes/doc-sections/documents/{document_id}/sections/bulk-import
   */
  export namespace bulk_import_sections {
    export type RequestParams = {
      /** Document Id */
      documentId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = AppApisDocumentSectionsBulkImportRequest;
    export type RequestHeaders = {};
    export type ResponseBody = BulkImportSectionsData;
  }

  /**
   * @description Export document sections in a structured format for backup/transfer
   * @tags dbtn/module:document_sections, dbtn/hasAuth
   * @name export_sections
   * @summary Export Sections
   * @request GET:/routes/doc-sections/documents/{document_id}/sections/export
   */
  export namespace export_sections {
    export type RequestParams = {
      /** Document Id */
      documentId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ExportSectionsData;
  }

  /**
   * @description Update the sections_not_applicable flag for a document
   * @tags dbtn/module:document_sections, dbtn/hasAuth
   * @name update_sections_not_applicable
   * @summary Update Sections Not Applicable
   * @request POST:/routes/doc-sections/documents/{document_id}/sections-not-applicable
   */
  export namespace update_sections_not_applicable {
    export type RequestParams = {
      /** Document Id */
      documentId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = SectionsNotApplicableRequest;
    export type RequestHeaders = {};
    export type ResponseBody = UpdateSectionsNotApplicableData;
  }

  /**
   * @description Get the sections_not_applicable flag for a document
   * @tags dbtn/module:document_sections, dbtn/hasAuth
   * @name get_sections_not_applicable
   * @summary Get Sections Not Applicable
   * @request GET:/routes/doc-sections/documents/{document_id}/sections-not-applicable
   */
  export namespace get_sections_not_applicable {
    export type RequestParams = {
      /** Document Id */
      documentId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetSectionsNotApplicableData;
  }

  /**
   * @description Get paginated list of documents with their pricing information
   * @tags dbtn/module:document_pricing, dbtn/hasAuth
   * @name get_document_pricing
   * @summary Get Document Pricing
   * @request GET:/routes/doc-pricing/document-pricing
   */
  export namespace get_document_pricing {
    export type RequestParams = {};
    export type RequestQuery = {
      /**
       * Page
       * @default 1
       */
      page?: number;
      /**
       * Limit
       * @default 50
       */
      limit?: number;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetDocumentPricingData;
  }

  /**
   * @description Update pricing for a specific document
   * @tags dbtn/module:document_pricing, dbtn/hasAuth
   * @name update_document_pricing
   * @summary Update Document Pricing
   * @request PUT:/routes/doc-pricing/document-pricing/{document_id}
   */
  export namespace update_document_pricing {
    export type RequestParams = {
      /** Document Id */
      documentId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = DocumentPricingUpdate;
    export type RequestHeaders = {};
    export type ResponseBody = UpdateDocumentPricingData;
  }

  /**
   * @description Update pricing for multiple documents
   * @tags dbtn/module:document_pricing, dbtn/hasAuth
   * @name update_bulk_pricing
   * @summary Update Bulk Pricing
   * @request PUT:/routes/doc-pricing/bulk-pricing
   */
  export namespace update_bulk_pricing {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = BulkPricingUpdate;
    export type RequestHeaders = {};
    export type ResponseBody = UpdateBulkPricingData;
  }

  /**
   * @description Apply default pricing rules to documents matching criteria
   * @tags dbtn/module:document_pricing, dbtn/hasAuth
   * @name apply_default_pricing
   * @summary Apply Default Pricing
   * @request POST:/routes/doc-pricing/apply-default-pricing
   */
  export namespace apply_default_pricing {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = DefaultPricingRule;
    export type RequestHeaders = {};
    export type ResponseBody = ApplyDefaultPricingData;
  }

  /**
   * @description Get pricing analytics from the view
   * @tags dbtn/module:document_pricing, dbtn/hasAuth
   * @name get_pricing_analytics
   * @summary Get Pricing Analytics
   * @request GET:/routes/doc-pricing/pricing-analytics
   */
  export namespace get_pricing_analytics {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetPricingAnalyticsData;
  }

  /**
   * @description Get pricing details for a specific document
   * @tags dbtn/module:document_pricing, dbtn/hasAuth
   * @name get_document_pricing_detail
   * @summary Get Document Pricing Detail
   * @request GET:/routes/doc-pricing/document/{document_id}/pricing
   */
  export namespace get_document_pricing_detail {
    export type RequestParams = {
      /** Document Id */
      documentId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetDocumentPricingDetailData;
  }

  /**
   * @description List all sanctions trees for admin management
   * @tags dbtn/module:sanctions, dbtn/hasAuth
   * @name list_sanctions_trees
   * @summary List Sanctions Trees
   * @request GET:/routes/sanctions/admin/trees
   */
  export namespace list_sanctions_trees {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ListSanctionsTreesData;
  }

  /**
   * @description Create a new sanctions tree
   * @tags dbtn/module:sanctions, dbtn/hasAuth
   * @name create_sanctions_tree
   * @summary Create Sanctions Tree
   * @request POST:/routes/sanctions/admin/trees
   */
  export namespace create_sanctions_tree {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = SanctionsTreeCreate;
    export type RequestHeaders = {};
    export type ResponseBody = CreateSanctionsTreeData;
  }

  /**
   * @description Get a specific sanctions tree
   * @tags dbtn/module:sanctions, dbtn/hasAuth
   * @name get_sanctions_tree
   * @summary Get Sanctions Tree
   * @request GET:/routes/sanctions/admin/trees/{tree_id}
   */
  export namespace get_sanctions_tree {
    export type RequestParams = {
      /** Tree Id */
      treeId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetSanctionsTreeData;
  }

  /**
   * @description Update a sanctions tree
   * @tags dbtn/module:sanctions, dbtn/hasAuth
   * @name update_sanctions_tree
   * @summary Update Sanctions Tree
   * @request PUT:/routes/sanctions/admin/trees/{tree_id}
   */
  export namespace update_sanctions_tree {
    export type RequestParams = {
      /** Tree Id */
      treeId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = SanctionsTreeUpdate;
    export type RequestHeaders = {};
    export type ResponseBody = UpdateSanctionsTreeData;
  }

  /**
   * @description Delete a sanctions tree
   * @tags dbtn/module:sanctions, dbtn/hasAuth
   * @name delete_sanctions_tree
   * @summary Delete Sanctions Tree
   * @request DELETE:/routes/sanctions/admin/trees/{tree_id}
   */
  export namespace delete_sanctions_tree {
    export type RequestParams = {
      /** Tree Id */
      treeId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = DeleteSanctionsTreeData;
  }

  /**
   * @description Duplicate a sanctions tree with all its nodes and options
   * @tags dbtn/module:sanctions, dbtn/hasAuth
   * @name duplicate_sanctions_tree
   * @summary Duplicate Sanctions Tree
   * @request POST:/routes/sanctions/admin/trees/{tree_id}/duplicate
   */
  export namespace duplicate_sanctions_tree {
    export type RequestParams = {
      /** Tree Id */
      treeId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = DuplicateSanctionsTreeData;
  }

  /**
   * @description List all nodes for a specific sanctions tree
   * @tags dbtn/module:sanctions, dbtn/hasAuth
   * @name list_sanctions_nodes
   * @summary List Sanctions Nodes
   * @request GET:/routes/sanctions/admin/trees/{tree_id}/nodes
   */
  export namespace list_sanctions_nodes {
    export type RequestParams = {
      /** Tree Id */
      treeId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ListSanctionsNodesData;
  }

  /**
   * @description Create a new node in a sanctions tree
   * @tags dbtn/module:sanctions, dbtn/hasAuth
   * @name create_sanctions_node
   * @summary Create Sanctions Node
   * @request POST:/routes/sanctions/admin/trees/{tree_id}/nodes
   */
  export namespace create_sanctions_node {
    export type RequestParams = {
      /** Tree Id */
      treeId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = SanctionsNodeCreate;
    export type RequestHeaders = {};
    export type ResponseBody = CreateSanctionsNodeData;
  }

  /**
   * @description Get a specific sanctions node
   * @tags dbtn/module:sanctions, dbtn/hasAuth
   * @name get_sanctions_node
   * @summary Get Sanctions Node
   * @request GET:/routes/sanctions/admin/trees/{tree_id}/nodes/{node_id}
   */
  export namespace get_sanctions_node {
    export type RequestParams = {
      /** Tree Id */
      treeId: string;
      /** Node Id */
      nodeId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetSanctionsNodeData;
  }

  /**
   * @description Update a sanctions node
   * @tags dbtn/module:sanctions, dbtn/hasAuth
   * @name update_sanctions_node
   * @summary Update Sanctions Node
   * @request PUT:/routes/sanctions/admin/trees/{tree_id}/nodes/{node_id}
   */
  export namespace update_sanctions_node {
    export type RequestParams = {
      /** Tree Id */
      treeId: string;
      /** Node Id */
      nodeId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = SanctionsNodeUpdate;
    export type RequestHeaders = {};
    export type ResponseBody = UpdateSanctionsNodeData;
  }

  /**
   * @description Delete a sanctions node
   * @tags dbtn/module:sanctions, dbtn/hasAuth
   * @name delete_sanctions_node
   * @summary Delete Sanctions Node
   * @request DELETE:/routes/sanctions/admin/trees/{tree_id}/nodes/{node_id}
   */
  export namespace delete_sanctions_node {
    export type RequestParams = {
      /** Tree Id */
      treeId: string;
      /** Node Id */
      nodeId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = DeleteSanctionsNodeData;
  }

  /**
   * @description Duplicate a sanctions node with all its options
   * @tags dbtn/module:sanctions, dbtn/hasAuth
   * @name duplicate_sanctions_node
   * @summary Duplicate Sanctions Node
   * @request POST:/routes/sanctions/admin/trees/{tree_id}/nodes/{node_id}/duplicate
   */
  export namespace duplicate_sanctions_node {
    export type RequestParams = {
      /** Tree Id */
      treeId: string;
      /** Node Id */
      nodeId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = DuplicateSanctionsNodeData;
  }

  /**
   * @description List all options for a specific sanctions node
   * @tags dbtn/module:sanctions, dbtn/hasAuth
   * @name list_sanctions_node_options
   * @summary List Sanctions Node Options
   * @request GET:/routes/sanctions/admin/trees/{tree_id}/nodes/{node_id}/options
   */
  export namespace list_sanctions_node_options {
    export type RequestParams = {
      /** Tree Id */
      treeId: string;
      /** Node Id */
      nodeId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ListSanctionsNodeOptionsData;
  }

  /**
   * @description Create a new option for a sanctions node
   * @tags dbtn/module:sanctions, dbtn/hasAuth
   * @name create_sanctions_node_option
   * @summary Create Sanctions Node Option
   * @request POST:/routes/sanctions/admin/trees/{tree_id}/nodes/{node_id}/options
   */
  export namespace create_sanctions_node_option {
    export type RequestParams = {
      /** Tree Id */
      treeId: string;
      /** Node Id */
      nodeId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = SanctionsNodeOptionCreate;
    export type RequestHeaders = {};
    export type ResponseBody = CreateSanctionsNodeOptionData;
  }

  /**
   * @description Get a specific sanctions node option
   * @tags dbtn/module:sanctions, dbtn/hasAuth
   * @name get_sanctions_node_option
   * @summary Get Sanctions Node Option
   * @request GET:/routes/sanctions/admin/trees/{tree_id}/nodes/{node_id}/options/{option_id}
   */
  export namespace get_sanctions_node_option {
    export type RequestParams = {
      /** Tree Id */
      treeId: string;
      /** Node Id */
      nodeId: string;
      /** Option Id */
      optionId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetSanctionsNodeOptionData;
  }

  /**
   * @description Update a sanctions node option
   * @tags dbtn/module:sanctions, dbtn/hasAuth
   * @name update_sanctions_node_option
   * @summary Update Sanctions Node Option
   * @request PUT:/routes/sanctions/admin/trees/{tree_id}/nodes/{node_id}/options/{option_id}
   */
  export namespace update_sanctions_node_option {
    export type RequestParams = {
      /** Tree Id */
      treeId: string;
      /** Node Id */
      nodeId: string;
      /** Option Id */
      optionId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = SanctionsNodeOptionUpdate;
    export type RequestHeaders = {};
    export type ResponseBody = UpdateSanctionsNodeOptionData;
  }

  /**
   * @description Delete a sanctions node option
   * @tags dbtn/module:sanctions, dbtn/hasAuth
   * @name delete_sanctions_node_option
   * @summary Delete Sanctions Node Option
   * @request DELETE:/routes/sanctions/admin/trees/{tree_id}/nodes/{node_id}/options/{option_id}
   */
  export namespace delete_sanctions_node_option {
    export type RequestParams = {
      /** Tree Id */
      treeId: string;
      /** Node Id */
      nodeId: string;
      /** Option Id */
      optionId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = DeleteSanctionsNodeOptionData;
  }

  /**
   * @description List all published sanctions trees for user access
   * @tags dbtn/module:sanctions, dbtn/hasAuth
   * @name list_published_sanctions_trees
   * @summary List Published Sanctions Trees
   * @request GET:/routes/sanctions/trees
   */
  export namespace list_published_sanctions_trees {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ListPublishedSanctionsTreesData;
  }

  /**
   * @description Get a specific published sanctions tree
   * @tags dbtn/module:sanctions, dbtn/hasAuth
   * @name get_published_sanctions_tree
   * @summary Get Published Sanctions Tree
   * @request GET:/routes/sanctions/trees/{tree_id}
   */
  export namespace get_published_sanctions_tree {
    export type RequestParams = {
      /** Tree Id */
      treeId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetPublishedSanctionsTreeData;
  }

  /**
   * @description Get all nodes for a published sanctions tree
   * @tags dbtn/module:sanctions, dbtn/hasAuth
   * @name get_published_sanctions_tree_nodes
   * @summary Get Published Sanctions Tree Nodes
   * @request GET:/routes/sanctions/trees/{tree_id}/nodes
   */
  export namespace get_published_sanctions_tree_nodes {
    export type RequestParams = {
      /** Tree Id */
      treeId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetPublishedSanctionsTreeNodesData;
  }

  /**
   * @description Get all options for a published sanctions node
   * @tags dbtn/module:sanctions, dbtn/hasAuth
   * @name get_published_sanctions_node_options
   * @summary Get Published Sanctions Node Options
   * @request GET:/routes/sanctions/trees/{tree_id}/nodes/{node_id}/options
   */
  export namespace get_published_sanctions_node_options {
    export type RequestParams = {
      /** Tree Id */
      treeId: string;
      /** Node Id */
      nodeId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetPublishedSanctionsNodeOptionsData;
  }

  /**
   * @description Assess sanctions applicability using tree logic
   * @tags dbtn/module:sanctions, dbtn/hasAuth
   * @name assess_sanctions_applicability
   * @summary Assess Sanctions Applicability
   * @request POST:/routes/sanctions/assess
   */
  export namespace assess_sanctions_applicability {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = SanctionsAssessmentRequest;
    export type RequestHeaders = {};
    export type ResponseBody = AssessSanctionsApplicabilityData;
  }

  /**
   * @description Save or update a classification progress
   * @tags dbtn/module:classification_autosave, dbtn/hasAuth
   * @name save_classification
   * @summary Save Classification
   * @request POST:/routes/classification-save/save-classification
   */
  export namespace save_classification {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = SavedClassificationRequest;
    export type RequestHeaders = {};
    export type ResponseBody = SaveClassificationData;
  }

  /**
   * @description List user's saved classifications
   * @tags dbtn/module:classification_autosave, dbtn/hasAuth
   * @name list_saved_classifications
   * @summary List Saved Classifications
   * @request GET:/routes/classification-save/list-classifications
   */
  export namespace list_saved_classifications {
    export type RequestParams = {};
    export type RequestQuery = {
      /**
       * Include Archived
       * @default false
       */
      include_archived?: boolean;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ListSavedClassificationsData;
  }

  /**
   * @description Load a specific classification
   * @tags dbtn/module:classification_autosave, dbtn/hasAuth
   * @name load_classification
   * @summary Load Classification
   * @request GET:/routes/classification-save/load-classification/{classification_id}
   */
  export namespace load_classification {
    export type RequestParams = {
      /** Classification Id */
      classificationId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = LoadClassificationData;
  }

  /**
   * @description Delete a classification (move to archived)
   * @tags dbtn/module:classification_autosave, dbtn/hasAuth
   * @name delete_classification
   * @summary Delete Classification
   * @request DELETE:/routes/classification-save/delete-classification/{classification_id}
   */
  export namespace delete_classification {
    export type RequestParams = {
      /** Classification Id */
      classificationId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = DeleteClassificationData;
  }

  /**
   * @description Restore an archived classification
   * @tags dbtn/module:classification_autosave, dbtn/hasAuth
   * @name restore_classification
   * @summary Restore Classification
   * @request POST:/routes/classification-save/restore-classification/{classification_id}
   */
  export namespace restore_classification {
    export type RequestParams = {
      /** Classification Id */
      classificationId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = RestoreClassificationData;
  }

  /**
   * @description Get pending notifications for classifications
   * @tags dbtn/module:classification_autosave, dbtn/hasAuth
   * @name get_classification_notifications
   * @summary Get Classification Notifications
   * @request GET:/routes/classification-save/notifications
   */
  export namespace get_classification_notifications {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetClassificationNotificationsData;
  }

  /**
   * @description Background task to archive expired classifications
   * @tags dbtn/module:classification_autosave, dbtn/hasAuth
   * @name cleanup_expired_classifications
   * @summary Cleanup Expired Classifications
   * @request POST:/routes/classification-save/cleanup-expired
   */
  export namespace cleanup_expired_classifications {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = CleanupExpiredClassificationsData;
  }

  /**
   * @description List all badges
   * @tags dbtn/module:badge_management, dbtn/hasAuth
   * @name list_badges
   * @summary List Badges
   * @request GET:/routes/badges/badges
   */
  export namespace list_badges {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ListBadgesData;
  }

  /**
   * @description Create a new badge
   * @tags dbtn/module:badge_management, dbtn/hasAuth
   * @name create_badge
   * @summary Create Badge
   * @request POST:/routes/badges/badges
   */
  export namespace create_badge {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = CreateBadgeRequest;
    export type RequestHeaders = {};
    export type ResponseBody = CreateBadgeData;
  }

  /**
   * @description Get a specific badge by ID
   * @tags dbtn/module:badge_management, dbtn/hasAuth
   * @name get_badge
   * @summary Get Badge
   * @request GET:/routes/badges/badges/{badge_id}
   */
  export namespace get_badge {
    export type RequestParams = {
      /** Badge Id */
      badgeId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetBadgeData;
  }

  /**
   * @description Update a badge
   * @tags dbtn/module:badge_management, dbtn/hasAuth
   * @name update_badge
   * @summary Update Badge
   * @request PUT:/routes/badges/badges/{badge_id}
   */
  export namespace update_badge {
    export type RequestParams = {
      /** Badge Id */
      badgeId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = UpdateBadgeRequest;
    export type RequestHeaders = {};
    export type ResponseBody = UpdateBadgeData;
  }

  /**
   * @description Delete a badge
   * @tags dbtn/module:badge_management, dbtn/hasAuth
   * @name delete_badge
   * @summary Delete Badge
   * @request DELETE:/routes/badges/badges/{badge_id}
   */
  export namespace delete_badge {
    export type RequestParams = {
      /** Badge Id */
      badgeId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = DeleteBadgeData;
  }

  /**
   * @description List all badge categories
   * @tags dbtn/module:badge_management, dbtn/hasAuth
   * @name list_badge_categories
   * @summary List Badge Categories
   * @request GET:/routes/badges/badges/categories
   */
  export namespace list_badge_categories {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ListBadgeCategoriesData;
  }

  /**
   * @description Create a new document alert
   * @tags dbtn/module:document_alerts, dbtn/hasAuth
   * @name create_document_alert
   * @summary Create Document Alert
   * @request POST:/routes/doc-alerts/create
   */
  export namespace create_document_alert {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = DocumentAlertCreate;
    export type RequestHeaders = {};
    export type ResponseBody = CreateDocumentAlertData;
  }

  /**
   * @description List document alerts with optional filtering
   * @tags dbtn/module:document_alerts, dbtn/hasAuth
   * @name list_document_alerts
   * @summary List Document Alerts
   * @request GET:/routes/doc-alerts/alerts
   */
  export namespace list_document_alerts {
    export type RequestParams = {};
    export type RequestQuery = {
      /**
       * Alert Type
       * Filter by alert type
       */
      alert_type?: string | null;
      /**
       * Status
       * Filter by status
       */
      status?: string | null;
      /**
       * Severity
       * Filter by severity
       */
      severity?: string | null;
      /**
       * Include Expired
       * Include expired alerts
       * @default false
       */
      include_expired?: boolean;
      /**
       * Limit
       * Maximum number of alerts to return
       * @default 50
       */
      limit?: number;
      /**
       * Offset
       * Offset for pagination
       * @default 0
       */
      offset?: number;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ListDocumentAlertsData;
  }

  /**
   * @description Get a specific document alert by ID
   * @tags dbtn/module:document_alerts, dbtn/hasAuth
   * @name get_document_alert
   * @summary Get Document Alert
   * @request GET:/routes/doc-alerts/alerts/{alert_id}
   */
  export namespace get_document_alert {
    export type RequestParams = {
      /** Alert Id */
      alertId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetDocumentAlertData;
  }

  /**
   * @description Update the status of a document alert (acknowledge or resolve)
   * @tags dbtn/module:document_alerts, dbtn/hasAuth
   * @name update_alert_status
   * @summary Update Alert Status
   * @request PUT:/routes/doc-alerts/{alert_id}/status
   */
  export namespace update_alert_status {
    export type RequestParams = {
      /** Alert Id */
      alertId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = DocumentAlertStatusUpdate;
    export type RequestHeaders = {};
    export type ResponseBody = UpdateAlertStatusData;
  }

  /**
   * @description Update a document alert
   * @tags dbtn/module:document_alerts, dbtn/hasAuth
   * @name update_document_alert
   * @summary Update Document Alert
   * @request PUT:/routes/doc-alerts/{alert_id}
   */
  export namespace update_document_alert {
    export type RequestParams = {
      /** Alert Id */
      alertId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = DocumentAlertUpdate;
    export type RequestHeaders = {};
    export type ResponseBody = UpdateDocumentAlertData;
  }

  /**
   * @description Delete a document alert
   * @tags dbtn/module:document_alerts, dbtn/hasAuth
   * @name delete_document_alert
   * @summary Delete Document Alert
   * @request DELETE:/routes/doc-alerts/{alert_id}
   */
  export namespace delete_document_alert {
    export type RequestParams = {
      /** Alert Id */
      alertId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = DeleteDocumentAlertData;
  }

  /**
   * @description Get summary statistics for alerts
   * @tags dbtn/module:document_alerts, dbtn/hasAuth
   * @name get_alerts_summary
   * @summary Get Alerts Summary
   * @request GET:/routes/doc-alerts/stats/summary
   */
  export namespace get_alerts_summary {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetAlertsSummaryData;
  }

  /**
   * @description Compare multiple documents side-by-side for regulatory analysis
   * @tags dbtn/module:document_comparison, dbtn/hasAuth
   * @name compare_documents
   * @summary Compare Documents
   * @request POST:/routes/doc-compare/compare
   */
  export namespace compare_documents {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = ComparisonRequest;
    export type RequestHeaders = {};
    export type ResponseBody = CompareDocumentsData;
  }

  /**
   * @description Get suggested documents for comparison with a given document
   * @tags dbtn/module:document_comparison, dbtn/hasAuth
   * @name get_comparison_suggestions
   * @summary Get Comparison Suggestions
   * @request GET:/routes/doc-compare/compare/suggestions
   */
  export namespace get_comparison_suggestions {
    export type RequestParams = {};
    export type RequestQuery = {
      /**
       * Document Id
       * Base document ID for suggestions
       */
      document_id: number;
      /**
       * Limit
       * Maximum number of suggestions
       * @default 5
       */
      limit?: number;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetComparisonSuggestionsData;
  }

  /**
   * @description Download CSV template for critical products bulk import
   * @tags dbtn/module:critical_products, dbtn/hasAuth
   * @name download_critical_products_template
   * @summary Download Critical Products Template
   * @request GET:/routes/critical-products/download-template
   */
  export namespace download_critical_products_template {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = DownloadCriticalProductsTemplateData;
  }

  /**
   * @description Download Excel template for critical products bulk import
   * @tags dbtn/module:critical_products, dbtn/hasAuth
   * @name download_critical_products_excel_template
   * @summary Download Critical Products Excel Template
   * @request GET:/routes/critical-products/download-excel-template
   */
  export namespace download_critical_products_excel_template {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = DownloadCriticalProductsExcelTemplateData;
  }

  /**
   * @description Search critical products database by HS/CN codes, keywords, or filters. Supports multi-modal search: exact code match, fuzzy search, and full-text search.
   * @tags dbtn/module:critical_products, dbtn/hasAuth
   * @name search_critical_products
   * @summary Search Critical Products
   * @request POST:/routes/critical-products/search
   */
  export namespace search_critical_products {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = SearchCriticalProductsRequest;
    export type RequestHeaders = {};
    export type ResponseBody = SearchCriticalProductsData;
  }

  /**
   * @description List all trade codes with optional category filtering.
   * @tags dbtn/module:critical_products, dbtn/hasAuth
   * @name list_trade_codes
   * @summary List Trade Codes
   * @request GET:/routes/critical-products/trade-codes
   */
  export namespace list_trade_codes {
    export type RequestParams = {};
    export type RequestQuery = {
      /** Category */
      category?: string | null;
      /**
       * Limit
       * @max 500
       * @default 100
       */
      limit?: number;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ListTradeCodesData;
  }

  /**
   * @description Create a new trade code entry.
   * @tags dbtn/module:critical_products, dbtn/hasAuth
   * @name create_trade_code
   * @summary Create Trade Code
   * @request POST:/routes/critical-products/trade-codes
   */
  export namespace create_trade_code {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = CreateTradeCodeRequest;
    export type RequestHeaders = {};
    export type ResponseBody = CreateTradeCodeData;
  }

  /**
   * @description List restrictive measures with optional filtering.
   * @tags dbtn/module:critical_products, dbtn/hasAuth
   * @name list_restrictive_measures
   * @summary List Restrictive Measures
   * @request GET:/routes/critical-products/restrictive-measures
   */
  export namespace list_restrictive_measures {
    export type RequestParams = {};
    export type RequestQuery = {
      /** Jurisdiction */
      jurisdiction?: string | null;
      /** Measure Type */
      measure_type?: string | null;
      /**
       * Limit
       * @max 500
       * @default 100
       */
      limit?: number;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ListRestrictiveMeasuresData;
  }

  /**
   * @description Create a new restrictive measure.
   * @tags dbtn/module:critical_products, dbtn/hasAuth
   * @name create_restrictive_measure
   * @summary Create Restrictive Measure
   * @request POST:/routes/critical-products/restrictive-measures
   */
  export namespace create_restrictive_measure {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = CreateRestrictiveMeasureRequest;
    export type RequestHeaders = {};
    export type ResponseBody = CreateRestrictiveMeasureData;
  }

  /**
   * @description Get list of available product categories.
   * @tags dbtn/module:critical_products, dbtn/hasAuth
   * @name get_categories
   * @summary Get Categories
   * @request GET:/routes/critical-products/product-categories
   */
  export namespace get_categories {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetCategoriesData;
  }

  /**
   * @description Get list of available jurisdictions.
   * @tags dbtn/module:critical_products, dbtn/hasAuth
   * @name get_jurisdictions
   * @summary Get Jurisdictions
   * @request GET:/routes/critical-products/product-jurisdictions
   */
  export namespace get_jurisdictions {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetJurisdictionsData;
  }

  /**
   * @description Get list of available measure types.
   * @tags dbtn/module:critical_products, dbtn/hasAuth
   * @name get_measure_types
   * @summary Get Measure Types
   * @request GET:/routes/critical-products/measure-types
   */
  export namespace get_measure_types {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetMeasureTypesData;
  }

  /**
   * @description Get statistics about the critical products database.
   * @tags dbtn/module:critical_products, dbtn/hasAuth
   * @name get_critical_products_stats
   * @summary Get Critical Products Stats
   * @request GET:/routes/critical-products/critical-stats
   */
  export namespace get_critical_products_stats {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetCriticalProductsStatsData;
  }

  /**
   * @description Get CMS content for Database sections (trade-codes, measures, restrictions, jurisdictions, product-classification)
   * @tags dbtn/module:critical_products, dbtn/hasAuth
   * @name get_critical_products_section_content
   * @summary Get Critical Products Section Content
   * @request GET:/routes/critical-products/section-content/{section_type}
   */
  export namespace get_critical_products_section_content {
    export type RequestParams = {
      /** Section Type */
      sectionType: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetCriticalProductsSectionContentData;
  }

  /**
   * @description Export critical products data to Excel or CSV.
   * @tags stream, dbtn/module:critical_products, dbtn/hasAuth
   * @name export_critical_products
   * @summary Export Critical Products
   * @request GET:/routes/critical-products/export-products
   */
  export namespace export_critical_products {
    export type RequestParams = {};
    export type RequestQuery = {
      /**
       * Format
       * @default "xlsx"
       */
      format?: string;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ExportCriticalProductsData;
  }

  /**
   * @description Create a new critical product entry.
   * @tags dbtn/module:critical_products, dbtn/hasAuth
   * @name create_critical_product
   * @summary Create Critical Product
   * @request POST:/routes/critical-products/critical-products/create
   */
  export namespace create_critical_product {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = CreateTradeCodeRequest;
    export type RequestHeaders = {};
    export type ResponseBody = CreateCriticalProductData;
  }

  /**
   * @description Delete a critical product.
   * @tags dbtn/module:critical_products, dbtn/hasAuth
   * @name delete_critical_product
   * @summary Delete Critical Product
   * @request DELETE:/routes/critical-products/delete/{product_id}
   */
  export namespace delete_critical_product {
    export type RequestParams = {
      /** Product Id */
      productId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = DeleteCriticalProductData;
  }

  /**
   * @description Import critical products from Excel or CSV file.
   * @tags dbtn/module:critical_products, dbtn/hasAuth
   * @name import_critical_products
   * @summary Import Critical Products
   * @request POST:/routes/critical-products/import
   */
  export namespace import_critical_products {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = BodyImportCriticalProducts;
    export type RequestHeaders = {};
    export type ResponseBody = ImportCriticalProductsData;
  }

  /**
   * @description Clear all critical products data from the database.
   * @tags dbtn/module:critical_products, dbtn/hasAuth
   * @name clear_critical_products_database
   * @summary Clear Critical Products Database
   * @request POST:/routes/critical-products/clear-database
   */
  export namespace clear_critical_products_database {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ClearCriticalProductsDatabaseData;
  }

  /**
   * @description Create a new admin notification to be sent to users. Only admins can create notifications.
   * @tags dbtn/module:admin_notifications, dbtn/hasAuth
   * @name create_admin_notification
   * @summary Create Admin Notification
   * @request POST:/routes/admin-notifications/admin/create
   */
  export namespace create_admin_notification {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = AdminNotificationCreate;
    export type RequestHeaders = {};
    export type ResponseBody = CreateAdminNotificationData;
  }

  /**
   * @description Get all admin notifications with delivery statistics. Only admins can access this endpoint.
   * @tags dbtn/module:admin_notifications, dbtn/hasAuth
   * @name get_admin_notifications
   * @summary Get Admin Notifications
   * @request GET:/routes/admin-notifications/admin/notifications
   */
  export namespace get_admin_notifications {
    export type RequestParams = {};
    export type RequestQuery = {
      /**
       * Active Only
       * @default true
       */
      active_only?: boolean;
      /** Notification Type */
      notification_type?: string | null;
      /**
       * Limit
       * @min 1
       * @max 100
       * @default 50
       */
      limit?: number;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetAdminNotificationsData;
  }

  /**
   * @description Update an existing admin notification. Only admins can update notifications.
   * @tags dbtn/module:admin_notifications, dbtn/hasAuth
   * @name update_admin_notification
   * @summary Update Admin Notification
   * @request PUT:/routes/admin-notifications/admin/notifications/{notification_id}
   */
  export namespace update_admin_notification {
    export type RequestParams = {
      /** Notification Id */
      notificationId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = AdminNotificationUpdate;
    export type RequestHeaders = {};
    export type ResponseBody = UpdateAdminNotificationData;
  }

  /**
   * @description Delete an admin notification (deactivate it). Only admins can delete notifications.
   * @tags dbtn/module:admin_notifications, dbtn/hasAuth
   * @name delete_admin_notification
   * @summary Delete Admin Notification
   * @request DELETE:/routes/admin-notifications/admin/notifications/{notification_id}
   */
  export namespace delete_admin_notification {
    export type RequestParams = {
      /** Notification Id */
      notificationId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = DeleteAdminNotificationData;
  }

  /**
   * @description Get notifications for the current user. Automatically creates user_notification_status entries for new notifications.
   * @tags dbtn/module:admin_notifications, dbtn/hasAuth
   * @name get_user_notifications
   * @summary Get User Notifications
   * @request GET:/routes/admin-notifications/user/notifications
   */
  export namespace get_user_notifications {
    export type RequestParams = {};
    export type RequestQuery = {
      /** Status */
      status?: string | null;
      /**
       * Limit
       * @min 1
       * @max 50
       * @default 20
       */
      limit?: number;
      /**
       * Offset
       * @min 0
       * @default 0
       */
      offset?: number;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetUserNotificationsData;
  }

  /**
   * @description Update the status of a notification for the current user (mark as read/dismissed).
   * @tags dbtn/module:admin_notifications, dbtn/hasAuth
   * @name update_notification_status
   * @summary Update Notification Status
   * @request PUT:/routes/admin-notifications/user/notifications/{notification_id}/status
   */
  export namespace update_notification_status {
    export type RequestParams = {
      /** Notification Id */
      notificationId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = NotificationStatusUpdate;
    export type RequestHeaders = {};
    export type ResponseBody = UpdateNotificationStatusData;
  }

  /**
   * @description Get the count of unread notifications for the current user. Used for updating the notification badge in real-time.
   * @tags dbtn/module:admin_notifications, dbtn/hasAuth
   * @name get_unread_notification_count
   * @summary Get Unread Notification Count
   * @request GET:/routes/admin-notifications/user/notifications/unread-count
   */
  export namespace get_unread_notification_count {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetUnreadNotificationCountData;
  }

  /**
   * @description Mark all unread notifications as read for the current user.
   * @tags dbtn/module:admin_notifications, dbtn/hasAuth
   * @name mark_all_notifications_read
   * @summary Mark All Notifications Read
   * @request POST:/routes/admin-notifications/user/notifications/mark-all-read
   */
  export namespace mark_all_notifications_read {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = MarkAllNotificationsReadData;
  }

  /**
   * @description Get all annotations for a document
   * @tags dbtn/module:document_collaboration, dbtn/hasAuth
   * @name get_document_annotations_collab
   * @summary Get Document Annotations Collab
   * @request GET:/routes/doc-collaboration/documents/{document_id}/annotations
   */
  export namespace get_document_annotations_collab {
    export type RequestParams = {
      /** Document Id */
      documentId: number;
    };
    export type RequestQuery = {
      /**
       * Include Private
       * @default false
       */
      include_private?: boolean;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetDocumentAnnotationsCollabData;
  }

  /**
   * @description Create a new document annotation
   * @tags dbtn/module:document_collaboration, dbtn/hasAuth
   * @name create_annotation_collab
   * @summary Create Annotation Collab
   * @request POST:/routes/doc-collaboration/annotations
   */
  export namespace create_annotation_collab {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = DocumentAnnotationInput;
    export type RequestHeaders = {};
    export type ResponseBody = CreateAnnotationCollabData;
  }

  /**
   * @description Update an existing annotation
   * @tags dbtn/module:document_collaboration, dbtn/hasAuth
   * @name update_annotation_collab
   * @summary Update Annotation Collab
   * @request PUT:/routes/doc-collaboration/annotations/{annotation_id}
   */
  export namespace update_annotation_collab {
    export type RequestParams = {
      /** Annotation Id */
      annotationId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = AnnotationUpdate;
    export type RequestHeaders = {};
    export type ResponseBody = UpdateAnnotationCollabData;
  }

  /**
   * @description Delete an annotation
   * @tags dbtn/module:document_collaboration, dbtn/hasAuth
   * @name delete_annotation_collab
   * @summary Delete Annotation Collab
   * @request DELETE:/routes/doc-collaboration/annotations/{annotation_id}
   */
  export namespace delete_annotation_collab {
    export type RequestParams = {
      /** Annotation Id */
      annotationId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = DeleteAnnotationCollabData;
  }

  /**
   * @description Mark an annotation as resolved
   * @tags dbtn/module:document_collaboration, dbtn/hasAuth
   * @name resolve_annotation_collab
   * @summary Resolve Annotation Collab
   * @request POST:/routes/doc-collaboration/annotations/{annotation_id}/resolve
   */
  export namespace resolve_annotation_collab {
    export type RequestParams = {
      /** Annotation Id */
      annotationId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ResolveAnnotationCollabData;
  }

  /**
   * @description Get user's bookmarks
   * @tags dbtn/module:document_collaboration, dbtn/hasAuth
   * @name get_user_bookmarks_collab
   * @summary Get User Bookmarks Collab
   * @request GET:/routes/doc-collaboration/bookmarks
   */
  export namespace get_user_bookmarks_collab {
    export type RequestParams = {};
    export type RequestQuery = {
      /** Document Id */
      document_id?: number | null;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetUserBookmarksCollabData;
  }

  /**
   * @description Create a new bookmark
   * @tags dbtn/module:document_collaboration, dbtn/hasAuth
   * @name create_bookmark_collab
   * @summary Create Bookmark Collab
   * @request POST:/routes/doc-collaboration/bookmarks
   */
  export namespace create_bookmark_collab {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = UserBookmarkInput;
    export type RequestHeaders = {};
    export type ResponseBody = CreateBookmarkCollabData;
  }

  /**
   * @description Delete a bookmark
   * @tags dbtn/module:document_collaboration, dbtn/hasAuth
   * @name delete_bookmark_collab
   * @summary Delete Bookmark Collab
   * @request DELETE:/routes/doc-collaboration/bookmarks/{bookmark_id}
   */
  export namespace delete_bookmark_collab {
    export type RequestParams = {
      /** Bookmark Id */
      bookmarkId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = DeleteBookmarkCollabData;
  }

  /**
   * @description Get document activity history
   * @tags dbtn/module:document_collaboration, dbtn/hasAuth
   * @name get_document_activity_collab
   * @summary Get Document Activity Collab
   * @request GET:/routes/doc-collaboration/documents/{document_id}/activity
   */
  export namespace get_document_activity_collab {
    export type RequestParams = {
      /** Document Id */
      documentId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetDocumentActivityCollabData;
  }

  /**
   * @description Track a new document activity
   * @tags dbtn/module:document_collaboration, dbtn/hasAuth
   * @name track_document_activity_collab
   * @summary Track Document Activity Collab
   * @request POST:/routes/doc-collaboration/documents/{document_id}/activity
   */
  export namespace track_document_activity_collab {
    export type RequestParams = {
      /** Document Id */
      documentId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = DocumentActivity;
    export type RequestHeaders = {};
    export type ResponseBody = TrackDocumentActivityCollabData;
  }

  /**
   * @description Get collaboration statistics
   * @tags dbtn/module:document_collaboration, dbtn/hasAuth
   * @name get_collaboration_stats_collab
   * @summary Get Collaboration Stats Collab
   * @request GET:/routes/doc-collaboration/stats
   */
  export namespace get_collaboration_stats_collab {
    export type RequestParams = {};
    export type RequestQuery = {
      /** Document Id */
      document_id?: number | null;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetCollaborationStatsCollabData;
  }

  /**
   * @description Get collaboration summary for a user
   * @tags dbtn/module:document_collaboration, dbtn/hasAuth
   * @name get_user_collaboration_summary_collab
   * @summary Get User Collaboration Summary Collab
   * @request GET:/routes/doc-collaboration/users/{user_id}/summary
   */
  export namespace get_user_collaboration_summary_collab {
    export type RequestParams = {
      /** User Id */
      userId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetUserCollaborationSummaryCollabData;
  }

  /**
   * @description List sanction entities with filtering and pagination
   * @tags dbtn/module:admin_sanctions, dbtn/hasAuth
   * @name list_sanction_entities
   * @summary List Sanction Entities
   * @request GET:/routes/admin-sanctions/entities
   */
  export namespace list_sanction_entities {
    export type RequestParams = {};
    export type RequestQuery = {
      /**
       * Page
       * @min 1
       * @default 1
       */
      page?: number;
      /**
       * Page Size
       * @min 1
       * @max 100
       * @default 20
       */
      page_size?: number;
      /** Search */
      search?: string | null;
      /** Entity Type */
      entity_type?: string | null;
      /** Jurisdiction */
      jurisdiction?: string | null;
      /** Risk Level */
      risk_level?: string | null;
      /**
       * Status
       * @default "active"
       */
      status?: string | null;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ListSanctionEntitiesData;
  }

  /**
   * @description Create a new sanction entity
   * @tags dbtn/module:admin_sanctions, dbtn/hasAuth
   * @name create_sanction_entity
   * @summary Create Sanction Entity
   * @request POST:/routes/admin-sanctions/entities
   */
  export namespace create_sanction_entity {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = SanctionEntityCreate;
    export type RequestHeaders = {};
    export type ResponseBody = CreateSanctionEntityData;
  }

  /**
   * @description Get a specific sanction entity
   * @tags dbtn/module:admin_sanctions, dbtn/hasAuth
   * @name get_admin_sanction_entity
   * @summary Get Admin Sanction Entity
   * @request GET:/routes/admin-sanctions/entities/{entity_id}
   */
  export namespace get_admin_sanction_entity {
    export type RequestParams = {
      /** Entity Id */
      entityId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetAdminSanctionEntityData;
  }

  /**
   * @description Update a sanction entity
   * @tags dbtn/module:admin_sanctions, dbtn/hasAuth
   * @name update_sanction_entity
   * @summary Update Sanction Entity
   * @request PUT:/routes/admin-sanctions/entities/{entity_id}
   */
  export namespace update_sanction_entity {
    export type RequestParams = {
      /** Entity Id */
      entityId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = SanctionEntityUpdate;
    export type RequestHeaders = {};
    export type ResponseBody = UpdateSanctionEntityData;
  }

  /**
   * @description Delete or deactivate a sanction entity
   * @tags dbtn/module:admin_sanctions, dbtn/hasAuth
   * @name delete_sanction_entity
   * @summary Delete Sanction Entity
   * @request DELETE:/routes/admin-sanctions/entities/{entity_id}
   */
  export namespace delete_sanction_entity {
    export type RequestParams = {
      /** Entity Id */
      entityId: string;
    };
    export type RequestQuery = {
      /**
       * Hard Delete
       * Permanently delete instead of marking inactive
       * @default false
       */
      hard_delete?: boolean;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = DeleteSanctionEntityData;
  }

  /**
   * @description Bulk import sanctions from CSV file
   * @tags dbtn/module:admin_sanctions, dbtn/hasAuth
   * @name bulk_import_sanctions
   * @summary Bulk Import Sanctions
   * @request POST:/routes/admin-sanctions/bulk-import
   */
  export namespace bulk_import_sanctions {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = BodyBulkImportSanctions;
    export type RequestHeaders = {};
    export type ResponseBody = BulkImportSanctionsData;
  }

  /**
   * @description Export sanctions data
   * @tags stream, dbtn/module:admin_sanctions, dbtn/hasAuth
   * @name export_sanctions
   * @summary Export Sanctions
   * @request GET:/routes/admin-sanctions/export
   */
  export namespace export_sanctions {
    export type RequestParams = {};
    export type RequestQuery = {
      /**
       * Format
       * Export format: csv or json
       * @default "csv"
       */
      format?: string;
      /** Jurisdiction */
      jurisdiction?: string | null;
      /**
       * Status
       * @default "active"
       */
      status?: string | null;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ExportSanctionsData;
  }

  /**
   * @description Get statistics about sanction sources
   * @tags dbtn/module:admin_sanctions, dbtn/hasAuth
   * @name get_sanction_sources
   * @summary Get Sanction Sources
   * @request GET:/routes/admin-sanctions/sources
   */
  export namespace get_sanction_sources {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetSanctionSourcesData;
  }

  /**
   * @description Get sanctions audit trail
   * @tags dbtn/module:admin_sanctions, dbtn/hasAuth
   * @name get_sanctions_audit_log
   * @summary Get Sanctions Audit Log
   * @request GET:/routes/admin-sanctions/audit-log
   */
  export namespace get_sanctions_audit_log {
    export type RequestParams = {};
    export type RequestQuery = {
      /** Entity Id */
      entity_id?: string | null;
      /** Action */
      action?: string | null;
      /**
       * Limit
       * @max 200
       * @default 50
       */
      limit?: number;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetSanctionsAuditLogData;
  }

  /**
   * @description Set up auto-recharge configuration for the user
   * @tags dbtn/module:automated_billing, dbtn/hasAuth
   * @name setup_auto_recharge
   * @summary Setup Auto Recharge
   * @request POST:/routes/auto-billing/auto-recharge/setup
   */
  export namespace setup_auto_recharge {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = AutoRechargeConfigRequest;
    export type RequestHeaders = {};
    export type ResponseBody = SetupAutoRechargeData;
  }

  /**
   * @description Get user's auto-recharge configuration
   * @tags dbtn/module:automated_billing, dbtn/hasAuth
   * @name get_auto_recharge_config
   * @summary Get Auto Recharge Config
   * @request GET:/routes/auto-billing/auto-recharge/config
   */
  export namespace get_auto_recharge_config {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetAutoRechargeConfigData;
  }

  /**
   * @description Enable or disable auto-recharge
   * @tags dbtn/module:automated_billing, dbtn/hasAuth
   * @name toggle_auto_recharge
   * @summary Toggle Auto Recharge
   * @request PATCH:/routes/auto-billing/auto-recharge/toggle
   */
  export namespace toggle_auto_recharge {
    export type RequestParams = {};
    export type RequestQuery = {
      /**
       * Enabled
       * @default true
       */
      enabled?: boolean;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ToggleAutoRechargeData;
  }

  /**
   * @description Manually trigger an auto-recharge (for testing or immediate need)
   * @tags dbtn/module:automated_billing, dbtn/hasAuth
   * @name manual_trigger_recharge
   * @summary Manual Trigger Recharge
   * @request POST:/routes/auto-billing/auto-recharge/trigger
   */
  export namespace manual_trigger_recharge {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ManualTriggerRechargeData;
  }

  /**
   * @description Get user's auto-recharge transaction history
   * @tags dbtn/module:automated_billing, dbtn/hasAuth
   * @name get_auto_recharge_history
   * @summary Get Auto Recharge History
   * @request GET:/routes/auto-billing/auto-recharge/history
   */
  export namespace get_auto_recharge_history {
    export type RequestParams = {};
    export type RequestQuery = {
      /**
       * Limit
       * @default 50
       */
      limit?: number;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetAutoRechargeHistoryData;
  }

  /**
   * @description Add or update payment method for the user
   * @tags dbtn/module:automated_billing, dbtn/hasAuth
   * @name add_payment_method
   * @summary Add Payment Method
   * @request POST:/routes/auto-billing/payment-methods/add
   */
  export namespace add_payment_method {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = PaymentMethodRequest;
    export type RequestHeaders = {};
    export type ResponseBody = AddPaymentMethodData;
  }

  /**
   * @description Get user's saved payment methods
   * @tags dbtn/module:automated_billing, dbtn/hasAuth
   * @name get_payment_methods
   * @summary Get Payment Methods
   * @request GET:/routes/auto-billing/payment-methods
   */
  export namespace get_payment_methods {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetPaymentMethodsData;
  }

  /**
   * @description Generate an enterprise invoice for bulk credit purchase
   * @tags dbtn/module:automated_billing, dbtn/hasAuth
   * @name generate_enterprise_invoice
   * @summary Generate Enterprise Invoice
   * @request POST:/routes/auto-billing/enterprise/generate-invoice
   */
  export namespace generate_enterprise_invoice {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = EnterpriseInvoiceRequest;
    export type RequestHeaders = {};
    export type ResponseBody = GenerateEnterpriseInvoiceData;
  }

  /**
   * @description Get user's enterprise invoices
   * @tags dbtn/module:automated_billing, dbtn/hasAuth
   * @name get_enterprise_invoices
   * @summary Get Enterprise Invoices
   * @request GET:/routes/auto-billing/enterprise/invoices
   */
  export namespace get_enterprise_invoices {
    export type RequestParams = {};
    export type RequestQuery = {
      /** Status */
      status?: string | null;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetEnterpriseInvoicesData;
  }

  /**
   * @description Get user's payment failures that need attention
   * @tags dbtn/module:automated_billing, dbtn/hasAuth
   * @name get_payment_failures
   * @summary Get Payment Failures
   * @request GET:/routes/auto-billing/payment-failures
   */
  export namespace get_payment_failures {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetPaymentFailuresData;
  }

  /**
   * @description Retry a failed payment
   * @tags dbtn/module:automated_billing, dbtn/hasAuth
   * @name retry_failed_payment
   * @summary Retry Failed Payment
   * @request POST:/routes/auto-billing/payment-failures/{failure_id}/retry
   */
  export namespace retry_failed_payment {
    export type RequestParams = {
      /** Failure Id */
      failureId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = RetryFailedPaymentData;
  }

  /**
   * @description List all automated feed sources
   * @tags dbtn/module:automation, dbtn/hasAuth
   * @name list_feed_sources
   * @summary List Feed Sources
   * @request GET:/routes/automation/feed-sources
   */
  export namespace list_feed_sources {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ListFeedSourcesData;
  }

  /**
   * @description Create a new automated feed source
   * @tags dbtn/module:automation, dbtn/hasAuth
   * @name create_feed_source
   * @summary Create Feed Source
   * @request POST:/routes/automation/feed-sources
   */
  export namespace create_feed_source {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = AutomatedFeedSource;
    export type RequestHeaders = {};
    export type ResponseBody = CreateFeedSourceData;
  }

  /**
   * @description Manually trigger a feed update
   * @tags dbtn/module:automation, dbtn/hasAuth
   * @name trigger_feed_update
   * @summary Trigger Feed Update
   * @request POST:/routes/automation/feed-sources/{feed_id}/trigger
   */
  export namespace trigger_feed_update {
    export type RequestParams = {
      /** Feed Id */
      feedId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = TriggerFeedUpdateData;
  }

  /**
   * @description List all webhook endpoints
   * @tags dbtn/module:automation, dbtn/hasAuth
   * @name list_webhooks
   * @summary List Webhooks
   * @request GET:/routes/automation/webhooks
   */
  export namespace list_webhooks {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ListWebhooksData;
  }

  /**
   * @description Create a new webhook endpoint
   * @tags dbtn/module:automation, dbtn/hasAuth
   * @name create_webhook
   * @summary Create Webhook
   * @request POST:/routes/automation/webhooks
   */
  export namespace create_webhook {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = WebhookEndpoint;
    export type RequestHeaders = {};
    export type ResponseBody = CreateWebhookData;
  }

  /**
   * @description Get comprehensive automation analytics
   * @tags dbtn/module:automation, dbtn/hasAuth
   * @name get_automation_analytics
   * @summary Get Automation Analytics
   * @request GET:/routes/automation/automation-analytics
   */
  export namespace get_automation_analytics {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetAutomationAnalyticsData;
  }

  /**
   * @description Search documents that can be referenced
   * @tags dbtn/module:document_references, dbtn/hasAuth
   * @name search_documents_for_reference
   * @summary Search Documents For Reference
   * @request GET:/routes/doc-references/search
   */
  export namespace search_documents_for_reference {
    export type RequestParams = {};
    export type RequestQuery = {
      /**
       * Q
       * Search term
       */
      q: string;
      /**
       * Limit
       * Maximum number of results
       * @default 10
       */
      limit?: number;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = SearchDocumentsForReferenceData;
  }

  /**
   * @description Resolve document reference IDs to actual document data
   * @tags dbtn/module:document_references, dbtn/hasAuth
   * @name resolve_document_references
   * @summary Resolve Document References
   * @request POST:/routes/doc-references/resolve
   */
  export namespace resolve_document_references {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = ResolveDocumentReferencesPayload;
    export type RequestHeaders = {};
    export type ResponseBody = ResolveDocumentReferencesData;
  }

  /**
   * @description Extract document references from text content
   * @tags dbtn/module:document_references, dbtn/hasAuth
   * @name extract_references_from_text_endpoint
   * @summary Extract References From Text Endpoint
   * @request GET:/routes/doc-references/extract-from-text
   */
  export namespace extract_references_from_text_endpoint {
    export type RequestParams = {};
    export type RequestQuery = {
      /**
       * Text
       * Text content to extract references from
       */
      text: string;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ExtractReferencesFromTextEndpointData;
  }

  /**
   * @description Get the reference ID for a specific document
   * @tags dbtn/module:document_references, dbtn/hasAuth
   * @name get_document_reference_id
   * @summary Get Document Reference Id
   * @request GET:/routes/doc-references/document/{document_id}/reference-id
   */
  export namespace get_document_reference_id {
    export type RequestParams = {
      /** Document Id */
      documentId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetDocumentReferenceIdData;
  }

  /**
   * @description Search country restrictions and embargoes for compliance checks
   * @tags dbtn/module:country_restrictions, dbtn/hasAuth
   * @name search_countries
   * @summary Search Countries
   * @request POST:/routes/country-restrictions/countries/search
   */
  export namespace search_countries {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = CountrySearchRequest;
    export type RequestHeaders = {};
    export type ResponseBody = SearchCountriesData;
  }

  /**
   * @description Get detailed restriction information for a specific country
   * @tags dbtn/module:country_restrictions, dbtn/hasAuth
   * @name get_country_restriction
   * @summary Get Country Restriction
   * @request GET:/routes/country-restrictions/country/{country_id}
   */
  export namespace get_country_restriction {
    export type RequestParams = {
      /** Country Id */
      countryId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetCountryRestrictionData;
  }

  /**
   * @description Get list of available restriction types
   * @tags dbtn/module:country_restrictions, dbtn/hasAuth
   * @name get_restriction_types
   * @summary Get Restriction Types
   * @request GET:/routes/country-restrictions/restriction-types
   */
  export namespace get_restriction_types {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetRestrictionTypesData;
  }

  /**
   * @description Get list of issuing authorities
   * @tags dbtn/module:country_restrictions, dbtn/hasAuth
   * @name get_issuing_authorities
   * @summary Get Issuing Authorities
   * @request GET:/routes/country-restrictions/authorities
   */
  export namespace get_issuing_authorities {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetIssuingAuthoritiesData;
  }

  /**
   * @description Get list of geographic regions
   * @tags dbtn/module:country_restrictions, dbtn/hasAuth
   * @name get_geographic_regions
   * @summary Get Geographic Regions
   * @request GET:/routes/country-restrictions/regions
   */
  export namespace get_geographic_regions {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetGeographicRegionsData;
  }

  /**
   * @description Get list of available risk levels for countries
   * @tags dbtn/module:country_restrictions, dbtn/hasAuth
   * @name get_country_risk_levels
   * @summary Get Country Risk Levels
   * @request GET:/routes/country-restrictions/risk-levels
   */
  export namespace get_country_risk_levels {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetCountryRiskLevelsData;
  }

  /**
   * @description Upload and process a document with OCR and text extraction
   * @tags dbtn/module:document_processing, dbtn/hasAuth
   * @name process_document
   * @summary Process Document
   * @request POST:/routes/doc-processing/process-document
   */
  export namespace process_document {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = BodyProcessDocument;
    export type RequestHeaders = {};
    export type ResponseBody = ProcessDocumentData;
  }

  /**
   * @description Get the processing status for a document
   * @tags dbtn/module:document_processing, dbtn/hasAuth
   * @name get_processing_status
   * @summary Get Processing Status
   * @request GET:/routes/doc-processing/processing-status/{processing_id}
   */
  export namespace get_processing_status {
    export type RequestParams = {
      /** Processing Id */
      processingId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetProcessingStatusData;
  }

  /**
   * @description Get hierarchical sections from a processed document
   * @tags dbtn/module:document_processing, dbtn/hasAuth
   * @name get_processed_document_sections
   * @summary Get Processed Document Sections
   * @request GET:/routes/doc-processing/document/{document_id}/sections
   */
  export namespace get_processed_document_sections {
    export type RequestParams = {
      /** Document Id */
      documentId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetProcessedDocumentSectionsData;
  }

  /**
   * @description Get cross-references extracted from a document
   * @tags dbtn/module:document_processing, dbtn/hasAuth
   * @name get_document_cross_references_processing
   * @summary Get Document Cross References Processing
   * @request GET:/routes/doc-processing/document/{document_id}/cross-references
   */
  export namespace get_document_cross_references_processing {
    export type RequestParams = {
      /** Document Id */
      documentId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetDocumentCrossReferencesProcessingData;
  }

  /**
   * @description Process multiple documents in batch
   * @tags dbtn/module:document_processing, dbtn/hasAuth
   * @name batch_process_documents
   * @summary Batch Process Documents
   * @request POST:/routes/doc-processing/batch-process
   */
  export namespace batch_process_documents {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = BatchProcessRequest;
    export type RequestHeaders = {};
    export type ResponseBody = BatchProcessDocumentsData;
  }

  /**
   * @description Get list of supported document formats for processing
   * @tags dbtn/module:document_processing, dbtn/hasAuth
   * @name get_supported_formats
   * @summary Get Supported Formats
   * @request GET:/routes/doc-processing/supported-formats
   */
  export namespace get_supported_formats {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetSupportedFormatsData;
  }

  /**
   * @description Clean up old processing status records
   * @tags dbtn/module:document_processing, dbtn/hasAuth
   * @name cleanup_processing_history
   * @summary Cleanup Processing History
   * @request DELETE:/routes/doc-processing/cleanup-processing-history
   */
  export namespace cleanup_processing_history {
    export type RequestParams = {};
    export type RequestQuery = {
      /**
       * Hours Old
       * @default 24
       */
      hours_old?: number;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = CleanupProcessingHistoryData;
  }

  /**
   * @description Initialize default content for modules (admin only)
   * @tags dbtn/module:content_management, dbtn/hasAuth
   * @name initialize_default_content
   * @summary Initialize Default Content
   * @request POST:/routes/content-management/initialize-defaults
   */
  export namespace initialize_default_content {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = InitializeDefaultContentData;
  }

  /**
   * @description Get all content items for a specific module
   * @tags dbtn/module:content_management, dbtn/hasAuth
   * @name get_content_by_module
   * @summary Get Content By Module
   * @request GET:/routes/content-management/content/{module_name}
   */
  export namespace get_content_by_module {
    export type RequestParams = {
      /** Module Name */
      moduleName: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetContentByModuleData;
  }

  /**
   * @description Create a new content item
   * @tags dbtn/module:content_management, dbtn/hasAuth
   * @name create_content_item
   * @summary Create Content Item
   * @request POST:/routes/content-management/content
   */
  export namespace create_content_item {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = CreateContentRequest;
    export type RequestHeaders = {};
    export type ResponseBody = CreateContentItemData;
  }

  /**
   * @description Update an existing content item
   * @tags dbtn/module:content_management, dbtn/hasAuth
   * @name update_content_item
   * @summary Update Content Item
   * @request PUT:/routes/content-management/content/{content_id}
   */
  export namespace update_content_item {
    export type RequestParams = {
      /** Content Id */
      contentId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = UpdateContentRequest;
    export type RequestHeaders = {};
    export type ResponseBody = UpdateContentItemData;
  }

  /**
   * @description Delete a content item
   * @tags dbtn/module:content_management, dbtn/hasAuth
   * @name delete_content_item
   * @summary Delete Content Item
   * @request DELETE:/routes/content-management/content/{content_id}
   */
  export namespace delete_content_item {
    export type RequestParams = {
      /** Content Id */
      contentId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = DeleteContentItemData;
  }

  /**
   * @description Get a specific content item by ID
   * @tags dbtn/module:content_management, dbtn/hasAuth
   * @name get_content_item
   * @summary Get Content Item
   * @request GET:/routes/content-management/content-item/{content_id}
   */
  export namespace get_content_item {
    export type RequestParams = {
      /** Content Id */
      contentId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetContentItemData;
  }

  /**
   * @description Activate free tier credits for new users automatically
   * @tags dbtn/module:credit_management, dbtn/hasAuth
   * @name activate_free_tier
   * @summary Activate Free Tier
   * @request POST:/routes/credit-management/credits/activate-free-tier
   */
  export namespace activate_free_tier {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ActivateFreeTierData;
  }

  /**
   * @description Check if user has claimed free tier credits and eligibility
   * @tags dbtn/module:credit_management, dbtn/hasAuth
   * @name get_free_tier_status
   * @summary Get Free Tier Status
   * @request GET:/routes/credit-management/credits/free-tier-status
   */
  export namespace get_free_tier_status {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetFreeTierStatusData;
  }

  /**
   * @description Get current user's credit balance
   * @tags dbtn/module:credit_management, dbtn/hasAuth
   * @name get_credit_balance
   * @summary Get Credit Balance
   * @request GET:/routes/credit-management/credits/balance
   */
  export namespace get_credit_balance {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetCreditBalanceData;
  }

  /**
   * @description Get user's credit transaction history
   * @tags dbtn/module:credit_management, dbtn/hasAuth
   * @name get_credit_transactions
   * @summary Get Credit Transactions
   * @request GET:/routes/credit-management/credits/transactions
   */
  export namespace get_credit_transactions {
    export type RequestParams = {};
    export type RequestQuery = {
      /**
       * Limit
       * @default 50
       */
      limit?: number;
      /**
       * Offset
       * @default 0
       */
      offset?: number;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetCreditTransactionsData;
  }

  /**
   * @description Get available credit packages for purchase
   * @tags dbtn/module:credit_management, dbtn/hasAuth
   * @name get_credit_packages
   * @summary Get Credit Packages
   * @request GET:/routes/credit-management/credits/packages
   */
  export namespace get_credit_packages {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetCreditPackagesData;
  }

  /**
   * @description Reserve credits for an action (check availability without consuming)
   * @tags dbtn/module:credit_management, dbtn/hasAuth
   * @name reserve_credits
   * @summary Reserve Credits
   * @request POST:/routes/credit-management/credits/reserve
   */
  export namespace reserve_credits {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = ReserveCreditsRequest;
    export type RequestHeaders = {};
    export type ResponseBody = ReserveCreditsData;
  }

  /**
   * @description Consume credits for an action
   * @tags dbtn/module:credit_management, dbtn/hasAuth
   * @name consume_credits
   * @summary Consume Credits
   * @request POST:/routes/credit-management/credits/consume
   */
  export namespace consume_credits {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = ConsumeCreditsRequest;
    export type RequestHeaders = {};
    export type ResponseBody = ConsumeCreditsData;
  }

  /**
   * @description Admin function to manually adjust user credits
   * @tags dbtn/module:credit_management, dbtn/hasAuth
   * @name admin_adjust_credits
   * @summary Admin Adjust Credits
   * @request POST:/routes/credit-management/admin/credits/adjust
   */
  export namespace admin_adjust_credits {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = AdminCreditAdjustment;
    export type RequestHeaders = {};
    export type ResponseBody = AdminAdjustCreditsData;
  }

  /**
   * @description Get all credit packages including inactive ones (admin only)
   * @tags dbtn/module:credit_management, dbtn/hasAuth
   * @name get_all_credit_packages
   * @summary Get All Credit Packages
   * @request GET:/routes/credit-management/admin/credits/packages
   */
  export namespace get_all_credit_packages {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetAllCreditPackagesData;
  }

  /**
   * @description Create a new credit package (admin only)
   * @tags dbtn/module:credit_management, dbtn/hasAuth
   * @name create_credit_package
   * @summary Create Credit Package
   * @request POST:/routes/credit-management/admin/credits/packages
   */
  export namespace create_credit_package {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = CreateCreditPackageRequest;
    export type RequestHeaders = {};
    export type ResponseBody = CreateCreditPackageData;
  }

  /**
   * @description Update an existing credit package (admin only)
   * @tags dbtn/module:credit_management, dbtn/hasAuth
   * @name update_credit_package
   * @summary Update Credit Package
   * @request PUT:/routes/credit-management/admin/credits/packages/{package_id}
   */
  export namespace update_credit_package {
    export type RequestParams = {
      /** Package Id */
      packageId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = UpdateCreditPackageRequest;
    export type RequestHeaders = {};
    export type ResponseBody = UpdateCreditPackageData;
  }

  /**
   * @description Delete a credit package (admin only)
   * @tags dbtn/module:credit_management, dbtn/hasAuth
   * @name delete_credit_package
   * @summary Delete Credit Package
   * @request DELETE:/routes/credit-management/admin/credits/packages/{package_id}
   */
  export namespace delete_credit_package {
    export type RequestParams = {
      /** Package Id */
      packageId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = DeleteCreditPackageData;
  }

  /**
   * @description Get the base EUR price per credit (admin only)
   * @tags dbtn/module:credit_management, dbtn/hasAuth
   * @name get_base_credit_price
   * @summary Get Base Credit Price
   * @request GET:/routes/credit-management/admin/credits/base-price
   */
  export namespace get_base_credit_price {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetBaseCreditPriceData;
  }

  /**
   * @description Update the base EUR price per credit (admin only)
   * @tags dbtn/module:credit_management, dbtn/hasAuth
   * @name update_base_credit_price
   * @summary Update Base Credit Price
   * @request PUT:/routes/credit-management/admin/credits/base-price
   */
  export namespace update_base_credit_price {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = BaseCreditPriceRequest;
    export type RequestHeaders = {};
    export type ResponseBody = UpdateBaseCreditPriceData;
  }

  /**
   * @description Export all regulatory notes to Excel format If tree_id is 'global', export all global notes (tree_id = NULL) Otherwise export notes for specific tree
   * @tags dbtn/module:excel_export, dbtn/hasAuth
   * @name export_notes_to_excel
   * @summary Export Notes To Excel
   * @request GET:/routes/excel-export/export-notes/{tree_id}
   */
  export namespace export_notes_to_excel {
    export type RequestParams = {
      /** Tree Id */
      treeId: string;
    };
    export type RequestQuery = {
      /**
       * Module Type
       * @default "product_classification"
       */
      module_type?: string;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ExportNotesToExcelData;
  }

  /**
   * @description Import regulatory notes from Excel file content
   * @tags dbtn/module:excel_export, dbtn/hasAuth
   * @name import_notes_from_excel
   * @summary Import Notes From Excel
   * @request POST:/routes/excel-export/import-notes/{tree_id}
   */
  export namespace import_notes_from_excel {
    export type RequestParams = {
      /** Tree Id */
      treeId: string;
    };
    export type RequestQuery = {
      /**
       * Module Type
       * @default "product_classification"
       */
      module_type?: string;
    };
    export type RequestBody = BodyImportNotesFromExcel;
    export type RequestHeaders = {};
    export type ResponseBody = ImportNotesFromExcelData;
  }

  /**
   * @description Get user's module access status and subscription information
   * @tags dbtn/module:payment_system, dbtn/hasAuth
   * @name get_user_access_status
   * @summary Get User Access Status
   * @request GET:/routes/user-access-status
   */
  export namespace get_user_access_status {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetUserAccessStatusData;
  }

  /**
   * @description Calculate VAT preview for a module purchase without creating payment intent
   * @tags dbtn/module:payment_system, dbtn/hasAuth
   * @name get_vat_preview
   * @summary Get Vat Preview
   * @request POST:/routes/vat-preview
   */
  export namespace get_vat_preview {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = VATPreviewRequest;
    export type RequestHeaders = {};
    export type ResponseBody = GetVatPreviewData;
  }

  /**
   * @description Create a Stripe payment intent for module access
   * @tags dbtn/module:payment_system, dbtn/hasAuth
   * @name create_payment_intent
   * @summary Create Payment Intent
   * @request POST:/routes/create-payment-intent
   */
  export namespace create_payment_intent {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = PaymentIntent;
    export type RequestHeaders = {};
    export type ResponseBody = CreatePaymentIntentData;
  }

  /**
   * @description Request an invoice for bank transfer payment (supports custom credit amounts)
   * @tags dbtn/module:payment_system, dbtn/hasAuth
   * @name request_invoice
   * @summary Request Invoice
   * @request POST:/routes/request-invoice
   */
  export namespace request_invoice {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = InvoiceRequest;
    export type RequestHeaders = {};
    export type ResponseBody = RequestInvoiceData;
  }

  /**
   * @description Select a template after successful payment
   * @tags dbtn/module:payment_system, dbtn/hasAuth
   * @name select_template
   * @summary Select Template
   * @request POST:/routes/select-template
   */
  export namespace select_template {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = TemplateSelectionRequest;
    export type RequestHeaders = {};
    export type ResponseBody = SelectTemplateData;
  }

  /**
   * @description Complete template selection after successful payment verification
   * @tags dbtn/module:payment_system, dbtn/hasAuth
   * @name complete_template_selection
   * @summary Complete Template Selection
   * @request POST:/routes/complete-template-selection
   */
  export namespace complete_template_selection {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = TemplateSelectionRequest;
    export type RequestHeaders = {};
    export type ResponseBody = CompleteTemplateSelectionData;
  }

  /**
   * @description Handle Stripe webhook events for payment confirmations
   * @tags dbtn/module:payment_system, dbtn/hasAuth
   * @name stripe_webhook
   * @summary Stripe Webhook
   * @request PATCH:/routes/webhook/stripe
   */
  export namespace stripe_webhook {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = StripeWebhookData;
  }

  /**
   * @description Get all customer details for admin dashboard
   * @tags dbtn/module:payment_system, dbtn/hasAuth
   * @name get_admin_customers
   * @summary Get Admin Customers
   * @request GET:/routes/admin/customers
   */
  export namespace get_admin_customers {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetAdminCustomersData;
  }

  /**
   * @description Get comprehensive list of all users for admin dashboard Includes both users with customer details and registered users without billing info
   * @tags dbtn/module:payment_system, dbtn/hasAuth
   * @name get_all_admin_users
   * @summary Get All Admin Users
   * @request GET:/routes/admin/all-users
   */
  export namespace get_all_admin_users {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetAllAdminUsersData;
  }

  /**
   * @description Get chat messages, optionally filtered by thread
   * @tags dbtn/module:community_chat, dbtn/hasAuth
   * @name get_chat_messages
   * @summary Get Chat Messages
   * @request GET:/routes/community-chat/messages
   */
  export namespace get_chat_messages {
    export type RequestParams = {};
    export type RequestQuery = {
      /** Thread Id */
      thread_id?: string;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetChatMessagesData;
  }

  /**
   * @description Send a new chat message
   * @tags dbtn/module:community_chat, dbtn/hasAuth
   * @name send_message
   * @summary Send Message
   * @request POST:/routes/community-chat/send-message
   */
  export namespace send_message {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = SendMessageRequest;
    export type RequestHeaders = {};
    export type ResponseBody = SendMessageData;
  }

  /**
   * @description Get all chat threads
   * @tags dbtn/module:community_chat, dbtn/hasAuth
   * @name get_chat_threads
   * @summary Get Chat Threads
   * @request GET:/routes/community-chat/threads
   */
  export namespace get_chat_threads {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetChatThreadsData;
  }

  /**
   * @description Create a new chat thread
   * @tags dbtn/module:community_chat, dbtn/hasAuth
   * @name create_chat_thread
   * @summary Create Chat Thread
   * @request POST:/routes/community-chat/threads
   */
  export namespace create_chat_thread {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = CreateThreadRequest;
    export type RequestHeaders = {};
    export type ResponseBody = CreateChatThreadData;
  }

  /**
   * @description Add or remove a reaction to a message
   * @tags dbtn/module:community_chat, dbtn/hasAuth
   * @name react_to_message
   * @summary React To Message
   * @request POST:/routes/community-chat/messages/{message_id}/react
   */
  export namespace react_to_message {
    export type RequestParams = {
      /** Message Id */
      messageId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = ReactionRequest;
    export type RequestHeaders = {};
    export type ResponseBody = ReactToMessageData;
  }

  /**
   * @description Delete a chat message (admin only or message author)
   * @tags dbtn/module:community_chat, dbtn/hasAuth
   * @name delete_message
   * @summary Delete Message
   * @request DELETE:/routes/community-chat/messages/{message_id}
   */
  export namespace delete_message {
    export type RequestParams = {
      /** Message Id */
      messageId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = DeleteMessageData;
  }

  /**
   * @description Block a user from chat (admin only)
   * @tags dbtn/module:community_chat, dbtn/hasAuth
   * @name block_user
   * @summary Block User
   * @request POST:/routes/community-chat/admin/block-user
   */
  export namespace block_user {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = BlockUserRequest;
    export type RequestHeaders = {};
    export type ResponseBody = BlockUserData;
  }

  /**
   * @description Delete chat content (admin only)
   * @tags dbtn/module:community_chat, dbtn/hasAuth
   * @name delete_chat
   * @summary Delete Chat
   * @request POST:/routes/community-chat/admin/delete-chat
   */
  export namespace delete_chat {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = DeleteChatRequest;
    export type RequestHeaders = {};
    export type ResponseBody = DeleteChatData;
  }

  /**
   * @description Get the chat community guidelines and policy
   * @tags dbtn/module:community_chat, dbtn/hasAuth
   * @name get_chat_policy
   * @summary Get Chat Policy
   * @request GET:/routes/community-chat/chat-policy
   */
  export namespace get_chat_policy {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetChatPolicyData;
  }

  /**
   * @description Check if a user is blocked (admin only)
   * @tags dbtn/module:community_chat, dbtn/hasAuth
   * @name check_user_blocked
   * @summary Check User Blocked
   * @request GET:/routes/community-chat/admin/check-user-blocked
   */
  export namespace check_user_blocked {
    export type RequestParams = {};
    export type RequestQuery = {
      /** User Id */
      user_id: string;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = CheckUserBlockedData;
  }

  /**
   * @description Upload a document for attachment to blog articles
   * @tags dbtn/module:document_upload, dbtn/hasAuth
   * @name upload_document_attachment
   * @summary Upload Document Attachment
   * @request POST:/routes/upload-document
   */
  export namespace upload_document_attachment {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = BodyUploadDocumentAttachment;
    export type RequestHeaders = {};
    export type ResponseBody = UploadDocumentAttachmentData;
  }

  /**
   * @description Serve uploaded documents
   * @tags dbtn/module:document_upload, dbtn/hasAuth
   * @name serve_document
   * @summary Serve Document
   * @request GET:/routes/documents/{document_filename}
   */
  export namespace serve_document {
    export type RequestParams = {
      /** Document Filename */
      documentFilename: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ServeDocumentData;
  }

  /**
   * @description Delete an uploaded document
   * @tags dbtn/module:document_upload, dbtn/hasAuth
   * @name delete_attachment_document
   * @summary Delete Attachment Document
   * @request DELETE:/routes/documents/{document_filename}
   */
  export namespace delete_attachment_document {
    export type RequestParams = {
      /** Document Filename */
      documentFilename: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = DeleteAttachmentDocumentData;
  }

  /**
   * @description List all uploaded documents
   * @tags dbtn/module:document_upload, dbtn/hasAuth
   * @name list_attachment_documents
   * @summary List Attachment Documents
   * @request GET:/routes/list-documents
   */
  export namespace list_attachment_documents {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ListAttachmentDocumentsData;
  }

  /**
   * @description Get all countries for Knowledge Base browsing
   * @tags dbtn/module:kb_data, dbtn/hasAuth
   * @name list_countries
   * @summary List Countries
   * @request GET:/routes/kb-data/countries
   */
  export namespace list_countries {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ListCountriesData;
  }

  /**
   * @description Get all sanctions for Knowledge Base browsing
   * @tags dbtn/module:kb_data, dbtn/hasAuth
   * @name list_sanctions
   * @summary List Sanctions
   * @request GET:/routes/kb-data/sanctions
   */
  export namespace list_sanctions {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ListSanctionsData;
  }

  /**
   * @description Get sections for a specific document with credit enforcement
   * @tags dbtn/module:kb_data, dbtn/hasAuth
   * @name get_document_sections
   * @summary Get Document Sections
   * @request GET:/routes/kb-data/documents/{document_id}/sections
   */
  export namespace get_document_sections {
    export type RequestParams = {
      /** Document Id */
      documentId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetDocumentSectionsData;
  }

  /**
   * @description Serve uploaded images publicly (no authentication required)
   * @tags dbtn/module:public_images, dbtn/hasAuth
   * @name serve_public_image
   * @summary Serve Public Image
   * @request GET:/routes/serve/{image_filename}
   */
  export namespace serve_public_image {
    export type RequestParams = {
      /** Image Filename */
      imageFilename: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ServePublicImageData;
  }

  /**
   * @description Serve uploaded images as static files (completely public)
   * @tags dbtn/module:static_serve, dbtn/hasAuth
   * @name serve_static_image
   * @summary Serve Static Image
   * @request GET:/routes/static/{image_filename}
   */
  export namespace serve_static_image {
    export type RequestParams = {
      /** Image Filename */
      imageFilename: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ServeStaticImageData;
  }

  /**
   * @description Upload an image for use in documents
   * @tags dbtn/module:image_upload, dbtn/hasAuth
   * @name upload_image
   * @summary Upload Image
   * @request POST:/routes/upload-image
   */
  export namespace upload_image {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = BodyUploadImage;
    export type RequestHeaders = {};
    export type ResponseBody = UploadImageData;
  }

  /**
   * @description Serve uploaded images
   * @tags dbtn/module:image_upload, dbtn/hasAuth
   * @name serve_image
   * @summary Serve Image
   * @request GET:/routes/images/{image_filename}
   */
  export namespace serve_image {
    export type RequestParams = {
      /** Image Filename */
      imageFilename: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ServeImageData;
  }

  /**
   * @description Delete an uploaded image
   * @tags dbtn/module:image_upload, dbtn/hasAuth
   * @name delete_image
   * @summary Delete Image
   * @request DELETE:/routes/images/{image_filename}
   */
  export namespace delete_image {
    export type RequestParams = {
      /** Image Filename */
      imageFilename: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = DeleteImageData;
  }

  /**
   * @description Serve uploaded images publicly (alternative endpoint without auth requirement)
   * @tags dbtn/module:image_upload, dbtn/hasAuth
   * @name serve_public_image_alt
   * @summary Serve Public Image Alt
   * @request GET:/routes/public-serve/{image_filename}
   */
  export namespace serve_public_image_alt {
    export type RequestParams = {
      /** Image Filename */
      imageFilename: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ServePublicImageAltData;
  }

  /**
   * @description List all uploaded images
   * @tags dbtn/module:image_upload, dbtn/hasAuth
   * @name list_images
   * @summary List Images
   * @request GET:/routes/list-images
   */
  export namespace list_images {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ListImagesData;
  }

  /**
   * @description Health check endpoint
   * @tags dbtn/module:knowledge_base, dbtn/hasAuth
   * @name knowledge_base_health
   * @summary Knowledge Base Health
   * @request GET:/routes/knowledge-base/health
   */
  export namespace knowledge_base_health {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = KnowledgeBaseHealthData;
  }

  /**
   * @description Upload a new document to the knowledge base
   * @tags dbtn/module:knowledge_base, dbtn/hasAuth
   * @name upload_document
   * @summary Upload Document
   * @request POST:/routes/knowledge-base/documents
   */
  export namespace upload_document {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = BodyUploadDocument;
    export type RequestHeaders = {};
    export type ResponseBody = UploadDocumentData;
  }

  /**
   * @description List documents with caching for improved performance
   * @tags dbtn/module:knowledge_base, dbtn/hasAuth
   * @name list_documents
   * @summary List Documents
   * @request GET:/routes/knowledge-base/documents
   */
  export namespace list_documents {
    export type RequestParams = {};
    export type RequestQuery = {
      /**
       * Page
       * @min 1
       * @default 1
       */
      page?: number;
      /**
       * Per Page
       * @min 1
       * @max 100
       * @default 20
       */
      per_page?: number;
      /** Search */
      search?: string | null;
      /**
       * Sort By
       * @default "created_at_desc"
       */
      sort_by?: string;
      /** Document Type */
      document_type?: string | null;
      /** Jurisdiction */
      jurisdiction?: string | null;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ListDocumentsData;
  }

  /**
   * @description Update a document
   * @tags dbtn/module:knowledge_base, dbtn/hasAuth
   * @name update_document
   * @summary Update Document
   * @request PUT:/routes/knowledge-base/documents/{document_id}
   */
  export namespace update_document {
    export type RequestParams = {
      /** Document Id */
      documentId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = BodyUpdateDocument;
    export type RequestHeaders = {};
    export type ResponseBody = UpdateDocumentData;
  }

  /**
   * @description Get a single document by ID for editing
   * @tags dbtn/module:knowledge_base, dbtn/hasAuth
   * @name get_document
   * @summary Get Document
   * @request GET:/routes/knowledge-base/documents/{document_id}
   */
  export namespace get_document {
    export type RequestParams = {
      /** Document Id */
      documentId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetDocumentData;
  }

  /**
   * @description Delete a document and all its sections from the knowledge base
   * @tags dbtn/module:knowledge_base, dbtn/hasAuth
   * @name delete_document
   * @summary Delete Document
   * @request DELETE:/routes/knowledge-base/documents/{document_id}
   */
  export namespace delete_document {
    export type RequestParams = {
      /** Document Id */
      documentId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = DeleteDocumentData;
  }

  /**
   * @description Get all available metadata options for document upload forms
   * @tags dbtn/module:knowledge_base, dbtn/hasAuth
   * @name get_knowledge_base_metadata_options
   * @summary Get Knowledge Base Metadata Options
   * @request GET:/routes/knowledge-base/metadata-options
   */
  export namespace get_knowledge_base_metadata_options {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetKnowledgeBaseMetadataOptionsData;
  }

  /**
   * @description Search documents with filters, full-text search, and pagination
   * @tags dbtn/module:knowledge_base, dbtn/hasAuth
   * @name search_documents
   * @summary Search Documents
   * @request POST:/routes/knowledge-base/search
   */
  export namespace search_documents {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = DocumentSearchRequest;
    export type RequestHeaders = {};
    export type ResponseBody = SearchDocumentsData;
  }

  /**
   * @description Advanced search with Boolean operators and filtering
   * @tags dbtn/module:knowledge_base, dbtn/hasAuth
   * @name advanced_search_documents
   * @summary Advanced Search Documents
   * @request POST:/routes/knowledge-base/advanced-search
   */
  export namespace advanced_search_documents {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = AdvancedSearchRequest;
    export type RequestHeaders = {};
    export type ResponseBody = AdvancedSearchDocumentsData;
  }

  /**
   * @description Get search suggestions and auto-complete options
   * @tags dbtn/module:knowledge_base, dbtn/hasAuth
   * @name get_search_suggestions
   * @summary Get Search Suggestions
   * @request GET:/routes/knowledge-base/search-suggestions
   */
  export namespace get_search_suggestions {
    export type RequestParams = {};
    export type RequestQuery = {
      /**
       * Query
       * Partial search query
       */
      query: string;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetSearchSuggestionsData;
  }

  /**
   * @description Download document file from storage
   * @tags stream, dbtn/module:knowledge_base, dbtn/hasAuth
   * @name download_document_file
   * @summary Download Document File
   * @request GET:/routes/knowledge-base/file/{document_id}
   */
  export namespace download_document_file {
    export type RequestParams = {
      /** Document Id */
      documentId: number;
    };
    export type RequestQuery = {
      /**
       * Token
       * Authentication token as query parameter
       */
      token?: string | null;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = DownloadDocumentFileData;
  }

  /**
   * @description Get a single blog document by ID for editing
   * @tags dbtn/module:knowledge_base, dbtn/hasAuth
   * @name get_blog_document
   * @summary Get Blog Document
   * @request GET:/routes/knowledge-base/blog/{document_id}
   */
  export namespace get_blog_document {
    export type RequestParams = {
      /** Document Id */
      documentId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetBlogDocumentData;
  }

  /**
   * @description Search blog documents with filters, full-text search, and pagination
   * @tags dbtn/module:knowledge_base, dbtn/hasAuth
   * @name search_blog_documents
   * @summary Search Blog Documents
   * @request POST:/routes/knowledge-base/blog-search
   */
  export namespace search_blog_documents {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = DocumentSearchRequest;
    export type RequestHeaders = {};
    export type ResponseBody = SearchBlogDocumentsData;
  }

  /**
   * @description List blog documents with caching for improved performance
   * @tags dbtn/module:knowledge_base, dbtn/hasAuth
   * @name list_blog_documents
   * @summary List Blog Documents
   * @request GET:/routes/knowledge-base/blog
   */
  export namespace list_blog_documents {
    export type RequestParams = {};
    export type RequestQuery = {
      /**
       * Page
       * @min 1
       * @default 1
       */
      page?: number;
      /**
       * Per Page
       * @min 1
       * @max 100
       * @default 20
       */
      per_page?: number;
      /** Search */
      search?: string | null;
      /**
       * Sort By
       * @default "created_at_desc"
       */
      sort_by?: string;
      /** Document Type */
      document_type?: string | null;
      /** Jurisdiction */
      jurisdiction?: string | null;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ListBlogDocumentsData;
  }

  /**
   * @description Advanced search with Boolean operators and filtering
   * @tags dbtn/module:knowledge_base, dbtn/hasAuth
   * @name advanced_search_blog_documents
   * @summary Advanced Search Blog Documents
   * @request POST:/routes/knowledge-base/blog-advanced-search
   */
  export namespace advanced_search_blog_documents {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = AdvancedSearchRequest;
    export type RequestHeaders = {};
    export type ResponseBody = AdvancedSearchBlogDocumentsData;
  }

  /**
   * @description Get search suggestions and auto-complete options
   * @tags dbtn/module:knowledge_base, dbtn/hasAuth
   * @name get_blog_search_suggestions
   * @summary Get Blog Search Suggestions
   * @request GET:/routes/knowledge-base/blog-search-suggestions
   */
  export namespace get_blog_search_suggestions {
    export type RequestParams = {};
    export type RequestQuery = {
      /**
       * Query
       * Partial search query
       */
      query: string;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetBlogSearchSuggestionsData;
  }

  /**
   * @description Get admin dashboard statistics
   * @tags dbtn/module:admin_dashboard, dbtn/hasAuth
   * @name get_admin_stats
   * @summary Get Admin Stats
   * @request GET:/routes/admin-dashboard/stats
   */
  export namespace get_admin_stats {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetAdminStatsData;
  }

  /**
   * @description List all documents for admin management
   * @tags dbtn/module:admin_dashboard, dbtn/hasAuth
   * @name list_admin_documents
   * @summary List Admin Documents
   * @request GET:/routes/admin-dashboard/documents
   */
  export namespace list_admin_documents {
    export type RequestParams = {};
    export type RequestQuery = {
      /**
       * Status
       * Filter by publishing status
       */
      status?: string | null;
      /**
       * Category Id
       * Filter by category
       */
      category_id?: number | null;
      /**
       * Limit
       * Number of documents to return
       * @default 50
       */
      limit?: number;
      /**
       * Offset
       * Offset for pagination
       * @default 0
       */
      offset?: number;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ListAdminDocumentsData;
  }

  /**
   * @description Update the publishing status of a document
   * @tags dbtn/module:admin_dashboard, dbtn/hasAuth
   * @name update_document_status
   * @summary Update Document Status
   * @request PUT:/routes/admin-dashboard/documents/{document_id}/status
   */
  export namespace update_document_status {
    export type RequestParams = {
      /** Document Id */
      documentId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = UpdateDocumentStatusRequest;
    export type RequestHeaders = {};
    export type ResponseBody = UpdateDocumentStatusData;
  }

  /**
   * @description Bulk publish/unpublish documents
   * @tags dbtn/module:admin_dashboard, dbtn/hasAuth
   * @name publish_document
   * @summary Publish Document
   * @request POST:/routes/admin-dashboard/documents/publish
   */
  export namespace publish_document {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = PublishDocumentRequest;
    export type RequestHeaders = {};
    export type ResponseBody = PublishDocumentData;
  }

  /**
   * @description Bulk update document statuses
   * @tags dbtn/module:admin_dashboard, dbtn/hasAuth
   * @name bulk_update_status
   * @summary Bulk Update Status
   * @request POST:/routes/admin-dashboard/documents/bulk-status
   */
  export namespace bulk_update_status {
    export type RequestParams = {};
    export type RequestQuery = {
      /** Status */
      status: string;
    };
    export type RequestBody = BulkUpdateStatusPayload;
    export type RequestHeaders = {};
    export type ResponseBody = BulkUpdateStatusData;
  }

  /**
   * @description Create a new category
   * @tags dbtn/module:admin_dashboard, dbtn/hasAuth
   * @name create_category
   * @summary Create Category
   * @request POST:/routes/admin-dashboard/categories
   */
  export namespace create_category {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = AppApisAdminDashboardCategoryRequest;
    export type RequestHeaders = {};
    export type ResponseBody = CreateCategoryData;
  }

  /**
   * @description Update a category
   * @tags dbtn/module:admin_dashboard, dbtn/hasAuth
   * @name update_category
   * @summary Update Category
   * @request PUT:/routes/admin-dashboard/categories/{category_id}
   */
  export namespace update_category {
    export type RequestParams = {
      /** Category Id */
      categoryId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = AppApisAdminDashboardCategoryRequest;
    export type RequestHeaders = {};
    export type ResponseBody = UpdateCategoryData;
  }

  /**
   * @description Delete a category
   * @tags dbtn/module:admin_dashboard, dbtn/hasAuth
   * @name delete_category
   * @summary Delete Category
   * @request DELETE:/routes/admin-dashboard/categories/{category_id}
   */
  export namespace delete_category {
    export type RequestParams = {
      /** Category Id */
      categoryId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = DeleteCategoryData;
  }

  /**
   * @description Get metadata options for a specific category (jurisdiction, type, subject)
   * @tags dbtn/module:admin_dashboard, dbtn/hasAuth
   * @name get_metadata_options
   * @summary Get Metadata Options
   * @request GET:/routes/admin-dashboard/metadata-options/{category}
   */
  export namespace get_metadata_options {
    export type RequestParams = {
      /** Category */
      category: string;
    };
    export type RequestQuery = {
      /**
       * Active Only
       * Only return active options
       * @default true
       */
      active_only?: boolean;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetMetadataOptionsData;
  }

  /**
   * @description Create a new metadata option
   * @tags dbtn/module:admin_dashboard, dbtn/hasAuth
   * @name create_metadata_option
   * @summary Create Metadata Option
   * @request POST:/routes/admin-dashboard/metadata-options
   */
  export namespace create_metadata_option {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = MetadataOptionRequest;
    export type RequestHeaders = {};
    export type ResponseBody = CreateMetadataOptionData;
  }

  /**
   * @description Update a metadata option
   * @tags dbtn/module:admin_dashboard, dbtn/hasAuth
   * @name update_metadata_option
   * @summary Update Metadata Option
   * @request PUT:/routes/admin-dashboard/metadata-options/{option_id}
   */
  export namespace update_metadata_option {
    export type RequestParams = {
      /** Option Id */
      optionId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = MetadataOptionUpdate;
    export type RequestHeaders = {};
    export type ResponseBody = UpdateMetadataOptionData;
  }

  /**
   * @description Delete a metadata option
   * @tags dbtn/module:admin_dashboard, dbtn/hasAuth
   * @name delete_metadata_option
   * @summary Delete Metadata Option
   * @request DELETE:/routes/admin-dashboard/metadata-options/{option_id}
   */
  export namespace delete_metadata_option {
    export type RequestParams = {
      /** Option Id */
      optionId: number;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = DeleteMetadataOptionData;
  }

  /**
   * @description Reorder metadata options within a category
   * @tags dbtn/module:admin_dashboard, dbtn/hasAuth
   * @name reorder_metadata_options
   * @summary Reorder Metadata Options
   * @request PUT:/routes/admin-dashboard/metadata-options/reorder
   */
  export namespace reorder_metadata_options {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = ReorderRequest;
    export type RequestHeaders = {};
    export type ResponseBody = ReorderMetadataOptionsData;
  }

  /**
   * @description Create a new classification workflow (Admin only)
   * @tags dbtn/module:classification_workflows, dbtn/hasAuth
   * @name create_workflow
   * @summary Create Workflow
   * @request POST:/routes/classification-workflows/admin/workflows
   */
  export namespace create_workflow {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = ClassificationWorkflowCreate;
    export type RequestHeaders = {};
    export type ResponseBody = CreateWorkflowData;
  }

  /**
   * @description List classification workflows for admin with optional type filtering
   * @tags dbtn/module:classification_workflows, dbtn/hasAuth
   * @name list_admin_workflows
   * @summary List Admin Workflows
   * @request GET:/routes/classification-workflows/admin/workflows
   */
  export namespace list_admin_workflows {
    export type RequestParams = {};
    export type RequestQuery = {
      /** Workflow Type */
      workflow_type?: string | null;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ListAdminWorkflowsData;
  }

  /**
   * @description Get workflow by ID (Admin only)
   * @tags dbtn/module:classification_workflows, dbtn/hasAuth
   * @name get_workflow_by_id
   * @summary Get Workflow By Id
   * @request GET:/routes/classification-workflows/admin/workflows/{workflow_id}
   */
  export namespace get_workflow_by_id {
    export type RequestParams = {
      /** Workflow Id */
      workflowId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetWorkflowByIdData;
  }

  /**
   * @description Update a classification workflow (Admin only)
   * @tags dbtn/module:classification_workflows, dbtn/hasAuth
   * @name update_workflow
   * @summary Update Workflow
   * @request PUT:/routes/classification-workflows/admin/workflows/{workflow_id}
   */
  export namespace update_workflow {
    export type RequestParams = {
      /** Workflow Id */
      workflowId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = ClassificationWorkflowUpdate;
    export type RequestHeaders = {};
    export type ResponseBody = UpdateWorkflowData;
  }

  /**
   * @description Delete a classification workflow (Admin only)
   * @tags dbtn/module:classification_workflows, dbtn/hasAuth
   * @name delete_workflow
   * @summary Delete Workflow
   * @request DELETE:/routes/classification-workflows/admin/workflows/{workflow_id}
   */
  export namespace delete_workflow {
    export type RequestParams = {
      /** Workflow Id */
      workflowId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = DeleteWorkflowData;
  }

  /**
   * @description Get all classification workflows for the authenticated user
   * @tags dbtn/module:classification_workflows, dbtn/hasAuth
   * @name list_workflows
   * @summary List Workflows
   * @request GET:/routes/classification-workflows/workflows
   */
  export namespace list_workflows {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ListWorkflowsData;
  }

  /**
   * @description Get a published workflow by ID for users
   * @tags dbtn/module:classification_workflows, dbtn/hasAuth
   * @name get_published_workflow
   * @summary Get Published Workflow
   * @request GET:/routes/classification-workflows/workflows/{workflow_id}
   */
  export namespace get_published_workflow {
    export type RequestParams = {
      /** Workflow Id */
      workflowId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetPublishedWorkflowData;
  }
}
