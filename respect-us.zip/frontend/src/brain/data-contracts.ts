/** AcceptInvitationRequest */
export interface AcceptInvitationRequest {
  /** Invitation Token */
  invitation_token: string;
}

/** ActivityResponse */
export interface ActivityResponse {
  /** Id */
  id: number;
  /** User Id */
  user_id: string;
  /** User Name */
  user_name: string;
  /** Document Id */
  document_id: number;
  /** Document Title */
  document_title: string;
  /** Activity Type */
  activity_type: string;
  /** Metadata */
  metadata: Record<string, any> | null;
  /**
   * Created At
   * @format date-time
   */
  created_at: string;
}

/** AdminCreditAdjustment */
export interface AdminCreditAdjustment {
  /** User Id */
  user_id: string;
  /** Amount */
  amount: number;
  /** Reason */
  reason: string;
}

/** AdminDocumentResponse */
export interface AdminDocumentResponse {
  /** Id */
  id: number;
  /** Title */
  title: string;
  /** Description */
  description: string | null;
  /** Content */
  content?: string | null;
  /** Country Jurisdiction */
  country_jurisdiction: string[] | null;
  /** Regulation Type */
  regulation_type: string[] | null;
  /** File Name */
  file_name: string;
  /** File Size */
  file_size: number | null;
  /** Tags */
  tags: string[];
  /** Uploaded By */
  uploaded_by: string | null;
  /**
   * Created At
   * @format date-time
   */
  created_at: string;
  /**
   * Updated At
   * @format date-time
   */
  updated_at: string;
  /**
   * Publishing Status
   * @default "draft"
   */
  publishing_status?: string | null;
  /** Published At */
  published_at: string | null;
  /** Published By */
  published_by: string | null;
  /**
   * Category Ids
   * @default []
   */
  category_ids?: number[];
  /** Subject */
  subject: string[] | null;
  /** Document Source Type */
  document_source_type: string | null;
  /** Source Url */
  source_url: string | null;
  /** Section Count */
  section_count: number;
  /** Issuing Authority */
  issuing_authority: string | null;
  /** Publication Date */
  publication_date: string | null;
  /** Effective Date */
  effective_date: string | null;
  /** Adoption Date */
  adoption_date: string | null;
  /** Expiration Date */
  expiration_date: string | null;
  /** Next Review Date */
  next_review_date: string | null;
  /** Legal Status */
  legal_status: string | null;
  /** Version */
  version: string | null;
}

/** AdminNotification */
export interface AdminNotification {
  /** Notification Id */
  notification_id: string;
  /** Title */
  title: string;
  /** Message */
  message: string;
  /** Notification Type */
  notification_type: string;
  /** Priority */
  priority: string;
  /** Target Audience */
  target_audience: string;
  /** Target Criteria */
  target_criteria: Record<string, any> | null;
  /** Is Active */
  is_active: boolean;
  /** Expires At */
  expires_at: string | null;
  /** Created By */
  created_by: string;
  /**
   * Created At
   * @format date-time
   */
  created_at: string;
  /**
   * Updated At
   * @format date-time
   */
  updated_at: string;
  /** Metadata */
  metadata: Record<string, any> | null;
  /** Delivery Stats */
  delivery_stats?: Record<string, number> | null;
}

/** AdminNotificationCreate */
export interface AdminNotificationCreate {
  /** Title */
  title: string;
  /** Message */
  message: string;
  /** Notification Type */
  notification_type: string;
  /**
   * Priority
   * @default "medium"
   */
  priority?: string;
  /**
   * Target Audience
   * @default "all_users"
   */
  target_audience?: string;
  /** Target Criteria */
  target_criteria?: Record<string, any> | null;
  /** Expires At */
  expires_at?: string | null;
  /** Metadata */
  metadata?: Record<string, any> | null;
}

/** AdminNotificationResponse */
export interface AdminNotificationResponse {
  /** Notification Id */
  notification_id: string;
  /** Message */
  message: string;
  /**
   * Created At
   * @format date-time
   */
  created_at: string;
}

/** AdminNotificationUpdate */
export interface AdminNotificationUpdate {
  /** Title */
  title?: string | null;
  /** Message */
  message?: string | null;
  /** Notification Type */
  notification_type?: string | null;
  /** Priority */
  priority?: string | null;
  /** Target Audience */
  target_audience?: string | null;
  /** Target Criteria */
  target_criteria?: Record<string, any> | null;
  /** Is Active */
  is_active?: boolean | null;
  /** Expires At */
  expires_at?: string | null;
  /** Metadata */
  metadata?: Record<string, any> | null;
}

/** AdminStatsResponse */
export interface AdminStatsResponse {
  /** Total Documents */
  total_documents: number;
  /** Published Documents */
  published_documents: number;
  /** Draft Documents */
  draft_documents: number;
  /** Archived Documents */
  archived_documents: number;
  /** Total Categories */
  total_categories: number;
  /** Recent Uploads */
  recent_uploads: number;
  /** Total Downloads */
  total_downloads: number;
  /** Active Users */
  active_users: number;
}

/** AdminSupportResponse */
export interface AdminSupportResponse {
  /** Response Message */
  response_message: string;
  /** Status */
  status: string;
  /** Internal Notes */
  internal_notes?: string | null;
}

/** AdminTask */
export interface AdminTask {
  /** Id */
  id: string;
  /** Title */
  title: string;
  /** Description */
  description: string;
  /** Type */
  type: string;
  /** Status */
  status: string;
  /** Submission Id */
  submission_id?: string | null;
  /** Submitted By */
  submitted_by?: string | null;
  /**
   * Created At
   * @format date-time
   */
  created_at: string;
  /**
   * Updated At
   * @format date-time
   */
  updated_at: string;
}

/** AdminUsageAnalytics */
export interface AdminUsageAnalytics {
  /** Total Users */
  total_users: number;
  /** Active Users Last 30 Days */
  active_users_last_30_days: number;
  /** Total Credits Consumed All Time */
  total_credits_consumed_all_time: number;
  /** Total Credits Consumed Last 30 Days */
  total_credits_consumed_last_30_days: number;
  /** Average Credits Per User */
  average_credits_per_user: number;
  /** Top Components By Usage */
  top_components_by_usage: ComponentUsage[];
  /** Revenue Analytics */
  revenue_analytics: Record<string, any>;
  /** User Engagement Metrics */
  user_engagement_metrics: Record<string, any>;
}

/** AdminValidationRequest */
export interface AdminValidationRequest {
  /** Validation Id */
  validation_id: string;
  /** Admin Decision */
  admin_decision: string;
  /** Admin Comments */
  admin_comments?: string | null;
  /** Modified Action Plan */
  modified_action_plan?: Record<string, string> | null;
  /** Modified Overall Assessment */
  modified_overall_assessment?: Record<string, string> | null;
}

/** AdminValidationResponse */
export interface AdminValidationResponse {
  /** Success */
  success: boolean;
  /** Message */
  message: string;
  /** Email Sent */
  email_sent: boolean;
}

/** AdvancedSearchRequest */
export interface AdvancedSearchRequest {
  /**
   * Query
   * Search query with Boolean operators (AND, OR, NOT)
   * @default ""
   */
  query?: string;
  /**
   * Filters
   * Advanced filters
   */
  filters?: Record<string, any>[] | null;
  /**
   * Search Sections
   * Search within document sections
   * @default false
   */
  search_sections?: boolean;
  /**
   * Sort By
   * Sort by: relevance, date, title
   * @default "relevance"
   */
  sort_by?: string;
  /**
   * Limit
   * @max 100
   * @default 50
   */
  limit?: number;
  /**
   * Offset
   * @default 0
   */
  offset?: number;
}

/** AdvancedSearchResponse */
export interface AdvancedSearchResponse {
  /** Documents */
  documents: Record<string, any>[];
  /**
   * Sections
   * @default []
   */
  sections?: Record<string, any>[];
  /** Total Count */
  total_count: number;
  /** Has More */
  has_more: boolean;
  /**
   * Search Terms
   * @default []
   */
  search_terms?: Record<string, any>[];
  /**
   * Filters Applied
   * @default []
   */
  filters_applied?: Record<string, any>[];
  /** Error */
  error?: string | null;
}

/** AlertAnalyticsResponse */
export interface AlertAnalyticsResponse {
  /** Total Alerts */
  total_alerts: number;
  /** Critical Alerts */
  critical_alerts: number;
  /** Pending Alerts */
  pending_alerts: number;
  /** Resolved Alerts */
  resolved_alerts: number;
  /** Alert Response Time */
  alert_response_time: number;
  /** Alerts By Type */
  alerts_by_type: Record<string, number>;
  /** Recent Alerts */
  recent_alerts: Record<string, any>[];
}

/** AlertThreshold */
export interface AlertThreshold {
  /** Alert Type */
  alert_type: string;
  /** Threshold Value */
  threshold_value: number;
  /** Is Enabled */
  is_enabled: boolean;
}

/** AnnotationResponse */
export interface AnnotationResponse {
  /** Id */
  id: number;
  /** Document Id */
  document_id: number;
  /** Section Id */
  section_id: number | null;
  /** User Id */
  user_id: string;
  /** User Name */
  user_name: string;
  /** Annotation Type */
  annotation_type: string;
  /** Content */
  content: string;
  /** Start Position */
  start_position: number | null;
  /** End Position */
  end_position: number | null;
  /** Is Public */
  is_public: boolean;
  /** Tags */
  tags: string[] | null;
  /** Metadata */
  metadata: Record<string, any> | null;
  /**
   * Created At
   * @format date-time
   */
  created_at: string;
  /**
   * Updated At
   * @format date-time
   */
  updated_at: string;
  /** Resolved */
  resolved: boolean;
  /** Resolved By */
  resolved_by: string | null;
  /** Resolved At */
  resolved_at: string | null;
}

/** AnnotationUpdate */
export interface AnnotationUpdate {
  /** Content */
  content?: string | null;
  /** Annotation Type */
  annotation_type?: string | null;
  /** Is Public */
  is_public?: boolean | null;
  /** Tags */
  tags?: string[] | null;
  /** Resolved */
  resolved?: boolean | null;
}

/** ApprovalRequest */
export interface ApprovalRequest {
  /** Document Id */
  document_id: number;
  /** Action */
  action: string;
  /** Admin Notes */
  admin_notes?: string | null;
}

/** AssessmentResponse */
export interface AssessmentResponse {
  /** Question Id */
  question_id: string;
  /** Section Id */
  section_id: string;
  /** Answer */
  answer: any;
  /** Notes */
  notes?: string | null;
}

/** AssignCategoriesRequest */
export interface AssignCategoriesRequest {
  /** Category Ids */
  category_ids: number[];
}

/** AuditLogEntry */
export interface AuditLogEntry {
  /** Id */
  id: number;
  /** Company Id */
  company_id: number | null;
  /** User Id */
  user_id: string;
  /** Action */
  action: string;
  /** Resource Type */
  resource_type: string | null;
  /** Resource Id */
  resource_id: string | null;
  /** Details */
  details: Record<string, any>;
  /** Ip Address */
  ip_address: string | null;
  /** User Agent */
  user_agent: string | null;
  /** Created At */
  created_at: string;
  /** User Email */
  user_email: string | null;
  /** User Name */
  user_name: string | null;
}

/** AuditLogResponse */
export interface AuditLogResponse {
  /** Logs */
  logs: AuditLogEntry[];
  /** Total Count */
  total_count: number;
  /** Has More */
  has_more: boolean;
}

/** AutoRechargeConfigRequest */
export interface AutoRechargeConfigRequest {
  /**
   * Trigger Threshold
   * Credits remaining to trigger recharge
   * @min 1
   * @max 1000
   */
  trigger_threshold: number;
  /**
   * Recharge Amount
   * Credits to purchase on recharge
   * @min 10
   * @max 10000
   */
  recharge_amount: number;
  /**
   * Max Recharges Per Month
   * Maximum recharges per month
   * @min 1
   * @max 50
   */
  max_recharges_per_month: number;
  /**
   * Payment Method Id
   * Stripe payment method ID
   */
  payment_method_id: string;
  /**
   * Is Enabled
   * Enable/disable auto-recharge
   * @default true
   */
  is_enabled?: boolean;
}

/** AutoRechargeConfigResponse */
export interface AutoRechargeConfigResponse {
  /** User Id */
  user_id: string;
  /** Trigger Threshold */
  trigger_threshold: number;
  /** Recharge Amount */
  recharge_amount: number;
  /** Max Recharges Per Month */
  max_recharges_per_month: number;
  /** Payment Method Id */
  payment_method_id: string;
  /** Is Enabled */
  is_enabled: boolean;
  /** Status */
  status: string;
  /** Pause Reason */
  pause_reason: string | null;
  /**
   * Created At
   * @format date-time
   */
  created_at: string;
  /**
   * Updated At
   * @format date-time
   */
  updated_at: string;
}

/** AutoRechargeTransactionResponse */
export interface AutoRechargeTransactionResponse {
  /** Transaction Id */
  transaction_id: string;
  /** Credit Amount */
  credit_amount: number;
  /** Payment Amount */
  payment_amount: number;
  /** Currency */
  currency: string;
  /** Status */
  status: string;
  /** Failure Reason */
  failure_reason: string | null;
  /**
   * Created At
   * @format date-time
   */
  created_at: string;
  /** Completed At */
  completed_at: string | null;
}

/** AutomatedFeedSource */
export interface AutomatedFeedSource {
  /** Name */
  name: string;
  /** Description */
  description: string;
  /**
   * Source Url
   * @format uri
   * @minLength 1
   * @maxLength 2083
   */
  source_url: string;
  /** Source Type */
  source_type: string;
  /** Jurisdiction */
  jurisdiction: string;
  /** Document Types */
  document_types: string[];
  /** Update Frequency */
  update_frequency: string;
  /**
   * Is Active
   * @default true
   */
  is_active?: boolean;
  /** Last Check */
  last_check?: string | null;
  /** Xpath Selectors */
  xpath_selectors?: Record<string, string> | null;
  /** Api Config */
  api_config?: Record<string, any> | null;
}

/** AutomationAnalytics */
export interface AutomationAnalytics {
  /** Total Feeds */
  total_feeds: number;
  /** Active Feeds */
  active_feeds: number;
  /** Total Documents Processed */
  total_documents_processed: number;
  /** Documents Added Today */
  documents_added_today: number;
  /** Documents Added This Week */
  documents_added_this_week: number;
  /** Feed Success Rate */
  feed_success_rate: number;
  /** Average Processing Time */
  average_processing_time: number;
  /** Top Performing Feeds */
  top_performing_feeds: Record<string, any>[];
  /** Recent Updates */
  recent_updates: Record<string, any>[];
}

/** AutomationJobResponse */
export interface AutomationJobResponse {
  /** Id */
  id: number;
  /** Job Type */
  job_type: string;
  /** Schedule Id */
  schedule_id: number | null;
  /** Status */
  status: string;
  /** Progress */
  progress: number;
  /** Total Items */
  total_items: number;
  /** Results */
  results: Record<string, any> | null;
  /** Error Message */
  error_message: string | null;
  /** Started At */
  started_at: string | null;
  /** Completed At */
  completed_at: string | null;
  /**
   * Created At
   * @format date-time
   */
  created_at: string;
}

/** AutomationPerformanceResponse */
export interface AutomationPerformanceResponse {
  /** Total Schedules */
  total_schedules: number;
  /** Active Schedules */
  active_schedules: number;
  /** Completed Jobs Today */
  completed_jobs_today: number;
  /** Failed Jobs Today */
  failed_jobs_today: number;
  /** Automation Efficiency */
  automation_efficiency: number;
  /** Schedule Performance */
  schedule_performance: Record<string, any>[];
}

/** BackgroundJobStatus */
export interface BackgroundJobStatus {
  /** Job Id */
  job_id: number;
  /** Job Type */
  job_type: string;
  /** Customer Id */
  customer_id: string | null;
  /** Status */
  status: string;
  /**
   * Started At
   * @format date-time
   */
  started_at: string;
  /** Completed At */
  completed_at: string | null;
  /** Result */
  result: Record<string, any> | null;
  /** Error Message */
  error_message: string | null;
}

/** BadgeListResponse */
export interface BadgeListResponse {
  /** Badges */
  badges: BadgeResponse[];
  /** Total */
  total: number;
}

/** BadgeResponse */
export interface BadgeResponse {
  /** Id */
  id: number;
  /** Name */
  name: string;
  /** Description */
  description: string | null;
  /** Color */
  color: string;
  /** Category */
  category: string;
  /** Is Active */
  is_active: boolean;
  /** Sort Order */
  sort_order: number;
  /** Created By */
  created_by: string;
  /**
   * Created At
   * @format date-time
   */
  created_at: string;
  /**
   * Updated At
   * @format date-time
   */
  updated_at: string;
}

/** BaseCreditPriceRequest */
export interface BaseCreditPriceRequest {
  /** Price Eur Per Credit */
  price_eur_per_credit: number;
}

/** BatchProcessRequest */
export interface BatchProcessRequest {
  /** Document Ids */
  document_ids: string[];
  /**
   * Processing Options
   * @default {}
   */
  processing_options?: Record<string, any>;
}

/** BatchProcessResponse */
export interface BatchProcessResponse {
  /** Batch Id */
  batch_id: string;
  /** Document Count */
  document_count: number;
  /** Estimated Completion */
  estimated_completion: string;
  /** Individual Processing Ids */
  individual_processing_ids: string[];
}

/**
 * BatchProcessingRequest
 * Request for batch processing multiple feeds
 */
export interface BatchProcessingRequest {
  /** Feed Ids */
  feed_ids: number[];
  /**
   * Parallel Workers
   * @min 1
   * @max 10
   * @default 3
   */
  parallel_workers?: number;
  /**
   * Error Threshold
   * @min 0
   * @max 1
   * @default 0.3
   */
  error_threshold?: number;
  /**
   * Timeout Seconds
   * @min 30
   * @max 3600
   * @default 300
   */
  timeout_seconds?: number;
}

/**
 * BatchProcessingResult
 * Result of batch processing operation
 */
export interface BatchProcessingResult {
  /** Total Feeds */
  total_feeds: number;
  /** Successful Feeds */
  successful_feeds: number;
  /** Failed Feeds */
  failed_feeds: number;
  /** Processing Time Seconds */
  processing_time_seconds: number;
  /** Results */
  results: FeedProcessingResult[];
  /** Overall Success Rate */
  overall_success_rate: number;
  /** Errors */
  errors?: string[];
}

/** BatchReportRequest */
export interface BatchReportRequest {
  /** Customer Ids */
  customer_ids: number[];
  /** Batch Name */
  batch_name?: string | null;
}

/**
 * BatchScreeningRequest
 * Request for batch screening multiple customers
 */
export interface BatchScreeningRequest {
  /** Customer Ids */
  customer_ids: number[];
  /**
   * Force Rescreen
   * @default false
   */
  force_rescreen?: boolean;
  /**
   * Screening Date
   * Date to screen against (uses current lists if None)
   */
  screening_date?: string | null;
}

/** BillingHistoryResponse */
export interface BillingHistoryResponse {
  /** Invoices */
  invoices: AppApisBillingManagementInvoiceResponse[];
  /** Total Count */
  total_count: number;
  /** Total Amount Paid */
  total_amount_paid: number;
  /** Total Amount Pending */
  total_amount_pending: number;
  /** Currency */
  currency: string;
}

/** BillingSettingsResponse */
export interface BillingSettingsResponse {
  /** Company Id */
  company_id: number | null;
  /** Billing Email */
  billing_email: string | null;
  /** Auto Pay Enabled */
  auto_pay_enabled: boolean;
  /** Invoice Delivery Method */
  invoice_delivery_method: string;
  /** Currency Preference */
  currency_preference: string;
  /** Billing Cycle */
  billing_cycle: string;
}

/** BlockUserRequest */
export interface BlockUserRequest {
  /** User Id */
  user_id: string;
  /** Reason */
  reason: string;
}

/** BlogSubmissionRequest */
export interface BlogSubmissionRequest {
  /** Title */
  title: string;
  /** Summary */
  summary?: string | null;
  /** Content */
  content: string;
  /** Tags */
  tags?: string | null;
}

/** Body_bulk_import_sanctions */
export interface BodyBulkImportSanctions {
  /**
   * File
   * @format binary
   */
  file: File;
  /** Source List */
  source_list: string;
  /** Jurisdiction */
  jurisdiction: string;
  /**
   * Update Existing
   * @default false
   */
  update_existing?: boolean;
}

/** Body_bulk_upload_critical_countries */
export interface BodyBulkUploadCriticalCountries {
  /**
   * File
   * @format binary
   */
  file: File;
}

/** Body_import_critical_products */
export interface BodyImportCriticalProducts {
  /**
   * File
   * @format binary
   */
  file: File;
}

/** Body_import_notes_from_excel */
export interface BodyImportNotesFromExcel {
  /**
   * File Content
   * @format binary
   */
  file_content: File;
}

/** Body_import_xml_sanctions */
export interface BodyImportXmlSanctions {
  /**
   * File
   * @format binary
   */
  file: File;
}

/** Body_process_document */
export interface BodyProcessDocument {
  /**
   * File
   * @format binary
   */
  file: File;
}

/** Body_submit_case_study */
export interface BodySubmitCaseStudy {
  /**
   * File
   * @format binary
   */
  file: File;
  /** Reason */
  reason?: string | null;
}

/** Body_submit_document */
export interface BodySubmitDocument {
  /**
   * File
   * @format binary
   */
  file: File;
  /** Reason */
  reason?: string | null;
}

/** Body_update_document */
export interface BodyUpdateDocument {
  /** Metadata */
  metadata: string;
  /** File */
  file?: File | null;
}

/** Body_upload_assessment_form */
export interface BodyUploadAssessmentForm {
  /**
   * File
   * @format binary
   */
  file: File;
}

/** Body_upload_customer_document */
export interface BodyUploadCustomerDocument {
  /**
   * File
   * @format binary
   */
  file: File;
  /** Customer Id */
  customer_id?: number | null;
  /** Category */
  category: string;
  /** Subcategory */
  subcategory?: string | null;
  /** Description */
  description?: string | null;
  /** Tags */
  tags?: string | null;
  /** Expires At */
  expires_at?: string | null;
  /**
   * Requires Approval
   * @default false
   */
  requires_approval?: boolean;
}

/** Body_upload_document */
export interface BodyUploadDocument {
  /** File */
  file?: File | null;
  /** Metadata */
  metadata: string;
}

/** Body_upload_document_attachment */
export interface BodyUploadDocumentAttachment {
  /**
   * File
   * @format binary
   */
  file: File;
}

/** Body_upload_image */
export interface BodyUploadImage {
  /**
   * File
   * @format binary
   */
  file: File;
}

/** BookmarkResponse */
export interface BookmarkResponse {
  /** Id */
  id: number;
  /** User Id */
  user_id: string;
  /** Document Id */
  document_id: number;
  /** Document Title */
  document_title: string;
  /** Section Id */
  section_id: number | null;
  /** Section Title */
  section_title: string | null;
  /** Bookmark Type */
  bookmark_type: string;
  /** Notes */
  notes: string | null;
  /** Tags */
  tags: string[] | null;
  /**
   * Created At
   * @format date-time
   */
  created_at: string;
  /**
   * Updated At
   * @format date-time
   */
  updated_at: string;
}

/** BulkPricingUpdate */
export interface BulkPricingUpdate {
  /** Document Ids */
  document_ids: number[];
  /** Credit Cost */
  credit_cost?: number | null;
  /**
   * Is Premium
   * @default false
   */
  is_premium?: boolean;
  /**
   * Pricing Tier
   * @default "free"
   */
  pricing_tier?: string;
}

/** BulkReorderRequest */
export interface BulkReorderRequest {
  /** Category */
  category: string;
  /** Option Orders */
  option_orders: Record<string, any>[];
}

/** BulkUpdateOrderRequest */
export interface BulkUpdateOrderRequest {
  /** Section Orders */
  section_orders: Record<string, any>[];
}

/** ChatMessage */
export interface ChatMessage {
  /** Id */
  id: string;
  /** User Id */
  user_id: string;
  /** Username */
  username: string;
  /** Content */
  content: string;
  /**
   * Message Type
   * @default "message"
   */
  message_type?: string;
  /** Thread Id */
  thread_id?: string | null;
  /** Reply To */
  reply_to?: string | null;
  /**
   * Created At
   * @format date-time
   */
  created_at: string;
  /** Updated At */
  updated_at?: string | null;
  /** Reactions */
  reactions?: Record<string, any> | null;
  /**
   * Is Pinned
   * @default false
   */
  is_pinned?: boolean;
  /**
   * Is Deleted
   * @default false
   */
  is_deleted?: boolean;
}

/** ClassificationNote */
export interface ClassificationNote {
  /** Id */
  id?: number | null;
  /** Note Key */
  note_key: string;
  /** Title */
  title: string;
  /** Content */
  content: string;
  /** Tree Id */
  tree_id?: string | null;
  /**
   * Module Type
   * @default "product_classification"
   */
  module_type?: string;
  /** Created By */
  created_by?: string | null;
  /** Created At */
  created_at?: string | null;
  /** Updated At */
  updated_at?: string | null;
}

/** ClassificationNotification */
export interface ClassificationNotification {
  /** Id */
  id: string;
  /** Classification Id */
  classification_id: string;
  /** Classification Name */
  classification_name: string;
  /** Notification Type */
  notification_type: string;
  /** Message */
  message: string;
  /**
   * Created At
   * @format date-time
   */
  created_at: string;
  /**
   * Acknowledged
   * @default false
   */
  acknowledged?: boolean;
}

/** ClassificationOutcome */
export interface ClassificationOutcome {
  /**
   * Id
   * @format uuid
   */
  id: string;
  /** Tree Id */
  tree_id?: string | null;
  /** Outcome Code */
  outcome_code: string;
  /** Outcome Title */
  outcome_title: string;
  /** Description */
  description: string | null;
  /** Regulatory Basis */
  regulatory_basis: string | null;
  /** Outcome Text */
  outcome_text: string;
  /**
   * Is Controlled
   * @default false
   */
  is_controlled?: boolean | null;
  /** Guidance Notes */
  guidance_notes?: string | null;
  /**
   * Created At
   * @format date-time
   */
  created_at: string;
}

/** ClassificationOutcomeCreate */
export interface ClassificationOutcomeCreate {
  /**
   * Outcome Code
   * @maxLength 100
   */
  outcome_code: string;
  /**
   * Outcome Title
   * @maxLength 255
   */
  outcome_title: string;
  /** Description */
  description?: string | null;
  /** Regulatory Basis */
  regulatory_basis?: string | null;
  /** Outcome Text */
  outcome_text: string;
  /**
   * Is Controlled
   * @default false
   */
  is_controlled?: boolean | null;
  /** Guidance Notes */
  guidance_notes?: string | null;
}

/** ClassificationOutcomeUpdate */
export interface ClassificationOutcomeUpdate {
  /** Outcome Code */
  outcome_code?: string | null;
  /** Outcome Title */
  outcome_title?: string | null;
  /** Description */
  description?: string | null;
  /** Regulatory Basis */
  regulatory_basis?: string | null;
  /** Outcome Text */
  outcome_text?: string | null;
  /** Is Controlled */
  is_controlled?: boolean | null;
  /** Guidance Notes */
  guidance_notes?: string | null;
}

/** ClassificationTreeCreate */
export interface ClassificationTreeCreate {
  /**
   * Name
   * @maxLength 255
   */
  name: string;
  /** Description */
  description?: string | null;
  /**
   * Jurisdiction
   * @maxLength 100
   */
  jurisdiction: string;
  /**
   * Category
   * @maxLength 100
   */
  category: string;
  /** Introduction Tree Id */
  introduction_tree_id?: string | null;
  /**
   * Is Introduction Template
   * @default false
   */
  is_introduction_template?: boolean;
}

/** ClassificationTreeUpdate */
export interface ClassificationTreeUpdate {
  /** Name */
  name?: string | null;
  /** Description */
  description?: string | null;
  /** Jurisdiction */
  jurisdiction?: string | null;
  /** Category */
  category?: string | null;
  /** Version */
  version?: number | null;
  /** Status */
  status?: string | null;
  /** Introduction Tree Id */
  introduction_tree_id?: string | null;
  /** Is Introduction Template */
  is_introduction_template?: boolean | null;
}

/** ClassificationWorkflow */
export interface ClassificationWorkflow {
  /** Id */
  id: string;
  /** Name */
  name: string;
  /** Description */
  description: string | null;
  /** Pricing Tier */
  pricing_tier: string | null;
  /** Introduction Tree Id */
  introduction_tree_id: string | null;
  /** Introduction Tree Name */
  introduction_tree_name: string | null;
  /** Created By */
  created_by: string;
  /** Status */
  status: string;
  /**
   * Created At
   * @format date-time
   */
  created_at: string;
  /**
   * Updated At
   * @format date-time
   */
  updated_at: string;
  /** Introduction Trees */
  introduction_trees: AppApisClassificationWorkflowsIntroductionTree[];
  /** Classification Trees */
  classification_trees: AppApisClassificationWorkflowsClassificationTree[];
  /** Conditional Rules */
  conditional_rules?: ConditionalRule[];
  /** Outcomes */
  outcomes?: WorkflowOutcome[];
  /**
   * Trigger Condition
   * @default "automatic"
   */
  trigger_condition?: string;
  /**
   * Workflow Type
   * @default "classification"
   */
  workflow_type?: string | null;
}

/** ClassificationWorkflowCreate */
export interface ClassificationWorkflowCreate {
  /**
   * Name
   * @minLength 1
   * @maxLength 255
   */
  name: string;
  /** Description */
  description?: string | null;
  /** Pricing Tier */
  pricing_tier?: string | null;
  /** Introduction Tree Ids */
  introduction_tree_ids?: string[];
  /** Classification Tree Ids */
  classification_tree_ids?: string[];
  /** Tree Orders */
  tree_orders?: TreeOrder[];
  /**
   * Status
   * @default "draft"
   * @pattern ^(draft|published|archived)$
   */
  status?: string;
  /** Conditional Rules */
  conditional_rules?: ConditionalRule[];
  /** Outcomes */
  outcomes?: WorkflowOutcome[];
  /**
   * Trigger Condition
   * @default "automatic"
   */
  trigger_condition?: string;
  /**
   * Workflow Type
   * @default "classification"
   */
  workflow_type?: string | null;
}

/** ClassificationWorkflowList */
export interface ClassificationWorkflowList {
  /** Workflows */
  workflows: ClassificationWorkflow[];
  /** Total */
  total: number;
}

/** ClassificationWorkflowUpdate */
export interface ClassificationWorkflowUpdate {
  /** Name */
  name?: string | null;
  /** Description */
  description?: string | null;
  /** Pricing Tier */
  pricing_tier?: string | null;
  /** Introduction Tree Ids */
  introduction_tree_ids?: string[] | null;
  /** Classification Tree Ids */
  classification_tree_ids?: string[] | null;
  /** Tree Orders */
  tree_orders?: TreeOrder[] | null;
  /** Status */
  status?: string | null;
  /** Conditional Rules */
  conditional_rules?: ConditionalRule[] | null;
  /** Outcomes */
  outcomes?: WorkflowOutcome[] | null;
  /** Trigger Condition */
  trigger_condition?: string | null;
  /** Global Order */
  global_order?: number | null;
}

/** CollaborationActivity */
export interface CollaborationActivity {
  /** Id */
  id?: number | null;
  /** Document Id */
  document_id: number;
  /** User Id */
  user_id: string;
  /** Activity Type */
  activity_type: string;
  /** Description */
  description: string;
  /** Metadata */
  metadata?: Record<string, any>;
  /** Created At */
  created_at?: string | null;
  /** User Name */
  user_name?: string | null;
}

/** CollaborationStatsResponse */
export interface CollaborationStatsResponse {
  /** Total Annotations */
  total_annotations: number;
  /** Public Annotations */
  public_annotations: number;
  /** User Annotations */
  user_annotations: number;
  /** Resolved Annotations */
  resolved_annotations: number;
  /** Total Bookmarks */
  total_bookmarks: number;
  /** Recent Activity Count */
  recent_activity_count: number;
  /** Top Annotated Documents */
  top_annotated_documents: Record<string, any>[];
  /** Collaboration Score */
  collaboration_score: number;
}

/** CompanyResponse */
export interface CompanyResponse {
  /** Id */
  id: number;
  /** Company Name */
  company_name: string;
  /** Company Slug */
  company_slug: string;
  /** Company Domain */
  company_domain: string | null;
  /** Billing Email */
  billing_email: string | null;
  /** Subscription Tier */
  subscription_tier: string;
  /** Max Team Members */
  max_team_members: number;
  /** Created By */
  created_by: string;
  /** Created At */
  created_at: string;
  /** Updated At */
  updated_at: string;
  /** Is Active */
  is_active: boolean;
  /** Sso Enabled */
  sso_enabled: boolean;
  /** Audit Logs Enabled */
  audit_logs_enabled: boolean;
  /** Api Access Enabled */
  api_access_enabled: boolean;
  /** Member Count */
  member_count: number;
  /** Current User Role */
  current_user_role: string;
}

/** ComparisonRequest */
export interface ComparisonRequest {
  /** Document Ids */
  document_ids: number[];
  /**
   * Comparison Type
   * @default "general"
   */
  comparison_type?: string | null;
  /**
   * Focus Areas
   * @default []
   */
  focus_areas?: string[] | null;
}

/** ComparisonResult */
export interface ComparisonResult {
  /** Documents */
  documents: Record<string, any>[];
  /** Comparisons */
  comparisons: DocumentComparison[];
  /** Summary */
  summary: Record<string, any>;
  /**
   * Generated At
   * @format date-time
   */
  generated_at: string;
}

/** ComplianceMetrics */
export interface ComplianceMetrics {
  /** Documents By Status */
  documents_by_status: Record<string, number>;
  /** Regulatory Updates This Month */
  regulatory_updates_this_month: number;
  /** Compliance Alerts Active */
  compliance_alerts_active: number;
  /** Risk Assessments Completed */
  risk_assessments_completed: number;
  /** User Training Completion */
  user_training_completion: number;
  /** Audit Trail Entries */
  audit_trail_entries: number;
}

/** ComplianceMetricsResponse */
export interface ComplianceMetricsResponse {
  /** Compliance Score */
  compliance_score: number;
  /** Regulatory Coverage */
  regulatory_coverage: number;
  /** Documentation Completeness */
  documentation_completeness: number;
  /** Audit Readiness Score */
  audit_readiness_score: number;
  /** Compliance Gaps */
  compliance_gaps: Record<string, any>[];
  /** Recent Compliance Activities */
  recent_compliance_activities: Record<string, any>[];
}

/** ComponentAnalytics */
export interface ComponentAnalytics {
  /** Component Name */
  component_name: string;
  /** Action Name */
  action_name: string;
  /** Total Usage */
  total_usage: number;
  /** Credits Consumed */
  credits_consumed: number;
  /** Revenue Generated */
  revenue_generated: number;
  /** Avg Cost Per Use */
  avg_cost_per_use: number;
  /** Unique Users */
  unique_users: number;
  /** Last 30 Days Usage */
  last_30_days_usage: number;
  /** Growth Percentage */
  growth_percentage: number;
}

/** ComponentPricing */
export interface ComponentPricing {
  /** Id */
  id: number;
  /** Component Name */
  component_name: string;
  /** Action Name */
  action_name: string;
  /** Credit Cost */
  credit_cost: number;
  /** Is Active */
  is_active: boolean;
  /** Description */
  description?: string | null;
  /**
   * Effective From
   * @format date-time
   */
  effective_from: string;
  /** Effective Until */
  effective_until?: string | null;
}

/** ComponentUsage */
export interface ComponentUsage {
  /** Component Name */
  component_name: string;
  /** Action Name */
  action_name: string;
  /** Total Usage */
  total_usage: number;
  /** Total Cost */
  total_cost: number;
  /** Usage Count */
  usage_count: number;
  /** Avg Cost Per Action */
  avg_cost_per_action: number;
  /**
   * Last Used
   * @format date-time
   */
  last_used: string;
  /** Percentage Of Total */
  percentage_of_total: number;
}

/** ComprehensivePricingAnalytics */
export interface ComprehensivePricingAnalytics {
  overall: OverallAnalytics;
  /** Component Analytics */
  component_analytics: ComponentAnalytics[];
  /** Package Analytics */
  package_analytics: CreditPackageAnalytics[];
  user_analytics: UserConsumptionAnalytics;
  /**
   * Last Updated
   * @format date-time
   */
  last_updated: string;
}

/** ConditionalRule */
export interface ConditionalRule {
  /** Id */
  id: string;
  /** Condition */
  condition: string;
  /** Action */
  action: string;
  /**
   * Priority
   * @default 1
   */
  priority?: number;
}

/** ConsumeCreditsRequest */
export interface ConsumeCreditsRequest {
  /** Component Name */
  component_name: string;
  /** Action Name */
  action_name: string;
  /** Resource Id */
  resource_id?: string | null;
  /** Description */
  description?: string | null;
}

/** ContentItem */
export interface ContentItem {
  /** Id */
  id?: number | null;
  /** Content Type */
  content_type: string;
  /** Module Name */
  module_name: string;
  /** Identifier */
  identifier: string;
  /** Title */
  title: string;
  /** Content */
  content: Record<string, any>;
  /**
   * Is Active
   * @default true
   */
  is_active?: boolean;
  /** Created At */
  created_at?: string | null;
  /** Updated At */
  updated_at?: string | null;
}

/** ContentListResponse */
export interface ContentListResponse {
  /** Items */
  items: ContentItem[];
  /** Total Count */
  total_count: number;
}

/** CountriesResponse */
export interface CountriesResponse {
  /** Countries */
  countries: Country[];
  /** Total */
  total: number;
}

/** Country */
export interface Country {
  /** Id */
  id: number;
  /** Country Code */
  country_code: string;
  /** Country Name */
  country_name: string;
  /** Flag Emoji */
  flag_emoji: string;
  /** Description */
  description: string;
  /** Regulation Summary */
  regulation_summary: string;
}

/** CountryCreateRequest */
export interface CountryCreateRequest {
  /** Name */
  name: string;
  /** Abbreviation */
  abbreviation?: string | null;
  /** Iso Code */
  iso_code?: string | null;
}

/** CountryReportRequest */
export interface CountryReportRequest {
  /** Country Id */
  country_id: number;
  /**
   * Include Executive Summary
   * @default true
   */
  include_executive_summary?: boolean;
  /**
   * Include Detailed Analysis
   * @default true
   */
  include_detailed_analysis?: boolean;
  /**
   * Include Recommendations
   * @default true
   */
  include_recommendations?: boolean;
}

/** CountryRestriction */
export interface CountryRestriction {
  /** Id */
  id: string;
  /** Country Name */
  country_name: string;
  /** Country Code */
  country_code: string;
  /** Region */
  region: string;
  /** Restriction Type */
  restriction_type: string;
  /** Program Name */
  program_name: string;
  /** Issuing Authority */
  issuing_authority: string;
  /** Description */
  description: string;
  /**
   * Restrictions
   * @default []
   */
  restrictions?: string[];
  /**
   * Exemptions
   * @default []
   */
  exemptions?: string[];
  /**
   * Effective Date
   * @format date-time
   */
  effective_date: string;
  /** End Date */
  end_date?: string | null;
  /** Risk Level */
  risk_level: string;
  /**
   * Product Categories
   * @default []
   */
  product_categories?: string[];
  /**
   * Trade Restrictions
   * @default {}
   */
  trade_restrictions?: Record<string, string>;
  /**
   * Last Updated
   * @format date-time
   */
  last_updated: string;
  /** Source Url */
  source_url?: string | null;
  /**
   * Details
   * @default {}
   */
  details?: Record<string, any>;
}

/** CountrySearchFilters */
export interface CountrySearchFilters {
  /** Search Term */
  search_term?: string | null;
  /** Risk Categories */
  risk_categories?: string[] | null;
  /** Has Arms Embargo */
  has_arms_embargo?: boolean | null;
  /** Treaty Compliance */
  treaty_compliance?: string[] | null;
  /** Freedom Score Min */
  freedom_score_min?: number | null;
  /** Freedom Score Max */
  freedom_score_max?: number | null;
}

/** CountrySearchRequest */
export interface CountrySearchRequest {
  /**
   * Query
   * Search query for country name or code
   * @minLength 1
   */
  query: string;
  /**
   * Restriction Type
   * Filter by restriction type
   */
  restriction_type?: string | null;
  /**
   * Issuing Authority
   * Filter by issuing authority
   */
  issuing_authority?: string | null;
  /**
   * Risk Level
   * Filter by risk level
   */
  risk_level?: string | null;
  /**
   * Region
   * Filter by geographic region
   */
  region?: string | null;
  /**
   * Include Expired
   * Include expired restrictions
   * @default false
   */
  include_expired?: boolean;
  /**
   * Product Category
   * Filter by affected product category
   */
  product_category?: string | null;
  /**
   * Limit
   * Maximum number of results
   * @max 100
   * @default 50
   */
  limit?: number;
}

/** CountrySearchResponse */
export interface CountrySearchResponse {
  /** Countries */
  countries: CountryRestriction[];
  /** Total Count */
  total_count: number;
  /** Search Time Ms */
  search_time_ms: number;
  /** Query Used */
  query_used: string;
  /**
   * Suggestions
   * @default []
   */
  suggestions?: string[];
}

/** CountryUpdateRequest */
export interface CountryUpdateRequest {
  /** Name */
  name?: string | null;
  /** Abbreviation */
  abbreviation?: string | null;
  /** Iso Code */
  iso_code?: string | null;
}

/** CreateAnnotationRequest */
export interface CreateAnnotationRequest {
  /** Document Id */
  document_id: number;
  /** Annotation Type */
  annotation_type: string;
  /** Content */
  content: string;
  /** Position Data */
  position_data?: Record<string, any>;
  /**
   * Visibility
   * @default "private"
   */
  visibility?: string;
  /** Parent Id */
  parent_id?: number | null;
  /** Metadata */
  metadata?: Record<string, any>;
}

/** CreateBadgeRequest */
export interface CreateBadgeRequest {
  /** Name */
  name: string;
  /** Description */
  description?: string | null;
  /**
   * Color
   * @default "#3b82f6"
   */
  color?: string;
  /**
   * Category
   * @default "custom"
   */
  category?: string;
  /**
   * Is Active
   * @default true
   */
  is_active?: boolean;
  /**
   * Sort Order
   * @default 0
   */
  sort_order?: number;
}

/** CreateBookmarkRequest */
export interface CreateBookmarkRequest {
  /** Document Id */
  document_id: number;
  /** Section Id */
  section_id?: string | null;
  /** Title */
  title: string;
  /** Description */
  description?: string | null;
  /** Tags */
  tags?: string[];
}

/** CreateCompanyRequest */
export interface CreateCompanyRequest {
  /** Company Name */
  company_name: string;
  /** Company Domain */
  company_domain?: string | null;
  /** Billing Email */
  billing_email?: string | null;
  /**
   * Subscription Tier
   * @default "basic"
   */
  subscription_tier?: string;
  /**
   * Max Team Members
   * @default 10
   */
  max_team_members?: number;
}

/** CreateContentRequest */
export interface CreateContentRequest {
  /** Content Type */
  content_type: string;
  /** Module Name */
  module_name: string;
  /** Identifier */
  identifier: string;
  /** Title */
  title: string;
  /** Content */
  content: Record<string, any>;
  /**
   * Is Active
   * @default true
   */
  is_active?: boolean;
}

/** CreateCreditPackageRequest */
export interface CreateCreditPackageRequest {
  /** Name */
  name: string;
  /** Credits */
  credits: number;
  /** Price Cents */
  price_cents: number;
  /**
   * Currency
   * @default "EUR"
   */
  currency?: string;
  /**
   * Discount Percentage
   * @default 0
   */
  discount_percentage?: number;
  /**
   * Is Active
   * @default true
   */
  is_active?: boolean;
  /**
   * Expiry Months
   * @default 12
   */
  expiry_months?: number;
}

/** CreateInvoiceRequest */
export interface CreateInvoiceRequest {
  /** Company Id */
  company_id: number;
  /** Line Items */
  line_items: AppApisBillingManagementInvoiceLineItem[];
  /** Billing Address */
  billing_address: Record<string, any>;
  /** Notes */
  notes?: string | null;
  /**
   * Due Days
   * @default 30
   */
  due_days?: number;
}

/** CreateMetadataOptionRequest */
export interface CreateMetadataOptionRequest {
  /** Category */
  category: string;
  /** Value */
  value: string;
  /** Display Name */
  display_name: string;
  /** Display Order */
  display_order?: number | null;
}

/** CreateMonitoringScheduleRequest */
export interface CreateMonitoringScheduleRequest {
  /** Schedule Name */
  schedule_name: string;
  /** Schedule Type */
  schedule_type: string;
  /**
   * Frequency Value
   * @default 1
   */
  frequency_value?: number | null;
  /** Target Type */
  target_type: string;
  /** Target Customers */
  target_customers?: string[] | null;
}

/** CreateNoteRequest */
export interface CreateNoteRequest {
  /** Note Key */
  note_key: string;
  /** Title */
  title: string;
  /** Content */
  content: string;
  /** Tree Id */
  tree_id?: string | null;
  /**
   * Module Type
   * @default "product_classification"
   */
  module_type?: string;
}

/** CreatePricingRequest */
export interface CreatePricingRequest {
  /** Component Name */
  component_name: string;
  /** Action Name */
  action_name: string;
  /** Credit Cost */
  credit_cost: number;
  /**
   * Is Active
   * @default true
   */
  is_active?: boolean;
  /** Description */
  description?: string | null;
}

/** CreateRestrictiveMeasureRequest */
export interface CreateRestrictiveMeasureRequest {
  /** Regulation Reference */
  regulation_reference: string;
  /** Article Number */
  article_number?: string | null;
  /** Measure Type */
  measure_type: string;
  /** Measure Description */
  measure_description: string;
  /** Jurisdiction */
  jurisdiction: string;
  /** Authority */
  authority?: string | null;
  /** Effective Date */
  effective_date: string;
  /** Expiry Date */
  expiry_date?: string | null;
}

/** CreateSectionRequest */
export interface CreateSectionRequest {
  /** Document Id */
  document_id: number;
  /** Section Number */
  section_number?: string | null;
  /** Section Title */
  section_title?: string | null;
  /** Section Content */
  section_content?: string | null;
  /** Parent Section Id */
  parent_section_id?: number | null;
  /**
   * Display Order
   * @default 0
   */
  display_order?: number;
}

/** CreateTemplateRequest */
export interface CreateTemplateRequest {
  /** Title */
  title: string;
  /** Description */
  description: string;
  /** How It Works */
  how_it_works?: string | null;
  /** Sections */
  sections: SectionModel[];
}

/** CreateThreadRequest */
export interface CreateThreadRequest {
  /** Title */
  title: string;
  /** Description */
  description?: string | null;
}

/** CreateTradeCodeRequest */
export interface CreateTradeCodeRequest {
  /** Hs Code */
  hs_code: string;
  /** Cn Code */
  cn_code?: string | null;
  /** Description */
  description: string;
  /** Category */
  category?: string | null;
  /** Subcategory */
  subcategory?: string | null;
  /** Unit Of Measure */
  unit_of_measure?: string | null;
}

/** CreateUserRequest */
export interface CreateUserRequest {
  /** Email */
  email: string;
  /** Contact Person */
  contact_person: string;
  /** Company Name */
  company_name?: string | null;
  /** Phone */
  phone?: string | null;
  /** Country */
  country?: string | null;
  /** Billing Address */
  billing_address?: string | null;
  /** City */
  city?: string | null;
  /** Postal Code */
  postal_code?: string | null;
  /** Tax Id */
  tax_id?: string | null;
  /** Vat Number */
  vat_number?: string | null;
}

/** CreateWidgetRequest */
export interface CreateWidgetRequest {
  template: WidgetTemplate;
}

/** CreditBalance */
export interface CreditBalance {
  /** User Id */
  user_id: string;
  /** Current Balance */
  current_balance: number;
  /** Lifetime Purchased */
  lifetime_purchased: number;
  /** Lifetime Consumed */
  lifetime_consumed: number;
}

/** CreditPackage */
export interface CreditPackage {
  /** Id */
  id: number;
  /** Name */
  name: string;
  /** Credits */
  credits: number;
  /** Price Cents */
  price_cents: number;
  /** Currency */
  currency: string;
  /** Discount Percentage */
  discount_percentage: number;
  /** Is Active */
  is_active: boolean;
  /** Expiry Months */
  expiry_months: number;
}

/** CreditPackageAnalytics */
export interface CreditPackageAnalytics {
  /** Package Name */
  package_name: string;
  /** Package Id */
  package_id: number;
  /** Total Sales */
  total_sales: number;
  /** Credits Sold */
  credits_sold: number;
  /** Revenue Generated */
  revenue_generated: number;
  /** Avg Purchase Size */
  avg_purchase_size: number;
  /** Popular Rank */
  popular_rank: number;
  /** Conversion Rate */
  conversion_rate: number;
}

/** CreditTransaction */
export interface CreditTransaction {
  /** Id */
  id: number;
  /** Transaction Type */
  transaction_type: string;
  /** Amount */
  amount: number;
  /** Balance After */
  balance_after: number;
  /** Description */
  description?: string | null;
  /** Component Name */
  component_name?: string | null;
  /** Action Name */
  action_name?: string | null;
  /** Resource Id */
  resource_id?: string | null;
  /**
   * Created At
   * @format date-time
   */
  created_at: string;
}

/** CriticalCountry */
export interface CriticalCountry {
  /** Id */
  id: number;
  /** Country Name */
  country_name: string;
  /** Abbreviation */
  abbreviation?: string | null;
  /** Iso Code */
  iso_code?: string | null;
  /**
   * Is Active
   * @default true
   */
  is_active?: boolean;
  /** Risk Level */
  risk_level?: string | null;
  /** Risk Categories */
  risk_categories?: Record<string, any> | null;
  /** Risk Description */
  risk_description?: string | null;
  /** Last Risk Assessment Date */
  last_risk_assessment_date?: string | null;
  /** Export Control Wassenaar */
  export_control_wassenaar?: boolean | null;
  /** Export Control Nsg */
  export_control_nsg?: boolean | null;
  /** Export Control Ag */
  export_control_ag?: boolean | null;
  /** Export Control Mtcr */
  export_control_mtcr?: boolean | null;
  /** Export Control Zc */
  export_control_zc?: boolean | null;
  /** Export Control Notes */
  export_control_notes?: string | null;
  /** Export Control Risk */
  export_control_risk?: string | null;
  /** Sanctions */
  sanctions?: boolean | null;
  /** Sanctions Notes */
  sanctions_notes?: string | null;
  /** Sanctions Risk */
  sanctions_risk?: string | null;
  /** Un Arms Embargo */
  un_arms_embargo?: boolean | null;
  /** Un Arms Embargo Notes */
  un_arms_embargo_notes?: string | null;
  /** Us Arms Embargo */
  us_arms_embargo?: boolean | null;
  /** Us Arms Embargo Notes */
  us_arms_embargo_notes?: string | null;
  /** Eu Arms Embargo */
  eu_arms_embargo?: boolean | null;
  /** Eu Arms Embargo Notes */
  eu_arms_embargo_notes?: string | null;
  /** Other Arms Embargo */
  other_arms_embargo?: boolean | null;
  /** Other Arms Embargo Notes */
  other_arms_embargo_notes?: string | null;
  /** Arms Risk */
  arms_risk?: string | null;
  /** Cwc 1993 Signatory */
  cwc_1993_signatory?: boolean | null;
  /** Cwc 1993 Ratified */
  cwc_1993_ratified?: boolean | null;
  /** Cwc Violations */
  cwc_violations?: boolean | null;
  /** Chemical Risk */
  chemical_risk?: string | null;
  /** Bwc 1972 Signatory */
  bwc_1972_signatory?: boolean | null;
  /** Bwc 1972 Ratified */
  bwc_1972_ratified?: boolean | null;
  /** Bwc Violations */
  bwc_violations?: boolean | null;
  /** Biological Risk */
  biological_risk?: string | null;
  /** Npt Signatory */
  npt_signatory?: boolean | null;
  /** Npt Ratified */
  npt_ratified?: boolean | null;
  /** Npt Notes */
  npt_notes?: string | null;
  /** Ctbt Signatory */
  ctbt_signatory?: boolean | null;
  /** Ctbt Ratified */
  ctbt_ratified?: boolean | null;
  /** Ctbt Notes */
  ctbt_notes?: string | null;
  /** Iaea Signatory */
  iaea_signatory?: boolean | null;
  /** Iaea Ratified */
  iaea_ratified?: boolean | null;
  /** Iaea Notes */
  iaea_notes?: string | null;
  /** Nsg 1974 Signatory */
  nsg_1974_signatory?: boolean | null;
  /** Nsg 1974 Ratified */
  nsg_1974_ratified?: boolean | null;
  /** Nsg Notes */
  nsg_notes?: string | null;
  /** Conv 1980 Signatory */
  conv_1980_signatory?: boolean | null;
  /** Conv 1980 Ratified */
  conv_1980_ratified?: boolean | null;
  /** Conv 1980 Notes */
  conv_1980_notes?: string | null;
  /** Conv 1994 Signatory */
  conv_1994_signatory?: boolean | null;
  /** Conv 1994 Ratified */
  conv_1994_ratified?: boolean | null;
  /** Conv 1994 Notes */
  conv_1994_notes?: string | null;
  /** Nuclear Violations */
  nuclear_violations?: boolean | null;
  /** Nuclear Risk */
  nuclear_risk?: string | null;
  /** Human Rights */
  human_rights?: string | null;
  /** Human Rights Note */
  human_rights_note?: string | null;
  /** Human Rights Risk Score */
  human_rights_risk_score?: number | null;
  /** Political Rights */
  political_rights?: string | null;
  /** Civil Liberties */
  civil_liberties?: string | null;
  /** Freedom In The World */
  freedom_in_the_world?: boolean | null;
  /** Freedom Note */
  freedom_note?: string | null;
  /** Freedom Risk */
  freedom_risk?: string | null;
  /** Obstacles To Access */
  obstacles_to_access?: string | null;
  /** Limits On Content */
  limits_on_content?: string | null;
  /** Violations Of User Rights */
  violations_of_user_rights?: string | null;
  /** Freedom Net Note */
  freedom_net_note?: string | null;
  /** Freedom Net Risk */
  freedom_net_risk?: string | null;
  /** Democracy Status */
  democracy_status?: string | null;
  /** Democracy Percentage */
  democracy_percentage?: string | null;
  /** Nations In Transit */
  nations_in_transit?: string | null;
  /** Regime Type */
  regime_type?: string | null;
  /** Human Rights Freedoms Risk */
  human_rights_freedoms_risk?: string | null;
  /** Created At */
  created_at?: string | null;
  /** Updated At */
  updated_at?: string | null;
  /** Created By */
  created_by?: string | null;
  /** Updated By */
  updated_by?: string | null;
  /** Notes */
  notes?: string | null;
}

/** CriticalCountryCreate */
export interface CriticalCountryCreate {
  /** Name */
  name: string;
  /** Abbreviation */
  abbreviation?: string | null;
  /** Iso Code */
  iso_code?: string | null;
  /** Notes */
  notes?: string | null;
  /**
   * Status
   * @default "active"
   */
  status?: string;
  /** Last Assessed */
  last_assessed?: string | null;
  /**
   * Wassenaar Arrangement
   * @default false
   */
  wassenaar_arrangement?: boolean;
  /**
   * Nuclear Suppliers Group
   * @default false
   */
  nuclear_suppliers_group?: boolean;
  /**
   * Australia Group
   * @default false
   */
  australia_group?: boolean;
  /**
   * Missile Technology Control Regime
   * @default false
   */
  missile_technology_control_regime?: boolean;
  /**
   * Zangger Committee
   * @default false
   */
  zangger_committee?: boolean;
  /** Export Control Notes */
  export_control_notes?: string | null;
  /**
   * Export Control Risk
   * @default "low"
   */
  export_control_risk?: string;
  /** Sanctions Status */
  sanctions_status?: string | null;
  /** Sanctions Notes */
  sanctions_notes?: string | null;
  /**
   * Sanctions Risk
   * @default "low"
   */
  sanctions_risk?: string;
  /**
   * Un Arms Embargo
   * @default false
   */
  un_arms_embargo?: boolean;
  /** Un Arms Embargo Notes */
  un_arms_embargo_notes?: string | null;
  /**
   * Us Arms Embargo
   * @default false
   */
  us_arms_embargo?: boolean;
  /** Us Arms Embargo Notes */
  us_arms_embargo_notes?: string | null;
  /**
   * Eu Arms Embargo
   * @default false
   */
  eu_arms_embargo?: boolean;
  /** Eu Arms Embargo Notes */
  eu_arms_embargo_notes?: string | null;
  /**
   * Other Arms Embargo
   * @default false
   */
  other_arms_embargo?: boolean;
  /** Other Arms Embargo Notes */
  other_arms_embargo_notes?: string | null;
  /**
   * Arms Risk
   * @default "low"
   */
  arms_risk?: string;
  /**
   * Cwc 1993 Signatory
   * @default false
   */
  cwc_1993_signatory?: boolean;
  /**
   * Cwc 1993 Ratified
   * @default false
   */
  cwc_1993_ratified?: boolean;
  /**
   * Cwc Violations
   * @default false
   */
  cwc_violations?: boolean;
  /**
   * Chemical Risk
   * @default "low"
   */
  chemical_risk?: string;
  /**
   * Bwc 1972 Signatory
   * @default false
   */
  bwc_1972_signatory?: boolean;
  /**
   * Bwc 1972 Ratified
   * @default false
   */
  bwc_1972_ratified?: boolean;
  /**
   * Bwc Violations
   * @default false
   */
  bwc_violations?: boolean;
  /**
   * Biological Risk
   * @default "low"
   */
  biological_risk?: string;
  /**
   * Npt Signatory
   * @default false
   */
  npt_signatory?: boolean;
  /**
   * Npt Ratified
   * @default false
   */
  npt_ratified?: boolean;
  /** Npt Notes */
  npt_notes?: string | null;
  /**
   * Ctbt Signatory
   * @default false
   */
  ctbt_signatory?: boolean;
  /**
   * Ctbt Ratified
   * @default false
   */
  ctbt_ratified?: boolean;
  /** Ctbt Notes */
  ctbt_notes?: string | null;
  /**
   * Iaea Signatory
   * @default false
   */
  iaea_signatory?: boolean;
  /**
   * Iaea Ratified
   * @default false
   */
  iaea_ratified?: boolean;
  /** Iaea Notes */
  iaea_notes?: string | null;
  /**
   * Nsg 1974 Signatory
   * @default false
   */
  nsg_1974_signatory?: boolean;
  /**
   * Nsg 1974 Ratified
   * @default false
   */
  nsg_1974_ratified?: boolean;
  /**
   * Convention 1980 Signatory
   * @default false
   */
  convention_1980_signatory?: boolean;
  /**
   * Convention 1980 Ratified
   * @default false
   */
  convention_1980_ratified?: boolean;
  /**
   * Convention 1994 Signatory
   * @default false
   */
  convention_1994_signatory?: boolean;
  /**
   * Convention 1994 Ratified
   * @default false
   */
  convention_1994_ratified?: boolean;
  /**
   * Nuclear Violations
   * @default false
   */
  nuclear_violations?: boolean;
  /**
   * Nuclear Risk
   * @default "low"
   */
  nuclear_risk?: string;
  /**
   * Human Rights Score
   * @default 50
   */
  human_rights_score?: number;
  /** Human Rights Notes */
  human_rights_notes?: string | null;
  /**
   * Human Rights Risk
   * @default "low"
   */
  human_rights_risk?: string;
  /**
   * Political Rights Score
   * @default 50
   */
  political_rights_score?: number;
  /**
   * Civil Liberties Score
   * @default 50
   */
  civil_liberties_score?: number;
  /** Freedom In The World */
  freedom_in_the_world?: string | null;
  /** Freedom Note */
  freedom_note?: string | null;
  /**
   * Freedom Risk
   * @default "low"
   */
  freedom_risk?: string;
  /** Obstacles To Access */
  obstacles_to_access?: string | null;
  /** Limits On Content */
  limits_on_content?: string | null;
  /** Violations Of User Rights */
  violations_of_user_rights?: string | null;
  /** Freedom Net Note */
  freedom_net_note?: string | null;
  /**
   * Freedom Net Risk
   * @default "low"
   */
  freedom_net_risk?: string;
  /** Democracy Status */
  democracy_status?: string | null;
  /** Democracy Percentage */
  democracy_percentage?: number | null;
  /** Nations In Transit */
  nations_in_transit?: string | null;
  /** Regime Type */
  regime_type?: string | null;
  /**
   * Human Rights Freedoms Risk
   * @default "low"
   */
  human_rights_freedoms_risk?: string;
  /** Varieties Of Democracy */
  varieties_of_democracy?: string | null;
  /**
   * Risk Level
   * @default "medium"
   */
  risk_level?: string;
  /**
   * Is Active
   * @default true
   */
  is_active?: boolean;
}

/** CriticalCountryResponse */
export interface CriticalCountryResponse {
  /** Id */
  id: string;
  /** Name */
  name: string;
  /** Abbreviation */
  abbreviation?: string | null;
  /** Iso Code */
  iso_code?: string | null;
  /** Notes */
  notes?: string | null;
  /**
   * Status
   * @default "active"
   */
  status?: string;
  /** Last Assessed */
  last_assessed?: string | null;
  /**
   * Wassenaar Arrangement
   * @default false
   */
  wassenaar_arrangement?: boolean;
  /**
   * Nuclear Suppliers Group
   * @default false
   */
  nuclear_suppliers_group?: boolean;
  /**
   * Australia Group
   * @default false
   */
  australia_group?: boolean;
  /**
   * Missile Technology Control Regime
   * @default false
   */
  missile_technology_control_regime?: boolean;
  /**
   * Zangger Committee
   * @default false
   */
  zangger_committee?: boolean;
  /** Export Control Notes */
  export_control_notes?: string | null;
  /**
   * Export Control Risk
   * @default "low"
   */
  export_control_risk?: string;
  /** Sanctions Status */
  sanctions_status?: string | null;
  /** Sanctions Notes */
  sanctions_notes?: string | null;
  /**
   * Sanctions Risk
   * @default "low"
   */
  sanctions_risk?: string;
  /**
   * Un Arms Embargo
   * @default false
   */
  un_arms_embargo?: boolean;
  /** Un Arms Embargo Notes */
  un_arms_embargo_notes?: string | null;
  /**
   * Us Arms Embargo
   * @default false
   */
  us_arms_embargo?: boolean;
  /** Us Arms Embargo Notes */
  us_arms_embargo_notes?: string | null;
  /**
   * Eu Arms Embargo
   * @default false
   */
  eu_arms_embargo?: boolean;
  /** Eu Arms Embargo Notes */
  eu_arms_embargo_notes?: string | null;
  /**
   * Other Arms Embargo
   * @default false
   */
  other_arms_embargo?: boolean;
  /** Other Arms Embargo Notes */
  other_arms_embargo_notes?: string | null;
  /**
   * Arms Risk
   * @default "low"
   */
  arms_risk?: string;
  /**
   * Cwc 1993 Signatory
   * @default false
   */
  cwc_1993_signatory?: boolean;
  /**
   * Cwc 1993 Ratified
   * @default false
   */
  cwc_1993_ratified?: boolean;
  /**
   * Cwc Violations
   * @default false
   */
  cwc_violations?: boolean;
  /**
   * Chemical Risk
   * @default "low"
   */
  chemical_risk?: string;
  /**
   * Bwc 1972 Signatory
   * @default false
   */
  bwc_1972_signatory?: boolean;
  /**
   * Bwc 1972 Ratified
   * @default false
   */
  bwc_1972_ratified?: boolean;
  /**
   * Bwc Violations
   * @default false
   */
  bwc_violations?: boolean;
  /**
   * Biological Risk
   * @default "low"
   */
  biological_risk?: string;
  /**
   * Npt Signatory
   * @default false
   */
  npt_signatory?: boolean;
  /**
   * Npt Ratified
   * @default false
   */
  npt_ratified?: boolean;
  /** Npt Notes */
  npt_notes?: string | null;
  /**
   * Ctbt Signatory
   * @default false
   */
  ctbt_signatory?: boolean;
  /**
   * Ctbt Ratified
   * @default false
   */
  ctbt_ratified?: boolean;
  /** Ctbt Notes */
  ctbt_notes?: string | null;
  /**
   * Iaea Signatory
   * @default false
   */
  iaea_signatory?: boolean;
  /**
   * Iaea Ratified
   * @default false
   */
  iaea_ratified?: boolean;
  /** Iaea Notes */
  iaea_notes?: string | null;
  /**
   * Nsg 1974 Signatory
   * @default false
   */
  nsg_1974_signatory?: boolean;
  /**
   * Nsg 1974 Ratified
   * @default false
   */
  nsg_1974_ratified?: boolean;
  /**
   * Convention 1980 Signatory
   * @default false
   */
  convention_1980_signatory?: boolean;
  /**
   * Convention 1980 Ratified
   * @default false
   */
  convention_1980_ratified?: boolean;
  /**
   * Convention 1994 Signatory
   * @default false
   */
  convention_1994_signatory?: boolean;
  /**
   * Convention 1994 Ratified
   * @default false
   */
  convention_1994_ratified?: boolean;
  /**
   * Nuclear Violations
   * @default false
   */
  nuclear_violations?: boolean;
  /**
   * Nuclear Risk
   * @default "low"
   */
  nuclear_risk?: string;
  /**
   * Human Rights Score
   * @default 50
   */
  human_rights_score?: number;
  /** Human Rights Notes */
  human_rights_notes?: string | null;
  /**
   * Human Rights Risk
   * @default "low"
   */
  human_rights_risk?: string;
  /**
   * Political Rights Score
   * @default 50
   */
  political_rights_score?: number;
  /**
   * Civil Liberties Score
   * @default 50
   */
  civil_liberties_score?: number;
  /** Freedom In The World */
  freedom_in_the_world?: string | null;
  /** Freedom Note */
  freedom_note?: string | null;
  /**
   * Freedom Risk
   * @default "low"
   */
  freedom_risk?: string;
  /** Obstacles To Access */
  obstacles_to_access?: string | null;
  /** Limits On Content */
  limits_on_content?: string | null;
  /** Violations Of User Rights */
  violations_of_user_rights?: string | null;
  /** Freedom Net Note */
  freedom_net_note?: string | null;
  /**
   * Freedom Net Risk
   * @default "low"
   */
  freedom_net_risk?: string;
  /** Democracy Status */
  democracy_status?: string | null;
  /** Democracy Percentage */
  democracy_percentage?: number | null;
  /** Nations In Transit */
  nations_in_transit?: string | null;
  /** Regime Type */
  regime_type?: string | null;
  /**
   * Human Rights Freedoms Risk
   * @default "low"
   */
  human_rights_freedoms_risk?: string;
  /** Varieties Of Democracy */
  varieties_of_democracy?: string | null;
  /**
   * Risk Level
   * @default "medium"
   */
  risk_level?: string;
  /**
   * Is Active
   * @default true
   */
  is_active?: boolean;
  /** Created At */
  created_at?: string | null;
  /** Updated At */
  updated_at?: string | null;
}

/** CriticalCountryUpdate */
export interface CriticalCountryUpdate {
  /** Name */
  name?: string | null;
  /** Abbreviation */
  abbreviation?: string | null;
  /** Iso Code */
  iso_code?: string | null;
  /** Notes */
  notes?: string | null;
  /** Status */
  status?: string | null;
  /** Last Assessed */
  last_assessed?: string | null;
  /** Wassenaar Arrangement */
  wassenaar_arrangement?: boolean | null;
  /** Nuclear Suppliers Group */
  nuclear_suppliers_group?: boolean | null;
  /** Australia Group */
  australia_group?: boolean | null;
  /** Missile Technology Control Regime */
  missile_technology_control_regime?: boolean | null;
  /** Zangger Committee */
  zangger_committee?: boolean | null;
  /** Export Control Notes */
  export_control_notes?: string | null;
  /** Export Control Risk */
  export_control_risk?: string | null;
  /** Sanctions Status */
  sanctions_status?: string | null;
  /** Sanctions Notes */
  sanctions_notes?: string | null;
  /** Sanctions Risk */
  sanctions_risk?: string | null;
  /** Un Arms Embargo */
  un_arms_embargo?: boolean | null;
  /** Un Arms Embargo Notes */
  un_arms_embargo_notes?: string | null;
  /** Us Arms Embargo */
  us_arms_embargo?: boolean | null;
  /** Us Arms Embargo Notes */
  us_arms_embargo_notes?: string | null;
  /** Eu Arms Embargo */
  eu_arms_embargo?: boolean | null;
  /** Eu Arms Embargo Notes */
  eu_arms_embargo_notes?: string | null;
  /** Other Arms Embargo */
  other_arms_embargo?: boolean | null;
  /** Other Arms Embargo Notes */
  other_arms_embargo_notes?: string | null;
  /** Arms Risk */
  arms_risk?: string | null;
  /** Cwc 1993 Signatory */
  cwc_1993_signatory?: boolean | null;
  /** Cwc 1993 Ratified */
  cwc_1993_ratified?: boolean | null;
  /** Cwc Violations */
  cwc_violations?: boolean | null;
  /** Chemical Risk */
  chemical_risk?: string | null;
  /** Bwc 1972 Signatory */
  bwc_1972_signatory?: boolean | null;
  /** Bwc 1972 Ratified */
  bwc_1972_ratified?: boolean | null;
  /** Bwc Violations */
  bwc_violations?: boolean | null;
  /** Biological Risk */
  biological_risk?: string | null;
  /** Npt Signatory */
  npt_signatory?: boolean | null;
  /** Npt Ratified */
  npt_ratified?: boolean | null;
  /** Npt Notes */
  npt_notes?: string | null;
  /** Ctbt Signatory */
  ctbt_signatory?: boolean | null;
  /** Ctbt Ratified */
  ctbt_ratified?: boolean | null;
  /** Ctbt Notes */
  ctbt_notes?: string | null;
  /** Iaea Signatory */
  iaea_signatory?: boolean | null;
  /** Iaea Ratified */
  iaea_ratified?: boolean | null;
  /** Iaea Notes */
  iaea_notes?: string | null;
  /** Nsg 1974 Signatory */
  nsg_1974_signatory?: boolean | null;
  /** Nsg 1974 Ratified */
  nsg_1974_ratified?: boolean | null;
  /** Convention 1980 Signatory */
  convention_1980_signatory?: boolean | null;
  /** Convention 1980 Ratified */
  convention_1980_ratified?: boolean | null;
  /** Convention 1994 Signatory */
  convention_1994_signatory?: boolean | null;
  /** Convention 1994 Ratified */
  convention_1994_ratified?: boolean | null;
  /** Nuclear Violations */
  nuclear_violations?: boolean | null;
  /** Nuclear Risk */
  nuclear_risk?: string | null;
  /** Human Rights Score */
  human_rights_score?: number | null;
  /** Human Rights Notes */
  human_rights_notes?: string | null;
  /** Human Rights Risk */
  human_rights_risk?: string | null;
  /** Political Rights Score */
  political_rights_score?: number | null;
  /** Civil Liberties Score */
  civil_liberties_score?: number | null;
  /** Freedom In The World */
  freedom_in_the_world?: string | null;
  /** Freedom Note */
  freedom_note?: string | null;
  /** Freedom Risk */
  freedom_risk?: string | null;
  /** Obstacles To Access */
  obstacles_to_access?: string | null;
  /** Limits On Content */
  limits_on_content?: string | null;
  /** Violations Of User Rights */
  violations_of_user_rights?: string | null;
  /** Freedom Net Note */
  freedom_net_note?: string | null;
  /** Freedom Net Risk */
  freedom_net_risk?: string | null;
  /** Democracy Status */
  democracy_status?: string | null;
  /** Democracy Percentage */
  democracy_percentage?: number | null;
  /** Nations In Transit */
  nations_in_transit?: string | null;
  /** Regime Type */
  regime_type?: string | null;
  /** Human Rights Freedoms Risk */
  human_rights_freedoms_risk?: string | null;
  /** Varieties Of Democracy */
  varieties_of_democracy?: string | null;
  /** Risk Level */
  risk_level?: string | null;
  /** Is Active */
  is_active?: boolean | null;
}

/** CriticalProductSearchResult */
export interface CriticalProductSearchResult {
  /** Id */
  id: string;
  /** Hs Code */
  hs_code: string;
  /** Cn Code */
  cn_code?: string | null;
  /** Description */
  description: string;
  /** Category */
  category?: string | null;
  /** Subcategory */
  subcategory?: string | null;
  /**
   * Restrictions
   * @default []
   */
  restrictions?: Record<string, any>[];
  /** Risk Level */
  risk_level?: string | null;
  /** Match Type */
  match_type: string;
}

/** CrossReferenceRequest */
export interface CrossReferenceRequest {
  /** Target Document Id */
  target_document_id: number;
  /**
   * Reference Type
   * @default "related"
   */
  reference_type?: string;
  /** Reference Text */
  reference_text: string;
  /** Context */
  context?: string | null;
  /**
   * Confidence Score
   * @default 0.8
   */
  confidence_score?: number;
}

/** CrossReferenceResponse */
export interface CrossReferenceResponse {
  /** Id */
  id: number;
  /** Title */
  title: string;
  /** Description */
  description?: string | null;
  /** Country Jurisdiction */
  country_jurisdiction?: string[] | null;
  /** Regulation Type */
  regulation_type?: string[] | null;
  /** Reference Text */
  reference_text: string;
  /** Reference Type */
  reference_type: string;
  /** Relevance Score */
  relevance_score: number;
}

/** CrossReferencesResponse */
export interface CrossReferencesResponse {
  /** Document Id */
  document_id: string;
  /** Cross References */
  cross_references: AppApisDocumentProcessingCrossReference[];
  /** Total References */
  total_references: number;
}

/** CustomerDetails */
export interface CustomerDetails {
  /** Company Name */
  company_name: string;
  /** Contact Person */
  contact_person: string;
  /** Email */
  email: string;
  /** Phone */
  phone?: string | null;
  /** Billing Address */
  billing_address: string;
  /** City */
  city: string;
  /** Postal Code */
  postal_code: string;
  /** Country */
  country: string;
  /** Tax Id */
  tax_id?: string | null;
  /** Vat Number */
  vat_number?: string | null;
}

/** CustomerMonitoringAnalytics */
export interface CustomerMonitoringAnalytics {
  /** By Risk Level */
  by_risk_level: Record<string, number>;
  /** By Type */
  by_type: Record<string, number>;
  /** By Geography */
  by_geography: Record<string, number>;
  /** Screening Success Rate */
  screening_success_rate: number;
  /** Average Screening Time */
  average_screening_time: number;
  /** Total Screenings Last 30 Days */
  total_screenings_last_30_days: number;
}

/** CustomerMonitoringStatus */
export interface CustomerMonitoringStatus {
  /** Customer Id */
  customer_id: string;
  /** Customer Name */
  customer_name: string;
  /** Risk Level */
  risk_level: string;
  /** Last Monitored */
  last_monitored: string | null;
  /** Next Monitoring */
  next_monitoring: string | null;
  /** Monitoring Active */
  monitoring_active: boolean;
  /** Recent Changes */
  recent_changes?: Record<string, any>[];
  /**
   * Alert Count
   * @default 0
   */
  alert_count?: number;
  /** Last Screening Result */
  last_screening_result?: Record<string, any> | null;
}

/**
 * CustomerProduct
 * Customer product/technology information
 */
export interface CustomerProduct {
  /** Id */
  id?: number | null;
  /** Customer Id */
  customer_id: number;
  /**
   * Product Name
   * @minLength 1
   * @maxLength 500
   */
  product_name: string;
  /** Product Category */
  product_category?: string | null;
  /**
   * Product Type
   * @pattern ^(goods|technology|software|service|dual_use)$
   */
  product_type: string;
  /** Eccn Classification */
  eccn_classification?: string | null;
  /** Ccl Category */
  ccl_category?: string | null;
  /** Description */
  description?: string | null;
  /** Technical Specifications */
  technical_specifications?: string | null;
  /**
   * Control Status
   * @default "uncontrolled"
   * @pattern ^(uncontrolled|controlled|restricted|prohibited)$
   */
  control_status?: string;
  /**
   * Export License Required
   * @default false
   */
  export_license_required?: boolean;
  /**
   * End Use Statement Required
   * @default false
   */
  end_use_statement_required?: boolean;
  /** Risk Assessment */
  risk_assessment?: Record<string, any>;
  /** Compliance Notes */
  compliance_notes?: string | null;
  /** Last Review Date */
  last_review_date?: string | null;
  /** Next Review Date */
  next_review_date?: string | null;
  /** Created By */
  created_by?: string | null;
  /** Created At */
  created_at?: string | null;
  /** Updated At */
  updated_at?: string | null;
}

/**
 * CustomerProfile
 * Customer profile information for screening
 */
export interface CustomerProfile {
  /** Id */
  id?: number | null;
  /**
   * Customer Name
   * @minLength 1
   * @maxLength 500
   */
  customer_name: string;
  /**
   * Customer Type
   * @default "individual"
   */
  customer_type?: string;
  /** Legal Name */
  legal_name?: string | null;
  /** Aliases */
  aliases?: string[];
  /** Address */
  address?: string | null;
  /** City */
  city?: string | null;
  /** Country */
  country?: string | null;
  /** Postal Code */
  postal_code?: string | null;
  /** Date Of Birth */
  date_of_birth?: string | null;
  /** Incorporation Date */
  incorporation_date?: string | null;
  /** Registration Number */
  registration_number?: string | null;
  /** Tax Id */
  tax_id?: string | null;
  /** Phone */
  phone?: string | null;
  /** Email */
  email?: string | null;
  /** Website */
  website?: string | null;
  /** Business Type */
  business_type?: string | null;
  /**
   * Risk Category
   * @default "standard"
   */
  risk_category?: string;
  /** Notes */
  notes?: string | null;
  /** Created By */
  created_by?: string | null;
  /** Created At */
  created_at?: string | null;
  /** Updated At */
  updated_at?: string | null;
}

/** CustomerRiskPrediction */
export interface CustomerRiskPrediction {
  /** Customer Id */
  customer_id: number;
  /** Customer Name */
  customer_name: string;
  /** Current Risk Level */
  current_risk_level: string;
  /** Current Risk Score */
  current_risk_score: number;
  /** Predicted Risk Level */
  predicted_risk_level: string;
  /** Predicted Risk Score */
  predicted_risk_score: number;
  /** Confidence Score */
  confidence_score: number;
  /** Risk Trend */
  risk_trend: string;
  /** Key Risk Factors */
  key_risk_factors: string[];
  /**
   * Prediction Date
   * @format date-time
   */
  prediction_date: string;
  /**
   * Next Review Date
   * @format date-time
   */
  next_review_date: string;
}

/** CustomerRiskUpdate */
export interface CustomerRiskUpdate {
  /** Customer Id */
  customer_id: number;
  /** Name */
  name: string;
  /** Previous Risk Level */
  previous_risk_level: string;
  /** New Risk Level */
  new_risk_level: string;
  /** New Risk Score */
  new_risk_score: number;
}

/**
 * CustomerTransaction
 * Customer transaction information
 */
export interface CustomerTransactionInput {
  /** Id */
  id?: number | null;
  /** Customer Id */
  customer_id: number;
  /**
   * Transaction Type
   * @pattern ^(export|import|domestic|transfer|service)$
   */
  transaction_type: string;
  /**
   * Transaction Date
   * @format date
   */
  transaction_date: string;
  /** Transaction Reference */
  transaction_reference?: string | null;
  /** Transaction Value */
  transaction_value?: number | string | null;
  /**
   * Currency
   * @maxLength 3
   * @default "EUR"
   */
  currency?: string;
  /** Description */
  description?: string | null;
  /**
   * Status
   * @default "pending"
   * @pattern ^(pending|approved|rejected|completed|cancelled)$
   */
  status?: string;
  /**
   * Risk Level
   * @default "standard"
   * @pattern ^(low|standard|high|critical)$
   */
  risk_level?: string;
  /** Compliance Notes */
  compliance_notes?: string | null;
  /** Documents Required */
  documents_required?: string[];
  /**
   * License Required
   * @default false
   */
  license_required?: boolean;
  /** License Number */
  license_number?: string | null;
  /** Created By */
  created_by?: string | null;
  /** Created At */
  created_at?: string | null;
  /** Updated At */
  updated_at?: string | null;
}

/**
 * CustomerTransaction
 * Customer transaction information
 */
export interface CustomerTransactionOutput {
  /** Id */
  id?: number | null;
  /** Customer Id */
  customer_id: number;
  /**
   * Transaction Type
   * @pattern ^(export|import|domestic|transfer|service)$
   */
  transaction_type: string;
  /**
   * Transaction Date
   * @format date
   */
  transaction_date: string;
  /** Transaction Reference */
  transaction_reference?: string | null;
  /** Transaction Value */
  transaction_value?: string | null;
  /**
   * Currency
   * @maxLength 3
   * @default "EUR"
   */
  currency?: string;
  /** Description */
  description?: string | null;
  /**
   * Status
   * @default "pending"
   * @pattern ^(pending|approved|rejected|completed|cancelled)$
   */
  status?: string;
  /**
   * Risk Level
   * @default "standard"
   * @pattern ^(low|standard|high|critical)$
   */
  risk_level?: string;
  /** Compliance Notes */
  compliance_notes?: string | null;
  /** Documents Required */
  documents_required?: string[];
  /**
   * License Required
   * @default false
   */
  license_required?: boolean;
  /** License Number */
  license_number?: string | null;
  /** Created By */
  created_by?: string | null;
  /** Created At */
  created_at?: string | null;
  /** Updated At */
  updated_at?: string | null;
}

/** CustomizeTemplateRequest */
export interface CustomizeTemplateRequest {
  /** Template Id */
  template_id: number;
  /** Company Name */
  company_name: string;
  /** Customizations */
  customizations: Record<string, any>;
}

/** DailyUsagePoint */
export interface DailyUsagePoint {
  /** Date */
  date: string;
  /** Credits Consumed */
  credits_consumed: number;
  /** Actions Performed */
  actions_performed: number;
  /** Components Used */
  components_used: string[];
}

/** DataSourceConfig */
export interface DataSourceConfig {
  /** Source Type */
  source_type: string;
  /** Source Url */
  source_url?: string | null;
  /** Source Query */
  source_query?: string | null;
  /** Static Data */
  static_data?: Record<string, any>[] | null;
  /** Mapping Fields */
  mapping_fields: Record<string, string>;
  /** Authentication */
  authentication?: Record<string, string> | null;
}

/** DefaultPricingRule */
export interface DefaultPricingRule {
  /** Regulation Type */
  regulation_type?: string | null;
  /** Country Jurisdiction */
  country_jurisdiction?: string | null;
  /**
   * Pricing Tier
   * @default "free"
   */
  pricing_tier?: string;
  /** Credit Cost */
  credit_cost?: number | null;
  /**
   * Is Premium
   * @default false
   */
  is_premium?: boolean;
}

/** DeleteChatRequest */
export interface DeleteChatRequest {
  /** Message Id */
  message_id?: string | null;
  /** Thread Id */
  thread_id?: string | null;
  /** Reason */
  reason?: string | null;
}

/** DeleteDocumentResponse */
export interface DeleteDocumentResponse {
  /** Success */
  success: boolean;
  /** Message */
  message: string;
}

/** DisplayConfig */
export interface DisplayConfig {
  /** Title Field */
  title_field: string;
  /** Subtitle Field */
  subtitle_field?: string | null;
  /** Description Field */
  description_field?: string | null;
  /** Badge Field */
  badge_field?: string | null;
  /** Badge Color Mapping */
  badge_color_mapping?: Record<string, string> | null;
  /** Risk Level Field */
  risk_level_field?: string | null;
  /**
   * Details Fields
   * @default []
   */
  details_fields?: string[];
}

/** DocumentActivity */
export interface DocumentActivity {
  /** Activity Type */
  activity_type: string;
  /** Metadata */
  metadata?: Record<string, any> | null;
}

/** DocumentAlertCreate */
export interface DocumentAlertCreate {
  /** Document Id */
  document_id: number;
  /** Alert Type */
  alert_type: string;
  /** Title */
  title: string;
  /** Description */
  description?: string | null;
  /**
   * Severity
   * @default "medium"
   */
  severity?: string;
  /**
   * Jurisdictions
   * @default []
   */
  jurisdictions?: string[] | null;
  /** Expires At */
  expires_at?: string | null;
}

/** DocumentAlertResponse */
export interface DocumentAlertResponse {
  /** Id */
  id: number;
  /** Document Id */
  document_id: number;
  /** Alert Type */
  alert_type: string;
  /** Title */
  title: string;
  /** Description */
  description: string | null;
  /** Severity */
  severity: string;
  /** Jurisdictions */
  jurisdictions: string[];
  /** Status */
  status: string;
  /**
   * Created At
   * @format date-time
   */
  created_at: string;
  /** Expires At */
  expires_at: string | null;
  /** Acknowledged At */
  acknowledged_at: string | null;
  /** Acknowledged By */
  acknowledged_by: string | null;
  /** Resolved At */
  resolved_at: string | null;
  /** Resolved By */
  resolved_by: string | null;
  /** Created By */
  created_by: string;
  /**
   * Updated At
   * @format date-time
   */
  updated_at: string;
  /** Document Title */
  document_title?: string | null;
  /** Document Description */
  document_description?: string | null;
}

/** DocumentAlertStatusUpdate */
export interface DocumentAlertStatusUpdate {
  /** Status */
  status: string;
  /** Comment */
  comment?: string | null;
}

/** DocumentAlertUpdate */
export interface DocumentAlertUpdate {
  /** Title */
  title?: string | null;
  /** Description */
  description?: string | null;
  /** Severity */
  severity?: string | null;
  /** Jurisdictions */
  jurisdictions?: string[] | null;
  /** Status */
  status?: string | null;
  /** Expires At */
  expires_at?: string | null;
}

/** DocumentAnalytics */
export interface DocumentAnalytics {
  /** Document Id */
  document_id: number;
  /** Title */
  title: string;
  /** Jurisdiction */
  jurisdiction: string;
  /** Total Views */
  total_views: number;
  /** Unique Viewers */
  unique_viewers: number;
  /** Avg Time Spent */
  avg_time_spent: number;
  /** Annotations Count */
  annotations_count: number;
  /** Bookmarks Count */
  bookmarks_count: number;
  /** Downloads */
  downloads: number;
  /**
   * Last Accessed
   * @format date-time
   */
  last_accessed: string;
  /** Popularity Score */
  popularity_score: number;
  /** Trending Score */
  trending_score: number;
}

/** DocumentAnalyticsResponse */
export interface DocumentAnalyticsResponse {
  /** Success */
  success: boolean;
  /** Message */
  message: string;
  /** Total Documents */
  total_documents: number;
  /** Total Size Gb */
  total_size_gb: number;
  /** Category Stats */
  category_stats: DocumentCategoryStats[];
  /** Recent Uploads */
  recent_uploads: DocumentMetadata[];
  /** Expiring Soon */
  expiring_soon: DocumentMetadata[];
}

/** DocumentAnnotation */
export interface DocumentAnnotationInput {
  /** Document Id */
  document_id: number;
  /** Section Id */
  section_id?: number | null;
  /** Annotation Type */
  annotation_type: string;
  /** Content */
  content: string;
  /** Start Position */
  start_position?: number | null;
  /** End Position */
  end_position?: number | null;
  /**
   * Is Public
   * @default false
   */
  is_public?: boolean;
  /** Tags */
  tags?: string[] | null;
  /** Metadata */
  metadata?: Record<string, any> | null;
}

/** DocumentAnnotation */
export interface DocumentAnnotationOutput {
  /** Id */
  id?: number | null;
  /** Document Id */
  document_id: number;
  /** User Id */
  user_id: string;
  /**
   * Annotation Type
   * Type of annotation
   */
  annotation_type: string;
  /**
   * Content
   * Annotation content/text
   */
  content: string;
  /**
   * Position Data
   * Position/selection data
   */
  position_data?: Record<string, any>;
  /**
   * Visibility
   * Who can see this annotation
   * @default "private"
   */
  visibility?: string;
  /**
   * Is Resolved
   * @default false
   */
  is_resolved?: boolean;
  /**
   * Parent Id
   * For threaded comments
   */
  parent_id?: number | null;
  /** Metadata */
  metadata?: Record<string, any>;
  /** Created At */
  created_at?: string | null;
  /** Updated At */
  updated_at?: string | null;
  /** User Name */
  user_name?: string | null;
  /** Replies */
  replies?: DocumentAnnotationOutput[];
}

/** DocumentApprovalRequest */
export interface DocumentApprovalRequest {
  /** Document Id */
  document_id: number;
  /** Action */
  action: string;
  /** Notes */
  notes?: string | null;
}

/** DocumentApprovalResponse */
export interface DocumentApprovalResponse {
  /** Success */
  success: boolean;
  /** Message */
  message: string;
  /** Document Id */
  document_id: number;
  /** New Status */
  new_status: string;
}

/** DocumentCategoryStats */
export interface DocumentCategoryStats {
  /** Category */
  category: string;
  /** Total Documents */
  total_documents: number;
  /** Pending Approval */
  pending_approval: number;
  /** Approved Documents */
  approved_documents: number;
  /** Total Size Mb */
  total_size_mb: number;
  /** Latest Upload */
  latest_upload: string | null;
}

/** DocumentComparison */
export interface DocumentComparison {
  /** Document1 Id */
  document1_id: number;
  /** Document1 Title */
  document1_title: string;
  /** Document1 Excerpt */
  document1_excerpt: string;
  /** Document2 Id */
  document2_id: number;
  /** Document2 Title */
  document2_title: string;
  /** Document2 Excerpt */
  document2_excerpt: string;
  /** Similarity Score */
  similarity_score: number;
  /** Differences */
  differences: Record<string, any>[];
  /** Common Sections */
  common_sections: string[];
  /** Comparison Type */
  comparison_type: string;
}

/** DocumentLinkingRequest */
export interface DocumentLinkingRequest {
  /**
   * Auto Detect
   * @default true
   */
  auto_detect?: boolean;
  /**
   * Include Suggestions
   * @default true
   */
  include_suggestions?: boolean;
  /**
   * Confidence Threshold
   * @default 0.7
   */
  confidence_threshold?: number;
}

/** DocumentLinkingResult */
export interface DocumentLinkingResult {
  /** Document Id */
  document_id: number;
  /** Cross References Found */
  cross_references_found: number;
  /** Cross References Created */
  cross_references_created: number;
  /** Related Documents */
  related_documents: RelatedDocument[];
  /** Processing Time Seconds */
  processing_time_seconds: number;
  /** Confidence Scores */
  confidence_scores: number[];
  /** Suggestions */
  suggestions?: string[];
}

/** DocumentListRequest */
export interface DocumentListRequest {
  /** Customer Id */
  customer_id?: number | null;
  /** Category */
  category?: string | null;
  /** Status */
  status?: string | null;
  /** Search Term */
  search_term?: string | null;
  /** Tags */
  tags?: string[] | null;
  /**
   * Page
   * @default 1
   */
  page?: number;
  /**
   * Limit
   * @default 20
   */
  limit?: number;
}

/** DocumentMetadata */
export interface DocumentMetadata {
  /** Id */
  id: number;
  /** Filename */
  filename: string;
  /** Original Filename */
  original_filename: string;
  /** File Size */
  file_size: number;
  /** File Type */
  file_type: string;
  /** Category */
  category: string;
  /** Subcategory */
  subcategory: string | null;
  /** Description */
  description: string | null;
  /** Tags */
  tags: string[];
  /** Customer Id */
  customer_id: number | null;
  /** Customer Name */
  customer_name: string | null;
  /**
   * Upload Date
   * @format date-time
   */
  upload_date: string;
  /** Uploaded By */
  uploaded_by: string;
  /** Expires At */
  expires_at: string | null;
  /** Status */
  status: string;
  /** Version */
  version: number;
  /** File Hash */
  file_hash: string;
  /** Download Url */
  download_url: string;
}

/** DocumentPricingResponse */
export interface DocumentPricingResponse {
  /** Id */
  id: number;
  /** Title */
  title: string;
  /** Credit Cost */
  credit_cost: number | null;
  /** Is Premium */
  is_premium: boolean;
  /** Pricing Tier */
  pricing_tier: string;
  /** Regulation Type */
  regulation_type: string | null;
  /** Country Jurisdiction */
  country_jurisdiction: string | null;
  /** Publishing Status */
  publishing_status: string;
}

/** DocumentPricingUpdate */
export interface DocumentPricingUpdate {
  /** Document Id */
  document_id: number;
  /** Credit Cost */
  credit_cost?: number | null;
  /**
   * Is Premium
   * @default false
   */
  is_premium?: boolean;
  /**
   * Pricing Tier
   * @default "free"
   */
  pricing_tier?: string;
}

/** DocumentReference */
export interface DocumentReference {
  /** Id */
  id: number;
  /** Reference Id */
  reference_id: string;
  /** Title */
  title: string;
  /** Description */
  description: string | null;
  /** Country Jurisdiction */
  country_jurisdiction: string | null;
  /** Regulation Type */
  regulation_type: string | null;
  /** Publication Date */
  publication_date: string | null;
  /** Legal Status */
  legal_status: string | null;
}

/** DocumentResponse */
export interface DocumentResponse {
  /** Id */
  id: number;
  /** Title */
  title: string;
  /** Description */
  description?: string | null;
  /** Content Text */
  content_text?: string | null;
  /** File Name */
  file_name?: string | null;
  /** File Path */
  file_path?: string | null;
  /** File Size */
  file_size?: number | null;
  /** File Type */
  file_type?: string | null;
  /** Country Jurisdiction */
  country_jurisdiction?: string | null;
  /** Regulation Type */
  regulation_type?: string | null;
  /** Subject */
  subject?: string | null;
  /**
   * Publishing Status
   * @default "draft"
   */
  publishing_status?: string;
  /** Created At */
  created_at?: string | null;
  /** Updated At */
  updated_at?: string | null;
  /** Created By */
  created_by?: string | null;
  /** Updated By */
  updated_by?: string | null;
  /** Author */
  author?: string | null;
  /** Reading Time */
  reading_time?: number | null;
  /**
   * Featured Status
   * @default false
   */
  featured_status?: boolean | null;
  /** Article Type */
  article_type?: string | null;
  /** Publication Date */
  publication_date?: string | null;
  /** Excerpt */
  excerpt?: string | null;
  /** Thumbnail Url */
  thumbnail_url?: string | null;
  /**
   * Attached Documents
   * @default []
   */
  attached_documents?: Record<string, any>[] | null;
  /** Category */
  category?: string | null;
  /**
   * View Count
   * @default 0
   */
  view_count?: number | null;
  /**
   * Likes Count
   * @default 0
   */
  likes_count?: number | null;
  /**
   * Is Blog Article
   * @default false
   */
  is_blog_article?: boolean | null;
}

/** DocumentSearchRequest */
export interface DocumentSearchRequest {
  /** Query */
  query?: string | null;
  /** Category Id */
  category_id?: number | null;
  /** Country Jurisdiction */
  country_jurisdiction?: string | null;
  /** Regulation Type */
  regulation_type?: string | null;
  /** Legal Status */
  legal_status?: string | null;
  /** Publishing Status */
  publishing_status?: string | null;
  /** Status */
  status?: string | null;
  /** Tags */
  tags?: string[] | null;
  /** Search Fields */
  search_fields?: string[] | null;
  /** Boolean Query */
  boolean_query?: string | null;
  /** Phrase Query */
  phrase_query?: string | null;
  /** Wildcard Query */
  wildcard_query?: string | null;
  /** Fuzzy Query */
  fuzzy_query?: string | null;
  /**
   * Search Mode
   * @default "simple"
   */
  search_mode?: string | null;
  /** Date From */
  date_from?: string | null;
  /** Date To */
  date_to?: string | null;
  /**
   * Limit
   * @default 50
   */
  limit?: number;
  /**
   * Offset
   * @default 0
   */
  offset?: number;
}

/** DocumentSearchResponse */
export interface DocumentSearchResponse {
  /** Documents */
  documents: DocumentResponse[];
  /** Total Count */
  total_count: number;
  /** Has More */
  has_more: boolean;
  /** Query Info */
  query_info?: Record<string, any> | null;
}

/** EmailRequest */
export interface EmailRequest {
  /**
   * To
   * @format email
   */
  to: string;
  /** Subject */
  subject: string;
  /** Message */
  message: string;
  /** Assessment Data */
  assessment_data: Record<string, any>;
}

/** EmailResponse */
export interface EmailResponse {
  /** Success */
  success: boolean;
  /** Message */
  message: string;
  /** Email Id */
  email_id?: string | null;
}

/** EnhancedMetadataOptionsResponse */
export interface EnhancedMetadataOptionsResponse {
  /** Classification Levels */
  classification_levels: Record<string, any>[];
  /** Security Markings */
  security_markings: Record<string, any>[];
  /** Compliance Frameworks */
  compliance_frameworks: Record<string, any>[];
  /** Document Types */
  document_types: Record<string, any>[];
  /** Product Categories */
  product_categories: Record<string, any>[];
  /** Review Schedules */
  review_schedules: Record<string, any>[];
  /** Geographic Scopes */
  geographic_scopes: Record<string, any>[];
}

/**
 * EnhancedRegulatoryFeed
 * Enhanced regulatory feed with comprehensive automation
 */
export interface EnhancedRegulatoryFeed {
  /** Id */
  id: number;
  /** Name */
  name: string;
  /** Url */
  url: string;
  /** Jurisdiction */
  jurisdiction: string;
  /**
   * Feed Type
   * @default "rss"
   */
  feed_type?: string;
  /**
   * Status
   * @default "active"
   */
  status?: string;
  /** Enhanced feed configuration with automation settings */
  configuration?: FeedConfiguration;
  /** Last Checked */
  last_checked?: string | null;
  /** Next Check */
  next_check?: string | null;
  /** Last Success */
  last_success?: string | null;
  /**
   * Error Count
   * @default 0
   */
  error_count?: number;
  /** Last Error */
  last_error?: string | null;
  /**
   * Health Score
   * @default 100
   */
  health_score?: number;
  /**
   * Created At
   * @format date-time
   */
  created_at: string;
  /**
   * Updated At
   * @format date-time
   */
  updated_at: string;
  /** Metadata */
  metadata?: Record<string, any>;
}

/** EnhancedUserProfileRequest */
export interface EnhancedUserProfileRequest {
  /** Company Name */
  company_name: string;
  /** Contact Person */
  contact_person: string;
  /**
   * Email
   * @format email
   */
  email: string;
  /** Phone */
  phone?: string | null;
  /** Billing Address */
  billing_address: string;
  /** City */
  city: string;
  /** Postal Code */
  postal_code: string;
  /** Country */
  country: string;
  /** Tax Id */
  tax_id?: string | null;
  /** Vat Number */
  vat_number?: string | null;
  /**
   * Create Company
   * @default false
   */
  create_company?: boolean;
  /** Join Company Slug */
  join_company_slug?: string | null;
  /** Company Domain */
  company_domain?: string | null;
}

/** EnhancedUserProfileResponse */
export interface EnhancedUserProfileResponse {
  /** Id */
  id: number;
  /** User Id */
  user_id: string;
  /** Company Name */
  company_name: string;
  /** Contact Person */
  contact_person: string;
  /** Email */
  email: string;
  /** Phone */
  phone: string | null;
  /** Billing Address */
  billing_address: string;
  /** City */
  city: string;
  /** Postal Code */
  postal_code: string;
  /** Country */
  country: string;
  /** Tax Id */
  tax_id: string | null;
  /** Vat Number */
  vat_number: string | null;
  /** Created At */
  created_at: string;
  /** Updated At */
  updated_at: string;
  /** Company Id */
  company_id: number | null;
  /** Company Slug */
  company_slug: string | null;
  /** User Role */
  user_role: string | null;
  /** Team Member Count */
  team_member_count: number | null;
}

/** EnterpriseInvoiceRequest */
export interface EnterpriseInvoiceRequest {
  /**
   * Credit Amount
   * Minimum 100 credits for enterprise invoices
   * @min 100
   */
  credit_amount: number;
  /** Line Items */
  line_items: AppApisAutomatedBillingInvoiceLineItem[];
  /**
   * Payment Terms
   * Payment terms
   * @default "Net 30"
   */
  payment_terms?: string;
  /** Notes */
  notes?: string | null;
}

/** EnterpriseInvoiceResponse */
export interface EnterpriseInvoiceResponse {
  /** Invoice Id */
  invoice_id: string;
  /** Invoice Number */
  invoice_number: string;
  /** Total Amount */
  total_amount: number;
  /** Net Amount */
  net_amount: number;
  /** Vat Amount */
  vat_amount: number;
  /** Currency */
  currency: string;
  /** Status */
  status: string;
  /**
   * Due Date
   * @format date
   */
  due_date: string;
  /** Line Items */
  line_items: Record<string, any>[];
  /**
   * Created At
   * @format date-time
   */
  created_at: string;
}

/** ExcelImportResponse */
export interface ExcelImportResponse {
  /** Success Count */
  success_count: number;
  /** Error Count */
  error_count: number;
  /** Message */
  message: string;
}

/** ExportRequest */
export interface ExportRequest {
  /** Format */
  format: string;
  /** Search Term */
  search_term?: string | null;
  /** Risk Categories */
  risk_categories?: string[] | null;
  /** Has Arms Embargo */
  has_arms_embargo?: boolean | null;
  /** Freedom Score Min */
  freedom_score_min?: number | null;
  /** Freedom Score Max */
  freedom_score_max?: number | null;
  /**
   * Include All Indicators
   * @default true
   */
  include_all_indicators?: boolean;
}

/** ExtractReferencesRequest */
export interface ExtractReferencesRequest {
  /** Text */
  text: string;
}

/** ExtractReferencesResponse */
export interface ExtractReferencesResponse {
  /** References */
  references: ExtractedReference[];
  /** Total Count */
  total_count: number;
}

/** ExtractedReference */
export interface ExtractedReference {
  /** Text */
  text: string;
  /** Start */
  start: number;
  /** End */
  end: number;
  /** Type */
  type: string;
  /** Groups */
  groups: string[];
}

/**
 * FeedConfiguration
 * Enhanced feed configuration with automation settings
 */
export interface FeedConfiguration {
  /**
   * Auto Import
   * @default true
   */
  auto_import?: boolean;
  /**
   * Notification Enabled
   * @default true
   */
  notification_enabled?: boolean;
  /**
   * Confidence Threshold
   * @default 0.8
   */
  confidence_threshold?: number;
  /** Keywords */
  keywords?: string[];
  /** Exclude Keywords */
  exclude_keywords?: string[];
  /** Retry Config */
  retry_config?: Record<string, any>;
  /** Scheduling */
  scheduling?: Record<string, any>;
  /** Health Monitoring */
  health_monitoring?: Record<string, any>;
}

/**
 * FeedHealthMetrics
 * Health metrics for a feed
 */
export interface FeedHealthMetrics {
  /** Feed Id */
  feed_id: number;
  /** Health Score */
  health_score: number;
  /** Uptime Percentage */
  uptime_percentage: number;
  /** Average Response Time Ms */
  average_response_time_ms: number;
  /** Success Rate 24H */
  success_rate_24h: number;
  /** Success Rate 7D */
  success_rate_7d: number;
  /** Last Check Status */
  last_check_status: string;
  /** Consecutive Failures */
  consecutive_failures: number;
  /** Total Checks */
  total_checks: number;
  /** Total Successes */
  total_successes: number;
  /**
   * Last Metrics Update
   * @format date-time
   */
  last_metrics_update: string;
}

/**
 * FeedProcessingResult
 * Result of feed processing operation
 */
export interface FeedProcessingResult {
  /** Feed Id */
  feed_id: number;
  /** Success */
  success: boolean;
  /** Documents Found */
  documents_found: number;
  /** Documents Imported */
  documents_imported: number;
  /** Processing Time Seconds */
  processing_time_seconds: number;
  /** Error Message */
  error_message?: string | null;
  /**
   * Retry Count
   * @default 0
   */
  retry_count?: number;
  /** Next Retry At */
  next_retry_at?: string | null;
  /** Metadata */
  metadata?: Record<string, any>;
}

/** FeedSourceResponse */
export interface FeedSourceResponse {
  /** Id */
  id: number;
  /** Name */
  name: string;
  /** Description */
  description: string;
  /** Source Url */
  source_url: string;
  /** Source Type */
  source_type: string;
  /** Jurisdiction */
  jurisdiction: string;
  /** Document Types */
  document_types: string[];
  /** Update Frequency */
  update_frequency: string;
  /** Is Active */
  is_active: boolean;
  /** Last Check */
  last_check: string | null;
  /** Documents Found */
  documents_found: number;
  /**
   * Created At
   * @format date-time
   */
  created_at: string;
  /**
   * Updated At
   * @format date-time
   */
  updated_at: string;
}

/** FeedUpdateResult */
export interface FeedUpdateResult {
  /** Feed Id */
  feed_id: number;
  /** Feed Name */
  feed_name: string;
  /** Documents Processed */
  documents_processed: number;
  /** Documents Added */
  documents_added: number;
  /** Documents Updated */
  documents_updated: number;
  /** Errors */
  errors: string[];
  /** Duration Seconds */
  duration_seconds: number;
  /**
   * Timestamp
   * @format date-time
   */
  timestamp: string;
}

/** FormField */
export interface FormField {
  /** Field Id */
  field_id: string;
  /** Field Type */
  field_type: string;
  /** Field Label */
  field_label: string;
  /** Field Description */
  field_description?: string | null;
  /** Options */
  options?: string[] | null;
  /**
   * Required
   * @default false
   */
  required?: boolean;
  /** Section */
  section: string;
}

/** FreeTierStatus */
export interface FreeTierStatus {
  /** Eligible */
  eligible: boolean;
  /** Already Activated */
  already_activated: boolean;
  /** Welcome Credits */
  welcome_credits: number;
  /** Activation Date */
  activation_date?: string | null;
  /** Days Since Activation */
  days_since_activation?: number | null;
  /** Remaining Trial Days */
  remaining_trial_days?: number | null;
}

/** GenerateWidgetCodeRequest */
export interface GenerateWidgetCodeRequest {
  /** Template Id */
  template_id: string;
  /** Widget Name */
  widget_name: string;
  /**
   * Custom Settings
   * @default {}
   */
  custom_settings?: Record<string, any>;
}

/** GeographicPricing */
export interface GeographicPricing {
  /** Id */
  id: number;
  /** Component Name */
  component_name: string;
  /** Action Name */
  action_name: string;
  /** Country Code */
  country_code: string;
  /** Region */
  region: string;
  /** Credit Cost */
  credit_cost: number;
  /** Currency Multiplier */
  currency_multiplier: number;
  /** Is Active */
  is_active: boolean;
  /**
   * Effective From
   * @format date-time
   */
  effective_from: string;
  /** Effective Until */
  effective_until?: string | null;
}

/** HTTPValidationError */
export interface HTTPValidationError {
  /** Detail */
  detail?: ValidationError[];
}

/** HealthResponse */
export interface HealthResponse {
  /** Status */
  status: string;
}

/**
 * HitVerificationRequest
 * Request for hit verification decision
 */
export interface HitVerificationRequest {
  /** Match Id */
  match_id: number;
  /** Customer Id */
  customer_id: number;
  /** Screening Id */
  screening_id: number;
  /** Verification Decision */
  verification_decision: string;
  /** Verification Reason */
  verification_reason?: string | null;
  /** Verification Notes */
  verification_notes?: string | null;
}

/**
 * HitVerificationResponse
 * Response for hit verification
 */
export interface HitVerificationResponse {
  /** Id */
  id: number;
  /** Match Id */
  match_id: number;
  /** Customer Id */
  customer_id: number;
  /** Screening Id */
  screening_id: number;
  /** Verification Decision */
  verification_decision: string;
  /** Verification Reason */
  verification_reason?: string | null;
  /** Verification Notes */
  verification_notes?: string | null;
  /** Verified By */
  verified_by: string;
  /**
   * Verified At
   * @format date-time
   */
  verified_at: string;
  /**
   * Created At
   * @format date-time
   */
  created_at: string;
}

/** HybridPricingModel */
export interface HybridPricingModel {
  /** Id */
  id: number;
  /** Component Name */
  component_name: string;
  /** Model Type */
  model_type: string;
  /** Subscription Tier */
  subscription_tier?: string | null;
  /** Included Actions */
  included_actions: number;
  /** Overage Credit Cost */
  overage_credit_cost: number;
  /** Subscription Monthly Cost */
  subscription_monthly_cost: number;
  /** Is Active */
  is_active: boolean;
  /**
   * Effective From
   * @format date-time
   */
  effective_from: string;
  /** Effective Until */
  effective_until?: string | null;
}

/** ImageListResponse */
export interface ImageListResponse {
  /** Images */
  images: ImageUploadResponse[];
}

/** ImageUploadResponse */
export interface ImageUploadResponse {
  /** Image Url */
  image_url: string;
  /** Image Id */
  image_id: string;
  /** Filename */
  filename: string;
  /** Size */
  size: number;
}

/** IndividualReportRequest */
export interface IndividualReportRequest {
  /** Customer Id */
  customer_id: number;
  /** Screening Id */
  screening_id: number;
  /**
   * Include Matches
   * @default true
   */
  include_matches?: boolean;
}

/** IntroductionNavigationRequest */
export interface IntroductionNavigationRequest {
  /**
   * Option Id
   * @format uuid
   */
  option_id: string;
  /** Option Value */
  option_value: string;
}

/** IntroductionNodeOption */
export interface IntroductionNodeOption {
  /**
   * Id
   * @format uuid
   */
  id: string;
  /**
   * Node Id
   * @format uuid
   */
  node_id: string;
  /** Option Text */
  option_text: string;
  /** Option Value */
  option_value: string;
  /** Routing Rule */
  routing_rule: string | null;
  /** Regulatory Notes */
  regulatory_notes: string[] | null;
  /** Display Order */
  display_order: number;
  /** Note */
  note: string | null;
  /**
   * Created At
   * @format date-time
   */
  created_at: string;
}

/** IntroductionNodeOptionCreate */
export interface IntroductionNodeOptionCreate {
  /** Option Text */
  option_text: string;
  /**
   * Option Value
   * @maxLength 255
   */
  option_value: string;
  /** Routing Rule */
  routing_rule?: string | null;
  /** Regulatory Notes */
  regulatory_notes?: string[] | null;
  /**
   * Display Order
   * @default 0
   */
  display_order?: number;
  /** Note */
  note?: string | null;
}

/** IntroductionNodeOptionUpdate */
export interface IntroductionNodeOptionUpdate {
  /** Option Text */
  option_text?: string | null;
  /** Option Value */
  option_value?: string | null;
  /** Routing Rule */
  routing_rule?: string | null;
  /** Regulatory Notes */
  regulatory_notes?: string[] | null;
  /** Display Order */
  display_order?: number | null;
  /** Note */
  note?: string | null;
}

/** IntroductionTreeCreate */
export interface IntroductionTreeCreate {
  /**
   * Name
   * @maxLength 255
   */
  name: string;
  /** Description */
  description?: string | null;
  /**
   * Jurisdiction
   * @maxLength 100
   */
  jurisdiction: string;
  /**
   * Category
   * @maxLength 100
   */
  category: string;
  /** Classification Tree Id */
  classification_tree_id?: string | null;
  /**
   * Is Classification Template
   * @default false
   */
  is_classification_template?: boolean;
}

/** IntroductionTreeNode */
export interface IntroductionTreeNode {
  /**
   * Id
   * @format uuid
   */
  id: string;
  /**
   * Tree Id
   * @format uuid
   */
  tree_id: string;
  /** Node Key */
  node_key: string;
  /** Title */
  title: string;
  /** Description */
  description: string | null;
  /** Question Text */
  question_text: string;
  /** Question Type */
  question_type: string;
  /** Is Root */
  is_root: boolean;
  /** Parent Node Id */
  parent_node_id: string | null;
  /** Display Order */
  display_order: number;
  /** Notes */
  notes: string | null;
  /** Routing Rule */
  routing_rule: string | null;
  /**
   * Created At
   * @format date-time
   */
  created_at: string;
  /**
   * Updated At
   * @format date-time
   */
  updated_at: string;
  /**
   * Multi Questions
   * Questions for multi_question_assessment type
   */
  multi_questions?: MultiQuestionItem[] | null;
  /**
   * Outcome Rules
   * Outcome rules for multi_question_assessment type
   */
  outcome_rules?: OutcomeRule[] | null;
}

/** IntroductionTreeNodeCreate */
export interface IntroductionTreeNodeCreate {
  /**
   * Node Key
   * @maxLength 50
   */
  node_key: string;
  /**
   * Title
   * @maxLength 500
   */
  title: string;
  /** Description */
  description?: string | null;
  /** Question Text */
  question_text: string;
  /**
   * Question Type
   * @default "multiple_choice"
   */
  question_type?: string;
  /**
   * Is Root
   * @default false
   */
  is_root?: boolean;
  /** Parent Node Id */
  parent_node_id?: string | null;
  /**
   * Display Order
   * @default 0
   */
  display_order?: number;
  /** Notes */
  notes?: string | null;
  /** Routing Rule */
  routing_rule?: string | null;
  /**
   * Multi Questions
   * Questions for multi_question_assessment type
   */
  multi_questions?: MultiQuestionItem[] | null;
  /**
   * Outcome Rules
   * Outcome rules for multi_question_assessment type
   */
  outcome_rules?: OutcomeRule[] | null;
}

/** IntroductionTreeNodeUpdate */
export interface IntroductionTreeNodeUpdate {
  /** Node Key */
  node_key?: string | null;
  /** Title */
  title?: string | null;
  /** Description */
  description?: string | null;
  /** Question Text */
  question_text?: string | null;
  /** Question Type */
  question_type?: string | null;
  /** Parent Node Id */
  parent_node_id?: string | null;
  /** Is Root */
  is_root?: boolean | null;
  /** Display Order */
  display_order?: number | null;
  /** Notes */
  notes?: string | null;
  /** Routing Rule */
  routing_rule?: string | null;
  /**
   * Multi Questions
   * Questions for multi_question_assessment type
   */
  multi_questions?: MultiQuestionItem[] | null;
  /**
   * Outcome Rules
   * Outcome rules for multi_question_assessment type
   */
  outcome_rules?: OutcomeRule[] | null;
}

/** IntroductionTreeUpdate */
export interface IntroductionTreeUpdate {
  /** Name */
  name?: string | null;
  /** Description */
  description?: string | null;
  /** Jurisdiction */
  jurisdiction?: string | null;
  /** Category */
  category?: string | null;
  /** Status */
  status?: string | null;
  /** Classification Tree Id */
  classification_tree_id?: string | null;
  /** Is Classification Template */
  is_classification_template?: boolean | null;
}

/** InvitationDetailsResponse */
export interface InvitationDetailsResponse {
  /** Id */
  id: number;
  /** Company Name */
  company_name: string;
  /** Company Slug */
  company_slug: string;
  /** Role Name */
  role_name: string;
  /** Role Description */
  role_description: string;
  /** Invited By Name */
  invited_by_name: string | null;
  /** Invited By Email */
  invited_by_email: string | null;
  /** Invited At */
  invited_at: string;
  /** Expires At */
  expires_at: string;
  /** Message */
  message: string | null;
  /** Is Expired */
  is_expired: boolean;
  /** Can Accept */
  can_accept: boolean;
}

/** InvitationResponse */
export interface InvitationResponse {
  /** Id */
  id: number;
  /** Email */
  email: string;
  /** Role Name */
  role_name: string;
  /** Status */
  status: string;
  /** Invited By */
  invited_by: string;
  /** Invited At */
  invited_at: string;
  /** Expires At */
  expires_at: string;
  /** Message */
  message: string | null;
}

/** InviteUserRequest */
export interface InviteUserRequest {
  /**
   * Email
   * @format email
   */
  email: string;
  /** Role Name */
  role_name: string;
  /** Message */
  message?: string | null;
}

/** InvoiceRequest */
export interface InvoiceRequest {
  /** Credits */
  credits?: number | null;
  /** Amount */
  amount?: number | null;
  /**
   * Currency
   * @default "USD"
   */
  currency?: string;
  /** Module Name */
  module_name?: string | null;
  /** Template Id */
  template_id?: number | null;
  /** Price Amount */
  price_amount?: number | null;
  customer_details?: CustomerDetails | null;
  /** Custom Credits */
  custom_credits?: number | null;
  /**
   * Payment Method
   * @default "bank_transfer"
   */
  payment_method?: string;
}

/** LoadAssessmentResponse */
export interface LoadAssessmentResponse {
  /** Assessment Id */
  assessment_id: string;
  /** Template Id */
  template_id: number;
  /** Company Name */
  company_name: string;
  /** Assessment Title */
  assessment_title: string;
  /** Responses */
  responses: AssessmentResponse[];
  /** Status */
  status: string;
  /** Completion Percentage */
  completion_percentage: number;
  /** Section Analysis */
  section_analysis?: Record<string, any> | null;
  /** Overall Assessment */
  overall_assessment?: Record<string, any> | null;
  /** Action Plan */
  action_plan?: Record<string, any> | null;
  /** Created At */
  created_at: string;
  /** Updated At */
  updated_at: string;
}

/** MatchQualificationRequest */
export interface MatchQualificationRequest {
  /** Is False Positive */
  is_false_positive: boolean;
  /** Notes */
  notes?: string | null;
}

/** MatchQualificationResponse */
export interface MatchQualificationResponse {
  /** Match Id */
  match_id: number;
  /** Screening Id */
  screening_id: number;
  /** Customer Id */
  customer_id: number;
  /** Is False Positive */
  is_false_positive: boolean;
  /** Notes */
  notes: string;
  /** Reviewed By */
  reviewed_by: string;
  /**
   * Reviewed At
   * @format date-time
   */
  reviewed_at: string;
  /** Updated */
  updated: boolean;
}

/** MetadataOption */
export interface MetadataOption {
  /** Id */
  id?: number | null;
  /** Category */
  category: string;
  /** Value */
  value: string;
  /** Display Name */
  display_name: string;
  /**
   * Display Order
   * @default 0
   */
  display_order?: number;
  /**
   * Is Active
   * @default true
   */
  is_active?: boolean;
}

/** MetadataOptionRequest */
export interface MetadataOptionRequest {
  /** Category */
  category: string;
  /** Value */
  value: string;
  /** Display Name */
  display_name: string;
  /**
   * Display Order
   * @default 0
   */
  display_order?: number | null;
  /**
   * Is Active
   * @default true
   */
  is_active?: boolean;
}

/** MetadataOptionResponse */
export interface MetadataOptionResponse {
  /** Id */
  id: number;
  /** Category */
  category: string;
  /** Value */
  value: string;
  /** Display Name */
  display_name: string;
  /** Display Order */
  display_order: number;
  /** Is Active */
  is_active: boolean;
  /**
   * Created At
   * @format date-time
   */
  created_at: string;
  /**
   * Updated At
   * @format date-time
   */
  updated_at: string;
}

/** MetadataOptionUpdate */
export interface MetadataOptionUpdate {
  /** Value */
  value?: string | null;
  /** Display Name */
  display_name?: string | null;
  /** Display Order */
  display_order?: number | null;
  /** Is Active */
  is_active?: boolean | null;
}

/** MetadataOptionsResponse */
export interface MetadataOptionsResponse {
  /** Options */
  options: MetadataOption[];
  /** Total Count */
  total_count: number;
}

/** ModelPerformanceMetrics */
export interface ModelPerformanceMetrics {
  /** Accuracy */
  accuracy: number;
  /** Precision */
  precision: number;
  /** Recall */
  recall: number;
  /** F1 Score */
  f1_score: number;
  /** True Positives */
  true_positives: number;
  /** False Positives */
  false_positives: number;
  /** True Negatives */
  true_negatives: number;
  /** False Negatives */
  false_negatives: number;
}

/** ModelPerformanceRequest */
export interface ModelPerformanceRequest {
  /**
   * Evaluation Period Days
   * @default 30
   */
  evaluation_period_days?: number;
  /**
   * Model Type
   * @default "risk_prediction"
   */
  model_type?: string;
}

/** ModelPerformanceResponse */
export interface ModelPerformanceResponse {
  /** Success */
  success: boolean;
  /** Message */
  message: string;
  metrics: ModelPerformanceMetrics;
  /** Evaluation Period */
  evaluation_period: string;
  /**
   * Last Updated
   * @format date-time
   */
  last_updated: string;
}

/** ModulePricingConfig */
export interface ModulePricingConfig {
  /** Id */
  id?: number | null;
  /** Module Name */
  module_name: string;
  /** Module Title */
  module_title: string;
  /** Pricing Type */
  pricing_type: string;
  /** Credit Cost */
  credit_cost?: number | null;
  /** Price Eur */
  price_eur?: number | null;
  /**
   * Is Active
   * @default true
   */
  is_active?: boolean;
  /** Description */
  description?: string | null;
}

/** ModulePricingCreate */
export interface ModulePricingCreate {
  /** Module Name */
  module_name: string;
  /** Module Title */
  module_title: string;
  /** Pricing Type */
  pricing_type: string;
  /** Credit Cost */
  credit_cost?: number | null;
  /** Price Eur */
  price_eur?: number | null;
  /** Description */
  description?: string | null;
}

/** ModulePricingUpdate */
export interface ModulePricingUpdate {
  /** Pricing Type */
  pricing_type?: string | null;
  /** Credit Cost */
  credit_cost?: number | null;
  /** Price Eur */
  price_eur?: number | null;
  /** Is Active */
  is_active?: boolean | null;
  /** Description */
  description?: string | null;
}

/** MonitoringConfiguration */
export interface MonitoringConfiguration {
  /** Id */
  id?: number | null;
  /** User Id */
  user_id: string;
  /**
   * Enabled
   * @default true
   */
  enabled?: boolean;
  /**
   * High Risk Monitoring
   * @default true
   */
  high_risk_monitoring?: boolean;
  /**
   * Medium Risk Monitoring
   * @default false
   */
  medium_risk_monitoring?: boolean;
  /**
   * Monitoring Frequency Hours
   * How often to check high-risk customers
   * @default 24
   */
  monitoring_frequency_hours?: number;
  /**
   * Auto Rescreening
   * @default true
   */
  auto_rescreening?: boolean;
  /**
   * Alert Threshold Changes
   * @default true
   */
  alert_threshold_changes?: boolean;
  /**
   * Risk Escalation Enabled
   * @default true
   */
  risk_escalation_enabled?: boolean;
  /** Created At */
  created_at?: string | null;
  /** Updated At */
  updated_at?: string | null;
}

/** MonitoringDashboardResponse */
export interface MonitoringDashboardResponse {
  /** Total Customers */
  total_customers: number;
  /** High Risk Customers */
  high_risk_customers: number;
  /** Active Schedules */
  active_schedules: number;
  /** Completed Screenings Today */
  completed_screenings_today: number;
  /** Pending Alerts */
  pending_alerts: number;
  /** System Health Score */
  system_health_score: number;
  /**
   * Last Updated
   * @format date-time
   */
  last_updated: string;
}

/** MonitoringReport */
export interface MonitoringReport {
  /** Total Monitored Customers */
  total_monitored_customers: number;
  /** High Risk Customers */
  high_risk_customers: number;
  /** Customers Requiring Attention */
  customers_requiring_attention: number;
  /** Last Monitoring Cycle */
  last_monitoring_cycle: string | null;
  /** Next Monitoring Cycle */
  next_monitoring_cycle: string | null;
  /** Recent Alerts Generated */
  recent_alerts_generated: number;
  /** Monitoring Efficiency */
  monitoring_efficiency: number;
  /** Customer Statuses */
  customer_statuses: CustomerMonitoringStatus[];
}

/** MonitoringScheduleResponse */
export interface MonitoringScheduleResponse {
  /** Id */
  id: number;
  /** Schedule Name */
  schedule_name: string;
  /** Schedule Type */
  schedule_type: string;
  /** Frequency Value */
  frequency_value: number;
  /** Target Type */
  target_type: string;
  /** Target Customers */
  target_customers: string[] | null;
  /** Is Active */
  is_active: boolean;
  /** Last Run At */
  last_run_at: string | null;
  /** Next Run At */
  next_run_at: string | null;
  /**
   * Created At
   * @format date-time
   */
  created_at: string;
  /**
   * Updated At
   * @format date-time
   */
  updated_at: string;
}

/**
 * MultiQuestionAssessmentRequest
 * Request for answering a multi-question assessment
 */
export interface MultiQuestionAssessmentRequest {
  /**
   * Responses
   * Map of question_key to yes/no (true/false) responses
   */
  responses: Record<string, boolean>;
}

/**
 * MultiQuestionAssessmentResponse
 * Response after evaluating a multi-question assessment
 */
export interface MultiQuestionAssessmentResponse {
  matched_rule?: OutcomeRule | null;
  /** Routing Target */
  routing_target?: string | null;
  /** Routing Type */
  routing_type?: string | null;
  /** Yes Count */
  yes_count: number;
  /** No Count */
  no_count: number;
  /** Total Questions */
  total_questions: number;
}

/**
 * MultiQuestionItem
 * Individual question within a multi-question assessment
 */
export interface MultiQuestionItem {
  /**
   * Key
   * Unique identifier for this question within the node
   * @maxLength 100
   */
  key: string;
  /**
   * Text
   * The question text
   */
  text: string;
  /**
   * Order
   * Display order of the question
   * @default 0
   */
  order?: number;
  /**
   * Regulatory Notes
   * Array of regulatory note keys for this question
   */
  regulatory_notes?: string[] | null;
}

/** MultilingualSupport */
export interface MultilingualSupport {
  /** Document Id */
  document_id: number;
  /** Original Language */
  original_language: string;
  /** Available Translations */
  available_translations: string[];
  /** Translation Quality Score */
  translation_quality_score: number;
  /** Auto Translated */
  auto_translated: boolean;
  /** Human Reviewed */
  human_reviewed: boolean;
  /**
   * Last Updated
   * @format date-time
   */
  last_updated: string;
}

/** NavigationRequest */
export interface NavigationRequest {
  /**
   * Option Id
   * @format uuid
   */
  option_id: string;
  /** Option Value */
  option_value: string;
}

/** NodeOption */
export interface NodeOption {
  /**
   * Id
   * @format uuid
   */
  id: string;
  /**
   * Node Id
   * @format uuid
   */
  node_id: string;
  /** Option Text */
  option_text: string;
  /** Option Value */
  option_value: string;
  /** Routing Rule */
  routing_rule: string | null;
  /** Regulatory Notes */
  regulatory_notes: string[] | null;
  /** Display Order */
  display_order: number;
  /** Note */
  note: string | null;
  /**
   * Created At
   * @format date-time
   */
  created_at: string;
}

/** NodeOptionCreate */
export interface NodeOptionCreate {
  /** Option Text */
  option_text: string;
  /**
   * Option Value
   * @maxLength 255
   */
  option_value: string;
  /** Routing Rule */
  routing_rule?: string | null;
  /** Regulatory Notes */
  regulatory_notes?: string[] | null;
  /**
   * Display Order
   * @default 0
   */
  display_order?: number;
  /** Note */
  note?: string | null;
}

/** NodeOptionUpdate */
export interface NodeOptionUpdate {
  /** Option Text */
  option_text?: string | null;
  /** Option Value */
  option_value?: string | null;
  /** Routing Rule */
  routing_rule?: string | null;
  /** Regulatory Notes */
  regulatory_notes?: string[] | null;
  /** Display Order */
  display_order?: number | null;
  /** Note */
  note?: string | null;
}

/** NoteResponse */
export interface NoteResponse {
  /** Success */
  success: boolean;
  /** Message */
  message: string;
  note?: ClassificationNote | null;
}

/** NotificationPreferencesRequest */
export interface NotificationPreferencesRequest {
  /** Email Alerts */
  email_alerts?: boolean | null;
  /** Sms Alerts */
  sms_alerts?: boolean | null;
  /** High Risk Alerts */
  high_risk_alerts?: boolean | null;
  /** Schedule Completion Alerts */
  schedule_completion_alerts?: boolean | null;
  /** System Alerts */
  system_alerts?: boolean | null;
  /** Notification Frequency */
  notification_frequency?: string | null;
}

/** NotificationPreferencesResponse */
export interface NotificationPreferencesResponse {
  /** Id */
  id: number;
  /** User Id */
  user_id: string;
  /** Email Alerts */
  email_alerts: boolean;
  /** Sms Alerts */
  sms_alerts: boolean;
  /** High Risk Alerts */
  high_risk_alerts: boolean;
  /** Schedule Completion Alerts */
  schedule_completion_alerts: boolean;
  /** System Alerts */
  system_alerts: boolean;
  /** Notification Frequency */
  notification_frequency: string;
  /**
   * Created At
   * @format date-time
   */
  created_at: string;
  /**
   * Updated At
   * @format date-time
   */
  updated_at: string;
}

/**
 * NotificationRequest
 * Request for sending notifications
 */
export interface NotificationRequest {
  /** Feed Id */
  feed_id: number;
  /** Notification Type */
  notification_type: string;
  /** Recipients */
  recipients: string[];
  /** Subject */
  subject: string;
  /** Message */
  message: string;
  /**
   * Priority
   * @default "medium"
   */
  priority?: string;
  /** Metadata */
  metadata?: Record<string, any>;
}

/**
 * NotificationResult
 * Result of notification delivery
 */
export interface NotificationResult {
  /** Notification Id */
  notification_id: string;
  /** Feed Id */
  feed_id: number;
  /** Notification Type */
  notification_type: string;
  /** Delivery Status */
  delivery_status: string;
  /**
   * Sent At
   * @format date-time
   */
  sent_at: string;
  /** Delivered At */
  delivered_at?: string | null;
  /** Error Message */
  error_message?: string | null;
}

/** NotificationStatusUpdate */
export interface NotificationStatusUpdate {
  /** Status */
  status: string;
}

/**
 * OutcomeRule
 * Rule for determining outcome based on response patterns
 */
export interface OutcomeRule {
  /**
   * Name
   * Name of the rule
   * @maxLength 255
   */
  name: string;
  /**
   * Description
   * Description of what this rule does
   */
  description?: string | null;
  /**
   * Logic
   * Logic conditions like {'yes_count': 2, 'no_count': {'max': 1}}
   */
  logic: Record<string, any>;
  /**
   * Target
   * Where to route (node_key or outcome_code)
   * @maxLength 255
   */
  target: string;
  /**
   * Target Type
   * Type of target: 'node' or 'outcome'
   * @default "node"
   */
  target_type?: string;
  /**
   * Priority
   * Higher priority rules are evaluated first
   * @default 0
   */
  priority?: number;
}

/** OverallAnalytics */
export interface OverallAnalytics {
  /** Total Revenue */
  total_revenue: number;
  /** Total Credits Consumed */
  total_credits_consumed: number;
  /** Total Credits Sold */
  total_credits_sold: number;
  /** Total Active Users */
  total_active_users: number;
  /** Revenue Growth Month */
  revenue_growth_month: number;
  /** Credits Growth Month */
  credits_growth_month: number;
  /** Most Popular Component */
  most_popular_component: string;
  /** Most Popular Package */
  most_popular_package: string;
}

/** PaymentIntent */
export interface PaymentIntent {
  /** Module Name */
  module_name: string;
  /** Template Id */
  template_id?: number | null;
  /** Price Amount */
  price_amount: number;
  /**
   * Currency
   * @default "EUR"
   */
  currency?: string;
  customer_details: CustomerDetails;
}

/** PaymentIntentResponse */
export interface PaymentIntentResponse {
  /** Client Secret */
  client_secret: string;
  /** Purchase Id */
  purchase_id: string;
  /** Amount */
  amount: number;
  /** Currency */
  currency: string;
  /** Company Name */
  company_name: string;
  /** Contact Person */
  contact_person: string;
  /** Email */
  email: string;
  /** Phone */
  phone?: string | null;
  /** Billing Address */
  billing_address: string;
  /** City */
  city: string;
  /** Postal Code */
  postal_code: string;
  /** Country */
  country: string;
}

/** PaymentMethodRequest */
export interface PaymentMethodRequest {
  /** Payment Method Id */
  payment_method_id: string;
  /**
   * Set As Default
   * @default true
   */
  set_as_default?: boolean;
}

/** PendingDocumentResponse */
export interface PendingDocumentResponse {
  /** Id */
  id: number;
  /** Title */
  title: string;
  /** Description */
  description: string | null;
  /** Uploaded By */
  uploaded_by: string;
  /**
   * Uploaded At
   * @format date-time
   */
  uploaded_at: string;
  /** File Name */
  file_name: string | null;
  /** File Size */
  file_size: number | null;
  /** Document Type */
  document_type: string | null;
  /** Jurisdiction */
  jurisdiction: string[] | null;
  /** Regulation Type */
  regulation_type: string[] | null;
  /** Publishing Status */
  publishing_status: string;
  /** Extraction Method */
  extraction_method: string | null;
}

/** PendingDocumentsListResponse */
export interface PendingDocumentsListResponse {
  /** Documents */
  documents: PendingDocumentResponse[];
  /** Total Count */
  total_count: number;
}

/** PerformanceMetrics */
export interface PerformanceMetrics {
  /** Avg Page Load Time */
  avg_page_load_time: number;
  /** Search Response Time */
  search_response_time: number;
  /** Document Processing Time */
  document_processing_time: number;
  /** Api Response Times */
  api_response_times: Record<string, number>;
  /** Cache Hit Rate */
  cache_hit_rate: number;
  /** Concurrent Users */
  concurrent_users: number;
  /** Peak Usage Hour */
  peak_usage_hour: number;
}

/** PredictiveRiskRequest */
export interface PredictiveRiskRequest {
  /** Customer Id */
  customer_id?: number | null;
  /**
   * Prediction Horizon Days
   * @default 30
   */
  prediction_horizon_days?: number;
  /**
   * Include Confidence Scores
   * @default true
   */
  include_confidence_scores?: boolean;
  /** Risk Factors */
  risk_factors?: string[] | null;
}

/** PredictiveRiskResponse */
export interface PredictiveRiskResponse {
  /** Success */
  success: boolean;
  /** Message */
  message: string;
  /** Predictions */
  predictions: CustomerRiskPrediction[];
  /** Total Predictions */
  total_predictions: number;
  /** High Risk Predictions */
  high_risk_predictions: number;
  /** Model Accuracy */
  model_accuracy?: number | null;
}

/** PricingAnalyticsResponse */
export interface PricingAnalyticsResponse {
  /** Pricing Tier */
  pricing_tier: string;
  /** Is Premium */
  is_premium: boolean;
  /** Document Count */
  document_count: number;
  /** Avg Credit Cost */
  avg_credit_cost: number | null;
  /** Min Credit Cost */
  min_credit_cost: number | null;
  /** Max Credit Cost */
  max_credit_cost: number | null;
  /** Priced Documents */
  priced_documents: number;
}

/** PricingFeatureFlag */
export interface PricingFeatureFlag {
  /** Id */
  id: number;
  /** Component Name */
  component_name: string;
  /** Is Pricing Enabled */
  is_pricing_enabled: boolean;
  /** Rollout Strategy */
  rollout_strategy: string;
  /** Rollout Percentage */
  rollout_percentage: number;
  /** Beta Users Only */
  beta_users_only: boolean;
  /** Free Trial Days */
  free_trial_days: number;
  /** Effective From */
  effective_from?: string | null;
}

/** ProcessDocumentResponse */
export interface ProcessDocumentResponse {
  /** Processing Id */
  processing_id: string;
  /** Message */
  message: string;
  /** Estimated Completion */
  estimated_completion: string;
  /** Supported Formats */
  supported_formats: string[];
}

/** ProcessReferenceRequest */
export interface ProcessReferenceRequest {
  /** Document Id */
  document_id: number;
  /** Content */
  content: string;
}

/** ProcessReferenceResponse */
export interface ProcessReferenceResponse {
  /** References Found */
  references_found: number;
  /** Related Documents */
  related_documents: CrossReferenceResponse[];
  /** Processing Time Ms */
  processing_time_ms: number;
}

/** ProcessedFormResponse */
export interface ProcessedFormResponse {
  /** Form Id */
  form_id: string;
  /** Form Title */
  form_title: string;
  /** Sections */
  sections: string[];
  /** Fields */
  fields: FormField[];
  /** Processing Complete */
  processing_complete: boolean;
  /** Recommendations */
  recommendations: string[];
}

/** ProcessingStatusResponse */
export interface ProcessingStatusResponse {
  /** Processing Id */
  processing_id: string;
  /** Status */
  status: string;
  /** Progress */
  progress: number;
  /** Message */
  message: string;
  /** Result */
  result?: Record<string, any> | null;
  /** Errors */
  errors?: string[] | null;
  /** Started At */
  started_at?: string | null;
  /** Completed At */
  completed_at?: string | null;
}

/** ProductClassification */
export interface ProductClassification {
  /** Id */
  id: string;
  /** Product Name */
  product_name: string;
  /** Classification Code */
  classification_code: string;
  /** Control Regime */
  control_regime: string;
  /** Category */
  category: string;
  /** Subcategory */
  subcategory?: string | null;
  /** Description */
  description: string;
  /**
   * Restrictions
   * @default []
   */
  restrictions?: string[];
  /** License Required */
  license_required: boolean;
  /**
   * License Exceptions
   * @default []
   */
  license_exceptions?: string[];
  /** Technical Notes */
  technical_notes?: string | null;
  /**
   * Related Codes
   * @default []
   */
  related_codes?: string[];
  /**
   * Last Updated
   * @format date-time
   */
  last_updated: string;
  /** Source Regulation */
  source_regulation: string;
  /** Risk Level */
  risk_level: string;
  /**
   * Details
   * @default {}
   */
  details?: Record<string, any>;
}

/**
 * ProductReviewUpdate
 * Product review update information
 */
export interface ProductReviewUpdate {
  /** Control Status */
  control_status?: string | null;
  /** Export License Required */
  export_license_required?: boolean | null;
  /** Compliance Notes */
  compliance_notes?: string | null;
  /** Next Review Date */
  next_review_date?: string | null;
}

/** ProductSearchRequest */
export interface ProductSearchRequest {
  /**
   * Query
   * Search query for product name or description
   * @minLength 2
   */
  query: string;
  /**
   * Classification Code
   * Filter by specific classification code
   */
  classification_code?: string | null;
  /**
   * Control Regime
   * Filter by control regime
   */
  control_regime?: string | null;
  /**
   * Category
   * Filter by product category
   */
  category?: string | null;
  /**
   * License Required
   * Filter by license requirement
   */
  license_required?: boolean | null;
  /**
   * Risk Level
   * Filter by risk level
   */
  risk_level?: string | null;
  /**
   * Limit
   * Maximum number of results
   * @max 100
   * @default 50
   */
  limit?: number;
  /**
   * Include Unrestricted
   * Include unrestricted items
   * @default true
   */
  include_unrestricted?: boolean;
}

/** ProductSearchResponse */
export interface ProductSearchResponse {
  /** Products */
  products: ProductClassification[];
  /** Total Count */
  total_count: number;
  /** Search Time Ms */
  search_time_ms: number;
  /** Query Used */
  query_used: string;
  /**
   * Suggestions
   * @default []
   */
  suggestions?: string[];
}

/** PublishDocumentRequest */
export interface PublishDocumentRequest {
  /** Document Ids */
  document_ids: number[];
  /** Action */
  action: string;
}

/** QuestionModel */
export interface QuestionModel {
  /** Text */
  text: string;
  /** Type */
  type: string;
  /**
   * Required
   * @default true
   */
  required?: boolean;
  /**
   * Options
   * @default []
   */
  options?: string[] | null;
  /** Information */
  information?: string | null;
  /**
   * Notes Enabled
   * @default false
   */
  notes_enabled?: boolean | null;
}

/** ReactionRequest */
export interface ReactionRequest {
  /** Reaction Type */
  reaction_type: string;
  /** User Id */
  user_id: string;
}

/** RealTimeMetrics */
export interface RealTimeMetrics {
  /** Credits Consumed Today */
  credits_consumed_today: number;
  /** Actions Performed Today */
  actions_performed_today: number;
  /** Active Sessions */
  active_sessions: number;
  /** Peak Usage Hour */
  peak_usage_hour: string;
  /** Current Burn Rate */
  current_burn_rate: number;
  /** Projected Daily Consumption */
  projected_daily_consumption: number;
}

/** ReferenceSearchResponse */
export interface ReferenceSearchResponse {
  /** References */
  references: DocumentReference[];
  /** Total */
  total: number;
}

/** RelatedDocument */
export interface RelatedDocument {
  /** Document Id */
  document_id: number;
  /** Title */
  title: string;
  /** Similarity Score */
  similarity_score: number;
  /** Relationship Type */
  relationship_type: string;
  /** Connection Details */
  connection_details: string;
  /** Jurisdiction */
  jurisdiction: string;
  /** Document Type */
  document_type: string;
}

/** ReorderRequest */
export interface ReorderRequest {
  /** Category */
  category: string;
  /** Option Orders */
  option_orders: Record<string, any>[];
}

/** ResendInvitationRequest */
export interface ResendInvitationRequest {
  /** Invitation Id */
  invitation_id: number;
  /** Custom Message */
  custom_message?: string | null;
}

/** ReserveCreditsRequest */
export interface ReserveCreditsRequest {
  /** Component Name */
  component_name: string;
  /** Action Name */
  action_name: string;
  /** Resource Id */
  resource_id?: string | null;
}

/** ResolveReferencesResponse */
export interface ResolveReferencesResponse {
  /** Resolved */
  resolved: ResolvedReference[];
  /** Total */
  total: number;
}

/** ResolvedReference */
export interface ResolvedReference {
  /** Reference Id */
  reference_id: string;
  /** Document Id */
  document_id: number | null;
  /** Title */
  title: string | null;
  /** Description */
  description: string | null;
  /** Url */
  url: string | null;
  /** Status */
  status: string;
  /** Error Message */
  error_message: string | null;
}

/** RestrictiveMeasure */
export interface RestrictiveMeasure {
  /** Id */
  id: string;
  /** Regulation Reference */
  regulation_reference: string;
  /** Article Number */
  article_number?: string | null;
  /** Measure Type */
  measure_type: string;
  /** Measure Description */
  measure_description: string;
  /** Jurisdiction */
  jurisdiction: string;
  /** Authority */
  authority?: string | null;
  /**
   * Effective Date
   * @format date-time
   */
  effective_date: string;
  /** Expiry Date */
  expiry_date?: string | null;
  /**
   * Is Active
   * @default true
   */
  is_active?: boolean;
  /**
   * Created At
   * @format date-time
   */
  created_at: string;
  /**
   * Updated At
   * @format date-time
   */
  updated_at: string;
  /** Created By */
  created_by: string;
  /** Updated By */
  updated_by?: string | null;
}

/** RiskAssessmentRequest */
export interface RiskAssessmentRequest {
  /** Country Id */
  country_id: number;
  /** Indicator Id */
  indicator_id: number;
  /** Value Text */
  value_text?: string | null;
  /** Value Boolean */
  value_boolean?: boolean | null;
  /** Value Numeric */
  value_numeric?: number | null;
  /** Value Date */
  value_date?: string | null;
  /** Notes */
  notes?: string | null;
}

/** RiskCategory */
export interface RiskCategory {
  /** Id */
  id: number;
  /** Category Name */
  category_name: string;
  /** Description */
  description?: string | null;
  /** Display Order */
  display_order: number;
}

/** RiskIndicator */
export interface RiskIndicator {
  /** Id */
  id: number;
  /** Category Id */
  category_id: number;
  /** Indicator Name */
  indicator_name: string;
  /** Indicator Type */
  indicator_type: string;
  /** Description */
  description?: string | null;
  /** Display Order */
  display_order: number;
}

/** RiskTrendAnalysisRequest */
export interface RiskTrendAnalysisRequest {
  /** Customer Ids */
  customer_ids?: number[] | null;
  /**
   * Analysis Period Days
   * @default 90
   */
  analysis_period_days?: number;
  /**
   * Trend Type
   * @default "risk_score"
   */
  trend_type?: string;
}

/** RiskTrendAnalysisResponse */
export interface RiskTrendAnalysisResponse {
  /** Success */
  success: boolean;
  /** Message */
  message: string;
  /** Trend Data */
  trend_data: TrendDataPoint[];
  /** Trend Direction */
  trend_direction: string;
  /** Correlation Score */
  correlation_score: number;
  /**
   * Period Start
   * @format date-time
   */
  period_start: string;
  /**
   * Period End
   * @format date-time
   */
  period_end: string;
}

/** RoleDefinitionResponse */
export interface RoleDefinitionResponse {
  /** Id */
  id: number;
  /** Role Name */
  role_name: string;
  /** Role Description */
  role_description: string;
  /** Permissions */
  permissions: Record<string, boolean>;
  /** Is System Role */
  is_system_role: boolean;
}

/** Sanction */
export interface Sanction {
  /** Id */
  id: number;
  /** Sanction Type */
  sanction_type: string;
  /** Name */
  name: string;
  /** Description */
  description: string;
  /** Flag Emoji */
  flag_emoji: string;
  /** Status */
  status: string;
}

/** SanctionAuditLogResponse */
export interface SanctionAuditLogResponse {
  /** Id */
  id: number;
  /** Entity Id */
  entity_id: string;
  /** Action */
  action: string;
  /** Changes */
  changes: Record<string, any> | null;
  /** Performed By */
  performed_by: string;
  /**
   * Performed At
   * @format date-time
   */
  performed_at: string;
  /** Notes */
  notes: string | null;
}

/** SanctionEntitiesResponse */
export interface SanctionEntitiesResponse {
  /** Entities */
  entities: SanctionEntityResponse[];
  /** Total */
  total: number;
  /** Page */
  page: number;
  /** Page Size */
  page_size: number;
  /** Total Pages */
  total_pages: number;
}

/** SanctionEntity */
export interface SanctionEntity {
  /** Id */
  id: string;
  /** Name */
  name: string;
  /** Entity Type */
  entity_type: string;
  /**
   * Aliases
   * @default []
   */
  aliases?: string[];
  /** Sanctions Program */
  sanctions_program: string;
  /** Jurisdiction */
  jurisdiction: string;
  /** Risk Level */
  risk_level: string;
  /** Description */
  description?: string | null;
  /**
   * Date Added
   * @format date-time
   */
  date_added: string;
  /** Source List */
  source_list: string;
  /**
   * Details
   * @default {}
   */
  details?: Record<string, any>;
}

/** SanctionEntityCreate */
export interface SanctionEntityCreate {
  /**
   * Name
   * @minLength 1
   * @maxLength 500
   */
  name: string;
  /**
   * Entity Type
   * person, entity, vessel, aircraft
   */
  entity_type: string;
  /** Aliases */
  aliases?: string[];
  /**
   * Sanctions Program
   * @minLength 1
   * @maxLength 200
   */
  sanctions_program: string;
  /**
   * Jurisdiction
   * @minLength 1
   * @maxLength 100
   */
  jurisdiction: string;
  /**
   * Risk Level
   * high, medium, low
   */
  risk_level: string;
  /** Description */
  description?: string | null;
  /**
   * Source List
   * @minLength 1
   * @maxLength 200
   */
  source_list: string;
  /** Details */
  details?: Record<string, any> | null;
  /**
   * Status
   * active, inactive, pending
   * @default "active"
   */
  status?: string;
}

/** SanctionEntityResponse */
export interface SanctionEntityResponse {
  /** Id */
  id: string;
  /** Name */
  name: string;
  /** Entity Type */
  entity_type: string;
  /** Aliases */
  aliases: string[];
  /** Sanctions Program */
  sanctions_program: string;
  /** Jurisdiction */
  jurisdiction: string;
  /** Risk Level */
  risk_level: string;
  /** Description */
  description: string | null;
  /** Source List */
  source_list: string;
  /** Details */
  details: Record<string, any> | null;
  /** Status */
  status: string;
  /**
   * Date Added
   * @format date-time
   */
  date_added: string;
  /**
   * Last Updated
   * @format date-time
   */
  last_updated: string;
  /** Created By */
  created_by: string;
  /** Updated By */
  updated_by: string | null;
}

/** SanctionEntityUpdate */
export interface SanctionEntityUpdate {
  /** Name */
  name?: string | null;
  /** Entity Type */
  entity_type?: string | null;
  /** Aliases */
  aliases?: string[] | null;
  /** Sanctions Program */
  sanctions_program?: string | null;
  /** Jurisdiction */
  jurisdiction?: string | null;
  /** Risk Level */
  risk_level?: string | null;
  /** Description */
  description?: string | null;
  /** Source List */
  source_list?: string | null;
  /** Details */
  details?: Record<string, any> | null;
  /** Status */
  status?: string | null;
}

/** SanctionSourceResponse */
export interface SanctionSourceResponse {
  /** Source List */
  source_list: string;
  /** Jurisdiction */
  jurisdiction: string;
  /** Entity Count */
  entity_count: number;
  /**
   * Last Updated
   * @format date-time
   */
  last_updated: string;
  /** Status */
  status: string;
}

/** SanctionsAssessmentRequest */
export interface SanctionsAssessmentRequest {
  /** Tree Id */
  tree_id: string;
  /** Jurisdiction */
  jurisdiction: string;
  /** Entity Name */
  entity_name: string;
  /** Entity Type */
  entity_type: string;
  /** Additional Details */
  additional_details?: Record<string, any> | null;
}

/** SanctionsAssessmentResult */
export interface SanctionsAssessmentResult {
  /** Assessment Id */
  assessment_id: string;
  /** Tree Id */
  tree_id: string;
  /** Jurisdiction */
  jurisdiction: string;
  /** Entity Name */
  entity_name: string;
  /** Sanctions Applicable */
  sanctions_applicable: boolean;
  /** Risk Level */
  risk_level: string;
  /** Applicable Sanctions */
  applicable_sanctions: string[];
  /** Reasoning */
  reasoning: string;
  /** Regulatory Notes */
  regulatory_notes?: string | null;
  /** Assessment Path */
  assessment_path: Record<string, any>[];
  /**
   * Created At
   * @format date-time
   */
  created_at: string;
}

/**
 * SanctionsListCreate
 * Model for creating a new sanctions list
 */
export interface SanctionsListCreate {
  /**
   * Name
   * @minLength 1
   * @maxLength 255
   */
  name: string;
  /** Description */
  description?: string | null;
  /**
   * List Type
   * Type of list: sanctions, watchlist, denied_persons, export_control, terrorism, pep, custom
   */
  list_type: string;
  /** Source */
  source?: string | null;
  /** Source Url */
  source_url?: string | null;
  /** Authority */
  authority?: string | null;
  /** Country Jurisdiction */
  country_jurisdiction?: string | null;
  /**
   * Is Active
   * @default true
   */
  is_active?: boolean;
  /**
   * Is Official
   * @default false
   */
  is_official?: boolean;
  /**
   * Update Frequency
   * manual, daily, weekly, monthly
   * @default "manual"
   */
  update_frequency?: string;
  /**
   * Risk Level
   * low, medium, high, critical
   * @default "high"
   */
  risk_level?: string;
  /**
   * Matching Algorithm
   * exact, fuzzy, phonetic, combined
   * @default "fuzzy"
   */
  matching_algorithm?: string;
  /**
   * Minimum Match Score
   * @min 0
   * @max 1
   * @default 0.8
   */
  minimum_match_score?: number;
  /** Notes */
  notes?: string | null;
}

/**
 * SanctionsListEntryCreate
 * Model for creating a new sanctions list entry
 */
export interface SanctionsListEntryCreate {
  /**
   * Entry Type
   * individual, entity, vessel, aircraft, address
   */
  entry_type: string;
  /**
   * Primary Name
   * @minLength 1
   * @maxLength 500
   */
  primary_name: string;
  /** Aliases */
  aliases?: string[];
  /** Date Of Birth */
  date_of_birth?: string | null;
  /** Place Of Birth */
  place_of_birth?: string | null;
  /** Nationality */
  nationality?: string | null;
  /** Passport Numbers */
  passport_numbers?: string[];
  /** Id Numbers */
  id_numbers?: string[];
  /** Addresses */
  addresses?: string[];
  /** Programs */
  programs?: string[];
  /** Reasons */
  reasons?: string | null;
  /** Remarks */
  remarks?: string | null;
  /** List Date */
  list_date?: string | null;
  /** Modification Date */
  modification_date?: string | null;
  /**
   * Is Active
   * @default true
   */
  is_active?: boolean;
  /** External Id */
  external_id?: string | null;
  /** Sanctions List Id */
  sanctions_list_id: number;
}

/**
 * SanctionsListEntryResponse
 * Model for sanctions list entry response
 */
export interface SanctionsListEntryResponse {
  /**
   * Entry Type
   * individual, entity, vessel, aircraft, address
   */
  entry_type: string;
  /**
   * Primary Name
   * @minLength 1
   * @maxLength 500
   */
  primary_name: string;
  /** Aliases */
  aliases?: string[];
  /** Date Of Birth */
  date_of_birth?: string | null;
  /** Place Of Birth */
  place_of_birth?: string | null;
  /** Nationality */
  nationality?: string | null;
  /** Passport Numbers */
  passport_numbers?: string[];
  /** Id Numbers */
  id_numbers?: string[];
  /** Addresses */
  addresses?: string[];
  /** Programs */
  programs?: string[];
  /** Reasons */
  reasons?: string | null;
  /** Remarks */
  remarks?: string | null;
  /** List Date */
  list_date?: string | null;
  /** Modification Date */
  modification_date?: string | null;
  /**
   * Is Active
   * @default true
   */
  is_active?: boolean;
  /** External Id */
  external_id?: string | null;
  /** Id */
  id: number;
  /** Sanctions List Id */
  sanctions_list_id: number;
  /**
   * Created At
   * @format date-time
   */
  created_at: string;
  /**
   * Updated At
   * @format date-time
   */
  updated_at: string;
}

/**
 * SanctionsListResponse
 * Model for sanctions list response
 */
export interface SanctionsListResponse {
  /**
   * Name
   * @minLength 1
   * @maxLength 255
   */
  name: string;
  /** Description */
  description?: string | null;
  /**
   * List Type
   * Type of list: sanctions, watchlist, denied_persons, export_control, terrorism, pep, custom
   */
  list_type: string;
  /** Source */
  source?: string | null;
  /** Source Url */
  source_url?: string | null;
  /** Authority */
  authority?: string | null;
  /** Country Jurisdiction */
  country_jurisdiction?: string | null;
  /**
   * Is Active
   * @default true
   */
  is_active?: boolean;
  /**
   * Is Official
   * @default false
   */
  is_official?: boolean;
  /**
   * Update Frequency
   * manual, daily, weekly, monthly
   * @default "manual"
   */
  update_frequency?: string;
  /**
   * Risk Level
   * low, medium, high, critical
   * @default "high"
   */
  risk_level?: string;
  /**
   * Matching Algorithm
   * exact, fuzzy, phonetic, combined
   * @default "fuzzy"
   */
  matching_algorithm?: string;
  /**
   * Minimum Match Score
   * @min 0
   * @max 1
   * @default 0.8
   */
  minimum_match_score?: number;
  /** Notes */
  notes?: string | null;
  /** Id */
  id: number;
  /** Last Updated */
  last_updated?: string | null;
  /** Last List Update */
  last_list_update?: string | null;
  /** Next Update Due */
  next_update_due?: string | null;
  /**
   * Total Entries
   * @default 0
   */
  total_entries?: number;
  /**
   * Created At
   * @format date-time
   */
  created_at: string;
  /**
   * Updated At
   * @format date-time
   */
  updated_at: string;
  /** Created By */
  created_by?: string | null;
  /** Updated By */
  updated_by?: string | null;
}

/**
 * SanctionsListStats
 * Statistics for sanctions lists overview
 */
export interface SanctionsListStats {
  /** Total Lists */
  total_lists: number;
  /** Active Lists */
  active_lists: number;
  /** Official Lists */
  official_lists: number;
  /** Total Entries */
  total_entries: number;
  /** Lists By Type */
  lists_by_type: Record<string, number>;
  /** Lists By Authority */
  lists_by_authority: Record<string, number>;
  /** Lists By Risk Level */
  lists_by_risk_level: Record<string, number>;
}

/**
 * SanctionsListUpdate
 * Model for updating a sanctions list
 */
export interface SanctionsListUpdate {
  /** Name */
  name?: string | null;
  /** Description */
  description?: string | null;
  /** List Type */
  list_type?: string | null;
  /** Source */
  source?: string | null;
  /** Source Url */
  source_url?: string | null;
  /** Authority */
  authority?: string | null;
  /** Country Jurisdiction */
  country_jurisdiction?: string | null;
  /** Is Active */
  is_active?: boolean | null;
  /** Is Official */
  is_official?: boolean | null;
  /** Update Frequency */
  update_frequency?: string | null;
  /** Last List Update */
  last_list_update?: string | null;
  /** Risk Level */
  risk_level?: string | null;
  /** Matching Algorithm */
  matching_algorithm?: string | null;
  /** Minimum Match Score */
  minimum_match_score?: number | null;
  /** Notes */
  notes?: string | null;
}

/** SanctionsNode */
export interface SanctionsNode {
  /** Id */
  id: string;
  /** Tree Id */
  tree_id: string;
  /** Node Key */
  node_key: string;
  /** Title */
  title: string;
  /** Description */
  description: string;
  /** Question Text */
  question_text?: string | null;
  /** Question Type */
  question_type?: string | null;
  /** Parent Node Id */
  parent_node_id?: string | null;
  /** Display Order */
  display_order: number;
  /** Is Root */
  is_root: boolean;
  /** Notes */
  notes?: string | null;
  /** Metadata */
  metadata?: Record<string, any> | null;
  /**
   * Created At
   * @format date-time
   */
  created_at: string;
  /**
   * Updated At
   * @format date-time
   */
  updated_at: string;
  /**
   * Children
   * @default []
   */
  children?: SanctionsNode[];
}

/** SanctionsNodeCreate */
export interface SanctionsNodeCreate {
  /** Node Key */
  node_key: string;
  /** Title */
  title: string;
  /** Description */
  description: string;
  /** Question Text */
  question_text?: string | null;
  /**
   * Question Type
   * @default "multiple_choice"
   */
  question_type?: string;
  /** Parent Node Id */
  parent_node_id?: string | null;
  /**
   * Display Order
   * @default 0
   */
  display_order?: number;
  /**
   * Is Root
   * @default false
   */
  is_root?: boolean;
  /** Notes */
  notes?: string | null;
  /** Metadata */
  metadata?: Record<string, any> | null;
}

/** SanctionsNodeOption */
export interface SanctionsNodeOption {
  /** Id */
  id: string;
  /** Node Id */
  node_id: string;
  /** Option Text */
  option_text: string;
  /** Option Value */
  option_value: string;
  /** Routing Rule */
  routing_rule?: string | null;
  /** Regulatory Notes */
  regulatory_notes?: string | null;
  /** Display Order */
  display_order: number;
  /** Note */
  note?: string | null;
  /**
   * Created At
   * @format date-time
   */
  created_at: string;
  /**
   * Updated At
   * @format date-time
   */
  updated_at: string;
}

/** SanctionsNodeOptionCreate */
export interface SanctionsNodeOptionCreate {
  /** Option Text */
  option_text: string;
  /** Option Value */
  option_value: string;
  /** Routing Rule */
  routing_rule?: string | null;
  /** Regulatory Notes */
  regulatory_notes?: string | null;
  /**
   * Display Order
   * @default 0
   */
  display_order?: number;
  /** Note */
  note?: string | null;
}

/** SanctionsNodeOptionUpdate */
export interface SanctionsNodeOptionUpdate {
  /** Option Text */
  option_text?: string | null;
  /** Option Value */
  option_value?: string | null;
  /** Routing Rule */
  routing_rule?: string | null;
  /** Regulatory Notes */
  regulatory_notes?: string | null;
  /** Display Order */
  display_order?: number | null;
  /** Note */
  note?: string | null;
}

/** SanctionsNodeUpdate */
export interface SanctionsNodeUpdate {
  /** Node Key */
  node_key?: string | null;
  /** Title */
  title?: string | null;
  /** Description */
  description?: string | null;
  /** Question Text */
  question_text?: string | null;
  /** Question Type */
  question_type?: string | null;
  /** Parent Node Id */
  parent_node_id?: string | null;
  /** Display Order */
  display_order?: number | null;
  /** Is Root */
  is_root?: boolean | null;
  /** Notes */
  notes?: string | null;
  /** Metadata */
  metadata?: Record<string, any> | null;
}

/** SanctionsResponse */
export interface SanctionsResponse {
  /** Sanctions */
  sanctions: Sanction[];
  /** Total */
  total: number;
}

/** SanctionsSearchRequest */
export interface SanctionsSearchRequest {
  /**
   * Query
   * Search query for person/entity name
   * @minLength 2
   */
  query: string;
  /**
   * Entity Type
   * Filter by entity type
   */
  entity_type?: string | null;
  /**
   * Jurisdiction
   * Filter by jurisdiction
   */
  jurisdiction?: string | null;
  /**
   * Sanctions Program
   * Filter by sanctions program
   */
  sanctions_program?: string | null;
  /**
   * Risk Level
   * Filter by risk level
   */
  risk_level?: string | null;
  /**
   * Limit
   * Maximum number of results
   * @max 100
   * @default 50
   */
  limit?: number;
  /**
   * Exact Match
   * Require exact name match
   * @default false
   */
  exact_match?: boolean;
}

/** SanctionsSearchResponse */
export interface SanctionsSearchResponse {
  /** Entities */
  entities: SanctionEntity[];
  /** Total Count */
  total_count: number;
  /** Search Time Ms */
  search_time_ms: number;
  /** Query Used */
  query_used: string;
  /**
   * Suggestions
   * @default []
   */
  suggestions?: string[];
}

/** SanctionsTree */
export interface SanctionsTree {
  /** Id */
  id: string;
  /** Name */
  name: string;
  /** Description */
  description: string;
  /** Jurisdiction */
  jurisdiction: string;
  /** Category */
  category: string;
  /** Version */
  version: string;
  /** Status */
  status: string;
  /** Created By */
  created_by: string;
  /**
   * Created At
   * @format date-time
   */
  created_at: string;
  /**
   * Updated At
   * @format date-time
   */
  updated_at: string;
  /** Published At */
  published_at?: string | null;
  /** Introduction Tree Id */
  introduction_tree_id?: string | null;
  /** Is Introduction Template */
  is_introduction_template: boolean;
}

/** SanctionsTreeCreate */
export interface SanctionsTreeCreate {
  /** Name */
  name: string;
  /** Description */
  description: string;
  /** Jurisdiction */
  jurisdiction: string;
  /** Category */
  category: string;
  /**
   * Is Introduction Template
   * @default false
   */
  is_introduction_template?: boolean | null;
  /** Introduction Tree Id */
  introduction_tree_id?: string | null;
}

/** SanctionsTreeUpdate */
export interface SanctionsTreeUpdate {
  /** Name */
  name?: string | null;
  /** Description */
  description?: string | null;
  /** Jurisdiction */
  jurisdiction?: string | null;
  /** Category */
  category?: string | null;
  /** Status */
  status?: string | null;
}

/** SaveArticleRequest */
export interface SaveArticleRequest {
  /** Document Id */
  document_id: string;
  /** Document Title */
  document_title: string;
  /** Document Description */
  document_description?: string | null;
  /** Document Type */
  document_type?: string | null;
  /** Document Url */
  document_url?: string | null;
  /**
   * Category Ids
   * @default []
   */
  category_ids?: number[] | null;
}

/** SaveAssessmentRequest */
export interface SaveAssessmentRequest {
  /** Template Id */
  template_id: number;
  /** Company Name */
  company_name: string;
  /** Assessment Title */
  assessment_title: string;
  /** Responses */
  responses: AssessmentResponse[];
  /** Status */
  status: string;
  /** Completion Percentage */
  completion_percentage: number;
  /** Section Analysis */
  section_analysis?: Record<string, any> | null;
  /** Overall Assessment */
  overall_assessment?: Record<string, any> | null;
  /** Action Plan */
  action_plan?: Record<string, any> | null;
}

/** SaveAssessmentResponse */
export interface SaveAssessmentResponse {
  /** Success */
  success: boolean;
  /** Assessment Id */
  assessment_id: string;
  /** Message */
  message: string;
  /** Saved At */
  saved_at: string;
}

/** SavedArticleResponse */
export interface SavedArticleResponse {
  /** Id */
  id: number;
  /** Document Id */
  document_id: string;
  /** Document Title */
  document_title: string;
  /** Document Description */
  document_description: string | null;
  /** Document Type */
  document_type: string | null;
  /** Document Url */
  document_url: string | null;
  /**
   * Saved At
   * @format date-time
   */
  saved_at: string;
  /** User Id */
  user_id: string;
  /**
   * Categories
   * @default []
   */
  categories?: AppApisSavedArticlesCategoryResponse[];
}

/** SavedClassificationRequest */
export interface SavedClassificationRequest {
  /** Name */
  name: string;
  /** Description */
  description?: string | null;
  /** Workflow Data */
  workflow_data: Record<string, any>;
  /** Item Name */
  item_name: string;
  /** Item Description */
  item_description?: string | null;
  /** Current Step */
  current_step: string;
  /** Progress Percentage */
  progress_percentage: number;
  /**
   * Auto Save
   * @default true
   */
  auto_save?: boolean;
}

/** SavedClassificationResponse */
export interface SavedClassificationResponse {
  /** Id */
  id: string;
  /** Name */
  name: string;
  /** Description */
  description: string | null;
  /** Item Name */
  item_name: string;
  /** Item Description */
  item_description: string | null;
  /** Current Step */
  current_step: string;
  /** Progress Percentage */
  progress_percentage: number;
  /**
   * Created At
   * @format date-time
   */
  created_at: string;
  /**
   * Updated At
   * @format date-time
   */
  updated_at: string;
  /**
   * Expires At
   * @format date-time
   */
  expires_at: string;
  /** Days Until Expiry */
  days_until_expiry: number;
  /** Auto Save */
  auto_save: boolean;
  /** Status */
  status: string;
}

/** SavedSearchRequest */
export interface SavedSearchRequest {
  /** Name */
  name: string;
  /** Description */
  description?: string | null;
  /** Search Query */
  search_query: string;
  /**
   * Search Mode
   * @default "simple"
   */
  search_mode?: string;
  /** Filters */
  filters?: Record<string, any> | null;
  /**
   * Alert Enabled
   * @default false
   */
  alert_enabled?: boolean;
  /**
   * Alert Frequency
   * @default "daily"
   */
  alert_frequency?: string;
}

/** SavedSearchResponse */
export interface SavedSearchResponse {
  /** Id */
  id: number;
  /** Name */
  name: string;
  /** Description */
  description: string | null;
  /** Search Query */
  search_query: string;
  /** Search Mode */
  search_mode: string;
  /** Filters */
  filters: Record<string, any> | null;
  /** Alert Enabled */
  alert_enabled: boolean;
  /** Alert Frequency */
  alert_frequency: string;
  /**
   * Created At
   * @format date-time
   */
  created_at: string;
  /**
   * Updated At
   * @format date-time
   */
  updated_at: string;
  /** Last Run */
  last_run: string | null;
  /** Result Count */
  result_count: number | null;
}

/** SavedSearchUpdate */
export interface SavedSearchUpdate {
  /** Name */
  name?: string | null;
  /** Description */
  description?: string | null;
  /** Search Query */
  search_query?: string | null;
  /** Search Mode */
  search_mode?: string | null;
  /** Filters */
  filters?: Record<string, any> | null;
  /** Alert Enabled */
  alert_enabled?: boolean | null;
  /** Alert Frequency */
  alert_frequency?: string | null;
}

/** ScheduleRiskAssessmentsRequest */
export interface ScheduleRiskAssessmentsRequest {
  /** Schedule Name */
  schedule_name: string;
  /** Frequency */
  frequency: string;
  /** Customer Ids */
  customer_ids?: number[] | null;
  /**
   * Days Threshold
   * @default 30
   */
  days_threshold?: number | null;
  /**
   * Email Notifications
   * @default true
   */
  email_notifications?: boolean;
  /**
   * Auto Update High Risk
   * @default true
   */
  auto_update_high_risk?: boolean;
  /**
   * Include Screening Context
   * @default true
   */
  include_screening_context?: boolean;
}

/** ScheduleRiskAssessmentsResponse */
export interface ScheduleRiskAssessmentsResponse {
  /** Success */
  success: boolean;
  /** Message */
  message: string;
  /** Schedule Id */
  schedule_id: number | null;
  /** Schedule Name */
  schedule_name: string;
  /** Frequency */
  frequency: string;
}

/**
 * SchedulingConfiguration
 * Scheduling configuration for automated feed processing
 */
export interface SchedulingConfiguration {
  /** Feed Id */
  feed_id: number;
  /**
   * Enabled
   * @default true
   */
  enabled?: boolean;
  /**
   * Frequency
   * @default "daily"
   */
  frequency?: string;
  /** Cron Expression */
  cron_expression?: string | null;
  /**
   * Timezone
   * @default "UTC"
   */
  timezone?: string;
  /** Next Run */
  next_run?: string | null;
  /** Last Run */
  last_run?: string | null;
  /**
   * Run Count
   * @default 0
   */
  run_count?: number;
}

/**
 * ScreeningAlert
 * High-risk screening alert
 */
export interface ScreeningAlert {
  /** Id */
  id?: number | null;
  /** Screening Id */
  screening_id: number;
  /** Customer Id */
  customer_id: number;
  /** Alert Type */
  alert_type: string;
  /**
   * Priority
   * @default "medium"
   */
  priority?: string;
  /** Message */
  message: string;
  /** Details */
  details?: Record<string, any>;
  /**
   * Status
   * @default "open"
   */
  status?: string;
  /** Assigned To */
  assigned_to?: string | null;
  /**
   * Created At
   * @format date-time
   */
  created_at?: string;
  /** Resolved At */
  resolved_at?: string | null;
  /** Resolution Notes */
  resolution_notes?: string | null;
}

/**
 * ScreeningExportRequest
 * Request for exporting screening results
 */
export interface ScreeningExportRequest {
  /**
   * Screening Ids
   * @minItems 1
   */
  screening_ids: number[];
  /**
   * Export Format
   * @default "pdf"
   */
  export_format?: string;
  /**
   * Include False Positives
   * @default false
   */
  include_false_positives?: boolean;
  /**
   * Include Raw Data
   * @default false
   */
  include_raw_data?: boolean;
}

/**
 * ScreeningMatch
 * Screening match result
 */
export interface ScreeningMatch {
  /** Id */
  id?: number | null;
  /** Screening Id */
  screening_id?: number | null;
  /** Watchlist Entry Id */
  watchlist_entry_id: string;
  /** Match Type */
  match_type: string;
  /**
   * Match Score
   * @min 0
   * @max 1
   */
  match_score: number;
  /** Matched Field */
  matched_field: string;
  /** Matched Value */
  matched_value: string;
  /**
   * Risk Level
   * @default "medium"
   */
  risk_level?: string;
  /** Original Value */
  original_value?: string | null;
  /** Confidence Factors */
  confidence_factors?: Record<string, any>;
  /**
   * Is False Positive
   * @default false
   */
  is_false_positive?: boolean;
  /**
   * Verification Status
   * @default "pending"
   */
  verification_status?: string;
  /** Verification Notes */
  verification_notes?: string | null;
  /** Verified By */
  verified_by?: string | null;
  /** Verified At */
  verified_at?: string | null;
}

/** ScreeningMetricsResponse */
export interface ScreeningMetricsResponse {
  /** Total Screenings */
  total_screenings: number;
  /** Successful Screenings */
  successful_screenings: number;
  /** Failed Screenings */
  failed_screenings: number;
  /** Success Rate */
  success_rate: number;
  /** Average Processing Time */
  average_processing_time: number;
  /** Screenings By Day */
  screenings_by_day: Record<string, any>[];
  /** Top Risk Factors */
  top_risk_factors: Record<string, any>[];
}

/**
 * ScreeningResult
 * Complete screening result
 */
export interface ScreeningResult {
  /** Id */
  id?: number | null;
  /** Customer Id */
  customer_id: number;
  /**
   * Screening Type
   * @default "full"
   */
  screening_type?: string;
  /**
   * Status
   * @default "pending"
   */
  status?: string;
  /**
   * Overall Risk Score
   * @min 0
   * @max 1
   * @default 0
   */
  overall_risk_score?: number;
  /**
   * Risk Level
   * @default "low"
   */
  risk_level?: string;
  /**
   * Total Matches
   * @default 0
   */
  total_matches?: number;
  /**
   * High Risk Matches
   * @default 0
   */
  high_risk_matches?: number;
  /**
   * False Positives
   * @default 0
   */
  false_positives?: number;
  /**
   * Screening Date
   * @format date-time
   */
  screening_date?: string;
  /** Screened By */
  screened_by: string;
  /** Screening Duration Ms */
  screening_duration_ms?: number | null;
  /** Watchlists Checked */
  watchlists_checked?: string[];
  /** Matches */
  matches?: ScreeningMatch[];
  /**
   * Alerts Generated
   * @default false
   */
  alerts_generated?: boolean;
  /**
   * Export Count
   * @default 0
   */
  export_count?: number;
  /** Last Exported */
  last_exported?: string | null;
  /** Notes */
  notes?: string | null;
}

/** SearchAlertResponse */
export interface SearchAlertResponse {
  /** Id */
  id: number;
  /** Saved Search Id */
  saved_search_id: number;
  /** New Documents Count */
  new_documents_count: number;
  /**
   * Triggered At
   * @format date-time
   */
  triggered_at: string;
  /** Documents */
  documents: Record<string, any>[];
}

/** SearchAnalytics */
export interface SearchAnalytics {
  /** Query */
  query: string;
  /** Frequency */
  frequency: number;
  /** Success Rate */
  success_rate: number;
  /** Avg Results Count */
  avg_results_count: number;
  /** Jurisdictions Searched */
  jurisdictions_searched: string[];
  /** Categories Searched */
  categories_searched: string[];
  /**
   * Last Searched
   * @format date-time
   */
  last_searched: string;
}

/** SearchCriticalProductsRequest */
export interface SearchCriticalProductsRequest {
  /** Query */
  query?: string | null;
  /** Hs Code */
  hs_code?: string | null;
  /** Cn Code */
  cn_code?: string | null;
  /** Category */
  category?: string | null;
  /** Jurisdiction */
  jurisdiction?: string | null;
  /** Measure Type */
  measure_type?: string | null;
  /** Risk Level */
  risk_level?: string | null;
  /**
   * Limit
   * @default 50
   */
  limit?: number;
  /**
   * Offset
   * @default 0
   */
  offset?: number;
}

/** SearchFieldConfig */
export interface SearchFieldConfig {
  /** Field Name */
  field_name: string;
  /** Field Type */
  field_type: string;
  /** Label */
  label: string;
  /** Placeholder */
  placeholder?: string | null;
  /**
   * Required
   * @default false
   */
  required?: boolean;
  /** Options */
  options?: string[] | null;
  /** Validation Rules */
  validation_rules?: Record<string, any> | null;
}

/** SectionModel */
export interface SectionModel {
  /** Title */
  title: string;
  /** Information */
  information?: string | null;
  /** Questions */
  questions: QuestionModel[];
  /**
   * Strengths Enabled
   * @default true
   */
  strengths_enabled?: boolean | null;
  /**
   * Weaknesses Enabled
   * @default true
   */
  weaknesses_enabled?: boolean | null;
}

/** SectionsNotApplicableRequest */
export interface SectionsNotApplicableRequest {
  /** Sections Not Applicable */
  sections_not_applicable: boolean;
}

/** SectionsNotApplicableResponse */
export interface SectionsNotApplicableResponse {
  /** Sections Not Applicable */
  sections_not_applicable: boolean;
  /** Message */
  message: string;
}

/** SendMessageRequest */
export interface SendMessageRequest {
  /** Content */
  content: string;
  /**
   * Message Type
   * @default "message"
   */
  message_type?: string;
  /** Thread Id */
  thread_id?: string | null;
  /** Reply To */
  reply_to?: string | null;
}

/** SpendingAlert */
export interface SpendingAlert {
  /** Id */
  id: number;
  /** User Id */
  user_id: string;
  /** Alert Type */
  alert_type: string;
  /** Threshold Value */
  threshold_value: number;
  /** Current Value */
  current_value: number;
  /** Message */
  message: string;
  /** Is Active */
  is_active: boolean;
  /**
   * Created At
   * @format date-time
   */
  created_at: string;
  /** Triggered At */
  triggered_at: string | null;
}

/** SubmissionResponse */
export interface SubmissionResponse {
  /** Success */
  success: boolean;
  /** Message */
  message: string;
  /** Submission Id */
  submission_id: string;
  /** Task Id */
  task_id?: string | null;
}

/** SupportRequestCreate */
export interface SupportRequestCreate {
  /** Subject */
  subject: string;
  /** Description */
  description: string;
  /** Category */
  category: string;
  /**
   * Priority
   * @default "medium"
   */
  priority?: string;
  /** Module Context */
  module_context?: string | null;
  /** User Context */
  user_context?: Record<string, any> | null;
}

/** SupportRequestResponse */
export interface SupportRequestResponse {
  /** Ticket Id */
  ticket_id: string;
  /** Status */
  status: string;
  /** Message */
  message: string;
  /**
   * Created At
   * @format date-time
   */
  created_at: string;
}

/** SupportTicket */
export interface SupportTicket {
  /** Ticket Id */
  ticket_id: string;
  /** User Id */
  user_id: string;
  /** User Name */
  user_name: string;
  /** User Email */
  user_email: string;
  /** Subject */
  subject: string;
  /** Description */
  description: string;
  /** Category */
  category: string;
  /** Priority */
  priority: string;
  /** Status */
  status: string;
  /** Module Context */
  module_context: string | null;
  /** User Context */
  user_context: Record<string, any> | null;
  /**
   * Created At
   * @format date-time
   */
  created_at: string;
  /**
   * Updated At
   * @format date-time
   */
  updated_at: string;
  /** Assigned To */
  assigned_to?: string | null;
  /** Resolution Notes */
  resolution_notes?: string | null;
  /**
   * Admin Responses
   * @default []
   */
  admin_responses?: Record<string, any>[];
}

/** SupportTicketListResponse */
export interface SupportTicketListResponse {
  /** Tickets */
  tickets: SupportTicket[];
  /** Total Count */
  total_count: number;
  /** Open Count */
  open_count: number;
  /** In Progress Count */
  in_progress_count: number;
  /** Resolved Count */
  resolved_count: number;
}

/** SupportedFormat */
export interface SupportedFormat {
  /** Format Type */
  format_type: string;
  /** Extensions */
  extensions: string[];
  /** Description */
  description: string;
  /** Ocr Supported */
  ocr_supported: boolean;
  /** Max File Size Mb */
  max_file_size_mb: number;
}

/** SupportedFormatsResponse */
export interface SupportedFormatsResponse {
  /** Formats */
  formats: SupportedFormat[];
  /** Total Formats */
  total_formats: number;
}

/** SystemMetrics */
export interface SystemMetrics {
  /** Total Users */
  total_users: number;
  /** Active Users Today */
  active_users_today: number;
  /** Active Users Week */
  active_users_week: number;
  /** Total Documents */
  total_documents: number;
  /** Total Views Today */
  total_views_today: number;
  /** Total Searches Today */
  total_searches_today: number;
  /** Avg Response Time */
  avg_response_time: number;
  /** Storage Used */
  storage_used: number;
  /** Bandwidth Used */
  bandwidth_used: number;
  /** Error Rate */
  error_rate: number;
}

/** TaskResponse */
export interface TaskResponse {
  /** Success */
  success: boolean;
  /** Message */
  message: string;
}

/** TaskUpdateRequest */
export interface TaskUpdateRequest {
  /** Status */
  status: string;
  /** Notes */
  notes?: string | null;
}

/** TeamMemberResponse */
export interface TeamMemberResponse {
  /** Id */
  id: number;
  /** User Id */
  user_id: string;
  /** Email */
  email?: string | null;
  /** Display Name */
  display_name?: string | null;
  /** Role Name */
  role_name: string;
  /** Role Description */
  role_description: string;
  /** Status */
  status: string;
  /** Joined At */
  joined_at: string;
  /** Last Active */
  last_active: string | null;
  /** Invited By */
  invited_by: string | null;
}

/** TemplateResponse */
export interface TemplateResponse {
  /** Id */
  id: number;
  /** Title */
  title: string;
  /** Description */
  description: string;
  /** How It Works */
  how_it_works?: string | null;
  /** Sections */
  sections: Record<string, any>[];
  /** Status */
  status: string;
  /** Created At */
  created_at: string;
  /** Updated At */
  updated_at: string;
  /** Created By */
  created_by: string;
}

/** TemplateSelectionRequest */
export interface TemplateSelectionRequest {
  /** Purchase Id */
  purchase_id: string;
  /** Template Id */
  template_id: number;
}

/** TemplateSelectionResponse */
export interface TemplateSelectionResponse {
  /** Success */
  success: boolean;
  /** Message */
  message: string;
  /** Access Granted */
  access_granted: boolean;
}

/** TemplatesListResponse */
export interface TemplatesListResponse {
  /** Templates */
  templates: TemplateResponse[];
  /** Total */
  total: number;
}

/** TradeCode */
export interface TradeCode {
  /** Id */
  id: string;
  /** Hs Code */
  hs_code: string;
  /** Cn Code */
  cn_code?: string | null;
  /** Description */
  description: string;
  /** Category */
  category?: string | null;
  /** Subcategory */
  subcategory?: string | null;
  /** Unit Of Measure */
  unit_of_measure?: string | null;
  /**
   * Is Active
   * @default true
   */
  is_active?: boolean;
  /**
   * Created At
   * @format date-time
   */
  created_at: string;
  /**
   * Updated At
   * @format date-time
   */
  updated_at: string;
  /** Created By */
  created_by: string;
  /** Updated By */
  updated_by?: string | null;
}

/** TranslationRequest */
export interface TranslationRequest {
  /** Document Id */
  document_id: number;
  /** Target Language */
  target_language: string;
  /**
   * Priority
   * low, normal, high, urgent
   * @default "normal"
   */
  priority?: string;
  /**
   * Auto Translate
   * @default true
   */
  auto_translate?: boolean;
}

/** TreeFormField */
export interface TreeFormField {
  /** Id */
  id: number;
  /**
   * Tree Id
   * @format uuid
   */
  tree_id: string;
  /** Field Key */
  field_key: string;
  /** Field Label */
  field_label: string;
  /** Field Type */
  field_type: string;
  /** Field Description */
  field_description: string | null;
  /** Placeholder Text */
  placeholder_text: string | null;
  /** Is Required */
  is_required: boolean;
  /** Display Order */
  display_order: number;
  /** Validation Rules */
  validation_rules: Record<string, any>;
  /** Field Options */
  field_options: string[];
  /**
   * Created At
   * @format date-time
   */
  created_at: string;
  /**
   * Updated At
   * @format date-time
   */
  updated_at: string;
}

/** TreeFormFieldCreate */
export interface TreeFormFieldCreate {
  /**
   * Field Key
   * @maxLength 100
   */
  field_key: string;
  /**
   * Field Label
   * @maxLength 255
   */
  field_label: string;
  /**
   * Field Type
   * @default "text"
   */
  field_type?: string;
  /** Field Description */
  field_description?: string | null;
  /** Placeholder Text */
  placeholder_text?: string | null;
  /**
   * Is Required
   * @default false
   */
  is_required?: boolean;
  /**
   * Display Order
   * @default 0
   */
  display_order?: number;
  /**
   * Validation Rules
   * @default {}
   */
  validation_rules?: Record<string, any>;
  /**
   * Field Options
   * @default []
   */
  field_options?: string[];
}

/** TreeFormFieldUpdate */
export interface TreeFormFieldUpdate {
  /** Field Label */
  field_label?: string | null;
  /** Field Type */
  field_type?: string | null;
  /** Field Description */
  field_description?: string | null;
  /** Placeholder Text */
  placeholder_text?: string | null;
  /** Is Required */
  is_required?: boolean | null;
  /** Display Order */
  display_order?: number | null;
  /** Validation Rules */
  validation_rules?: Record<string, any> | null;
  /** Field Options */
  field_options?: string[] | null;
}

/** TreeNode */
export interface TreeNode {
  /**
   * Id
   * @format uuid
   */
  id: string;
  /**
   * Tree Id
   * @format uuid
   */
  tree_id: string;
  /** Node Key */
  node_key: string;
  /** Title */
  title: string;
  /** Description */
  description: string | null;
  /** Question Text */
  question_text: string;
  /** Question Type */
  question_type: string;
  /** Is Root */
  is_root: boolean;
  /** Parent Node Id */
  parent_node_id: string | null;
  /** Display Order */
  display_order: number;
  /** Notes */
  notes: string | null;
  /**
   * Created At
   * @format date-time
   */
  created_at: string;
  /**
   * Updated At
   * @format date-time
   */
  updated_at: string;
  /**
   * Multi Questions
   * Questions for multi_question_assessment type
   */
  multi_questions?: MultiQuestionItem[] | null;
  /**
   * Outcome Rules
   * Outcome rules for multi_question_assessment type
   */
  outcome_rules?: OutcomeRule[] | null;
}

/** TreeNodeCreate */
export interface TreeNodeCreate {
  /**
   * Node Key
   * @maxLength 50
   */
  node_key: string;
  /**
   * Title
   * @maxLength 500
   */
  title: string;
  /** Description */
  description?: string | null;
  /** Question Text */
  question_text: string;
  /**
   * Question Type
   * @default "multiple_choice"
   */
  question_type?: string;
  /**
   * Is Root
   * @default false
   */
  is_root?: boolean;
  /** Parent Node Id */
  parent_node_id?: string | null;
  /**
   * Display Order
   * @default 0
   */
  display_order?: number;
  /** Notes */
  notes: string | null;
  /**
   * Multi Questions
   * Questions for multi_question_assessment type
   */
  multi_questions?: MultiQuestionItem[] | null;
  /**
   * Outcome Rules
   * Outcome rules for multi_question_assessment type
   */
  outcome_rules?: OutcomeRule[] | null;
}

/** TreeNodeUpdate */
export interface TreeNodeUpdate {
  /** Node Key */
  node_key?: string | null;
  /** Title */
  title?: string | null;
  /** Description */
  description?: string | null;
  /** Question Text */
  question_text?: string | null;
  /** Question Type */
  question_type?: string | null;
  /** Display Order */
  display_order?: number | null;
  /** Notes */
  notes: string | null;
  /**
   * Multi Questions
   * Questions for multi_question_assessment type
   */
  multi_questions?: MultiQuestionItem[] | null;
  /**
   * Outcome Rules
   * Outcome rules for multi_question_assessment type
   */
  outcome_rules?: OutcomeRule[] | null;
}

/** TreeOrder */
export interface TreeOrder {
  /** Tree Id */
  tree_id: string;
  /** Order */
  order: number;
  /**
   * Tree Type
   * @pattern ^(introduction|classification)$
   */
  tree_type: string;
}

/** TrendAnalysisResponse */
export interface TrendAnalysisResponse {
  /** Customer Growth Trend */
  customer_growth_trend: Record<string, any>[];
  /** Risk Score Trends */
  risk_score_trends: Record<string, any>[];
  /** Screening Volume Trend */
  screening_volume_trend: Record<string, any>[];
  /** Automation Usage Trend */
  automation_usage_trend: Record<string, any>[];
}

/** TrendDataPoint */
export interface TrendDataPoint {
  /**
   * Date
   * @format date-time
   */
  date: string;
  /** Value */
  value: number;
  /** Customer Count */
  customer_count: number;
}

/** TrialUsageStats */
export interface TrialUsageStats {
  /** Total Credits Used */
  total_credits_used: number;
  /** Credits Remaining */
  credits_remaining: number;
  /** Days Active */
  days_active: number;
  /** Most Used Modules */
  most_used_modules: Record<string, any>[];
  /** Trial Completion Percentage */
  trial_completion_percentage: number;
  /** Suggested Next Steps */
  suggested_next_steps: string[];
}

/** TriggerMonitoringRequest */
export interface TriggerMonitoringRequest {
  /** Customer Ids */
  customer_ids?: string[] | null;
  /** Risk Levels */
  risk_levels?: string[] | null;
  /**
   * Force All
   * @default false
   */
  force_all?: boolean;
}

/** UpdateAnnotationRequest */
export interface UpdateAnnotationRequest {
  /** Content */
  content?: string | null;
  /** Visibility */
  visibility?: string | null;
  /** Is Resolved */
  is_resolved?: boolean | null;
  /** Metadata */
  metadata?: Record<string, any> | null;
}

/** UpdateBadgeRequest */
export interface UpdateBadgeRequest {
  /** Name */
  name?: string | null;
  /** Description */
  description?: string | null;
  /** Color */
  color?: string | null;
  /** Category */
  category?: string | null;
  /** Is Active */
  is_active?: boolean | null;
  /** Sort Order */
  sort_order?: number | null;
}

/** UpdateBillingSettingsRequest */
export interface UpdateBillingSettingsRequest {
  /** Billing Email */
  billing_email?: string | null;
  /** Auto Pay Enabled */
  auto_pay_enabled?: boolean | null;
  /** Invoice Delivery Method */
  invoice_delivery_method?: string | null;
  /** Currency Preference */
  currency_preference?: string | null;
  /** Billing Cycle */
  billing_cycle?: string | null;
}

/** UpdateCompanyProfileRequest */
export interface UpdateCompanyProfileRequest {
  /** Company Name */
  company_name: string;
  /** Company Domain */
  company_domain?: string | null;
  /** Billing Email */
  billing_email?: string | null;
  /** Max Team Members */
  max_team_members: number;
}

/** UpdateContentRequest */
export interface UpdateContentRequest {
  /** Title */
  title?: string | null;
  /** Content */
  content?: Record<string, any> | null;
  /** Is Active */
  is_active?: boolean | null;
}

/** UpdateCreditPackageRequest */
export interface UpdateCreditPackageRequest {
  /** Name */
  name: string;
  /** Credits */
  credits: number;
  /** Price Cents */
  price_cents: number;
  /**
   * Discount Percentage
   * @default 0
   */
  discount_percentage?: number;
  /**
   * Is Active
   * @default true
   */
  is_active?: boolean;
  /**
   * Expiry Months
   * @default 12
   */
  expiry_months?: number;
}

/** UpdateDocumentStatusRequest */
export interface UpdateDocumentStatusRequest {
  /** Status */
  status: string;
  /** Notes */
  notes?: string | null;
}

/** UpdateFeatureFlagRequest */
export interface UpdateFeatureFlagRequest {
  /** Is Pricing Enabled */
  is_pricing_enabled: boolean;
  /**
   * Rollout Strategy
   * @default "full"
   */
  rollout_strategy?: string | null;
  /**
   * Rollout Percentage
   * @default 100
   */
  rollout_percentage?: number | null;
  /**
   * Beta Users Only
   * @default false
   */
  beta_users_only?: boolean | null;
  /**
   * Free Trial Days
   * @default 0
   */
  free_trial_days?: number | null;
}

/** UpdateMemberRoleRequest */
export interface UpdateMemberRoleRequest {
  /** Role Name */
  role_name: string;
}

/** UpdateMetadataOptionRequest */
export interface UpdateMetadataOptionRequest {
  /** Value */
  value?: string | null;
  /** Display Name */
  display_name?: string | null;
  /** Display Order */
  display_order?: number | null;
  /** Is Active */
  is_active?: boolean | null;
}

/** UpdateMonitoringScheduleRequest */
export interface UpdateMonitoringScheduleRequest {
  /** Schedule Name */
  schedule_name?: string | null;
  /** Schedule Type */
  schedule_type?: string | null;
  /** Frequency Value */
  frequency_value?: number | null;
  /** Target Type */
  target_type?: string | null;
  /** Target Customers */
  target_customers?: string[] | null;
  /** Is Active */
  is_active?: boolean | null;
}

/** UpdateNoteRequest */
export interface UpdateNoteRequest {
  /** Note Key */
  note_key: string;
  /** Title */
  title: string;
  /** Content */
  content: string;
}

/** UpdatePricingRequest */
export interface UpdatePricingRequest {
  /** Component Name */
  component_name: string;
  /** Action Name */
  action_name: string;
  /** Credit Cost */
  credit_cost: number;
  /**
   * Is Active
   * @default true
   */
  is_active?: boolean | null;
  /** Description */
  description?: string | null;
}

/** UpdateRiskAssessmentsRequest */
export interface UpdateRiskAssessmentsRequest {
  /** Customer Ids */
  customer_ids?: number[] | null;
  /**
   * Days Since Last Assessment
   * @default 30
   */
  days_since_last_assessment?: number | null;
  /**
   * Force Update
   * @default false
   */
  force_update?: boolean;
}

/** UpdateRiskAssessmentsResponse */
export interface UpdateRiskAssessmentsResponse {
  /** Success */
  success: boolean;
  /** Message */
  message: string;
  /** Updated Customers */
  updated_customers: CustomerRiskUpdate[];
  /** Total Updated */
  total_updated: number;
}

/** UpdateSectionRequest */
export interface UpdateSectionRequest {
  /** Section Number */
  section_number?: string | null;
  /** Section Title */
  section_title?: string | null;
  /** Section Content */
  section_content?: string | null;
  /** Parent Section Id */
  parent_section_id?: number | null;
  /** Display Order */
  display_order?: number | null;
}

/** UpdateTemplateRequest */
export interface UpdateTemplateRequest {
  /** Title */
  title?: string | null;
  /** Description */
  description?: string | null;
  /** How It Works */
  how_it_works?: string | null;
  /** Sections */
  sections?: SectionModel[] | null;
  /** Status */
  status?: string | null;
}

/** UpdateUserRequest */
export interface UpdateUserRequest {
  /** Customer Id */
  customer_id: string;
  /** Email */
  email: string;
  /** Contact Person */
  contact_person: string;
  /** Company Name */
  company_name?: string | null;
  /** Phone */
  phone?: string | null;
  /** Country */
  country?: string | null;
  /** Billing Address */
  billing_address?: string | null;
  /** City */
  city?: string | null;
  /** Postal Code */
  postal_code?: string | null;
  /** Tax Id */
  tax_id?: string | null;
  /** Vat Number */
  vat_number?: string | null;
}

/** UpdateWidgetRequest */
export interface UpdateWidgetRequest {
  /** Widget Id */
  widget_id: string;
  template: WidgetTemplate;
}

/** UploadResponse */
export interface UploadResponse {
  /** File Id */
  file_id: string;
  /** Filename */
  filename: string;
  /** File Size */
  file_size: number;
  /** File Type */
  file_type: string;
  /**
   * Upload Time
   * @format date-time
   */
  upload_time: string;
  /** Processing Status */
  processing_status: string;
  /** Message */
  message: string;
}

/** UsageAnalyticsResponse */
export interface UsageAnalyticsResponse {
  /** Company Id */
  company_id: number | null;
  /** Period Start */
  period_start: string;
  /** Period End */
  period_end: string;
  /** Total Users */
  total_users: number;
  /** Active Users */
  active_users: number;
  /** Module Usage */
  module_usage: Record<string, number>;
  /** Total Credits Used */
  total_credits_used: number;
  /** Total Amount Spent */
  total_amount_spent: number;
  /** Average Monthly Spend */
  average_monthly_spend: number;
}

/** UsageSummary */
export interface UsageSummary {
  /** Total Credits Consumed */
  total_credits_consumed: number;
  /** Total Actions Performed */
  total_actions_performed: number;
  /** Most Used Component */
  most_used_component: string;
  /** Most Used Action */
  most_used_action: string;
  /** Daily Average */
  daily_average: number;
  /** Weekly Trend */
  weekly_trend: string;
  /** Current Balance */
  current_balance: number;
  /** Lifetime Consumed */
  lifetime_consumed: number;
}

/** UsageTierPricing */
export interface UsageTierPricing {
  /** Id */
  id: number;
  /** Component Name */
  component_name: string;
  /** Action Name */
  action_name: string;
  /** Tier Min Usage */
  tier_min_usage: number;
  /** Tier Max Usage */
  tier_max_usage?: number | null;
  /** Credit Cost */
  credit_cost: number;
  /** Discount Percentage */
  discount_percentage: number;
  /** Tier Name */
  tier_name: string;
  /** Is Active */
  is_active: boolean;
  /**
   * Effective From
   * @format date-time
   */
  effective_from: string;
  /** Effective Until */
  effective_until?: string | null;
}

/** UserActivitySummary */
export interface UserActivitySummary {
  /** User Id */
  user_id: string;
  /** User Email */
  user_email: string | null;
  /** User Name */
  user_name: string | null;
  /** Total Actions */
  total_actions: number;
  /** Last Activity */
  last_activity: string | null;
  /** Most Common Actions */
  most_common_actions: Record<string, any>[];
  /** Risk Score */
  risk_score: number;
}

/** UserAssessmentListItem */
export interface UserAssessmentListItem {
  /** Assessment Id */
  assessment_id: string;
  /** Template Id */
  template_id: number;
  /** Template Title */
  template_title: string;
  /** Company Name */
  company_name: string;
  /** Assessment Title */
  assessment_title: string;
  /** Status */
  status: string;
  /** Completion Percentage */
  completion_percentage: number;
  /** Created At */
  created_at: string;
  /** Updated At */
  updated_at: string;
}

/** UserAssessmentsResponse */
export interface UserAssessmentsResponse {
  /** Assessments */
  assessments: UserAssessmentListItem[];
  /** Total Count */
  total_count: number;
}

/** UserBehaviorAnalytics */
export interface UserBehaviorAnalytics {
  /** User Id */
  user_id: string;
  /** Total Sessions */
  total_sessions: number;
  /** Total Time Spent */
  total_time_spent: number;
  /** Documents Viewed */
  documents_viewed: number;
  /** Documents Bookmarked */
  documents_bookmarked: number;
  /** Annotations Created */
  annotations_created: number;
  /** Searches Performed */
  searches_performed: number;
  /** Most Active Jurisdiction */
  most_active_jurisdiction: string;
  /** Engagement Level */
  engagement_level: string;
  /**
   * Last Active
   * @format date-time
   */
  last_active: string;
}

/** UserBookmark */
export interface UserBookmarkInput {
  /** Document Id */
  document_id: number;
  /** Section Id */
  section_id?: number | null;
  /**
   * Bookmark Type
   * @default "document"
   */
  bookmark_type?: string;
  /** Notes */
  notes?: string | null;
  /** Tags */
  tags?: string[] | null;
}

/** UserBookmark */
export interface UserBookmarkOutput {
  /** Id */
  id?: number | null;
  /** User Id */
  user_id: string;
  /** Document Id */
  document_id: number;
  /** Section Id */
  section_id?: string | null;
  /** Title */
  title: string;
  /** Description */
  description?: string | null;
  /** Tags */
  tags?: string[];
  /** Created At */
  created_at?: string | null;
  /** Document Title */
  document_title?: string | null;
  /** Document Jurisdiction */
  document_jurisdiction?: string | null;
}

/** UserCollaborationSummary */
export interface UserCollaborationSummary {
  /** User Id */
  user_id: string;
  /** User Name */
  user_name: string;
  /** Total Annotations */
  total_annotations: number;
  /** Public Annotations */
  public_annotations: number;
  /** Resolved Annotations */
  resolved_annotations: number;
  /** Total Bookmarks */
  total_bookmarks: number;
  /** Documents Accessed */
  documents_accessed: number;
  /** Last Activity */
  last_activity: string | null;
  /** Collaboration Rank */
  collaboration_rank: number;
}

/** UserConsumptionAnalytics */
export interface UserConsumptionAnalytics {
  /** Total Active Users */
  total_active_users: number;
  /** Avg Credits Per User */
  avg_credits_per_user: number;
  /** Top Consuming Users */
  top_consuming_users: Record<string, any>[];
  /** Credits Expiring Soon */
  credits_expiring_soon: number;
  /** Retention Rate */
  retention_rate: number;
}

/** UserNotification */
export interface UserNotification {
  /** Notification Id */
  notification_id: string;
  /** Title */
  title: string;
  /** Message */
  message: string;
  /** Notification Type */
  notification_type: string;
  /** Priority */
  priority: string;
  /** Status */
  status: string;
  /**
   * Created At
   * @format date-time
   */
  created_at: string;
  /** Read At */
  read_at?: string | null;
  /** Dismissed At */
  dismissed_at?: string | null;
  /** Metadata */
  metadata?: Record<string, any> | null;
}

/** UserNotificationsResponse */
export interface UserNotificationsResponse {
  /** Notifications */
  notifications: UserNotification[];
  /** Total Count */
  total_count: number;
  /** Unread Count */
  unread_count: number;
  /** Has More */
  has_more: boolean;
}

/** UserProfileRequest */
export interface UserProfileRequest {
  /** Company Name */
  company_name: string;
  /** Contact Person */
  contact_person: string;
  /**
   * Email
   * @format email
   */
  email: string;
  /** Phone */
  phone?: string | null;
  /** Billing Address */
  billing_address: string;
  /** City */
  city: string;
  /** Postal Code */
  postal_code: string;
  /** Country */
  country: string;
  /** Tax Id */
  tax_id?: string | null;
  /** Vat Number */
  vat_number?: string | null;
}

/** UserProfileResponse */
export interface UserProfileResponse {
  /** Id */
  id: number;
  /** User Id */
  user_id: string;
  /** Company Name */
  company_name: string;
  /** Contact Person */
  contact_person: string;
  /** Email */
  email: string;
  /** Phone */
  phone: string | null;
  /** Billing Address */
  billing_address: string;
  /** City */
  city: string;
  /** Postal Code */
  postal_code: string;
  /** Country */
  country: string;
  /** Tax Id */
  tax_id: string | null;
  /** Vat Number */
  vat_number: string | null;
  /** Created At */
  created_at: string;
  /** Updated At */
  updated_at: string;
}

/** VATBreakdown */
export interface VATBreakdown {
  /** Net Amount */
  net_amount: number;
  /** Vat Amount */
  vat_amount: number;
  /** Gross Amount */
  gross_amount: number;
  /** Vat Rate */
  vat_rate: number;
  /** Vat Type */
  vat_type: string;
  /** Country Code */
  country_code?: string | null;
}

/** VATPreviewRequest */
export interface VATPreviewRequest {
  /** Module Name */
  module_name: string;
  /** Customer Country */
  customer_country: string;
  /** Vat Number */
  vat_number?: string | null;
}

/** VATPreviewResponse */
export interface VATPreviewResponse {
  vat_breakdown: VATBreakdown;
  /** Price Display */
  price_display: string;
}

/** ValidationError */
export interface ValidationError {
  /** Location */
  loc: (string | number)[];
  /** Message */
  msg: string;
  /** Error Type */
  type: string;
}

/** ValidationResponse */
export interface ValidationResponse {
  /** Validation Id */
  validation_id: string;
  /** Status */
  status: string;
  /** Message */
  message: string;
}

/** ValidationSubmissionRequest */
export interface ValidationSubmissionRequest {
  /** Assessment Id */
  assessment_id: string;
  /** Assessment Title */
  assessment_title: string;
  /** Company Name */
  company_name: string;
  /** Template Id */
  template_id: number;
  /** Template Title */
  template_title: string;
  /** User Id */
  user_id: string;
  /** User Email */
  user_email: string;
  /** User Name */
  user_name: string;
  /** Responses */
  responses: Record<string, any>;
  /** Action Plan */
  action_plan: Record<string, string>;
  /** Overall Assessment */
  overall_assessment: Record<string, string>;
  /** Risk Score */
  risk_score: Record<string, any>;
  /** Submission Notes */
  submission_notes?: string | null;
}

/** ValidationTaskDetail */
export interface ValidationTaskDetail {
  /** Validation Id */
  validation_id: string;
  /** Assessment Id */
  assessment_id: string;
  /** Assessment Title */
  assessment_title: string;
  /** Company Name */
  company_name: string;
  /** Template Id */
  template_id: number;
  /** Template Title */
  template_title: string;
  /** User Id */
  user_id: string;
  /** User Email */
  user_email: string;
  /** User Name */
  user_name: string;
  /** Submitted At */
  submitted_at: string;
  /** Status */
  status: string;
  /** Responses */
  responses: Record<string, any>;
  /** Action Plan */
  action_plan: Record<string, string>;
  /** Overall Assessment */
  overall_assessment: Record<string, string>;
  /** Risk Score */
  risk_score: Record<string, any>;
  /** Submission Notes */
  submission_notes: string | null;
  /** Admin Comments */
  admin_comments: string | null;
  /** Reviewed At */
  reviewed_at: string | null;
  /** Reviewed By */
  reviewed_by: string | null;
}

/** ValidationTaskItem */
export interface ValidationTaskItem {
  /** Validation Id */
  validation_id: string;
  /** Assessment Title */
  assessment_title: string;
  /** Company Name */
  company_name: string;
  /** Template Title */
  template_title: string;
  /** User Name */
  user_name: string;
  /** User Email */
  user_email: string;
  /** Submitted At */
  submitted_at: string;
  /** Status */
  status: string;
  /** Priority */
  priority: string;
  /** Risk Level */
  risk_level: string;
  /** Risk Percentage */
  risk_percentage: number;
}

/** ValidationTasksListResponse */
export interface ValidationTasksListResponse {
  /** Tasks */
  tasks: ValidationTaskItem[];
  /** Total Count */
  total_count: number;
  /** Pending Count */
  pending_count: number;
  /** Completed Count */
  completed_count: number;
}

/**
 * VersionedScreeningRequest
 * Request for versioned screening at a specific date
 */
export interface VersionedScreeningRequest {
  /**
   * Screening Date
   * Date to screen against (uses current lists if None)
   */
  screening_date?: string | null;
  /**
   * Force Rescreen
   * Force re-screening even if recent results exist
   * @default false
   */
  force_rescreen?: boolean;
  /**
   * Notes
   * Notes about this screening
   */
  notes?: string | null;
}

/**
 * WatchlistEntry
 * Watchlist entry for screening against
 */
export interface WatchlistEntry {
  /** Id */
  id?: number | null;
  /** List Name */
  list_name: string;
  /** Entity Name */
  entity_name: string;
  /** Aliases */
  aliases?: string[];
  /** Entity Type */
  entity_type: string;
  /** Country */
  country?: string | null;
  /** Date Of Birth */
  date_of_birth?: string | null;
  /** Identification Numbers */
  identification_numbers?: string[];
  /** Sanctions Program */
  sanctions_program: string;
  /** Listing Date */
  listing_date?: string | null;
  /** Last Updated */
  last_updated?: string | null;
  /**
   * Is Active
   * @default true
   */
  is_active?: boolean;
  /** Source Url */
  source_url?: string | null;
  /** Raw Data */
  raw_data?: Record<string, any>;
}

/** WatchlistSearchRequest */
export interface WatchlistSearchRequest {
  /** Search Term */
  search_term: string;
  /** Entity Type */
  entity_type?: string | null;
  /** Country */
  country?: string | null;
  /** Date Of Birth */
  date_of_birth?: string | null;
  /**
   * Exact Match
   * @default false
   */
  exact_match?: boolean;
  /**
   * Limit
   * @default 50
   */
  limit?: number;
}

/** WatchlistSearchResult */
export interface WatchlistSearchResult {
  /** Watchlist entry for screening against */
  watchlist_entry: WatchlistEntry;
  /** Match Score */
  match_score: number;
  /** Match Type */
  match_type: string;
  /** Matched Field */
  matched_field: string;
  /** Risk Assessment */
  risk_assessment: string;
}

/** WebhookEndpoint */
export interface WebhookEndpoint {
  /** Name */
  name: string;
  /** Description */
  description: string;
  /**
   * Target Url
   * @format uri
   * @minLength 1
   * @maxLength 2083
   */
  target_url: string;
  /** Event Types */
  event_types: string[];
  /**
   * Is Active
   * @default true
   */
  is_active?: boolean;
  /** Secret Token */
  secret_token?: string | null;
  /** Custom Headers */
  custom_headers?: Record<string, string> | null;
}

/** WebhookResponse */
export interface WebhookResponse {
  /** Id */
  id: number;
  /** Name */
  name: string;
  /** Description */
  description: string;
  /** Target Url */
  target_url: string;
  /** Event Types */
  event_types: string[];
  /** Is Active */
  is_active: boolean;
  /**
   * Created At
   * @format date-time
   */
  created_at: string;
  /** Last Triggered */
  last_triggered: string | null;
  /** Success Count */
  success_count: number;
  /** Failure Count */
  failure_count: number;
}

/** WidgetSearchRequest */
export interface WidgetSearchRequest {
  /** Widget Id */
  widget_id: string;
  /** Search Query */
  search_query: string;
  /**
   * Filters
   * @default {}
   */
  filters?: Record<string, any>;
  /**
   * Limit
   * @default 20
   */
  limit?: number;
  /**
   * Offset
   * @default 0
   */
  offset?: number;
}

/** WidgetTemplate */
export interface WidgetTemplate {
  /** Id */
  id?: string | null;
  /** Name */
  name: string;
  /** Description */
  description: string;
  /** Category */
  category: string;
  /** Icon */
  icon: string;
  /** Color Scheme */
  color_scheme: string;
  /** Search Fields */
  search_fields: SearchFieldConfig[];
  data_source: DataSourceConfig;
  display_config: DisplayConfig;
  /**
   * Advanced Features
   * @default {}
   */
  advanced_features?: Record<string, any>;
  /** Created At */
  created_at?: string | null;
  /** Updated At */
  updated_at?: string | null;
  /**
   * Is Active
   * @default true
   */
  is_active?: boolean;
}

/** WidgetTestRequest */
export interface WidgetTestRequest {
  /** Widget Id */
  widget_id: string;
  /** Test Query */
  test_query: string;
  /**
   * Test Parameters
   * @default {}
   */
  test_parameters?: Record<string, any>;
}

/** WorkflowOutcome */
export interface WorkflowOutcome {
  /** Id */
  id: string;
  /** Title */
  title: string;
  /** Description */
  description: string;
  /** Action */
  action: string;
}

/** CategoryRequest */
export interface AppApisAdminDashboardCategoryRequest {
  /** Name */
  name: string;
  /** Description */
  description?: string | null;
  /** Parent Id */
  parent_id?: number | null;
}

/** CategoryResponse */
export interface AppApisAdminDashboardCategoryResponse {
  /** Id */
  id: number;
  /** Name */
  name: string;
  /** Description */
  description: string | null;
  /** Parent Id */
  parent_id: number | null;
  /** Document Count */
  document_count: number;
}

/** BulkImportResponse */
export interface AppApisAdminSanctionsBulkImportResponse {
  /** Success */
  success: boolean;
  /** Imported Count */
  imported_count: number;
  /** Updated Count */
  updated_count: number;
  /** Failed Count */
  failed_count: number;
  /** Errors */
  errors: string[];
  /** Summary */
  summary: string;
}

/** InvoiceLineItem */
export interface AppApisAutomatedBillingInvoiceLineItem {
  /** Description */
  description: string;
  /** Quantity */
  quantity: number;
  /** Unit Price */
  unit_price: number;
  /** Total Price */
  total_price: number;
}

/** InvoiceLineItem */
export interface AppApisBillingManagementInvoiceLineItem {
  /** Description */
  description: string;
  /** Quantity */
  quantity: number;
  /** Unit Price */
  unit_price: number;
  /** Total Price */
  total_price: number;
  /** Module Name */
  module_name?: string | null;
  /** Template Id */
  template_id?: number | null;
}

/** InvoiceResponse */
export interface AppApisBillingManagementInvoiceResponse {
  /** Id */
  id: number;
  /** Company Id */
  company_id: number | null;
  /** User Id */
  user_id: string;
  /** Invoice Number */
  invoice_number: string;
  /** Invoice Date */
  invoice_date: string;
  /** Due Date */
  due_date: string | null;
  /** Amount Net */
  amount_net: number;
  /** Amount Vat */
  amount_vat: number;
  /** Amount Total */
  amount_total: number;
  /** Currency */
  currency: string;
  /** Status */
  status: string;
  /** Payment Method */
  payment_method: string | null;
  /** Payment Date */
  payment_date: string | null;
  /** Line Items */
  line_items: Record<string, any>[];
  /** Billing Address */
  billing_address: Record<string, any> | null;
  /** Notes */
  notes: string | null;
  /** Pdf Url */
  pdf_url: string | null;
  /** Created At */
  created_at: string;
  /** Updated At */
  updated_at: string;
  /** Company Name */
  company_name?: string | null;
}

/** CategoryResponse */
export interface AppApisCategoriesCategoryResponse {
  /** Id */
  id: number;
  /** Name */
  name: string;
  /** Description */
  description?: string | null;
  /** Parent Id */
  parent_id?: number | null;
  /** Jurisdiction */
  jurisdiction?: string | null;
  /**
   * Sort Order
   * @default 0
   */
  sort_order?: number;
  /** Created At */
  created_at: string;
  /** Updated At */
  updated_at: string;
  /**
   * Children
   * @default []
   */
  children?: AppApisCategoriesCategoryResponse[] | null;
  /**
   * Document Count
   * @default 0
   */
  document_count?: number;
}

/** ClassificationTree */
export interface AppApisClassificationClassificationTree {
  /**
   * Id
   * @format uuid
   */
  id: string;
  /** Name */
  name: string;
  /** Description */
  description: string | null;
  /** Jurisdiction */
  jurisdiction: string;
  /** Category */
  category: string;
  /** Version */
  version: number;
  /** Status */
  status: string;
  /** Created By */
  created_by: string | null;
  /**
   * Created At
   * @format date-time
   */
  created_at: string;
  /**
   * Updated At
   * @format date-time
   */
  updated_at: string;
  /** Published At */
  published_at: string | null;
  /** Introduction Tree Id */
  introduction_tree_id: string | null;
  /** Is Introduction Template */
  is_introduction_template: boolean;
}

/** ClassificationTree */
export interface AppApisClassificationWorkflowsClassificationTree {
  /** Id */
  id: string;
  /** Name */
  name: string;
  /** Description */
  description: string | null;
  /** Sequence Order */
  sequence_order: number;
  /**
   * Tree Type
   * @default "classification"
   */
  tree_type?: string;
  /** Global Order */
  global_order?: number | null;
}

/** IntroductionTree */
export interface AppApisClassificationWorkflowsIntroductionTree {
  /** Id */
  id: string;
  /** Name */
  name: string;
  /** Description */
  description: string | null;
  /** Sequence Order */
  sequence_order: number;
  /**
   * Tree Type
   * @default "introduction"
   */
  tree_type?: string;
  /** Global Order */
  global_order?: number | null;
}

/** FreeTierActivationResponse */
export interface AppApisCreditManagementFreeTierActivationResponse {
  /** Success */
  success: boolean;
  /** Credits Awarded */
  credits_awarded: number;
  /** New Balance */
  new_balance: number;
  /** Message */
  message: string;
  /** Is First Time */
  is_first_time: boolean;
}

/** DocumentListResponse */
export interface AppApisDocumentManagementDocumentListResponse {
  /** Success */
  success: boolean;
  /** Message */
  message: string;
  /** Documents */
  documents: DocumentMetadata[];
  /** Total Count */
  total_count: number;
  /** Page */
  page: number;
  /** Total Pages */
  total_pages: number;
}

/** DocumentUploadResponse */
export interface AppApisDocumentManagementDocumentUploadResponse {
  /** Success */
  success: boolean;
  /** Message */
  message: string;
  document: DocumentMetadata | null;
  /** Document Id */
  document_id: number | null;
}

/** BulkImportRequest */
export interface AppApisDocumentMetadataBulkImportRequest {
  /** Category */
  category: string;
  /** Options */
  options: Record<string, any>[];
  /**
   * Replace Existing
   * @default false
   */
  replace_existing?: boolean;
}

/** CrossReference */
export interface AppApisDocumentProcessingCrossReference {
  /** Reference Id */
  reference_id: string;
  /** Source Text */
  source_text: string;
  /** Target Regulation */
  target_regulation: string;
  /** Target Section */
  target_section?: string | null;
  /** Reference Type */
  reference_type: string;
  /** Confidence Score */
  confidence_score: number;
  /** Context */
  context: string;
}

/** DocumentSection */
export interface AppApisDocumentProcessingDocumentSection {
  /** Section Id */
  section_id: string;
  /** Title */
  title: string;
  /** Content */
  content: string;
  /** Level */
  level: number;
  /** Parent Section Id */
  parent_section_id?: string | null;
  /** Page Number */
  page_number?: number | null;
  /** Confidence Score */
  confidence_score?: number | null;
}

/** DocumentSectionsResponse */
export interface AppApisDocumentProcessingDocumentSectionsResponse {
  /** Document Id */
  document_id: string;
  /** Sections */
  sections: AppApisDocumentProcessingDocumentSection[];
  /** Total Sections */
  total_sections: number;
  /** Processing Method */
  processing_method: string;
}

/** BulkImportRequest */
export interface AppApisDocumentSectionsBulkImportRequest {
  /** Document Id */
  document_id: number;
  /** Sections */
  sections: Record<string, any>[];
  /**
   * Replace Existing
   * @default false
   */
  replace_existing?: boolean;
}

/** DocumentSection */
export interface AppApisDocumentSectionsDocumentSection {
  /** Id */
  id?: number | null;
  /** Document Id */
  document_id: number;
  /** Section Number */
  section_number?: string | null;
  /** Section Title */
  section_title?: string | null;
  /** Section Content */
  section_content?: string | null;
  /** Parent Section Id */
  parent_section_id?: number | null;
  /**
   * Display Order
   * @default 0
   */
  display_order?: number;
  /** Created At */
  created_at?: string | null;
}

/** DocumentSectionsResponse */
export interface AppApisDocumentSectionsDocumentSectionsResponse {
  /** Sections */
  sections: AppApisDocumentSectionsDocumentSection[];
  /** Total Count */
  total_count: number;
  /**
   * Sections Not Applicable
   * @default false
   */
  sections_not_applicable?: boolean;
}

/** DocumentListResponse */
export interface AppApisDocumentUploadDocumentListResponse {
  /** Documents */
  documents: AppApisDocumentUploadDocumentUploadResponse[];
}

/** DocumentUploadResponse */
export interface AppApisDocumentUploadDocumentUploadResponse {
  /** Document Url */
  document_url: string;
  /** Document Id */
  document_id: string;
  /** Filename */
  filename: string;
  /** Size */
  size: number;
  /** File Type */
  file_type: string;
}

/** FreeTierActivationResponse */
export interface AppApisFreeTierFreeTierActivationResponse {
  /** Success */
  success: boolean;
  /** Credits Awarded */
  credits_awarded: number;
  /** Message */
  message: string;
  /**
   * Trial Expires Date
   * @format date-time
   */
  trial_expires_date: string;
  /** Welcome Benefits */
  welcome_benefits: string[];
}

/** IntroductionTree */
export interface AppApisIntroductionIntroductionTree {
  /**
   * Id
   * @format uuid
   */
  id: string;
  /** Name */
  name: string;
  /** Description */
  description: string | null;
  /** Jurisdiction */
  jurisdiction: string;
  /** Category */
  category: string;
  /** Version */
  version: number;
  /** Status */
  status: string;
  /** Created By */
  created_by: string | null;
  /**
   * Created At
   * @format date-time
   */
  created_at: string;
  /**
   * Updated At
   * @format date-time
   */
  updated_at: string;
  /** Published At */
  published_at: string | null;
  /** Classification Tree Id */
  classification_tree_id: string | null;
  /** Is Classification Template */
  is_classification_template: boolean;
}

/** DocumentSection */
export interface AppApisKbDataDocumentSection {
  /** Id */
  id: number;
  /** Document Id */
  document_id: number;
  /** Section Number */
  section_number: string;
  /** Section Title */
  section_title: string;
  /** Section Content */
  section_content: string;
  /** Parent Section Id */
  parent_section_id: number | null;
  /** Display Order */
  display_order: number;
}

/** DocumentSectionsResponse */
export interface AppApisKbDataDocumentSectionsResponse {
  /** Sections */
  sections: AppApisKbDataDocumentSection[];
  /** Total */
  total: number;
}

/** DocumentListResponse */
export interface AppApisKnowledgeBaseDocumentListResponse {
  /** Documents */
  documents: DocumentResponse[];
  /** Total Count */
  total_count: number;
  /** Has More */
  has_more: boolean;
}

/** InvoiceResponse */
export interface AppApisPaymentSystemInvoiceResponse {
  /** Invoice Id */
  invoice_id: string;
  /** Amount */
  amount: number;
  /** Currency */
  currency: string;
  /** Company Name */
  company_name: string;
  /** Contact Person */
  contact_person: string;
  /** Email */
  email: string;
  /** Phone */
  phone?: string | null;
  /** Billing Address */
  billing_address: string;
  /** City */
  city: string;
  /** Postal Code */
  postal_code: string;
  /** Country */
  country: string;
  /** Payment Instructions */
  payment_instructions: string;
  /** Due Date */
  due_date: string;
}

/** CrossReference */
export interface AppApisRegulatoryMonitoringCrossReference {
  /** Id */
  id: number;
  /** Source Document Id */
  source_document_id: number;
  /** Target Document Id */
  target_document_id: number;
  /** Reference Type */
  reference_type: string;
  /** Reference Text */
  reference_text: string;
  /** Context */
  context: string;
  /** Confidence Score */
  confidence_score: number;
  /** Created By */
  created_by: string;
  /**
   * Created At
   * @format date-time
   */
  created_at: string;
  /** Target Title */
  target_title?: string | null;
  /** Section Reference */
  section_reference?: string | null;
  /** Connection Details */
  connection_details?: string | null;
}

/**
 * BulkImportRequest
 * Model for bulk importing sanctions list entries
 */
export interface AppApisSanctionsListManagementBulkImportRequest {
  /** Sanctions List Id */
  sanctions_list_id: number;
  /** Entries */
  entries: Record<string, any>[];
  /**
   * Replace Existing
   * @default false
   */
  replace_existing?: boolean;
}

/**
 * BulkImportResponse
 * Response for bulk import operation
 */
export interface AppApisSanctionsListManagementBulkImportResponse {
  /** Success */
  success: boolean;
  /** Imported Count */
  imported_count: number;
  /** Updated Count */
  updated_count: number;
  /** Skipped Count */
  skipped_count: number;
  /** Errors */
  errors: string[];
}

/** CategoryRequest */
export interface AppApisSavedArticlesCategoryRequest {
  /** Name */
  name: string;
  /** Description */
  description?: string | null;
  /**
   * Color
   * @default "#6366f1"
   */
  color?: string | null;
  /**
   * Icon
   * @default "folder"
   */
  icon?: string | null;
  /**
   * Display Order
   * @default 0
   */
  display_order?: number | null;
}

/** CategoryResponse */
export interface AppApisSavedArticlesCategoryResponse {
  /** Id */
  id: number;
  /** Name */
  name: string;
  /** Description */
  description: string | null;
  /** Color */
  color: string;
}

export type CheckHealthData = HealthResponse;

/** Response Get Categories Hierarchy */
export type GetCategoriesHierarchyData = AppApisCategoriesCategoryResponse[];

export type GetEnhancedMetadataOptionsData = EnhancedMetadataOptionsResponse;

export type SearchWidgetDataData = any;

export type SearchWidgetDataError = HTTPValidationError;

export interface PreviewWidgetSearchParams {
  /**
   * Query
   * @default "test"
   */
  query?: string;
  /** Widget Id */
  widgetId: string;
}

export type PreviewWidgetSearchData = any;

export type PreviewWidgetSearchError = HTTPValidationError;

export type ListWidgetTemplatesData = any;

export type CreateWidgetTemplateData = any;

export type CreateWidgetTemplateError = HTTPValidationError;

export interface GetWidgetTemplateParams {
  /** Template Id */
  templateId: string;
}

export type GetWidgetTemplateData = any;

export type GetWidgetTemplateError = HTTPValidationError;

export interface UpdateWidgetTemplateParams {
  /** Template Id */
  templateId: string;
}

export type UpdateWidgetTemplateData = any;

export type UpdateWidgetTemplateError = HTTPValidationError;

export interface DeleteWidgetTemplateParams {
  /** Template Id */
  templateId: string;
}

export type DeleteWidgetTemplateData = any;

export type DeleteWidgetTemplateError = HTTPValidationError;

export type ListCustomWidgetsData = any;

export type CreateCustomWidgetData = any;

export type CreateCustomWidgetError = HTTPValidationError;

export interface GetCustomWidgetParams {
  /** Widget Id */
  widgetId: string;
}

export type GetCustomWidgetData = any;

export type GetCustomWidgetError = HTTPValidationError;

export interface UpdateCustomWidgetParams {
  /** Widget Id */
  widgetId: string;
}

export type UpdateCustomWidgetData = any;

export type UpdateCustomWidgetError = HTTPValidationError;

export interface DeleteCustomWidgetParams {
  /** Widget Id */
  widgetId: string;
}

export type DeleteCustomWidgetData = any;

export type DeleteCustomWidgetError = HTTPValidationError;

export interface TestWidgetParams {
  /** Widget Id */
  widgetId: string;
}

export type TestWidgetData = any;

export type TestWidgetError = HTTPValidationError;

export type GetWidgetCategoriesData = any;

export type GetFieldTypesData = any;

export type GenerateWidgetCodeData = any;

export type GenerateWidgetCodeError = HTTPValidationError;

export interface PreviewWidgetTemplateParams {
  /** Template Id */
  templateId: string;
}

export type PreviewWidgetTemplateData = any;

export type PreviewWidgetTemplateError = HTTPValidationError;

export interface GetDocumentAnalyticsParams {
  /**
   * Limit
   * @max 100
   * @default 50
   */
  limit?: number;
  /**
   * Sort By
   * @default "popularity_score"
   * @pattern ^(views|popularity_score|trending_score|last_accessed)$
   */
  sort_by?: string;
  /** Jurisdiction */
  jurisdiction?: string | null;
  /**
   * Time Range
   * @default "30d"
   */
  time_range?: string | null;
}

/** Response Get Document Analytics */
export type GetDocumentAnalyticsData = DocumentAnalytics[];

export type GetDocumentAnalyticsError = HTTPValidationError;

export interface GetDetailedDocumentAnalyticsParams {
  /** Document Id */
  documentId: number;
}

export type GetDetailedDocumentAnalyticsData = any;

export type GetDetailedDocumentAnalyticsError = HTTPValidationError;

export interface GetUserBehaviorAnalyticsParams {
  /**
   * Limit
   * @max 100
   * @default 50
   */
  limit?: number;
  /**
   * Time Range
   * @default "30d"
   */
  time_range?: string;
}

/** Response Get User Behavior Analytics */
export type GetUserBehaviorAnalyticsData = UserBehaviorAnalytics[];

export type GetUserBehaviorAnalyticsError = HTTPValidationError;

export interface GetSearchAnalyticsParams {
  /**
   * Limit
   * @max 100
   * @default 50
   */
  limit?: number;
  /**
   * Min Frequency
   * @default 1
   */
  min_frequency?: number;
}

/** Response Get Search Analytics */
export type GetSearchAnalyticsData = SearchAnalytics[];

export type GetSearchAnalyticsError = HTTPValidationError;

export type GetSystemMetricsData = SystemMetrics;

export type GetComplianceMetricsData = ComplianceMetrics;

export type GetPerformanceMetricsData = PerformanceMetrics;

export interface GetDocumentTranslationsParams {
  /** Document Id */
  documentId: number;
}

export type GetDocumentTranslationsData = MultilingualSupport;

export type GetDocumentTranslationsError = HTTPValidationError;

export type RequestTranslationData = any;

export type RequestTranslationError = HTTPValidationError;

export type GetSupportedLanguagesData = any;

export type GetDashboardSummaryData = any;

/** Response List Introduction Trees */
export type ListIntroductionTreesData = AppApisIntroductionIntroductionTree[];

export type CreateIntroductionTreeData = AppApisIntroductionIntroductionTree;

export type CreateIntroductionTreeError = HTTPValidationError;

export interface GetIntroductionTreeParams {
  /**
   * Tree Id
   * @format uuid
   */
  treeId: string;
}

export type GetIntroductionTreeData = AppApisIntroductionIntroductionTree;

export type GetIntroductionTreeError = HTTPValidationError;

export interface UpdateIntroductionTreeParams {
  /**
   * Tree Id
   * @format uuid
   */
  treeId: string;
}

export type UpdateIntroductionTreeData = AppApisIntroductionIntroductionTree;

export type UpdateIntroductionTreeError = HTTPValidationError;

export interface DeleteIntroductionTreeParams {
  /**
   * Tree Id
   * @format uuid
   */
  treeId: string;
}

export type DeleteIntroductionTreeData = any;

export type DeleteIntroductionTreeError = HTTPValidationError;

export interface DuplicateIntroductionTreeParams {
  /**
   * Tree Id
   * @format uuid
   */
  treeId: string;
}

export type DuplicateIntroductionTreeData = AppApisIntroductionIntroductionTree;

export type DuplicateIntroductionTreeError = HTTPValidationError;

export interface ListIntroductionTreeNodesParams {
  /**
   * Tree Id
   * @format uuid
   */
  treeId: string;
}

/** Response List Introduction Tree Nodes */
export type ListIntroductionTreeNodesData = IntroductionTreeNode[];

export type ListIntroductionTreeNodesError = HTTPValidationError;

export interface CreateIntroductionTreeNodeParams {
  /**
   * Tree Id
   * @format uuid
   */
  treeId: string;
}

export type CreateIntroductionTreeNodeData = IntroductionTreeNode;

export type CreateIntroductionTreeNodeError = HTTPValidationError;

export interface UpdateIntroductionTreeNodeParams {
  /**
   * Node Id
   * @format uuid
   */
  nodeId: string;
}

export type UpdateIntroductionTreeNodeData = IntroductionTreeNode;

export type UpdateIntroductionTreeNodeError = HTTPValidationError;

export interface DeleteIntroductionTreeNodeParams {
  /**
   * Node Id
   * @format uuid
   */
  nodeId: string;
}

export type DeleteIntroductionTreeNodeData = any;

export type DeleteIntroductionTreeNodeError = HTTPValidationError;

export interface DuplicateIntroductionTreeNodeParams {
  /**
   * Node Id
   * @format uuid
   */
  nodeId: string;
}

export type DuplicateIntroductionTreeNodeData = IntroductionTreeNode;

export type DuplicateIntroductionTreeNodeError = HTTPValidationError;

export interface ListIntroductionNodeOptionsParams {
  /**
   * Node Id
   * @format uuid
   */
  nodeId: string;
}

/** Response List Introduction Node Options */
export type ListIntroductionNodeOptionsData = IntroductionNodeOption[];

export type ListIntroductionNodeOptionsError = HTTPValidationError;

export interface CreateIntroductionNodeOptionParams {
  /**
   * Node Id
   * @format uuid
   */
  nodeId: string;
}

export type CreateIntroductionNodeOptionData = IntroductionNodeOption;

export type CreateIntroductionNodeOptionError = HTTPValidationError;

export interface UpdateIntroductionNodeOptionParams {
  /**
   * Option Id
   * @format uuid
   */
  optionId: string;
}

export type UpdateIntroductionNodeOptionData = IntroductionNodeOption;

export type UpdateIntroductionNodeOptionError = HTTPValidationError;

export interface DeleteIntroductionNodeOptionParams {
  /**
   * Option Id
   * @format uuid
   */
  optionId: string;
}

export type DeleteIntroductionNodeOptionData = any;

export type DeleteIntroductionNodeOptionError = HTTPValidationError;

/** Response List Active Introduction Trees */
export type ListActiveIntroductionTreesData = AppApisIntroductionIntroductionTree[];

export interface GetIntroductionTreeStartNodeParams {
  /**
   * Tree Id
   * @format uuid
   */
  treeId: string;
}

export type GetIntroductionTreeStartNodeData = any;

export type GetIntroductionTreeStartNodeError = HTTPValidationError;

export interface GetIntroductionNodeByKeyParams {
  /**
   * Tree Id
   * @format uuid
   */
  treeId: string;
  /** Node Key */
  nodeKey: string;
}

export type GetIntroductionNodeByKeyData = any;

export type GetIntroductionNodeByKeyError = HTTPValidationError;

export interface NavigateIntroductionTreeParams {
  /**
   * Tree Id
   * @format uuid
   */
  treeId: string;
}

export type NavigateIntroductionTreeData = any;

export type NavigateIntroductionTreeError = HTTPValidationError;

export interface ProcessIntroductionMultiQuestionAssessmentParams {
  /**
   * Tree Id
   * @format uuid
   */
  treeId: string;
  /** Node Key */
  nodeKey: string;
}

export type ProcessIntroductionMultiQuestionAssessmentData = MultiQuestionAssessmentResponse;

export type ProcessIntroductionMultiQuestionAssessmentError = HTTPValidationError;

export interface GetTreeFormFieldsParams {
  /**
   * Tree Id
   * @format uuid
   */
  treeId: string;
}

/** Response Get Tree Form Fields */
export type GetTreeFormFieldsData = TreeFormField[];

export type GetTreeFormFieldsError = HTTPValidationError;

export interface CreateTreeFormFieldParams {
  /**
   * Tree Id
   * @format uuid
   */
  treeId: string;
}

export type CreateTreeFormFieldData = TreeFormField;

export type CreateTreeFormFieldError = HTTPValidationError;

export interface UpdateTreeFormFieldParams {
  /**
   * Tree Id
   * @format uuid
   */
  treeId: string;
  /** Field Id */
  fieldId: number;
}

export type UpdateTreeFormFieldData = TreeFormField;

export type UpdateTreeFormFieldError = HTTPValidationError;

export interface DeleteTreeFormFieldParams {
  /**
   * Tree Id
   * @format uuid
   */
  treeId: string;
  /** Field Id */
  fieldId: number;
}

/** Response Delete Tree Form Field */
export type DeleteTreeFormFieldData = Record<string, string>;

export type DeleteTreeFormFieldError = HTTPValidationError;

/** Response List Classification Trees */
export type ListClassificationTreesData = AppApisClassificationClassificationTree[];

export type CreateClassificationTreeData = AppApisClassificationClassificationTree;

export type CreateClassificationTreeError = HTTPValidationError;

export interface GetClassificationTreeParams {
  /**
   * Tree Id
   * @format uuid
   */
  treeId: string;
}

export type GetClassificationTreeData = AppApisClassificationClassificationTree;

export type GetClassificationTreeError = HTTPValidationError;

export interface UpdateClassificationTreeParams {
  /**
   * Tree Id
   * @format uuid
   */
  treeId: string;
}

export type UpdateClassificationTreeData = AppApisClassificationClassificationTree;

export type UpdateClassificationTreeError = HTTPValidationError;

export interface DeleteClassificationTreeParams {
  /**
   * Tree Id
   * @format uuid
   */
  treeId: string;
}

export type DeleteClassificationTreeData = any;

export type DeleteClassificationTreeError = HTTPValidationError;

export interface DuplicateClassificationTreeParams {
  /**
   * Tree Id
   * @format uuid
   */
  treeId: string;
}

export type DuplicateClassificationTreeData = AppApisClassificationClassificationTree;

export type DuplicateClassificationTreeError = HTTPValidationError;

export interface ListTreeNodesParams {
  /**
   * Tree Id
   * @format uuid
   */
  treeId: string;
}

/** Response List Tree Nodes */
export type ListTreeNodesData = TreeNode[];

export type ListTreeNodesError = HTTPValidationError;

export interface CreateTreeNodeParams {
  /**
   * Tree Id
   * @format uuid
   */
  treeId: string;
}

export type CreateTreeNodeData = TreeNode;

export type CreateTreeNodeError = HTTPValidationError;

export interface UpdateTreeNodeParams {
  /**
   * Tree Id
   * @format uuid
   */
  treeId: string;
  /**
   * Node Id
   * @format uuid
   */
  nodeId: string;
}

export type UpdateTreeNodeData = TreeNode;

export type UpdateTreeNodeError = HTTPValidationError;

export interface DeleteTreeNodeParams {
  /**
   * Node Id
   * @format uuid
   */
  nodeId: string;
}

export type DeleteTreeNodeData = any;

export type DeleteTreeNodeError = HTTPValidationError;

export interface ListNodeOptionsParams {
  /**
   * Node Id
   * @format uuid
   */
  nodeId: string;
}

/** Response List Node Options */
export type ListNodeOptionsData = NodeOption[];

export type ListNodeOptionsError = HTTPValidationError;

export interface CreateNodeOptionParams {
  /**
   * Node Id
   * @format uuid
   */
  nodeId: string;
}

export type CreateNodeOptionData = NodeOption;

export type CreateNodeOptionError = HTTPValidationError;

export interface DeleteNodeOptionParams {
  /**
   * Option Id
   * @format uuid
   */
  optionId: string;
}

export type DeleteNodeOptionData = any;

export type DeleteNodeOptionError = HTTPValidationError;

export interface UpdateNodeOptionParams {
  /**
   * Option Id
   * @format uuid
   */
  optionId: string;
}

export type UpdateNodeOptionData = NodeOption;

export type UpdateNodeOptionError = HTTPValidationError;

/** Response List All Classification Outcomes */
export type ListAllClassificationOutcomesData = ClassificationOutcome[];

export type CreateTreeIndependentOutcomeData = ClassificationOutcome;

export type CreateTreeIndependentOutcomeError = HTTPValidationError;

export interface ListClassificationOutcomesParams {
  /**
   * Tree Id
   * @format uuid
   */
  treeId: string;
}

/** Response List Classification Outcomes */
export type ListClassificationOutcomesData = ClassificationOutcome[];

export type ListClassificationOutcomesError = HTTPValidationError;

export interface CreateClassificationOutcomeParams {
  /**
   * Tree Id
   * @format uuid
   */
  treeId: string;
}

export type CreateClassificationOutcomeData = ClassificationOutcome;

export type CreateClassificationOutcomeError = HTTPValidationError;

export interface UpdateClassificationOutcomeParams {
  /**
   * Outcome Id
   * @format uuid
   */
  outcomeId: string;
}

export type UpdateClassificationOutcomeData = ClassificationOutcome;

export type UpdateClassificationOutcomeError = HTTPValidationError;

export interface DeleteClassificationOutcomeParams {
  /**
   * Outcome Id
   * @format uuid
   */
  outcomeId: string;
}

export type DeleteClassificationOutcomeData = any;

export type DeleteClassificationOutcomeError = HTTPValidationError;

/** Response List Active Trees */
export type ListActiveTreesData = AppApisClassificationClassificationTree[];

export interface GetTreeStartNodeParams {
  /**
   * Tree Id
   * @format uuid
   */
  treeId: string;
}

export type GetTreeStartNodeData = any;

export type GetTreeStartNodeError = HTTPValidationError;

export interface GetNodeByKeyParams {
  /**
   * Tree Id
   * @format uuid
   */
  treeId: string;
  /** Node Key */
  nodeKey: string;
}

export type GetNodeByKeyData = any;

export type GetNodeByKeyError = HTTPValidationError;

export interface NavigateTreeParams {
  /**
   * Tree Id
   * @format uuid
   */
  treeId: string;
}

export type NavigateTreeData = any;

export type NavigateTreeError = HTTPValidationError;

export interface ProcessClassificationMultiQuestionAssessmentParams {
  /**
   * Tree Id
   * @format uuid
   */
  treeId: string;
  /** Node Key */
  nodeKey: string;
}

export type ProcessClassificationMultiQuestionAssessmentData = MultiQuestionAssessmentResponse;

export type ProcessClassificationMultiQuestionAssessmentError = HTTPValidationError;

export type SearchSanctionsData = SanctionsSearchResponse;

export type SearchSanctionsError = HTTPValidationError;

export interface GetSanctionsSearchEntityParams {
  /** Entity Id */
  entityId: string;
}

export type GetSanctionsSearchEntityData = SanctionEntity;

export type GetSanctionsSearchEntityError = HTTPValidationError;

/** Response Get Sanctions Jurisdictions */
export type GetSanctionsJurisdictionsData = string[];

/** Response Get Sanctions Programs */
export type GetSanctionsProgramsData = string[];

/** Response Get Entity Types */
export type GetEntityTypesData = string[];

/** Response Get Risk Levels */
export type GetRiskLevelsData = string[];

export type GetSanctionsListStatsData = SanctionsListStats;

export interface ListSanctionsListsParams {
  /**
   * Active Only
   * @default false
   */
  active_only?: boolean;
  /** List Type */
  list_type?: string | null;
  /** Authority */
  authority?: string | null;
  /**
   * Limit
   * @default 100
   */
  limit?: number;
  /**
   * Offset
   * @default 0
   */
  offset?: number;
}

/** Response List Sanctions Lists */
export type ListSanctionsListsData = SanctionsListResponse[];

export type ListSanctionsListsError = HTTPValidationError;

export type CreateSanctionsListData = SanctionsListResponse;

export type CreateSanctionsListError = HTTPValidationError;

export interface GetSanctionsListParams {
  /** List Id */
  listId: number;
}

export type GetSanctionsListData = SanctionsListResponse;

export type GetSanctionsListError = HTTPValidationError;

export interface UpdateSanctionsListParams {
  /** List Id */
  listId: number;
}

export type UpdateSanctionsListData = SanctionsListResponse;

export type UpdateSanctionsListError = HTTPValidationError;

export interface DeleteSanctionsListParams {
  /** List Id */
  listId: number;
}

export type DeleteSanctionsListData = any;

export type DeleteSanctionsListError = HTTPValidationError;

export interface GetSanctionsListEntriesParams {
  /** Entry Type */
  entry_type?: string | null;
  /**
   * Active Only
   * @default true
   */
  active_only?: boolean;
  /** Search */
  search?: string | null;
  /**
   * Limit
   * @default 100
   */
  limit?: number;
  /**
   * Offset
   * @default 0
   */
  offset?: number;
  /** List Id */
  listId: number;
}

/** Response Get Sanctions List Entries */
export type GetSanctionsListEntriesData = SanctionsListEntryResponse[];

export type GetSanctionsListEntriesError = HTTPValidationError;

export interface CreateSanctionsListEntryParams {
  /** List Id */
  listId: number;
}

export type CreateSanctionsListEntryData = SanctionsListEntryResponse;

export type CreateSanctionsListEntryError = HTTPValidationError;

export interface BulkImportEntriesParams {
  /** List Id */
  listId: number;
}

export type BulkImportEntriesData = AppApisSanctionsListManagementBulkImportResponse;

export type BulkImportEntriesError = HTTPValidationError;

export type GetListTypesData = any;

/** Response Import Xml Sanctions */
export type ImportXmlSanctionsData = Record<string, any>;

export type ImportXmlSanctionsError = HTTPValidationError;

export type GetComprehensivePricingAnalyticsData = ComprehensivePricingAnalytics;

/** Updates */
export type BulkUpdatePricingPayload = Record<string, any>[];

/** Response Bulk Update Pricing */
export type BulkUpdatePricingData = Record<string, any>;

export type BulkUpdatePricingError = HTTPValidationError;

export interface GetPricingAuditLogParams {
  /**
   * Limit
   * @default 50
   */
  limit?: number;
}

/** Response Get Pricing Audit Log */
export type GetPricingAuditLogData = Record<string, any>[];

export type GetPricingAuditLogError = HTTPValidationError;

export type SaveEnhancedUserProfileData = EnhancedUserProfileResponse;

export type SaveEnhancedUserProfileError = HTTPValidationError;

/** Response Get Enhanced User Profile */
export type GetEnhancedUserProfileData = EnhancedUserProfileResponse | null;

export interface GetAuditLogsParams {
  /** Company Id */
  company_id?: number | null;
  /** Action Filter */
  action_filter?: string | null;
  /** User Filter */
  user_filter?: string | null;
  /**
   * Limit
   * @default 100
   */
  limit?: number;
  /**
   * Offset
   * @default 0
   */
  offset?: number;
}

export type GetAuditLogsData = AuditLogResponse;

export type GetAuditLogsError = HTTPValidationError;

export interface GetUserActivitySummaryParams {
  /** Company Id */
  company_id?: number | null;
  /**
   * Days Back
   * @default 30
   */
  days_back?: number;
}

/** Response Get User Activity Summary */
export type GetUserActivitySummaryData = UserActivitySummary[];

export type GetUserActivitySummaryError = HTTPValidationError;

/** Details */
export type LogCustomActionPayload = Record<string, any> | null;

export interface LogCustomActionParams {
  /** Action */
  action: string;
  /** Resource Type */
  resource_type?: string | null;
  /** Resource Id */
  resource_id?: string | null;
}

/** Response Log Custom Action */
export type LogCustomActionData = Record<string, any>;

export type LogCustomActionError = HTTPValidationError;

export interface UpdateUserParams {
  /** Customer Id */
  customerId: string;
}

export type UpdateUserData = any;

export type UpdateUserError = HTTPValidationError;

export interface DeleteUserParams {
  /** Customer Id */
  customerId: string;
}

export type DeleteUserData = any;

export type DeleteUserError = HTTPValidationError;

export type CreateUserData = any;

export type CreateUserError = HTTPValidationError;

export interface GetDocumentCrossReferencesParams {
  /** Document Id */
  documentId: number;
}

/** Response Get Document Cross References */
export type GetDocumentCrossReferencesData = CrossReferenceResponse[];

export type GetDocumentCrossReferencesError = HTTPValidationError;

export type ProcessDocumentReferencesData = ProcessReferenceResponse;

export type ProcessDocumentReferencesError = HTTPValidationError;

export type ExtractReferencesFromTextData = ExtractReferencesResponse;

export type ExtractReferencesFromTextError = HTTPValidationError;

export interface RebuildDocumentCrossReferencesParams {
  /** Document Id */
  documentId: number;
}

export type RebuildDocumentCrossReferencesData = any;

export type RebuildDocumentCrossReferencesError = HTTPValidationError;

export type RebuildAllCrossReferencesData = any;

export type GetCrossReferenceStatsData = any;

/** Response List Saved Searches */
export type ListSavedSearchesData = SavedSearchResponse[];

export type CreateSavedSearchData = SavedSearchResponse;

export type CreateSavedSearchError = HTTPValidationError;

export interface GetSavedSearchParams {
  /** Search Id */
  searchId: number;
}

export type GetSavedSearchData = SavedSearchResponse;

export type GetSavedSearchError = HTTPValidationError;

export interface UpdateSavedSearchParams {
  /** Search Id */
  searchId: number;
}

export type UpdateSavedSearchData = SavedSearchResponse;

export type UpdateSavedSearchError = HTTPValidationError;

export interface DeleteSavedSearchParams {
  /** Search Id */
  searchId: number;
}

export type DeleteSavedSearchData = any;

export type DeleteSavedSearchError = HTTPValidationError;

export interface RunSavedSearchParams {
  /** Search Id */
  searchId: number;
}

export type RunSavedSearchData = any;

export type RunSavedSearchError = HTTPValidationError;

export interface GetSearchAlertsParams {
  /** Search Id */
  searchId: number;
}

/** Response Get Search Alerts */
export type GetSearchAlertsData = SearchAlertResponse[];

export type GetSearchAlertsError = HTTPValidationError;

export type CreateCompanyData = CompanyResponse;

export type CreateCompanyError = HTTPValidationError;

/** Response Get My Companies */
export type GetMyCompaniesData = CompanyResponse[];

export interface InviteTeamMemberParams {
  /** Company Id */
  companyId: number;
}

/** Response Invite Team Member */
export type InviteTeamMemberData = Record<string, any>;

export type InviteTeamMemberError = HTTPValidationError;

export interface GetTeamMembersParams {
  /** Company Id */
  companyId: number;
}

/** Response Get Team Members */
export type GetTeamMembersData = TeamMemberResponse[];

export type GetTeamMembersError = HTTPValidationError;

export interface GetPendingInvitationsParams {
  /** Company Id */
  companyId: number;
}

/** Response Get Pending Invitations */
export type GetPendingInvitationsData = InvitationResponse[];

export type GetPendingInvitationsError = HTTPValidationError;

export interface UpdateMemberRoleParams {
  /** Company Id */
  companyId: number;
  /** Member Id */
  memberId: number;
}

/** Response Update Member Role */
export type UpdateMemberRoleData = Record<string, any>;

export type UpdateMemberRoleError = HTTPValidationError;

export interface RemoveTeamMemberParams {
  /** Company Id */
  companyId: number;
  /** Member Id */
  memberId: number;
}

/** Response Remove Team Member */
export type RemoveTeamMemberData = Record<string, any>;

export type RemoveTeamMemberError = HTTPValidationError;

/** Response Get Role Definitions */
export type GetRoleDefinitionsData = RoleDefinitionResponse[];

export interface GetCompanyProfileParams {
  /** Company Id */
  companyId: number;
}

export type GetCompanyProfileData = CompanyResponse;

export type GetCompanyProfileError = HTTPValidationError;

export interface UpdateCompanyProfileParams {
  /** Company Id */
  companyId: number;
}

export type UpdateCompanyProfileData = CompanyResponse;

export type UpdateCompanyProfileError = HTTPValidationError;

export interface ListPendingDocumentsParams {
  /**
   * Limit
   * @default 50
   */
  limit?: number;
  /**
   * Offset
   * @default 0
   */
  offset?: number;
}

export type ListPendingDocumentsData = PendingDocumentsListResponse;

export type ListPendingDocumentsError = HTTPValidationError;

export type ApproveOrRejectDocumentData = any;

export type ApproveOrRejectDocumentError = HTTPValidationError;

export type GetPendingStatsData = any;

/** Response Save User Profile */
export type SaveUserProfileData = Record<string, any>;

export type SaveUserProfileError = HTTPValidationError;

export type GetUserProfileData = UserProfileResponse;

/** Response Delete User Profile */
export type DeleteUserProfileData = Record<string, any>;

export interface GetDocumentAnnotationsParams {
  /** Annotation Type */
  annotation_type?: string | null;
  /** Visibility */
  visibility?: string | null;
  /** Document Id */
  documentId: number;
}

/** Response Get Document Annotations */
export type GetDocumentAnnotationsData = DocumentAnnotationOutput[];

export type GetDocumentAnnotationsError = HTTPValidationError;

export interface CreateAnnotationParams {
  /** Document Id */
  documentId: number;
}

export type CreateAnnotationData = DocumentAnnotationOutput;

export type CreateAnnotationError = HTTPValidationError;

export interface UpdateAnnotationParams {
  /** Annotation Id */
  annotationId: number;
}

export type UpdateAnnotationData = DocumentAnnotationOutput;

export type UpdateAnnotationError = HTTPValidationError;

export interface DeleteAnnotationParams {
  /** Annotation Id */
  annotationId: number;
}

export type DeleteAnnotationData = any;

export type DeleteAnnotationError = HTTPValidationError;

export interface ResolveAnnotationParams {
  /** Annotation Id */
  annotationId: number;
}

export type ResolveAnnotationData = any;

export type ResolveAnnotationError = HTTPValidationError;

/** Response Get User Bookmarks */
export type GetUserBookmarksData = UserBookmarkOutput[];

export type CreateBookmarkData = UserBookmarkOutput;

export type CreateBookmarkError = HTTPValidationError;

export interface DeleteBookmarkParams {
  /** Bookmark Id */
  bookmarkId: number;
}

export type DeleteBookmarkData = any;

export type DeleteBookmarkError = HTTPValidationError;

export interface GetDocumentActivityParams {
  /**
   * Limit
   * @default 50
   */
  limit?: number;
  /** Document Id */
  documentId: number;
}

/** Response Get Document Activity */
export type GetDocumentActivityData = CollaborationActivity[];

export type GetDocumentActivityError = HTTPValidationError;

/** Metadata */
export type TrackDocumentActivityPayload = Record<string, any>;

export interface TrackDocumentActivityParams {
  /** Activity Type */
  activity_type: string;
  /** Description */
  description: string;
  /** Document Id */
  documentId: number;
}

export type TrackDocumentActivityData = any;

export type TrackDocumentActivityError = HTTPValidationError;

export interface GetCollaborationStatsParams {
  /** Document Id */
  documentId: number;
}

export type GetCollaborationStatsData = any;

export type GetCollaborationStatsError = HTTPValidationError;

export type GetUserCollaborationSummaryData = any;

/** Response List Regulatory Feeds */
export type ListRegulatoryFeedsData = EnhancedRegulatoryFeed[];

/** Feed Data */
export type CreateRegulatoryFeedPayload = Record<string, any>;

export type CreateRegulatoryFeedData = EnhancedRegulatoryFeed;

export type CreateRegulatoryFeedError = HTTPValidationError;

export interface GetRelatedDocumentsForDocParams {
  /** Document Id */
  documentId: number;
}

/** Response Get Related Documents For Doc */
export type GetRelatedDocumentsForDocData = RelatedDocument[];

export type GetRelatedDocumentsForDocError = HTTPValidationError;

export interface CreateDocumentCrossReferenceParams {
  /** Document Id */
  documentId: number;
}

export type CreateDocumentCrossReferenceData = AppApisRegulatoryMonitoringCrossReference;

export type CreateDocumentCrossReferenceError = HTTPValidationError;

export interface GetDocumentCrossReferencesMonitoringParams {
  /** Document Id */
  documentId: number;
}

/** Response Get Document Cross References Monitoring */
export type GetDocumentCrossReferencesMonitoringData = AppApisRegulatoryMonitoringCrossReference[];

export type GetDocumentCrossReferencesMonitoringError = HTTPValidationError;

export interface AnalyzeDocumentReferencesParams {
  /** Document Id */
  documentId: number;
}

export type AnalyzeDocumentReferencesData = DocumentLinkingResult;

export type AnalyzeDocumentReferencesError = HTTPValidationError;

export interface ProcessFeedEnhancedParams {
  /** Feed Id */
  feedId: number;
}

export type ProcessFeedEnhancedData = FeedProcessingResult;

export type ProcessFeedEnhancedError = HTTPValidationError;

export type BulkProcessFeedsData = BatchProcessingResult;

export type BulkProcessFeedsError = HTTPValidationError;

export interface GetFeedHealthMetricsParams {
  /** Feed Id */
  feedId: number;
}

export type GetFeedHealthMetricsData = FeedHealthMetrics;

export type GetFeedHealthMetricsError = HTTPValidationError;

export interface PerformFeedHealthCheckParams {
  /** Feed Id */
  feedId: number;
}

export type PerformFeedHealthCheckData = any;

export type PerformFeedHealthCheckError = HTTPValidationError;

/** Schedule Config */
export type ConfigureFeedSchedulingPayload = Record<string, any>;

export interface ConfigureFeedSchedulingParams {
  /** Feed Id */
  feedId: number;
}

export type ConfigureFeedSchedulingData = SchedulingConfiguration;

export type ConfigureFeedSchedulingError = HTTPValidationError;

export interface SendFeedNotificationParams {
  /** Feed Id */
  feedId: number;
}

export type SendFeedNotificationData = NotificationResult;

export type SendFeedNotificationError = HTTPValidationError;

export interface GetFeedNotificationsParams {
  /**
   * Limit
   * @min 1
   * @max 100
   * @default 20
   */
  limit?: number;
  /** Feed Id */
  feedId: number;
}

export type GetFeedNotificationsData = any;

export type GetFeedNotificationsError = HTTPValidationError;

/** Alert Config */
export type ConfigureFeedAlertsPayload = Record<string, any>;

export interface ConfigureFeedAlertsParams {
  /** Feed Id */
  feedId: number;
}

export type ConfigureFeedAlertsData = any;

export type ConfigureFeedAlertsError = HTTPValidationError;

export type GetSystemStatusData = any;

export type SubmitForValidationData = ValidationResponse;

export type SubmitForValidationError = HTTPValidationError;

export interface GetAdminValidationTasksParams {
  /** Status */
  status?: string | null;
}

export type GetAdminValidationTasksData = ValidationTasksListResponse;

export type GetAdminValidationTasksError = HTTPValidationError;

export interface GetValidationTaskDetailParams {
  /** Validation Id */
  validationId: string;
}

export type GetValidationTaskDetailData = ValidationTaskDetail;

export type GetValidationTaskDetailError = HTTPValidationError;

export type RespondToValidationData = AdminValidationResponse;

export type RespondToValidationError = HTTPValidationError;

export interface GetUserValidationStatusParams {
  /** Assessment Id */
  assessmentId: string;
}

export type GetUserValidationStatusData = any;

export type GetUserValidationStatusError = HTTPValidationError;

export interface GetInvitationDetailsParams {
  /** Invitation Token */
  invitationToken: string;
}

export type GetInvitationDetailsData = InvitationDetailsResponse;

export type GetInvitationDetailsError = HTTPValidationError;

/** Response Accept Invitation */
export type AcceptInvitationData = Record<string, any>;

export type AcceptInvitationError = HTTPValidationError;

/** Response Resend Invitation */
export type ResendInvitationData = Record<string, any>;

export type ResendInvitationError = HTTPValidationError;

export interface CancelInvitationParams {
  /** Invitation Id */
  invitationId: number;
}

/** Response Cancel Invitation */
export type CancelInvitationData = Record<string, any>;

export type CancelInvitationError = HTTPValidationError;

export interface SendInvitationEmailManuallyParams {
  /** Invitation Id */
  invitation_id: number;
  /** Custom Message */
  custom_message?: string | null;
}

/** Response Send Invitation Email Manually */
export type SendInvitationEmailManuallyData = Record<string, any>;

export type SendInvitationEmailManuallyError = HTTPValidationError;

export type CreateCustomerData = CustomerProfile;

export type CreateCustomerError = HTTPValidationError;

export interface ListCustomersParams {
  /**
   * Limit
   * @max 1000
   * @default 50
   */
  limit?: number;
  /**
   * Offset
   * @min 0
   * @default 0
   */
  offset?: number;
  /** Search */
  search?: string | null;
  /** Risk Category */
  risk_category?: string | null;
}

/** Response List Customers */
export type ListCustomersData = CustomerProfile[];

export type ListCustomersError = HTTPValidationError;

export interface UpdateCustomerParams {
  /** Customer Id */
  customerId: number;
}

export type UpdateCustomerData = CustomerProfile;

export type UpdateCustomerError = HTTPValidationError;

export interface DeleteCustomerParams {
  /** Customer Id */
  customerId: number;
}

/** Response Delete Customer */
export type DeleteCustomerData = Record<string, any>;

export type DeleteCustomerError = HTTPValidationError;

/** Response Batch Screen Customers */
export type BatchScreenCustomersData = Record<string, any>;

export type BatchScreenCustomersError = HTTPValidationError;

/** Response Export Screening Results */
export type ExportScreeningResultsData = Record<string, any>;

export type ExportScreeningResultsError = HTTPValidationError;

/** Request */
export type ScreenCustomerPayload = VersionedScreeningRequest | null;

export interface ScreenCustomerParams {
  /** Customer Id */
  customerId: number;
}

export type ScreenCustomerData = ScreeningResult;

export type ScreenCustomerError = HTTPValidationError;

export interface GetScreeningHistoryParams {
  /** Customer Id */
  customerId: number;
}

/** Response Get Screening History */
export type GetScreeningHistoryData = ScreeningResult[];

export type GetScreeningHistoryError = HTTPValidationError;

export interface GetScreeningAlertsParams {
  /** Status */
  status?: string | null;
  /** Priority */
  priority?: string | null;
  /**
   * Limit
   * @max 200
   * @default 50
   */
  limit?: number;
}

/** Response Get Screening Alerts */
export type GetScreeningAlertsData = ScreeningAlert[];

export type GetScreeningAlertsError = HTTPValidationError;

export type VerifyHitData = HitVerificationResponse;

export type VerifyHitError = HTTPValidationError;

/** Response Search Watchlists */
export type SearchWatchlistsData = WatchlistSearchResult[];

export type SearchWatchlistsError = HTTPValidationError;

export interface QualifyScreeningMatchParams {
  /** Match Id */
  matchId: number;
}

export type QualifyScreeningMatchData = MatchQualificationResponse;

export type QualifyScreeningMatchError = HTTPValidationError;

/** Response Get Risk Categories */
export type GetRiskCategoriesData = RiskCategory[];

export interface GetRiskIndicatorsParams {
  /** Category Id */
  category_id?: number | null;
}

/** Response Get Risk Indicators */
export type GetRiskIndicatorsData = RiskIndicator[];

export type GetRiskIndicatorsError = HTTPValidationError;

export interface ListCriticalCountriesParams {
  /** Search */
  search?: string | null;
  /** Category */
  category?: string | null;
  /**
   * Limit
   * @default 100
   */
  limit?: number;
  /**
   * Offset
   * @default 0
   */
  offset?: number;
}

/** Response List Critical Countries */
export type ListCriticalCountriesData = CriticalCountry[];

export type ListCriticalCountriesError = HTTPValidationError;

export type CreateCountryData = CriticalCountry;

export type CreateCountryError = HTTPValidationError;

export interface GetCountryDetailParams {
  /** Country Id */
  countryId: number;
}

export type GetCountryDetailData = CriticalCountry;

export type GetCountryDetailError = HTTPValidationError;

export interface UpdateCountryParams {
  /** Country Id */
  countryId: number;
}

export type UpdateCountryData = CriticalCountry;

export type UpdateCountryError = HTTPValidationError;

export interface DeleteCountryParams {
  /** Country Id */
  countryId: number;
}

export type DeleteCountryData = any;

export type DeleteCountryError = HTTPValidationError;

export type CreateOrUpdateRiskAssessmentData = any;

export type CreateOrUpdateRiskAssessmentError = HTTPValidationError;

export interface DeleteRiskAssessmentParams {
  /** Country Id */
  countryId: number;
  /** Indicator Id */
  indicatorId: number;
}

export type DeleteRiskAssessmentData = any;

export type DeleteRiskAssessmentError = HTTPValidationError;

/** Response Search Critical Countries */
export type SearchCriticalCountriesData = CriticalCountry[];

export type SearchCriticalCountriesError = HTTPValidationError;

export type GetCriticalCountriesStatsData = any;

export type BulkUploadCriticalCountriesData = any;

export type BulkUploadCriticalCountriesError = HTTPValidationError;

export type DownloadCriticalCountriesTemplateData = any;

export interface GetCriticalCountriesListParams {
  /**
   * Limit
   * @default 50
   */
  limit?: number;
  /**
   * Offset
   * @default 0
   */
  offset?: number;
  /** Search */
  search?: string | null;
  /** Risk Level */
  risk_level?: string | null;
  /** Is Active */
  is_active?: boolean | null;
  /** Has Sanctions */
  has_sanctions?: boolean | null;
  /** Export Control Member */
  export_control_member?: boolean | null;
}

export type GetCriticalCountriesListData = any;

export type GetCriticalCountriesListError = HTTPValidationError;

export type GetUserUsageSummaryData = UsageSummary;

export interface GetComponentUsageBreakdownParams {
  /**
   * Days
   * Number of days to analyze
   * @default 30
   */
  days?: number;
}

/** Response Get Component Usage Breakdown */
export type GetComponentUsageBreakdownData = ComponentUsage[];

export type GetComponentUsageBreakdownError = HTTPValidationError;

export interface GetDailyUsageChartParams {
  /**
   * Days
   * Number of days to chart
   * @default 30
   */
  days?: number;
}

/** Response Get Daily Usage Chart */
export type GetDailyUsageChartData = DailyUsagePoint[];

export type GetDailyUsageChartError = HTTPValidationError;

export type GetRealTimeMetricsData = RealTimeMetrics;

/** Response Get Active Spending Alerts */
export type GetActiveSpendingAlertsData = SpendingAlert[];

/** Thresholds */
export type ConfigureSpendingAlertsPayload = AlertThreshold[];

export type ConfigureSpendingAlertsData = any;

export type ConfigureSpendingAlertsError = HTTPValidationError;

export type CheckAndTriggerAlertsData = any;

export interface DismissSpendingAlertParams {
  /** Alert Id */
  alertId: number;
}

export type DismissSpendingAlertData = any;

export type DismissSpendingAlertError = HTTPValidationError;

export type GetAdminUsageAnalyticsData = AdminUsageAnalytics;

export type GetAdminRealTimeDashboardData = any;

export type SubmitDocumentData = SubmissionResponse;

export type SubmitDocumentError = HTTPValidationError;

export type SubmitCaseStudyData = SubmissionResponse;

export type SubmitCaseStudyError = HTTPValidationError;

export type SubmitBlogArticleData = SubmissionResponse;

export type SubmitBlogArticleError = HTTPValidationError;

export type GetMySubmissionsData = any;

/** Response List Admin Tasks */
export type ListAdminTasksData = AdminTask[];

/** Response Get Pending Tasks */
export type GetPendingTasksData = AdminTask[];

export interface UpdateTaskParams {
  /** Task Id */
  taskId: string;
}

export type UpdateTaskData = TaskResponse;

export type UpdateTaskError = HTTPValidationError;

export type SaveAssessmentData = SaveAssessmentResponse;

export type SaveAssessmentError = HTTPValidationError;

export interface LoadAssessmentParams {
  /** Assessment Id */
  assessmentId: string;
}

export type LoadAssessmentData = LoadAssessmentResponse;

export type LoadAssessmentError = HTTPValidationError;

export type ListUserAssessmentsData = UserAssessmentsResponse;

export interface DeleteAssessmentParams {
  /** Assessment Id */
  assessmentId: string;
}

export type DeleteAssessmentData = any;

export type DeleteAssessmentError = HTTPValidationError;

/** Response Get Module Pricing Configurations */
export type GetModulePricingConfigurationsData = ModulePricingConfig[];

export type CreateModulePricingConfigurationData = ModulePricingConfig;

export type CreateModulePricingConfigurationError = HTTPValidationError;

export interface UpdateModulePricingConfigurationParams {
  /** Module Name */
  moduleName: string;
}

export type UpdateModulePricingConfigurationData = ModulePricingConfig;

export type UpdateModulePricingConfigurationError = HTTPValidationError;

export interface DeleteModulePricingConfigurationParams {
  /** Module Name */
  moduleName: string;
}

export type DeleteModulePricingConfigurationData = any;

export type DeleteModulePricingConfigurationError = HTTPValidationError;

export interface GetModulePricingConfigurationParams {
  /** Module Name */
  moduleName: string;
}

export type GetModulePricingConfigurationData = ModulePricingConfig;

export type GetModulePricingConfigurationError = HTTPValidationError;

export type SendAssessmentEmailData = EmailResponse;

export type SendAssessmentEmailError = HTTPValidationError;

export type CheckFreeTierEligibilityData = FreeTierStatus;

export type ActivateFreeTierCreditsData = AppApisFreeTierFreeTierActivationResponse;

export type GetTrialUsageStatsData = TrialUsageStats;

export interface ExtendTrialCreditsParams {
  /**
   * Bonus Credits
   * @default 25
   */
  bonus_credits?: number;
}

export type ExtendTrialCreditsData = any;

export type ExtendTrialCreditsError = HTTPValidationError;

export type UploadAssessmentFormData = UploadResponse;

export type UploadAssessmentFormError = HTTPValidationError;

export interface AnalyzeUploadedFormParams {
  /** File Id */
  fileId: string;
}

export type AnalyzeUploadedFormData = ProcessedFormResponse;

export type AnalyzeUploadedFormError = HTTPValidationError;

export type ListUploadedFormsData = any;

export interface ExportAssessmentPdfParams {
  /** Assessment Id */
  assessmentId: string;
}

export type ExportAssessmentPdfData = any;

export type ExportAssessmentPdfError = HTTPValidationError;

/** Response Get All Critical Countries */
export type GetAllCriticalCountriesData = CriticalCountryResponse[];

export type CreateCriticalCountryData = CriticalCountryResponse;

export type CreateCriticalCountryError = HTTPValidationError;

export interface UpdateCriticalCountryParams {
  /** Countryid */
  countryId: string;
}

export type UpdateCriticalCountryData = CriticalCountryResponse;

export type UpdateCriticalCountryError = HTTPValidationError;

export interface DeleteCriticalCountryParams {
  /** Countryid */
  countryId: string;
}

export type DeleteCriticalCountryData = any;

export type DeleteCriticalCountryError = HTTPValidationError;

export type GenerateIndividualReportData = any;

export type GenerateIndividualReportError = HTTPValidationError;

export type GenerateBatchReportData = any;

export type GenerateBatchReportError = HTTPValidationError;

export type GenerateCountryReportData = any;

export type GenerateCountryReportError = HTTPValidationError;

export type ExportCriticalCountriesData = any;

export type ExportCriticalCountriesError = HTTPValidationError;

export type CreateTransactionData = CustomerTransactionOutput;

export type CreateTransactionError = HTTPValidationError;

export interface ListTransactionsParams {
  /** Customer Id */
  customer_id?: number | null;
  /** Transaction Type */
  transaction_type?: string | null;
  /** Status */
  status?: string | null;
  /**
   * Limit
   * @max 1000
   * @default 50
   */
  limit?: number;
  /**
   * Offset
   * @min 0
   * @default 0
   */
  offset?: number;
}

/** Response List Transactions */
export type ListTransactionsData = CustomerTransactionOutput[];

export type ListTransactionsError = HTTPValidationError;

export interface UpdateTransactionParams {
  /** Transaction Id */
  transactionId: number;
}

export type UpdateTransactionData = CustomerTransactionOutput;

export type UpdateTransactionError = HTTPValidationError;

export interface DeleteTransactionParams {
  /** Transaction Id */
  transactionId: number;
}

/** Response Delete Transaction */
export type DeleteTransactionData = Record<string, string>;

export type DeleteTransactionError = HTTPValidationError;

export type GetMonitoringConfigurationData = MonitoringConfiguration;

export type SaveMonitoringConfigurationData = any;

export type SaveMonitoringConfigurationError = HTTPValidationError;

export type GetMonitoringStatusData = MonitoringReport;

export type TriggerMonitoringData = any;

export type TriggerMonitoringError = HTTPValidationError;

export interface GetBackgroundJobsParams {
  /**
   * Limit
   * @default 20
   */
  limit?: number;
}

/** Response Get Background Jobs */
export type GetBackgroundJobsData = BackgroundJobStatus[];

export type GetBackgroundJobsError = HTTPValidationError;

export interface GetCustomerMonitoringHistoryParams {
  /**
   * Limit
   * @default 10
   */
  limit?: number;
  /** Customer Id */
  customerId: string;
}

export type GetCustomerMonitoringHistoryData = any;

export type GetCustomerMonitoringHistoryError = HTTPValidationError;

export type GetMonitoringSystemHealthData = any;

/** Response List Monitoring Schedules */
export type ListMonitoringSchedulesData = MonitoringScheduleResponse[];

export type CreateMonitoringScheduleData = MonitoringScheduleResponse;

export type CreateMonitoringScheduleError = HTTPValidationError;

export interface GetMonitoringScheduleParams {
  /** Schedule Id */
  scheduleId: number;
}

export type GetMonitoringScheduleData = MonitoringScheduleResponse;

export type GetMonitoringScheduleError = HTTPValidationError;

export interface UpdateMonitoringScheduleParams {
  /** Schedule Id */
  scheduleId: number;
}

export type UpdateMonitoringScheduleData = MonitoringScheduleResponse;

export type UpdateMonitoringScheduleError = HTTPValidationError;

export interface DeleteMonitoringScheduleParams {
  /** Schedule Id */
  scheduleId: number;
}

export type DeleteMonitoringScheduleData = any;

export type DeleteMonitoringScheduleError = HTTPValidationError;

export interface ListAutomationJobsParams {
  /**
   * Limit
   * @default 50
   */
  limit?: number;
}

/** Response List Automation Jobs */
export type ListAutomationJobsData = AutomationJobResponse[];

export type ListAutomationJobsError = HTTPValidationError;

export interface GetAutomationJobParams {
  /** Job Id */
  jobId: number;
}

export type GetAutomationJobData = AutomationJobResponse;

export type GetAutomationJobError = HTTPValidationError;

export type GetNotificationPreferencesData = NotificationPreferencesResponse;

export type UpdateNotificationPreferencesData = NotificationPreferencesResponse;

export type UpdateNotificationPreferencesError = HTTPValidationError;

export interface TriggerManualScreeningParams {
  /** Schedule Id */
  scheduleId: number;
}

export type TriggerManualScreeningData = any;

export type TriggerManualScreeningError = HTTPValidationError;

export type UpdateRiskAssessmentsData = UpdateRiskAssessmentsResponse;

export type UpdateRiskAssessmentsError = HTTPValidationError;

export type ScheduleRiskAssessmentsData = ScheduleRiskAssessmentsResponse;

export type ScheduleRiskAssessmentsError = HTTPValidationError;

export type PredictCustomerRisksData = PredictiveRiskResponse;

export type PredictCustomerRisksError = HTTPValidationError;

export type AnalyzeRiskTrendsData = RiskTrendAnalysisResponse;

export type AnalyzeRiskTrendsError = HTTPValidationError;

export type GetModelPerformanceData = ModelPerformanceResponse;

export type GetModelPerformanceError = HTTPValidationError;

export type UploadCustomerDocumentData = AppApisDocumentManagementDocumentUploadResponse;

export type UploadCustomerDocumentError = HTTPValidationError;

export type ListCustomerDocumentsData = AppApisDocumentManagementDocumentListResponse;

export type ListCustomerDocumentsError = HTTPValidationError;

export type ApproveDocumentData = DocumentApprovalResponse;

export type ApproveDocumentError = HTTPValidationError;

export type GetCustomerDocumentAnalyticsData = DocumentAnalyticsResponse;

export interface ListClassificationNotesParams {
  /** Tree Id */
  tree_id?: string | null;
  /** Module Type */
  module_type?: string | null;
}

/** Response List Classification Notes */
export type ListClassificationNotesData = ClassificationNote[];

export type ListClassificationNotesError = HTTPValidationError;

export type CreateClassificationNoteData = NoteResponse;

export type CreateClassificationNoteError = HTTPValidationError;

export interface GetClassificationNoteByKeyParams {
  /** Note Key */
  noteKey: string;
}

export type GetClassificationNoteByKeyData = ClassificationNote;

export type GetClassificationNoteByKeyError = HTTPValidationError;

export interface UpdateClassificationNoteParams {
  /** Note Id */
  noteId: number;
}

export type UpdateClassificationNoteData = NoteResponse;

export type UpdateClassificationNoteError = HTTPValidationError;

export interface DeleteClassificationNoteParams {
  /** Note Id */
  noteId: number;
}

export type DeleteClassificationNoteData = NoteResponse;

export type DeleteClassificationNoteError = HTTPValidationError;

export type GetScreeningExplanationData = ClassificationNote;

export type CreateOrUpdateScreeningExplanationData = NoteResponse;

export type CreateOrUpdateScreeningExplanationError = HTTPValidationError;

export type CreateProductData = CustomerProduct;

export type CreateProductError = HTTPValidationError;

export interface ListProductsParams {
  /** Customer Id */
  customer_id?: number | null;
  /** Product Type */
  product_type?: string | null;
  /** Control Status */
  control_status?: string | null;
  /** Search */
  search?: string | null;
  /**
   * Limit
   * @max 1000
   * @default 50
   */
  limit?: number;
  /**
   * Offset
   * @min 0
   * @default 0
   */
  offset?: number;
}

/** Response List Products */
export type ListProductsData = CustomerProduct[];

export type ListProductsError = HTTPValidationError;

export interface UpdateProductParams {
  /** Product Id */
  productId: number;
}

export type UpdateProductData = CustomerProduct;

export type UpdateProductError = HTTPValidationError;

export interface DeleteProductParams {
  /** Product Id */
  productId: number;
}

/** Response Delete Product */
export type DeleteProductData = Record<string, string>;

export type DeleteProductError = HTTPValidationError;

export interface UpdateProductReviewParams {
  /** Product Id */
  productId: number;
}

export type UpdateProductReviewData = CustomerProduct;

export type UpdateProductReviewError = HTTPValidationError;

/** Response Get Customer Product Categories */
export type GetCustomerProductCategoriesData = string[];

export type SearchProductsData = ProductSearchResponse;

export type SearchProductsError = HTTPValidationError;

export interface GetProductClassificationParams {
  /** Product Id */
  productId: string;
}

export type GetProductClassificationData = ProductClassification;

export type GetProductClassificationError = HTTPValidationError;

/** Response Get Control Regimes */
export type GetControlRegimesData = string[];

/** Response Get Classification Categories */
export type GetClassificationCategoriesData = string[];

/** Response Get Product Risk Levels */
export type GetProductRiskLevelsData = string[];

export type GetMonitoringDashboardSummaryData = MonitoringDashboardResponse;

export type GetCustomerMonitoringAnalyticsData = CustomerMonitoringAnalytics;

export interface GetScreeningPerformanceMetricsParams {
  /**
   * Days
   * @default 30
   */
  days?: number;
}

export type GetScreeningPerformanceMetricsData = ScreeningMetricsResponse;

export type GetScreeningPerformanceMetricsError = HTTPValidationError;

export type GetAutomationPerformanceMetricsData = AutomationPerformanceResponse;

export type GetComplianceRegulatoryMetricsData = ComplianceMetricsResponse;

export type GetMonitoringAlertAnalyticsData = AlertAnalyticsResponse;

export interface GetTrendAnalysisParams {
  /**
   * Days
   * @default 90
   */
  days?: number;
}

export type GetTrendAnalysisData = TrendAnalysisResponse;

export type GetTrendAnalysisError = HTTPValidationError;

export type SaveArticleData = SavedArticleResponse;

export type SaveArticleError = HTTPValidationError;

export interface UnsaveArticleParams {
  /** Document Id */
  documentId: string;
}

export type UnsaveArticleData = any;

export type UnsaveArticleError = HTTPValidationError;

export interface GetSavedArticlesParams {
  /** Category Id */
  category_id?: number | null;
}

/** Response Get Saved Articles */
export type GetSavedArticlesData = SavedArticleResponse[];

export type GetSavedArticlesError = HTTPValidationError;

export interface CheckIfSavedParams {
  /** Document Id */
  documentId: string;
}

export type CheckIfSavedData = any;

export type CheckIfSavedError = HTTPValidationError;

/** Response Get Article Categories */
export type GetArticleCategoriesData = AppApisSavedArticlesCategoryResponse[];

export type CreateArticleCategoryData = AppApisSavedArticlesCategoryResponse;

export type CreateArticleCategoryError = HTTPValidationError;

export interface UpdateArticleCategoryParams {
  /** Category Id */
  categoryId: number;
}

export type UpdateArticleCategoryData = AppApisSavedArticlesCategoryResponse;

export type UpdateArticleCategoryError = HTTPValidationError;

export interface DeleteArticleCategoryParams {
  /** Category Id */
  categoryId: number;
}

export type DeleteArticleCategoryData = any;

export type DeleteArticleCategoryError = HTTPValidationError;

export interface AssignCategoriesToArticleParams {
  /** Article Id */
  articleId: number;
}

export type AssignCategoriesToArticleData = SavedArticleResponse;

export type AssignCategoriesToArticleError = HTTPValidationError;

export type CreateSupportRequestData = SupportRequestResponse;

export type CreateSupportRequestError = HTTPValidationError;

export interface GetUserSupportTicketsParams {
  /** Status */
  status?: string | null;
}

/** Response Get User Support Tickets */
export type GetUserSupportTicketsData = SupportTicket[];

export type GetUserSupportTicketsError = HTTPValidationError;

export interface GetAdminSupportTicketsParams {
  /** Status */
  status?: string | null;
  /** Priority */
  priority?: string | null;
}

export type GetAdminSupportTicketsData = SupportTicketListResponse;

export type GetAdminSupportTicketsError = HTTPValidationError;

export interface AdminRespondToTicketParams {
  /** Ticket Id */
  ticketId: string;
}

export type AdminRespondToTicketData = any;

export type AdminRespondToTicketError = HTTPValidationError;

export interface GetSupportTicketDetailParams {
  /** Ticket Id */
  ticketId: string;
}

export type GetSupportTicketDetailData = SupportTicket;

export type GetSupportTicketDetailError = HTTPValidationError;

/** Response Get Component Pricing */
export type GetComponentPricingData = ComponentPricing[];

export type CreateComponentPricingData = ComponentPricing;

export type CreateComponentPricingError = HTTPValidationError;

export interface UpdateComponentPricingParams {
  /** Pricing Id */
  pricingId: number;
}

export type UpdateComponentPricingData = ComponentPricing;

export type UpdateComponentPricingError = HTTPValidationError;

export interface DeleteComponentPricingParams {
  /** Pricing Id */
  pricingId: number;
}

/** Response Delete Component Pricing */
export type DeleteComponentPricingData = Record<string, any>;

export type DeleteComponentPricingError = HTTPValidationError;

/** Response Get Pricing Feature Flags */
export type GetPricingFeatureFlagsData = PricingFeatureFlag[];

export interface UpdatePricingFeatureFlagParams {
  /** Component Name */
  componentName: string;
}

export type UpdatePricingFeatureFlagData = PricingFeatureFlag;

export type UpdatePricingFeatureFlagError = HTTPValidationError;

export interface CheckActionPricingParams {
  /** Component Name */
  componentName: string;
  /** Action Name */
  actionName: string;
}

/** Response Check Action Pricing */
export type CheckActionPricingData = Record<string, any>;

export type CheckActionPricingError = HTTPValidationError;

/** Response Get Usage Tier Pricing */
export type GetUsageTierPricingData = UsageTierPricing[];

/** Request */
export type CreateUsageTierPricingPayload = Record<string, any>;

export type CreateUsageTierPricingData = UsageTierPricing;

export type CreateUsageTierPricingError = HTTPValidationError;

/** Response Get Geographic Pricing */
export type GetGeographicPricingData = GeographicPricing[];

/** Request */
export type CreateGeographicPricingPayload = Record<string, any>;

export type CreateGeographicPricingData = GeographicPricing;

export type CreateGeographicPricingError = HTTPValidationError;

/** Response Get Hybrid Pricing Models */
export type GetHybridPricingModelsData = HybridPricingModel[];

/** Request */
export type CreateHybridPricingModelPayload = Record<string, any>;

export type CreateHybridPricingModelData = HybridPricingModel;

export type CreateHybridPricingModelError = HTTPValidationError;

export interface CheckDynamicPricingParams {
  /** User Country */
  user_country?: string | null;
  /** Monthly Usage */
  monthly_usage?: number | null;
  /** Subscription Tier */
  subscription_tier?: string | null;
  /** Component Name */
  componentName: string;
  /** Action Name */
  actionName: string;
}

/** Response Check Dynamic Pricing */
export type CheckDynamicPricingData = Record<string, any>;

export type CheckDynamicPricingError = HTTPValidationError;

export interface GetInvoiceHistoryParams {
  /** Company Id */
  company_id?: number | null;
  /** Status */
  status?: string | null;
  /**
   * Limit
   * @default 50
   */
  limit?: number;
  /**
   * Offset
   * @default 0
   */
  offset?: number;
}

export type GetInvoiceHistoryData = BillingHistoryResponse;

export type GetInvoiceHistoryError = HTTPValidationError;

export type CreateInvoiceData = AppApisBillingManagementInvoiceResponse;

export type CreateInvoiceError = HTTPValidationError;

export interface GetUsageAnalyticsParams {
  /** Company Id */
  company_id?: number | null;
  /**
   * Period Days
   * @default 30
   */
  period_days?: number;
}

export type GetUsageAnalyticsData = UsageAnalyticsResponse;

export type GetUsageAnalyticsError = HTTPValidationError;

export interface DownloadInvoiceParams {
  /** Invoice Id */
  invoiceId: number;
}

/** Response Download Invoice */
export type DownloadInvoiceData = Record<string, any>;

export type DownloadInvoiceError = HTTPValidationError;

export interface UpdateInvoiceStatusParams {
  /** Status */
  status: string;
  /** Payment Method */
  payment_method?: string | null;
  /** Invoice Id */
  invoiceId: number;
}

/** Response Update Invoice Status */
export type UpdateInvoiceStatusData = Record<string, any>;

export type UpdateInvoiceStatusError = HTTPValidationError;

export interface GetBillingSummaryParams {
  /** Company Id */
  company_id?: number | null;
}

/** Response Get Billing Summary */
export type GetBillingSummaryData = Record<string, any>;

export type GetBillingSummaryError = HTTPValidationError;

export interface GetBillingSettingsParams {
  /** Company Id */
  company_id?: number | null;
}

export type GetBillingSettingsData = BillingSettingsResponse;

export type GetBillingSettingsError = HTTPValidationError;

export interface UpdateBillingSettingsParams {
  /** Company Id */
  company_id?: number | null;
}

/** Response Update Billing Settings */
export type UpdateBillingSettingsData = Record<string, any>;

export type UpdateBillingSettingsError = HTTPValidationError;

/** Response Create Template */
export type CreateTemplateData = Record<string, any>;

export type CreateTemplateError = HTTPValidationError;

export type ListTemplatesData = TemplatesListResponse;

export interface GetTemplateParams {
  /** Template Id */
  templateId: number;
}

export type GetTemplateData = TemplateResponse;

export type GetTemplateError = HTTPValidationError;

export interface UpdateTemplateParams {
  /** Template Id */
  templateId: number;
}

/** Response Update Template */
export type UpdateTemplateData = Record<string, any>;

export type UpdateTemplateError = HTTPValidationError;

export interface DeleteTemplateParams {
  /** Template Id */
  templateId: number;
}

/** Response Delete Template */
export type DeleteTemplateData = Record<string, any>;

export type DeleteTemplateError = HTTPValidationError;

/** Response Customize Template */
export type CustomizeTemplateData = Record<string, any>;

export type CustomizeTemplateError = HTTPValidationError;

/** Response List Company Forms */
export type ListCompanyFormsData = Record<string, any>;

export interface GetDocumentMetadataOptionsParams {
  /** Category */
  category: string;
}

export type GetDocumentMetadataOptionsData = MetadataOptionsResponse;

export type GetDocumentMetadataOptionsError = HTTPValidationError;

/** Response Get All Document Metadata Options */
export type GetAllDocumentMetadataOptionsData = Record<string, any>;

export type CreateDocumentMetadataOptionData = MetadataOption;

export type CreateDocumentMetadataOptionError = HTTPValidationError;

export interface UpdateDocumentMetadataOptionParams {
  /** Option Id */
  optionId: number;
}

export type UpdateDocumentMetadataOptionData = MetadataOption;

export type UpdateDocumentMetadataOptionError = HTTPValidationError;

export interface DeleteDocumentMetadataOptionParams {
  /** Option Id */
  optionId: number;
}

/** Response Delete Document Metadata Option */
export type DeleteDocumentMetadataOptionData = Record<string, any>;

export type DeleteDocumentMetadataOptionError = HTTPValidationError;

export interface ReorderDocumentMetadataOptionsParams {
  /** Category */
  category: string;
}

/** Response Reorder Document Metadata Options */
export type ReorderDocumentMetadataOptionsData = Record<string, any>;

export type ReorderDocumentMetadataOptionsError = HTTPValidationError;

export interface BulkImportMetadataOptionsParams {
  /** Category */
  category: string;
}

/** Response Bulk Import Metadata Options */
export type BulkImportMetadataOptionsData = Record<string, any>;

export type BulkImportMetadataOptionsError = HTTPValidationError;

export interface ExportMetadataOptionsParams {
  /** Category */
  category: string;
}

/** Response Export Metadata Options */
export type ExportMetadataOptionsData = Record<string, any>;

export type ExportMetadataOptionsError = HTTPValidationError;

export interface GetDocumentSectionsAdminParams {
  /** Document Id */
  documentId: number;
}

export type GetDocumentSectionsAdminData = AppApisDocumentSectionsDocumentSectionsResponse;

export type GetDocumentSectionsAdminError = HTTPValidationError;

export interface CreateDocumentSectionParams {
  /** Document Id */
  documentId: number;
}

export type CreateDocumentSectionData = AppApisDocumentSectionsDocumentSection;

export type CreateDocumentSectionError = HTTPValidationError;

export interface UpdateDocumentSectionParams {
  /** Section Id */
  sectionId: number;
}

export type UpdateDocumentSectionData = AppApisDocumentSectionsDocumentSection;

export type UpdateDocumentSectionError = HTTPValidationError;

export interface DeleteDocumentSectionParams {
  /** Section Id */
  sectionId: number;
}

/** Response Delete Document Section */
export type DeleteDocumentSectionData = Record<string, any>;

export type DeleteDocumentSectionError = HTTPValidationError;

export interface ReorderSectionsParams {
  /** Document Id */
  documentId: number;
}

/** Response Reorder Sections */
export type ReorderSectionsData = Record<string, any>;

export type ReorderSectionsError = HTTPValidationError;

export interface BulkImportSectionsParams {
  /** Document Id */
  documentId: number;
}

/** Response Bulk Import Sections */
export type BulkImportSectionsData = Record<string, any>;

export type BulkImportSectionsError = HTTPValidationError;

export interface ExportSectionsParams {
  /** Document Id */
  documentId: number;
}

/** Response Export Sections */
export type ExportSectionsData = Record<string, any>;

export type ExportSectionsError = HTTPValidationError;

export interface UpdateSectionsNotApplicableParams {
  /** Document Id */
  documentId: number;
}

export type UpdateSectionsNotApplicableData = SectionsNotApplicableResponse;

export type UpdateSectionsNotApplicableError = HTTPValidationError;

export interface GetSectionsNotApplicableParams {
  /** Document Id */
  documentId: number;
}

export type GetSectionsNotApplicableData = SectionsNotApplicableResponse;

export type GetSectionsNotApplicableError = HTTPValidationError;

export interface GetDocumentPricingParams {
  /**
   * Page
   * @default 1
   */
  page?: number;
  /**
   * Limit
   * @default 50
   */
  limit?: number;
}

/** Response Get Document Pricing */
export type GetDocumentPricingData = DocumentPricingResponse[];

export type GetDocumentPricingError = HTTPValidationError;

export interface UpdateDocumentPricingParams {
  /** Document Id */
  documentId: number;
}

/** Response Update Document Pricing */
export type UpdateDocumentPricingData = Record<string, any>;

export type UpdateDocumentPricingError = HTTPValidationError;

/** Response Update Bulk Pricing */
export type UpdateBulkPricingData = Record<string, any>;

export type UpdateBulkPricingError = HTTPValidationError;

/** Response Apply Default Pricing */
export type ApplyDefaultPricingData = Record<string, any>;

export type ApplyDefaultPricingError = HTTPValidationError;

/** Response Get Pricing Analytics */
export type GetPricingAnalyticsData = PricingAnalyticsResponse[];

export interface GetDocumentPricingDetailParams {
  /** Document Id */
  documentId: number;
}

export type GetDocumentPricingDetailData = DocumentPricingResponse;

export type GetDocumentPricingDetailError = HTTPValidationError;

/** Response List Sanctions Trees */
export type ListSanctionsTreesData = SanctionsTree[];

export type CreateSanctionsTreeData = SanctionsTree;

export type CreateSanctionsTreeError = HTTPValidationError;

export interface GetSanctionsTreeParams {
  /** Tree Id */
  treeId: string;
}

export type GetSanctionsTreeData = SanctionsTree;

export type GetSanctionsTreeError = HTTPValidationError;

export interface UpdateSanctionsTreeParams {
  /** Tree Id */
  treeId: string;
}

export type UpdateSanctionsTreeData = SanctionsTree;

export type UpdateSanctionsTreeError = HTTPValidationError;

export interface DeleteSanctionsTreeParams {
  /** Tree Id */
  treeId: string;
}

export type DeleteSanctionsTreeData = any;

export type DeleteSanctionsTreeError = HTTPValidationError;

export interface DuplicateSanctionsTreeParams {
  /** Tree Id */
  treeId: string;
}

export type DuplicateSanctionsTreeData = SanctionsTree;

export type DuplicateSanctionsTreeError = HTTPValidationError;

export interface ListSanctionsNodesParams {
  /** Tree Id */
  treeId: string;
}

/** Response List Sanctions Nodes */
export type ListSanctionsNodesData = SanctionsNode[];

export type ListSanctionsNodesError = HTTPValidationError;

export interface CreateSanctionsNodeParams {
  /** Tree Id */
  treeId: string;
}

export type CreateSanctionsNodeData = SanctionsNode;

export type CreateSanctionsNodeError = HTTPValidationError;

export interface GetSanctionsNodeParams {
  /** Tree Id */
  treeId: string;
  /** Node Id */
  nodeId: string;
}

export type GetSanctionsNodeData = SanctionsNode;

export type GetSanctionsNodeError = HTTPValidationError;

export interface UpdateSanctionsNodeParams {
  /** Tree Id */
  treeId: string;
  /** Node Id */
  nodeId: string;
}

export type UpdateSanctionsNodeData = SanctionsNode;

export type UpdateSanctionsNodeError = HTTPValidationError;

export interface DeleteSanctionsNodeParams {
  /** Tree Id */
  treeId: string;
  /** Node Id */
  nodeId: string;
}

export type DeleteSanctionsNodeData = any;

export type DeleteSanctionsNodeError = HTTPValidationError;

export interface DuplicateSanctionsNodeParams {
  /** Tree Id */
  treeId: string;
  /** Node Id */
  nodeId: string;
}

export type DuplicateSanctionsNodeData = SanctionsNode;

export type DuplicateSanctionsNodeError = HTTPValidationError;

export interface ListSanctionsNodeOptionsParams {
  /** Tree Id */
  treeId: string;
  /** Node Id */
  nodeId: string;
}

/** Response List Sanctions Node Options */
export type ListSanctionsNodeOptionsData = SanctionsNodeOption[];

export type ListSanctionsNodeOptionsError = HTTPValidationError;

export interface CreateSanctionsNodeOptionParams {
  /** Tree Id */
  treeId: string;
  /** Node Id */
  nodeId: string;
}

export type CreateSanctionsNodeOptionData = SanctionsNodeOption;

export type CreateSanctionsNodeOptionError = HTTPValidationError;

export interface GetSanctionsNodeOptionParams {
  /** Tree Id */
  treeId: string;
  /** Node Id */
  nodeId: string;
  /** Option Id */
  optionId: string;
}

export type GetSanctionsNodeOptionData = SanctionsNodeOption;

export type GetSanctionsNodeOptionError = HTTPValidationError;

export interface UpdateSanctionsNodeOptionParams {
  /** Tree Id */
  treeId: string;
  /** Node Id */
  nodeId: string;
  /** Option Id */
  optionId: string;
}

export type UpdateSanctionsNodeOptionData = SanctionsNodeOption;

export type UpdateSanctionsNodeOptionError = HTTPValidationError;

export interface DeleteSanctionsNodeOptionParams {
  /** Tree Id */
  treeId: string;
  /** Node Id */
  nodeId: string;
  /** Option Id */
  optionId: string;
}

export type DeleteSanctionsNodeOptionData = any;

export type DeleteSanctionsNodeOptionError = HTTPValidationError;

/** Response List Published Sanctions Trees */
export type ListPublishedSanctionsTreesData = SanctionsTree[];

export interface GetPublishedSanctionsTreeParams {
  /** Tree Id */
  treeId: string;
}

export type GetPublishedSanctionsTreeData = SanctionsTree;

export type GetPublishedSanctionsTreeError = HTTPValidationError;

export interface GetPublishedSanctionsTreeNodesParams {
  /** Tree Id */
  treeId: string;
}

/** Response Get Published Sanctions Tree Nodes */
export type GetPublishedSanctionsTreeNodesData = SanctionsNode[];

export type GetPublishedSanctionsTreeNodesError = HTTPValidationError;

export interface GetPublishedSanctionsNodeOptionsParams {
  /** Tree Id */
  treeId: string;
  /** Node Id */
  nodeId: string;
}

/** Response Get Published Sanctions Node Options */
export type GetPublishedSanctionsNodeOptionsData = SanctionsNodeOption[];

export type GetPublishedSanctionsNodeOptionsError = HTTPValidationError;

export type AssessSanctionsApplicabilityData = SanctionsAssessmentResult;

export type AssessSanctionsApplicabilityError = HTTPValidationError;

export type SaveClassificationData = SavedClassificationResponse;

export type SaveClassificationError = HTTPValidationError;

export interface ListSavedClassificationsParams {
  /**
   * Include Archived
   * @default false
   */
  include_archived?: boolean;
}

/** Response List Saved Classifications */
export type ListSavedClassificationsData = SavedClassificationResponse[];

export type ListSavedClassificationsError = HTTPValidationError;

export interface LoadClassificationParams {
  /** Classification Id */
  classificationId: string;
}

export type LoadClassificationData = any;

export type LoadClassificationError = HTTPValidationError;

export interface DeleteClassificationParams {
  /** Classification Id */
  classificationId: string;
}

export type DeleteClassificationData = any;

export type DeleteClassificationError = HTTPValidationError;

export interface RestoreClassificationParams {
  /** Classification Id */
  classificationId: string;
}

export type RestoreClassificationData = any;

export type RestoreClassificationError = HTTPValidationError;

/** Response Get Classification Notifications */
export type GetClassificationNotificationsData = ClassificationNotification[];

export type CleanupExpiredClassificationsData = any;

export type ListBadgesData = BadgeListResponse;

export type CreateBadgeData = BadgeResponse;

export type CreateBadgeError = HTTPValidationError;

export interface GetBadgeParams {
  /** Badge Id */
  badgeId: number;
}

export type GetBadgeData = BadgeResponse;

export type GetBadgeError = HTTPValidationError;

export interface UpdateBadgeParams {
  /** Badge Id */
  badgeId: number;
}

export type UpdateBadgeData = BadgeResponse;

export type UpdateBadgeError = HTTPValidationError;

export interface DeleteBadgeParams {
  /** Badge Id */
  badgeId: number;
}

export type DeleteBadgeData = any;

export type DeleteBadgeError = HTTPValidationError;

/** Response List Badge Categories */
export type ListBadgeCategoriesData = string[];

export type CreateDocumentAlertData = DocumentAlertResponse;

export type CreateDocumentAlertError = HTTPValidationError;

export interface ListDocumentAlertsParams {
  /**
   * Alert Type
   * Filter by alert type
   */
  alert_type?: string | null;
  /**
   * Status
   * Filter by status
   */
  status?: string | null;
  /**
   * Severity
   * Filter by severity
   */
  severity?: string | null;
  /**
   * Include Expired
   * Include expired alerts
   * @default false
   */
  include_expired?: boolean;
  /**
   * Limit
   * Maximum number of alerts to return
   * @default 50
   */
  limit?: number;
  /**
   * Offset
   * Offset for pagination
   * @default 0
   */
  offset?: number;
}

/** Response List Document Alerts */
export type ListDocumentAlertsData = DocumentAlertResponse[];

export type ListDocumentAlertsError = HTTPValidationError;

export interface GetDocumentAlertParams {
  /** Alert Id */
  alertId: number;
}

export type GetDocumentAlertData = DocumentAlertResponse;

export type GetDocumentAlertError = HTTPValidationError;

export interface UpdateAlertStatusParams {
  /** Alert Id */
  alertId: number;
}

export type UpdateAlertStatusData = DocumentAlertResponse;

export type UpdateAlertStatusError = HTTPValidationError;

export interface UpdateDocumentAlertParams {
  /** Alert Id */
  alertId: number;
}

export type UpdateDocumentAlertData = DocumentAlertResponse;

export type UpdateDocumentAlertError = HTTPValidationError;

export interface DeleteDocumentAlertParams {
  /** Alert Id */
  alertId: number;
}

/** Response Delete Document Alert */
export type DeleteDocumentAlertData = Record<string, string>;

export type DeleteDocumentAlertError = HTTPValidationError;

/** Response Get Alerts Summary */
export type GetAlertsSummaryData = Record<string, any>;

export type CompareDocumentsData = ComparisonResult;

export type CompareDocumentsError = HTTPValidationError;

export interface GetComparisonSuggestionsParams {
  /**
   * Document Id
   * Base document ID for suggestions
   */
  document_id: number;
  /**
   * Limit
   * Maximum number of suggestions
   * @default 5
   */
  limit?: number;
}

/** Response Get Comparison Suggestions */
export type GetComparisonSuggestionsData = Record<string, any>[];

export type GetComparisonSuggestionsError = HTTPValidationError;

export type DownloadCriticalProductsTemplateData = any;

export type DownloadCriticalProductsExcelTemplateData = any;

/** Response Search Critical Products */
export type SearchCriticalProductsData = CriticalProductSearchResult[];

export type SearchCriticalProductsError = HTTPValidationError;

export interface ListTradeCodesParams {
  /** Category */
  category?: string | null;
  /**
   * Limit
   * @max 500
   * @default 100
   */
  limit?: number;
}

/** Response List Trade Codes */
export type ListTradeCodesData = TradeCode[];

export type ListTradeCodesError = HTTPValidationError;

export type CreateTradeCodeData = TradeCode;

export type CreateTradeCodeError = HTTPValidationError;

export interface ListRestrictiveMeasuresParams {
  /** Jurisdiction */
  jurisdiction?: string | null;
  /** Measure Type */
  measure_type?: string | null;
  /**
   * Limit
   * @max 500
   * @default 100
   */
  limit?: number;
}

/** Response List Restrictive Measures */
export type ListRestrictiveMeasuresData = RestrictiveMeasure[];

export type ListRestrictiveMeasuresError = HTTPValidationError;

export type CreateRestrictiveMeasureData = RestrictiveMeasure;

export type CreateRestrictiveMeasureError = HTTPValidationError;

/** Response Get Categories */
export type GetCategoriesData = string[];

/** Response Get Jurisdictions */
export type GetJurisdictionsData = string[];

/** Response Get Measure Types */
export type GetMeasureTypesData = string[];

/** Response Get Critical Products Stats */
export type GetCriticalProductsStatsData = Record<string, any>;

export interface GetCriticalProductsSectionContentParams {
  /** Section Type */
  sectionType: string;
}

/** Response Get Critical Products Section Content */
export type GetCriticalProductsSectionContentData = Record<string, any>;

export type GetCriticalProductsSectionContentError = HTTPValidationError;

export interface ExportCriticalProductsParams {
  /**
   * Format
   * @default "xlsx"
   */
  format?: string;
}

export type ExportCriticalProductsData = any;

export type ExportCriticalProductsError = HTTPValidationError;

/** Response Create Critical Product */
export type CreateCriticalProductData = Record<string, any>;

export type CreateCriticalProductError = HTTPValidationError;

export interface DeleteCriticalProductParams {
  /** Product Id */
  productId: string;
}

/** Response Delete Critical Product */
export type DeleteCriticalProductData = Record<string, string>;

export type DeleteCriticalProductError = HTTPValidationError;

/** Response Import Critical Products */
export type ImportCriticalProductsData = Record<string, any>;

export type ImportCriticalProductsError = HTTPValidationError;

/** Response Clear Critical Products Database */
export type ClearCriticalProductsDatabaseData = Record<string, any>;

export type CreateAdminNotificationData = AdminNotificationResponse;

export type CreateAdminNotificationError = HTTPValidationError;

export interface GetAdminNotificationsParams {
  /**
   * Active Only
   * @default true
   */
  active_only?: boolean;
  /** Notification Type */
  notification_type?: string | null;
  /**
   * Limit
   * @min 1
   * @max 100
   * @default 50
   */
  limit?: number;
}

/** Response Get Admin Notifications */
export type GetAdminNotificationsData = AdminNotification[];

export type GetAdminNotificationsError = HTTPValidationError;

export interface UpdateAdminNotificationParams {
  /** Notification Id */
  notificationId: string;
}

export type UpdateAdminNotificationData = AdminNotificationResponse;

export type UpdateAdminNotificationError = HTTPValidationError;

export interface DeleteAdminNotificationParams {
  /** Notification Id */
  notificationId: string;
}

export type DeleteAdminNotificationData = any;

export type DeleteAdminNotificationError = HTTPValidationError;

export interface GetUserNotificationsParams {
  /** Status */
  status?: string | null;
  /**
   * Limit
   * @min 1
   * @max 50
   * @default 20
   */
  limit?: number;
  /**
   * Offset
   * @min 0
   * @default 0
   */
  offset?: number;
}

export type GetUserNotificationsData = UserNotificationsResponse;

export type GetUserNotificationsError = HTTPValidationError;

export interface UpdateNotificationStatusParams {
  /** Notification Id */
  notificationId: string;
}

export type UpdateNotificationStatusData = any;

export type UpdateNotificationStatusError = HTTPValidationError;

export type GetUnreadNotificationCountData = any;

export type MarkAllNotificationsReadData = any;

export interface GetDocumentAnnotationsCollabParams {
  /**
   * Include Private
   * @default false
   */
  include_private?: boolean;
  /** Document Id */
  documentId: number;
}

/** Response Get Document Annotations Collab */
export type GetDocumentAnnotationsCollabData = AnnotationResponse[];

export type GetDocumentAnnotationsCollabError = HTTPValidationError;

export type CreateAnnotationCollabData = AnnotationResponse;

export type CreateAnnotationCollabError = HTTPValidationError;

export interface UpdateAnnotationCollabParams {
  /** Annotation Id */
  annotationId: number;
}

export type UpdateAnnotationCollabData = AnnotationResponse;

export type UpdateAnnotationCollabError = HTTPValidationError;

export interface DeleteAnnotationCollabParams {
  /** Annotation Id */
  annotationId: number;
}

export type DeleteAnnotationCollabData = any;

export type DeleteAnnotationCollabError = HTTPValidationError;

export interface ResolveAnnotationCollabParams {
  /** Annotation Id */
  annotationId: number;
}

export type ResolveAnnotationCollabData = any;

export type ResolveAnnotationCollabError = HTTPValidationError;

export interface GetUserBookmarksCollabParams {
  /** Document Id */
  document_id?: number | null;
}

/** Response Get User Bookmarks Collab */
export type GetUserBookmarksCollabData = BookmarkResponse[];

export type GetUserBookmarksCollabError = HTTPValidationError;

export type CreateBookmarkCollabData = BookmarkResponse;

export type CreateBookmarkCollabError = HTTPValidationError;

export interface DeleteBookmarkCollabParams {
  /** Bookmark Id */
  bookmarkId: number;
}

export type DeleteBookmarkCollabData = any;

export type DeleteBookmarkCollabError = HTTPValidationError;

export interface GetDocumentActivityCollabParams {
  /** Document Id */
  documentId: number;
}

/** Response Get Document Activity Collab */
export type GetDocumentActivityCollabData = ActivityResponse[];

export type GetDocumentActivityCollabError = HTTPValidationError;

export interface TrackDocumentActivityCollabParams {
  /** Document Id */
  documentId: number;
}

export type TrackDocumentActivityCollabData = any;

export type TrackDocumentActivityCollabError = HTTPValidationError;

export interface GetCollaborationStatsCollabParams {
  /** Document Id */
  document_id?: number | null;
}

export type GetCollaborationStatsCollabData = CollaborationStatsResponse;

export type GetCollaborationStatsCollabError = HTTPValidationError;

export interface GetUserCollaborationSummaryCollabParams {
  /** User Id */
  userId: string;
}

export type GetUserCollaborationSummaryCollabData = UserCollaborationSummary;

export type GetUserCollaborationSummaryCollabError = HTTPValidationError;

export interface ListSanctionEntitiesParams {
  /**
   * Page
   * @min 1
   * @default 1
   */
  page?: number;
  /**
   * Page Size
   * @min 1
   * @max 100
   * @default 20
   */
  page_size?: number;
  /** Search */
  search?: string | null;
  /** Entity Type */
  entity_type?: string | null;
  /** Jurisdiction */
  jurisdiction?: string | null;
  /** Risk Level */
  risk_level?: string | null;
  /**
   * Status
   * @default "active"
   */
  status?: string | null;
}

export type ListSanctionEntitiesData = SanctionEntitiesResponse;

export type ListSanctionEntitiesError = HTTPValidationError;

export type CreateSanctionEntityData = SanctionEntityResponse;

export type CreateSanctionEntityError = HTTPValidationError;

export interface GetAdminSanctionEntityParams {
  /** Entity Id */
  entityId: string;
}

export type GetAdminSanctionEntityData = SanctionEntityResponse;

export type GetAdminSanctionEntityError = HTTPValidationError;

export interface UpdateSanctionEntityParams {
  /** Entity Id */
  entityId: string;
}

export type UpdateSanctionEntityData = SanctionEntityResponse;

export type UpdateSanctionEntityError = HTTPValidationError;

export interface DeleteSanctionEntityParams {
  /**
   * Hard Delete
   * Permanently delete instead of marking inactive
   * @default false
   */
  hard_delete?: boolean;
  /** Entity Id */
  entityId: string;
}

export type DeleteSanctionEntityData = any;

export type DeleteSanctionEntityError = HTTPValidationError;

export type BulkImportSanctionsData = AppApisAdminSanctionsBulkImportResponse;

export type BulkImportSanctionsError = HTTPValidationError;

export interface ExportSanctionsParams {
  /**
   * Format
   * Export format: csv or json
   * @default "csv"
   */
  format?: string;
  /** Jurisdiction */
  jurisdiction?: string | null;
  /**
   * Status
   * @default "active"
   */
  status?: string | null;
}

export type ExportSanctionsData = any;

export type ExportSanctionsError = HTTPValidationError;

/** Response Get Sanction Sources */
export type GetSanctionSourcesData = SanctionSourceResponse[];

export interface GetSanctionsAuditLogParams {
  /** Entity Id */
  entity_id?: string | null;
  /** Action */
  action?: string | null;
  /**
   * Limit
   * @max 200
   * @default 50
   */
  limit?: number;
}

/** Response Get Sanctions Audit Log */
export type GetSanctionsAuditLogData = SanctionAuditLogResponse[];

export type GetSanctionsAuditLogError = HTTPValidationError;

/** Response Setup Auto Recharge */
export type SetupAutoRechargeData = Record<string, any>;

export type SetupAutoRechargeError = HTTPValidationError;

/** Response Get Auto Recharge Config */
export type GetAutoRechargeConfigData = AutoRechargeConfigResponse | null;

export interface ToggleAutoRechargeParams {
  /**
   * Enabled
   * @default true
   */
  enabled?: boolean;
}

/** Response Toggle Auto Recharge */
export type ToggleAutoRechargeData = Record<string, any>;

export type ToggleAutoRechargeError = HTTPValidationError;

/** Response Manual Trigger Recharge */
export type ManualTriggerRechargeData = Record<string, any>;

export interface GetAutoRechargeHistoryParams {
  /**
   * Limit
   * @default 50
   */
  limit?: number;
}

/** Response Get Auto Recharge History */
export type GetAutoRechargeHistoryData = AutoRechargeTransactionResponse[];

export type GetAutoRechargeHistoryError = HTTPValidationError;

/** Response Add Payment Method */
export type AddPaymentMethodData = Record<string, any>;

export type AddPaymentMethodError = HTTPValidationError;

/** Response Get Payment Methods */
export type GetPaymentMethodsData = Record<string, any>;

export type GenerateEnterpriseInvoiceData = EnterpriseInvoiceResponse;

export type GenerateEnterpriseInvoiceError = HTTPValidationError;

export interface GetEnterpriseInvoicesParams {
  /** Status */
  status?: string | null;
}

/** Response Get Enterprise Invoices */
export type GetEnterpriseInvoicesData = EnterpriseInvoiceResponse[];

export type GetEnterpriseInvoicesError = HTTPValidationError;

/** Response Get Payment Failures */
export type GetPaymentFailuresData = Record<string, any>[];

export interface RetryFailedPaymentParams {
  /** Failure Id */
  failureId: number;
}

/** Response Retry Failed Payment */
export type RetryFailedPaymentData = Record<string, any>;

export type RetryFailedPaymentError = HTTPValidationError;

/** Response List Feed Sources */
export type ListFeedSourcesData = FeedSourceResponse[];

export type CreateFeedSourceData = FeedSourceResponse;

export type CreateFeedSourceError = HTTPValidationError;

export interface TriggerFeedUpdateParams {
  /** Feed Id */
  feedId: number;
}

export type TriggerFeedUpdateData = FeedUpdateResult;

export type TriggerFeedUpdateError = HTTPValidationError;

/** Response List Webhooks */
export type ListWebhooksData = WebhookResponse[];

export type CreateWebhookData = WebhookResponse;

export type CreateWebhookError = HTTPValidationError;

export type GetAutomationAnalyticsData = AutomationAnalytics;

export interface SearchDocumentsForReferenceParams {
  /**
   * Q
   * Search term
   */
  q: string;
  /**
   * Limit
   * Maximum number of results
   * @default 10
   */
  limit?: number;
}

export type SearchDocumentsForReferenceData = ReferenceSearchResponse;

export type SearchDocumentsForReferenceError = HTTPValidationError;

/** Reference Ids */
export type ResolveDocumentReferencesPayload = string[];

export type ResolveDocumentReferencesData = ResolveReferencesResponse;

export type ResolveDocumentReferencesError = HTTPValidationError;

export interface ExtractReferencesFromTextEndpointParams {
  /**
   * Text
   * Text content to extract references from
   */
  text: string;
}

/** Response Extract References From Text Endpoint */
export type ExtractReferencesFromTextEndpointData = Record<string, string[]>;

export type ExtractReferencesFromTextEndpointError = HTTPValidationError;

export interface GetDocumentReferenceIdParams {
  /** Document Id */
  documentId: number;
}

/** Response Get Document Reference Id */
export type GetDocumentReferenceIdData = Record<string, string>;

export type GetDocumentReferenceIdError = HTTPValidationError;

export type SearchCountriesData = CountrySearchResponse;

export type SearchCountriesError = HTTPValidationError;

export interface GetCountryRestrictionParams {
  /** Country Id */
  countryId: string;
}

export type GetCountryRestrictionData = CountryRestriction;

export type GetCountryRestrictionError = HTTPValidationError;

/** Response Get Restriction Types */
export type GetRestrictionTypesData = string[];

/** Response Get Issuing Authorities */
export type GetIssuingAuthoritiesData = string[];

/** Response Get Geographic Regions */
export type GetGeographicRegionsData = string[];

/** Response Get Country Risk Levels */
export type GetCountryRiskLevelsData = string[];

export type ProcessDocumentData = ProcessDocumentResponse;

export type ProcessDocumentError = HTTPValidationError;

export interface GetProcessingStatusParams {
  /** Processing Id */
  processingId: string;
}

export type GetProcessingStatusData = ProcessingStatusResponse;

export type GetProcessingStatusError = HTTPValidationError;

export interface GetProcessedDocumentSectionsParams {
  /** Document Id */
  documentId: string;
}

export type GetProcessedDocumentSectionsData = AppApisDocumentProcessingDocumentSectionsResponse;

export type GetProcessedDocumentSectionsError = HTTPValidationError;

export interface GetDocumentCrossReferencesProcessingParams {
  /** Document Id */
  documentId: string;
}

export type GetDocumentCrossReferencesProcessingData = CrossReferencesResponse;

export type GetDocumentCrossReferencesProcessingError = HTTPValidationError;

export type BatchProcessDocumentsData = BatchProcessResponse;

export type BatchProcessDocumentsError = HTTPValidationError;

export type GetSupportedFormatsData = SupportedFormatsResponse;

export interface CleanupProcessingHistoryParams {
  /**
   * Hours Old
   * @default 24
   */
  hours_old?: number;
}

/** Response Cleanup Processing History */
export type CleanupProcessingHistoryData = Record<string, any>;

export type CleanupProcessingHistoryError = HTTPValidationError;

export type InitializeDefaultContentData = any;

export interface GetContentByModuleParams {
  /** Module Name */
  moduleName: string;
}

export type GetContentByModuleData = ContentListResponse;

export type GetContentByModuleError = HTTPValidationError;

export type CreateContentItemData = any;

export type CreateContentItemError = HTTPValidationError;

export interface UpdateContentItemParams {
  /** Content Id */
  contentId: number;
}

export type UpdateContentItemData = any;

export type UpdateContentItemError = HTTPValidationError;

export interface DeleteContentItemParams {
  /** Content Id */
  contentId: number;
}

export type DeleteContentItemData = any;

export type DeleteContentItemError = HTTPValidationError;

export interface GetContentItemParams {
  /** Content Id */
  contentId: number;
}

export type GetContentItemData = any;

export type GetContentItemError = HTTPValidationError;

export type ActivateFreeTierData = AppApisCreditManagementFreeTierActivationResponse;

/** Response Get Free Tier Status */
export type GetFreeTierStatusData = Record<string, any>;

export type GetCreditBalanceData = CreditBalance;

export interface GetCreditTransactionsParams {
  /**
   * Limit
   * @default 50
   */
  limit?: number;
  /**
   * Offset
   * @default 0
   */
  offset?: number;
}

/** Response Get Credit Transactions */
export type GetCreditTransactionsData = CreditTransaction[];

export type GetCreditTransactionsError = HTTPValidationError;

/** Response Get Credit Packages */
export type GetCreditPackagesData = CreditPackage[];

/** Response Reserve Credits */
export type ReserveCreditsData = Record<string, any>;

export type ReserveCreditsError = HTTPValidationError;

/** Response Consume Credits */
export type ConsumeCreditsData = Record<string, any>;

export type ConsumeCreditsError = HTTPValidationError;

/** Response Admin Adjust Credits */
export type AdminAdjustCreditsData = Record<string, any>;

export type AdminAdjustCreditsError = HTTPValidationError;

/** Response Get All Credit Packages */
export type GetAllCreditPackagesData = CreditPackage[];

export type CreateCreditPackageData = CreditPackage;

export type CreateCreditPackageError = HTTPValidationError;

export interface UpdateCreditPackageParams {
  /** Package Id */
  packageId: number;
}

export type UpdateCreditPackageData = CreditPackage;

export type UpdateCreditPackageError = HTTPValidationError;

export interface DeleteCreditPackageParams {
  /** Package Id */
  packageId: number;
}

/** Response Delete Credit Package */
export type DeleteCreditPackageData = Record<string, string>;

export type DeleteCreditPackageError = HTTPValidationError;

/** Response Get Base Credit Price */
export type GetBaseCreditPriceData = Record<string, number>;

/** Response Update Base Credit Price */
export type UpdateBaseCreditPriceData = Record<string, number>;

export type UpdateBaseCreditPriceError = HTTPValidationError;

export interface ExportNotesToExcelParams {
  /**
   * Module Type
   * @default "product_classification"
   */
  module_type?: string;
  /** Tree Id */
  treeId: string;
}

export type ExportNotesToExcelData = any;

export type ExportNotesToExcelError = HTTPValidationError;

export interface ImportNotesFromExcelParams {
  /**
   * Module Type
   * @default "product_classification"
   */
  module_type?: string;
  /** Tree Id */
  treeId: string;
}

export type ImportNotesFromExcelData = ExcelImportResponse;

export type ImportNotesFromExcelError = HTTPValidationError;

export type GetUserAccessStatusData = any;

export type GetVatPreviewData = VATPreviewResponse;

export type GetVatPreviewError = HTTPValidationError;

export type CreatePaymentIntentData = PaymentIntentResponse;

export type CreatePaymentIntentError = HTTPValidationError;

export type RequestInvoiceData = AppApisPaymentSystemInvoiceResponse;

export type RequestInvoiceError = HTTPValidationError;

export type SelectTemplateData = TemplateSelectionResponse;

export type SelectTemplateError = HTTPValidationError;

export type CompleteTemplateSelectionData = any;

export type CompleteTemplateSelectionError = HTTPValidationError;

export type StripeWebhookData = any;

export type GetAdminCustomersData = any;

export type GetAllAdminUsersData = any;

export interface GetChatMessagesParams {
  /** Thread Id */
  thread_id?: string;
}

export type GetChatMessagesData = any;

export type GetChatMessagesError = HTTPValidationError;

export type SendMessageData = ChatMessage;

export type SendMessageError = HTTPValidationError;

export type GetChatThreadsData = any;

export type CreateChatThreadData = any;

export type CreateChatThreadError = HTTPValidationError;

export interface ReactToMessageParams {
  /** Message Id */
  messageId: string;
}

export type ReactToMessageData = any;

export type ReactToMessageError = HTTPValidationError;

export interface DeleteMessageParams {
  /** Message Id */
  messageId: string;
}

export type DeleteMessageData = any;

export type DeleteMessageError = HTTPValidationError;

export type BlockUserData = any;

export type BlockUserError = HTTPValidationError;

export type DeleteChatData = any;

export type DeleteChatError = HTTPValidationError;

export type GetChatPolicyData = any;

export interface CheckUserBlockedParams {
  /** User Id */
  user_id: string;
}

export type CheckUserBlockedData = any;

export type CheckUserBlockedError = HTTPValidationError;

export type UploadDocumentAttachmentData = AppApisDocumentUploadDocumentUploadResponse;

export type UploadDocumentAttachmentError = HTTPValidationError;

export interface ServeDocumentParams {
  /** Document Filename */
  documentFilename: string;
}

export type ServeDocumentData = any;

export type ServeDocumentError = HTTPValidationError;

export interface DeleteAttachmentDocumentParams {
  /** Document Filename */
  documentFilename: string;
}

export type DeleteAttachmentDocumentData = any;

export type DeleteAttachmentDocumentError = HTTPValidationError;

export type ListAttachmentDocumentsData = AppApisDocumentUploadDocumentListResponse;

export type ListCountriesData = CountriesResponse;

export type ListSanctionsData = SanctionsResponse;

export interface GetDocumentSectionsParams {
  /** Document Id */
  documentId: number;
}

export type GetDocumentSectionsData = AppApisKbDataDocumentSectionsResponse;

export type GetDocumentSectionsError = HTTPValidationError;

export interface ServePublicImageParams {
  /** Image Filename */
  imageFilename: string;
}

export type ServePublicImageData = any;

export type ServePublicImageError = HTTPValidationError;

export interface ServeStaticImageParams {
  /** Image Filename */
  imageFilename: string;
}

export type ServeStaticImageData = any;

export type ServeStaticImageError = HTTPValidationError;

export type UploadImageData = ImageUploadResponse;

export type UploadImageError = HTTPValidationError;

export interface ServeImageParams {
  /** Image Filename */
  imageFilename: string;
}

export type ServeImageData = any;

export type ServeImageError = HTTPValidationError;

export interface DeleteImageParams {
  /** Image Filename */
  imageFilename: string;
}

export type DeleteImageData = any;

export type DeleteImageError = HTTPValidationError;

export interface ServePublicImageAltParams {
  /** Image Filename */
  imageFilename: string;
}

export type ServePublicImageAltData = any;

export type ServePublicImageAltError = HTTPValidationError;

export type ListImagesData = ImageListResponse;

export type KnowledgeBaseHealthData = any;

export type UploadDocumentData = DocumentResponse;

export type UploadDocumentError = HTTPValidationError;

export interface ListDocumentsParams {
  /**
   * Page
   * @min 1
   * @default 1
   */
  page?: number;
  /**
   * Per Page
   * @min 1
   * @max 100
   * @default 20
   */
  per_page?: number;
  /** Search */
  search?: string | null;
  /**
   * Sort By
   * @default "created_at_desc"
   */
  sort_by?: string;
  /** Document Type */
  document_type?: string | null;
  /** Jurisdiction */
  jurisdiction?: string | null;
}

export type ListDocumentsData = AppApisKnowledgeBaseDocumentListResponse;

export type ListDocumentsError = HTTPValidationError;

export interface UpdateDocumentParams {
  /** Document Id */
  documentId: number;
}

export type UpdateDocumentData = any;

export type UpdateDocumentError = HTTPValidationError;

export interface GetDocumentParams {
  /** Document Id */
  documentId: number;
}

export type GetDocumentData = DocumentResponse;

export type GetDocumentError = HTTPValidationError;

export interface DeleteDocumentParams {
  /** Document Id */
  documentId: number;
}

export type DeleteDocumentData = DeleteDocumentResponse;

export type DeleteDocumentError = HTTPValidationError;

export type GetKnowledgeBaseMetadataOptionsData = any;

export type SearchDocumentsData = DocumentSearchResponse;

export type SearchDocumentsError = HTTPValidationError;

export type AdvancedSearchDocumentsData = AdvancedSearchResponse;

export type AdvancedSearchDocumentsError = HTTPValidationError;

export interface GetSearchSuggestionsParams {
  /**
   * Query
   * Partial search query
   */
  query: string;
}

/** Response Get Search Suggestions */
export type GetSearchSuggestionsData = Record<string, string[]>;

export type GetSearchSuggestionsError = HTTPValidationError;

export interface DownloadDocumentFileParams {
  /**
   * Token
   * Authentication token as query parameter
   */
  token?: string | null;
  /** Document Id */
  documentId: number;
}

export type DownloadDocumentFileData = any;

export type DownloadDocumentFileError = HTTPValidationError;

export interface GetBlogDocumentParams {
  /** Document Id */
  documentId: number;
}

export type GetBlogDocumentData = DocumentResponse;

export type GetBlogDocumentError = HTTPValidationError;

export type SearchBlogDocumentsData = DocumentSearchResponse;

export type SearchBlogDocumentsError = HTTPValidationError;

export interface ListBlogDocumentsParams {
  /**
   * Page
   * @min 1
   * @default 1
   */
  page?: number;
  /**
   * Per Page
   * @min 1
   * @max 100
   * @default 20
   */
  per_page?: number;
  /** Search */
  search?: string | null;
  /**
   * Sort By
   * @default "created_at_desc"
   */
  sort_by?: string;
  /** Document Type */
  document_type?: string | null;
  /** Jurisdiction */
  jurisdiction?: string | null;
}

export type ListBlogDocumentsData = AppApisKnowledgeBaseDocumentListResponse;

export type ListBlogDocumentsError = HTTPValidationError;

export type AdvancedSearchBlogDocumentsData = AdvancedSearchResponse;

export type AdvancedSearchBlogDocumentsError = HTTPValidationError;

export interface GetBlogSearchSuggestionsParams {
  /**
   * Query
   * Partial search query
   */
  query: string;
}

/** Response Get Blog Search Suggestions */
export type GetBlogSearchSuggestionsData = Record<string, string[]>;

export type GetBlogSearchSuggestionsError = HTTPValidationError;

export type GetAdminStatsData = AdminStatsResponse;

export interface ListAdminDocumentsParams {
  /**
   * Status
   * Filter by publishing status
   */
  status?: string | null;
  /**
   * Category Id
   * Filter by category
   */
  category_id?: number | null;
  /**
   * Limit
   * Number of documents to return
   * @default 50
   */
  limit?: number;
  /**
   * Offset
   * Offset for pagination
   * @default 0
   */
  offset?: number;
}

/** Response List Admin Documents */
export type ListAdminDocumentsData = AdminDocumentResponse[];

export type ListAdminDocumentsError = HTTPValidationError;

export interface UpdateDocumentStatusParams {
  /** Document Id */
  documentId: number;
}

/** Response Update Document Status */
export type UpdateDocumentStatusData = Record<string, any>;

export type UpdateDocumentStatusError = HTTPValidationError;

/** Response Publish Document */
export type PublishDocumentData = Record<string, any>;

export type PublishDocumentError = HTTPValidationError;

/** Document Ids */
export type BulkUpdateStatusPayload = number[];

export interface BulkUpdateStatusParams {
  /** Status */
  status: string;
}

/** Response Bulk Update Status */
export type BulkUpdateStatusData = Record<string, any>;

export type BulkUpdateStatusError = HTTPValidationError;

export type CreateCategoryData = AppApisAdminDashboardCategoryResponse;

export type CreateCategoryError = HTTPValidationError;

export interface UpdateCategoryParams {
  /** Category Id */
  categoryId: number;
}

export type UpdateCategoryData = AppApisAdminDashboardCategoryResponse;

export type UpdateCategoryError = HTTPValidationError;

export interface DeleteCategoryParams {
  /** Category Id */
  categoryId: number;
}

/** Response Delete Category */
export type DeleteCategoryData = Record<string, any>;

export type DeleteCategoryError = HTTPValidationError;

export interface GetMetadataOptionsParams {
  /**
   * Active Only
   * Only return active options
   * @default true
   */
  active_only?: boolean;
  /** Category */
  category: string;
}

/** Response Get Metadata Options */
export type GetMetadataOptionsData = MetadataOptionResponse[];

export type GetMetadataOptionsError = HTTPValidationError;

export type CreateMetadataOptionData = MetadataOptionResponse;

export type CreateMetadataOptionError = HTTPValidationError;

export interface UpdateMetadataOptionParams {
  /** Option Id */
  optionId: number;
}

export type UpdateMetadataOptionData = MetadataOptionResponse;

export type UpdateMetadataOptionError = HTTPValidationError;

export interface DeleteMetadataOptionParams {
  /** Option Id */
  optionId: number;
}

/** Response Delete Metadata Option */
export type DeleteMetadataOptionData = Record<string, any>;

export type DeleteMetadataOptionError = HTTPValidationError;

/** Response Reorder Metadata Options */
export type ReorderMetadataOptionsData = Record<string, any>;

export type ReorderMetadataOptionsError = HTTPValidationError;

export type CreateWorkflowData = ClassificationWorkflow;

export type CreateWorkflowError = HTTPValidationError;

export interface ListAdminWorkflowsParams {
  /** Workflow Type */
  workflow_type?: string | null;
}

/** Response List Admin Workflows */
export type ListAdminWorkflowsData = ClassificationWorkflow[];

export type ListAdminWorkflowsError = HTTPValidationError;

export interface GetWorkflowByIdParams {
  /** Workflow Id */
  workflowId: string;
}

export type GetWorkflowByIdData = ClassificationWorkflow;

export type GetWorkflowByIdError = HTTPValidationError;

export interface UpdateWorkflowParams {
  /** Workflow Id */
  workflowId: string;
}

/** Response Update Workflow */
export type UpdateWorkflowData = Record<string, any>;

export type UpdateWorkflowError = HTTPValidationError;

export interface DeleteWorkflowParams {
  /** Workflow Id */
  workflowId: string;
}

/** Response Delete Workflow */
export type DeleteWorkflowData = Record<string, any>;

export type DeleteWorkflowError = HTTPValidationError;

export type ListWorkflowsData = ClassificationWorkflowList;

export interface GetPublishedWorkflowParams {
  /** Workflow Id */
  workflowId: string;
}

export type GetPublishedWorkflowData = ClassificationWorkflow;

export type GetPublishedWorkflowError = HTTPValidationError;
