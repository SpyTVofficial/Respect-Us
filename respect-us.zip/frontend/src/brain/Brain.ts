import {
  AcceptInvitationData,
  AcceptInvitationError,
  AcceptInvitationRequest,
  ActivateFreeTierCreditsData,
  ActivateFreeTierData,
  AddPaymentMethodData,
  AddPaymentMethodError,
  AdminAdjustCreditsData,
  AdminAdjustCreditsError,
  AdminCreditAdjustment,
  AdminNotificationCreate,
  AdminNotificationUpdate,
  AdminRespondToTicketData,
  AdminRespondToTicketError,
  AdminRespondToTicketParams,
  AdminSupportResponse,
  AdminValidationRequest,
  AdvancedSearchBlogDocumentsData,
  AdvancedSearchBlogDocumentsError,
  AdvancedSearchDocumentsData,
  AdvancedSearchDocumentsError,
  AdvancedSearchRequest,
  AnalyzeDocumentReferencesData,
  AnalyzeDocumentReferencesError,
  AnalyzeDocumentReferencesParams,
  AnalyzeRiskTrendsData,
  AnalyzeRiskTrendsError,
  AnalyzeUploadedFormData,
  AnalyzeUploadedFormError,
  AnalyzeUploadedFormParams,
  AnnotationUpdate,
  AppApisAdminDashboardCategoryRequest,
  AppApisDocumentMetadataBulkImportRequest,
  AppApisDocumentSectionsBulkImportRequest,
  AppApisSanctionsListManagementBulkImportRequest,
  AppApisSavedArticlesCategoryRequest,
  ApplyDefaultPricingData,
  ApplyDefaultPricingError,
  ApprovalRequest,
  ApproveDocumentData,
  ApproveDocumentError,
  ApproveOrRejectDocumentData,
  ApproveOrRejectDocumentError,
  AssessSanctionsApplicabilityData,
  AssessSanctionsApplicabilityError,
  AssignCategoriesRequest,
  AssignCategoriesToArticleData,
  AssignCategoriesToArticleError,
  AssignCategoriesToArticleParams,
  AutoRechargeConfigRequest,
  AutomatedFeedSource,
  BaseCreditPriceRequest,
  BatchProcessDocumentsData,
  BatchProcessDocumentsError,
  BatchProcessRequest,
  BatchProcessingRequest,
  BatchReportRequest,
  BatchScreenCustomersData,
  BatchScreenCustomersError,
  BatchScreeningRequest,
  BlockUserData,
  BlockUserError,
  BlockUserRequest,
  BlogSubmissionRequest,
  BodyBulkImportSanctions,
  BodyBulkUploadCriticalCountries,
  BodyImportCriticalProducts,
  BodyImportNotesFromExcel,
  BodyImportXmlSanctions,
  BodyProcessDocument,
  BodySubmitCaseStudy,
  BodySubmitDocument,
  BodyUpdateDocument,
  BodyUploadAssessmentForm,
  BodyUploadCustomerDocument,
  BodyUploadDocument,
  BodyUploadDocumentAttachment,
  BodyUploadImage,
  BulkImportEntriesData,
  BulkImportEntriesError,
  BulkImportEntriesParams,
  BulkImportMetadataOptionsData,
  BulkImportMetadataOptionsError,
  BulkImportMetadataOptionsParams,
  BulkImportSanctionsData,
  BulkImportSanctionsError,
  BulkImportSectionsData,
  BulkImportSectionsError,
  BulkImportSectionsParams,
  BulkPricingUpdate,
  BulkProcessFeedsData,
  BulkProcessFeedsError,
  BulkReorderRequest,
  BulkUpdateOrderRequest,
  BulkUpdatePricingData,
  BulkUpdatePricingError,
  BulkUpdatePricingPayload,
  BulkUpdateStatusData,
  BulkUpdateStatusError,
  BulkUpdateStatusParams,
  BulkUpdateStatusPayload,
  BulkUploadCriticalCountriesData,
  BulkUploadCriticalCountriesError,
  CancelInvitationData,
  CancelInvitationError,
  CancelInvitationParams,
  CheckActionPricingData,
  CheckActionPricingError,
  CheckActionPricingParams,
  CheckAndTriggerAlertsData,
  CheckDynamicPricingData,
  CheckDynamicPricingError,
  CheckDynamicPricingParams,
  CheckFreeTierEligibilityData,
  CheckHealthData,
  CheckIfSavedData,
  CheckIfSavedError,
  CheckIfSavedParams,
  CheckUserBlockedData,
  CheckUserBlockedError,
  CheckUserBlockedParams,
  ClassificationOutcomeCreate,
  ClassificationOutcomeUpdate,
  ClassificationTreeCreate,
  ClassificationTreeUpdate,
  ClassificationWorkflowCreate,
  ClassificationWorkflowUpdate,
  CleanupExpiredClassificationsData,
  CleanupProcessingHistoryData,
  CleanupProcessingHistoryError,
  CleanupProcessingHistoryParams,
  ClearCriticalProductsDatabaseData,
  CompareDocumentsData,
  CompareDocumentsError,
  ComparisonRequest,
  CompleteTemplateSelectionData,
  CompleteTemplateSelectionError,
  ConfigureFeedAlertsData,
  ConfigureFeedAlertsError,
  ConfigureFeedAlertsParams,
  ConfigureFeedAlertsPayload,
  ConfigureFeedSchedulingData,
  ConfigureFeedSchedulingError,
  ConfigureFeedSchedulingParams,
  ConfigureFeedSchedulingPayload,
  ConfigureSpendingAlertsData,
  ConfigureSpendingAlertsError,
  ConfigureSpendingAlertsPayload,
  ConsumeCreditsData,
  ConsumeCreditsError,
  ConsumeCreditsRequest,
  CountryCreateRequest,
  CountryReportRequest,
  CountrySearchFilters,
  CountrySearchRequest,
  CountryUpdateRequest,
  CreateAdminNotificationData,
  CreateAdminNotificationError,
  CreateAnnotationCollabData,
  CreateAnnotationCollabError,
  CreateAnnotationData,
  CreateAnnotationError,
  CreateAnnotationParams,
  CreateAnnotationRequest,
  CreateArticleCategoryData,
  CreateArticleCategoryError,
  CreateBadgeData,
  CreateBadgeError,
  CreateBadgeRequest,
  CreateBookmarkCollabData,
  CreateBookmarkCollabError,
  CreateBookmarkData,
  CreateBookmarkError,
  CreateBookmarkRequest,
  CreateCategoryData,
  CreateCategoryError,
  CreateChatThreadData,
  CreateChatThreadError,
  CreateClassificationNoteData,
  CreateClassificationNoteError,
  CreateClassificationOutcomeData,
  CreateClassificationOutcomeError,
  CreateClassificationOutcomeParams,
  CreateClassificationTreeData,
  CreateClassificationTreeError,
  CreateCompanyData,
  CreateCompanyError,
  CreateCompanyRequest,
  CreateComponentPricingData,
  CreateComponentPricingError,
  CreateContentItemData,
  CreateContentItemError,
  CreateContentRequest,
  CreateCountryData,
  CreateCountryError,
  CreateCreditPackageData,
  CreateCreditPackageError,
  CreateCreditPackageRequest,
  CreateCriticalCountryData,
  CreateCriticalCountryError,
  CreateCriticalProductData,
  CreateCriticalProductError,
  CreateCustomWidgetData,
  CreateCustomWidgetError,
  CreateCustomerData,
  CreateCustomerError,
  CreateDocumentAlertData,
  CreateDocumentAlertError,
  CreateDocumentCrossReferenceData,
  CreateDocumentCrossReferenceError,
  CreateDocumentCrossReferenceParams,
  CreateDocumentMetadataOptionData,
  CreateDocumentMetadataOptionError,
  CreateDocumentSectionData,
  CreateDocumentSectionError,
  CreateDocumentSectionParams,
  CreateFeedSourceData,
  CreateFeedSourceError,
  CreateGeographicPricingData,
  CreateGeographicPricingError,
  CreateGeographicPricingPayload,
  CreateHybridPricingModelData,
  CreateHybridPricingModelError,
  CreateHybridPricingModelPayload,
  CreateIntroductionNodeOptionData,
  CreateIntroductionNodeOptionError,
  CreateIntroductionNodeOptionParams,
  CreateIntroductionTreeData,
  CreateIntroductionTreeError,
  CreateIntroductionTreeNodeData,
  CreateIntroductionTreeNodeError,
  CreateIntroductionTreeNodeParams,
  CreateInvoiceData,
  CreateInvoiceError,
  CreateInvoiceRequest,
  CreateMetadataOptionData,
  CreateMetadataOptionError,
  CreateMetadataOptionRequest,
  CreateModulePricingConfigurationData,
  CreateModulePricingConfigurationError,
  CreateMonitoringScheduleData,
  CreateMonitoringScheduleError,
  CreateMonitoringScheduleRequest,
  CreateNodeOptionData,
  CreateNodeOptionError,
  CreateNodeOptionParams,
  CreateNoteRequest,
  CreateOrUpdateRiskAssessmentData,
  CreateOrUpdateRiskAssessmentError,
  CreateOrUpdateScreeningExplanationData,
  CreateOrUpdateScreeningExplanationError,
  CreatePaymentIntentData,
  CreatePaymentIntentError,
  CreatePricingRequest,
  CreateProductData,
  CreateProductError,
  CreateRegulatoryFeedData,
  CreateRegulatoryFeedError,
  CreateRegulatoryFeedPayload,
  CreateRestrictiveMeasureData,
  CreateRestrictiveMeasureError,
  CreateRestrictiveMeasureRequest,
  CreateSanctionEntityData,
  CreateSanctionEntityError,
  CreateSanctionsListData,
  CreateSanctionsListEntryData,
  CreateSanctionsListEntryError,
  CreateSanctionsListEntryParams,
  CreateSanctionsListError,
  CreateSanctionsNodeData,
  CreateSanctionsNodeError,
  CreateSanctionsNodeOptionData,
  CreateSanctionsNodeOptionError,
  CreateSanctionsNodeOptionParams,
  CreateSanctionsNodeParams,
  CreateSanctionsTreeData,
  CreateSanctionsTreeError,
  CreateSavedSearchData,
  CreateSavedSearchError,
  CreateSectionRequest,
  CreateSupportRequestData,
  CreateSupportRequestError,
  CreateTemplateData,
  CreateTemplateError,
  CreateTemplateRequest,
  CreateThreadRequest,
  CreateTradeCodeData,
  CreateTradeCodeError,
  CreateTradeCodeRequest,
  CreateTransactionData,
  CreateTransactionError,
  CreateTreeFormFieldData,
  CreateTreeFormFieldError,
  CreateTreeFormFieldParams,
  CreateTreeIndependentOutcomeData,
  CreateTreeIndependentOutcomeError,
  CreateTreeNodeData,
  CreateTreeNodeError,
  CreateTreeNodeParams,
  CreateUsageTierPricingData,
  CreateUsageTierPricingError,
  CreateUsageTierPricingPayload,
  CreateUserData,
  CreateUserError,
  CreateUserRequest,
  CreateWebhookData,
  CreateWebhookError,
  CreateWidgetRequest,
  CreateWidgetTemplateData,
  CreateWidgetTemplateError,
  CreateWorkflowData,
  CreateWorkflowError,
  CriticalCountryCreate,
  CriticalCountryUpdate,
  CrossReferenceRequest,
  CustomerProduct,
  CustomerProfile,
  CustomerTransactionInput,
  CustomizeTemplateData,
  CustomizeTemplateError,
  CustomizeTemplateRequest,
  DefaultPricingRule,
  DeleteAdminNotificationData,
  DeleteAdminNotificationError,
  DeleteAdminNotificationParams,
  DeleteAnnotationCollabData,
  DeleteAnnotationCollabError,
  DeleteAnnotationCollabParams,
  DeleteAnnotationData,
  DeleteAnnotationError,
  DeleteAnnotationParams,
  DeleteArticleCategoryData,
  DeleteArticleCategoryError,
  DeleteArticleCategoryParams,
  DeleteAssessmentData,
  DeleteAssessmentError,
  DeleteAssessmentParams,
  DeleteAttachmentDocumentData,
  DeleteAttachmentDocumentError,
  DeleteAttachmentDocumentParams,
  DeleteBadgeData,
  DeleteBadgeError,
  DeleteBadgeParams,
  DeleteBookmarkCollabData,
  DeleteBookmarkCollabError,
  DeleteBookmarkCollabParams,
  DeleteBookmarkData,
  DeleteBookmarkError,
  DeleteBookmarkParams,
  DeleteCategoryData,
  DeleteCategoryError,
  DeleteCategoryParams,
  DeleteChatData,
  DeleteChatError,
  DeleteChatRequest,
  DeleteClassificationData,
  DeleteClassificationError,
  DeleteClassificationNoteData,
  DeleteClassificationNoteError,
  DeleteClassificationNoteParams,
  DeleteClassificationOutcomeData,
  DeleteClassificationOutcomeError,
  DeleteClassificationOutcomeParams,
  DeleteClassificationParams,
  DeleteClassificationTreeData,
  DeleteClassificationTreeError,
  DeleteClassificationTreeParams,
  DeleteComponentPricingData,
  DeleteComponentPricingError,
  DeleteComponentPricingParams,
  DeleteContentItemData,
  DeleteContentItemError,
  DeleteContentItemParams,
  DeleteCountryData,
  DeleteCountryError,
  DeleteCountryParams,
  DeleteCreditPackageData,
  DeleteCreditPackageError,
  DeleteCreditPackageParams,
  DeleteCriticalCountryData,
  DeleteCriticalCountryError,
  DeleteCriticalCountryParams,
  DeleteCriticalProductData,
  DeleteCriticalProductError,
  DeleteCriticalProductParams,
  DeleteCustomWidgetData,
  DeleteCustomWidgetError,
  DeleteCustomWidgetParams,
  DeleteCustomerData,
  DeleteCustomerError,
  DeleteCustomerParams,
  DeleteDocumentAlertData,
  DeleteDocumentAlertError,
  DeleteDocumentAlertParams,
  DeleteDocumentData,
  DeleteDocumentError,
  DeleteDocumentMetadataOptionData,
  DeleteDocumentMetadataOptionError,
  DeleteDocumentMetadataOptionParams,
  DeleteDocumentParams,
  DeleteDocumentSectionData,
  DeleteDocumentSectionError,
  DeleteDocumentSectionParams,
  DeleteImageData,
  DeleteImageError,
  DeleteImageParams,
  DeleteIntroductionNodeOptionData,
  DeleteIntroductionNodeOptionError,
  DeleteIntroductionNodeOptionParams,
  DeleteIntroductionTreeData,
  DeleteIntroductionTreeError,
  DeleteIntroductionTreeNodeData,
  DeleteIntroductionTreeNodeError,
  DeleteIntroductionTreeNodeParams,
  DeleteIntroductionTreeParams,
  DeleteMessageData,
  DeleteMessageError,
  DeleteMessageParams,
  DeleteMetadataOptionData,
  DeleteMetadataOptionError,
  DeleteMetadataOptionParams,
  DeleteModulePricingConfigurationData,
  DeleteModulePricingConfigurationError,
  DeleteModulePricingConfigurationParams,
  DeleteMonitoringScheduleData,
  DeleteMonitoringScheduleError,
  DeleteMonitoringScheduleParams,
  DeleteNodeOptionData,
  DeleteNodeOptionError,
  DeleteNodeOptionParams,
  DeleteProductData,
  DeleteProductError,
  DeleteProductParams,
  DeleteRiskAssessmentData,
  DeleteRiskAssessmentError,
  DeleteRiskAssessmentParams,
  DeleteSanctionEntityData,
  DeleteSanctionEntityError,
  DeleteSanctionEntityParams,
  DeleteSanctionsListData,
  DeleteSanctionsListError,
  DeleteSanctionsListParams,
  DeleteSanctionsNodeData,
  DeleteSanctionsNodeError,
  DeleteSanctionsNodeOptionData,
  DeleteSanctionsNodeOptionError,
  DeleteSanctionsNodeOptionParams,
  DeleteSanctionsNodeParams,
  DeleteSanctionsTreeData,
  DeleteSanctionsTreeError,
  DeleteSanctionsTreeParams,
  DeleteSavedSearchData,
  DeleteSavedSearchError,
  DeleteSavedSearchParams,
  DeleteTemplateData,
  DeleteTemplateError,
  DeleteTemplateParams,
  DeleteTransactionData,
  DeleteTransactionError,
  DeleteTransactionParams,
  DeleteTreeFormFieldData,
  DeleteTreeFormFieldError,
  DeleteTreeFormFieldParams,
  DeleteTreeNodeData,
  DeleteTreeNodeError,
  DeleteTreeNodeParams,
  DeleteUserData,
  DeleteUserError,
  DeleteUserParams,
  DeleteUserProfileData,
  DeleteWidgetTemplateData,
  DeleteWidgetTemplateError,
  DeleteWidgetTemplateParams,
  DeleteWorkflowData,
  DeleteWorkflowError,
  DeleteWorkflowParams,
  DismissSpendingAlertData,
  DismissSpendingAlertError,
  DismissSpendingAlertParams,
  DocumentActivity,
  DocumentAlertCreate,
  DocumentAlertStatusUpdate,
  DocumentAlertUpdate,
  DocumentAnnotationInput,
  DocumentApprovalRequest,
  DocumentLinkingRequest,
  DocumentListRequest,
  DocumentPricingUpdate,
  DocumentSearchRequest,
  DownloadCriticalCountriesTemplateData,
  DownloadCriticalProductsExcelTemplateData,
  DownloadCriticalProductsTemplateData,
  DownloadDocumentFileData,
  DownloadDocumentFileError,
  DownloadDocumentFileParams,
  DownloadInvoiceData,
  DownloadInvoiceError,
  DownloadInvoiceParams,
  DuplicateClassificationTreeData,
  DuplicateClassificationTreeError,
  DuplicateClassificationTreeParams,
  DuplicateIntroductionTreeData,
  DuplicateIntroductionTreeError,
  DuplicateIntroductionTreeNodeData,
  DuplicateIntroductionTreeNodeError,
  DuplicateIntroductionTreeNodeParams,
  DuplicateIntroductionTreeParams,
  DuplicateSanctionsNodeData,
  DuplicateSanctionsNodeError,
  DuplicateSanctionsNodeParams,
  DuplicateSanctionsTreeData,
  DuplicateSanctionsTreeError,
  DuplicateSanctionsTreeParams,
  EmailRequest,
  EnhancedUserProfileRequest,
  EnterpriseInvoiceRequest,
  ExportAssessmentPdfData,
  ExportAssessmentPdfError,
  ExportAssessmentPdfParams,
  ExportCriticalCountriesData,
  ExportCriticalCountriesError,
  ExportCriticalProductsData,
  ExportCriticalProductsError,
  ExportCriticalProductsParams,
  ExportMetadataOptionsData,
  ExportMetadataOptionsError,
  ExportMetadataOptionsParams,
  ExportNotesToExcelData,
  ExportNotesToExcelError,
  ExportNotesToExcelParams,
  ExportRequest,
  ExportSanctionsData,
  ExportSanctionsError,
  ExportSanctionsParams,
  ExportScreeningResultsData,
  ExportScreeningResultsError,
  ExportSectionsData,
  ExportSectionsError,
  ExportSectionsParams,
  ExtendTrialCreditsData,
  ExtendTrialCreditsError,
  ExtendTrialCreditsParams,
  ExtractReferencesFromTextData,
  ExtractReferencesFromTextEndpointData,
  ExtractReferencesFromTextEndpointError,
  ExtractReferencesFromTextEndpointParams,
  ExtractReferencesFromTextError,
  ExtractReferencesRequest,
  GenerateBatchReportData,
  GenerateBatchReportError,
  GenerateCountryReportData,
  GenerateCountryReportError,
  GenerateEnterpriseInvoiceData,
  GenerateEnterpriseInvoiceError,
  GenerateIndividualReportData,
  GenerateIndividualReportError,
  GenerateWidgetCodeData,
  GenerateWidgetCodeError,
  GenerateWidgetCodeRequest,
  GetActiveSpendingAlertsData,
  GetAdminCustomersData,
  GetAdminNotificationsData,
  GetAdminNotificationsError,
  GetAdminNotificationsParams,
  GetAdminRealTimeDashboardData,
  GetAdminSanctionEntityData,
  GetAdminSanctionEntityError,
  GetAdminSanctionEntityParams,
  GetAdminStatsData,
  GetAdminSupportTicketsData,
  GetAdminSupportTicketsError,
  GetAdminSupportTicketsParams,
  GetAdminUsageAnalyticsData,
  GetAdminValidationTasksData,
  GetAdminValidationTasksError,
  GetAdminValidationTasksParams,
  GetAlertsSummaryData,
  GetAllAdminUsersData,
  GetAllCreditPackagesData,
  GetAllCriticalCountriesData,
  GetAllDocumentMetadataOptionsData,
  GetArticleCategoriesData,
  GetAuditLogsData,
  GetAuditLogsError,
  GetAuditLogsParams,
  GetAutoRechargeConfigData,
  GetAutoRechargeHistoryData,
  GetAutoRechargeHistoryError,
  GetAutoRechargeHistoryParams,
  GetAutomationAnalyticsData,
  GetAutomationJobData,
  GetAutomationJobError,
  GetAutomationJobParams,
  GetAutomationPerformanceMetricsData,
  GetBackgroundJobsData,
  GetBackgroundJobsError,
  GetBackgroundJobsParams,
  GetBadgeData,
  GetBadgeError,
  GetBadgeParams,
  GetBaseCreditPriceData,
  GetBillingSettingsData,
  GetBillingSettingsError,
  GetBillingSettingsParams,
  GetBillingSummaryData,
  GetBillingSummaryError,
  GetBillingSummaryParams,
  GetBlogDocumentData,
  GetBlogDocumentError,
  GetBlogDocumentParams,
  GetBlogSearchSuggestionsData,
  GetBlogSearchSuggestionsError,
  GetBlogSearchSuggestionsParams,
  GetCategoriesData,
  GetCategoriesHierarchyData,
  GetChatMessagesData,
  GetChatMessagesError,
  GetChatMessagesParams,
  GetChatPolicyData,
  GetChatThreadsData,
  GetClassificationCategoriesData,
  GetClassificationNoteByKeyData,
  GetClassificationNoteByKeyError,
  GetClassificationNoteByKeyParams,
  GetClassificationNotificationsData,
  GetClassificationTreeData,
  GetClassificationTreeError,
  GetClassificationTreeParams,
  GetCollaborationStatsCollabData,
  GetCollaborationStatsCollabError,
  GetCollaborationStatsCollabParams,
  GetCollaborationStatsData,
  GetCollaborationStatsError,
  GetCollaborationStatsParams,
  GetCompanyProfileData,
  GetCompanyProfileError,
  GetCompanyProfileParams,
  GetComparisonSuggestionsData,
  GetComparisonSuggestionsError,
  GetComparisonSuggestionsParams,
  GetComplianceMetricsData,
  GetComplianceRegulatoryMetricsData,
  GetComponentPricingData,
  GetComponentUsageBreakdownData,
  GetComponentUsageBreakdownError,
  GetComponentUsageBreakdownParams,
  GetComprehensivePricingAnalyticsData,
  GetContentByModuleData,
  GetContentByModuleError,
  GetContentByModuleParams,
  GetContentItemData,
  GetContentItemError,
  GetContentItemParams,
  GetControlRegimesData,
  GetCountryDetailData,
  GetCountryDetailError,
  GetCountryDetailParams,
  GetCountryRestrictionData,
  GetCountryRestrictionError,
  GetCountryRestrictionParams,
  GetCountryRiskLevelsData,
  GetCreditBalanceData,
  GetCreditPackagesData,
  GetCreditTransactionsData,
  GetCreditTransactionsError,
  GetCreditTransactionsParams,
  GetCriticalCountriesListData,
  GetCriticalCountriesListError,
  GetCriticalCountriesListParams,
  GetCriticalCountriesStatsData,
  GetCriticalProductsSectionContentData,
  GetCriticalProductsSectionContentError,
  GetCriticalProductsSectionContentParams,
  GetCriticalProductsStatsData,
  GetCrossReferenceStatsData,
  GetCustomWidgetData,
  GetCustomWidgetError,
  GetCustomWidgetParams,
  GetCustomerDocumentAnalyticsData,
  GetCustomerMonitoringAnalyticsData,
  GetCustomerMonitoringHistoryData,
  GetCustomerMonitoringHistoryError,
  GetCustomerMonitoringHistoryParams,
  GetCustomerProductCategoriesData,
  GetDailyUsageChartData,
  GetDailyUsageChartError,
  GetDailyUsageChartParams,
  GetDashboardSummaryData,
  GetDetailedDocumentAnalyticsData,
  GetDetailedDocumentAnalyticsError,
  GetDetailedDocumentAnalyticsParams,
  GetDocumentActivityCollabData,
  GetDocumentActivityCollabError,
  GetDocumentActivityCollabParams,
  GetDocumentActivityData,
  GetDocumentActivityError,
  GetDocumentActivityParams,
  GetDocumentAlertData,
  GetDocumentAlertError,
  GetDocumentAlertParams,
  GetDocumentAnalyticsData,
  GetDocumentAnalyticsError,
  GetDocumentAnalyticsParams,
  GetDocumentAnnotationsCollabData,
  GetDocumentAnnotationsCollabError,
  GetDocumentAnnotationsCollabParams,
  GetDocumentAnnotationsData,
  GetDocumentAnnotationsError,
  GetDocumentAnnotationsParams,
  GetDocumentCrossReferencesData,
  GetDocumentCrossReferencesError,
  GetDocumentCrossReferencesMonitoringData,
  GetDocumentCrossReferencesMonitoringError,
  GetDocumentCrossReferencesMonitoringParams,
  GetDocumentCrossReferencesParams,
  GetDocumentCrossReferencesProcessingData,
  GetDocumentCrossReferencesProcessingError,
  GetDocumentCrossReferencesProcessingParams,
  GetDocumentData,
  GetDocumentError,
  GetDocumentMetadataOptionsData,
  GetDocumentMetadataOptionsError,
  GetDocumentMetadataOptionsParams,
  GetDocumentParams,
  GetDocumentPricingData,
  GetDocumentPricingDetailData,
  GetDocumentPricingDetailError,
  GetDocumentPricingDetailParams,
  GetDocumentPricingError,
  GetDocumentPricingParams,
  GetDocumentReferenceIdData,
  GetDocumentReferenceIdError,
  GetDocumentReferenceIdParams,
  GetDocumentSectionsAdminData,
  GetDocumentSectionsAdminError,
  GetDocumentSectionsAdminParams,
  GetDocumentSectionsData,
  GetDocumentSectionsError,
  GetDocumentSectionsParams,
  GetDocumentTranslationsData,
  GetDocumentTranslationsError,
  GetDocumentTranslationsParams,
  GetEnhancedMetadataOptionsData,
  GetEnhancedUserProfileData,
  GetEnterpriseInvoicesData,
  GetEnterpriseInvoicesError,
  GetEnterpriseInvoicesParams,
  GetEntityTypesData,
  GetFeedHealthMetricsData,
  GetFeedHealthMetricsError,
  GetFeedHealthMetricsParams,
  GetFeedNotificationsData,
  GetFeedNotificationsError,
  GetFeedNotificationsParams,
  GetFieldTypesData,
  GetFreeTierStatusData,
  GetGeographicPricingData,
  GetGeographicRegionsData,
  GetHybridPricingModelsData,
  GetIntroductionNodeByKeyData,
  GetIntroductionNodeByKeyError,
  GetIntroductionNodeByKeyParams,
  GetIntroductionTreeData,
  GetIntroductionTreeError,
  GetIntroductionTreeParams,
  GetIntroductionTreeStartNodeData,
  GetIntroductionTreeStartNodeError,
  GetIntroductionTreeStartNodeParams,
  GetInvitationDetailsData,
  GetInvitationDetailsError,
  GetInvitationDetailsParams,
  GetInvoiceHistoryData,
  GetInvoiceHistoryError,
  GetInvoiceHistoryParams,
  GetIssuingAuthoritiesData,
  GetJurisdictionsData,
  GetKnowledgeBaseMetadataOptionsData,
  GetListTypesData,
  GetMeasureTypesData,
  GetMetadataOptionsData,
  GetMetadataOptionsError,
  GetMetadataOptionsParams,
  GetModelPerformanceData,
  GetModelPerformanceError,
  GetModulePricingConfigurationData,
  GetModulePricingConfigurationError,
  GetModulePricingConfigurationParams,
  GetModulePricingConfigurationsData,
  GetMonitoringAlertAnalyticsData,
  GetMonitoringConfigurationData,
  GetMonitoringDashboardSummaryData,
  GetMonitoringScheduleData,
  GetMonitoringScheduleError,
  GetMonitoringScheduleParams,
  GetMonitoringStatusData,
  GetMonitoringSystemHealthData,
  GetMyCompaniesData,
  GetMySubmissionsData,
  GetNodeByKeyData,
  GetNodeByKeyError,
  GetNodeByKeyParams,
  GetNotificationPreferencesData,
  GetPaymentFailuresData,
  GetPaymentMethodsData,
  GetPendingInvitationsData,
  GetPendingInvitationsError,
  GetPendingInvitationsParams,
  GetPendingStatsData,
  GetPendingTasksData,
  GetPerformanceMetricsData,
  GetPricingAnalyticsData,
  GetPricingAuditLogData,
  GetPricingAuditLogError,
  GetPricingAuditLogParams,
  GetPricingFeatureFlagsData,
  GetProcessedDocumentSectionsData,
  GetProcessedDocumentSectionsError,
  GetProcessedDocumentSectionsParams,
  GetProcessingStatusData,
  GetProcessingStatusError,
  GetProcessingStatusParams,
  GetProductClassificationData,
  GetProductClassificationError,
  GetProductClassificationParams,
  GetProductRiskLevelsData,
  GetPublishedSanctionsNodeOptionsData,
  GetPublishedSanctionsNodeOptionsError,
  GetPublishedSanctionsNodeOptionsParams,
  GetPublishedSanctionsTreeData,
  GetPublishedSanctionsTreeError,
  GetPublishedSanctionsTreeNodesData,
  GetPublishedSanctionsTreeNodesError,
  GetPublishedSanctionsTreeNodesParams,
  GetPublishedSanctionsTreeParams,
  GetPublishedWorkflowData,
  GetPublishedWorkflowError,
  GetPublishedWorkflowParams,
  GetRealTimeMetricsData,
  GetRelatedDocumentsForDocData,
  GetRelatedDocumentsForDocError,
  GetRelatedDocumentsForDocParams,
  GetRestrictionTypesData,
  GetRiskCategoriesData,
  GetRiskIndicatorsData,
  GetRiskIndicatorsError,
  GetRiskIndicatorsParams,
  GetRiskLevelsData,
  GetRoleDefinitionsData,
  GetSanctionSourcesData,
  GetSanctionsAuditLogData,
  GetSanctionsAuditLogError,
  GetSanctionsAuditLogParams,
  GetSanctionsJurisdictionsData,
  GetSanctionsListData,
  GetSanctionsListEntriesData,
  GetSanctionsListEntriesError,
  GetSanctionsListEntriesParams,
  GetSanctionsListError,
  GetSanctionsListParams,
  GetSanctionsListStatsData,
  GetSanctionsNodeData,
  GetSanctionsNodeError,
  GetSanctionsNodeOptionData,
  GetSanctionsNodeOptionError,
  GetSanctionsNodeOptionParams,
  GetSanctionsNodeParams,
  GetSanctionsProgramsData,
  GetSanctionsSearchEntityData,
  GetSanctionsSearchEntityError,
  GetSanctionsSearchEntityParams,
  GetSanctionsTreeData,
  GetSanctionsTreeError,
  GetSanctionsTreeParams,
  GetSavedArticlesData,
  GetSavedArticlesError,
  GetSavedArticlesParams,
  GetSavedSearchData,
  GetSavedSearchError,
  GetSavedSearchParams,
  GetScreeningAlertsData,
  GetScreeningAlertsError,
  GetScreeningAlertsParams,
  GetScreeningExplanationData,
  GetScreeningHistoryData,
  GetScreeningHistoryError,
  GetScreeningHistoryParams,
  GetScreeningPerformanceMetricsData,
  GetScreeningPerformanceMetricsError,
  GetScreeningPerformanceMetricsParams,
  GetSearchAlertsData,
  GetSearchAlertsError,
  GetSearchAlertsParams,
  GetSearchAnalyticsData,
  GetSearchAnalyticsError,
  GetSearchAnalyticsParams,
  GetSearchSuggestionsData,
  GetSearchSuggestionsError,
  GetSearchSuggestionsParams,
  GetSectionsNotApplicableData,
  GetSectionsNotApplicableError,
  GetSectionsNotApplicableParams,
  GetSupportTicketDetailData,
  GetSupportTicketDetailError,
  GetSupportTicketDetailParams,
  GetSupportedFormatsData,
  GetSupportedLanguagesData,
  GetSystemMetricsData,
  GetSystemStatusData,
  GetTeamMembersData,
  GetTeamMembersError,
  GetTeamMembersParams,
  GetTemplateData,
  GetTemplateError,
  GetTemplateParams,
  GetTreeFormFieldsData,
  GetTreeFormFieldsError,
  GetTreeFormFieldsParams,
  GetTreeStartNodeData,
  GetTreeStartNodeError,
  GetTreeStartNodeParams,
  GetTrendAnalysisData,
  GetTrendAnalysisError,
  GetTrendAnalysisParams,
  GetTrialUsageStatsData,
  GetUnreadNotificationCountData,
  GetUsageAnalyticsData,
  GetUsageAnalyticsError,
  GetUsageAnalyticsParams,
  GetUsageTierPricingData,
  GetUserAccessStatusData,
  GetUserActivitySummaryData,
  GetUserActivitySummaryError,
  GetUserActivitySummaryParams,
  GetUserBehaviorAnalyticsData,
  GetUserBehaviorAnalyticsError,
  GetUserBehaviorAnalyticsParams,
  GetUserBookmarksCollabData,
  GetUserBookmarksCollabError,
  GetUserBookmarksCollabParams,
  GetUserBookmarksData,
  GetUserCollaborationSummaryCollabData,
  GetUserCollaborationSummaryCollabError,
  GetUserCollaborationSummaryCollabParams,
  GetUserCollaborationSummaryData,
  GetUserNotificationsData,
  GetUserNotificationsError,
  GetUserNotificationsParams,
  GetUserProfileData,
  GetUserSupportTicketsData,
  GetUserSupportTicketsError,
  GetUserSupportTicketsParams,
  GetUserUsageSummaryData,
  GetUserValidationStatusData,
  GetUserValidationStatusError,
  GetUserValidationStatusParams,
  GetValidationTaskDetailData,
  GetValidationTaskDetailError,
  GetValidationTaskDetailParams,
  GetVatPreviewData,
  GetVatPreviewError,
  GetWidgetCategoriesData,
  GetWidgetTemplateData,
  GetWidgetTemplateError,
  GetWidgetTemplateParams,
  GetWorkflowByIdData,
  GetWorkflowByIdError,
  GetWorkflowByIdParams,
  HitVerificationRequest,
  ImportCriticalProductsData,
  ImportCriticalProductsError,
  ImportNotesFromExcelData,
  ImportNotesFromExcelError,
  ImportNotesFromExcelParams,
  ImportXmlSanctionsData,
  ImportXmlSanctionsError,
  IndividualReportRequest,
  InitializeDefaultContentData,
  IntroductionNavigationRequest,
  IntroductionNodeOptionCreate,
  IntroductionNodeOptionUpdate,
  IntroductionTreeCreate,
  IntroductionTreeNodeCreate,
  IntroductionTreeNodeUpdate,
  IntroductionTreeUpdate,
  InviteTeamMemberData,
  InviteTeamMemberError,
  InviteTeamMemberParams,
  InviteUserRequest,
  InvoiceRequest,
  KnowledgeBaseHealthData,
  ListActiveIntroductionTreesData,
  ListActiveTreesData,
  ListAdminDocumentsData,
  ListAdminDocumentsError,
  ListAdminDocumentsParams,
  ListAdminTasksData,
  ListAdminWorkflowsData,
  ListAdminWorkflowsError,
  ListAdminWorkflowsParams,
  ListAllClassificationOutcomesData,
  ListAttachmentDocumentsData,
  ListAutomationJobsData,
  ListAutomationJobsError,
  ListAutomationJobsParams,
  ListBadgeCategoriesData,
  ListBadgesData,
  ListBlogDocumentsData,
  ListBlogDocumentsError,
  ListBlogDocumentsParams,
  ListClassificationNotesData,
  ListClassificationNotesError,
  ListClassificationNotesParams,
  ListClassificationOutcomesData,
  ListClassificationOutcomesError,
  ListClassificationOutcomesParams,
  ListClassificationTreesData,
  ListCompanyFormsData,
  ListCountriesData,
  ListCriticalCountriesData,
  ListCriticalCountriesError,
  ListCriticalCountriesParams,
  ListCustomWidgetsData,
  ListCustomerDocumentsData,
  ListCustomerDocumentsError,
  ListCustomersData,
  ListCustomersError,
  ListCustomersParams,
  ListDocumentAlertsData,
  ListDocumentAlertsError,
  ListDocumentAlertsParams,
  ListDocumentsData,
  ListDocumentsError,
  ListDocumentsParams,
  ListFeedSourcesData,
  ListImagesData,
  ListIntroductionNodeOptionsData,
  ListIntroductionNodeOptionsError,
  ListIntroductionNodeOptionsParams,
  ListIntroductionTreeNodesData,
  ListIntroductionTreeNodesError,
  ListIntroductionTreeNodesParams,
  ListIntroductionTreesData,
  ListMonitoringSchedulesData,
  ListNodeOptionsData,
  ListNodeOptionsError,
  ListNodeOptionsParams,
  ListPendingDocumentsData,
  ListPendingDocumentsError,
  ListPendingDocumentsParams,
  ListProductsData,
  ListProductsError,
  ListProductsParams,
  ListPublishedSanctionsTreesData,
  ListRegulatoryFeedsData,
  ListRestrictiveMeasuresData,
  ListRestrictiveMeasuresError,
  ListRestrictiveMeasuresParams,
  ListSanctionEntitiesData,
  ListSanctionEntitiesError,
  ListSanctionEntitiesParams,
  ListSanctionsData,
  ListSanctionsListsData,
  ListSanctionsListsError,
  ListSanctionsListsParams,
  ListSanctionsNodeOptionsData,
  ListSanctionsNodeOptionsError,
  ListSanctionsNodeOptionsParams,
  ListSanctionsNodesData,
  ListSanctionsNodesError,
  ListSanctionsNodesParams,
  ListSanctionsTreesData,
  ListSavedClassificationsData,
  ListSavedClassificationsError,
  ListSavedClassificationsParams,
  ListSavedSearchesData,
  ListTemplatesData,
  ListTradeCodesData,
  ListTradeCodesError,
  ListTradeCodesParams,
  ListTransactionsData,
  ListTransactionsError,
  ListTransactionsParams,
  ListTreeNodesData,
  ListTreeNodesError,
  ListTreeNodesParams,
  ListUploadedFormsData,
  ListUserAssessmentsData,
  ListWebhooksData,
  ListWidgetTemplatesData,
  ListWorkflowsData,
  LoadAssessmentData,
  LoadAssessmentError,
  LoadAssessmentParams,
  LoadClassificationData,
  LoadClassificationError,
  LoadClassificationParams,
  LogCustomActionData,
  LogCustomActionError,
  LogCustomActionParams,
  LogCustomActionPayload,
  ManualTriggerRechargeData,
  MarkAllNotificationsReadData,
  MatchQualificationRequest,
  MetadataOptionRequest,
  MetadataOptionUpdate,
  ModelPerformanceRequest,
  ModulePricingCreate,
  ModulePricingUpdate,
  MonitoringConfiguration,
  MultiQuestionAssessmentRequest,
  NavigateIntroductionTreeData,
  NavigateIntroductionTreeError,
  NavigateIntroductionTreeParams,
  NavigateTreeData,
  NavigateTreeError,
  NavigateTreeParams,
  NavigationRequest,
  NodeOptionCreate,
  NodeOptionUpdate,
  NotificationPreferencesRequest,
  NotificationRequest,
  NotificationStatusUpdate,
  PaymentIntent,
  PaymentMethodRequest,
  PerformFeedHealthCheckData,
  PerformFeedHealthCheckError,
  PerformFeedHealthCheckParams,
  PredictCustomerRisksData,
  PredictCustomerRisksError,
  PredictiveRiskRequest,
  PreviewWidgetSearchData,
  PreviewWidgetSearchError,
  PreviewWidgetSearchParams,
  PreviewWidgetTemplateData,
  PreviewWidgetTemplateError,
  PreviewWidgetTemplateParams,
  ProcessClassificationMultiQuestionAssessmentData,
  ProcessClassificationMultiQuestionAssessmentError,
  ProcessClassificationMultiQuestionAssessmentParams,
  ProcessDocumentData,
  ProcessDocumentError,
  ProcessDocumentReferencesData,
  ProcessDocumentReferencesError,
  ProcessFeedEnhancedData,
  ProcessFeedEnhancedError,
  ProcessFeedEnhancedParams,
  ProcessIntroductionMultiQuestionAssessmentData,
  ProcessIntroductionMultiQuestionAssessmentError,
  ProcessIntroductionMultiQuestionAssessmentParams,
  ProcessReferenceRequest,
  ProductReviewUpdate,
  ProductSearchRequest,
  PublishDocumentData,
  PublishDocumentError,
  PublishDocumentRequest,
  QualifyScreeningMatchData,
  QualifyScreeningMatchError,
  QualifyScreeningMatchParams,
  ReactToMessageData,
  ReactToMessageError,
  ReactToMessageParams,
  ReactionRequest,
  RebuildAllCrossReferencesData,
  RebuildDocumentCrossReferencesData,
  RebuildDocumentCrossReferencesError,
  RebuildDocumentCrossReferencesParams,
  RemoveTeamMemberData,
  RemoveTeamMemberError,
  RemoveTeamMemberParams,
  ReorderDocumentMetadataOptionsData,
  ReorderDocumentMetadataOptionsError,
  ReorderDocumentMetadataOptionsParams,
  ReorderMetadataOptionsData,
  ReorderMetadataOptionsError,
  ReorderRequest,
  ReorderSectionsData,
  ReorderSectionsError,
  ReorderSectionsParams,
  RequestInvoiceData,
  RequestInvoiceError,
  RequestTranslationData,
  RequestTranslationError,
  ResendInvitationData,
  ResendInvitationError,
  ResendInvitationRequest,
  ReserveCreditsData,
  ReserveCreditsError,
  ReserveCreditsRequest,
  ResolveAnnotationCollabData,
  ResolveAnnotationCollabError,
  ResolveAnnotationCollabParams,
  ResolveAnnotationData,
  ResolveAnnotationError,
  ResolveAnnotationParams,
  ResolveDocumentReferencesData,
  ResolveDocumentReferencesError,
  ResolveDocumentReferencesPayload,
  RespondToValidationData,
  RespondToValidationError,
  RestoreClassificationData,
  RestoreClassificationError,
  RestoreClassificationParams,
  RetryFailedPaymentData,
  RetryFailedPaymentError,
  RetryFailedPaymentParams,
  RiskAssessmentRequest,
  RiskTrendAnalysisRequest,
  RunSavedSearchData,
  RunSavedSearchError,
  RunSavedSearchParams,
  SanctionEntityCreate,
  SanctionEntityUpdate,
  SanctionsAssessmentRequest,
  SanctionsListCreate,
  SanctionsListEntryCreate,
  SanctionsListUpdate,
  SanctionsNodeCreate,
  SanctionsNodeOptionCreate,
  SanctionsNodeOptionUpdate,
  SanctionsNodeUpdate,
  SanctionsSearchRequest,
  SanctionsTreeCreate,
  SanctionsTreeUpdate,
  SaveArticleData,
  SaveArticleError,
  SaveArticleRequest,
  SaveAssessmentData,
  SaveAssessmentError,
  SaveAssessmentRequest,
  SaveClassificationData,
  SaveClassificationError,
  SaveEnhancedUserProfileData,
  SaveEnhancedUserProfileError,
  SaveMonitoringConfigurationData,
  SaveMonitoringConfigurationError,
  SaveUserProfileData,
  SaveUserProfileError,
  SavedClassificationRequest,
  SavedSearchRequest,
  SavedSearchUpdate,
  ScheduleRiskAssessmentsData,
  ScheduleRiskAssessmentsError,
  ScheduleRiskAssessmentsRequest,
  ScreenCustomerData,
  ScreenCustomerError,
  ScreenCustomerParams,
  ScreenCustomerPayload,
  ScreeningExportRequest,
  SearchBlogDocumentsData,
  SearchBlogDocumentsError,
  SearchCountriesData,
  SearchCountriesError,
  SearchCriticalCountriesData,
  SearchCriticalCountriesError,
  SearchCriticalProductsData,
  SearchCriticalProductsError,
  SearchCriticalProductsRequest,
  SearchDocumentsData,
  SearchDocumentsError,
  SearchDocumentsForReferenceData,
  SearchDocumentsForReferenceError,
  SearchDocumentsForReferenceParams,
  SearchProductsData,
  SearchProductsError,
  SearchSanctionsData,
  SearchSanctionsError,
  SearchWatchlistsData,
  SearchWatchlistsError,
  SearchWidgetDataData,
  SearchWidgetDataError,
  SectionsNotApplicableRequest,
  SelectTemplateData,
  SelectTemplateError,
  SendAssessmentEmailData,
  SendAssessmentEmailError,
  SendFeedNotificationData,
  SendFeedNotificationError,
  SendFeedNotificationParams,
  SendInvitationEmailManuallyData,
  SendInvitationEmailManuallyError,
  SendInvitationEmailManuallyParams,
  SendMessageData,
  SendMessageError,
  SendMessageRequest,
  ServeDocumentData,
  ServeDocumentError,
  ServeDocumentParams,
  ServeImageData,
  ServeImageError,
  ServeImageParams,
  ServePublicImageAltData,
  ServePublicImageAltError,
  ServePublicImageAltParams,
  ServePublicImageData,
  ServePublicImageError,
  ServePublicImageParams,
  ServeStaticImageData,
  ServeStaticImageError,
  ServeStaticImageParams,
  SetupAutoRechargeData,
  SetupAutoRechargeError,
  StripeWebhookData,
  SubmitBlogArticleData,
  SubmitBlogArticleError,
  SubmitCaseStudyData,
  SubmitCaseStudyError,
  SubmitDocumentData,
  SubmitDocumentError,
  SubmitForValidationData,
  SubmitForValidationError,
  SupportRequestCreate,
  TaskUpdateRequest,
  TemplateSelectionRequest,
  TestWidgetData,
  TestWidgetError,
  TestWidgetParams,
  ToggleAutoRechargeData,
  ToggleAutoRechargeError,
  ToggleAutoRechargeParams,
  TrackDocumentActivityCollabData,
  TrackDocumentActivityCollabError,
  TrackDocumentActivityCollabParams,
  TrackDocumentActivityData,
  TrackDocumentActivityError,
  TrackDocumentActivityParams,
  TrackDocumentActivityPayload,
  TranslationRequest,
  TreeFormFieldCreate,
  TreeFormFieldUpdate,
  TreeNodeCreate,
  TreeNodeUpdate,
  TriggerFeedUpdateData,
  TriggerFeedUpdateError,
  TriggerFeedUpdateParams,
  TriggerManualScreeningData,
  TriggerManualScreeningError,
  TriggerManualScreeningParams,
  TriggerMonitoringData,
  TriggerMonitoringError,
  TriggerMonitoringRequest,
  UnsaveArticleData,
  UnsaveArticleError,
  UnsaveArticleParams,
  UpdateAdminNotificationData,
  UpdateAdminNotificationError,
  UpdateAdminNotificationParams,
  UpdateAlertStatusData,
  UpdateAlertStatusError,
  UpdateAlertStatusParams,
  UpdateAnnotationCollabData,
  UpdateAnnotationCollabError,
  UpdateAnnotationCollabParams,
  UpdateAnnotationData,
  UpdateAnnotationError,
  UpdateAnnotationParams,
  UpdateAnnotationRequest,
  UpdateArticleCategoryData,
  UpdateArticleCategoryError,
  UpdateArticleCategoryParams,
  UpdateBadgeData,
  UpdateBadgeError,
  UpdateBadgeParams,
  UpdateBadgeRequest,
  UpdateBaseCreditPriceData,
  UpdateBaseCreditPriceError,
  UpdateBillingSettingsData,
  UpdateBillingSettingsError,
  UpdateBillingSettingsParams,
  UpdateBillingSettingsRequest,
  UpdateBulkPricingData,
  UpdateBulkPricingError,
  UpdateCategoryData,
  UpdateCategoryError,
  UpdateCategoryParams,
  UpdateClassificationNoteData,
  UpdateClassificationNoteError,
  UpdateClassificationNoteParams,
  UpdateClassificationOutcomeData,
  UpdateClassificationOutcomeError,
  UpdateClassificationOutcomeParams,
  UpdateClassificationTreeData,
  UpdateClassificationTreeError,
  UpdateClassificationTreeParams,
  UpdateCompanyProfileData,
  UpdateCompanyProfileError,
  UpdateCompanyProfileParams,
  UpdateCompanyProfileRequest,
  UpdateComponentPricingData,
  UpdateComponentPricingError,
  UpdateComponentPricingParams,
  UpdateContentItemData,
  UpdateContentItemError,
  UpdateContentItemParams,
  UpdateContentRequest,
  UpdateCountryData,
  UpdateCountryError,
  UpdateCountryParams,
  UpdateCreditPackageData,
  UpdateCreditPackageError,
  UpdateCreditPackageParams,
  UpdateCreditPackageRequest,
  UpdateCriticalCountryData,
  UpdateCriticalCountryError,
  UpdateCriticalCountryParams,
  UpdateCustomWidgetData,
  UpdateCustomWidgetError,
  UpdateCustomWidgetParams,
  UpdateCustomerData,
  UpdateCustomerError,
  UpdateCustomerParams,
  UpdateDocumentAlertData,
  UpdateDocumentAlertError,
  UpdateDocumentAlertParams,
  UpdateDocumentData,
  UpdateDocumentError,
  UpdateDocumentMetadataOptionData,
  UpdateDocumentMetadataOptionError,
  UpdateDocumentMetadataOptionParams,
  UpdateDocumentParams,
  UpdateDocumentPricingData,
  UpdateDocumentPricingError,
  UpdateDocumentPricingParams,
  UpdateDocumentSectionData,
  UpdateDocumentSectionError,
  UpdateDocumentSectionParams,
  UpdateDocumentStatusData,
  UpdateDocumentStatusError,
  UpdateDocumentStatusParams,
  UpdateDocumentStatusRequest,
  UpdateFeatureFlagRequest,
  UpdateIntroductionNodeOptionData,
  UpdateIntroductionNodeOptionError,
  UpdateIntroductionNodeOptionParams,
  UpdateIntroductionTreeData,
  UpdateIntroductionTreeError,
  UpdateIntroductionTreeNodeData,
  UpdateIntroductionTreeNodeError,
  UpdateIntroductionTreeNodeParams,
  UpdateIntroductionTreeParams,
  UpdateInvoiceStatusData,
  UpdateInvoiceStatusError,
  UpdateInvoiceStatusParams,
  UpdateMemberRoleData,
  UpdateMemberRoleError,
  UpdateMemberRoleParams,
  UpdateMemberRoleRequest,
  UpdateMetadataOptionData,
  UpdateMetadataOptionError,
  UpdateMetadataOptionParams,
  UpdateMetadataOptionRequest,
  UpdateModulePricingConfigurationData,
  UpdateModulePricingConfigurationError,
  UpdateModulePricingConfigurationParams,
  UpdateMonitoringScheduleData,
  UpdateMonitoringScheduleError,
  UpdateMonitoringScheduleParams,
  UpdateMonitoringScheduleRequest,
  UpdateNodeOptionData,
  UpdateNodeOptionError,
  UpdateNodeOptionParams,
  UpdateNoteRequest,
  UpdateNotificationPreferencesData,
  UpdateNotificationPreferencesError,
  UpdateNotificationStatusData,
  UpdateNotificationStatusError,
  UpdateNotificationStatusParams,
  UpdatePricingFeatureFlagData,
  UpdatePricingFeatureFlagError,
  UpdatePricingFeatureFlagParams,
  UpdatePricingRequest,
  UpdateProductData,
  UpdateProductError,
  UpdateProductParams,
  UpdateProductReviewData,
  UpdateProductReviewError,
  UpdateProductReviewParams,
  UpdateRiskAssessmentsData,
  UpdateRiskAssessmentsError,
  UpdateRiskAssessmentsRequest,
  UpdateSanctionEntityData,
  UpdateSanctionEntityError,
  UpdateSanctionEntityParams,
  UpdateSanctionsListData,
  UpdateSanctionsListError,
  UpdateSanctionsListParams,
  UpdateSanctionsNodeData,
  UpdateSanctionsNodeError,
  UpdateSanctionsNodeOptionData,
  UpdateSanctionsNodeOptionError,
  UpdateSanctionsNodeOptionParams,
  UpdateSanctionsNodeParams,
  UpdateSanctionsTreeData,
  UpdateSanctionsTreeError,
  UpdateSanctionsTreeParams,
  UpdateSavedSearchData,
  UpdateSavedSearchError,
  UpdateSavedSearchParams,
  UpdateSectionRequest,
  UpdateSectionsNotApplicableData,
  UpdateSectionsNotApplicableError,
  UpdateSectionsNotApplicableParams,
  UpdateTaskData,
  UpdateTaskError,
  UpdateTaskParams,
  UpdateTemplateData,
  UpdateTemplateError,
  UpdateTemplateParams,
  UpdateTemplateRequest,
  UpdateTransactionData,
  UpdateTransactionError,
  UpdateTransactionParams,
  UpdateTreeFormFieldData,
  UpdateTreeFormFieldError,
  UpdateTreeFormFieldParams,
  UpdateTreeNodeData,
  UpdateTreeNodeError,
  UpdateTreeNodeParams,
  UpdateUserData,
  UpdateUserError,
  UpdateUserParams,
  UpdateUserRequest,
  UpdateWidgetRequest,
  UpdateWidgetTemplateData,
  UpdateWidgetTemplateError,
  UpdateWidgetTemplateParams,
  UpdateWorkflowData,
  UpdateWorkflowError,
  UpdateWorkflowParams,
  UploadAssessmentFormData,
  UploadAssessmentFormError,
  UploadCustomerDocumentData,
  UploadCustomerDocumentError,
  UploadDocumentAttachmentData,
  UploadDocumentAttachmentError,
  UploadDocumentData,
  UploadDocumentError,
  UploadImageData,
  UploadImageError,
  UserBookmarkInput,
  UserProfileRequest,
  VATPreviewRequest,
  ValidationSubmissionRequest,
  VerifyHitData,
  VerifyHitError,
  WatchlistSearchRequest,
  WebhookEndpoint,
  WidgetSearchRequest,
  WidgetTemplate,
  WidgetTestRequest,
} from "./data-contracts";
import { ContentType, HttpClient, RequestParams } from "./http-client";

export class Brain<SecurityDataType = unknown> extends HttpClient<SecurityDataType> {
  /**
   * @description Check health of application. Returns 200 when OK, 500 when not.
   *
   * @name check_health
   * @summary Check Health
   * @request GET:/_healthz
   */
  check_health = (params: RequestParams = {}) =>
    this.request<CheckHealthData, any>({
      path: `/_healthz`,
      method: "GET",
      ...params,
    });

  /**
   * @description Get hierarchical categories structure with document counts
   *
   * @tags categories, dbtn/module:categories, dbtn/hasAuth
   * @name get_categories_hierarchy
   * @summary Get Categories Hierarchy
   * @request GET:/routes/categories/hierarchy
   */
  get_categories_hierarchy = (params: RequestParams = {}) =>
    this.request<GetCategoriesHierarchyData, any>({
      path: `/routes/categories/hierarchy`,
      method: "GET",
      ...params,
    });

  /**
   * @description Get all enhanced metadata options for document upload and editing
   *
   * @tags dbtn/module:enhanced_metadata, dbtn/hasAuth
   * @name get_enhanced_metadata_options
   * @summary Get Enhanced Metadata Options
   * @request GET:/routes/enhanced-metadata/options
   */
  get_enhanced_metadata_options = (params: RequestParams = {}) =>
    this.request<GetEnhancedMetadataOptionsData, any>({
      path: `/routes/enhanced-metadata/options`,
      method: "GET",
      ...params,
    });

  /**
   * @description Perform search using a custom widget configuration
   *
   * @tags dbtn/module:widget_search, dbtn/hasAuth
   * @name search_widget_data
   * @summary Search Widget Data
   * @request POST:/routes/widget-search/search
   */
  search_widget_data = (data: WidgetSearchRequest, params: RequestParams = {}) =>
    this.request<SearchWidgetDataData, SearchWidgetDataError>({
      path: `/routes/widget-search/search`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Preview search results for a widget without full configuration
   *
   * @tags dbtn/module:widget_search, dbtn/hasAuth
   * @name preview_widget_search
   * @summary Preview Widget Search
   * @request GET:/routes/widget-search/widget/{widget_id}/preview
   */
  preview_widget_search = ({ widgetId, ...query }: PreviewWidgetSearchParams, params: RequestParams = {}) =>
    this.request<PreviewWidgetSearchData, PreviewWidgetSearchError>({
      path: `/routes/widget-search/widget/${widgetId}/preview`,
      method: "GET",
      query: query,
      ...params,
    });

  /**
   * @description Get all available widget templates
   *
   * @tags dbtn/module:widget_management, dbtn/hasAuth
   * @name list_widget_templates
   * @summary List Widget Templates
   * @request GET:/routes/widget-management/templates
   */
  list_widget_templates = (params: RequestParams = {}) =>
    this.request<ListWidgetTemplatesData, any>({
      path: `/routes/widget-management/templates`,
      method: "GET",
      ...params,
    });

  /**
   * @description Create a new widget template
   *
   * @tags dbtn/module:widget_management, dbtn/hasAuth
   * @name create_widget_template
   * @summary Create Widget Template
   * @request POST:/routes/widget-management/templates
   */
  create_widget_template = (data: WidgetTemplate, params: RequestParams = {}) =>
    this.request<CreateWidgetTemplateData, CreateWidgetTemplateError>({
      path: `/routes/widget-management/templates`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Get a specific widget template
   *
   * @tags dbtn/module:widget_management, dbtn/hasAuth
   * @name get_widget_template
   * @summary Get Widget Template
   * @request GET:/routes/widget-management/templates/{template_id}
   */
  get_widget_template = ({ templateId, ...query }: GetWidgetTemplateParams, params: RequestParams = {}) =>
    this.request<GetWidgetTemplateData, GetWidgetTemplateError>({
      path: `/routes/widget-management/templates/${templateId}`,
      method: "GET",
      ...params,
    });

  /**
   * @description Update an existing widget template
   *
   * @tags dbtn/module:widget_management, dbtn/hasAuth
   * @name update_widget_template
   * @summary Update Widget Template
   * @request PUT:/routes/widget-management/templates/{template_id}
   */
  update_widget_template = (
    { templateId, ...query }: UpdateWidgetTemplateParams,
    data: WidgetTemplate,
    params: RequestParams = {},
  ) =>
    this.request<UpdateWidgetTemplateData, UpdateWidgetTemplateError>({
      path: `/routes/widget-management/templates/${templateId}`,
      method: "PUT",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Delete a widget template
   *
   * @tags dbtn/module:widget_management, dbtn/hasAuth
   * @name delete_widget_template
   * @summary Delete Widget Template
   * @request DELETE:/routes/widget-management/templates/{template_id}
   */
  delete_widget_template = ({ templateId, ...query }: DeleteWidgetTemplateParams, params: RequestParams = {}) =>
    this.request<DeleteWidgetTemplateData, DeleteWidgetTemplateError>({
      path: `/routes/widget-management/templates/${templateId}`,
      method: "DELETE",
      ...params,
    });

  /**
   * @description Get all created custom widgets
   *
   * @tags dbtn/module:widget_management, dbtn/hasAuth
   * @name list_custom_widgets
   * @summary List Custom Widgets
   * @request GET:/routes/widget-management/widgets
   */
  list_custom_widgets = (params: RequestParams = {}) =>
    this.request<ListCustomWidgetsData, any>({
      path: `/routes/widget-management/widgets`,
      method: "GET",
      ...params,
    });

  /**
   * @description Create a new custom widget from a template
   *
   * @tags dbtn/module:widget_management, dbtn/hasAuth
   * @name create_custom_widget
   * @summary Create Custom Widget
   * @request POST:/routes/widget-management/widgets
   */
  create_custom_widget = (data: CreateWidgetRequest, params: RequestParams = {}) =>
    this.request<CreateCustomWidgetData, CreateCustomWidgetError>({
      path: `/routes/widget-management/widgets`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Get a specific custom widget
   *
   * @tags dbtn/module:widget_management, dbtn/hasAuth
   * @name get_custom_widget
   * @summary Get Custom Widget
   * @request GET:/routes/widget-management/widgets/{widget_id}
   */
  get_custom_widget = ({ widgetId, ...query }: GetCustomWidgetParams, params: RequestParams = {}) =>
    this.request<GetCustomWidgetData, GetCustomWidgetError>({
      path: `/routes/widget-management/widgets/${widgetId}`,
      method: "GET",
      ...params,
    });

  /**
   * @description Update a custom widget
   *
   * @tags dbtn/module:widget_management, dbtn/hasAuth
   * @name update_custom_widget
   * @summary Update Custom Widget
   * @request PUT:/routes/widget-management/widgets/{widget_id}
   */
  update_custom_widget = (
    { widgetId, ...query }: UpdateCustomWidgetParams,
    data: UpdateWidgetRequest,
    params: RequestParams = {},
  ) =>
    this.request<UpdateCustomWidgetData, UpdateCustomWidgetError>({
      path: `/routes/widget-management/widgets/${widgetId}`,
      method: "PUT",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Delete a custom widget
   *
   * @tags dbtn/module:widget_management, dbtn/hasAuth
   * @name delete_custom_widget
   * @summary Delete Custom Widget
   * @request DELETE:/routes/widget-management/widgets/{widget_id}
   */
  delete_custom_widget = ({ widgetId, ...query }: DeleteCustomWidgetParams, params: RequestParams = {}) =>
    this.request<DeleteCustomWidgetData, DeleteCustomWidgetError>({
      path: `/routes/widget-management/widgets/${widgetId}`,
      method: "DELETE",
      ...params,
    });

  /**
   * @description Test a widget with sample data
   *
   * @tags dbtn/module:widget_management, dbtn/hasAuth
   * @name test_widget
   * @summary Test Widget
   * @request POST:/routes/widget-management/widgets/{widget_id}/test
   */
  test_widget = ({ widgetId, ...query }: TestWidgetParams, data: WidgetTestRequest, params: RequestParams = {}) =>
    this.request<TestWidgetData, TestWidgetError>({
      path: `/routes/widget-management/widgets/${widgetId}/test`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Get available widget categories
   *
   * @tags dbtn/module:widget_management, dbtn/hasAuth
   * @name get_widget_categories
   * @summary Get Widget Categories
   * @request GET:/routes/widget-management/categories
   */
  get_widget_categories = (params: RequestParams = {}) =>
    this.request<GetWidgetCategoriesData, any>({
      path: `/routes/widget-management/categories`,
      method: "GET",
      ...params,
    });

  /**
   * @description Get available field types for widget configuration
   *
   * @tags dbtn/module:widget_management, dbtn/hasAuth
   * @name get_field_types
   * @summary Get Field Types
   * @request GET:/routes/widget-management/field-types
   */
  get_field_types = (params: RequestParams = {}) =>
    this.request<GetFieldTypesData, any>({
      path: `/routes/widget-management/field-types`,
      method: "GET",
      ...params,
    });

  /**
   * @description Generate React component code for a custom widget
   *
   * @tags dbtn/module:widget_generator, dbtn/hasAuth
   * @name generate_widget_code
   * @summary Generate Widget Code
   * @request POST:/routes/widget-generator/generate
   */
  generate_widget_code = (data: GenerateWidgetCodeRequest, params: RequestParams = {}) =>
    this.request<GenerateWidgetCodeData, GenerateWidgetCodeError>({
      path: `/routes/widget-generator/generate`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Preview what a widget template would generate
   *
   * @tags dbtn/module:widget_generator, dbtn/hasAuth
   * @name preview_widget_template
   * @summary Preview Widget Template
   * @request GET:/routes/widget-generator/templates/{template_id}/preview
   */
  preview_widget_template = ({ templateId, ...query }: PreviewWidgetTemplateParams, params: RequestParams = {}) =>
    this.request<PreviewWidgetTemplateData, PreviewWidgetTemplateError>({
      path: `/routes/widget-generator/templates/${templateId}/preview`,
      method: "GET",
      ...params,
    });

  /**
   * @description Get analytics for documents with views, engagement metrics, and trends
   *
   * @tags analytics, dbtn/module:analytics, dbtn/hasAuth
   * @name get_document_analytics
   * @summary Get Document Analytics
   * @request GET:/routes/analytics/documents
   */
  get_document_analytics = (query: GetDocumentAnalyticsParams, params: RequestParams = {}) =>
    this.request<GetDocumentAnalyticsData, GetDocumentAnalyticsError>({
      path: `/routes/analytics/documents`,
      method: "GET",
      query: query,
      ...params,
    });

  /**
   * @description Get detailed analytics for a specific document
   *
   * @tags analytics, dbtn/module:analytics, dbtn/hasAuth
   * @name get_detailed_document_analytics
   * @summary Get Detailed Document Analytics
   * @request GET:/routes/analytics/documents/{document_id}/detailed
   */
  get_detailed_document_analytics = (
    { documentId, ...query }: GetDetailedDocumentAnalyticsParams,
    params: RequestParams = {},
  ) =>
    this.request<GetDetailedDocumentAnalyticsData, GetDetailedDocumentAnalyticsError>({
      path: `/routes/analytics/documents/${documentId}/detailed`,
      method: "GET",
      ...params,
    });

  /**
   * @description Get user behavior analytics and engagement patterns
   *
   * @tags analytics, dbtn/module:analytics, dbtn/hasAuth
   * @name get_user_behavior_analytics
   * @summary Get User Behavior Analytics
   * @request GET:/routes/analytics/users/behavior
   */
  get_user_behavior_analytics = (query: GetUserBehaviorAnalyticsParams, params: RequestParams = {}) =>
    this.request<GetUserBehaviorAnalyticsData, GetUserBehaviorAnalyticsError>({
      path: `/routes/analytics/users/behavior`,
      method: "GET",
      query: query,
      ...params,
    });

  /**
   * @description Get search query analytics and patterns
   *
   * @tags analytics, dbtn/module:analytics, dbtn/hasAuth
   * @name get_search_analytics
   * @summary Get Search Analytics
   * @request GET:/routes/analytics/search
   */
  get_search_analytics = (query: GetSearchAnalyticsParams, params: RequestParams = {}) =>
    this.request<GetSearchAnalyticsData, GetSearchAnalyticsError>({
      path: `/routes/analytics/search`,
      method: "GET",
      query: query,
      ...params,
    });

  /**
   * @description Get overall system performance and usage metrics
   *
   * @tags analytics, dbtn/module:analytics, dbtn/hasAuth
   * @name get_system_metrics
   * @summary Get System Metrics
   * @request GET:/routes/analytics/system/metrics
   */
  get_system_metrics = (params: RequestParams = {}) =>
    this.request<GetSystemMetricsData, any>({
      path: `/routes/analytics/system/metrics`,
      method: "GET",
      ...params,
    });

  /**
   * @description Get compliance-specific metrics and KPIs
   *
   * @tags analytics, dbtn/module:analytics, dbtn/hasAuth
   * @name get_compliance_metrics
   * @summary Get Compliance Metrics
   * @request GET:/routes/analytics/compliance/metrics
   */
  get_compliance_metrics = (params: RequestParams = {}) =>
    this.request<GetComplianceMetricsData, any>({
      path: `/routes/analytics/compliance/metrics`,
      method: "GET",
      ...params,
    });

  /**
   * @description Get system performance metrics and optimization data
   *
   * @tags analytics, dbtn/module:analytics, dbtn/hasAuth
   * @name get_performance_metrics
   * @summary Get Performance Metrics
   * @request GET:/routes/analytics/performance/metrics
   */
  get_performance_metrics = (params: RequestParams = {}) =>
    this.request<GetPerformanceMetricsData, any>({
      path: `/routes/analytics/performance/metrics`,
      method: "GET",
      ...params,
    });

  /**
   * @description Get translation status and available languages for a document
   *
   * @tags analytics, dbtn/module:analytics, dbtn/hasAuth
   * @name get_document_translations
   * @summary Get Document Translations
   * @request GET:/routes/analytics/multilingual/documents/{document_id}
   */
  get_document_translations = ({ documentId, ...query }: GetDocumentTranslationsParams, params: RequestParams = {}) =>
    this.request<GetDocumentTranslationsData, GetDocumentTranslationsError>({
      path: `/routes/analytics/multilingual/documents/${documentId}`,
      method: "GET",
      ...params,
    });

  /**
   * @description Request translation of a document to a target language
   *
   * @tags analytics, dbtn/module:analytics, dbtn/hasAuth
   * @name request_translation
   * @summary Request Translation
   * @request POST:/routes/analytics/multilingual/translate
   */
  request_translation = (data: TranslationRequest, params: RequestParams = {}) =>
    this.request<RequestTranslationData, RequestTranslationError>({
      path: `/routes/analytics/multilingual/translate`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Get list of supported languages for translation
   *
   * @tags analytics, dbtn/module:analytics, dbtn/hasAuth
   * @name get_supported_languages
   * @summary Get Supported Languages
   * @request GET:/routes/analytics/multilingual/supported-languages
   */
  get_supported_languages = (params: RequestParams = {}) =>
    this.request<GetSupportedLanguagesData, any>({
      path: `/routes/analytics/multilingual/supported-languages`,
      method: "GET",
      ...params,
    });

  /**
   * @description Get comprehensive dashboard summary with key metrics
   *
   * @tags analytics, dbtn/module:analytics, dbtn/hasAuth
   * @name get_dashboard_summary
   * @summary Get Dashboard Summary
   * @request GET:/routes/analytics/dashboard/summary
   */
  get_dashboard_summary = (params: RequestParams = {}) =>
    this.request<GetDashboardSummaryData, any>({
      path: `/routes/analytics/dashboard/summary`,
      method: "GET",
      ...params,
    });

  /**
   * @description List all introduction trees
   *
   * @tags dbtn/module:introduction, dbtn/hasAuth
   * @name list_introduction_trees
   * @summary List Introduction Trees
   * @request GET:/routes/introduction/admin/trees
   */
  list_introduction_trees = (params: RequestParams = {}) =>
    this.request<ListIntroductionTreesData, any>({
      path: `/routes/introduction/admin/trees`,
      method: "GET",
      ...params,
    });

  /**
   * @description Create a new introduction tree
   *
   * @tags dbtn/module:introduction, dbtn/hasAuth
   * @name create_introduction_tree
   * @summary Create Introduction Tree
   * @request POST:/routes/introduction/admin/trees
   */
  create_introduction_tree = (data: IntroductionTreeCreate, params: RequestParams = {}) =>
    this.request<CreateIntroductionTreeData, CreateIntroductionTreeError>({
      path: `/routes/introduction/admin/trees`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Get a specific introduction tree
   *
   * @tags dbtn/module:introduction, dbtn/hasAuth
   * @name get_introduction_tree
   * @summary Get Introduction Tree
   * @request GET:/routes/introduction/admin/trees/{tree_id}
   */
  get_introduction_tree = ({ treeId, ...query }: GetIntroductionTreeParams, params: RequestParams = {}) =>
    this.request<GetIntroductionTreeData, GetIntroductionTreeError>({
      path: `/routes/introduction/admin/trees/${treeId}`,
      method: "GET",
      ...params,
    });

  /**
   * @description Update an introduction tree
   *
   * @tags dbtn/module:introduction, dbtn/hasAuth
   * @name update_introduction_tree
   * @summary Update Introduction Tree
   * @request PUT:/routes/introduction/admin/trees/{tree_id}
   */
  update_introduction_tree = (
    { treeId, ...query }: UpdateIntroductionTreeParams,
    data: IntroductionTreeUpdate,
    params: RequestParams = {},
  ) =>
    this.request<UpdateIntroductionTreeData, UpdateIntroductionTreeError>({
      path: `/routes/introduction/admin/trees/${treeId}`,
      method: "PUT",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Delete an introduction tree and all its related data
   *
   * @tags dbtn/module:introduction, dbtn/hasAuth
   * @name delete_introduction_tree
   * @summary Delete Introduction Tree
   * @request DELETE:/routes/introduction/admin/trees/{tree_id}
   */
  delete_introduction_tree = ({ treeId, ...query }: DeleteIntroductionTreeParams, params: RequestParams = {}) =>
    this.request<DeleteIntroductionTreeData, DeleteIntroductionTreeError>({
      path: `/routes/introduction/admin/trees/${treeId}`,
      method: "DELETE",
      ...params,
    });

  /**
   * @description Duplicate an introduction tree with all its nodes and options
   *
   * @tags dbtn/module:introduction, dbtn/hasAuth
   * @name duplicate_introduction_tree
   * @summary Duplicate Introduction Tree
   * @request POST:/routes/introduction/admin/trees/{tree_id}/duplicate
   */
  duplicate_introduction_tree = ({ treeId, ...query }: DuplicateIntroductionTreeParams, params: RequestParams = {}) =>
    this.request<DuplicateIntroductionTreeData, DuplicateIntroductionTreeError>({
      path: `/routes/introduction/admin/trees/${treeId}/duplicate`,
      method: "POST",
      ...params,
    });

  /**
   * @description List all nodes for an introduction tree
   *
   * @tags dbtn/module:introduction, dbtn/hasAuth
   * @name list_introduction_tree_nodes
   * @summary List Introduction Tree Nodes
   * @request GET:/routes/introduction/admin/trees/{tree_id}/nodes
   */
  list_introduction_tree_nodes = ({ treeId, ...query }: ListIntroductionTreeNodesParams, params: RequestParams = {}) =>
    this.request<ListIntroductionTreeNodesData, ListIntroductionTreeNodesError>({
      path: `/routes/introduction/admin/trees/${treeId}/nodes`,
      method: "GET",
      ...params,
    });

  /**
   * @description Create a new introduction tree node
   *
   * @tags dbtn/module:introduction, dbtn/hasAuth
   * @name create_introduction_tree_node
   * @summary Create Introduction Tree Node
   * @request POST:/routes/introduction/admin/trees/{tree_id}/nodes
   */
  create_introduction_tree_node = (
    { treeId, ...query }: CreateIntroductionTreeNodeParams,
    data: IntroductionTreeNodeCreate,
    params: RequestParams = {},
  ) =>
    this.request<CreateIntroductionTreeNodeData, CreateIntroductionTreeNodeError>({
      path: `/routes/introduction/admin/trees/${treeId}/nodes`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Update an introduction tree node
   *
   * @tags dbtn/module:introduction, dbtn/hasAuth
   * @name update_introduction_tree_node
   * @summary Update Introduction Tree Node
   * @request PUT:/routes/introduction/admin/nodes/{node_id}
   */
  update_introduction_tree_node = (
    { nodeId, ...query }: UpdateIntroductionTreeNodeParams,
    data: IntroductionTreeNodeUpdate,
    params: RequestParams = {},
  ) =>
    this.request<UpdateIntroductionTreeNodeData, UpdateIntroductionTreeNodeError>({
      path: `/routes/introduction/admin/nodes/${nodeId}`,
      method: "PUT",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Delete an introduction tree node
   *
   * @tags dbtn/module:introduction, dbtn/hasAuth
   * @name delete_introduction_tree_node
   * @summary Delete Introduction Tree Node
   * @request DELETE:/routes/introduction/admin/nodes/{node_id}
   */
  delete_introduction_tree_node = (
    { nodeId, ...query }: DeleteIntroductionTreeNodeParams,
    params: RequestParams = {},
  ) =>
    this.request<DeleteIntroductionTreeNodeData, DeleteIntroductionTreeNodeError>({
      path: `/routes/introduction/admin/nodes/${nodeId}`,
      method: "DELETE",
      ...params,
    });

  /**
   * @description Duplicate an introduction tree node with all its options
   *
   * @tags dbtn/module:introduction, dbtn/hasAuth
   * @name duplicate_introduction_tree_node
   * @summary Duplicate Introduction Tree Node
   * @request POST:/routes/introduction/admin/nodes/{node_id}/duplicate
   */
  duplicate_introduction_tree_node = (
    { nodeId, ...query }: DuplicateIntroductionTreeNodeParams,
    params: RequestParams = {},
  ) =>
    this.request<DuplicateIntroductionTreeNodeData, DuplicateIntroductionTreeNodeError>({
      path: `/routes/introduction/admin/nodes/${nodeId}/duplicate`,
      method: "POST",
      ...params,
    });

  /**
   * @description List all options for an introduction tree node
   *
   * @tags dbtn/module:introduction, dbtn/hasAuth
   * @name list_introduction_node_options
   * @summary List Introduction Node Options
   * @request GET:/routes/introduction/admin/nodes/{node_id}/options
   */
  list_introduction_node_options = (
    { nodeId, ...query }: ListIntroductionNodeOptionsParams,
    params: RequestParams = {},
  ) =>
    this.request<ListIntroductionNodeOptionsData, ListIntroductionNodeOptionsError>({
      path: `/routes/introduction/admin/nodes/${nodeId}/options`,
      method: "GET",
      ...params,
    });

  /**
   * @description Create a new option for an introduction tree node
   *
   * @tags dbtn/module:introduction, dbtn/hasAuth
   * @name create_introduction_node_option
   * @summary Create Introduction Node Option
   * @request POST:/routes/introduction/admin/nodes/{node_id}/options
   */
  create_introduction_node_option = (
    { nodeId, ...query }: CreateIntroductionNodeOptionParams,
    data: IntroductionNodeOptionCreate,
    params: RequestParams = {},
  ) =>
    this.request<CreateIntroductionNodeOptionData, CreateIntroductionNodeOptionError>({
      path: `/routes/introduction/admin/nodes/${nodeId}/options`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Update an introduction node option
   *
   * @tags dbtn/module:introduction, dbtn/hasAuth
   * @name update_introduction_node_option
   * @summary Update Introduction Node Option
   * @request PUT:/routes/introduction/admin/options/{option_id}
   */
  update_introduction_node_option = (
    { optionId, ...query }: UpdateIntroductionNodeOptionParams,
    data: IntroductionNodeOptionUpdate,
    params: RequestParams = {},
  ) =>
    this.request<UpdateIntroductionNodeOptionData, UpdateIntroductionNodeOptionError>({
      path: `/routes/introduction/admin/options/${optionId}`,
      method: "PUT",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Delete an introduction node option
   *
   * @tags dbtn/module:introduction, dbtn/hasAuth
   * @name delete_introduction_node_option
   * @summary Delete Introduction Node Option
   * @request DELETE:/routes/introduction/admin/options/{option_id}
   */
  delete_introduction_node_option = (
    { optionId, ...query }: DeleteIntroductionNodeOptionParams,
    params: RequestParams = {},
  ) =>
    this.request<DeleteIntroductionNodeOptionData, DeleteIntroductionNodeOptionError>({
      path: `/routes/introduction/admin/options/${optionId}`,
      method: "DELETE",
      ...params,
    });

  /**
   * @description List all active introduction trees for public use
   *
   * @tags dbtn/module:introduction, dbtn/hasAuth
   * @name list_active_introduction_trees
   * @summary List Active Introduction Trees
   * @request GET:/routes/introduction/trees
   */
  list_active_introduction_trees = (params: RequestParams = {}) =>
    this.request<ListActiveIntroductionTreesData, any>({
      path: `/routes/introduction/trees`,
      method: "GET",
      ...params,
    });

  /**
   * @description Get the starting node for an introduction tree - trigger brain regeneration
   *
   * @tags dbtn/module:introduction, dbtn/hasAuth
   * @name get_introduction_tree_start_node
   * @summary Get Introduction Tree Start Node
   * @request GET:/routes/introduction/trees/{tree_id}/start
   */
  get_introduction_tree_start_node = (
    { treeId, ...query }: GetIntroductionTreeStartNodeParams,
    params: RequestParams = {},
  ) =>
    this.request<GetIntroductionTreeStartNodeData, GetIntroductionTreeStartNodeError>({
      path: `/routes/introduction/trees/${treeId}/start`,
      method: "GET",
      ...params,
    });

  /**
   * @description Get a specific introduction node by its key within a tree
   *
   * @tags dbtn/module:introduction, dbtn/hasAuth
   * @name get_introduction_node_by_key
   * @summary Get Introduction Node By Key
   * @request GET:/routes/introduction/trees/{tree_id}/nodes/{node_key}
   */
  get_introduction_node_by_key = (
    { treeId, nodeKey, ...query }: GetIntroductionNodeByKeyParams,
    params: RequestParams = {},
  ) =>
    this.request<GetIntroductionNodeByKeyData, GetIntroductionNodeByKeyError>({
      path: `/routes/introduction/trees/${treeId}/nodes/${nodeKey}`,
      method: "GET",
      ...params,
    });

  /**
   * @description Navigate through an introduction tree based on user selection
   *
   * @tags dbtn/module:introduction, dbtn/hasAuth
   * @name navigate_introduction_tree
   * @summary Navigate Introduction Tree
   * @request POST:/routes/introduction/trees/{tree_id}/navigate
   */
  navigate_introduction_tree = (
    { treeId, ...query }: NavigateIntroductionTreeParams,
    data: IntroductionNavigationRequest,
    params: RequestParams = {},
  ) =>
    this.request<NavigateIntroductionTreeData, NavigateIntroductionTreeError>({
      path: `/routes/introduction/trees/${treeId}/navigate`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Process responses to a multi-question assessment and determine routing
   *
   * @tags dbtn/module:introduction, dbtn/hasAuth
   * @name process_introduction_multi_question_assessment
   * @summary Process Introduction Multi Question Assessment
   * @request POST:/routes/introduction/trees/{tree_id}/nodes/{node_key}/assess
   */
  process_introduction_multi_question_assessment = (
    { treeId, nodeKey, ...query }: ProcessIntroductionMultiQuestionAssessmentParams,
    data: MultiQuestionAssessmentRequest,
    params: RequestParams = {},
  ) =>
    this.request<ProcessIntroductionMultiQuestionAssessmentData, ProcessIntroductionMultiQuestionAssessmentError>({
      path: `/routes/introduction/trees/${treeId}/nodes/${nodeKey}/assess`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Get all form fields for a classification tree
   *
   * @tags dbtn/module:classification, dbtn/hasAuth
   * @name get_tree_form_fields
   * @summary Get Tree Form Fields
   * @request GET:/routes/classification/tree/{tree_id}/form-fields
   */
  get_tree_form_fields = ({ treeId, ...query }: GetTreeFormFieldsParams, params: RequestParams = {}) =>
    this.request<GetTreeFormFieldsData, GetTreeFormFieldsError>({
      path: `/routes/classification/tree/${treeId}/form-fields`,
      method: "GET",
      ...params,
    });

  /**
   * @description Create a new form field for a classification tree
   *
   * @tags dbtn/module:classification, dbtn/hasAuth
   * @name create_tree_form_field
   * @summary Create Tree Form Field
   * @request POST:/routes/classification/tree/{tree_id}/form-fields
   */
  create_tree_form_field = (
    { treeId, ...query }: CreateTreeFormFieldParams,
    data: TreeFormFieldCreate,
    params: RequestParams = {},
  ) =>
    this.request<CreateTreeFormFieldData, CreateTreeFormFieldError>({
      path: `/routes/classification/tree/${treeId}/form-fields`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Update a form field for a classification tree
   *
   * @tags dbtn/module:classification, dbtn/hasAuth
   * @name update_tree_form_field
   * @summary Update Tree Form Field
   * @request PUT:/routes/classification/tree/{tree_id}/form-fields/{field_id}
   */
  update_tree_form_field = (
    { treeId, fieldId, ...query }: UpdateTreeFormFieldParams,
    data: TreeFormFieldUpdate,
    params: RequestParams = {},
  ) =>
    this.request<UpdateTreeFormFieldData, UpdateTreeFormFieldError>({
      path: `/routes/classification/tree/${treeId}/form-fields/${fieldId}`,
      method: "PUT",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Delete a form field from a classification tree
   *
   * @tags dbtn/module:classification, dbtn/hasAuth
   * @name delete_tree_form_field
   * @summary Delete Tree Form Field
   * @request DELETE:/routes/classification/tree/{tree_id}/form-fields/{field_id}
   */
  delete_tree_form_field = ({ treeId, fieldId, ...query }: DeleteTreeFormFieldParams, params: RequestParams = {}) =>
    this.request<DeleteTreeFormFieldData, DeleteTreeFormFieldError>({
      path: `/routes/classification/tree/${treeId}/form-fields/${fieldId}`,
      method: "DELETE",
      ...params,
    });

  /**
   * @description List all classification trees for admin management
   *
   * @tags dbtn/module:classification, dbtn/hasAuth
   * @name list_classification_trees
   * @summary List Classification Trees
   * @request GET:/routes/classification/admin/trees
   */
  list_classification_trees = (params: RequestParams = {}) =>
    this.request<ListClassificationTreesData, any>({
      path: `/routes/classification/admin/trees`,
      method: "GET",
      ...params,
    });

  /**
   * @description Create a new classification tree
   *
   * @tags dbtn/module:classification, dbtn/hasAuth
   * @name create_classification_tree
   * @summary Create Classification Tree
   * @request POST:/routes/classification/admin/trees
   */
  create_classification_tree = (data: ClassificationTreeCreate, params: RequestParams = {}) =>
    this.request<CreateClassificationTreeData, CreateClassificationTreeError>({
      path: `/routes/classification/admin/trees`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Get a specific classification tree
   *
   * @tags dbtn/module:classification, dbtn/hasAuth
   * @name get_classification_tree
   * @summary Get Classification Tree
   * @request GET:/routes/classification/admin/trees/{tree_id}
   */
  get_classification_tree = ({ treeId, ...query }: GetClassificationTreeParams, params: RequestParams = {}) =>
    this.request<GetClassificationTreeData, GetClassificationTreeError>({
      path: `/routes/classification/admin/trees/${treeId}`,
      method: "GET",
      ...params,
    });

  /**
   * @description Update a classification tree
   *
   * @tags dbtn/module:classification, dbtn/hasAuth
   * @name update_classification_tree
   * @summary Update Classification Tree
   * @request PUT:/routes/classification/admin/trees/{tree_id}
   */
  update_classification_tree = (
    { treeId, ...query }: UpdateClassificationTreeParams,
    data: ClassificationTreeUpdate,
    params: RequestParams = {},
  ) =>
    this.request<UpdateClassificationTreeData, UpdateClassificationTreeError>({
      path: `/routes/classification/admin/trees/${treeId}`,
      method: "PUT",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Delete a classification tree and all its related data
   *
   * @tags dbtn/module:classification, dbtn/hasAuth
   * @name delete_classification_tree
   * @summary Delete Classification Tree
   * @request DELETE:/routes/classification/admin/trees/{tree_id}
   */
  delete_classification_tree = ({ treeId, ...query }: DeleteClassificationTreeParams, params: RequestParams = {}) =>
    this.request<DeleteClassificationTreeData, DeleteClassificationTreeError>({
      path: `/routes/classification/admin/trees/${treeId}`,
      method: "DELETE",
      ...params,
    });

  /**
   * @description Duplicate a classification tree with all its nodes and options
   *
   * @tags dbtn/module:classification, dbtn/hasAuth
   * @name duplicate_classification_tree
   * @summary Duplicate Classification Tree
   * @request POST:/routes/classification/admin/trees/{tree_id}/duplicate
   */
  duplicate_classification_tree = (
    { treeId, ...query }: DuplicateClassificationTreeParams,
    params: RequestParams = {},
  ) =>
    this.request<DuplicateClassificationTreeData, DuplicateClassificationTreeError>({
      path: `/routes/classification/admin/trees/${treeId}/duplicate`,
      method: "POST",
      ...params,
    });

  /**
   * @description List all nodes for a classification tree
   *
   * @tags dbtn/module:classification, dbtn/hasAuth
   * @name list_tree_nodes
   * @summary List Tree Nodes
   * @request GET:/routes/classification/admin/trees/{tree_id}/nodes
   */
  list_tree_nodes = ({ treeId, ...query }: ListTreeNodesParams, params: RequestParams = {}) =>
    this.request<ListTreeNodesData, ListTreeNodesError>({
      path: `/routes/classification/admin/trees/${treeId}/nodes`,
      method: "GET",
      ...params,
    });

  /**
   * @description Create a new tree node
   *
   * @tags dbtn/module:classification, dbtn/hasAuth
   * @name create_tree_node
   * @summary Create Tree Node
   * @request POST:/routes/classification/admin/trees/{tree_id}/nodes
   */
  create_tree_node = ({ treeId, ...query }: CreateTreeNodeParams, data: TreeNodeCreate, params: RequestParams = {}) =>
    this.request<CreateTreeNodeData, CreateTreeNodeError>({
      path: `/routes/classification/admin/trees/${treeId}/nodes`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Update a tree node
   *
   * @tags dbtn/module:classification, dbtn/hasAuth
   * @name update_tree_node
   * @summary Update Tree Node
   * @request PUT:/routes/classification/admin/trees/{tree_id}/nodes/{node_id}
   */
  update_tree_node = (
    { treeId, nodeId, ...query }: UpdateTreeNodeParams,
    data: TreeNodeUpdate,
    params: RequestParams = {},
  ) =>
    this.request<UpdateTreeNodeData, UpdateTreeNodeError>({
      path: `/routes/classification/admin/trees/${treeId}/nodes/${nodeId}`,
      method: "PUT",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Delete a tree node
   *
   * @tags dbtn/module:classification, dbtn/hasAuth
   * @name delete_tree_node
   * @summary Delete Tree Node
   * @request DELETE:/routes/classification/admin/nodes/{node_id}
   */
  delete_tree_node = ({ nodeId, ...query }: DeleteTreeNodeParams, params: RequestParams = {}) =>
    this.request<DeleteTreeNodeData, DeleteTreeNodeError>({
      path: `/routes/classification/admin/nodes/${nodeId}`,
      method: "DELETE",
      ...params,
    });

  /**
   * @description List all options for a tree node
   *
   * @tags dbtn/module:classification, dbtn/hasAuth
   * @name list_node_options
   * @summary List Node Options
   * @request GET:/routes/classification/admin/nodes/{node_id}/options
   */
  list_node_options = ({ nodeId, ...query }: ListNodeOptionsParams, params: RequestParams = {}) =>
    this.request<ListNodeOptionsData, ListNodeOptionsError>({
      path: `/routes/classification/admin/nodes/${nodeId}/options`,
      method: "GET",
      ...params,
    });

  /**
   * @description Create a new node option
   *
   * @tags dbtn/module:classification, dbtn/hasAuth
   * @name create_node_option
   * @summary Create Node Option
   * @request POST:/routes/classification/admin/nodes/{node_id}/options
   */
  create_node_option = (
    { nodeId, ...query }: CreateNodeOptionParams,
    data: NodeOptionCreate,
    params: RequestParams = {},
  ) =>
    this.request<CreateNodeOptionData, CreateNodeOptionError>({
      path: `/routes/classification/admin/nodes/${nodeId}/options`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Delete a node option
   *
   * @tags dbtn/module:classification, dbtn/hasAuth
   * @name delete_node_option
   * @summary Delete Node Option
   * @request DELETE:/routes/classification/admin/options/{option_id}
   */
  delete_node_option = ({ optionId, ...query }: DeleteNodeOptionParams, params: RequestParams = {}) =>
    this.request<DeleteNodeOptionData, DeleteNodeOptionError>({
      path: `/routes/classification/admin/options/${optionId}`,
      method: "DELETE",
      ...params,
    });

  /**
   * @description Update a node option
   *
   * @tags dbtn/module:classification, dbtn/hasAuth
   * @name update_node_option
   * @summary Update Node Option
   * @request PUT:/routes/classification/admin/options/{option_id}
   */
  update_node_option = (
    { optionId, ...query }: UpdateNodeOptionParams,
    data: NodeOptionUpdate,
    params: RequestParams = {},
  ) =>
    this.request<UpdateNodeOptionData, UpdateNodeOptionError>({
      path: `/routes/classification/admin/options/${optionId}`,
      method: "PUT",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description List all outcomes across all classification trees
   *
   * @tags dbtn/module:classification, dbtn/hasAuth
   * @name list_all_classification_outcomes
   * @summary List All Classification Outcomes
   * @request GET:/routes/classification/admin/outcomes
   */
  list_all_classification_outcomes = (params: RequestParams = {}) =>
    this.request<ListAllClassificationOutcomesData, any>({
      path: `/routes/classification/admin/outcomes`,
      method: "GET",
      ...params,
    });

  /**
   * @description Create a new tree-independent classification outcome
   *
   * @tags dbtn/module:classification, dbtn/hasAuth
   * @name create_tree_independent_outcome
   * @summary Create Tree Independent Outcome
   * @request POST:/routes/classification/admin/outcomes
   */
  create_tree_independent_outcome = (data: ClassificationOutcomeCreate, params: RequestParams = {}) =>
    this.request<CreateTreeIndependentOutcomeData, CreateTreeIndependentOutcomeError>({
      path: `/routes/classification/admin/outcomes`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description List all outcomes for a classification tree
   *
   * @tags dbtn/module:classification, dbtn/hasAuth
   * @name list_classification_outcomes
   * @summary List Classification Outcomes
   * @request GET:/routes/classification/admin/trees/{tree_id}/outcomes
   */
  list_classification_outcomes = ({ treeId, ...query }: ListClassificationOutcomesParams, params: RequestParams = {}) =>
    this.request<ListClassificationOutcomesData, ListClassificationOutcomesError>({
      path: `/routes/classification/admin/trees/${treeId}/outcomes`,
      method: "GET",
      ...params,
    });

  /**
   * @description Create a new classification outcome for a tree
   *
   * @tags dbtn/module:classification, dbtn/hasAuth
   * @name create_classification_outcome
   * @summary Create Classification Outcome
   * @request POST:/routes/classification/admin/trees/{tree_id}/outcomes
   */
  create_classification_outcome = (
    { treeId, ...query }: CreateClassificationOutcomeParams,
    data: ClassificationOutcomeCreate,
    params: RequestParams = {},
  ) =>
    this.request<CreateClassificationOutcomeData, CreateClassificationOutcomeError>({
      path: `/routes/classification/admin/trees/${treeId}/outcomes`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Update a classification outcome
   *
   * @tags dbtn/module:classification, dbtn/hasAuth
   * @name update_classification_outcome
   * @summary Update Classification Outcome
   * @request PUT:/routes/classification/admin/outcomes/{outcome_id}
   */
  update_classification_outcome = (
    { outcomeId, ...query }: UpdateClassificationOutcomeParams,
    data: ClassificationOutcomeUpdate,
    params: RequestParams = {},
  ) =>
    this.request<UpdateClassificationOutcomeData, UpdateClassificationOutcomeError>({
      path: `/routes/classification/admin/outcomes/${outcomeId}`,
      method: "PUT",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Delete a classification outcome
   *
   * @tags dbtn/module:classification, dbtn/hasAuth
   * @name delete_classification_outcome
   * @summary Delete Classification Outcome
   * @request DELETE:/routes/classification/admin/outcomes/{outcome_id}
   */
  delete_classification_outcome = (
    { outcomeId, ...query }: DeleteClassificationOutcomeParams,
    params: RequestParams = {},
  ) =>
    this.request<DeleteClassificationOutcomeData, DeleteClassificationOutcomeError>({
      path: `/routes/classification/admin/outcomes/${outcomeId}`,
      method: "DELETE",
      ...params,
    });

  /**
   * @description List all active classification trees for public use
   *
   * @tags dbtn/module:classification, dbtn/hasAuth
   * @name list_active_trees
   * @summary List Active Trees
   * @request GET:/routes/classification/trees
   */
  list_active_trees = (params: RequestParams = {}) =>
    this.request<ListActiveTreesData, any>({
      path: `/routes/classification/trees`,
      method: "GET",
      ...params,
    });

  /**
   * @description Get the starting node for a classification tree
   *
   * @tags dbtn/module:classification, dbtn/hasAuth
   * @name get_tree_start_node
   * @summary Get Tree Start Node
   * @request GET:/routes/classification/trees/{tree_id}/start
   */
  get_tree_start_node = ({ treeId, ...query }: GetTreeStartNodeParams, params: RequestParams = {}) =>
    this.request<GetTreeStartNodeData, GetTreeStartNodeError>({
      path: `/routes/classification/trees/${treeId}/start`,
      method: "GET",
      ...params,
    });

  /**
   * @description Get a specific node by its key within a tree
   *
   * @tags dbtn/module:classification, dbtn/hasAuth
   * @name get_node_by_key
   * @summary Get Node By Key
   * @request GET:/routes/classification/trees/{tree_id}/nodes/{node_key}
   */
  get_node_by_key = ({ treeId, nodeKey, ...query }: GetNodeByKeyParams, params: RequestParams = {}) =>
    this.request<GetNodeByKeyData, GetNodeByKeyError>({
      path: `/routes/classification/trees/${treeId}/nodes/${nodeKey}`,
      method: "GET",
      ...params,
    });

  /**
   * @description Navigate to the next node based on selected option
   *
   * @tags dbtn/module:classification, dbtn/hasAuth
   * @name navigate_tree
   * @summary Navigate Tree
   * @request POST:/routes/classification/trees/{tree_id}/navigate
   */
  navigate_tree = ({ treeId, ...query }: NavigateTreeParams, data: NavigationRequest, params: RequestParams = {}) =>
    this.request<NavigateTreeData, NavigateTreeError>({
      path: `/routes/classification/trees/${treeId}/navigate`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Process responses to a multi-question assessment and determine routing
   *
   * @tags dbtn/module:classification, dbtn/hasAuth
   * @name process_classification_multi_question_assessment
   * @summary Process Classification Multi Question Assessment
   * @request POST:/routes/classification/trees/{tree_id}/nodes/{node_key}/assess
   */
  process_classification_multi_question_assessment = (
    { treeId, nodeKey, ...query }: ProcessClassificationMultiQuestionAssessmentParams,
    data: MultiQuestionAssessmentRequest,
    params: RequestParams = {},
  ) =>
    this.request<ProcessClassificationMultiQuestionAssessmentData, ProcessClassificationMultiQuestionAssessmentError>({
      path: `/routes/classification/trees/${treeId}/nodes/${nodeKey}/assess`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Search sanctions lists for compliance screening
   *
   * @tags dbtn/module:sanctions_search, dbtn/hasAuth
   * @name search_sanctions
   * @summary Search Sanctions
   * @request POST:/routes/sanctions/search
   */
  search_sanctions = (data: SanctionsSearchRequest, params: RequestParams = {}) =>
    this.request<SearchSanctionsData, SearchSanctionsError>({
      path: `/routes/sanctions/search`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Get detailed information about a specific sanctioned entity
   *
   * @tags dbtn/module:sanctions_search, dbtn/hasAuth
   * @name get_sanctions_search_entity
   * @summary Get Sanctions Search Entity
   * @request GET:/routes/entity/{entity_id}
   */
  get_sanctions_search_entity = ({ entityId, ...query }: GetSanctionsSearchEntityParams, params: RequestParams = {}) =>
    this.request<GetSanctionsSearchEntityData, GetSanctionsSearchEntityError>({
      path: `/routes/entity/${entityId}`,
      method: "GET",
      ...params,
    });

  /**
   * @description Get list of available sanctions jurisdictions
   *
   * @tags dbtn/module:sanctions_search, dbtn/hasAuth
   * @name get_sanctions_jurisdictions
   * @summary Get Sanctions Jurisdictions
   * @request GET:/routes/jurisdictions
   */
  get_sanctions_jurisdictions = (params: RequestParams = {}) =>
    this.request<GetSanctionsJurisdictionsData, any>({
      path: `/routes/jurisdictions`,
      method: "GET",
      ...params,
    });

  /**
   * @description Get list of available sanctions programs
   *
   * @tags dbtn/module:sanctions_search, dbtn/hasAuth
   * @name get_sanctions_programs
   * @summary Get Sanctions Programs
   * @request GET:/routes/programs
   */
  get_sanctions_programs = (params: RequestParams = {}) =>
    this.request<GetSanctionsProgramsData, any>({
      path: `/routes/programs`,
      method: "GET",
      ...params,
    });

  /**
   * @description Get list of available entity types
   *
   * @tags dbtn/module:sanctions_search, dbtn/hasAuth
   * @name get_entity_types
   * @summary Get Entity Types
   * @request GET:/routes/entity-types
   */
  get_entity_types = (params: RequestParams = {}) =>
    this.request<GetEntityTypesData, any>({
      path: `/routes/entity-types`,
      method: "GET",
      ...params,
    });

  /**
   * @description Get list of available risk levels for sanctions
   *
   * @tags dbtn/module:sanctions_search, dbtn/hasAuth
   * @name get_risk_levels
   * @summary Get Risk Levels
   * @request GET:/routes/sanctions/risk-levels
   */
  get_risk_levels = (params: RequestParams = {}) =>
    this.request<GetRiskLevelsData, any>({
      path: `/routes/sanctions/risk-levels`,
      method: "GET",
      ...params,
    });

  /**
   * @description Get statistics for sanctions lists overview
   *
   * @tags dbtn/module:sanctions_list_management, dbtn/hasAuth
   * @name get_sanctions_list_stats
   * @summary Get Sanctions List Stats
   * @request GET:/routes/sanctions-lists/stats
   */
  get_sanctions_list_stats = (params: RequestParams = {}) =>
    this.request<GetSanctionsListStatsData, any>({
      path: `/routes/sanctions-lists/stats`,
      method: "GET",
      ...params,
    });

  /**
   * @description List all sanctions lists with filtering
   *
   * @tags dbtn/module:sanctions_list_management, dbtn/hasAuth
   * @name list_sanctions_lists
   * @summary List Sanctions Lists
   * @request GET:/routes/sanctions-lists/lists
   */
  list_sanctions_lists = (query: ListSanctionsListsParams, params: RequestParams = {}) =>
    this.request<ListSanctionsListsData, ListSanctionsListsError>({
      path: `/routes/sanctions-lists/lists`,
      method: "GET",
      query: query,
      ...params,
    });

  /**
   * @description Create a new sanctions list
   *
   * @tags dbtn/module:sanctions_list_management, dbtn/hasAuth
   * @name create_sanctions_list
   * @summary Create Sanctions List
   * @request POST:/routes/sanctions-lists/lists
   */
  create_sanctions_list = (data: SanctionsListCreate, params: RequestParams = {}) =>
    this.request<CreateSanctionsListData, CreateSanctionsListError>({
      path: `/routes/sanctions-lists/lists`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Get a specific sanctions list by ID
   *
   * @tags dbtn/module:sanctions_list_management, dbtn/hasAuth
   * @name get_sanctions_list
   * @summary Get Sanctions List
   * @request GET:/routes/sanctions-lists/lists/{list_id}
   */
  get_sanctions_list = ({ listId, ...query }: GetSanctionsListParams, params: RequestParams = {}) =>
    this.request<GetSanctionsListData, GetSanctionsListError>({
      path: `/routes/sanctions-lists/lists/${listId}`,
      method: "GET",
      ...params,
    });

  /**
   * @description Update an existing sanctions list
   *
   * @tags dbtn/module:sanctions_list_management, dbtn/hasAuth
   * @name update_sanctions_list
   * @summary Update Sanctions List
   * @request PUT:/routes/sanctions-lists/lists/{list_id}
   */
  update_sanctions_list = (
    { listId, ...query }: UpdateSanctionsListParams,
    data: SanctionsListUpdate,
    params: RequestParams = {},
  ) =>
    this.request<UpdateSanctionsListData, UpdateSanctionsListError>({
      path: `/routes/sanctions-lists/lists/${listId}`,
      method: "PUT",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Delete a sanctions list and all its entries
   *
   * @tags dbtn/module:sanctions_list_management, dbtn/hasAuth
   * @name delete_sanctions_list
   * @summary Delete Sanctions List
   * @request DELETE:/routes/sanctions-lists/lists/{list_id}
   */
  delete_sanctions_list = ({ listId, ...query }: DeleteSanctionsListParams, params: RequestParams = {}) =>
    this.request<DeleteSanctionsListData, DeleteSanctionsListError>({
      path: `/routes/sanctions-lists/lists/${listId}`,
      method: "DELETE",
      ...params,
    });

  /**
   * @description Get entries for a specific sanctions list
   *
   * @tags dbtn/module:sanctions_list_management, dbtn/hasAuth
   * @name get_sanctions_list_entries
   * @summary Get Sanctions List Entries
   * @request GET:/routes/sanctions-lists/lists/{list_id}/entries
   */
  get_sanctions_list_entries = ({ listId, ...query }: GetSanctionsListEntriesParams, params: RequestParams = {}) =>
    this.request<GetSanctionsListEntriesData, GetSanctionsListEntriesError>({
      path: `/routes/sanctions-lists/lists/${listId}/entries`,
      method: "GET",
      query: query,
      ...params,
    });

  /**
   * @description Add a new entry to a sanctions list
   *
   * @tags dbtn/module:sanctions_list_management, dbtn/hasAuth
   * @name create_sanctions_list_entry
   * @summary Create Sanctions List Entry
   * @request POST:/routes/sanctions-lists/lists/{list_id}/entries
   */
  create_sanctions_list_entry = (
    { listId, ...query }: CreateSanctionsListEntryParams,
    data: SanctionsListEntryCreate,
    params: RequestParams = {},
  ) =>
    this.request<CreateSanctionsListEntryData, CreateSanctionsListEntryError>({
      path: `/routes/sanctions-lists/lists/${listId}/entries`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Bulk import entries into a sanctions list
   *
   * @tags dbtn/module:sanctions_list_management, dbtn/hasAuth
   * @name bulk_import_entries
   * @summary Bulk Import Entries
   * @request POST:/routes/sanctions-lists/lists/{list_id}/bulk-import
   */
  bulk_import_entries = (
    { listId, ...query }: BulkImportEntriesParams,
    data: AppApisSanctionsListManagementBulkImportRequest,
    params: RequestParams = {},
  ) =>
    this.request<BulkImportEntriesData, BulkImportEntriesError>({
      path: `/routes/sanctions-lists/lists/${listId}/bulk-import`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Get available list types
   *
   * @tags dbtn/module:sanctions_list_management, dbtn/hasAuth
   * @name get_list_types
   * @summary Get List Types
   * @request GET:/routes/sanctions-lists/list-types
   */
  get_list_types = (params: RequestParams = {}) =>
    this.request<GetListTypesData, any>({
      path: `/routes/sanctions-lists/list-types`,
      method: "GET",
      ...params,
    });

  /**
   * @description Import sanctions from UN Security Council XML file
   *
   * @tags dbtn/module:sanctions_list_management, dbtn/hasAuth
   * @name import_xml_sanctions
   * @summary Import Xml Sanctions
   * @request POST:/routes/sanctions-lists/import-xml
   */
  import_xml_sanctions = (data: BodyImportXmlSanctions, params: RequestParams = {}) =>
    this.request<ImportXmlSanctionsData, ImportXmlSanctionsError>({
      path: `/routes/sanctions-lists/import-xml`,
      method: "POST",
      body: data,
      type: ContentType.FormData,
      ...params,
    });

  /**
   * @description Get comprehensive pricing analytics across all components and packages
   *
   * @tags dbtn/module:pricing_analytics, dbtn/hasAuth
   * @name get_comprehensive_pricing_analytics
   * @summary Get Comprehensive Pricing Analytics
   * @request GET:/routes/comprehensive-analytics
   */
  get_comprehensive_pricing_analytics = (params: RequestParams = {}) =>
    this.request<GetComprehensivePricingAnalyticsData, any>({
      path: `/routes/comprehensive-analytics`,
      method: "GET",
      ...params,
    });

  /**
   * @description Bulk update pricing for multiple components
   *
   * @tags dbtn/module:pricing_analytics, dbtn/hasAuth
   * @name bulk_update_pricing
   * @summary Bulk Update Pricing
   * @request POST:/routes/bulk-pricing-update
   */
  bulk_update_pricing = (data: BulkUpdatePricingPayload, params: RequestParams = {}) =>
    this.request<BulkUpdatePricingData, BulkUpdatePricingError>({
      path: `/routes/bulk-pricing-update`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Get audit log of pricing changes
   *
   * @tags dbtn/module:pricing_analytics, dbtn/hasAuth
   * @name get_pricing_audit_log
   * @summary Get Pricing Audit Log
   * @request GET:/routes/pricing-audit-log
   */
  get_pricing_audit_log = (query: GetPricingAuditLogParams, params: RequestParams = {}) =>
    this.request<GetPricingAuditLogData, GetPricingAuditLogError>({
      path: `/routes/pricing-audit-log`,
      method: "GET",
      query: query,
      ...params,
    });

  /**
   * @description Save user profile with company integration
   *
   * @tags dbtn/module:enterprise_profile, dbtn/hasAuth
   * @name save_enhanced_user_profile
   * @summary Save Enhanced User Profile
   * @request POST:/routes/enterprise-profile/save-enhanced-profile
   */
  save_enhanced_user_profile = (data: EnhancedUserProfileRequest, params: RequestParams = {}) =>
    this.request<SaveEnhancedUserProfileData, SaveEnhancedUserProfileError>({
      path: `/routes/enterprise-profile/save-enhanced-profile`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Get user profile with company information
   *
   * @tags dbtn/module:enterprise_profile, dbtn/hasAuth
   * @name get_enhanced_user_profile
   * @summary Get Enhanced User Profile
   * @request GET:/routes/enterprise-profile/enhanced-profile
   */
  get_enhanced_user_profile = (params: RequestParams = {}) =>
    this.request<GetEnhancedUserProfileData, any>({
      path: `/routes/enterprise-profile/enhanced-profile`,
      method: "GET",
      ...params,
    });

  /**
   * @description Get audit logs with filtering
   *
   * @tags dbtn/module:enterprise_profile, dbtn/hasAuth
   * @name get_audit_logs
   * @summary Get Audit Logs
   * @request GET:/routes/enterprise-profile/audit-logs
   */
  get_audit_logs = (query: GetAuditLogsParams, params: RequestParams = {}) =>
    this.request<GetAuditLogsData, GetAuditLogsError>({
      path: `/routes/enterprise-profile/audit-logs`,
      method: "GET",
      query: query,
      ...params,
    });

  /**
   * @description Get user activity summary for compliance monitoring
   *
   * @tags dbtn/module:enterprise_profile, dbtn/hasAuth
   * @name get_user_activity_summary
   * @summary Get User Activity Summary
   * @request GET:/routes/enterprise-profile/user-activity-summary
   */
  get_user_activity_summary = (query: GetUserActivitySummaryParams, params: RequestParams = {}) =>
    this.request<GetUserActivitySummaryData, GetUserActivitySummaryError>({
      path: `/routes/enterprise-profile/user-activity-summary`,
      method: "GET",
      query: query,
      ...params,
    });

  /**
   * @description Log a custom audit action
   *
   * @tags dbtn/module:enterprise_profile, dbtn/hasAuth
   * @name log_custom_action
   * @summary Log Custom Action
   * @request POST:/routes/enterprise-profile/log-custom-action
   */
  log_custom_action = (query: LogCustomActionParams, data: LogCustomActionPayload, params: RequestParams = {}) =>
    this.request<LogCustomActionData, LogCustomActionError>({
      path: `/routes/enterprise-profile/log-custom-action`,
      method: "POST",
      query: query,
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Update customer/user information in the database
   *
   * @tags dbtn/module:user_management, dbtn/hasAuth
   * @name update_user
   * @summary Update User
   * @request PUT:/routes/admin/users/{customer_id}
   */
  update_user = ({ customerId, ...query }: UpdateUserParams, data: UpdateUserRequest, params: RequestParams = {}) =>
    this.request<UpdateUserData, UpdateUserError>({
      path: `/routes/admin/users/${customerId}`,
      method: "PUT",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Delete a customer/user from the database
   *
   * @tags dbtn/module:user_management, dbtn/hasAuth
   * @name delete_user
   * @summary Delete User
   * @request DELETE:/routes/admin/users/{customer_id}
   */
  delete_user = ({ customerId, ...query }: DeleteUserParams, params: RequestParams = {}) =>
    this.request<DeleteUserData, DeleteUserError>({
      path: `/routes/admin/users/${customerId}`,
      method: "DELETE",
      ...params,
    });

  /**
   * @description Create a new customer/user in the database
   *
   * @tags dbtn/module:user_management, dbtn/hasAuth
   * @name create_user
   * @summary Create User
   * @request POST:/routes/admin/users
   */
  create_user = (data: CreateUserRequest, params: RequestParams = {}) =>
    this.request<CreateUserData, CreateUserError>({
      path: `/routes/admin/users`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Get cross-references for a specific document
   *
   * @tags dbtn/module:cross_references, dbtn/hasAuth
   * @name get_document_cross_references
   * @summary Get Document Cross References
   * @request GET:/routes/cross-references/document/{document_id}
   */
  get_document_cross_references = (
    { documentId, ...query }: GetDocumentCrossReferencesParams,
    params: RequestParams = {},
  ) =>
    this.request<GetDocumentCrossReferencesData, GetDocumentCrossReferencesError>({
      path: `/routes/cross-references/document/${documentId}`,
      method: "GET",
      ...params,
    });

  /**
   * @description Process a document to extract and link cross-references
   *
   * @tags dbtn/module:cross_references, dbtn/hasAuth
   * @name process_document_references
   * @summary Process Document References
   * @request POST:/routes/cross-references/process
   */
  process_document_references = (data: ProcessReferenceRequest, params: RequestParams = {}) =>
    this.request<ProcessDocumentReferencesData, ProcessDocumentReferencesError>({
      path: `/routes/cross-references/process`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Extract regulatory references from text
   *
   * @tags dbtn/module:cross_references, dbtn/hasAuth
   * @name extract_references_from_text
   * @summary Extract References From Text
   * @request POST:/routes/cross-references/extract
   */
  extract_references_from_text = (data: ExtractReferencesRequest, params: RequestParams = {}) =>
    this.request<ExtractReferencesFromTextData, ExtractReferencesFromTextError>({
      path: `/routes/cross-references/extract`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Rebuild cross-references for a specific document
   *
   * @tags dbtn/module:cross_references, dbtn/hasAuth
   * @name rebuild_document_cross_references
   * @summary Rebuild Document Cross References
   * @request POST:/routes/cross-references/rebuild/{document_id}
   */
  rebuild_document_cross_references = (
    { documentId, ...query }: RebuildDocumentCrossReferencesParams,
    params: RequestParams = {},
  ) =>
    this.request<RebuildDocumentCrossReferencesData, RebuildDocumentCrossReferencesError>({
      path: `/routes/cross-references/rebuild/${documentId}`,
      method: "POST",
      ...params,
    });

  /**
   * @description Rebuild cross-references for all documents (admin only)
   *
   * @tags dbtn/module:cross_references, dbtn/hasAuth
   * @name rebuild_all_cross_references
   * @summary Rebuild All Cross References
   * @request POST:/routes/cross-references/rebuild-all
   */
  rebuild_all_cross_references = (params: RequestParams = {}) =>
    this.request<RebuildAllCrossReferencesData, any>({
      path: `/routes/cross-references/rebuild-all`,
      method: "POST",
      ...params,
    });

  /**
   * @description Get statistics about cross-references in the system
   *
   * @tags dbtn/module:cross_references, dbtn/hasAuth
   * @name get_cross_reference_stats
   * @summary Get Cross Reference Stats
   * @request GET:/routes/cross-references/stats
   */
  get_cross_reference_stats = (params: RequestParams = {}) =>
    this.request<GetCrossReferenceStatsData, any>({
      path: `/routes/cross-references/stats`,
      method: "GET",
      ...params,
    });

  /**
   * @description Get all saved searches for the current user
   *
   * @tags dbtn/module:saved_searches, dbtn/hasAuth
   * @name list_saved_searches
   * @summary List Saved Searches
   * @request GET:/routes/saved-searches
   */
  list_saved_searches = (params: RequestParams = {}) =>
    this.request<ListSavedSearchesData, any>({
      path: `/routes/saved-searches`,
      method: "GET",
      ...params,
    });

  /**
   * @description Create a new saved search with optional alerts
   *
   * @tags dbtn/module:saved_searches, dbtn/hasAuth
   * @name create_saved_search
   * @summary Create Saved Search
   * @request POST:/routes/saved-searches
   */
  create_saved_search = (data: SavedSearchRequest, params: RequestParams = {}) =>
    this.request<CreateSavedSearchData, CreateSavedSearchError>({
      path: `/routes/saved-searches`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Get a specific saved search
   *
   * @tags dbtn/module:saved_searches, dbtn/hasAuth
   * @name get_saved_search
   * @summary Get Saved Search
   * @request GET:/routes/saved-searches/{search_id}
   */
  get_saved_search = ({ searchId, ...query }: GetSavedSearchParams, params: RequestParams = {}) =>
    this.request<GetSavedSearchData, GetSavedSearchError>({
      path: `/routes/saved-searches/${searchId}`,
      method: "GET",
      ...params,
    });

  /**
   * @description Update a saved search
   *
   * @tags dbtn/module:saved_searches, dbtn/hasAuth
   * @name update_saved_search
   * @summary Update Saved Search
   * @request PUT:/routes/saved-searches/{search_id}
   */
  update_saved_search = (
    { searchId, ...query }: UpdateSavedSearchParams,
    data: SavedSearchUpdate,
    params: RequestParams = {},
  ) =>
    this.request<UpdateSavedSearchData, UpdateSavedSearchError>({
      path: `/routes/saved-searches/${searchId}`,
      method: "PUT",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Delete a saved search
   *
   * @tags dbtn/module:saved_searches, dbtn/hasAuth
   * @name delete_saved_search
   * @summary Delete Saved Search
   * @request DELETE:/routes/saved-searches/{search_id}
   */
  delete_saved_search = ({ searchId, ...query }: DeleteSavedSearchParams, params: RequestParams = {}) =>
    this.request<DeleteSavedSearchData, DeleteSavedSearchError>({
      path: `/routes/saved-searches/${searchId}`,
      method: "DELETE",
      ...params,
    });

  /**
   * @description Execute a saved search and return results
   *
   * @tags dbtn/module:saved_searches, dbtn/hasAuth
   * @name run_saved_search
   * @summary Run Saved Search
   * @request POST:/routes/saved-searches/{search_id}/run
   */
  run_saved_search = ({ searchId, ...query }: RunSavedSearchParams, params: RequestParams = {}) =>
    this.request<RunSavedSearchData, RunSavedSearchError>({
      path: `/routes/saved-searches/${searchId}/run`,
      method: "POST",
      ...params,
    });

  /**
   * @description Get alert history for a saved search
   *
   * @tags dbtn/module:saved_searches, dbtn/hasAuth
   * @name get_search_alerts
   * @summary Get Search Alerts
   * @request GET:/routes/saved-searches/{search_id}/alerts
   */
  get_search_alerts = ({ searchId, ...query }: GetSearchAlertsParams, params: RequestParams = {}) =>
    this.request<GetSearchAlertsData, GetSearchAlertsError>({
      path: `/routes/saved-searches/${searchId}/alerts`,
      method: "GET",
      ...params,
    });

  /**
   * @description Create a new company (automatically makes user the owner)
   *
   * @tags dbtn/module:team_management, dbtn/hasAuth
   * @name create_company
   * @summary Create Company
   * @request POST:/routes/team-management/create-company
   */
  create_company = (data: CreateCompanyRequest, params: RequestParams = {}) =>
    this.request<CreateCompanyData, CreateCompanyError>({
      path: `/routes/team-management/create-company`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Get all companies where user is a member
   *
   * @tags dbtn/module:team_management, dbtn/hasAuth
   * @name get_my_companies
   * @summary Get My Companies
   * @request GET:/routes/team-management/my-companies
   */
  get_my_companies = (params: RequestParams = {}) =>
    this.request<GetMyCompaniesData, any>({
      path: `/routes/team-management/my-companies`,
      method: "GET",
      ...params,
    });

  /**
   * @description Invite a new team member to the company
   *
   * @tags dbtn/module:team_management, dbtn/hasAuth
   * @name invite_team_member
   * @summary Invite Team Member
   * @request POST:/routes/team-management/companies/{company_id}/invite
   */
  invite_team_member = (
    { companyId, ...query }: InviteTeamMemberParams,
    data: InviteUserRequest,
    params: RequestParams = {},
  ) =>
    this.request<InviteTeamMemberData, InviteTeamMemberError>({
      path: `/routes/team-management/companies/${companyId}/invite`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Get all team members for a company
   *
   * @tags dbtn/module:team_management, dbtn/hasAuth
   * @name get_team_members
   * @summary Get Team Members
   * @request GET:/routes/team-management/companies/{company_id}/members
   */
  get_team_members = ({ companyId, ...query }: GetTeamMembersParams, params: RequestParams = {}) =>
    this.request<GetTeamMembersData, GetTeamMembersError>({
      path: `/routes/team-management/companies/${companyId}/members`,
      method: "GET",
      ...params,
    });

  /**
   * @description Get all pending invitations for a company
   *
   * @tags dbtn/module:team_management, dbtn/hasAuth
   * @name get_pending_invitations
   * @summary Get Pending Invitations
   * @request GET:/routes/team-management/companies/{company_id}/invitations
   */
  get_pending_invitations = ({ companyId, ...query }: GetPendingInvitationsParams, params: RequestParams = {}) =>
    this.request<GetPendingInvitationsData, GetPendingInvitationsError>({
      path: `/routes/team-management/companies/${companyId}/invitations`,
      method: "GET",
      ...params,
    });

  /**
   * @description Update a team member's role
   *
   * @tags dbtn/module:team_management, dbtn/hasAuth
   * @name update_member_role
   * @summary Update Member Role
   * @request PUT:/routes/team-management/companies/{company_id}/members/{member_id}/role
   */
  update_member_role = (
    { companyId, memberId, ...query }: UpdateMemberRoleParams,
    data: UpdateMemberRoleRequest,
    params: RequestParams = {},
  ) =>
    this.request<UpdateMemberRoleData, UpdateMemberRoleError>({
      path: `/routes/team-management/companies/${companyId}/members/${memberId}/role`,
      method: "PUT",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Remove a team member from the company
   *
   * @tags dbtn/module:team_management, dbtn/hasAuth
   * @name remove_team_member
   * @summary Remove Team Member
   * @request DELETE:/routes/team-management/companies/{company_id}/members/{member_id}
   */
  remove_team_member = ({ companyId, memberId, ...query }: RemoveTeamMemberParams, params: RequestParams = {}) =>
    this.request<RemoveTeamMemberData, RemoveTeamMemberError>({
      path: `/routes/team-management/companies/${companyId}/members/${memberId}`,
      method: "DELETE",
      ...params,
    });

  /**
   * @description Get all available role definitions
   *
   * @tags dbtn/module:team_management, dbtn/hasAuth
   * @name get_role_definitions
   * @summary Get Role Definitions
   * @request GET:/routes/team-management/role-definitions
   */
  get_role_definitions = (params: RequestParams = {}) =>
    this.request<GetRoleDefinitionsData, any>({
      path: `/routes/team-management/role-definitions`,
      method: "GET",
      ...params,
    });

  /**
   * @description Get company profile details
   *
   * @tags dbtn/module:team_management, dbtn/hasAuth
   * @name get_company_profile
   * @summary Get Company Profile
   * @request GET:/routes/team-management/companies/{company_id}/profile
   */
  get_company_profile = ({ companyId, ...query }: GetCompanyProfileParams, params: RequestParams = {}) =>
    this.request<GetCompanyProfileData, GetCompanyProfileError>({
      path: `/routes/team-management/companies/${companyId}/profile`,
      method: "GET",
      ...params,
    });

  /**
   * @description Update company profile (requires billing management permission)
   *
   * @tags dbtn/module:team_management, dbtn/hasAuth
   * @name update_company_profile
   * @summary Update Company Profile
   * @request PUT:/routes/team-management/companies/{company_id}/profile
   */
  update_company_profile = (
    { companyId, ...query }: UpdateCompanyProfileParams,
    data: UpdateCompanyProfileRequest,
    params: RequestParams = {},
  ) =>
    this.request<UpdateCompanyProfileData, UpdateCompanyProfileError>({
      path: `/routes/team-management/companies/${companyId}/profile`,
      method: "PUT",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Get all documents pending admin approval
   *
   * @tags dbtn/module:pending_documents, dbtn/hasAuth
   * @name list_pending_documents
   * @summary List Pending Documents
   * @request GET:/routes/pending-documents/list
   */
  list_pending_documents = (query: ListPendingDocumentsParams, params: RequestParams = {}) =>
    this.request<ListPendingDocumentsData, ListPendingDocumentsError>({
      path: `/routes/pending-documents/list`,
      method: "GET",
      query: query,
      ...params,
    });

  /**
   * @description Approve or reject a pending document
   *
   * @tags dbtn/module:pending_documents, dbtn/hasAuth
   * @name approve_or_reject_document
   * @summary Approve Or Reject Document
   * @request POST:/routes/pending-documents/approve
   */
  approve_or_reject_document = (data: ApprovalRequest, params: RequestParams = {}) =>
    this.request<ApproveOrRejectDocumentData, ApproveOrRejectDocumentError>({
      path: `/routes/pending-documents/approve`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Get statistics for pending documents
   *
   * @tags dbtn/module:pending_documents, dbtn/hasAuth
   * @name get_pending_stats
   * @summary Get Pending Stats
   * @request GET:/routes/pending-documents/stats
   */
  get_pending_stats = (params: RequestParams = {}) =>
    this.request<GetPendingStatsData, any>({
      path: `/routes/pending-documents/stats`,
      method: "GET",
      ...params,
    });

  /**
   * @description Save or update user business profile information
   *
   * @tags dbtn/module:user_profile, dbtn/hasAuth
   * @name save_user_profile
   * @summary Save User Profile
   * @request POST:/routes/save-user-profile
   */
  save_user_profile = (data: UserProfileRequest, params: RequestParams = {}) =>
    this.request<SaveUserProfileData, SaveUserProfileError>({
      path: `/routes/save-user-profile`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Get user business profile information
   *
   * @tags dbtn/module:user_profile, dbtn/hasAuth
   * @name get_user_profile
   * @summary Get User Profile
   * @request GET:/routes/get-user-profile
   */
  get_user_profile = (params: RequestParams = {}) =>
    this.request<GetUserProfileData, any>({
      path: `/routes/get-user-profile`,
      method: "GET",
      ...params,
    });

  /**
   * @description Delete user business profile information
   *
   * @tags dbtn/module:user_profile, dbtn/hasAuth
   * @name delete_user_profile
   * @summary Delete User Profile
   * @request DELETE:/routes/delete-user-profile
   */
  delete_user_profile = (params: RequestParams = {}) =>
    this.request<DeleteUserProfileData, any>({
      path: `/routes/delete-user-profile`,
      method: "DELETE",
      ...params,
    });

  /**
   * @description Get all annotations for a document
   *
   * @tags annotations, dbtn/module:annotations, dbtn/hasAuth
   * @name get_document_annotations
   * @summary Get Document Annotations
   * @request GET:/routes/annotations/documents/{document_id}
   */
  get_document_annotations = ({ documentId, ...query }: GetDocumentAnnotationsParams, params: RequestParams = {}) =>
    this.request<GetDocumentAnnotationsData, GetDocumentAnnotationsError>({
      path: `/routes/annotations/documents/${documentId}`,
      method: "GET",
      query: query,
      ...params,
    });

  /**
   * @description Create a new annotation
   *
   * @tags annotations, dbtn/module:annotations, dbtn/hasAuth
   * @name create_annotation
   * @summary Create Annotation
   * @request POST:/routes/annotations/documents/{document_id}
   */
  create_annotation = (
    { documentId, ...query }: CreateAnnotationParams,
    data: CreateAnnotationRequest,
    params: RequestParams = {},
  ) =>
    this.request<CreateAnnotationData, CreateAnnotationError>({
      path: `/routes/annotations/documents/${documentId}`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Update an existing annotation
   *
   * @tags annotations, dbtn/module:annotations, dbtn/hasAuth
   * @name update_annotation
   * @summary Update Annotation
   * @request PUT:/routes/annotations/annotations/{annotation_id}
   */
  update_annotation = (
    { annotationId, ...query }: UpdateAnnotationParams,
    data: UpdateAnnotationRequest,
    params: RequestParams = {},
  ) =>
    this.request<UpdateAnnotationData, UpdateAnnotationError>({
      path: `/routes/annotations/annotations/${annotationId}`,
      method: "PUT",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Delete an annotation
   *
   * @tags annotations, dbtn/module:annotations, dbtn/hasAuth
   * @name delete_annotation
   * @summary Delete Annotation
   * @request DELETE:/routes/annotations/annotations/{annotation_id}
   */
  delete_annotation = ({ annotationId, ...query }: DeleteAnnotationParams, params: RequestParams = {}) =>
    this.request<DeleteAnnotationData, DeleteAnnotationError>({
      path: `/routes/annotations/annotations/${annotationId}`,
      method: "DELETE",
      ...params,
    });

  /**
   * @description Mark an annotation as resolved
   *
   * @tags annotations, dbtn/module:annotations, dbtn/hasAuth
   * @name resolve_annotation
   * @summary Resolve Annotation
   * @request POST:/routes/annotations/annotations/{annotation_id}/resolve
   */
  resolve_annotation = ({ annotationId, ...query }: ResolveAnnotationParams, params: RequestParams = {}) =>
    this.request<ResolveAnnotationData, ResolveAnnotationError>({
      path: `/routes/annotations/annotations/${annotationId}/resolve`,
      method: "POST",
      ...params,
    });

  /**
   * @description Get all bookmarks for the current user
   *
   * @tags annotations, dbtn/module:annotations, dbtn/hasAuth
   * @name get_user_bookmarks
   * @summary Get User Bookmarks
   * @request GET:/routes/annotations/bookmarks
   */
  get_user_bookmarks = (params: RequestParams = {}) =>
    this.request<GetUserBookmarksData, any>({
      path: `/routes/annotations/bookmarks`,
      method: "GET",
      ...params,
    });

  /**
   * @description Create a new bookmark
   *
   * @tags annotations, dbtn/module:annotations, dbtn/hasAuth
   * @name create_bookmark
   * @summary Create Bookmark
   * @request POST:/routes/annotations/bookmarks
   */
  create_bookmark = (data: CreateBookmarkRequest, params: RequestParams = {}) =>
    this.request<CreateBookmarkData, CreateBookmarkError>({
      path: `/routes/annotations/bookmarks`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Delete a bookmark
   *
   * @tags annotations, dbtn/module:annotations, dbtn/hasAuth
   * @name delete_bookmark
   * @summary Delete Bookmark
   * @request DELETE:/routes/annotations/bookmarks/{bookmark_id}
   */
  delete_bookmark = ({ bookmarkId, ...query }: DeleteBookmarkParams, params: RequestParams = {}) =>
    this.request<DeleteBookmarkData, DeleteBookmarkError>({
      path: `/routes/annotations/bookmarks/${bookmarkId}`,
      method: "DELETE",
      ...params,
    });

  /**
   * @description Get recent activity for a document
   *
   * @tags annotations, dbtn/module:annotations, dbtn/hasAuth
   * @name get_document_activity
   * @summary Get Document Activity
   * @request GET:/routes/annotations/documents/{document_id}/activity
   */
  get_document_activity = ({ documentId, ...query }: GetDocumentActivityParams, params: RequestParams = {}) =>
    this.request<GetDocumentActivityData, GetDocumentActivityError>({
      path: `/routes/annotations/documents/${documentId}/activity`,
      method: "GET",
      query: query,
      ...params,
    });

  /**
   * @description Track user activity on a document
   *
   * @tags annotations, dbtn/module:annotations, dbtn/hasAuth
   * @name track_document_activity
   * @summary Track Document Activity
   * @request POST:/routes/annotations/documents/{document_id}/activity
   */
  track_document_activity = (
    { documentId, ...query }: TrackDocumentActivityParams,
    data: TrackDocumentActivityPayload,
    params: RequestParams = {},
  ) =>
    this.request<TrackDocumentActivityData, TrackDocumentActivityError>({
      path: `/routes/annotations/documents/${documentId}/activity`,
      method: "POST",
      query: query,
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Get collaboration statistics for a document
   *
   * @tags annotations, dbtn/module:annotations, dbtn/hasAuth
   * @name get_collaboration_stats
   * @summary Get Collaboration Stats
   * @request GET:/routes/annotations/documents/{document_id}/collaboration-stats
   */
  get_collaboration_stats = ({ documentId, ...query }: GetCollaborationStatsParams, params: RequestParams = {}) =>
    this.request<GetCollaborationStatsData, GetCollaborationStatsError>({
      path: `/routes/annotations/documents/${documentId}/collaboration-stats`,
      method: "GET",
      ...params,
    });

  /**
   * @description Get collaboration summary for the current user
   *
   * @tags annotations, dbtn/module:annotations, dbtn/hasAuth
   * @name get_user_collaboration_summary
   * @summary Get User Collaboration Summary
   * @request GET:/routes/annotations/user/collaboration-summary
   */
  get_user_collaboration_summary = (params: RequestParams = {}) =>
    this.request<GetUserCollaborationSummaryData, any>({
      path: `/routes/annotations/user/collaboration-summary`,
      method: "GET",
      ...params,
    });

  /**
   * @description List all regulatory feeds with enhanced metadata
   *
   * @tags dbtn/module:regulatory_monitoring, dbtn/hasAuth
   * @name list_regulatory_feeds
   * @summary List Regulatory Feeds
   * @request GET:/routes/feeds
   */
  list_regulatory_feeds = (params: RequestParams = {}) =>
    this.request<ListRegulatoryFeedsData, any>({
      path: `/routes/feeds`,
      method: "GET",
      ...params,
    });

  /**
   * @description Create a new regulatory feed with enhanced configuration
   *
   * @tags dbtn/module:regulatory_monitoring, dbtn/hasAuth
   * @name create_regulatory_feed
   * @summary Create Regulatory Feed
   * @request POST:/routes/feeds
   */
  create_regulatory_feed = (data: CreateRegulatoryFeedPayload, params: RequestParams = {}) =>
    this.request<CreateRegulatoryFeedData, CreateRegulatoryFeedError>({
      path: `/routes/feeds`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Get documents related to a specific document based on content analysis
   *
   * @tags dbtn/module:regulatory_monitoring, dbtn/hasAuth
   * @name get_related_documents_for_doc
   * @summary Get Related Documents For Doc
   * @request GET:/routes/documents/{document_id}/related
   */
  get_related_documents_for_doc = (
    { documentId, ...query }: GetRelatedDocumentsForDocParams,
    params: RequestParams = {},
  ) =>
    this.request<GetRelatedDocumentsForDocData, GetRelatedDocumentsForDocError>({
      path: `/routes/documents/${documentId}/related`,
      method: "GET",
      ...params,
    });

  /**
   * @description Create a cross-reference between two documents
   *
   * @tags dbtn/module:regulatory_monitoring, dbtn/hasAuth
   * @name create_document_cross_reference
   * @summary Create Document Cross Reference
   * @request POST:/routes/documents/{document_id}/cross-references
   */
  create_document_cross_reference = (
    { documentId, ...query }: CreateDocumentCrossReferenceParams,
    data: CrossReferenceRequest,
    params: RequestParams = {},
  ) =>
    this.request<CreateDocumentCrossReferenceData, CreateDocumentCrossReferenceError>({
      path: `/routes/documents/${documentId}/cross-references`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Get all cross-references for a document
   *
   * @tags dbtn/module:regulatory_monitoring, dbtn/hasAuth
   * @name get_document_cross_references_monitoring
   * @summary Get Document Cross References Monitoring
   * @request GET:/routes/documents/{document_id}/cross-references
   */
  get_document_cross_references_monitoring = (
    { documentId, ...query }: GetDocumentCrossReferencesMonitoringParams,
    params: RequestParams = {},
  ) =>
    this.request<GetDocumentCrossReferencesMonitoringData, GetDocumentCrossReferencesMonitoringError>({
      path: `/routes/documents/${documentId}/cross-references`,
      method: "GET",
      ...params,
    });

  /**
   * @description Analyze document and create cross-references automatically
   *
   * @tags dbtn/module:regulatory_monitoring, dbtn/hasAuth
   * @name analyze_document_references
   * @summary Analyze Document References
   * @request POST:/routes/documents/{document_id}/analyze-references
   */
  analyze_document_references = (
    { documentId, ...query }: AnalyzeDocumentReferencesParams,
    data: DocumentLinkingRequest,
    params: RequestParams = {},
  ) =>
    this.request<AnalyzeDocumentReferencesData, AnalyzeDocumentReferencesError>({
      path: `/routes/documents/${documentId}/analyze-references`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Enhanced feed processing with retry logic and error handling
   *
   * @tags dbtn/module:regulatory_monitoring, dbtn/hasAuth
   * @name process_feed_enhanced
   * @summary Process Feed Enhanced
   * @request POST:/routes/feeds/{feed_id}/process-enhanced
   */
  process_feed_enhanced = ({ feedId, ...query }: ProcessFeedEnhancedParams, params: RequestParams = {}) =>
    this.request<ProcessFeedEnhancedData, ProcessFeedEnhancedError>({
      path: `/routes/feeds/${feedId}/process-enhanced`,
      method: "POST",
      ...params,
    });

  /**
   * @description Process multiple feeds in parallel with error handling
   *
   * @tags dbtn/module:regulatory_monitoring, dbtn/hasAuth
   * @name bulk_process_feeds
   * @summary Bulk Process Feeds
   * @request POST:/routes/feeds/bulk-process
   */
  bulk_process_feeds = (data: BatchProcessingRequest, params: RequestParams = {}) =>
    this.request<BulkProcessFeedsData, BulkProcessFeedsError>({
      path: `/routes/feeds/bulk-process`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Get comprehensive health metrics for a feed
   *
   * @tags dbtn/module:regulatory_monitoring, dbtn/hasAuth
   * @name get_feed_health_metrics
   * @summary Get Feed Health Metrics
   * @request GET:/routes/feeds/{feed_id}/health
   */
  get_feed_health_metrics = ({ feedId, ...query }: GetFeedHealthMetricsParams, params: RequestParams = {}) =>
    this.request<GetFeedHealthMetricsData, GetFeedHealthMetricsError>({
      path: `/routes/feeds/${feedId}/health`,
      method: "GET",
      ...params,
    });

  /**
   * @description Perform comprehensive health check on a feed
   *
   * @tags dbtn/module:regulatory_monitoring, dbtn/hasAuth
   * @name perform_feed_health_check
   * @summary Perform Feed Health Check
   * @request POST:/routes/feeds/{feed_id}/health-check
   */
  perform_feed_health_check = ({ feedId, ...query }: PerformFeedHealthCheckParams, params: RequestParams = {}) =>
    this.request<PerformFeedHealthCheckData, PerformFeedHealthCheckError>({
      path: `/routes/feeds/${feedId}/health-check`,
      method: "POST",
      ...params,
    });

  /**
   * @description Configure automated scheduling for a feed
   *
   * @tags dbtn/module:regulatory_monitoring, dbtn/hasAuth
   * @name configure_feed_scheduling
   * @summary Configure Feed Scheduling
   * @request POST:/routes/feeds/{feed_id}/schedule
   */
  configure_feed_scheduling = (
    { feedId, ...query }: ConfigureFeedSchedulingParams,
    data: ConfigureFeedSchedulingPayload,
    params: RequestParams = {},
  ) =>
    this.request<ConfigureFeedSchedulingData, ConfigureFeedSchedulingError>({
      path: `/routes/feeds/${feedId}/schedule`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Send real-time notification for feed events
   *
   * @tags dbtn/module:regulatory_monitoring, dbtn/hasAuth
   * @name send_feed_notification
   * @summary Send Feed Notification
   * @request POST:/routes/feeds/{feed_id}/notify
   */
  send_feed_notification = (
    { feedId, ...query }: SendFeedNotificationParams,
    data: NotificationRequest,
    params: RequestParams = {},
  ) =>
    this.request<SendFeedNotificationData, SendFeedNotificationError>({
      path: `/routes/feeds/${feedId}/notify`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Get recent notifications for a feed
   *
   * @tags dbtn/module:regulatory_monitoring, dbtn/hasAuth
   * @name get_feed_notifications
   * @summary Get Feed Notifications
   * @request GET:/routes/feeds/{feed_id}/notifications
   */
  get_feed_notifications = ({ feedId, ...query }: GetFeedNotificationsParams, params: RequestParams = {}) =>
    this.request<GetFeedNotificationsData, GetFeedNotificationsError>({
      path: `/routes/feeds/${feedId}/notifications`,
      method: "GET",
      query: query,
      ...params,
    });

  /**
   * @description Configure automated alerts for feed events
   *
   * @tags dbtn/module:regulatory_monitoring, dbtn/hasAuth
   * @name configure_feed_alerts
   * @summary Configure Feed Alerts
   * @request POST:/routes/feeds/{feed_id}/alerts/configure
   */
  configure_feed_alerts = (
    { feedId, ...query }: ConfigureFeedAlertsParams,
    data: ConfigureFeedAlertsPayload,
    params: RequestParams = {},
  ) =>
    this.request<ConfigureFeedAlertsData, ConfigureFeedAlertsError>({
      path: `/routes/feeds/${feedId}/alerts/configure`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Get overall regulatory feeds system status
   *
   * @tags dbtn/module:regulatory_monitoring, dbtn/hasAuth
   * @name get_system_status
   * @summary Get System Status
   * @request GET:/routes/system/status
   */
  get_system_status = (params: RequestParams = {}) =>
    this.request<GetSystemStatusData, any>({
      path: `/routes/system/status`,
      method: "GET",
      ...params,
    });

  /**
   * @description Submit an assessment for RespectUs validation review. Creates a task in the admin dashboard for review.
   *
   * @tags dbtn/module:validation, dbtn/hasAuth
   * @name submit_for_validation
   * @summary Submit For Validation
   * @request POST:/routes/validation/submit
   */
  submit_for_validation = (data: ValidationSubmissionRequest, params: RequestParams = {}) =>
    this.request<SubmitForValidationData, SubmitForValidationError>({
      path: `/routes/validation/submit`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Get all validation tasks for admin review. Optionally filter by status: 'submitted', 'under_review', 'validated', 'needs_revision'
   *
   * @tags dbtn/module:validation, dbtn/hasAuth
   * @name get_admin_validation_tasks
   * @summary Get Admin Validation Tasks
   * @request GET:/routes/validation/admin/tasks
   */
  get_admin_validation_tasks = (query: GetAdminValidationTasksParams, params: RequestParams = {}) =>
    this.request<GetAdminValidationTasksData, GetAdminValidationTasksError>({
      path: `/routes/validation/admin/tasks`,
      method: "GET",
      query: query,
      ...params,
    });

  /**
   * @description Get detailed information about a specific validation task for admin review.
   *
   * @tags dbtn/module:validation, dbtn/hasAuth
   * @name get_validation_task_detail
   * @summary Get Validation Task Detail
   * @request GET:/routes/validation/admin/task/{validation_id}
   */
  get_validation_task_detail = (
    { validationId, ...query }: GetValidationTaskDetailParams,
    params: RequestParams = {},
  ) =>
    this.request<GetValidationTaskDetailData, GetValidationTaskDetailError>({
      path: `/routes/validation/admin/task/${validationId}`,
      method: "GET",
      ...params,
    });

  /**
   * @description Admin responds to a validation request - either approve or request changes. Sends email notification to the user.
   *
   * @tags dbtn/module:validation, dbtn/hasAuth
   * @name respond_to_validation
   * @summary Respond To Validation
   * @request POST:/routes/validation/admin/respond
   */
  respond_to_validation = (data: AdminValidationRequest, params: RequestParams = {}) =>
    this.request<RespondToValidationData, RespondToValidationError>({
      path: `/routes/validation/admin/respond`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Get validation status for a specific assessment for the current user.
   *
   * @tags dbtn/module:validation, dbtn/hasAuth
   * @name get_user_validation_status
   * @summary Get User Validation Status
   * @request GET:/routes/validation/user/status/{assessment_id}
   */
  get_user_validation_status = (
    { assessmentId, ...query }: GetUserValidationStatusParams,
    params: RequestParams = {},
  ) =>
    this.request<GetUserValidationStatusData, GetUserValidationStatusError>({
      path: `/routes/validation/user/status/${assessmentId}`,
      method: "GET",
      ...params,
    });

  /**
   * @description Get invitation details for acceptance page (public endpoint)
   *
   * @tags dbtn/module:invitation_system, dbtn/hasAuth
   * @name get_invitation_details
   * @summary Get Invitation Details
   * @request GET:/routes/invitation-system/invitation/{invitation_token}
   */
  get_invitation_details = ({ invitationToken, ...query }: GetInvitationDetailsParams, params: RequestParams = {}) =>
    this.request<GetInvitationDetailsData, GetInvitationDetailsError>({
      path: `/routes/invitation-system/invitation/${invitationToken}`,
      method: "GET",
      ...params,
    });

  /**
   * @description Accept a team invitation
   *
   * @tags dbtn/module:invitation_system, dbtn/hasAuth
   * @name accept_invitation
   * @summary Accept Invitation
   * @request POST:/routes/invitation-system/accept-invitation
   */
  accept_invitation = (data: AcceptInvitationRequest, params: RequestParams = {}) =>
    this.request<AcceptInvitationData, AcceptInvitationError>({
      path: `/routes/invitation-system/accept-invitation`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Resend a team invitation
   *
   * @tags dbtn/module:invitation_system, dbtn/hasAuth
   * @name resend_invitation
   * @summary Resend Invitation
   * @request POST:/routes/invitation-system/resend-invitation
   */
  resend_invitation = (data: ResendInvitationRequest, params: RequestParams = {}) =>
    this.request<ResendInvitationData, ResendInvitationError>({
      path: `/routes/invitation-system/resend-invitation`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Cancel a pending invitation
   *
   * @tags dbtn/module:invitation_system, dbtn/hasAuth
   * @name cancel_invitation
   * @summary Cancel Invitation
   * @request DELETE:/routes/invitation-system/invitations/{invitation_id}
   */
  cancel_invitation = ({ invitationId, ...query }: CancelInvitationParams, params: RequestParams = {}) =>
    this.request<CancelInvitationData, CancelInvitationError>({
      path: `/routes/invitation-system/invitations/${invitationId}`,
      method: "DELETE",
      ...params,
    });

  /**
   * @description Manually send invitation email (for testing or resending)
   *
   * @tags dbtn/module:invitation_system, dbtn/hasAuth
   * @name send_invitation_email_manually
   * @summary Send Invitation Email Manually
   * @request POST:/routes/invitation-system/send-invitation-email
   */
  send_invitation_email_manually = (query: SendInvitationEmailManuallyParams, params: RequestParams = {}) =>
    this.request<SendInvitationEmailManuallyData, SendInvitationEmailManuallyError>({
      path: `/routes/invitation-system/send-invitation-email`,
      method: "POST",
      query: query,
      ...params,
    });

  /**
   * @description Create a new customer profile for screening
   *
   * @tags dbtn/module:customer_screening, dbtn/hasAuth
   * @name create_customer
   * @summary Create Customer
   * @request POST:/routes/customer-screening/customers
   */
  create_customer = (data: CustomerProfile, params: RequestParams = {}) =>
    this.request<CreateCustomerData, CreateCustomerError>({
      path: `/routes/customer-screening/customers`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description List customer profiles with filtering and pagination
   *
   * @tags dbtn/module:customer_screening, dbtn/hasAuth
   * @name list_customers
   * @summary List Customers
   * @request GET:/routes/customer-screening/customers
   */
  list_customers = (query: ListCustomersParams, params: RequestParams = {}) =>
    this.request<ListCustomersData, ListCustomersError>({
      path: `/routes/customer-screening/customers`,
      method: "GET",
      query: query,
      ...params,
    });

  /**
   * @description Update an existing customer profile
   *
   * @tags dbtn/module:customer_screening, dbtn/hasAuth
   * @name update_customer
   * @summary Update Customer
   * @request PUT:/routes/customer-screening/customers/{customer_id}
   */
  update_customer = (
    { customerId, ...query }: UpdateCustomerParams,
    data: CustomerProfile,
    params: RequestParams = {},
  ) =>
    this.request<UpdateCustomerData, UpdateCustomerError>({
      path: `/routes/customer-screening/customers/${customerId}`,
      method: "PUT",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Delete a customer profile and associated screening data
   *
   * @tags dbtn/module:customer_screening, dbtn/hasAuth
   * @name delete_customer
   * @summary Delete Customer
   * @request DELETE:/routes/customer-screening/customers/{customer_id}
   */
  delete_customer = ({ customerId, ...query }: DeleteCustomerParams, params: RequestParams = {}) =>
    this.request<DeleteCustomerData, DeleteCustomerError>({
      path: `/routes/customer-screening/customers/${customerId}`,
      method: "DELETE",
      ...params,
    });

  /**
   * @description Perform batch screening for multiple customers
   *
   * @tags dbtn/module:customer_screening, dbtn/hasAuth
   * @name batch_screen_customers
   * @summary Batch Screen Customers
   * @request POST:/routes/customer-screening/batch-screen
   */
  batch_screen_customers = (data: BatchScreeningRequest, params: RequestParams = {}) =>
    this.request<BatchScreenCustomersData, BatchScreenCustomersError>({
      path: `/routes/customer-screening/batch-screen`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Export screening results in specified format
   *
   * @tags dbtn/module:customer_screening, dbtn/hasAuth
   * @name export_screening_results
   * @summary Export Screening Results
   * @request POST:/routes/customer-screening/export
   */
  export_screening_results = (data: ScreeningExportRequest, params: RequestParams = {}) =>
    this.request<ExportScreeningResultsData, ExportScreeningResultsError>({
      path: `/routes/customer-screening/export`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Perform screening for a specific customer against watchlists (optionally at a specific date)
   *
   * @tags dbtn/module:customer_screening, dbtn/hasAuth
   * @name screen_customer
   * @summary Screen Customer
   * @request POST:/routes/customer-screening/screen/{customer_id}
   */
  screen_customer = (
    { customerId, ...query }: ScreenCustomerParams,
    data: ScreenCustomerPayload,
    params: RequestParams = {},
  ) =>
    this.request<ScreenCustomerData, ScreenCustomerError>({
      path: `/routes/customer-screening/screen/${customerId}`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Get screening history for a customer
   *
   * @tags dbtn/module:customer_screening, dbtn/hasAuth
   * @name get_screening_history
   * @summary Get Screening History
   * @request GET:/routes/customer-screening/results/{customer_id}
   */
  get_screening_history = ({ customerId, ...query }: GetScreeningHistoryParams, params: RequestParams = {}) =>
    this.request<GetScreeningHistoryData, GetScreeningHistoryError>({
      path: `/routes/customer-screening/results/${customerId}`,
      method: "GET",
      ...params,
    });

  /**
   * @description Get screening alerts with filtering
   *
   * @tags dbtn/module:customer_screening, dbtn/hasAuth
   * @name get_screening_alerts
   * @summary Get Screening Alerts
   * @request GET:/routes/customer-screening/alerts
   */
  get_screening_alerts = (query: GetScreeningAlertsParams, params: RequestParams = {}) =>
    this.request<GetScreeningAlertsData, GetScreeningAlertsError>({
      path: `/routes/customer-screening/alerts`,
      method: "GET",
      query: query,
      ...params,
    });

  /**
   * @description Verify a screening match as true positive or false positive
   *
   * @tags dbtn/module:customer_screening, dbtn/hasAuth
   * @name verify_hit
   * @summary Verify Hit
   * @request POST:/routes/customer-screening/verify-hit
   */
  verify_hit = (data: HitVerificationRequest, params: RequestParams = {}) =>
    this.request<VerifyHitData, VerifyHitError>({
      path: `/routes/customer-screening/verify-hit`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Search watchlists directly for sanctioned persons, entities, vessels, and aircraft
   *
   * @tags dbtn/module:customer_screening, dbtn/hasAuth
   * @name search_watchlists
   * @summary Search Watchlists
   * @request POST:/routes/customer-screening/search-watchlists
   */
  search_watchlists = (data: WatchlistSearchRequest, params: RequestParams = {}) =>
    this.request<SearchWatchlistsData, SearchWatchlistsError>({
      path: `/routes/customer-screening/search-watchlists`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Qualify a screening match as true positive or false positive
   *
   * @tags dbtn/module:customer_screening, dbtn/hasAuth
   * @name qualify_screening_match
   * @summary Qualify Screening Match
   * @request PUT:/routes/customer-screening/qualify-match/{match_id}
   */
  qualify_screening_match = (
    { matchId, ...query }: QualifyScreeningMatchParams,
    data: MatchQualificationRequest,
    params: RequestParams = {},
  ) =>
    this.request<QualifyScreeningMatchData, QualifyScreeningMatchError>({
      path: `/routes/customer-screening/qualify-match/${matchId}`,
      method: "PUT",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Get all risk categories
   *
   * @tags dbtn/module:end_use_checks, dbtn/hasAuth
   * @name get_risk_categories
   * @summary Get Risk Categories
   * @request GET:/routes/end-use-checks/risk-categories
   */
  get_risk_categories = (params: RequestParams = {}) =>
    this.request<GetRiskCategoriesData, any>({
      path: `/routes/end-use-checks/risk-categories`,
      method: "GET",
      ...params,
    });

  /**
   * @description Get risk indicators, optionally filtered by category
   *
   * @tags dbtn/module:end_use_checks, dbtn/hasAuth
   * @name get_risk_indicators
   * @summary Get Risk Indicators
   * @request GET:/routes/end-use-checks/risk-indicators
   */
  get_risk_indicators = (query: GetRiskIndicatorsParams, params: RequestParams = {}) =>
    this.request<GetRiskIndicatorsData, GetRiskIndicatorsError>({
      path: `/routes/end-use-checks/risk-indicators`,
      method: "GET",
      query: query,
      ...params,
    });

  /**
   * @description Get critical countries with optional search and filtering
   *
   * @tags dbtn/module:end_use_checks, dbtn/hasAuth
   * @name list_critical_countries
   * @summary List Critical Countries
   * @request GET:/routes/end-use-checks/countries
   */
  list_critical_countries = (query: ListCriticalCountriesParams, params: RequestParams = {}) =>
    this.request<ListCriticalCountriesData, ListCriticalCountriesError>({
      path: `/routes/end-use-checks/countries`,
      method: "GET",
      query: query,
      ...params,
    });

  /**
   * @description Create a new critical country
   *
   * @tags dbtn/module:end_use_checks, dbtn/hasAuth
   * @name create_country
   * @summary Create Country
   * @request POST:/routes/end-use-checks/countries
   */
  create_country = (data: CountryCreateRequest, params: RequestParams = {}) =>
    this.request<CreateCountryData, CreateCountryError>({
      path: `/routes/end-use-checks/countries`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Get detailed information for a specific country
   *
   * @tags dbtn/module:end_use_checks, dbtn/hasAuth
   * @name get_country_detail
   * @summary Get Country Detail
   * @request GET:/routes/end-use-checks/countries/{country_id}
   */
  get_country_detail = ({ countryId, ...query }: GetCountryDetailParams, params: RequestParams = {}) =>
    this.request<GetCountryDetailData, GetCountryDetailError>({
      path: `/routes/end-use-checks/countries/${countryId}`,
      method: "GET",
      ...params,
    });

  /**
   * @description Update a critical country
   *
   * @tags dbtn/module:end_use_checks, dbtn/hasAuth
   * @name update_country
   * @summary Update Country
   * @request PUT:/routes/end-use-checks/countries/{country_id}
   */
  update_country = (
    { countryId, ...query }: UpdateCountryParams,
    data: CountryUpdateRequest,
    params: RequestParams = {},
  ) =>
    this.request<UpdateCountryData, UpdateCountryError>({
      path: `/routes/end-use-checks/countries/${countryId}`,
      method: "PUT",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Delete a critical country
   *
   * @tags dbtn/module:end_use_checks, dbtn/hasAuth
   * @name delete_country
   * @summary Delete Country
   * @request DELETE:/routes/end-use-checks/countries/{country_id}
   */
  delete_country = ({ countryId, ...query }: DeleteCountryParams, params: RequestParams = {}) =>
    this.request<DeleteCountryData, DeleteCountryError>({
      path: `/routes/end-use-checks/countries/${countryId}`,
      method: "DELETE",
      ...params,
    });

  /**
   * @description Create or update a risk assessment for a country
   *
   * @tags dbtn/module:end_use_checks, dbtn/hasAuth
   * @name create_or_update_risk_assessment
   * @summary Create Or Update Risk Assessment
   * @request POST:/routes/end-use-checks/risk-assessments
   */
  create_or_update_risk_assessment = (data: RiskAssessmentRequest, params: RequestParams = {}) =>
    this.request<CreateOrUpdateRiskAssessmentData, CreateOrUpdateRiskAssessmentError>({
      path: `/routes/end-use-checks/risk-assessments`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Delete a specific risk assessment
   *
   * @tags dbtn/module:end_use_checks, dbtn/hasAuth
   * @name delete_risk_assessment
   * @summary Delete Risk Assessment
   * @request DELETE:/routes/end-use-checks/risk-assessments/{country_id}/{indicator_id}
   */
  delete_risk_assessment = (
    { countryId, indicatorId, ...query }: DeleteRiskAssessmentParams,
    params: RequestParams = {},
  ) =>
    this.request<DeleteRiskAssessmentData, DeleteRiskAssessmentError>({
      path: `/routes/end-use-checks/risk-assessments/${countryId}/${indicatorId}`,
      method: "DELETE",
      ...params,
    });

  /**
   * @description Advanced search for countries with risk-based filtering
   *
   * @tags dbtn/module:end_use_checks, dbtn/hasAuth
   * @name search_critical_countries
   * @summary Search Critical Countries
   * @request POST:/routes/end-use-checks/countries/search
   */
  search_critical_countries = (data: CountrySearchFilters, params: RequestParams = {}) =>
    this.request<SearchCriticalCountriesData, SearchCriticalCountriesError>({
      path: `/routes/end-use-checks/countries/search`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Get statistics about critical countries data
   *
   * @tags dbtn/module:end_use_checks, dbtn/hasAuth
   * @name get_critical_countries_stats
   * @summary Get Critical Countries Stats
   * @request GET:/routes/end-use-checks/stats
   */
  get_critical_countries_stats = (params: RequestParams = {}) =>
    this.request<GetCriticalCountriesStatsData, any>({
      path: `/routes/end-use-checks/stats`,
      method: "GET",
      ...params,
    });

  /**
   * @description Bulk upload critical countries from Excel file
   *
   * @tags dbtn/module:end_use_checks, dbtn/hasAuth
   * @name bulk_upload_critical_countries
   * @summary Bulk Upload Critical Countries
   * @request POST:/routes/end-use-checks/critical-countries/bulk-upload
   */
  bulk_upload_critical_countries = (data: BodyBulkUploadCriticalCountries, params: RequestParams = {}) =>
    this.request<BulkUploadCriticalCountriesData, BulkUploadCriticalCountriesError>({
      path: `/routes/end-use-checks/critical-countries/bulk-upload`,
      method: "POST",
      body: data,
      type: ContentType.FormData,
      ...params,
    });

  /**
   * @description Download Excel template for critical countries bulk upload
   *
   * @tags dbtn/module:end_use_checks, dbtn/hasAuth
   * @name download_critical_countries_template
   * @summary Download Critical Countries Template
   * @request GET:/routes/end-use-checks/critical-countries/download-template
   */
  download_critical_countries_template = (params: RequestParams = {}) =>
    this.request<DownloadCriticalCountriesTemplateData, any>({
      path: `/routes/end-use-checks/critical-countries/download-template`,
      method: "GET",
      ...params,
    });

  /**
   * @description List critical countries with filtering and pagination
   *
   * @tags dbtn/module:end_use_checks, dbtn/hasAuth
   * @name get_critical_countries_list
   * @summary Get Critical Countries List
   * @request GET:/routes/end-use-checks/critical-countries
   */
  get_critical_countries_list = (query: GetCriticalCountriesListParams, params: RequestParams = {}) =>
    this.request<GetCriticalCountriesListData, GetCriticalCountriesListError>({
      path: `/routes/end-use-checks/critical-countries`,
      method: "GET",
      query: query,
      ...params,
    });

  /**
   * @description Get comprehensive usage summary for the current user
   *
   * @tags dbtn/module:usage_monitoring, dbtn/hasAuth
   * @name get_user_usage_summary
   * @summary Get User Usage Summary
   * @request GET:/routes/usage/summary
   */
  get_user_usage_summary = (params: RequestParams = {}) =>
    this.request<GetUserUsageSummaryData, any>({
      path: `/routes/usage/summary`,
      method: "GET",
      ...params,
    });

  /**
   * @description Get detailed breakdown of usage by component and action
   *
   * @tags dbtn/module:usage_monitoring, dbtn/hasAuth
   * @name get_component_usage_breakdown
   * @summary Get Component Usage Breakdown
   * @request GET:/routes/usage/components
   */
  get_component_usage_breakdown = (query: GetComponentUsageBreakdownParams, params: RequestParams = {}) =>
    this.request<GetComponentUsageBreakdownData, GetComponentUsageBreakdownError>({
      path: `/routes/usage/components`,
      method: "GET",
      query: query,
      ...params,
    });

  /**
   * @description Get daily usage data for charting
   *
   * @tags dbtn/module:usage_monitoring, dbtn/hasAuth
   * @name get_daily_usage_chart
   * @summary Get Daily Usage Chart
   * @request GET:/routes/usage/daily-chart
   */
  get_daily_usage_chart = (query: GetDailyUsageChartParams, params: RequestParams = {}) =>
    this.request<GetDailyUsageChartData, GetDailyUsageChartError>({
      path: `/routes/usage/daily-chart`,
      method: "GET",
      query: query,
      ...params,
    });

  /**
   * @description Get real-time usage metrics for the current day
   *
   * @tags dbtn/module:usage_monitoring, dbtn/hasAuth
   * @name get_real_time_metrics
   * @summary Get Real Time Metrics
   * @request GET:/routes/usage/real-time-metrics
   */
  get_real_time_metrics = (params: RequestParams = {}) =>
    this.request<GetRealTimeMetricsData, any>({
      path: `/routes/usage/real-time-metrics`,
      method: "GET",
      ...params,
    });

  /**
   * @description Get active spending alerts for the user
   *
   * @tags dbtn/module:usage_monitoring, dbtn/hasAuth
   * @name get_active_spending_alerts
   * @summary Get Active Spending Alerts
   * @request GET:/routes/alerts/active
   */
  get_active_spending_alerts = (params: RequestParams = {}) =>
    this.request<GetActiveSpendingAlertsData, any>({
      path: `/routes/alerts/active`,
      method: "GET",
      ...params,
    });

  /**
   * @description Configure spending alert thresholds
   *
   * @tags dbtn/module:usage_monitoring, dbtn/hasAuth
   * @name configure_spending_alerts
   * @summary Configure Spending Alerts
   * @request POST:/routes/alerts/configure
   */
  configure_spending_alerts = (data: ConfigureSpendingAlertsPayload, params: RequestParams = {}) =>
    this.request<ConfigureSpendingAlertsData, ConfigureSpendingAlertsError>({
      path: `/routes/alerts/configure`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Check current usage against thresholds and trigger alerts if needed
   *
   * @tags dbtn/module:usage_monitoring, dbtn/hasAuth
   * @name check_and_trigger_alerts
   * @summary Check And Trigger Alerts
   * @request POST:/routes/alerts/check
   */
  check_and_trigger_alerts = (params: RequestParams = {}) =>
    this.request<CheckAndTriggerAlertsData, any>({
      path: `/routes/alerts/check`,
      method: "POST",
      ...params,
    });

  /**
   * @description Dismiss a spending alert
   *
   * @tags dbtn/module:usage_monitoring, dbtn/hasAuth
   * @name dismiss_spending_alert
   * @summary Dismiss Spending Alert
   * @request POST:/routes/alerts/{alert_id}/dismiss
   */
  dismiss_spending_alert = ({ alertId, ...query }: DismissSpendingAlertParams, params: RequestParams = {}) =>
    this.request<DismissSpendingAlertData, DismissSpendingAlertError>({
      path: `/routes/alerts/${alertId}/dismiss`,
      method: "POST",
      ...params,
    });

  /**
   * @description Get comprehensive usage analytics for admin dashboard
   *
   * @tags dbtn/module:usage_monitoring, dbtn/hasAuth
   * @name get_admin_usage_analytics
   * @summary Get Admin Usage Analytics
   * @request GET:/routes/admin/analytics
   */
  get_admin_usage_analytics = (params: RequestParams = {}) =>
    this.request<GetAdminUsageAnalyticsData, any>({
      path: `/routes/admin/analytics`,
      method: "GET",
      ...params,
    });

  /**
   * @description Get real-time system-wide metrics for admin dashboard
   *
   * @tags dbtn/module:usage_monitoring, dbtn/hasAuth
   * @name get_admin_real_time_dashboard
   * @summary Get Admin Real Time Dashboard
   * @request GET:/routes/admin/real-time-dashboard
   */
  get_admin_real_time_dashboard = (params: RequestParams = {}) =>
    this.request<GetAdminRealTimeDashboardData, any>({
      path: `/routes/admin/real-time-dashboard`,
      method: "GET",
      ...params,
    });

  /**
   * @description Submit a document for admin review and approval
   *
   * @tags dbtn/module:user_submissions, dbtn/hasAuth
   * @name submit_document
   * @summary Submit Document
   * @request POST:/routes/user-submissions/submit-document
   */
  submit_document = (data: BodySubmitDocument, params: RequestParams = {}) =>
    this.request<SubmitDocumentData, SubmitDocumentError>({
      path: `/routes/user-submissions/submit-document`,
      method: "POST",
      body: data,
      type: ContentType.FormData,
      ...params,
    });

  /**
   * @description Submit a case study for admin review and approval
   *
   * @tags dbtn/module:user_submissions, dbtn/hasAuth
   * @name submit_case_study
   * @summary Submit Case Study
   * @request POST:/routes/user-submissions/submit-case-study
   */
  submit_case_study = (data: BodySubmitCaseStudy, params: RequestParams = {}) =>
    this.request<SubmitCaseStudyData, SubmitCaseStudyError>({
      path: `/routes/user-submissions/submit-case-study`,
      method: "POST",
      body: data,
      type: ContentType.FormData,
      ...params,
    });

  /**
   * @description Submit a blog article for admin review and approval
   *
   * @tags dbtn/module:user_submissions, dbtn/hasAuth
   * @name submit_blog_article
   * @summary Submit Blog Article
   * @request POST:/routes/user-submissions/submit-blog-article
   */
  submit_blog_article = (data: BlogSubmissionRequest, params: RequestParams = {}) =>
    this.request<SubmitBlogArticleData, SubmitBlogArticleError>({
      path: `/routes/user-submissions/submit-blog-article`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Get user's submission history
   *
   * @tags dbtn/module:user_submissions, dbtn/hasAuth
   * @name get_my_submissions
   * @summary Get My Submissions
   * @request GET:/routes/user-submissions/my-submissions
   */
  get_my_submissions = (params: RequestParams = {}) =>
    this.request<GetMySubmissionsData, any>({
      path: `/routes/user-submissions/my-submissions`,
      method: "GET",
      ...params,
    });

  /**
   * @description Get all admin validation tasks
   *
   * @tags dbtn/module:admin_tasks, dbtn/hasAuth
   * @name list_admin_tasks
   * @summary List Admin Tasks
   * @request GET:/routes/admin-tasks/list
   */
  list_admin_tasks = (params: RequestParams = {}) =>
    this.request<ListAdminTasksData, any>({
      path: `/routes/admin-tasks/list`,
      method: "GET",
      ...params,
    });

  /**
   * @description Get all pending validation tasks
   *
   * @tags dbtn/module:admin_tasks, dbtn/hasAuth
   * @name get_pending_tasks
   * @summary Get Pending Tasks
   * @request GET:/routes/admin-tasks/pending
   */
  get_pending_tasks = (params: RequestParams = {}) =>
    this.request<GetPendingTasksData, any>({
      path: `/routes/admin-tasks/pending`,
      method: "GET",
      ...params,
    });

  /**
   * @description Update task status (approve/reject)
   *
   * @tags dbtn/module:admin_tasks, dbtn/hasAuth
   * @name update_task
   * @summary Update Task
   * @request POST:/routes/admin-tasks/update/{task_id}
   */
  update_task = ({ taskId, ...query }: UpdateTaskParams, data: TaskUpdateRequest, params: RequestParams = {}) =>
    this.request<UpdateTaskData, UpdateTaskError>({
      path: `/routes/admin-tasks/update/${taskId}`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Save or update an assessment with user responses
   *
   * @tags dbtn/module:assessment_management, dbtn/hasAuth
   * @name save_assessment
   * @summary Save Assessment
   * @request POST:/routes/assessment-management/save
   */
  save_assessment = (data: SaveAssessmentRequest, params: RequestParams = {}) =>
    this.request<SaveAssessmentData, SaveAssessmentError>({
      path: `/routes/assessment-management/save`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Load a specific assessment by ID
   *
   * @tags dbtn/module:assessment_management, dbtn/hasAuth
   * @name load_assessment
   * @summary Load Assessment
   * @request GET:/routes/assessment-management/load/{assessment_id}
   */
  load_assessment = ({ assessmentId, ...query }: LoadAssessmentParams, params: RequestParams = {}) =>
    this.request<LoadAssessmentData, LoadAssessmentError>({
      path: `/routes/assessment-management/load/${assessmentId}`,
      method: "GET",
      ...params,
    });

  /**
   * @description List all assessments for the current user
   *
   * @tags dbtn/module:assessment_management, dbtn/hasAuth
   * @name list_user_assessments
   * @summary List User Assessments
   * @request GET:/routes/assessment-management/list
   */
  list_user_assessments = (params: RequestParams = {}) =>
    this.request<ListUserAssessmentsData, any>({
      path: `/routes/assessment-management/list`,
      method: "GET",
      ...params,
    });

  /**
   * @description Delete an assessment
   *
   * @tags dbtn/module:assessment_management, dbtn/hasAuth
   * @name delete_assessment
   * @summary Delete Assessment
   * @request DELETE:/routes/assessment-management/delete/{assessment_id}
   */
  delete_assessment = ({ assessmentId, ...query }: DeleteAssessmentParams, params: RequestParams = {}) =>
    this.request<DeleteAssessmentData, DeleteAssessmentError>({
      path: `/routes/assessment-management/delete/${assessmentId}`,
      method: "DELETE",
      ...params,
    });

  /**
   * @description Get all module pricing configurations
   *
   * @tags dbtn/module:module_pricing, dbtn/hasAuth
   * @name get_module_pricing_configurations
   * @summary Get Module Pricing Configurations
   * @request GET:/routes/module-pricing/configurations
   */
  get_module_pricing_configurations = (params: RequestParams = {}) =>
    this.request<GetModulePricingConfigurationsData, any>({
      path: `/routes/module-pricing/configurations`,
      method: "GET",
      ...params,
    });

  /**
   * @description Create new module pricing configuration
   *
   * @tags dbtn/module:module_pricing, dbtn/hasAuth
   * @name create_module_pricing_configuration
   * @summary Create Module Pricing Configuration
   * @request POST:/routes/module-pricing/configurations
   */
  create_module_pricing_configuration = (data: ModulePricingCreate, params: RequestParams = {}) =>
    this.request<CreateModulePricingConfigurationData, CreateModulePricingConfigurationError>({
      path: `/routes/module-pricing/configurations`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Update module pricing configuration
   *
   * @tags dbtn/module:module_pricing, dbtn/hasAuth
   * @name update_module_pricing_configuration
   * @summary Update Module Pricing Configuration
   * @request PUT:/routes/module-pricing/configurations/{module_name}
   */
  update_module_pricing_configuration = (
    { moduleName, ...query }: UpdateModulePricingConfigurationParams,
    data: ModulePricingUpdate,
    params: RequestParams = {},
  ) =>
    this.request<UpdateModulePricingConfigurationData, UpdateModulePricingConfigurationError>({
      path: `/routes/module-pricing/configurations/${moduleName}`,
      method: "PUT",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Delete module pricing configuration
   *
   * @tags dbtn/module:module_pricing, dbtn/hasAuth
   * @name delete_module_pricing_configuration
   * @summary Delete Module Pricing Configuration
   * @request DELETE:/routes/module-pricing/configurations/{module_name}
   */
  delete_module_pricing_configuration = (
    { moduleName, ...query }: DeleteModulePricingConfigurationParams,
    params: RequestParams = {},
  ) =>
    this.request<DeleteModulePricingConfigurationData, DeleteModulePricingConfigurationError>({
      path: `/routes/module-pricing/configurations/${moduleName}`,
      method: "DELETE",
      ...params,
    });

  /**
   * @description Get specific module pricing configuration
   *
   * @tags dbtn/module:module_pricing, dbtn/hasAuth
   * @name get_module_pricing_configuration
   * @summary Get Module Pricing Configuration
   * @request GET:/routes/module-pricing/configuration/{module_name}
   */
  get_module_pricing_configuration = (
    { moduleName, ...query }: GetModulePricingConfigurationParams,
    params: RequestParams = {},
  ) =>
    this.request<GetModulePricingConfigurationData, GetModulePricingConfigurationError>({
      path: `/routes/module-pricing/configuration/${moduleName}`,
      method: "GET",
      ...params,
    });

  /**
   * @description Send a risk assessment report via email with PDF attachment. Uses Databutton's email service to send professional assessment reports.
   *
   * @tags dbtn/module:email_service, dbtn/hasAuth
   * @name send_assessment_email
   * @summary Send Assessment Email
   * @request POST:/routes/email/send-assessment
   */
  send_assessment_email = (data: EmailRequest, params: RequestParams = {}) =>
    this.request<SendAssessmentEmailData, SendAssessmentEmailError>({
      path: `/routes/email/send-assessment`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Check if user is eligible for free tier credits
   *
   * @tags dbtn/module:free_tier, dbtn/hasAuth
   * @name check_free_tier_eligibility
   * @summary Check Free Tier Eligibility
   * @request GET:/routes/check-eligibility
   */
  check_free_tier_eligibility = (params: RequestParams = {}) =>
    this.request<CheckFreeTierEligibilityData, any>({
      path: `/routes/check-eligibility`,
      method: "GET",
      ...params,
    });

  /**
   * @description Activate free tier credits for eligible users
   *
   * @tags dbtn/module:free_tier, dbtn/hasAuth
   * @name activate_free_tier_credits
   * @summary Activate Free Tier Credits
   * @request POST:/routes/activate
   */
  activate_free_tier_credits = (params: RequestParams = {}) =>
    this.request<ActivateFreeTierCreditsData, any>({
      path: `/routes/activate`,
      method: "POST",
      ...params,
    });

  /**
   * @description Get trial usage statistics for the user
   *
   * @tags dbtn/module:free_tier, dbtn/hasAuth
   * @name get_trial_usage_stats
   * @summary Get Trial Usage Stats
   * @request GET:/routes/trial-stats
   */
  get_trial_usage_stats = (params: RequestParams = {}) =>
    this.request<GetTrialUsageStatsData, any>({
      path: `/routes/trial-stats`,
      method: "GET",
      ...params,
    });

  /**
   * @description Award bonus credits for specific trial milestones
   *
   * @tags dbtn/module:free_tier, dbtn/hasAuth
   * @name extend_trial_credits
   * @summary Extend Trial Credits
   * @request POST:/routes/extend-trial
   */
  extend_trial_credits = (query: ExtendTrialCreditsParams, params: RequestParams = {}) =>
    this.request<ExtendTrialCreditsData, ExtendTrialCreditsError>({
      path: `/routes/extend-trial`,
      method: "POST",
      query: query,
      ...params,
    });

  /**
   * @description Upload a form for risk assessment analysis
   *
   * @tags dbtn/module:risk_assessment, dbtn/hasAuth
   * @name upload_assessment_form
   * @summary Upload Assessment Form
   * @request POST:/routes/risk-assessment/upload-form
   */
  upload_assessment_form = (data: BodyUploadAssessmentForm, params: RequestParams = {}) =>
    this.request<UploadAssessmentFormData, UploadAssessmentFormError>({
      path: `/routes/risk-assessment/upload-form`,
      method: "POST",
      body: data,
      type: ContentType.FormData,
      ...params,
    });

  /**
   * @description Analyze the uploaded form and extract structure
   *
   * @tags dbtn/module:risk_assessment, dbtn/hasAuth
   * @name analyze_uploaded_form
   * @summary Analyze Uploaded Form
   * @request GET:/routes/risk-assessment/analyze-form/{file_id}
   */
  analyze_uploaded_form = ({ fileId, ...query }: AnalyzeUploadedFormParams, params: RequestParams = {}) =>
    this.request<AnalyzeUploadedFormData, AnalyzeUploadedFormError>({
      path: `/routes/risk-assessment/analyze-form/${fileId}`,
      method: "GET",
      ...params,
    });

  /**
   * @description List all uploaded forms for the current user
   *
   * @tags dbtn/module:risk_assessment, dbtn/hasAuth
   * @name list_uploaded_forms
   * @summary List Uploaded Forms
   * @request GET:/routes/risk-assessment/forms
   */
  list_uploaded_forms = (params: RequestParams = {}) =>
    this.request<ListUploadedFormsData, any>({
      path: `/routes/risk-assessment/forms`,
      method: "GET",
      ...params,
    });

  /**
   * @description Export risk assessment as PDF with RespectUs branding
   *
   * @tags stream, dbtn/module:risk_assessment, dbtn/hasAuth
   * @name export_assessment_pdf
   * @summary Export Assessment Pdf
   * @request GET:/routes/risk-assessment/export-pdf/{assessment_id}
   */
  export_assessment_pdf = ({ assessmentId, ...query }: ExportAssessmentPdfParams, params: RequestParams = {}) =>
    this.requestStream<ExportAssessmentPdfData, ExportAssessmentPdfError>({
      path: `/routes/risk-assessment/export-pdf/${assessmentId}`,
      method: "GET",
      ...params,
    });

  /**
   * @description Get all critical countries with comprehensive data
   *
   * @tags dbtn/module:critical_countries, dbtn/hasAuth
   * @name get_all_critical_countries
   * @summary Get All Critical Countries
   * @request GET:/routes/critical-countries
   */
  get_all_critical_countries = (params: RequestParams = {}) =>
    this.request<GetAllCriticalCountriesData, any>({
      path: `/routes/critical-countries`,
      method: "GET",
      ...params,
    });

  /**
   * @description Create a new critical country
   *
   * @tags dbtn/module:critical_countries, dbtn/hasAuth
   * @name create_critical_country
   * @summary Create Critical Country
   * @request POST:/routes/critical-countries
   */
  create_critical_country = (data: CriticalCountryCreate, params: RequestParams = {}) =>
    this.request<CreateCriticalCountryData, CreateCriticalCountryError>({
      path: `/routes/critical-countries`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Update a critical country
   *
   * @tags dbtn/module:critical_countries, dbtn/hasAuth
   * @name update_critical_country
   * @summary Update Critical Country
   * @request PUT:/routes/critical-countries/{countryId}
   */
  update_critical_country = (
    { countryId, ...query }: UpdateCriticalCountryParams,
    data: CriticalCountryUpdate,
    params: RequestParams = {},
  ) =>
    this.request<UpdateCriticalCountryData, UpdateCriticalCountryError>({
      path: `/routes/critical-countries/${countryId}`,
      method: "PUT",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Delete a critical country
   *
   * @tags dbtn/module:critical_countries, dbtn/hasAuth
   * @name delete_critical_country
   * @summary Delete Critical Country
   * @request DELETE:/routes/critical-countries/{countryId}
   */
  delete_critical_country = ({ countryId, ...query }: DeleteCriticalCountryParams, params: RequestParams = {}) =>
    this.request<DeleteCriticalCountryData, DeleteCriticalCountryError>({
      path: `/routes/critical-countries/${countryId}`,
      method: "DELETE",
      ...params,
    });

  /**
   * @description Generate PDF report for individual customer screening
   *
   * @tags dbtn/module:pdf_reports, dbtn/hasAuth
   * @name generate_individual_report
   * @summary Generate Individual Report
   * @request POST:/routes/generate-individual-report
   */
  generate_individual_report = (data: IndividualReportRequest, params: RequestParams = {}) =>
    this.request<GenerateIndividualReportData, GenerateIndividualReportError>({
      path: `/routes/generate-individual-report`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Generate PDF report for batch customer screening
   *
   * @tags dbtn/module:pdf_reports, dbtn/hasAuth
   * @name generate_batch_report
   * @summary Generate Batch Report
   * @request POST:/routes/generate-batch-report
   */
  generate_batch_report = (data: BatchReportRequest, params: RequestParams = {}) =>
    this.request<GenerateBatchReportData, GenerateBatchReportError>({
      path: `/routes/generate-batch-report`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Generate PDF report for country risk analysis
   *
   * @tags dbtn/module:pdf_reports, dbtn/hasAuth
   * @name generate_country_report
   * @summary Generate Country Report
   * @request POST:/routes/generate-country-report
   */
  generate_country_report = (data: CountryReportRequest, params: RequestParams = {}) =>
    this.request<GenerateCountryReportData, GenerateCountryReportError>({
      path: `/routes/generate-country-report`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Export critical countries data in various formats
   *
   * @tags stream, dbtn/module:export, dbtn/hasAuth
   * @name export_critical_countries
   * @summary Export Critical Countries
   * @request POST:/routes/export/critical-countries
   */
  export_critical_countries = (data: ExportRequest, params: RequestParams = {}) =>
    this.requestStream<ExportCriticalCountriesData, ExportCriticalCountriesError>({
      path: `/routes/export/critical-countries`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Create a new customer transaction
   *
   * @tags dbtn/module:customer_transactions, dbtn/hasAuth
   * @name create_transaction
   * @summary Create Transaction
   * @request POST:/routes/customer-transactions/transactions
   */
  create_transaction = (data: CustomerTransactionInput, params: RequestParams = {}) =>
    this.request<CreateTransactionData, CreateTransactionError>({
      path: `/routes/customer-transactions/transactions`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description List customer transactions with filtering
   *
   * @tags dbtn/module:customer_transactions, dbtn/hasAuth
   * @name list_transactions
   * @summary List Transactions
   * @request GET:/routes/customer-transactions/transactions
   */
  list_transactions = (query: ListTransactionsParams, params: RequestParams = {}) =>
    this.request<ListTransactionsData, ListTransactionsError>({
      path: `/routes/customer-transactions/transactions`,
      method: "GET",
      query: query,
      ...params,
    });

  /**
   * @description Update an existing transaction
   *
   * @tags dbtn/module:customer_transactions, dbtn/hasAuth
   * @name update_transaction
   * @summary Update Transaction
   * @request PUT:/routes/customer-transactions/transactions/{transaction_id}
   */
  update_transaction = (
    { transactionId, ...query }: UpdateTransactionParams,
    data: CustomerTransactionInput,
    params: RequestParams = {},
  ) =>
    this.request<UpdateTransactionData, UpdateTransactionError>({
      path: `/routes/customer-transactions/transactions/${transactionId}`,
      method: "PUT",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Delete a transaction
   *
   * @tags dbtn/module:customer_transactions, dbtn/hasAuth
   * @name delete_transaction
   * @summary Delete Transaction
   * @request DELETE:/routes/customer-transactions/transactions/{transaction_id}
   */
  delete_transaction = ({ transactionId, ...query }: DeleteTransactionParams, params: RequestParams = {}) =>
    this.request<DeleteTransactionData, DeleteTransactionError>({
      path: `/routes/customer-transactions/transactions/${transactionId}`,
      method: "DELETE",
      ...params,
    });

  /**
   * @description Get current monitoring configuration for the user
   *
   * @tags dbtn/module:background_monitoring, dbtn/hasAuth
   * @name get_monitoring_configuration
   * @summary Get Monitoring Configuration
   * @request GET:/routes/background-monitoring/configuration
   */
  get_monitoring_configuration = (params: RequestParams = {}) =>
    this.request<GetMonitoringConfigurationData, any>({
      path: `/routes/background-monitoring/configuration`,
      method: "GET",
      ...params,
    });

  /**
   * @description Save monitoring configuration
   *
   * @tags dbtn/module:background_monitoring, dbtn/hasAuth
   * @name save_monitoring_configuration
   * @summary Save Monitoring Configuration
   * @request POST:/routes/background-monitoring/configuration
   */
  save_monitoring_configuration = (data: MonitoringConfiguration, params: RequestParams = {}) =>
    this.request<SaveMonitoringConfigurationData, SaveMonitoringConfigurationError>({
      path: `/routes/background-monitoring/configuration`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Get current monitoring status and report
   *
   * @tags dbtn/module:background_monitoring, dbtn/hasAuth
   * @name get_monitoring_status
   * @summary Get Monitoring Status
   * @request GET:/routes/background-monitoring/status
   */
  get_monitoring_status = (params: RequestParams = {}) =>
    this.request<GetMonitoringStatusData, any>({
      path: `/routes/background-monitoring/status`,
      method: "GET",
      ...params,
    });

  /**
   * @description Manually trigger monitoring for specific customers or all
   *
   * @tags dbtn/module:background_monitoring, dbtn/hasAuth
   * @name trigger_monitoring
   * @summary Trigger Monitoring
   * @request POST:/routes/background-monitoring/trigger
   */
  trigger_monitoring = (data: TriggerMonitoringRequest, params: RequestParams = {}) =>
    this.request<TriggerMonitoringData, TriggerMonitoringError>({
      path: `/routes/background-monitoring/trigger`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Get recent background monitoring job statuses
   *
   * @tags dbtn/module:background_monitoring, dbtn/hasAuth
   * @name get_background_jobs
   * @summary Get Background Jobs
   * @request GET:/routes/background-monitoring/jobs
   */
  get_background_jobs = (query: GetBackgroundJobsParams, params: RequestParams = {}) =>
    this.request<GetBackgroundJobsData, GetBackgroundJobsError>({
      path: `/routes/background-monitoring/jobs`,
      method: "GET",
      query: query,
      ...params,
    });

  /**
   * @description Get monitoring history for a specific customer
   *
   * @tags dbtn/module:background_monitoring, dbtn/hasAuth
   * @name get_customer_monitoring_history
   * @summary Get Customer Monitoring History
   * @request GET:/routes/background-monitoring/customer/{customer_id}/history
   */
  get_customer_monitoring_history = (
    { customerId, ...query }: GetCustomerMonitoringHistoryParams,
    params: RequestParams = {},
  ) =>
    this.request<GetCustomerMonitoringHistoryData, GetCustomerMonitoringHistoryError>({
      path: `/routes/background-monitoring/customer/${customerId}/history`,
      method: "GET",
      query: query,
      ...params,
    });

  /**
   * @description Get monitoring system health metrics
   *
   * @tags dbtn/module:background_monitoring, dbtn/hasAuth
   * @name get_monitoring_system_health
   * @summary Get Monitoring System Health
   * @request GET:/routes/background-monitoring/health
   */
  get_monitoring_system_health = (params: RequestParams = {}) =>
    this.request<GetMonitoringSystemHealthData, any>({
      path: `/routes/background-monitoring/health`,
      method: "GET",
      ...params,
    });

  /**
   * @description List all monitoring schedules for the current user.
   *
   * @tags dbtn/module:monitoring, dbtn/hasAuth
   * @name list_monitoring_schedules
   * @summary List Monitoring Schedules
   * @request GET:/routes/monitoring/schedules
   */
  list_monitoring_schedules = (params: RequestParams = {}) =>
    this.request<ListMonitoringSchedulesData, any>({
      path: `/routes/monitoring/schedules`,
      method: "GET",
      ...params,
    });

  /**
   * @description Create a new automated monitoring schedule.
   *
   * @tags dbtn/module:monitoring, dbtn/hasAuth
   * @name create_monitoring_schedule
   * @summary Create Monitoring Schedule
   * @request POST:/routes/monitoring/schedules
   */
  create_monitoring_schedule = (data: CreateMonitoringScheduleRequest, params: RequestParams = {}) =>
    this.request<CreateMonitoringScheduleData, CreateMonitoringScheduleError>({
      path: `/routes/monitoring/schedules`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Get a specific monitoring schedule.
   *
   * @tags dbtn/module:monitoring, dbtn/hasAuth
   * @name get_monitoring_schedule
   * @summary Get Monitoring Schedule
   * @request GET:/routes/monitoring/schedules/{schedule_id}
   */
  get_monitoring_schedule = ({ scheduleId, ...query }: GetMonitoringScheduleParams, params: RequestParams = {}) =>
    this.request<GetMonitoringScheduleData, GetMonitoringScheduleError>({
      path: `/routes/monitoring/schedules/${scheduleId}`,
      method: "GET",
      ...params,
    });

  /**
   * @description Update a monitoring schedule.
   *
   * @tags dbtn/module:monitoring, dbtn/hasAuth
   * @name update_monitoring_schedule
   * @summary Update Monitoring Schedule
   * @request PUT:/routes/monitoring/schedules/{schedule_id}
   */
  update_monitoring_schedule = (
    { scheduleId, ...query }: UpdateMonitoringScheduleParams,
    data: UpdateMonitoringScheduleRequest,
    params: RequestParams = {},
  ) =>
    this.request<UpdateMonitoringScheduleData, UpdateMonitoringScheduleError>({
      path: `/routes/monitoring/schedules/${scheduleId}`,
      method: "PUT",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Delete a monitoring schedule.
   *
   * @tags dbtn/module:monitoring, dbtn/hasAuth
   * @name delete_monitoring_schedule
   * @summary Delete Monitoring Schedule
   * @request DELETE:/routes/monitoring/schedules/{schedule_id}
   */
  delete_monitoring_schedule = ({ scheduleId, ...query }: DeleteMonitoringScheduleParams, params: RequestParams = {}) =>
    this.request<DeleteMonitoringScheduleData, DeleteMonitoringScheduleError>({
      path: `/routes/monitoring/schedules/${scheduleId}`,
      method: "DELETE",
      ...params,
    });

  /**
   * @description List automation jobs for the current user.
   *
   * @tags dbtn/module:monitoring, dbtn/hasAuth
   * @name list_automation_jobs
   * @summary List Automation Jobs
   * @request GET:/routes/monitoring/jobs
   */
  list_automation_jobs = (query: ListAutomationJobsParams, params: RequestParams = {}) =>
    this.request<ListAutomationJobsData, ListAutomationJobsError>({
      path: `/routes/monitoring/jobs`,
      method: "GET",
      query: query,
      ...params,
    });

  /**
   * @description Get a specific automation job.
   *
   * @tags dbtn/module:monitoring, dbtn/hasAuth
   * @name get_automation_job
   * @summary Get Automation Job
   * @request GET:/routes/monitoring/jobs/{job_id}
   */
  get_automation_job = ({ jobId, ...query }: GetAutomationJobParams, params: RequestParams = {}) =>
    this.request<GetAutomationJobData, GetAutomationJobError>({
      path: `/routes/monitoring/jobs/${jobId}`,
      method: "GET",
      ...params,
    });

  /**
   * @description Get notification preferences for the current user.
   *
   * @tags dbtn/module:monitoring, dbtn/hasAuth
   * @name get_notification_preferences
   * @summary Get Notification Preferences
   * @request GET:/routes/monitoring/notification-preferences
   */
  get_notification_preferences = (params: RequestParams = {}) =>
    this.request<GetNotificationPreferencesData, any>({
      path: `/routes/monitoring/notification-preferences`,
      method: "GET",
      ...params,
    });

  /**
   * @description Update notification preferences for the current user.
   *
   * @tags dbtn/module:monitoring, dbtn/hasAuth
   * @name update_notification_preferences
   * @summary Update Notification Preferences
   * @request PUT:/routes/monitoring/notification-preferences
   */
  update_notification_preferences = (data: NotificationPreferencesRequest, params: RequestParams = {}) =>
    this.request<UpdateNotificationPreferencesData, UpdateNotificationPreferencesError>({
      path: `/routes/monitoring/notification-preferences`,
      method: "PUT",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Manually trigger a screening job for a specific schedule.
   *
   * @tags dbtn/module:monitoring, dbtn/hasAuth
   * @name trigger_manual_screening
   * @summary Trigger Manual Screening
   * @request POST:/routes/monitoring/trigger-screening/{schedule_id}
   */
  trigger_manual_screening = ({ scheduleId, ...query }: TriggerManualScreeningParams, params: RequestParams = {}) =>
    this.request<TriggerManualScreeningData, TriggerManualScreeningError>({
      path: `/routes/monitoring/trigger-screening/${scheduleId}`,
      method: "POST",
      ...params,
    });

  /**
   * @description Update risk assessments for customers based on latest screening results
   *
   * @tags dbtn/module:monitoring, dbtn/hasAuth
   * @name update_risk_assessments
   * @summary Update Risk Assessments
   * @request POST:/routes/monitoring/update-risk-assessments
   */
  update_risk_assessments = (data: UpdateRiskAssessmentsRequest, params: RequestParams = {}) =>
    this.request<UpdateRiskAssessmentsData, UpdateRiskAssessmentsError>({
      path: `/routes/monitoring/update-risk-assessments`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Schedule automated risk assessment updates
   *
   * @tags dbtn/module:monitoring, dbtn/hasAuth
   * @name schedule_risk_assessments
   * @summary Schedule Risk Assessments
   * @request POST:/routes/monitoring/schedule-risk-assessments
   */
  schedule_risk_assessments = (data: ScheduleRiskAssessmentsRequest, params: RequestParams = {}) =>
    this.request<ScheduleRiskAssessmentsData, ScheduleRiskAssessmentsError>({
      path: `/routes/monitoring/schedule-risk-assessments`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Generate predictive risk scores for customers using historical data patterns
   *
   * @tags dbtn/module:predictive_analytics, dbtn/hasAuth
   * @name predict_customer_risks
   * @summary Predict Customer Risks
   * @request POST:/routes/predictive-analytics/predict-customer-risks
   */
  predict_customer_risks = (data: PredictiveRiskRequest, params: RequestParams = {}) =>
    this.request<PredictCustomerRisksData, PredictCustomerRisksError>({
      path: `/routes/predictive-analytics/predict-customer-risks`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Analyze risk trends over time for pattern recognition
   *
   * @tags dbtn/module:predictive_analytics, dbtn/hasAuth
   * @name analyze_risk_trends
   * @summary Analyze Risk Trends
   * @request POST:/routes/predictive-analytics/analyze-risk-trends
   */
  analyze_risk_trends = (data: RiskTrendAnalysisRequest, params: RequestParams = {}) =>
    this.request<AnalyzeRiskTrendsData, AnalyzeRiskTrendsError>({
      path: `/routes/predictive-analytics/analyze-risk-trends`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Evaluate the performance of the predictive risk model
   *
   * @tags dbtn/module:predictive_analytics, dbtn/hasAuth
   * @name get_model_performance
   * @summary Get Model Performance
   * @request GET:/routes/predictive-analytics/model-performance
   */
  get_model_performance = (data: ModelPerformanceRequest, params: RequestParams = {}) =>
    this.request<GetModelPerformanceData, GetModelPerformanceError>({
      path: `/routes/predictive-analytics/model-performance`,
      method: "GET",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Upload a document with metadata and store securely
   *
   * @tags dbtn/module:document_management, dbtn/hasAuth
   * @name upload_customer_document
   * @summary Upload Customer Document
   * @request POST:/routes/documents/upload
   */
  upload_customer_document = (data: BodyUploadCustomerDocument, params: RequestParams = {}) =>
    this.request<UploadCustomerDocumentData, UploadCustomerDocumentError>({
      path: `/routes/documents/upload`,
      method: "POST",
      body: data,
      type: ContentType.FormData,
      ...params,
    });

  /**
   * @description List documents with filtering and pagination
   *
   * @tags dbtn/module:document_management, dbtn/hasAuth
   * @name list_customer_documents
   * @summary List Customer Documents
   * @request POST:/routes/documents/list
   */
  list_customer_documents = (data: DocumentListRequest, params: RequestParams = {}) =>
    this.request<ListCustomerDocumentsData, ListCustomerDocumentsError>({
      path: `/routes/documents/list`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Approve or reject a document
   *
   * @tags dbtn/module:document_management, dbtn/hasAuth
   * @name approve_document
   * @summary Approve Document
   * @request POST:/routes/documents/approve
   */
  approve_document = (data: DocumentApprovalRequest, params: RequestParams = {}) =>
    this.request<ApproveDocumentData, ApproveDocumentError>({
      path: `/routes/documents/approve`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Get document management analytics
   *
   * @tags dbtn/module:document_management, dbtn/hasAuth
   * @name get_customer_document_analytics
   * @summary Get Customer Document Analytics
   * @request GET:/routes/documents/analytics
   */
  get_customer_document_analytics = (params: RequestParams = {}) =>
    this.request<GetCustomerDocumentAnalyticsData, any>({
      path: `/routes/documents/analytics`,
      method: "GET",
      ...params,
    });

  /**
   * @description List all classification notes, optionally filtered by tree_id and/or module_type
   *
   * @tags dbtn/module:classification_notes, dbtn/hasAuth
   * @name list_classification_notes
   * @summary List Classification Notes
   * @request GET:/routes/classification/notes/list
   */
  list_classification_notes = (query: ListClassificationNotesParams, params: RequestParams = {}) =>
    this.request<ListClassificationNotesData, ListClassificationNotesError>({
      path: `/routes/classification/notes/list`,
      method: "GET",
      query: query,
      ...params,
    });

  /**
   * @description Create a new classification note
   *
   * @tags dbtn/module:classification_notes, dbtn/hasAuth
   * @name create_classification_note
   * @summary Create Classification Note
   * @request POST:/routes/classification/notes/create
   */
  create_classification_note = (data: CreateNoteRequest, params: RequestParams = {}) =>
    this.request<CreateClassificationNoteData, CreateClassificationNoteError>({
      path: `/routes/classification/notes/create`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Get a classification note by its key
   *
   * @tags dbtn/module:classification_notes, dbtn/hasAuth
   * @name get_classification_note_by_key
   * @summary Get Classification Note By Key
   * @request GET:/routes/classification/notes/get/{note_key}
   */
  get_classification_note_by_key = (
    { noteKey, ...query }: GetClassificationNoteByKeyParams,
    params: RequestParams = {},
  ) =>
    this.request<GetClassificationNoteByKeyData, GetClassificationNoteByKeyError>({
      path: `/routes/classification/notes/get/${noteKey}`,
      method: "GET",
      ...params,
    });

  /**
   * @description Update a classification note
   *
   * @tags dbtn/module:classification_notes, dbtn/hasAuth
   * @name update_classification_note
   * @summary Update Classification Note
   * @request PUT:/routes/classification/notes/update/{note_id}
   */
  update_classification_note = (
    { noteId, ...query }: UpdateClassificationNoteParams,
    data: UpdateNoteRequest,
    params: RequestParams = {},
  ) =>
    this.request<UpdateClassificationNoteData, UpdateClassificationNoteError>({
      path: `/routes/classification/notes/update/${noteId}`,
      method: "PUT",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Delete a classification note
   *
   * @tags dbtn/module:classification_notes, dbtn/hasAuth
   * @name delete_classification_note
   * @summary Delete Classification Note
   * @request DELETE:/routes/classification/notes/delete/{note_id}
   */
  delete_classification_note = ({ noteId, ...query }: DeleteClassificationNoteParams, params: RequestParams = {}) =>
    this.request<DeleteClassificationNoteData, DeleteClassificationNoteError>({
      path: `/routes/classification/notes/delete/${noteId}`,
      method: "DELETE",
      ...params,
    });

  /**
   * @description Get the screening explanation content for the Sanctions & Embargoes screening tab
   *
   * @tags dbtn/module:classification_notes, dbtn/hasAuth
   * @name get_screening_explanation
   * @summary Get Screening Explanation
   * @request GET:/routes/classification/notes/screening-explanation
   */
  get_screening_explanation = (params: RequestParams = {}) =>
    this.request<GetScreeningExplanationData, any>({
      path: `/routes/classification/notes/screening-explanation`,
      method: "GET",
      ...params,
    });

  /**
   * @description Create or update the screening explanation content for the Sanctions & Embargoes screening tab
   *
   * @tags dbtn/module:classification_notes, dbtn/hasAuth
   * @name create_or_update_screening_explanation
   * @summary Create Or Update Screening Explanation
   * @request POST:/routes/classification/notes/screening-explanation
   */
  create_or_update_screening_explanation = (data: CreateNoteRequest, params: RequestParams = {}) =>
    this.request<CreateOrUpdateScreeningExplanationData, CreateOrUpdateScreeningExplanationError>({
      path: `/routes/classification/notes/screening-explanation`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Create a new customer product/technology record
   *
   * @tags dbtn/module:customer_products, dbtn/hasAuth
   * @name create_product
   * @summary Create Product
   * @request POST:/routes/customer-products/products
   */
  create_product = (data: CustomerProduct, params: RequestParams = {}) =>
    this.request<CreateProductData, CreateProductError>({
      path: `/routes/customer-products/products`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description List customer products with filtering
   *
   * @tags dbtn/module:customer_products, dbtn/hasAuth
   * @name list_products
   * @summary List Products
   * @request GET:/routes/customer-products/products
   */
  list_products = (query: ListProductsParams, params: RequestParams = {}) =>
    this.request<ListProductsData, ListProductsError>({
      path: `/routes/customer-products/products`,
      method: "GET",
      query: query,
      ...params,
    });

  /**
   * @description Update an existing product
   *
   * @tags dbtn/module:customer_products, dbtn/hasAuth
   * @name update_product
   * @summary Update Product
   * @request PUT:/routes/customer-products/products/{product_id}
   */
  update_product = ({ productId, ...query }: UpdateProductParams, data: CustomerProduct, params: RequestParams = {}) =>
    this.request<UpdateProductData, UpdateProductError>({
      path: `/routes/customer-products/products/${productId}`,
      method: "PUT",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Delete a product
   *
   * @tags dbtn/module:customer_products, dbtn/hasAuth
   * @name delete_product
   * @summary Delete Product
   * @request DELETE:/routes/customer-products/products/{product_id}
   */
  delete_product = ({ productId, ...query }: DeleteProductParams, params: RequestParams = {}) =>
    this.request<DeleteProductData, DeleteProductError>({
      path: `/routes/customer-products/products/${productId}`,
      method: "DELETE",
      ...params,
    });

  /**
   * @description Update product review status and compliance information
   *
   * @tags dbtn/module:customer_products, dbtn/hasAuth
   * @name update_product_review
   * @summary Update Product Review
   * @request PATCH:/routes/customer-products/products/{product_id}/review
   */
  update_product_review = (
    { productId, ...query }: UpdateProductReviewParams,
    data: ProductReviewUpdate,
    params: RequestParams = {},
  ) =>
    this.request<UpdateProductReviewData, UpdateProductReviewError>({
      path: `/routes/customer-products/products/${productId}/review`,
      method: "PATCH",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Get list of unique product categories
   *
   * @tags dbtn/module:customer_products, dbtn/hasAuth
   * @name get_customer_product_categories
   * @summary Get Customer Product Categories
   * @request GET:/routes/customer-products/products/categories
   */
  get_customer_product_categories = (params: RequestParams = {}) =>
    this.request<GetCustomerProductCategoriesData, any>({
      path: `/routes/customer-products/products/categories`,
      method: "GET",
      ...params,
    });

  /**
   * @description Search product classifications for export control compliance
   *
   * @tags dbtn/module:product_classification, dbtn/hasAuth
   * @name search_products
   * @summary Search Products
   * @request POST:/routes/products/search
   */
  search_products = (data: ProductSearchRequest, params: RequestParams = {}) =>
    this.request<SearchProductsData, SearchProductsError>({
      path: `/routes/products/search`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Get detailed classification information for a specific product
   *
   * @tags dbtn/module:product_classification, dbtn/hasAuth
   * @name get_product_classification
   * @summary Get Product Classification
   * @request GET:/routes/product/{product_id}
   */
  get_product_classification = ({ productId, ...query }: GetProductClassificationParams, params: RequestParams = {}) =>
    this.request<GetProductClassificationData, GetProductClassificationError>({
      path: `/routes/product/${productId}`,
      method: "GET",
      ...params,
    });

  /**
   * @description Get list of available control regimes
   *
   * @tags dbtn/module:product_classification, dbtn/hasAuth
   * @name get_control_regimes
   * @summary Get Control Regimes
   * @request GET:/routes/control-regimes
   */
  get_control_regimes = (params: RequestParams = {}) =>
    this.request<GetControlRegimesData, any>({
      path: `/routes/control-regimes`,
      method: "GET",
      ...params,
    });

  /**
   * @description Get list of available product categories
   *
   * @tags dbtn/module:product_classification, dbtn/hasAuth
   * @name get_classification_categories
   * @summary Get Classification Categories
   * @request GET:/routes/classification-categories
   */
  get_classification_categories = (params: RequestParams = {}) =>
    this.request<GetClassificationCategoriesData, any>({
      path: `/routes/classification-categories`,
      method: "GET",
      ...params,
    });

  /**
   * @description Get list of available risk levels for products
   *
   * @tags dbtn/module:product_classification, dbtn/hasAuth
   * @name get_product_risk_levels
   * @summary Get Product Risk Levels
   * @request GET:/routes/products/risk-levels
   */
  get_product_risk_levels = (params: RequestParams = {}) =>
    this.request<GetProductRiskLevelsData, any>({
      path: `/routes/products/risk-levels`,
      method: "GET",
      ...params,
    });

  /**
   * @description Get comprehensive monitoring dashboard summary with key metrics
   *
   * @tags dbtn/module:monitoring_analytics, dbtn/hasAuth
   * @name get_monitoring_dashboard_summary
   * @summary Get Monitoring Dashboard Summary
   * @request GET:/routes/monitoring-analytics/dashboard-summary
   */
  get_monitoring_dashboard_summary = (params: RequestParams = {}) =>
    this.request<GetMonitoringDashboardSummaryData, any>({
      path: `/routes/monitoring-analytics/dashboard-summary`,
      method: "GET",
      ...params,
    });

  /**
   * @description Get detailed customer monitoring analytics and distribution metrics
   *
   * @tags dbtn/module:monitoring_analytics, dbtn/hasAuth
   * @name get_customer_monitoring_analytics
   * @summary Get Customer Monitoring Analytics
   * @request GET:/routes/monitoring-analytics/customer-analytics
   */
  get_customer_monitoring_analytics = (params: RequestParams = {}) =>
    this.request<GetCustomerMonitoringAnalyticsData, any>({
      path: `/routes/monitoring-analytics/customer-analytics`,
      method: "GET",
      ...params,
    });

  /**
   * @description Get detailed screening performance metrics
   *
   * @tags dbtn/module:monitoring_analytics, dbtn/hasAuth
   * @name get_screening_performance_metrics
   * @summary Get Screening Performance Metrics
   * @request GET:/routes/monitoring-analytics/screening-metrics
   */
  get_screening_performance_metrics = (query: GetScreeningPerformanceMetricsParams, params: RequestParams = {}) =>
    this.request<GetScreeningPerformanceMetricsData, GetScreeningPerformanceMetricsError>({
      path: `/routes/monitoring-analytics/screening-metrics`,
      method: "GET",
      query: query,
      ...params,
    });

  /**
   * @description Get automation system performance metrics
   *
   * @tags dbtn/module:monitoring_analytics, dbtn/hasAuth
   * @name get_automation_performance_metrics
   * @summary Get Automation Performance Metrics
   * @request GET:/routes/monitoring-analytics/automation-performance
   */
  get_automation_performance_metrics = (params: RequestParams = {}) =>
    this.request<GetAutomationPerformanceMetricsData, any>({
      path: `/routes/monitoring-analytics/automation-performance`,
      method: "GET",
      ...params,
    });

  /**
   * @description Get compliance and regulatory metrics
   *
   * @tags dbtn/module:monitoring_analytics, dbtn/hasAuth
   * @name get_compliance_regulatory_metrics
   * @summary Get Compliance Regulatory Metrics
   * @request GET:/routes/monitoring-analytics/compliance-metrics
   */
  get_compliance_regulatory_metrics = (params: RequestParams = {}) =>
    this.request<GetComplianceRegulatoryMetricsData, any>({
      path: `/routes/monitoring-analytics/compliance-metrics`,
      method: "GET",
      ...params,
    });

  /**
   * @description Get alert system analytics and metrics
   *
   * @tags dbtn/module:monitoring_analytics, dbtn/hasAuth
   * @name get_monitoring_alert_analytics
   * @summary Get Monitoring Alert Analytics
   * @request GET:/routes/monitoring-analytics/alert-analytics
   */
  get_monitoring_alert_analytics = (params: RequestParams = {}) =>
    this.request<GetMonitoringAlertAnalyticsData, any>({
      path: `/routes/monitoring-analytics/alert-analytics`,
      method: "GET",
      ...params,
    });

  /**
   * @description Get trend analysis data for various metrics
   *
   * @tags dbtn/module:monitoring_analytics, dbtn/hasAuth
   * @name get_trend_analysis
   * @summary Get Trend Analysis
   * @request GET:/routes/monitoring-analytics/trend-analysis
   */
  get_trend_analysis = (query: GetTrendAnalysisParams, params: RequestParams = {}) =>
    this.request<GetTrendAnalysisData, GetTrendAnalysisError>({
      path: `/routes/monitoring-analytics/trend-analysis`,
      method: "GET",
      query: query,
      ...params,
    });

  /**
   * @description Save an article to user's saved collection
   *
   * @tags dbtn/module:saved_articles, dbtn/hasAuth
   * @name save_article
   * @summary Save Article
   * @request POST:/routes/save-article
   */
  save_article = (data: SaveArticleRequest, params: RequestParams = {}) =>
    this.request<SaveArticleData, SaveArticleError>({
      path: `/routes/save-article`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Remove an article from user's saved collection
   *
   * @tags dbtn/module:saved_articles, dbtn/hasAuth
   * @name unsave_article
   * @summary Unsave Article
   * @request DELETE:/routes/unsave-article/{document_id}
   */
  unsave_article = ({ documentId, ...query }: UnsaveArticleParams, params: RequestParams = {}) =>
    this.request<UnsaveArticleData, UnsaveArticleError>({
      path: `/routes/unsave-article/${documentId}`,
      method: "DELETE",
      ...params,
    });

  /**
   * @description Get all saved articles for the current user, optionally filtered by category
   *
   * @tags dbtn/module:saved_articles, dbtn/hasAuth
   * @name get_saved_articles
   * @summary Get Saved Articles
   * @request GET:/routes/saved-articles
   */
  get_saved_articles = (query: GetSavedArticlesParams, params: RequestParams = {}) =>
    this.request<GetSavedArticlesData, GetSavedArticlesError>({
      path: `/routes/saved-articles`,
      method: "GET",
      query: query,
      ...params,
    });

  /**
   * @description Check if a document is saved by the user
   *
   * @tags dbtn/module:saved_articles, dbtn/hasAuth
   * @name check_if_saved
   * @summary Check If Saved
   * @request GET:/routes/check-saved/{document_id}
   */
  check_if_saved = ({ documentId, ...query }: CheckIfSavedParams, params: RequestParams = {}) =>
    this.request<CheckIfSavedData, CheckIfSavedError>({
      path: `/routes/check-saved/${documentId}`,
      method: "GET",
      ...params,
    });

  /**
   * @description Get all categories for the current user with article counts
   *
   * @tags dbtn/module:saved_articles, dbtn/hasAuth
   * @name get_article_categories
   * @summary Get Article Categories
   * @request GET:/routes/categories
   */
  get_article_categories = (params: RequestParams = {}) =>
    this.request<GetArticleCategoriesData, any>({
      path: `/routes/categories`,
      method: "GET",
      ...params,
    });

  /**
   * @description Create a new article category for the user
   *
   * @tags dbtn/module:saved_articles, dbtn/hasAuth
   * @name create_article_category
   * @summary Create Article Category
   * @request POST:/routes/categories
   */
  create_article_category = (data: AppApisSavedArticlesCategoryRequest, params: RequestParams = {}) =>
    this.request<CreateArticleCategoryData, CreateArticleCategoryError>({
      path: `/routes/categories`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Update an existing category
   *
   * @tags dbtn/module:saved_articles, dbtn/hasAuth
   * @name update_article_category
   * @summary Update Article Category
   * @request PUT:/routes/categories/{category_id}
   */
  update_article_category = (
    { categoryId, ...query }: UpdateArticleCategoryParams,
    data: AppApisSavedArticlesCategoryRequest,
    params: RequestParams = {},
  ) =>
    this.request<UpdateArticleCategoryData, UpdateArticleCategoryError>({
      path: `/routes/categories/${categoryId}`,
      method: "PUT",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Delete a category (only if it has no articles)
   *
   * @tags dbtn/module:saved_articles, dbtn/hasAuth
   * @name delete_article_category
   * @summary Delete Article Category
   * @request DELETE:/routes/categories/{category_id}
   */
  delete_article_category = ({ categoryId, ...query }: DeleteArticleCategoryParams, params: RequestParams = {}) =>
    this.request<DeleteArticleCategoryData, DeleteArticleCategoryError>({
      path: `/routes/categories/${categoryId}`,
      method: "DELETE",
      ...params,
    });

  /**
   * @description Assign categories to an existing saved article
   *
   * @tags dbtn/module:saved_articles, dbtn/hasAuth
   * @name assign_categories_to_article
   * @summary Assign Categories To Article
   * @request PUT:/routes/saved-articles/{article_id}/categories
   */
  assign_categories_to_article = (
    { articleId, ...query }: AssignCategoriesToArticleParams,
    data: AssignCategoriesRequest,
    params: RequestParams = {},
  ) =>
    this.request<AssignCategoriesToArticleData, AssignCategoriesToArticleError>({
      path: `/routes/saved-articles/${articleId}/categories`,
      method: "PUT",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Create a new support request from a user. This creates a task in the admin dashboard for review.
   *
   * @tags dbtn/module:support_system, dbtn/hasAuth
   * @name create_support_request
   * @summary Create Support Request
   * @request POST:/routes/request
   */
  create_support_request = (data: SupportRequestCreate, params: RequestParams = {}) =>
    this.request<CreateSupportRequestData, CreateSupportRequestError>({
      path: `/routes/request`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Get all support tickets for the current user. Optionally filter by status: 'open', 'in_progress', 'resolved', 'closed'
   *
   * @tags dbtn/module:support_system, dbtn/hasAuth
   * @name get_user_support_tickets
   * @summary Get User Support Tickets
   * @request GET:/routes/my-tickets
   */
  get_user_support_tickets = (query: GetUserSupportTicketsParams, params: RequestParams = {}) =>
    this.request<GetUserSupportTicketsData, GetUserSupportTicketsError>({
      path: `/routes/my-tickets`,
      method: "GET",
      query: query,
      ...params,
    });

  /**
   * @description Get all support tickets for admin review. Optionally filter by status and/or priority.
   *
   * @tags dbtn/module:support_system, dbtn/hasAuth
   * @name get_admin_support_tickets
   * @summary Get Admin Support Tickets
   * @request GET:/routes/admin/tickets
   */
  get_admin_support_tickets = (query: GetAdminSupportTicketsParams, params: RequestParams = {}) =>
    this.request<GetAdminSupportTicketsData, GetAdminSupportTicketsError>({
      path: `/routes/admin/tickets`,
      method: "GET",
      query: query,
      ...params,
    });

  /**
   * @description Admin responds to a support ticket and optionally updates status. Sends email notification to the user.
   *
   * @tags dbtn/module:support_system, dbtn/hasAuth
   * @name admin_respond_to_ticket
   * @summary Admin Respond To Ticket
   * @request POST:/routes/admin/tickets/{ticket_id}/respond
   */
  admin_respond_to_ticket = (
    { ticketId, ...query }: AdminRespondToTicketParams,
    data: AdminSupportResponse,
    params: RequestParams = {},
  ) =>
    this.request<AdminRespondToTicketData, AdminRespondToTicketError>({
      path: `/routes/admin/tickets/${ticketId}/respond`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Get detailed information about a specific support ticket for admin review.
   *
   * @tags dbtn/module:support_system, dbtn/hasAuth
   * @name get_support_ticket_detail
   * @summary Get Support Ticket Detail
   * @request GET:/routes/admin/tickets/{ticket_id}
   */
  get_support_ticket_detail = ({ ticketId, ...query }: GetSupportTicketDetailParams, params: RequestParams = {}) =>
    this.request<GetSupportTicketDetailData, GetSupportTicketDetailError>({
      path: `/routes/admin/tickets/${ticketId}`,
      method: "GET",
      ...params,
    });

  /**
   * @description Get all component pricing configurations
   *
   * @tags dbtn/module:pricing_configuration, dbtn/hasAuth
   * @name get_component_pricing
   * @summary Get Component Pricing
   * @request GET:/routes/admin/pricing/components
   */
  get_component_pricing = (params: RequestParams = {}) =>
    this.request<GetComponentPricingData, any>({
      path: `/routes/admin/pricing/components`,
      method: "GET",
      ...params,
    });

  /**
   * @description Create new component pricing
   *
   * @tags dbtn/module:pricing_configuration, dbtn/hasAuth
   * @name create_component_pricing
   * @summary Create Component Pricing
   * @request POST:/routes/admin/pricing/components
   */
  create_component_pricing = (data: CreatePricingRequest, params: RequestParams = {}) =>
    this.request<CreateComponentPricingData, CreateComponentPricingError>({
      path: `/routes/admin/pricing/components`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Update component pricing
   *
   * @tags dbtn/module:pricing_configuration, dbtn/hasAuth
   * @name update_component_pricing
   * @summary Update Component Pricing
   * @request PUT:/routes/admin/pricing/components/{pricing_id}
   */
  update_component_pricing = (
    { pricingId, ...query }: UpdateComponentPricingParams,
    data: UpdatePricingRequest,
    params: RequestParams = {},
  ) =>
    this.request<UpdateComponentPricingData, UpdateComponentPricingError>({
      path: `/routes/admin/pricing/components/${pricingId}`,
      method: "PUT",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Delete component pricing configuration
   *
   * @tags dbtn/module:pricing_configuration, dbtn/hasAuth
   * @name delete_component_pricing
   * @summary Delete Component Pricing
   * @request DELETE:/routes/admin/pricing/components/{pricing_id}
   */
  delete_component_pricing = ({ pricingId, ...query }: DeleteComponentPricingParams, params: RequestParams = {}) =>
    this.request<DeleteComponentPricingData, DeleteComponentPricingError>({
      path: `/routes/admin/pricing/components/${pricingId}`,
      method: "DELETE",
      ...params,
    });

  /**
   * @description Get all pricing feature flags
   *
   * @tags dbtn/module:pricing_configuration, dbtn/hasAuth
   * @name get_pricing_feature_flags
   * @summary Get Pricing Feature Flags
   * @request GET:/routes/admin/pricing/feature-flags
   */
  get_pricing_feature_flags = (params: RequestParams = {}) =>
    this.request<GetPricingFeatureFlagsData, any>({
      path: `/routes/admin/pricing/feature-flags`,
      method: "GET",
      ...params,
    });

  /**
   * @description Update pricing feature flag for a component
   *
   * @tags dbtn/module:pricing_configuration, dbtn/hasAuth
   * @name update_pricing_feature_flag
   * @summary Update Pricing Feature Flag
   * @request PUT:/routes/admin/pricing/feature-flags/{component_name}
   */
  update_pricing_feature_flag = (
    { componentName, ...query }: UpdatePricingFeatureFlagParams,
    data: UpdateFeatureFlagRequest,
    params: RequestParams = {},
  ) =>
    this.request<UpdatePricingFeatureFlagData, UpdatePricingFeatureFlagError>({
      path: `/routes/admin/pricing/feature-flags/${componentName}`,
      method: "PUT",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Check if an action requires credits and how much
   *
   * @tags dbtn/module:pricing_configuration, dbtn/hasAuth
   * @name check_action_pricing
   * @summary Check Action Pricing
   * @request GET:/routes/pricing/check/{component_name}/{action_name}
   */
  check_action_pricing = (
    { componentName, actionName, ...query }: CheckActionPricingParams,
    params: RequestParams = {},
  ) =>
    this.request<CheckActionPricingData, CheckActionPricingError>({
      path: `/routes/pricing/check/${componentName}/${actionName}`,
      method: "GET",
      ...params,
    });

  /**
   * @description Get all usage tier pricing configurations
   *
   * @tags dbtn/module:pricing_configuration, dbtn/hasAuth
   * @name get_usage_tier_pricing
   * @summary Get Usage Tier Pricing
   * @request GET:/routes/admin/pricing/usage-tiers
   */
  get_usage_tier_pricing = (params: RequestParams = {}) =>
    this.request<GetUsageTierPricingData, any>({
      path: `/routes/admin/pricing/usage-tiers`,
      method: "GET",
      ...params,
    });

  /**
   * @description Create new usage tier pricing
   *
   * @tags dbtn/module:pricing_configuration, dbtn/hasAuth
   * @name create_usage_tier_pricing
   * @summary Create Usage Tier Pricing
   * @request POST:/routes/admin/pricing/usage-tiers
   */
  create_usage_tier_pricing = (data: CreateUsageTierPricingPayload, params: RequestParams = {}) =>
    this.request<CreateUsageTierPricingData, CreateUsageTierPricingError>({
      path: `/routes/admin/pricing/usage-tiers`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Get all geographic pricing configurations
   *
   * @tags dbtn/module:pricing_configuration, dbtn/hasAuth
   * @name get_geographic_pricing
   * @summary Get Geographic Pricing
   * @request GET:/routes/admin/pricing/geographic
   */
  get_geographic_pricing = (params: RequestParams = {}) =>
    this.request<GetGeographicPricingData, any>({
      path: `/routes/admin/pricing/geographic`,
      method: "GET",
      ...params,
    });

  /**
   * @description Create new geographic pricing
   *
   * @tags dbtn/module:pricing_configuration, dbtn/hasAuth
   * @name create_geographic_pricing
   * @summary Create Geographic Pricing
   * @request POST:/routes/admin/pricing/geographic
   */
  create_geographic_pricing = (data: CreateGeographicPricingPayload, params: RequestParams = {}) =>
    this.request<CreateGeographicPricingData, CreateGeographicPricingError>({
      path: `/routes/admin/pricing/geographic`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Get all hybrid pricing model configurations
   *
   * @tags dbtn/module:pricing_configuration, dbtn/hasAuth
   * @name get_hybrid_pricing_models
   * @summary Get Hybrid Pricing Models
   * @request GET:/routes/admin/pricing/hybrid-models
   */
  get_hybrid_pricing_models = (params: RequestParams = {}) =>
    this.request<GetHybridPricingModelsData, any>({
      path: `/routes/admin/pricing/hybrid-models`,
      method: "GET",
      ...params,
    });

  /**
   * @description Create new hybrid pricing model
   *
   * @tags dbtn/module:pricing_configuration, dbtn/hasAuth
   * @name create_hybrid_pricing_model
   * @summary Create Hybrid Pricing Model
   * @request POST:/routes/admin/pricing/hybrid-models
   */
  create_hybrid_pricing_model = (data: CreateHybridPricingModelPayload, params: RequestParams = {}) =>
    this.request<CreateHybridPricingModelData, CreateHybridPricingModelError>({
      path: `/routes/admin/pricing/hybrid-models`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Advanced pricing check with tier, geographic, and hybrid model support
   *
   * @tags dbtn/module:pricing_configuration, dbtn/hasAuth
   * @name check_dynamic_pricing
   * @summary Check Dynamic Pricing
   * @request GET:/routes/pricing/dynamic-check/{component_name}/{action_name}
   */
  check_dynamic_pricing = (
    { componentName, actionName, ...query }: CheckDynamicPricingParams,
    params: RequestParams = {},
  ) =>
    this.request<CheckDynamicPricingData, CheckDynamicPricingError>({
      path: `/routes/pricing/dynamic-check/${componentName}/${actionName}`,
      method: "GET",
      query: query,
      ...params,
    });

  /**
   * @description Get comprehensive invoice history with filtering
   *
   * @tags dbtn/module:billing_management, dbtn/hasAuth
   * @name get_invoice_history
   * @summary Get Invoice History
   * @request GET:/routes/billing-management/invoice-history
   */
  get_invoice_history = (query: GetInvoiceHistoryParams, params: RequestParams = {}) =>
    this.request<GetInvoiceHistoryData, GetInvoiceHistoryError>({
      path: `/routes/billing-management/invoice-history`,
      method: "GET",
      query: query,
      ...params,
    });

  /**
   * @description Create a new invoice (Admin only)
   *
   * @tags dbtn/module:billing_management, dbtn/hasAuth
   * @name create_invoice
   * @summary Create Invoice
   * @request POST:/routes/billing-management/create-invoice
   */
  create_invoice = (data: CreateInvoiceRequest, params: RequestParams = {}) =>
    this.request<CreateInvoiceData, CreateInvoiceError>({
      path: `/routes/billing-management/create-invoice`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Get usage analytics for billing insights
   *
   * @tags dbtn/module:billing_management, dbtn/hasAuth
   * @name get_usage_analytics
   * @summary Get Usage Analytics
   * @request GET:/routes/billing-management/usage-analytics
   */
  get_usage_analytics = (query: GetUsageAnalyticsParams, params: RequestParams = {}) =>
    this.request<GetUsageAnalyticsData, GetUsageAnalyticsError>({
      path: `/routes/billing-management/usage-analytics`,
      method: "GET",
      query: query,
      ...params,
    });

  /**
   * @description Download invoice as PDF
   *
   * @tags dbtn/module:billing_management, dbtn/hasAuth
   * @name download_invoice
   * @summary Download Invoice
   * @request GET:/routes/billing-management/download-invoice/{invoice_id}
   */
  download_invoice = ({ invoiceId, ...query }: DownloadInvoiceParams, params: RequestParams = {}) =>
    this.request<DownloadInvoiceData, DownloadInvoiceError>({
      path: `/routes/billing-management/download-invoice/${invoiceId}`,
      method: "GET",
      ...params,
    });

  /**
   * @description Update invoice status (Admin only)
   *
   * @tags dbtn/module:billing_management, dbtn/hasAuth
   * @name update_invoice_status
   * @summary Update Invoice Status
   * @request PUT:/routes/billing-management/invoices/{invoice_id}/status
   */
  update_invoice_status = ({ invoiceId, ...query }: UpdateInvoiceStatusParams, params: RequestParams = {}) =>
    this.request<UpdateInvoiceStatusData, UpdateInvoiceStatusError>({
      path: `/routes/billing-management/invoices/${invoiceId}/status`,
      method: "PUT",
      query: query,
      ...params,
    });

  /**
   * @description Get billing summary for dashboard
   *
   * @tags dbtn/module:billing_management, dbtn/hasAuth
   * @name get_billing_summary
   * @summary Get Billing Summary
   * @request GET:/routes/billing-management/billing-summary
   */
  get_billing_summary = (query: GetBillingSummaryParams, params: RequestParams = {}) =>
    this.request<GetBillingSummaryData, GetBillingSummaryError>({
      path: `/routes/billing-management/billing-summary`,
      method: "GET",
      query: query,
      ...params,
    });

  /**
   * @description Get billing settings and preferences
   *
   * @tags dbtn/module:billing_management, dbtn/hasAuth
   * @name get_billing_settings
   * @summary Get Billing Settings
   * @request GET:/routes/billing-management/billing-settings
   */
  get_billing_settings = (query: GetBillingSettingsParams, params: RequestParams = {}) =>
    this.request<GetBillingSettingsData, GetBillingSettingsError>({
      path: `/routes/billing-management/billing-settings`,
      method: "GET",
      query: query,
      ...params,
    });

  /**
   * @description Update billing settings and preferences
   *
   * @tags dbtn/module:billing_management, dbtn/hasAuth
   * @name update_billing_settings
   * @summary Update Billing Settings
   * @request PUT:/routes/billing-management/billing-settings
   */
  update_billing_settings = (
    query: UpdateBillingSettingsParams,
    data: UpdateBillingSettingsRequest,
    params: RequestParams = {},
  ) =>
    this.request<UpdateBillingSettingsData, UpdateBillingSettingsError>({
      path: `/routes/billing-management/billing-settings`,
      method: "PUT",
      query: query,
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Create a new risk assessment template (Admin only)
   *
   * @tags dbtn/module:risk_templates, dbtn/hasAuth
   * @name create_template
   * @summary Create Template
   * @request POST:/routes/templates/create
   */
  create_template = (data: CreateTemplateRequest, params: RequestParams = {}) =>
    this.request<CreateTemplateData, CreateTemplateError>({
      path: `/routes/templates/create`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description List all risk assessment templates
   *
   * @tags dbtn/module:risk_templates, dbtn/hasAuth
   * @name list_templates
   * @summary List Templates
   * @request GET:/routes/templates
   */
  list_templates = (params: RequestParams = {}) =>
    this.request<ListTemplatesData, any>({
      path: `/routes/templates`,
      method: "GET",
      ...params,
    });

  /**
   * @description Get a specific template by ID
   *
   * @tags dbtn/module:risk_templates, dbtn/hasAuth
   * @name get_template
   * @summary Get Template
   * @request GET:/routes/template/{template_id}
   */
  get_template = ({ templateId, ...query }: GetTemplateParams, params: RequestParams = {}) =>
    this.request<GetTemplateData, GetTemplateError>({
      path: `/routes/template/${templateId}`,
      method: "GET",
      ...params,
    });

  /**
   * @description Update a template (Admin only)
   *
   * @tags dbtn/module:risk_templates, dbtn/hasAuth
   * @name update_template
   * @summary Update Template
   * @request PUT:/routes/template/{template_id}
   */
  update_template = (
    { templateId, ...query }: UpdateTemplateParams,
    data: UpdateTemplateRequest,
    params: RequestParams = {},
  ) =>
    this.request<UpdateTemplateData, UpdateTemplateError>({
      path: `/routes/template/${templateId}`,
      method: "PUT",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Delete a template (Admin only)
   *
   * @tags dbtn/module:risk_templates, dbtn/hasAuth
   * @name delete_template
   * @summary Delete Template
   * @request DELETE:/routes/template/{template_id}
   */
  delete_template = ({ templateId, ...query }: DeleteTemplateParams, params: RequestParams = {}) =>
    this.request<DeleteTemplateData, DeleteTemplateError>({
      path: `/routes/template/${templateId}`,
      method: "DELETE",
      ...params,
    });

  /**
   * @description Create a customized version of a template for a company
   *
   * @tags dbtn/module:risk_templates, dbtn/hasAuth
   * @name customize_template
   * @summary Customize Template
   * @request POST:/routes/customize
   */
  customize_template = (data: CustomizeTemplateRequest, params: RequestParams = {}) =>
    this.request<CustomizeTemplateData, CustomizeTemplateError>({
      path: `/routes/customize`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description List all customized forms for the current user's company
   *
   * @tags dbtn/module:risk_templates, dbtn/hasAuth
   * @name list_company_forms
   * @summary List Company Forms
   * @request GET:/routes/company-forms
   */
  list_company_forms = (params: RequestParams = {}) =>
    this.request<ListCompanyFormsData, any>({
      path: `/routes/company-forms`,
      method: "GET",
      ...params,
    });

  /**
   * @description Get all metadata options for a specific category (jurisdiction/type/subject)
   *
   * @tags dbtn/module:document_metadata, dbtn/hasAuth
   * @name get_document_metadata_options
   * @summary Get Document Metadata Options
   * @request GET:/routes/doc-metadata/metadata-options/{category}
   */
  get_document_metadata_options = (
    { category, ...query }: GetDocumentMetadataOptionsParams,
    params: RequestParams = {},
  ) =>
    this.request<GetDocumentMetadataOptionsData, GetDocumentMetadataOptionsError>({
      path: `/routes/doc-metadata/metadata-options/${category}`,
      method: "GET",
      ...params,
    });

  /**
   * @description Get all metadata options grouped by category
   *
   * @tags dbtn/module:document_metadata, dbtn/hasAuth
   * @name get_all_document_metadata_options
   * @summary Get All Document Metadata Options
   * @request GET:/routes/doc-metadata/metadata-options
   */
  get_all_document_metadata_options = (params: RequestParams = {}) =>
    this.request<GetAllDocumentMetadataOptionsData, any>({
      path: `/routes/doc-metadata/metadata-options`,
      method: "GET",
      ...params,
    });

  /**
   * @description Create a new metadata option
   *
   * @tags dbtn/module:document_metadata, dbtn/hasAuth
   * @name create_document_metadata_option
   * @summary Create Document Metadata Option
   * @request POST:/routes/doc-metadata/metadata-options
   */
  create_document_metadata_option = (data: CreateMetadataOptionRequest, params: RequestParams = {}) =>
    this.request<CreateDocumentMetadataOptionData, CreateDocumentMetadataOptionError>({
      path: `/routes/doc-metadata/metadata-options`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Update an existing metadata option
   *
   * @tags dbtn/module:document_metadata, dbtn/hasAuth
   * @name update_document_metadata_option
   * @summary Update Document Metadata Option
   * @request PUT:/routes/doc-metadata/metadata-options/{option_id}
   */
  update_document_metadata_option = (
    { optionId, ...query }: UpdateDocumentMetadataOptionParams,
    data: UpdateMetadataOptionRequest,
    params: RequestParams = {},
  ) =>
    this.request<UpdateDocumentMetadataOptionData, UpdateDocumentMetadataOptionError>({
      path: `/routes/doc-metadata/metadata-options/${optionId}`,
      method: "PUT",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Delete a metadata option (soft delete by setting is_active to false)
   *
   * @tags dbtn/module:document_metadata, dbtn/hasAuth
   * @name delete_document_metadata_option
   * @summary Delete Document Metadata Option
   * @request DELETE:/routes/doc-metadata/metadata-options/{option_id}
   */
  delete_document_metadata_option = (
    { optionId, ...query }: DeleteDocumentMetadataOptionParams,
    params: RequestParams = {},
  ) =>
    this.request<DeleteDocumentMetadataOptionData, DeleteDocumentMetadataOptionError>({
      path: `/routes/doc-metadata/metadata-options/${optionId}`,
      method: "DELETE",
      ...params,
    });

  /**
   * @description Bulk update display orders for drag-and-drop reordering
   *
   * @tags dbtn/module:document_metadata, dbtn/hasAuth
   * @name reorder_document_metadata_options
   * @summary Reorder Document Metadata Options
   * @request PUT:/routes/doc-metadata/metadata-options/{category}/reorder
   */
  reorder_document_metadata_options = (
    { category, ...query }: ReorderDocumentMetadataOptionsParams,
    data: BulkReorderRequest,
    params: RequestParams = {},
  ) =>
    this.request<ReorderDocumentMetadataOptionsData, ReorderDocumentMetadataOptionsError>({
      path: `/routes/doc-metadata/metadata-options/${category}/reorder`,
      method: "PUT",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Bulk import metadata options from structured data
   *
   * @tags dbtn/module:document_metadata, dbtn/hasAuth
   * @name bulk_import_metadata_options
   * @summary Bulk Import Metadata Options
   * @request POST:/routes/doc-metadata/metadata-options/{category}/bulk-import
   */
  bulk_import_metadata_options = (
    { category, ...query }: BulkImportMetadataOptionsParams,
    data: AppApisDocumentMetadataBulkImportRequest,
    params: RequestParams = {},
  ) =>
    this.request<BulkImportMetadataOptionsData, BulkImportMetadataOptionsError>({
      path: `/routes/doc-metadata/metadata-options/${category}/bulk-import`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Export metadata options in a structured format for backup/transfer
   *
   * @tags dbtn/module:document_metadata, dbtn/hasAuth
   * @name export_metadata_options
   * @summary Export Metadata Options
   * @request GET:/routes/doc-metadata/metadata-options/{category}/export
   */
  export_metadata_options = ({ category, ...query }: ExportMetadataOptionsParams, params: RequestParams = {}) =>
    this.request<ExportMetadataOptionsData, ExportMetadataOptionsError>({
      path: `/routes/doc-metadata/metadata-options/${category}/export`,
      method: "GET",
      ...params,
    });

  /**
   * @description Get all sections for a document (admin version with all fields)
   *
   * @tags dbtn/module:document_sections, dbtn/hasAuth
   * @name get_document_sections_admin
   * @summary Get Document Sections Admin
   * @request GET:/routes/doc-sections/documents/{document_id}/sections
   */
  get_document_sections_admin = (
    { documentId, ...query }: GetDocumentSectionsAdminParams,
    params: RequestParams = {},
  ) =>
    this.request<GetDocumentSectionsAdminData, GetDocumentSectionsAdminError>({
      path: `/routes/doc-sections/documents/${documentId}/sections`,
      method: "GET",
      ...params,
    });

  /**
   * @description Create a new document section
   *
   * @tags dbtn/module:document_sections, dbtn/hasAuth
   * @name create_document_section
   * @summary Create Document Section
   * @request POST:/routes/doc-sections/documents/{document_id}/sections
   */
  create_document_section = (
    { documentId, ...query }: CreateDocumentSectionParams,
    data: CreateSectionRequest,
    params: RequestParams = {},
  ) =>
    this.request<CreateDocumentSectionData, CreateDocumentSectionError>({
      path: `/routes/doc-sections/documents/${documentId}/sections`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Update an existing document section
   *
   * @tags dbtn/module:document_sections, dbtn/hasAuth
   * @name update_document_section
   * @summary Update Document Section
   * @request PUT:/routes/doc-sections/sections/{section_id}
   */
  update_document_section = (
    { sectionId, ...query }: UpdateDocumentSectionParams,
    data: UpdateSectionRequest,
    params: RequestParams = {},
  ) =>
    this.request<UpdateDocumentSectionData, UpdateDocumentSectionError>({
      path: `/routes/doc-sections/sections/${sectionId}`,
      method: "PUT",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Delete a document section
   *
   * @tags dbtn/module:document_sections, dbtn/hasAuth
   * @name delete_document_section
   * @summary Delete Document Section
   * @request DELETE:/routes/doc-sections/sections/{section_id}
   */
  delete_document_section = ({ sectionId, ...query }: DeleteDocumentSectionParams, params: RequestParams = {}) =>
    this.request<DeleteDocumentSectionData, DeleteDocumentSectionError>({
      path: `/routes/doc-sections/sections/${sectionId}`,
      method: "DELETE",
      ...params,
    });

  /**
   * @description Bulk update section display orders for drag-and-drop reordering
   *
   * @tags dbtn/module:document_sections, dbtn/hasAuth
   * @name reorder_sections
   * @summary Reorder Sections
   * @request PUT:/routes/doc-sections/documents/{document_id}/sections/reorder
   */
  reorder_sections = (
    { documentId, ...query }: ReorderSectionsParams,
    data: BulkUpdateOrderRequest,
    params: RequestParams = {},
  ) =>
    this.request<ReorderSectionsData, ReorderSectionsError>({
      path: `/routes/doc-sections/documents/${documentId}/sections/reorder`,
      method: "PUT",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Bulk import sections from structured data
   *
   * @tags dbtn/module:document_sections, dbtn/hasAuth
   * @name bulk_import_sections
   * @summary Bulk Import Sections
   * @request POST:/routes/doc-sections/documents/{document_id}/sections/bulk-import
   */
  bulk_import_sections = (
    { documentId, ...query }: BulkImportSectionsParams,
    data: AppApisDocumentSectionsBulkImportRequest,
    params: RequestParams = {},
  ) =>
    this.request<BulkImportSectionsData, BulkImportSectionsError>({
      path: `/routes/doc-sections/documents/${documentId}/sections/bulk-import`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Export document sections in a structured format for backup/transfer
   *
   * @tags dbtn/module:document_sections, dbtn/hasAuth
   * @name export_sections
   * @summary Export Sections
   * @request GET:/routes/doc-sections/documents/{document_id}/sections/export
   */
  export_sections = ({ documentId, ...query }: ExportSectionsParams, params: RequestParams = {}) =>
    this.request<ExportSectionsData, ExportSectionsError>({
      path: `/routes/doc-sections/documents/${documentId}/sections/export`,
      method: "GET",
      ...params,
    });

  /**
   * @description Update the sections_not_applicable flag for a document
   *
   * @tags dbtn/module:document_sections, dbtn/hasAuth
   * @name update_sections_not_applicable
   * @summary Update Sections Not Applicable
   * @request POST:/routes/doc-sections/documents/{document_id}/sections-not-applicable
   */
  update_sections_not_applicable = (
    { documentId, ...query }: UpdateSectionsNotApplicableParams,
    data: SectionsNotApplicableRequest,
    params: RequestParams = {},
  ) =>
    this.request<UpdateSectionsNotApplicableData, UpdateSectionsNotApplicableError>({
      path: `/routes/doc-sections/documents/${documentId}/sections-not-applicable`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Get the sections_not_applicable flag for a document
   *
   * @tags dbtn/module:document_sections, dbtn/hasAuth
   * @name get_sections_not_applicable
   * @summary Get Sections Not Applicable
   * @request GET:/routes/doc-sections/documents/{document_id}/sections-not-applicable
   */
  get_sections_not_applicable = (
    { documentId, ...query }: GetSectionsNotApplicableParams,
    params: RequestParams = {},
  ) =>
    this.request<GetSectionsNotApplicableData, GetSectionsNotApplicableError>({
      path: `/routes/doc-sections/documents/${documentId}/sections-not-applicable`,
      method: "GET",
      ...params,
    });

  /**
   * @description Get paginated list of documents with their pricing information
   *
   * @tags dbtn/module:document_pricing, dbtn/hasAuth
   * @name get_document_pricing
   * @summary Get Document Pricing
   * @request GET:/routes/doc-pricing/document-pricing
   */
  get_document_pricing = (query: GetDocumentPricingParams, params: RequestParams = {}) =>
    this.request<GetDocumentPricingData, GetDocumentPricingError>({
      path: `/routes/doc-pricing/document-pricing`,
      method: "GET",
      query: query,
      ...params,
    });

  /**
   * @description Update pricing for a specific document
   *
   * @tags dbtn/module:document_pricing, dbtn/hasAuth
   * @name update_document_pricing
   * @summary Update Document Pricing
   * @request PUT:/routes/doc-pricing/document-pricing/{document_id}
   */
  update_document_pricing = (
    { documentId, ...query }: UpdateDocumentPricingParams,
    data: DocumentPricingUpdate,
    params: RequestParams = {},
  ) =>
    this.request<UpdateDocumentPricingData, UpdateDocumentPricingError>({
      path: `/routes/doc-pricing/document-pricing/${documentId}`,
      method: "PUT",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Update pricing for multiple documents
   *
   * @tags dbtn/module:document_pricing, dbtn/hasAuth
   * @name update_bulk_pricing
   * @summary Update Bulk Pricing
   * @request PUT:/routes/doc-pricing/bulk-pricing
   */
  update_bulk_pricing = (data: BulkPricingUpdate, params: RequestParams = {}) =>
    this.request<UpdateBulkPricingData, UpdateBulkPricingError>({
      path: `/routes/doc-pricing/bulk-pricing`,
      method: "PUT",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Apply default pricing rules to documents matching criteria
   *
   * @tags dbtn/module:document_pricing, dbtn/hasAuth
   * @name apply_default_pricing
   * @summary Apply Default Pricing
   * @request POST:/routes/doc-pricing/apply-default-pricing
   */
  apply_default_pricing = (data: DefaultPricingRule, params: RequestParams = {}) =>
    this.request<ApplyDefaultPricingData, ApplyDefaultPricingError>({
      path: `/routes/doc-pricing/apply-default-pricing`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Get pricing analytics from the view
   *
   * @tags dbtn/module:document_pricing, dbtn/hasAuth
   * @name get_pricing_analytics
   * @summary Get Pricing Analytics
   * @request GET:/routes/doc-pricing/pricing-analytics
   */
  get_pricing_analytics = (params: RequestParams = {}) =>
    this.request<GetPricingAnalyticsData, any>({
      path: `/routes/doc-pricing/pricing-analytics`,
      method: "GET",
      ...params,
    });

  /**
   * @description Get pricing details for a specific document
   *
   * @tags dbtn/module:document_pricing, dbtn/hasAuth
   * @name get_document_pricing_detail
   * @summary Get Document Pricing Detail
   * @request GET:/routes/doc-pricing/document/{document_id}/pricing
   */
  get_document_pricing_detail = (
    { documentId, ...query }: GetDocumentPricingDetailParams,
    params: RequestParams = {},
  ) =>
    this.request<GetDocumentPricingDetailData, GetDocumentPricingDetailError>({
      path: `/routes/doc-pricing/document/${documentId}/pricing`,
      method: "GET",
      ...params,
    });

  /**
   * @description List all sanctions trees for admin management
   *
   * @tags dbtn/module:sanctions, dbtn/hasAuth
   * @name list_sanctions_trees
   * @summary List Sanctions Trees
   * @request GET:/routes/sanctions/admin/trees
   */
  list_sanctions_trees = (params: RequestParams = {}) =>
    this.request<ListSanctionsTreesData, any>({
      path: `/routes/sanctions/admin/trees`,
      method: "GET",
      ...params,
    });

  /**
   * @description Create a new sanctions tree
   *
   * @tags dbtn/module:sanctions, dbtn/hasAuth
   * @name create_sanctions_tree
   * @summary Create Sanctions Tree
   * @request POST:/routes/sanctions/admin/trees
   */
  create_sanctions_tree = (data: SanctionsTreeCreate, params: RequestParams = {}) =>
    this.request<CreateSanctionsTreeData, CreateSanctionsTreeError>({
      path: `/routes/sanctions/admin/trees`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Get a specific sanctions tree
   *
   * @tags dbtn/module:sanctions, dbtn/hasAuth
   * @name get_sanctions_tree
   * @summary Get Sanctions Tree
   * @request GET:/routes/sanctions/admin/trees/{tree_id}
   */
  get_sanctions_tree = ({ treeId, ...query }: GetSanctionsTreeParams, params: RequestParams = {}) =>
    this.request<GetSanctionsTreeData, GetSanctionsTreeError>({
      path: `/routes/sanctions/admin/trees/${treeId}`,
      method: "GET",
      ...params,
    });

  /**
   * @description Update a sanctions tree
   *
   * @tags dbtn/module:sanctions, dbtn/hasAuth
   * @name update_sanctions_tree
   * @summary Update Sanctions Tree
   * @request PUT:/routes/sanctions/admin/trees/{tree_id}
   */
  update_sanctions_tree = (
    { treeId, ...query }: UpdateSanctionsTreeParams,
    data: SanctionsTreeUpdate,
    params: RequestParams = {},
  ) =>
    this.request<UpdateSanctionsTreeData, UpdateSanctionsTreeError>({
      path: `/routes/sanctions/admin/trees/${treeId}`,
      method: "PUT",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Delete a sanctions tree
   *
   * @tags dbtn/module:sanctions, dbtn/hasAuth
   * @name delete_sanctions_tree
   * @summary Delete Sanctions Tree
   * @request DELETE:/routes/sanctions/admin/trees/{tree_id}
   */
  delete_sanctions_tree = ({ treeId, ...query }: DeleteSanctionsTreeParams, params: RequestParams = {}) =>
    this.request<DeleteSanctionsTreeData, DeleteSanctionsTreeError>({
      path: `/routes/sanctions/admin/trees/${treeId}`,
      method: "DELETE",
      ...params,
    });

  /**
   * @description Duplicate a sanctions tree with all its nodes and options
   *
   * @tags dbtn/module:sanctions, dbtn/hasAuth
   * @name duplicate_sanctions_tree
   * @summary Duplicate Sanctions Tree
   * @request POST:/routes/sanctions/admin/trees/{tree_id}/duplicate
   */
  duplicate_sanctions_tree = ({ treeId, ...query }: DuplicateSanctionsTreeParams, params: RequestParams = {}) =>
    this.request<DuplicateSanctionsTreeData, DuplicateSanctionsTreeError>({
      path: `/routes/sanctions/admin/trees/${treeId}/duplicate`,
      method: "POST",
      ...params,
    });

  /**
   * @description List all nodes for a specific sanctions tree
   *
   * @tags dbtn/module:sanctions, dbtn/hasAuth
   * @name list_sanctions_nodes
   * @summary List Sanctions Nodes
   * @request GET:/routes/sanctions/admin/trees/{tree_id}/nodes
   */
  list_sanctions_nodes = ({ treeId, ...query }: ListSanctionsNodesParams, params: RequestParams = {}) =>
    this.request<ListSanctionsNodesData, ListSanctionsNodesError>({
      path: `/routes/sanctions/admin/trees/${treeId}/nodes`,
      method: "GET",
      ...params,
    });

  /**
   * @description Create a new node in a sanctions tree
   *
   * @tags dbtn/module:sanctions, dbtn/hasAuth
   * @name create_sanctions_node
   * @summary Create Sanctions Node
   * @request POST:/routes/sanctions/admin/trees/{tree_id}/nodes
   */
  create_sanctions_node = (
    { treeId, ...query }: CreateSanctionsNodeParams,
    data: SanctionsNodeCreate,
    params: RequestParams = {},
  ) =>
    this.request<CreateSanctionsNodeData, CreateSanctionsNodeError>({
      path: `/routes/sanctions/admin/trees/${treeId}/nodes`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Get a specific sanctions node
   *
   * @tags dbtn/module:sanctions, dbtn/hasAuth
   * @name get_sanctions_node
   * @summary Get Sanctions Node
   * @request GET:/routes/sanctions/admin/trees/{tree_id}/nodes/{node_id}
   */
  get_sanctions_node = ({ treeId, nodeId, ...query }: GetSanctionsNodeParams, params: RequestParams = {}) =>
    this.request<GetSanctionsNodeData, GetSanctionsNodeError>({
      path: `/routes/sanctions/admin/trees/${treeId}/nodes/${nodeId}`,
      method: "GET",
      ...params,
    });

  /**
   * @description Update a sanctions node
   *
   * @tags dbtn/module:sanctions, dbtn/hasAuth
   * @name update_sanctions_node
   * @summary Update Sanctions Node
   * @request PUT:/routes/sanctions/admin/trees/{tree_id}/nodes/{node_id}
   */
  update_sanctions_node = (
    { treeId, nodeId, ...query }: UpdateSanctionsNodeParams,
    data: SanctionsNodeUpdate,
    params: RequestParams = {},
  ) =>
    this.request<UpdateSanctionsNodeData, UpdateSanctionsNodeError>({
      path: `/routes/sanctions/admin/trees/${treeId}/nodes/${nodeId}`,
      method: "PUT",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Delete a sanctions node
   *
   * @tags dbtn/module:sanctions, dbtn/hasAuth
   * @name delete_sanctions_node
   * @summary Delete Sanctions Node
   * @request DELETE:/routes/sanctions/admin/trees/{tree_id}/nodes/{node_id}
   */
  delete_sanctions_node = ({ treeId, nodeId, ...query }: DeleteSanctionsNodeParams, params: RequestParams = {}) =>
    this.request<DeleteSanctionsNodeData, DeleteSanctionsNodeError>({
      path: `/routes/sanctions/admin/trees/${treeId}/nodes/${nodeId}`,
      method: "DELETE",
      ...params,
    });

  /**
   * @description Duplicate a sanctions node with all its options
   *
   * @tags dbtn/module:sanctions, dbtn/hasAuth
   * @name duplicate_sanctions_node
   * @summary Duplicate Sanctions Node
   * @request POST:/routes/sanctions/admin/trees/{tree_id}/nodes/{node_id}/duplicate
   */
  duplicate_sanctions_node = ({ treeId, nodeId, ...query }: DuplicateSanctionsNodeParams, params: RequestParams = {}) =>
    this.request<DuplicateSanctionsNodeData, DuplicateSanctionsNodeError>({
      path: `/routes/sanctions/admin/trees/${treeId}/nodes/${nodeId}/duplicate`,
      method: "POST",
      ...params,
    });

  /**
   * @description List all options for a specific sanctions node
   *
   * @tags dbtn/module:sanctions, dbtn/hasAuth
   * @name list_sanctions_node_options
   * @summary List Sanctions Node Options
   * @request GET:/routes/sanctions/admin/trees/{tree_id}/nodes/{node_id}/options
   */
  list_sanctions_node_options = (
    { treeId, nodeId, ...query }: ListSanctionsNodeOptionsParams,
    params: RequestParams = {},
  ) =>
    this.request<ListSanctionsNodeOptionsData, ListSanctionsNodeOptionsError>({
      path: `/routes/sanctions/admin/trees/${treeId}/nodes/${nodeId}/options`,
      method: "GET",
      ...params,
    });

  /**
   * @description Create a new option for a sanctions node
   *
   * @tags dbtn/module:sanctions, dbtn/hasAuth
   * @name create_sanctions_node_option
   * @summary Create Sanctions Node Option
   * @request POST:/routes/sanctions/admin/trees/{tree_id}/nodes/{node_id}/options
   */
  create_sanctions_node_option = (
    { treeId, nodeId, ...query }: CreateSanctionsNodeOptionParams,
    data: SanctionsNodeOptionCreate,
    params: RequestParams = {},
  ) =>
    this.request<CreateSanctionsNodeOptionData, CreateSanctionsNodeOptionError>({
      path: `/routes/sanctions/admin/trees/${treeId}/nodes/${nodeId}/options`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Get a specific sanctions node option
   *
   * @tags dbtn/module:sanctions, dbtn/hasAuth
   * @name get_sanctions_node_option
   * @summary Get Sanctions Node Option
   * @request GET:/routes/sanctions/admin/trees/{tree_id}/nodes/{node_id}/options/{option_id}
   */
  get_sanctions_node_option = (
    { treeId, nodeId, optionId, ...query }: GetSanctionsNodeOptionParams,
    params: RequestParams = {},
  ) =>
    this.request<GetSanctionsNodeOptionData, GetSanctionsNodeOptionError>({
      path: `/routes/sanctions/admin/trees/${treeId}/nodes/${nodeId}/options/${optionId}`,
      method: "GET",
      ...params,
    });

  /**
   * @description Update a sanctions node option
   *
   * @tags dbtn/module:sanctions, dbtn/hasAuth
   * @name update_sanctions_node_option
   * @summary Update Sanctions Node Option
   * @request PUT:/routes/sanctions/admin/trees/{tree_id}/nodes/{node_id}/options/{option_id}
   */
  update_sanctions_node_option = (
    { treeId, nodeId, optionId, ...query }: UpdateSanctionsNodeOptionParams,
    data: SanctionsNodeOptionUpdate,
    params: RequestParams = {},
  ) =>
    this.request<UpdateSanctionsNodeOptionData, UpdateSanctionsNodeOptionError>({
      path: `/routes/sanctions/admin/trees/${treeId}/nodes/${nodeId}/options/${optionId}`,
      method: "PUT",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Delete a sanctions node option
   *
   * @tags dbtn/module:sanctions, dbtn/hasAuth
   * @name delete_sanctions_node_option
   * @summary Delete Sanctions Node Option
   * @request DELETE:/routes/sanctions/admin/trees/{tree_id}/nodes/{node_id}/options/{option_id}
   */
  delete_sanctions_node_option = (
    { treeId, nodeId, optionId, ...query }: DeleteSanctionsNodeOptionParams,
    params: RequestParams = {},
  ) =>
    this.request<DeleteSanctionsNodeOptionData, DeleteSanctionsNodeOptionError>({
      path: `/routes/sanctions/admin/trees/${treeId}/nodes/${nodeId}/options/${optionId}`,
      method: "DELETE",
      ...params,
    });

  /**
   * @description List all published sanctions trees for user access
   *
   * @tags dbtn/module:sanctions, dbtn/hasAuth
   * @name list_published_sanctions_trees
   * @summary List Published Sanctions Trees
   * @request GET:/routes/sanctions/trees
   */
  list_published_sanctions_trees = (params: RequestParams = {}) =>
    this.request<ListPublishedSanctionsTreesData, any>({
      path: `/routes/sanctions/trees`,
      method: "GET",
      ...params,
    });

  /**
   * @description Get a specific published sanctions tree
   *
   * @tags dbtn/module:sanctions, dbtn/hasAuth
   * @name get_published_sanctions_tree
   * @summary Get Published Sanctions Tree
   * @request GET:/routes/sanctions/trees/{tree_id}
   */
  get_published_sanctions_tree = ({ treeId, ...query }: GetPublishedSanctionsTreeParams, params: RequestParams = {}) =>
    this.request<GetPublishedSanctionsTreeData, GetPublishedSanctionsTreeError>({
      path: `/routes/sanctions/trees/${treeId}`,
      method: "GET",
      ...params,
    });

  /**
   * @description Get all nodes for a published sanctions tree
   *
   * @tags dbtn/module:sanctions, dbtn/hasAuth
   * @name get_published_sanctions_tree_nodes
   * @summary Get Published Sanctions Tree Nodes
   * @request GET:/routes/sanctions/trees/{tree_id}/nodes
   */
  get_published_sanctions_tree_nodes = (
    { treeId, ...query }: GetPublishedSanctionsTreeNodesParams,
    params: RequestParams = {},
  ) =>
    this.request<GetPublishedSanctionsTreeNodesData, GetPublishedSanctionsTreeNodesError>({
      path: `/routes/sanctions/trees/${treeId}/nodes`,
      method: "GET",
      ...params,
    });

  /**
   * @description Get all options for a published sanctions node
   *
   * @tags dbtn/module:sanctions, dbtn/hasAuth
   * @name get_published_sanctions_node_options
   * @summary Get Published Sanctions Node Options
   * @request GET:/routes/sanctions/trees/{tree_id}/nodes/{node_id}/options
   */
  get_published_sanctions_node_options = (
    { treeId, nodeId, ...query }: GetPublishedSanctionsNodeOptionsParams,
    params: RequestParams = {},
  ) =>
    this.request<GetPublishedSanctionsNodeOptionsData, GetPublishedSanctionsNodeOptionsError>({
      path: `/routes/sanctions/trees/${treeId}/nodes/${nodeId}/options`,
      method: "GET",
      ...params,
    });

  /**
   * @description Assess sanctions applicability using tree logic
   *
   * @tags dbtn/module:sanctions, dbtn/hasAuth
   * @name assess_sanctions_applicability
   * @summary Assess Sanctions Applicability
   * @request POST:/routes/sanctions/assess
   */
  assess_sanctions_applicability = (data: SanctionsAssessmentRequest, params: RequestParams = {}) =>
    this.request<AssessSanctionsApplicabilityData, AssessSanctionsApplicabilityError>({
      path: `/routes/sanctions/assess`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Save or update a classification progress
   *
   * @tags dbtn/module:classification_autosave, dbtn/hasAuth
   * @name save_classification
   * @summary Save Classification
   * @request POST:/routes/classification-save/save-classification
   */
  save_classification = (data: SavedClassificationRequest, params: RequestParams = {}) =>
    this.request<SaveClassificationData, SaveClassificationError>({
      path: `/routes/classification-save/save-classification`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description List user's saved classifications
   *
   * @tags dbtn/module:classification_autosave, dbtn/hasAuth
   * @name list_saved_classifications
   * @summary List Saved Classifications
   * @request GET:/routes/classification-save/list-classifications
   */
  list_saved_classifications = (query: ListSavedClassificationsParams, params: RequestParams = {}) =>
    this.request<ListSavedClassificationsData, ListSavedClassificationsError>({
      path: `/routes/classification-save/list-classifications`,
      method: "GET",
      query: query,
      ...params,
    });

  /**
   * @description Load a specific classification
   *
   * @tags dbtn/module:classification_autosave, dbtn/hasAuth
   * @name load_classification
   * @summary Load Classification
   * @request GET:/routes/classification-save/load-classification/{classification_id}
   */
  load_classification = ({ classificationId, ...query }: LoadClassificationParams, params: RequestParams = {}) =>
    this.request<LoadClassificationData, LoadClassificationError>({
      path: `/routes/classification-save/load-classification/${classificationId}`,
      method: "GET",
      ...params,
    });

  /**
   * @description Delete a classification (move to archived)
   *
   * @tags dbtn/module:classification_autosave, dbtn/hasAuth
   * @name delete_classification
   * @summary Delete Classification
   * @request DELETE:/routes/classification-save/delete-classification/{classification_id}
   */
  delete_classification = ({ classificationId, ...query }: DeleteClassificationParams, params: RequestParams = {}) =>
    this.request<DeleteClassificationData, DeleteClassificationError>({
      path: `/routes/classification-save/delete-classification/${classificationId}`,
      method: "DELETE",
      ...params,
    });

  /**
   * @description Restore an archived classification
   *
   * @tags dbtn/module:classification_autosave, dbtn/hasAuth
   * @name restore_classification
   * @summary Restore Classification
   * @request POST:/routes/classification-save/restore-classification/{classification_id}
   */
  restore_classification = ({ classificationId, ...query }: RestoreClassificationParams, params: RequestParams = {}) =>
    this.request<RestoreClassificationData, RestoreClassificationError>({
      path: `/routes/classification-save/restore-classification/${classificationId}`,
      method: "POST",
      ...params,
    });

  /**
   * @description Get pending notifications for classifications
   *
   * @tags dbtn/module:classification_autosave, dbtn/hasAuth
   * @name get_classification_notifications
   * @summary Get Classification Notifications
   * @request GET:/routes/classification-save/notifications
   */
  get_classification_notifications = (params: RequestParams = {}) =>
    this.request<GetClassificationNotificationsData, any>({
      path: `/routes/classification-save/notifications`,
      method: "GET",
      ...params,
    });

  /**
   * @description Background task to archive expired classifications
   *
   * @tags dbtn/module:classification_autosave, dbtn/hasAuth
   * @name cleanup_expired_classifications
   * @summary Cleanup Expired Classifications
   * @request POST:/routes/classification-save/cleanup-expired
   */
  cleanup_expired_classifications = (params: RequestParams = {}) =>
    this.request<CleanupExpiredClassificationsData, any>({
      path: `/routes/classification-save/cleanup-expired`,
      method: "POST",
      ...params,
    });

  /**
   * @description List all badges
   *
   * @tags dbtn/module:badge_management, dbtn/hasAuth
   * @name list_badges
   * @summary List Badges
   * @request GET:/routes/badges/badges
   */
  list_badges = (params: RequestParams = {}) =>
    this.request<ListBadgesData, any>({
      path: `/routes/badges/badges`,
      method: "GET",
      ...params,
    });

  /**
   * @description Create a new badge
   *
   * @tags dbtn/module:badge_management, dbtn/hasAuth
   * @name create_badge
   * @summary Create Badge
   * @request POST:/routes/badges/badges
   */
  create_badge = (data: CreateBadgeRequest, params: RequestParams = {}) =>
    this.request<CreateBadgeData, CreateBadgeError>({
      path: `/routes/badges/badges`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Get a specific badge by ID
   *
   * @tags dbtn/module:badge_management, dbtn/hasAuth
   * @name get_badge
   * @summary Get Badge
   * @request GET:/routes/badges/badges/{badge_id}
   */
  get_badge = ({ badgeId, ...query }: GetBadgeParams, params: RequestParams = {}) =>
    this.request<GetBadgeData, GetBadgeError>({
      path: `/routes/badges/badges/${badgeId}`,
      method: "GET",
      ...params,
    });

  /**
   * @description Update a badge
   *
   * @tags dbtn/module:badge_management, dbtn/hasAuth
   * @name update_badge
   * @summary Update Badge
   * @request PUT:/routes/badges/badges/{badge_id}
   */
  update_badge = ({ badgeId, ...query }: UpdateBadgeParams, data: UpdateBadgeRequest, params: RequestParams = {}) =>
    this.request<UpdateBadgeData, UpdateBadgeError>({
      path: `/routes/badges/badges/${badgeId}`,
      method: "PUT",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Delete a badge
   *
   * @tags dbtn/module:badge_management, dbtn/hasAuth
   * @name delete_badge
   * @summary Delete Badge
   * @request DELETE:/routes/badges/badges/{badge_id}
   */
  delete_badge = ({ badgeId, ...query }: DeleteBadgeParams, params: RequestParams = {}) =>
    this.request<DeleteBadgeData, DeleteBadgeError>({
      path: `/routes/badges/badges/${badgeId}`,
      method: "DELETE",
      ...params,
    });

  /**
   * @description List all badge categories
   *
   * @tags dbtn/module:badge_management, dbtn/hasAuth
   * @name list_badge_categories
   * @summary List Badge Categories
   * @request GET:/routes/badges/badges/categories
   */
  list_badge_categories = (params: RequestParams = {}) =>
    this.request<ListBadgeCategoriesData, any>({
      path: `/routes/badges/badges/categories`,
      method: "GET",
      ...params,
    });

  /**
   * @description Create a new document alert
   *
   * @tags dbtn/module:document_alerts, dbtn/hasAuth
   * @name create_document_alert
   * @summary Create Document Alert
   * @request POST:/routes/doc-alerts/create
   */
  create_document_alert = (data: DocumentAlertCreate, params: RequestParams = {}) =>
    this.request<CreateDocumentAlertData, CreateDocumentAlertError>({
      path: `/routes/doc-alerts/create`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description List document alerts with optional filtering
   *
   * @tags dbtn/module:document_alerts, dbtn/hasAuth
   * @name list_document_alerts
   * @summary List Document Alerts
   * @request GET:/routes/doc-alerts/alerts
   */
  list_document_alerts = (query: ListDocumentAlertsParams, params: RequestParams = {}) =>
    this.request<ListDocumentAlertsData, ListDocumentAlertsError>({
      path: `/routes/doc-alerts/alerts`,
      method: "GET",
      query: query,
      ...params,
    });

  /**
   * @description Get a specific document alert by ID
   *
   * @tags dbtn/module:document_alerts, dbtn/hasAuth
   * @name get_document_alert
   * @summary Get Document Alert
   * @request GET:/routes/doc-alerts/alerts/{alert_id}
   */
  get_document_alert = ({ alertId, ...query }: GetDocumentAlertParams, params: RequestParams = {}) =>
    this.request<GetDocumentAlertData, GetDocumentAlertError>({
      path: `/routes/doc-alerts/alerts/${alertId}`,
      method: "GET",
      ...params,
    });

  /**
   * @description Update the status of a document alert (acknowledge or resolve)
   *
   * @tags dbtn/module:document_alerts, dbtn/hasAuth
   * @name update_alert_status
   * @summary Update Alert Status
   * @request PUT:/routes/doc-alerts/{alert_id}/status
   */
  update_alert_status = (
    { alertId, ...query }: UpdateAlertStatusParams,
    data: DocumentAlertStatusUpdate,
    params: RequestParams = {},
  ) =>
    this.request<UpdateAlertStatusData, UpdateAlertStatusError>({
      path: `/routes/doc-alerts/${alertId}/status`,
      method: "PUT",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Update a document alert
   *
   * @tags dbtn/module:document_alerts, dbtn/hasAuth
   * @name update_document_alert
   * @summary Update Document Alert
   * @request PUT:/routes/doc-alerts/{alert_id}
   */
  update_document_alert = (
    { alertId, ...query }: UpdateDocumentAlertParams,
    data: DocumentAlertUpdate,
    params: RequestParams = {},
  ) =>
    this.request<UpdateDocumentAlertData, UpdateDocumentAlertError>({
      path: `/routes/doc-alerts/${alertId}`,
      method: "PUT",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Delete a document alert
   *
   * @tags dbtn/module:document_alerts, dbtn/hasAuth
   * @name delete_document_alert
   * @summary Delete Document Alert
   * @request DELETE:/routes/doc-alerts/{alert_id}
   */
  delete_document_alert = ({ alertId, ...query }: DeleteDocumentAlertParams, params: RequestParams = {}) =>
    this.request<DeleteDocumentAlertData, DeleteDocumentAlertError>({
      path: `/routes/doc-alerts/${alertId}`,
      method: "DELETE",
      ...params,
    });

  /**
   * @description Get summary statistics for alerts
   *
   * @tags dbtn/module:document_alerts, dbtn/hasAuth
   * @name get_alerts_summary
   * @summary Get Alerts Summary
   * @request GET:/routes/doc-alerts/stats/summary
   */
  get_alerts_summary = (params: RequestParams = {}) =>
    this.request<GetAlertsSummaryData, any>({
      path: `/routes/doc-alerts/stats/summary`,
      method: "GET",
      ...params,
    });

  /**
   * @description Compare multiple documents side-by-side for regulatory analysis
   *
   * @tags dbtn/module:document_comparison, dbtn/hasAuth
   * @name compare_documents
   * @summary Compare Documents
   * @request POST:/routes/doc-compare/compare
   */
  compare_documents = (data: ComparisonRequest, params: RequestParams = {}) =>
    this.request<CompareDocumentsData, CompareDocumentsError>({
      path: `/routes/doc-compare/compare`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Get suggested documents for comparison with a given document
   *
   * @tags dbtn/module:document_comparison, dbtn/hasAuth
   * @name get_comparison_suggestions
   * @summary Get Comparison Suggestions
   * @request GET:/routes/doc-compare/compare/suggestions
   */
  get_comparison_suggestions = (query: GetComparisonSuggestionsParams, params: RequestParams = {}) =>
    this.request<GetComparisonSuggestionsData, GetComparisonSuggestionsError>({
      path: `/routes/doc-compare/compare/suggestions`,
      method: "GET",
      query: query,
      ...params,
    });

  /**
   * @description Download CSV template for critical products bulk import
   *
   * @tags dbtn/module:critical_products, dbtn/hasAuth
   * @name download_critical_products_template
   * @summary Download Critical Products Template
   * @request GET:/routes/critical-products/download-template
   */
  download_critical_products_template = (params: RequestParams = {}) =>
    this.request<DownloadCriticalProductsTemplateData, any>({
      path: `/routes/critical-products/download-template`,
      method: "GET",
      ...params,
    });

  /**
   * @description Download Excel template for critical products bulk import
   *
   * @tags dbtn/module:critical_products, dbtn/hasAuth
   * @name download_critical_products_excel_template
   * @summary Download Critical Products Excel Template
   * @request GET:/routes/critical-products/download-excel-template
   */
  download_critical_products_excel_template = (params: RequestParams = {}) =>
    this.request<DownloadCriticalProductsExcelTemplateData, any>({
      path: `/routes/critical-products/download-excel-template`,
      method: "GET",
      ...params,
    });

  /**
   * @description Search critical products database by HS/CN codes, keywords, or filters. Supports multi-modal search: exact code match, fuzzy search, and full-text search.
   *
   * @tags dbtn/module:critical_products, dbtn/hasAuth
   * @name search_critical_products
   * @summary Search Critical Products
   * @request POST:/routes/critical-products/search
   */
  search_critical_products = (data: SearchCriticalProductsRequest, params: RequestParams = {}) =>
    this.request<SearchCriticalProductsData, SearchCriticalProductsError>({
      path: `/routes/critical-products/search`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description List all trade codes with optional category filtering.
   *
   * @tags dbtn/module:critical_products, dbtn/hasAuth
   * @name list_trade_codes
   * @summary List Trade Codes
   * @request GET:/routes/critical-products/trade-codes
   */
  list_trade_codes = (query: ListTradeCodesParams, params: RequestParams = {}) =>
    this.request<ListTradeCodesData, ListTradeCodesError>({
      path: `/routes/critical-products/trade-codes`,
      method: "GET",
      query: query,
      ...params,
    });

  /**
   * @description Create a new trade code entry.
   *
   * @tags dbtn/module:critical_products, dbtn/hasAuth
   * @name create_trade_code
   * @summary Create Trade Code
   * @request POST:/routes/critical-products/trade-codes
   */
  create_trade_code = (data: CreateTradeCodeRequest, params: RequestParams = {}) =>
    this.request<CreateTradeCodeData, CreateTradeCodeError>({
      path: `/routes/critical-products/trade-codes`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description List restrictive measures with optional filtering.
   *
   * @tags dbtn/module:critical_products, dbtn/hasAuth
   * @name list_restrictive_measures
   * @summary List Restrictive Measures
   * @request GET:/routes/critical-products/restrictive-measures
   */
  list_restrictive_measures = (query: ListRestrictiveMeasuresParams, params: RequestParams = {}) =>
    this.request<ListRestrictiveMeasuresData, ListRestrictiveMeasuresError>({
      path: `/routes/critical-products/restrictive-measures`,
      method: "GET",
      query: query,
      ...params,
    });

  /**
   * @description Create a new restrictive measure.
   *
   * @tags dbtn/module:critical_products, dbtn/hasAuth
   * @name create_restrictive_measure
   * @summary Create Restrictive Measure
   * @request POST:/routes/critical-products/restrictive-measures
   */
  create_restrictive_measure = (data: CreateRestrictiveMeasureRequest, params: RequestParams = {}) =>
    this.request<CreateRestrictiveMeasureData, CreateRestrictiveMeasureError>({
      path: `/routes/critical-products/restrictive-measures`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Get list of available product categories.
   *
   * @tags dbtn/module:critical_products, dbtn/hasAuth
   * @name get_categories
   * @summary Get Categories
   * @request GET:/routes/critical-products/product-categories
   */
  get_categories = (params: RequestParams = {}) =>
    this.request<GetCategoriesData, any>({
      path: `/routes/critical-products/product-categories`,
      method: "GET",
      ...params,
    });

  /**
   * @description Get list of available jurisdictions.
   *
   * @tags dbtn/module:critical_products, dbtn/hasAuth
   * @name get_jurisdictions
   * @summary Get Jurisdictions
   * @request GET:/routes/critical-products/product-jurisdictions
   */
  get_jurisdictions = (params: RequestParams = {}) =>
    this.request<GetJurisdictionsData, any>({
      path: `/routes/critical-products/product-jurisdictions`,
      method: "GET",
      ...params,
    });

  /**
   * @description Get list of available measure types.
   *
   * @tags dbtn/module:critical_products, dbtn/hasAuth
   * @name get_measure_types
   * @summary Get Measure Types
   * @request GET:/routes/critical-products/measure-types
   */
  get_measure_types = (params: RequestParams = {}) =>
    this.request<GetMeasureTypesData, any>({
      path: `/routes/critical-products/measure-types`,
      method: "GET",
      ...params,
    });

  /**
   * @description Get statistics about the critical products database.
   *
   * @tags dbtn/module:critical_products, dbtn/hasAuth
   * @name get_critical_products_stats
   * @summary Get Critical Products Stats
   * @request GET:/routes/critical-products/critical-stats
   */
  get_critical_products_stats = (params: RequestParams = {}) =>
    this.request<GetCriticalProductsStatsData, any>({
      path: `/routes/critical-products/critical-stats`,
      method: "GET",
      ...params,
    });

  /**
   * @description Get CMS content for Database sections (trade-codes, measures, restrictions, jurisdictions, product-classification)
   *
   * @tags dbtn/module:critical_products, dbtn/hasAuth
   * @name get_critical_products_section_content
   * @summary Get Critical Products Section Content
   * @request GET:/routes/critical-products/section-content/{section_type}
   */
  get_critical_products_section_content = (
    { sectionType, ...query }: GetCriticalProductsSectionContentParams,
    params: RequestParams = {},
  ) =>
    this.request<GetCriticalProductsSectionContentData, GetCriticalProductsSectionContentError>({
      path: `/routes/critical-products/section-content/${sectionType}`,
      method: "GET",
      ...params,
    });

  /**
   * @description Export critical products data to Excel or CSV.
   *
   * @tags stream, dbtn/module:critical_products, dbtn/hasAuth
   * @name export_critical_products
   * @summary Export Critical Products
   * @request GET:/routes/critical-products/export-products
   */
  export_critical_products = (query: ExportCriticalProductsParams, params: RequestParams = {}) =>
    this.requestStream<ExportCriticalProductsData, ExportCriticalProductsError>({
      path: `/routes/critical-products/export-products`,
      method: "GET",
      query: query,
      ...params,
    });

  /**
   * @description Create a new critical product entry.
   *
   * @tags dbtn/module:critical_products, dbtn/hasAuth
   * @name create_critical_product
   * @summary Create Critical Product
   * @request POST:/routes/critical-products/critical-products/create
   */
  create_critical_product = (data: CreateTradeCodeRequest, params: RequestParams = {}) =>
    this.request<CreateCriticalProductData, CreateCriticalProductError>({
      path: `/routes/critical-products/critical-products/create`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Delete a critical product.
   *
   * @tags dbtn/module:critical_products, dbtn/hasAuth
   * @name delete_critical_product
   * @summary Delete Critical Product
   * @request DELETE:/routes/critical-products/delete/{product_id}
   */
  delete_critical_product = ({ productId, ...query }: DeleteCriticalProductParams, params: RequestParams = {}) =>
    this.request<DeleteCriticalProductData, DeleteCriticalProductError>({
      path: `/routes/critical-products/delete/${productId}`,
      method: "DELETE",
      ...params,
    });

  /**
   * @description Import critical products from Excel or CSV file.
   *
   * @tags dbtn/module:critical_products, dbtn/hasAuth
   * @name import_critical_products
   * @summary Import Critical Products
   * @request POST:/routes/critical-products/import
   */
  import_critical_products = (data: BodyImportCriticalProducts, params: RequestParams = {}) =>
    this.request<ImportCriticalProductsData, ImportCriticalProductsError>({
      path: `/routes/critical-products/import`,
      method: "POST",
      body: data,
      type: ContentType.FormData,
      ...params,
    });

  /**
   * @description Clear all critical products data from the database.
   *
   * @tags dbtn/module:critical_products, dbtn/hasAuth
   * @name clear_critical_products_database
   * @summary Clear Critical Products Database
   * @request POST:/routes/critical-products/clear-database
   */
  clear_critical_products_database = (params: RequestParams = {}) =>
    this.request<ClearCriticalProductsDatabaseData, any>({
      path: `/routes/critical-products/clear-database`,
      method: "POST",
      ...params,
    });

  /**
   * @description Create a new admin notification to be sent to users. Only admins can create notifications.
   *
   * @tags dbtn/module:admin_notifications, dbtn/hasAuth
   * @name create_admin_notification
   * @summary Create Admin Notification
   * @request POST:/routes/admin-notifications/admin/create
   */
  create_admin_notification = (data: AdminNotificationCreate, params: RequestParams = {}) =>
    this.request<CreateAdminNotificationData, CreateAdminNotificationError>({
      path: `/routes/admin-notifications/admin/create`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Get all admin notifications with delivery statistics. Only admins can access this endpoint.
   *
   * @tags dbtn/module:admin_notifications, dbtn/hasAuth
   * @name get_admin_notifications
   * @summary Get Admin Notifications
   * @request GET:/routes/admin-notifications/admin/notifications
   */
  get_admin_notifications = (query: GetAdminNotificationsParams, params: RequestParams = {}) =>
    this.request<GetAdminNotificationsData, GetAdminNotificationsError>({
      path: `/routes/admin-notifications/admin/notifications`,
      method: "GET",
      query: query,
      ...params,
    });

  /**
   * @description Update an existing admin notification. Only admins can update notifications.
   *
   * @tags dbtn/module:admin_notifications, dbtn/hasAuth
   * @name update_admin_notification
   * @summary Update Admin Notification
   * @request PUT:/routes/admin-notifications/admin/notifications/{notification_id}
   */
  update_admin_notification = (
    { notificationId, ...query }: UpdateAdminNotificationParams,
    data: AdminNotificationUpdate,
    params: RequestParams = {},
  ) =>
    this.request<UpdateAdminNotificationData, UpdateAdminNotificationError>({
      path: `/routes/admin-notifications/admin/notifications/${notificationId}`,
      method: "PUT",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Delete an admin notification (deactivate it). Only admins can delete notifications.
   *
   * @tags dbtn/module:admin_notifications, dbtn/hasAuth
   * @name delete_admin_notification
   * @summary Delete Admin Notification
   * @request DELETE:/routes/admin-notifications/admin/notifications/{notification_id}
   */
  delete_admin_notification = (
    { notificationId, ...query }: DeleteAdminNotificationParams,
    params: RequestParams = {},
  ) =>
    this.request<DeleteAdminNotificationData, DeleteAdminNotificationError>({
      path: `/routes/admin-notifications/admin/notifications/${notificationId}`,
      method: "DELETE",
      ...params,
    });

  /**
   * @description Get notifications for the current user. Automatically creates user_notification_status entries for new notifications.
   *
   * @tags dbtn/module:admin_notifications, dbtn/hasAuth
   * @name get_user_notifications
   * @summary Get User Notifications
   * @request GET:/routes/admin-notifications/user/notifications
   */
  get_user_notifications = (query: GetUserNotificationsParams, params: RequestParams = {}) =>
    this.request<GetUserNotificationsData, GetUserNotificationsError>({
      path: `/routes/admin-notifications/user/notifications`,
      method: "GET",
      query: query,
      ...params,
    });

  /**
   * @description Update the status of a notification for the current user (mark as read/dismissed).
   *
   * @tags dbtn/module:admin_notifications, dbtn/hasAuth
   * @name update_notification_status
   * @summary Update Notification Status
   * @request PUT:/routes/admin-notifications/user/notifications/{notification_id}/status
   */
  update_notification_status = (
    { notificationId, ...query }: UpdateNotificationStatusParams,
    data: NotificationStatusUpdate,
    params: RequestParams = {},
  ) =>
    this.request<UpdateNotificationStatusData, UpdateNotificationStatusError>({
      path: `/routes/admin-notifications/user/notifications/${notificationId}/status`,
      method: "PUT",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Get the count of unread notifications for the current user. Used for updating the notification badge in real-time.
   *
   * @tags dbtn/module:admin_notifications, dbtn/hasAuth
   * @name get_unread_notification_count
   * @summary Get Unread Notification Count
   * @request GET:/routes/admin-notifications/user/notifications/unread-count
   */
  get_unread_notification_count = (params: RequestParams = {}) =>
    this.request<GetUnreadNotificationCountData, any>({
      path: `/routes/admin-notifications/user/notifications/unread-count`,
      method: "GET",
      ...params,
    });

  /**
   * @description Mark all unread notifications as read for the current user.
   *
   * @tags dbtn/module:admin_notifications, dbtn/hasAuth
   * @name mark_all_notifications_read
   * @summary Mark All Notifications Read
   * @request POST:/routes/admin-notifications/user/notifications/mark-all-read
   */
  mark_all_notifications_read = (params: RequestParams = {}) =>
    this.request<MarkAllNotificationsReadData, any>({
      path: `/routes/admin-notifications/user/notifications/mark-all-read`,
      method: "POST",
      ...params,
    });

  /**
   * @description Get all annotations for a document
   *
   * @tags dbtn/module:document_collaboration, dbtn/hasAuth
   * @name get_document_annotations_collab
   * @summary Get Document Annotations Collab
   * @request GET:/routes/doc-collaboration/documents/{document_id}/annotations
   */
  get_document_annotations_collab = (
    { documentId, ...query }: GetDocumentAnnotationsCollabParams,
    params: RequestParams = {},
  ) =>
    this.request<GetDocumentAnnotationsCollabData, GetDocumentAnnotationsCollabError>({
      path: `/routes/doc-collaboration/documents/${documentId}/annotations`,
      method: "GET",
      query: query,
      ...params,
    });

  /**
   * @description Create a new document annotation
   *
   * @tags dbtn/module:document_collaboration, dbtn/hasAuth
   * @name create_annotation_collab
   * @summary Create Annotation Collab
   * @request POST:/routes/doc-collaboration/annotations
   */
  create_annotation_collab = (data: DocumentAnnotationInput, params: RequestParams = {}) =>
    this.request<CreateAnnotationCollabData, CreateAnnotationCollabError>({
      path: `/routes/doc-collaboration/annotations`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Update an existing annotation
   *
   * @tags dbtn/module:document_collaboration, dbtn/hasAuth
   * @name update_annotation_collab
   * @summary Update Annotation Collab
   * @request PUT:/routes/doc-collaboration/annotations/{annotation_id}
   */
  update_annotation_collab = (
    { annotationId, ...query }: UpdateAnnotationCollabParams,
    data: AnnotationUpdate,
    params: RequestParams = {},
  ) =>
    this.request<UpdateAnnotationCollabData, UpdateAnnotationCollabError>({
      path: `/routes/doc-collaboration/annotations/${annotationId}`,
      method: "PUT",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Delete an annotation
   *
   * @tags dbtn/module:document_collaboration, dbtn/hasAuth
   * @name delete_annotation_collab
   * @summary Delete Annotation Collab
   * @request DELETE:/routes/doc-collaboration/annotations/{annotation_id}
   */
  delete_annotation_collab = ({ annotationId, ...query }: DeleteAnnotationCollabParams, params: RequestParams = {}) =>
    this.request<DeleteAnnotationCollabData, DeleteAnnotationCollabError>({
      path: `/routes/doc-collaboration/annotations/${annotationId}`,
      method: "DELETE",
      ...params,
    });

  /**
   * @description Mark an annotation as resolved
   *
   * @tags dbtn/module:document_collaboration, dbtn/hasAuth
   * @name resolve_annotation_collab
   * @summary Resolve Annotation Collab
   * @request POST:/routes/doc-collaboration/annotations/{annotation_id}/resolve
   */
  resolve_annotation_collab = ({ annotationId, ...query }: ResolveAnnotationCollabParams, params: RequestParams = {}) =>
    this.request<ResolveAnnotationCollabData, ResolveAnnotationCollabError>({
      path: `/routes/doc-collaboration/annotations/${annotationId}/resolve`,
      method: "POST",
      ...params,
    });

  /**
   * @description Get user's bookmarks
   *
   * @tags dbtn/module:document_collaboration, dbtn/hasAuth
   * @name get_user_bookmarks_collab
   * @summary Get User Bookmarks Collab
   * @request GET:/routes/doc-collaboration/bookmarks
   */
  get_user_bookmarks_collab = (query: GetUserBookmarksCollabParams, params: RequestParams = {}) =>
    this.request<GetUserBookmarksCollabData, GetUserBookmarksCollabError>({
      path: `/routes/doc-collaboration/bookmarks`,
      method: "GET",
      query: query,
      ...params,
    });

  /**
   * @description Create a new bookmark
   *
   * @tags dbtn/module:document_collaboration, dbtn/hasAuth
   * @name create_bookmark_collab
   * @summary Create Bookmark Collab
   * @request POST:/routes/doc-collaboration/bookmarks
   */
  create_bookmark_collab = (data: UserBookmarkInput, params: RequestParams = {}) =>
    this.request<CreateBookmarkCollabData, CreateBookmarkCollabError>({
      path: `/routes/doc-collaboration/bookmarks`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Delete a bookmark
   *
   * @tags dbtn/module:document_collaboration, dbtn/hasAuth
   * @name delete_bookmark_collab
   * @summary Delete Bookmark Collab
   * @request DELETE:/routes/doc-collaboration/bookmarks/{bookmark_id}
   */
  delete_bookmark_collab = ({ bookmarkId, ...query }: DeleteBookmarkCollabParams, params: RequestParams = {}) =>
    this.request<DeleteBookmarkCollabData, DeleteBookmarkCollabError>({
      path: `/routes/doc-collaboration/bookmarks/${bookmarkId}`,
      method: "DELETE",
      ...params,
    });

  /**
   * @description Get document activity history
   *
   * @tags dbtn/module:document_collaboration, dbtn/hasAuth
   * @name get_document_activity_collab
   * @summary Get Document Activity Collab
   * @request GET:/routes/doc-collaboration/documents/{document_id}/activity
   */
  get_document_activity_collab = (
    { documentId, ...query }: GetDocumentActivityCollabParams,
    params: RequestParams = {},
  ) =>
    this.request<GetDocumentActivityCollabData, GetDocumentActivityCollabError>({
      path: `/routes/doc-collaboration/documents/${documentId}/activity`,
      method: "GET",
      ...params,
    });

  /**
   * @description Track a new document activity
   *
   * @tags dbtn/module:document_collaboration, dbtn/hasAuth
   * @name track_document_activity_collab
   * @summary Track Document Activity Collab
   * @request POST:/routes/doc-collaboration/documents/{document_id}/activity
   */
  track_document_activity_collab = (
    { documentId, ...query }: TrackDocumentActivityCollabParams,
    data: DocumentActivity,
    params: RequestParams = {},
  ) =>
    this.request<TrackDocumentActivityCollabData, TrackDocumentActivityCollabError>({
      path: `/routes/doc-collaboration/documents/${documentId}/activity`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Get collaboration statistics
   *
   * @tags dbtn/module:document_collaboration, dbtn/hasAuth
   * @name get_collaboration_stats_collab
   * @summary Get Collaboration Stats Collab
   * @request GET:/routes/doc-collaboration/stats
   */
  get_collaboration_stats_collab = (query: GetCollaborationStatsCollabParams, params: RequestParams = {}) =>
    this.request<GetCollaborationStatsCollabData, GetCollaborationStatsCollabError>({
      path: `/routes/doc-collaboration/stats`,
      method: "GET",
      query: query,
      ...params,
    });

  /**
   * @description Get collaboration summary for a user
   *
   * @tags dbtn/module:document_collaboration, dbtn/hasAuth
   * @name get_user_collaboration_summary_collab
   * @summary Get User Collaboration Summary Collab
   * @request GET:/routes/doc-collaboration/users/{user_id}/summary
   */
  get_user_collaboration_summary_collab = (
    { userId, ...query }: GetUserCollaborationSummaryCollabParams,
    params: RequestParams = {},
  ) =>
    this.request<GetUserCollaborationSummaryCollabData, GetUserCollaborationSummaryCollabError>({
      path: `/routes/doc-collaboration/users/${userId}/summary`,
      method: "GET",
      ...params,
    });

  /**
   * @description List sanction entities with filtering and pagination
   *
   * @tags dbtn/module:admin_sanctions, dbtn/hasAuth
   * @name list_sanction_entities
   * @summary List Sanction Entities
   * @request GET:/routes/admin-sanctions/entities
   */
  list_sanction_entities = (query: ListSanctionEntitiesParams, params: RequestParams = {}) =>
    this.request<ListSanctionEntitiesData, ListSanctionEntitiesError>({
      path: `/routes/admin-sanctions/entities`,
      method: "GET",
      query: query,
      ...params,
    });

  /**
   * @description Create a new sanction entity
   *
   * @tags dbtn/module:admin_sanctions, dbtn/hasAuth
   * @name create_sanction_entity
   * @summary Create Sanction Entity
   * @request POST:/routes/admin-sanctions/entities
   */
  create_sanction_entity = (data: SanctionEntityCreate, params: RequestParams = {}) =>
    this.request<CreateSanctionEntityData, CreateSanctionEntityError>({
      path: `/routes/admin-sanctions/entities`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Get a specific sanction entity
   *
   * @tags dbtn/module:admin_sanctions, dbtn/hasAuth
   * @name get_admin_sanction_entity
   * @summary Get Admin Sanction Entity
   * @request GET:/routes/admin-sanctions/entities/{entity_id}
   */
  get_admin_sanction_entity = ({ entityId, ...query }: GetAdminSanctionEntityParams, params: RequestParams = {}) =>
    this.request<GetAdminSanctionEntityData, GetAdminSanctionEntityError>({
      path: `/routes/admin-sanctions/entities/${entityId}`,
      method: "GET",
      ...params,
    });

  /**
   * @description Update a sanction entity
   *
   * @tags dbtn/module:admin_sanctions, dbtn/hasAuth
   * @name update_sanction_entity
   * @summary Update Sanction Entity
   * @request PUT:/routes/admin-sanctions/entities/{entity_id}
   */
  update_sanction_entity = (
    { entityId, ...query }: UpdateSanctionEntityParams,
    data: SanctionEntityUpdate,
    params: RequestParams = {},
  ) =>
    this.request<UpdateSanctionEntityData, UpdateSanctionEntityError>({
      path: `/routes/admin-sanctions/entities/${entityId}`,
      method: "PUT",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Delete or deactivate a sanction entity
   *
   * @tags dbtn/module:admin_sanctions, dbtn/hasAuth
   * @name delete_sanction_entity
   * @summary Delete Sanction Entity
   * @request DELETE:/routes/admin-sanctions/entities/{entity_id}
   */
  delete_sanction_entity = ({ entityId, ...query }: DeleteSanctionEntityParams, params: RequestParams = {}) =>
    this.request<DeleteSanctionEntityData, DeleteSanctionEntityError>({
      path: `/routes/admin-sanctions/entities/${entityId}`,
      method: "DELETE",
      query: query,
      ...params,
    });

  /**
   * @description Bulk import sanctions from CSV file
   *
   * @tags dbtn/module:admin_sanctions, dbtn/hasAuth
   * @name bulk_import_sanctions
   * @summary Bulk Import Sanctions
   * @request POST:/routes/admin-sanctions/bulk-import
   */
  bulk_import_sanctions = (data: BodyBulkImportSanctions, params: RequestParams = {}) =>
    this.request<BulkImportSanctionsData, BulkImportSanctionsError>({
      path: `/routes/admin-sanctions/bulk-import`,
      method: "POST",
      body: data,
      type: ContentType.FormData,
      ...params,
    });

  /**
   * @description Export sanctions data
   *
   * @tags stream, dbtn/module:admin_sanctions, dbtn/hasAuth
   * @name export_sanctions
   * @summary Export Sanctions
   * @request GET:/routes/admin-sanctions/export
   */
  export_sanctions = (query: ExportSanctionsParams, params: RequestParams = {}) =>
    this.requestStream<ExportSanctionsData, ExportSanctionsError>({
      path: `/routes/admin-sanctions/export`,
      method: "GET",
      query: query,
      ...params,
    });

  /**
   * @description Get statistics about sanction sources
   *
   * @tags dbtn/module:admin_sanctions, dbtn/hasAuth
   * @name get_sanction_sources
   * @summary Get Sanction Sources
   * @request GET:/routes/admin-sanctions/sources
   */
  get_sanction_sources = (params: RequestParams = {}) =>
    this.request<GetSanctionSourcesData, any>({
      path: `/routes/admin-sanctions/sources`,
      method: "GET",
      ...params,
    });

  /**
   * @description Get sanctions audit trail
   *
   * @tags dbtn/module:admin_sanctions, dbtn/hasAuth
   * @name get_sanctions_audit_log
   * @summary Get Sanctions Audit Log
   * @request GET:/routes/admin-sanctions/audit-log
   */
  get_sanctions_audit_log = (query: GetSanctionsAuditLogParams, params: RequestParams = {}) =>
    this.request<GetSanctionsAuditLogData, GetSanctionsAuditLogError>({
      path: `/routes/admin-sanctions/audit-log`,
      method: "GET",
      query: query,
      ...params,
    });

  /**
   * @description Set up auto-recharge configuration for the user
   *
   * @tags dbtn/module:automated_billing, dbtn/hasAuth
   * @name setup_auto_recharge
   * @summary Setup Auto Recharge
   * @request POST:/routes/auto-billing/auto-recharge/setup
   */
  setup_auto_recharge = (data: AutoRechargeConfigRequest, params: RequestParams = {}) =>
    this.request<SetupAutoRechargeData, SetupAutoRechargeError>({
      path: `/routes/auto-billing/auto-recharge/setup`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Get user's auto-recharge configuration
   *
   * @tags dbtn/module:automated_billing, dbtn/hasAuth
   * @name get_auto_recharge_config
   * @summary Get Auto Recharge Config
   * @request GET:/routes/auto-billing/auto-recharge/config
   */
  get_auto_recharge_config = (params: RequestParams = {}) =>
    this.request<GetAutoRechargeConfigData, any>({
      path: `/routes/auto-billing/auto-recharge/config`,
      method: "GET",
      ...params,
    });

  /**
   * @description Enable or disable auto-recharge
   *
   * @tags dbtn/module:automated_billing, dbtn/hasAuth
   * @name toggle_auto_recharge
   * @summary Toggle Auto Recharge
   * @request PATCH:/routes/auto-billing/auto-recharge/toggle
   */
  toggle_auto_recharge = (query: ToggleAutoRechargeParams, params: RequestParams = {}) =>
    this.request<ToggleAutoRechargeData, ToggleAutoRechargeError>({
      path: `/routes/auto-billing/auto-recharge/toggle`,
      method: "PATCH",
      query: query,
      ...params,
    });

  /**
   * @description Manually trigger an auto-recharge (for testing or immediate need)
   *
   * @tags dbtn/module:automated_billing, dbtn/hasAuth
   * @name manual_trigger_recharge
   * @summary Manual Trigger Recharge
   * @request POST:/routes/auto-billing/auto-recharge/trigger
   */
  manual_trigger_recharge = (params: RequestParams = {}) =>
    this.request<ManualTriggerRechargeData, any>({
      path: `/routes/auto-billing/auto-recharge/trigger`,
      method: "POST",
      ...params,
    });

  /**
   * @description Get user's auto-recharge transaction history
   *
   * @tags dbtn/module:automated_billing, dbtn/hasAuth
   * @name get_auto_recharge_history
   * @summary Get Auto Recharge History
   * @request GET:/routes/auto-billing/auto-recharge/history
   */
  get_auto_recharge_history = (query: GetAutoRechargeHistoryParams, params: RequestParams = {}) =>
    this.request<GetAutoRechargeHistoryData, GetAutoRechargeHistoryError>({
      path: `/routes/auto-billing/auto-recharge/history`,
      method: "GET",
      query: query,
      ...params,
    });

  /**
   * @description Add or update payment method for the user
   *
   * @tags dbtn/module:automated_billing, dbtn/hasAuth
   * @name add_payment_method
   * @summary Add Payment Method
   * @request POST:/routes/auto-billing/payment-methods/add
   */
  add_payment_method = (data: PaymentMethodRequest, params: RequestParams = {}) =>
    this.request<AddPaymentMethodData, AddPaymentMethodError>({
      path: `/routes/auto-billing/payment-methods/add`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Get user's saved payment methods
   *
   * @tags dbtn/module:automated_billing, dbtn/hasAuth
   * @name get_payment_methods
   * @summary Get Payment Methods
   * @request GET:/routes/auto-billing/payment-methods
   */
  get_payment_methods = (params: RequestParams = {}) =>
    this.request<GetPaymentMethodsData, any>({
      path: `/routes/auto-billing/payment-methods`,
      method: "GET",
      ...params,
    });

  /**
   * @description Generate an enterprise invoice for bulk credit purchase
   *
   * @tags dbtn/module:automated_billing, dbtn/hasAuth
   * @name generate_enterprise_invoice
   * @summary Generate Enterprise Invoice
   * @request POST:/routes/auto-billing/enterprise/generate-invoice
   */
  generate_enterprise_invoice = (data: EnterpriseInvoiceRequest, params: RequestParams = {}) =>
    this.request<GenerateEnterpriseInvoiceData, GenerateEnterpriseInvoiceError>({
      path: `/routes/auto-billing/enterprise/generate-invoice`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Get user's enterprise invoices
   *
   * @tags dbtn/module:automated_billing, dbtn/hasAuth
   * @name get_enterprise_invoices
   * @summary Get Enterprise Invoices
   * @request GET:/routes/auto-billing/enterprise/invoices
   */
  get_enterprise_invoices = (query: GetEnterpriseInvoicesParams, params: RequestParams = {}) =>
    this.request<GetEnterpriseInvoicesData, GetEnterpriseInvoicesError>({
      path: `/routes/auto-billing/enterprise/invoices`,
      method: "GET",
      query: query,
      ...params,
    });

  /**
   * @description Get user's payment failures that need attention
   *
   * @tags dbtn/module:automated_billing, dbtn/hasAuth
   * @name get_payment_failures
   * @summary Get Payment Failures
   * @request GET:/routes/auto-billing/payment-failures
   */
  get_payment_failures = (params: RequestParams = {}) =>
    this.request<GetPaymentFailuresData, any>({
      path: `/routes/auto-billing/payment-failures`,
      method: "GET",
      ...params,
    });

  /**
   * @description Retry a failed payment
   *
   * @tags dbtn/module:automated_billing, dbtn/hasAuth
   * @name retry_failed_payment
   * @summary Retry Failed Payment
   * @request POST:/routes/auto-billing/payment-failures/{failure_id}/retry
   */
  retry_failed_payment = ({ failureId, ...query }: RetryFailedPaymentParams, params: RequestParams = {}) =>
    this.request<RetryFailedPaymentData, RetryFailedPaymentError>({
      path: `/routes/auto-billing/payment-failures/${failureId}/retry`,
      method: "POST",
      ...params,
    });

  /**
   * @description List all automated feed sources
   *
   * @tags dbtn/module:automation, dbtn/hasAuth
   * @name list_feed_sources
   * @summary List Feed Sources
   * @request GET:/routes/automation/feed-sources
   */
  list_feed_sources = (params: RequestParams = {}) =>
    this.request<ListFeedSourcesData, any>({
      path: `/routes/automation/feed-sources`,
      method: "GET",
      ...params,
    });

  /**
   * @description Create a new automated feed source
   *
   * @tags dbtn/module:automation, dbtn/hasAuth
   * @name create_feed_source
   * @summary Create Feed Source
   * @request POST:/routes/automation/feed-sources
   */
  create_feed_source = (data: AutomatedFeedSource, params: RequestParams = {}) =>
    this.request<CreateFeedSourceData, CreateFeedSourceError>({
      path: `/routes/automation/feed-sources`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Manually trigger a feed update
   *
   * @tags dbtn/module:automation, dbtn/hasAuth
   * @name trigger_feed_update
   * @summary Trigger Feed Update
   * @request POST:/routes/automation/feed-sources/{feed_id}/trigger
   */
  trigger_feed_update = ({ feedId, ...query }: TriggerFeedUpdateParams, params: RequestParams = {}) =>
    this.request<TriggerFeedUpdateData, TriggerFeedUpdateError>({
      path: `/routes/automation/feed-sources/${feedId}/trigger`,
      method: "POST",
      ...params,
    });

  /**
   * @description List all webhook endpoints
   *
   * @tags dbtn/module:automation, dbtn/hasAuth
   * @name list_webhooks
   * @summary List Webhooks
   * @request GET:/routes/automation/webhooks
   */
  list_webhooks = (params: RequestParams = {}) =>
    this.request<ListWebhooksData, any>({
      path: `/routes/automation/webhooks`,
      method: "GET",
      ...params,
    });

  /**
   * @description Create a new webhook endpoint
   *
   * @tags dbtn/module:automation, dbtn/hasAuth
   * @name create_webhook
   * @summary Create Webhook
   * @request POST:/routes/automation/webhooks
   */
  create_webhook = (data: WebhookEndpoint, params: RequestParams = {}) =>
    this.request<CreateWebhookData, CreateWebhookError>({
      path: `/routes/automation/webhooks`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Get comprehensive automation analytics
   *
   * @tags dbtn/module:automation, dbtn/hasAuth
   * @name get_automation_analytics
   * @summary Get Automation Analytics
   * @request GET:/routes/automation/automation-analytics
   */
  get_automation_analytics = (params: RequestParams = {}) =>
    this.request<GetAutomationAnalyticsData, any>({
      path: `/routes/automation/automation-analytics`,
      method: "GET",
      ...params,
    });

  /**
   * @description Search documents that can be referenced
   *
   * @tags dbtn/module:document_references, dbtn/hasAuth
   * @name search_documents_for_reference
   * @summary Search Documents For Reference
   * @request GET:/routes/doc-references/search
   */
  search_documents_for_reference = (query: SearchDocumentsForReferenceParams, params: RequestParams = {}) =>
    this.request<SearchDocumentsForReferenceData, SearchDocumentsForReferenceError>({
      path: `/routes/doc-references/search`,
      method: "GET",
      query: query,
      ...params,
    });

  /**
   * @description Resolve document reference IDs to actual document data
   *
   * @tags dbtn/module:document_references, dbtn/hasAuth
   * @name resolve_document_references
   * @summary Resolve Document References
   * @request POST:/routes/doc-references/resolve
   */
  resolve_document_references = (data: ResolveDocumentReferencesPayload, params: RequestParams = {}) =>
    this.request<ResolveDocumentReferencesData, ResolveDocumentReferencesError>({
      path: `/routes/doc-references/resolve`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Extract document references from text content
   *
   * @tags dbtn/module:document_references, dbtn/hasAuth
   * @name extract_references_from_text_endpoint
   * @summary Extract References From Text Endpoint
   * @request GET:/routes/doc-references/extract-from-text
   */
  extract_references_from_text_endpoint = (
    query: ExtractReferencesFromTextEndpointParams,
    params: RequestParams = {},
  ) =>
    this.request<ExtractReferencesFromTextEndpointData, ExtractReferencesFromTextEndpointError>({
      path: `/routes/doc-references/extract-from-text`,
      method: "GET",
      query: query,
      ...params,
    });

  /**
   * @description Get the reference ID for a specific document
   *
   * @tags dbtn/module:document_references, dbtn/hasAuth
   * @name get_document_reference_id
   * @summary Get Document Reference Id
   * @request GET:/routes/doc-references/document/{document_id}/reference-id
   */
  get_document_reference_id = ({ documentId, ...query }: GetDocumentReferenceIdParams, params: RequestParams = {}) =>
    this.request<GetDocumentReferenceIdData, GetDocumentReferenceIdError>({
      path: `/routes/doc-references/document/${documentId}/reference-id`,
      method: "GET",
      ...params,
    });

  /**
   * @description Search country restrictions and embargoes for compliance checks
   *
   * @tags dbtn/module:country_restrictions, dbtn/hasAuth
   * @name search_countries
   * @summary Search Countries
   * @request POST:/routes/country-restrictions/countries/search
   */
  search_countries = (data: CountrySearchRequest, params: RequestParams = {}) =>
    this.request<SearchCountriesData, SearchCountriesError>({
      path: `/routes/country-restrictions/countries/search`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Get detailed restriction information for a specific country
   *
   * @tags dbtn/module:country_restrictions, dbtn/hasAuth
   * @name get_country_restriction
   * @summary Get Country Restriction
   * @request GET:/routes/country-restrictions/country/{country_id}
   */
  get_country_restriction = ({ countryId, ...query }: GetCountryRestrictionParams, params: RequestParams = {}) =>
    this.request<GetCountryRestrictionData, GetCountryRestrictionError>({
      path: `/routes/country-restrictions/country/${countryId}`,
      method: "GET",
      ...params,
    });

  /**
   * @description Get list of available restriction types
   *
   * @tags dbtn/module:country_restrictions, dbtn/hasAuth
   * @name get_restriction_types
   * @summary Get Restriction Types
   * @request GET:/routes/country-restrictions/restriction-types
   */
  get_restriction_types = (params: RequestParams = {}) =>
    this.request<GetRestrictionTypesData, any>({
      path: `/routes/country-restrictions/restriction-types`,
      method: "GET",
      ...params,
    });

  /**
   * @description Get list of issuing authorities
   *
   * @tags dbtn/module:country_restrictions, dbtn/hasAuth
   * @name get_issuing_authorities
   * @summary Get Issuing Authorities
   * @request GET:/routes/country-restrictions/authorities
   */
  get_issuing_authorities = (params: RequestParams = {}) =>
    this.request<GetIssuingAuthoritiesData, any>({
      path: `/routes/country-restrictions/authorities`,
      method: "GET",
      ...params,
    });

  /**
   * @description Get list of geographic regions
   *
   * @tags dbtn/module:country_restrictions, dbtn/hasAuth
   * @name get_geographic_regions
   * @summary Get Geographic Regions
   * @request GET:/routes/country-restrictions/regions
   */
  get_geographic_regions = (params: RequestParams = {}) =>
    this.request<GetGeographicRegionsData, any>({
      path: `/routes/country-restrictions/regions`,
      method: "GET",
      ...params,
    });

  /**
   * @description Get list of available risk levels for countries
   *
   * @tags dbtn/module:country_restrictions, dbtn/hasAuth
   * @name get_country_risk_levels
   * @summary Get Country Risk Levels
   * @request GET:/routes/country-restrictions/risk-levels
   */
  get_country_risk_levels = (params: RequestParams = {}) =>
    this.request<GetCountryRiskLevelsData, any>({
      path: `/routes/country-restrictions/risk-levels`,
      method: "GET",
      ...params,
    });

  /**
   * @description Upload and process a document with OCR and text extraction
   *
   * @tags dbtn/module:document_processing, dbtn/hasAuth
   * @name process_document
   * @summary Process Document
   * @request POST:/routes/doc-processing/process-document
   */
  process_document = (data: BodyProcessDocument, params: RequestParams = {}) =>
    this.request<ProcessDocumentData, ProcessDocumentError>({
      path: `/routes/doc-processing/process-document`,
      method: "POST",
      body: data,
      type: ContentType.FormData,
      ...params,
    });

  /**
   * @description Get the processing status for a document
   *
   * @tags dbtn/module:document_processing, dbtn/hasAuth
   * @name get_processing_status
   * @summary Get Processing Status
   * @request GET:/routes/doc-processing/processing-status/{processing_id}
   */
  get_processing_status = ({ processingId, ...query }: GetProcessingStatusParams, params: RequestParams = {}) =>
    this.request<GetProcessingStatusData, GetProcessingStatusError>({
      path: `/routes/doc-processing/processing-status/${processingId}`,
      method: "GET",
      ...params,
    });

  /**
   * @description Get hierarchical sections from a processed document
   *
   * @tags dbtn/module:document_processing, dbtn/hasAuth
   * @name get_processed_document_sections
   * @summary Get Processed Document Sections
   * @request GET:/routes/doc-processing/document/{document_id}/sections
   */
  get_processed_document_sections = (
    { documentId, ...query }: GetProcessedDocumentSectionsParams,
    params: RequestParams = {},
  ) =>
    this.request<GetProcessedDocumentSectionsData, GetProcessedDocumentSectionsError>({
      path: `/routes/doc-processing/document/${documentId}/sections`,
      method: "GET",
      ...params,
    });

  /**
   * @description Get cross-references extracted from a document
   *
   * @tags dbtn/module:document_processing, dbtn/hasAuth
   * @name get_document_cross_references_processing
   * @summary Get Document Cross References Processing
   * @request GET:/routes/doc-processing/document/{document_id}/cross-references
   */
  get_document_cross_references_processing = (
    { documentId, ...query }: GetDocumentCrossReferencesProcessingParams,
    params: RequestParams = {},
  ) =>
    this.request<GetDocumentCrossReferencesProcessingData, GetDocumentCrossReferencesProcessingError>({
      path: `/routes/doc-processing/document/${documentId}/cross-references`,
      method: "GET",
      ...params,
    });

  /**
   * @description Process multiple documents in batch
   *
   * @tags dbtn/module:document_processing, dbtn/hasAuth
   * @name batch_process_documents
   * @summary Batch Process Documents
   * @request POST:/routes/doc-processing/batch-process
   */
  batch_process_documents = (data: BatchProcessRequest, params: RequestParams = {}) =>
    this.request<BatchProcessDocumentsData, BatchProcessDocumentsError>({
      path: `/routes/doc-processing/batch-process`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Get list of supported document formats for processing
   *
   * @tags dbtn/module:document_processing, dbtn/hasAuth
   * @name get_supported_formats
   * @summary Get Supported Formats
   * @request GET:/routes/doc-processing/supported-formats
   */
  get_supported_formats = (params: RequestParams = {}) =>
    this.request<GetSupportedFormatsData, any>({
      path: `/routes/doc-processing/supported-formats`,
      method: "GET",
      ...params,
    });

  /**
   * @description Clean up old processing status records
   *
   * @tags dbtn/module:document_processing, dbtn/hasAuth
   * @name cleanup_processing_history
   * @summary Cleanup Processing History
   * @request DELETE:/routes/doc-processing/cleanup-processing-history
   */
  cleanup_processing_history = (query: CleanupProcessingHistoryParams, params: RequestParams = {}) =>
    this.request<CleanupProcessingHistoryData, CleanupProcessingHistoryError>({
      path: `/routes/doc-processing/cleanup-processing-history`,
      method: "DELETE",
      query: query,
      ...params,
    });

  /**
   * @description Initialize default content for modules (admin only)
   *
   * @tags dbtn/module:content_management, dbtn/hasAuth
   * @name initialize_default_content
   * @summary Initialize Default Content
   * @request POST:/routes/content-management/initialize-defaults
   */
  initialize_default_content = (params: RequestParams = {}) =>
    this.request<InitializeDefaultContentData, any>({
      path: `/routes/content-management/initialize-defaults`,
      method: "POST",
      ...params,
    });

  /**
   * @description Get all content items for a specific module
   *
   * @tags dbtn/module:content_management, dbtn/hasAuth
   * @name get_content_by_module
   * @summary Get Content By Module
   * @request GET:/routes/content-management/content/{module_name}
   */
  get_content_by_module = ({ moduleName, ...query }: GetContentByModuleParams, params: RequestParams = {}) =>
    this.request<GetContentByModuleData, GetContentByModuleError>({
      path: `/routes/content-management/content/${moduleName}`,
      method: "GET",
      ...params,
    });

  /**
   * @description Create a new content item
   *
   * @tags dbtn/module:content_management, dbtn/hasAuth
   * @name create_content_item
   * @summary Create Content Item
   * @request POST:/routes/content-management/content
   */
  create_content_item = (data: CreateContentRequest, params: RequestParams = {}) =>
    this.request<CreateContentItemData, CreateContentItemError>({
      path: `/routes/content-management/content`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Update an existing content item
   *
   * @tags dbtn/module:content_management, dbtn/hasAuth
   * @name update_content_item
   * @summary Update Content Item
   * @request PUT:/routes/content-management/content/{content_id}
   */
  update_content_item = (
    { contentId, ...query }: UpdateContentItemParams,
    data: UpdateContentRequest,
    params: RequestParams = {},
  ) =>
    this.request<UpdateContentItemData, UpdateContentItemError>({
      path: `/routes/content-management/content/${contentId}`,
      method: "PUT",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Delete a content item
   *
   * @tags dbtn/module:content_management, dbtn/hasAuth
   * @name delete_content_item
   * @summary Delete Content Item
   * @request DELETE:/routes/content-management/content/{content_id}
   */
  delete_content_item = ({ contentId, ...query }: DeleteContentItemParams, params: RequestParams = {}) =>
    this.request<DeleteContentItemData, DeleteContentItemError>({
      path: `/routes/content-management/content/${contentId}`,
      method: "DELETE",
      ...params,
    });

  /**
   * @description Get a specific content item by ID
   *
   * @tags dbtn/module:content_management, dbtn/hasAuth
   * @name get_content_item
   * @summary Get Content Item
   * @request GET:/routes/content-management/content-item/{content_id}
   */
  get_content_item = ({ contentId, ...query }: GetContentItemParams, params: RequestParams = {}) =>
    this.request<GetContentItemData, GetContentItemError>({
      path: `/routes/content-management/content-item/${contentId}`,
      method: "GET",
      ...params,
    });

  /**
   * @description Activate free tier credits for new users automatically
   *
   * @tags dbtn/module:credit_management, dbtn/hasAuth
   * @name activate_free_tier
   * @summary Activate Free Tier
   * @request POST:/routes/credit-management/credits/activate-free-tier
   */
  activate_free_tier = (params: RequestParams = {}) =>
    this.request<ActivateFreeTierData, any>({
      path: `/routes/credit-management/credits/activate-free-tier`,
      method: "POST",
      ...params,
    });

  /**
   * @description Check if user has claimed free tier credits and eligibility
   *
   * @tags dbtn/module:credit_management, dbtn/hasAuth
   * @name get_free_tier_status
   * @summary Get Free Tier Status
   * @request GET:/routes/credit-management/credits/free-tier-status
   */
  get_free_tier_status = (params: RequestParams = {}) =>
    this.request<GetFreeTierStatusData, any>({
      path: `/routes/credit-management/credits/free-tier-status`,
      method: "GET",
      ...params,
    });

  /**
   * @description Get current user's credit balance
   *
   * @tags dbtn/module:credit_management, dbtn/hasAuth
   * @name get_credit_balance
   * @summary Get Credit Balance
   * @request GET:/routes/credit-management/credits/balance
   */
  get_credit_balance = (params: RequestParams = {}) =>
    this.request<GetCreditBalanceData, any>({
      path: `/routes/credit-management/credits/balance`,
      method: "GET",
      ...params,
    });

  /**
   * @description Get user's credit transaction history
   *
   * @tags dbtn/module:credit_management, dbtn/hasAuth
   * @name get_credit_transactions
   * @summary Get Credit Transactions
   * @request GET:/routes/credit-management/credits/transactions
   */
  get_credit_transactions = (query: GetCreditTransactionsParams, params: RequestParams = {}) =>
    this.request<GetCreditTransactionsData, GetCreditTransactionsError>({
      path: `/routes/credit-management/credits/transactions`,
      method: "GET",
      query: query,
      ...params,
    });

  /**
   * @description Get available credit packages for purchase
   *
   * @tags dbtn/module:credit_management, dbtn/hasAuth
   * @name get_credit_packages
   * @summary Get Credit Packages
   * @request GET:/routes/credit-management/credits/packages
   */
  get_credit_packages = (params: RequestParams = {}) =>
    this.request<GetCreditPackagesData, any>({
      path: `/routes/credit-management/credits/packages`,
      method: "GET",
      ...params,
    });

  /**
   * @description Reserve credits for an action (check availability without consuming)
   *
   * @tags dbtn/module:credit_management, dbtn/hasAuth
   * @name reserve_credits
   * @summary Reserve Credits
   * @request POST:/routes/credit-management/credits/reserve
   */
  reserve_credits = (data: ReserveCreditsRequest, params: RequestParams = {}) =>
    this.request<ReserveCreditsData, ReserveCreditsError>({
      path: `/routes/credit-management/credits/reserve`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Consume credits for an action
   *
   * @tags dbtn/module:credit_management, dbtn/hasAuth
   * @name consume_credits
   * @summary Consume Credits
   * @request POST:/routes/credit-management/credits/consume
   */
  consume_credits = (data: ConsumeCreditsRequest, params: RequestParams = {}) =>
    this.request<ConsumeCreditsData, ConsumeCreditsError>({
      path: `/routes/credit-management/credits/consume`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Admin function to manually adjust user credits
   *
   * @tags dbtn/module:credit_management, dbtn/hasAuth
   * @name admin_adjust_credits
   * @summary Admin Adjust Credits
   * @request POST:/routes/credit-management/admin/credits/adjust
   */
  admin_adjust_credits = (data: AdminCreditAdjustment, params: RequestParams = {}) =>
    this.request<AdminAdjustCreditsData, AdminAdjustCreditsError>({
      path: `/routes/credit-management/admin/credits/adjust`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Get all credit packages including inactive ones (admin only)
   *
   * @tags dbtn/module:credit_management, dbtn/hasAuth
   * @name get_all_credit_packages
   * @summary Get All Credit Packages
   * @request GET:/routes/credit-management/admin/credits/packages
   */
  get_all_credit_packages = (params: RequestParams = {}) =>
    this.request<GetAllCreditPackagesData, any>({
      path: `/routes/credit-management/admin/credits/packages`,
      method: "GET",
      ...params,
    });

  /**
   * @description Create a new credit package (admin only)
   *
   * @tags dbtn/module:credit_management, dbtn/hasAuth
   * @name create_credit_package
   * @summary Create Credit Package
   * @request POST:/routes/credit-management/admin/credits/packages
   */
  create_credit_package = (data: CreateCreditPackageRequest, params: RequestParams = {}) =>
    this.request<CreateCreditPackageData, CreateCreditPackageError>({
      path: `/routes/credit-management/admin/credits/packages`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Update an existing credit package (admin only)
   *
   * @tags dbtn/module:credit_management, dbtn/hasAuth
   * @name update_credit_package
   * @summary Update Credit Package
   * @request PUT:/routes/credit-management/admin/credits/packages/{package_id}
   */
  update_credit_package = (
    { packageId, ...query }: UpdateCreditPackageParams,
    data: UpdateCreditPackageRequest,
    params: RequestParams = {},
  ) =>
    this.request<UpdateCreditPackageData, UpdateCreditPackageError>({
      path: `/routes/credit-management/admin/credits/packages/${packageId}`,
      method: "PUT",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Delete a credit package (admin only)
   *
   * @tags dbtn/module:credit_management, dbtn/hasAuth
   * @name delete_credit_package
   * @summary Delete Credit Package
   * @request DELETE:/routes/credit-management/admin/credits/packages/{package_id}
   */
  delete_credit_package = ({ packageId, ...query }: DeleteCreditPackageParams, params: RequestParams = {}) =>
    this.request<DeleteCreditPackageData, DeleteCreditPackageError>({
      path: `/routes/credit-management/admin/credits/packages/${packageId}`,
      method: "DELETE",
      ...params,
    });

  /**
   * @description Get the base EUR price per credit (admin only)
   *
   * @tags dbtn/module:credit_management, dbtn/hasAuth
   * @name get_base_credit_price
   * @summary Get Base Credit Price
   * @request GET:/routes/credit-management/admin/credits/base-price
   */
  get_base_credit_price = (params: RequestParams = {}) =>
    this.request<GetBaseCreditPriceData, any>({
      path: `/routes/credit-management/admin/credits/base-price`,
      method: "GET",
      ...params,
    });

  /**
   * @description Update the base EUR price per credit (admin only)
   *
   * @tags dbtn/module:credit_management, dbtn/hasAuth
   * @name update_base_credit_price
   * @summary Update Base Credit Price
   * @request PUT:/routes/credit-management/admin/credits/base-price
   */
  update_base_credit_price = (data: BaseCreditPriceRequest, params: RequestParams = {}) =>
    this.request<UpdateBaseCreditPriceData, UpdateBaseCreditPriceError>({
      path: `/routes/credit-management/admin/credits/base-price`,
      method: "PUT",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Export all regulatory notes to Excel format If tree_id is 'global', export all global notes (tree_id = NULL) Otherwise export notes for specific tree
   *
   * @tags dbtn/module:excel_export, dbtn/hasAuth
   * @name export_notes_to_excel
   * @summary Export Notes To Excel
   * @request GET:/routes/excel-export/export-notes/{tree_id}
   */
  export_notes_to_excel = ({ treeId, ...query }: ExportNotesToExcelParams, params: RequestParams = {}) =>
    this.request<ExportNotesToExcelData, ExportNotesToExcelError>({
      path: `/routes/excel-export/export-notes/${treeId}`,
      method: "GET",
      query: query,
      ...params,
    });

  /**
   * @description Import regulatory notes from Excel file content
   *
   * @tags dbtn/module:excel_export, dbtn/hasAuth
   * @name import_notes_from_excel
   * @summary Import Notes From Excel
   * @request POST:/routes/excel-export/import-notes/{tree_id}
   */
  import_notes_from_excel = (
    { treeId, ...query }: ImportNotesFromExcelParams,
    data: BodyImportNotesFromExcel,
    params: RequestParams = {},
  ) =>
    this.request<ImportNotesFromExcelData, ImportNotesFromExcelError>({
      path: `/routes/excel-export/import-notes/${treeId}`,
      method: "POST",
      query: query,
      body: data,
      type: ContentType.FormData,
      ...params,
    });

  /**
   * @description Get user's module access status and subscription information
   *
   * @tags dbtn/module:payment_system, dbtn/hasAuth
   * @name get_user_access_status
   * @summary Get User Access Status
   * @request GET:/routes/user-access-status
   */
  get_user_access_status = (params: RequestParams = {}) =>
    this.request<GetUserAccessStatusData, any>({
      path: `/routes/user-access-status`,
      method: "GET",
      ...params,
    });

  /**
   * @description Calculate VAT preview for a module purchase without creating payment intent
   *
   * @tags dbtn/module:payment_system, dbtn/hasAuth
   * @name get_vat_preview
   * @summary Get Vat Preview
   * @request POST:/routes/vat-preview
   */
  get_vat_preview = (data: VATPreviewRequest, params: RequestParams = {}) =>
    this.request<GetVatPreviewData, GetVatPreviewError>({
      path: `/routes/vat-preview`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Create a Stripe payment intent for module access
   *
   * @tags dbtn/module:payment_system, dbtn/hasAuth
   * @name create_payment_intent
   * @summary Create Payment Intent
   * @request POST:/routes/create-payment-intent
   */
  create_payment_intent = (data: PaymentIntent, params: RequestParams = {}) =>
    this.request<CreatePaymentIntentData, CreatePaymentIntentError>({
      path: `/routes/create-payment-intent`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Request an invoice for bank transfer payment (supports custom credit amounts)
   *
   * @tags dbtn/module:payment_system, dbtn/hasAuth
   * @name request_invoice
   * @summary Request Invoice
   * @request POST:/routes/request-invoice
   */
  request_invoice = (data: InvoiceRequest, params: RequestParams = {}) =>
    this.request<RequestInvoiceData, RequestInvoiceError>({
      path: `/routes/request-invoice`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Select a template after successful payment
   *
   * @tags dbtn/module:payment_system, dbtn/hasAuth
   * @name select_template
   * @summary Select Template
   * @request POST:/routes/select-template
   */
  select_template = (data: TemplateSelectionRequest, params: RequestParams = {}) =>
    this.request<SelectTemplateData, SelectTemplateError>({
      path: `/routes/select-template`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Complete template selection after successful payment verification
   *
   * @tags dbtn/module:payment_system, dbtn/hasAuth
   * @name complete_template_selection
   * @summary Complete Template Selection
   * @request POST:/routes/complete-template-selection
   */
  complete_template_selection = (data: TemplateSelectionRequest, params: RequestParams = {}) =>
    this.request<CompleteTemplateSelectionData, CompleteTemplateSelectionError>({
      path: `/routes/complete-template-selection`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Handle Stripe webhook events for payment confirmations
   *
   * @tags dbtn/module:payment_system, dbtn/hasAuth
   * @name stripe_webhook
   * @summary Stripe Webhook
   * @request PATCH:/routes/webhook/stripe
   */
  stripe_webhook = (params: RequestParams = {}) =>
    this.request<StripeWebhookData, any>({
      path: `/routes/webhook/stripe`,
      method: "PATCH",
      ...params,
    });

  /**
   * @description Get all customer details for admin dashboard
   *
   * @tags dbtn/module:payment_system, dbtn/hasAuth
   * @name get_admin_customers
   * @summary Get Admin Customers
   * @request GET:/routes/admin/customers
   */
  get_admin_customers = (params: RequestParams = {}) =>
    this.request<GetAdminCustomersData, any>({
      path: `/routes/admin/customers`,
      method: "GET",
      ...params,
    });

  /**
   * @description Get comprehensive list of all users for admin dashboard Includes both users with customer details and registered users without billing info
   *
   * @tags dbtn/module:payment_system, dbtn/hasAuth
   * @name get_all_admin_users
   * @summary Get All Admin Users
   * @request GET:/routes/admin/all-users
   */
  get_all_admin_users = (params: RequestParams = {}) =>
    this.request<GetAllAdminUsersData, any>({
      path: `/routes/admin/all-users`,
      method: "GET",
      ...params,
    });

  /**
   * @description Get chat messages, optionally filtered by thread
   *
   * @tags dbtn/module:community_chat, dbtn/hasAuth
   * @name get_chat_messages
   * @summary Get Chat Messages
   * @request GET:/routes/community-chat/messages
   */
  get_chat_messages = (query: GetChatMessagesParams, params: RequestParams = {}) =>
    this.request<GetChatMessagesData, GetChatMessagesError>({
      path: `/routes/community-chat/messages`,
      method: "GET",
      query: query,
      ...params,
    });

  /**
   * @description Send a new chat message
   *
   * @tags dbtn/module:community_chat, dbtn/hasAuth
   * @name send_message
   * @summary Send Message
   * @request POST:/routes/community-chat/send-message
   */
  send_message = (data: SendMessageRequest, params: RequestParams = {}) =>
    this.request<SendMessageData, SendMessageError>({
      path: `/routes/community-chat/send-message`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Get all chat threads
   *
   * @tags dbtn/module:community_chat, dbtn/hasAuth
   * @name get_chat_threads
   * @summary Get Chat Threads
   * @request GET:/routes/community-chat/threads
   */
  get_chat_threads = (params: RequestParams = {}) =>
    this.request<GetChatThreadsData, any>({
      path: `/routes/community-chat/threads`,
      method: "GET",
      ...params,
    });

  /**
   * @description Create a new chat thread
   *
   * @tags dbtn/module:community_chat, dbtn/hasAuth
   * @name create_chat_thread
   * @summary Create Chat Thread
   * @request POST:/routes/community-chat/threads
   */
  create_chat_thread = (data: CreateThreadRequest, params: RequestParams = {}) =>
    this.request<CreateChatThreadData, CreateChatThreadError>({
      path: `/routes/community-chat/threads`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Add or remove a reaction to a message
   *
   * @tags dbtn/module:community_chat, dbtn/hasAuth
   * @name react_to_message
   * @summary React To Message
   * @request POST:/routes/community-chat/messages/{message_id}/react
   */
  react_to_message = (
    { messageId, ...query }: ReactToMessageParams,
    data: ReactionRequest,
    params: RequestParams = {},
  ) =>
    this.request<ReactToMessageData, ReactToMessageError>({
      path: `/routes/community-chat/messages/${messageId}/react`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Delete a chat message (admin only or message author)
   *
   * @tags dbtn/module:community_chat, dbtn/hasAuth
   * @name delete_message
   * @summary Delete Message
   * @request DELETE:/routes/community-chat/messages/{message_id}
   */
  delete_message = ({ messageId, ...query }: DeleteMessageParams, params: RequestParams = {}) =>
    this.request<DeleteMessageData, DeleteMessageError>({
      path: `/routes/community-chat/messages/${messageId}`,
      method: "DELETE",
      ...params,
    });

  /**
   * @description Block a user from chat (admin only)
   *
   * @tags dbtn/module:community_chat, dbtn/hasAuth
   * @name block_user
   * @summary Block User
   * @request POST:/routes/community-chat/admin/block-user
   */
  block_user = (data: BlockUserRequest, params: RequestParams = {}) =>
    this.request<BlockUserData, BlockUserError>({
      path: `/routes/community-chat/admin/block-user`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Delete chat content (admin only)
   *
   * @tags dbtn/module:community_chat, dbtn/hasAuth
   * @name delete_chat
   * @summary Delete Chat
   * @request POST:/routes/community-chat/admin/delete-chat
   */
  delete_chat = (data: DeleteChatRequest, params: RequestParams = {}) =>
    this.request<DeleteChatData, DeleteChatError>({
      path: `/routes/community-chat/admin/delete-chat`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Get the chat community guidelines and policy
   *
   * @tags dbtn/module:community_chat, dbtn/hasAuth
   * @name get_chat_policy
   * @summary Get Chat Policy
   * @request GET:/routes/community-chat/chat-policy
   */
  get_chat_policy = (params: RequestParams = {}) =>
    this.request<GetChatPolicyData, any>({
      path: `/routes/community-chat/chat-policy`,
      method: "GET",
      ...params,
    });

  /**
   * @description Check if a user is blocked (admin only)
   *
   * @tags dbtn/module:community_chat, dbtn/hasAuth
   * @name check_user_blocked
   * @summary Check User Blocked
   * @request GET:/routes/community-chat/admin/check-user-blocked
   */
  check_user_blocked = (query: CheckUserBlockedParams, params: RequestParams = {}) =>
    this.request<CheckUserBlockedData, CheckUserBlockedError>({
      path: `/routes/community-chat/admin/check-user-blocked`,
      method: "GET",
      query: query,
      ...params,
    });

  /**
   * @description Upload a document for attachment to blog articles
   *
   * @tags dbtn/module:document_upload, dbtn/hasAuth
   * @name upload_document_attachment
   * @summary Upload Document Attachment
   * @request POST:/routes/upload-document
   */
  upload_document_attachment = (data: BodyUploadDocumentAttachment, params: RequestParams = {}) =>
    this.request<UploadDocumentAttachmentData, UploadDocumentAttachmentError>({
      path: `/routes/upload-document`,
      method: "POST",
      body: data,
      type: ContentType.FormData,
      ...params,
    });

  /**
   * @description Serve uploaded documents
   *
   * @tags dbtn/module:document_upload, dbtn/hasAuth
   * @name serve_document
   * @summary Serve Document
   * @request GET:/routes/documents/{document_filename}
   */
  serve_document = ({ documentFilename, ...query }: ServeDocumentParams, params: RequestParams = {}) =>
    this.request<ServeDocumentData, ServeDocumentError>({
      path: `/routes/documents/${documentFilename}`,
      method: "GET",
      ...params,
    });

  /**
   * @description Delete an uploaded document
   *
   * @tags dbtn/module:document_upload, dbtn/hasAuth
   * @name delete_attachment_document
   * @summary Delete Attachment Document
   * @request DELETE:/routes/documents/{document_filename}
   */
  delete_attachment_document = (
    { documentFilename, ...query }: DeleteAttachmentDocumentParams,
    params: RequestParams = {},
  ) =>
    this.request<DeleteAttachmentDocumentData, DeleteAttachmentDocumentError>({
      path: `/routes/documents/${documentFilename}`,
      method: "DELETE",
      ...params,
    });

  /**
   * @description List all uploaded documents
   *
   * @tags dbtn/module:document_upload, dbtn/hasAuth
   * @name list_attachment_documents
   * @summary List Attachment Documents
   * @request GET:/routes/list-documents
   */
  list_attachment_documents = (params: RequestParams = {}) =>
    this.request<ListAttachmentDocumentsData, any>({
      path: `/routes/list-documents`,
      method: "GET",
      ...params,
    });

  /**
   * @description Get all countries for Knowledge Base browsing
   *
   * @tags dbtn/module:kb_data, dbtn/hasAuth
   * @name list_countries
   * @summary List Countries
   * @request GET:/routes/kb-data/countries
   */
  list_countries = (params: RequestParams = {}) =>
    this.request<ListCountriesData, any>({
      path: `/routes/kb-data/countries`,
      method: "GET",
      ...params,
    });

  /**
   * @description Get all sanctions for Knowledge Base browsing
   *
   * @tags dbtn/module:kb_data, dbtn/hasAuth
   * @name list_sanctions
   * @summary List Sanctions
   * @request GET:/routes/kb-data/sanctions
   */
  list_sanctions = (params: RequestParams = {}) =>
    this.request<ListSanctionsData, any>({
      path: `/routes/kb-data/sanctions`,
      method: "GET",
      ...params,
    });

  /**
   * @description Get sections for a specific document with credit enforcement
   *
   * @tags dbtn/module:kb_data, dbtn/hasAuth
   * @name get_document_sections
   * @summary Get Document Sections
   * @request GET:/routes/kb-data/documents/{document_id}/sections
   */
  get_document_sections = ({ documentId, ...query }: GetDocumentSectionsParams, params: RequestParams = {}) =>
    this.request<GetDocumentSectionsData, GetDocumentSectionsError>({
      path: `/routes/kb-data/documents/${documentId}/sections`,
      method: "GET",
      ...params,
    });

  /**
   * @description Serve uploaded images publicly (no authentication required)
   *
   * @tags dbtn/module:public_images, dbtn/hasAuth
   * @name serve_public_image
   * @summary Serve Public Image
   * @request GET:/routes/serve/{image_filename}
   */
  serve_public_image = ({ imageFilename, ...query }: ServePublicImageParams, params: RequestParams = {}) =>
    this.request<ServePublicImageData, ServePublicImageError>({
      path: `/routes/serve/${imageFilename}`,
      method: "GET",
      ...params,
    });

  /**
   * @description Serve uploaded images as static files (completely public)
   *
   * @tags dbtn/module:static_serve, dbtn/hasAuth
   * @name serve_static_image
   * @summary Serve Static Image
   * @request GET:/routes/static/{image_filename}
   */
  serve_static_image = ({ imageFilename, ...query }: ServeStaticImageParams, params: RequestParams = {}) =>
    this.request<ServeStaticImageData, ServeStaticImageError>({
      path: `/routes/static/${imageFilename}`,
      method: "GET",
      ...params,
    });

  /**
   * @description Upload an image for use in documents
   *
   * @tags dbtn/module:image_upload, dbtn/hasAuth
   * @name upload_image
   * @summary Upload Image
   * @request POST:/routes/upload-image
   */
  upload_image = (data: BodyUploadImage, params: RequestParams = {}) =>
    this.request<UploadImageData, UploadImageError>({
      path: `/routes/upload-image`,
      method: "POST",
      body: data,
      type: ContentType.FormData,
      ...params,
    });

  /**
   * @description Serve uploaded images
   *
   * @tags dbtn/module:image_upload, dbtn/hasAuth
   * @name serve_image
   * @summary Serve Image
   * @request GET:/routes/images/{image_filename}
   */
  serve_image = ({ imageFilename, ...query }: ServeImageParams, params: RequestParams = {}) =>
    this.request<ServeImageData, ServeImageError>({
      path: `/routes/images/${imageFilename}`,
      method: "GET",
      ...params,
    });

  /**
   * @description Delete an uploaded image
   *
   * @tags dbtn/module:image_upload, dbtn/hasAuth
   * @name delete_image
   * @summary Delete Image
   * @request DELETE:/routes/images/{image_filename}
   */
  delete_image = ({ imageFilename, ...query }: DeleteImageParams, params: RequestParams = {}) =>
    this.request<DeleteImageData, DeleteImageError>({
      path: `/routes/images/${imageFilename}`,
      method: "DELETE",
      ...params,
    });

  /**
   * @description Serve uploaded images publicly (alternative endpoint without auth requirement)
   *
   * @tags dbtn/module:image_upload, dbtn/hasAuth
   * @name serve_public_image_alt
   * @summary Serve Public Image Alt
   * @request GET:/routes/public-serve/{image_filename}
   */
  serve_public_image_alt = ({ imageFilename, ...query }: ServePublicImageAltParams, params: RequestParams = {}) =>
    this.request<ServePublicImageAltData, ServePublicImageAltError>({
      path: `/routes/public-serve/${imageFilename}`,
      method: "GET",
      ...params,
    });

  /**
   * @description List all uploaded images
   *
   * @tags dbtn/module:image_upload, dbtn/hasAuth
   * @name list_images
   * @summary List Images
   * @request GET:/routes/list-images
   */
  list_images = (params: RequestParams = {}) =>
    this.request<ListImagesData, any>({
      path: `/routes/list-images`,
      method: "GET",
      ...params,
    });

  /**
   * @description Health check endpoint
   *
   * @tags dbtn/module:knowledge_base, dbtn/hasAuth
   * @name knowledge_base_health
   * @summary Knowledge Base Health
   * @request GET:/routes/knowledge-base/health
   */
  knowledge_base_health = (params: RequestParams = {}) =>
    this.request<KnowledgeBaseHealthData, any>({
      path: `/routes/knowledge-base/health`,
      method: "GET",
      ...params,
    });

  /**
   * @description Upload a new document to the knowledge base
   *
   * @tags dbtn/module:knowledge_base, dbtn/hasAuth
   * @name upload_document
   * @summary Upload Document
   * @request POST:/routes/knowledge-base/documents
   */
  upload_document = (data: BodyUploadDocument, params: RequestParams = {}) =>
    this.request<UploadDocumentData, UploadDocumentError>({
      path: `/routes/knowledge-base/documents`,
      method: "POST",
      body: data,
      type: ContentType.FormData,
      ...params,
    });

  /**
   * @description List documents with caching for improved performance
   *
   * @tags dbtn/module:knowledge_base, dbtn/hasAuth
   * @name list_documents
   * @summary List Documents
   * @request GET:/routes/knowledge-base/documents
   */
  list_documents = (query: ListDocumentsParams, params: RequestParams = {}) =>
    this.request<ListDocumentsData, ListDocumentsError>({
      path: `/routes/knowledge-base/documents`,
      method: "GET",
      query: query,
      ...params,
    });

  /**
   * @description Update a document
   *
   * @tags dbtn/module:knowledge_base, dbtn/hasAuth
   * @name update_document
   * @summary Update Document
   * @request PUT:/routes/knowledge-base/documents/{document_id}
   */
  update_document = (
    { documentId, ...query }: UpdateDocumentParams,
    data: BodyUpdateDocument,
    params: RequestParams = {},
  ) =>
    this.request<UpdateDocumentData, UpdateDocumentError>({
      path: `/routes/knowledge-base/documents/${documentId}`,
      method: "PUT",
      body: data,
      type: ContentType.FormData,
      ...params,
    });

  /**
   * @description Get a single document by ID for editing
   *
   * @tags dbtn/module:knowledge_base, dbtn/hasAuth
   * @name get_document
   * @summary Get Document
   * @request GET:/routes/knowledge-base/documents/{document_id}
   */
  get_document = ({ documentId, ...query }: GetDocumentParams, params: RequestParams = {}) =>
    this.request<GetDocumentData, GetDocumentError>({
      path: `/routes/knowledge-base/documents/${documentId}`,
      method: "GET",
      ...params,
    });

  /**
   * @description Delete a document and all its sections from the knowledge base
   *
   * @tags dbtn/module:knowledge_base, dbtn/hasAuth
   * @name delete_document
   * @summary Delete Document
   * @request DELETE:/routes/knowledge-base/documents/{document_id}
   */
  delete_document = ({ documentId, ...query }: DeleteDocumentParams, params: RequestParams = {}) =>
    this.request<DeleteDocumentData, DeleteDocumentError>({
      path: `/routes/knowledge-base/documents/${documentId}`,
      method: "DELETE",
      ...params,
    });

  /**
   * @description Get all available metadata options for document upload forms
   *
   * @tags dbtn/module:knowledge_base, dbtn/hasAuth
   * @name get_knowledge_base_metadata_options
   * @summary Get Knowledge Base Metadata Options
   * @request GET:/routes/knowledge-base/metadata-options
   */
  get_knowledge_base_metadata_options = (params: RequestParams = {}) =>
    this.request<GetKnowledgeBaseMetadataOptionsData, any>({
      path: `/routes/knowledge-base/metadata-options`,
      method: "GET",
      ...params,
    });

  /**
   * @description Search documents with filters, full-text search, and pagination
   *
   * @tags dbtn/module:knowledge_base, dbtn/hasAuth
   * @name search_documents
   * @summary Search Documents
   * @request POST:/routes/knowledge-base/search
   */
  search_documents = (data: DocumentSearchRequest, params: RequestParams = {}) =>
    this.request<SearchDocumentsData, SearchDocumentsError>({
      path: `/routes/knowledge-base/search`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Advanced search with Boolean operators and filtering
   *
   * @tags dbtn/module:knowledge_base, dbtn/hasAuth
   * @name advanced_search_documents
   * @summary Advanced Search Documents
   * @request POST:/routes/knowledge-base/advanced-search
   */
  advanced_search_documents = (data: AdvancedSearchRequest, params: RequestParams = {}) =>
    this.request<AdvancedSearchDocumentsData, AdvancedSearchDocumentsError>({
      path: `/routes/knowledge-base/advanced-search`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Get search suggestions and auto-complete options
   *
   * @tags dbtn/module:knowledge_base, dbtn/hasAuth
   * @name get_search_suggestions
   * @summary Get Search Suggestions
   * @request GET:/routes/knowledge-base/search-suggestions
   */
  get_search_suggestions = (query: GetSearchSuggestionsParams, params: RequestParams = {}) =>
    this.request<GetSearchSuggestionsData, GetSearchSuggestionsError>({
      path: `/routes/knowledge-base/search-suggestions`,
      method: "GET",
      query: query,
      ...params,
    });

  /**
   * @description Download document file from storage
   *
   * @tags stream, dbtn/module:knowledge_base, dbtn/hasAuth
   * @name download_document_file
   * @summary Download Document File
   * @request GET:/routes/knowledge-base/file/{document_id}
   */
  download_document_file = ({ documentId, ...query }: DownloadDocumentFileParams, params: RequestParams = {}) =>
    this.requestStream<DownloadDocumentFileData, DownloadDocumentFileError>({
      path: `/routes/knowledge-base/file/${documentId}`,
      method: "GET",
      query: query,
      ...params,
    });

  /**
   * @description Get a single blog document by ID for editing
   *
   * @tags dbtn/module:knowledge_base, dbtn/hasAuth
   * @name get_blog_document
   * @summary Get Blog Document
   * @request GET:/routes/knowledge-base/blog/{document_id}
   */
  get_blog_document = ({ documentId, ...query }: GetBlogDocumentParams, params: RequestParams = {}) =>
    this.request<GetBlogDocumentData, GetBlogDocumentError>({
      path: `/routes/knowledge-base/blog/${documentId}`,
      method: "GET",
      ...params,
    });

  /**
   * @description Search blog documents with filters, full-text search, and pagination
   *
   * @tags dbtn/module:knowledge_base, dbtn/hasAuth
   * @name search_blog_documents
   * @summary Search Blog Documents
   * @request POST:/routes/knowledge-base/blog-search
   */
  search_blog_documents = (data: DocumentSearchRequest, params: RequestParams = {}) =>
    this.request<SearchBlogDocumentsData, SearchBlogDocumentsError>({
      path: `/routes/knowledge-base/blog-search`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description List blog documents with caching for improved performance
   *
   * @tags dbtn/module:knowledge_base, dbtn/hasAuth
   * @name list_blog_documents
   * @summary List Blog Documents
   * @request GET:/routes/knowledge-base/blog
   */
  list_blog_documents = (query: ListBlogDocumentsParams, params: RequestParams = {}) =>
    this.request<ListBlogDocumentsData, ListBlogDocumentsError>({
      path: `/routes/knowledge-base/blog`,
      method: "GET",
      query: query,
      ...params,
    });

  /**
   * @description Advanced search with Boolean operators and filtering
   *
   * @tags dbtn/module:knowledge_base, dbtn/hasAuth
   * @name advanced_search_blog_documents
   * @summary Advanced Search Blog Documents
   * @request POST:/routes/knowledge-base/blog-advanced-search
   */
  advanced_search_blog_documents = (data: AdvancedSearchRequest, params: RequestParams = {}) =>
    this.request<AdvancedSearchBlogDocumentsData, AdvancedSearchBlogDocumentsError>({
      path: `/routes/knowledge-base/blog-advanced-search`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Get search suggestions and auto-complete options
   *
   * @tags dbtn/module:knowledge_base, dbtn/hasAuth
   * @name get_blog_search_suggestions
   * @summary Get Blog Search Suggestions
   * @request GET:/routes/knowledge-base/blog-search-suggestions
   */
  get_blog_search_suggestions = (query: GetBlogSearchSuggestionsParams, params: RequestParams = {}) =>
    this.request<GetBlogSearchSuggestionsData, GetBlogSearchSuggestionsError>({
      path: `/routes/knowledge-base/blog-search-suggestions`,
      method: "GET",
      query: query,
      ...params,
    });

  /**
   * @description Get admin dashboard statistics
   *
   * @tags dbtn/module:admin_dashboard, dbtn/hasAuth
   * @name get_admin_stats
   * @summary Get Admin Stats
   * @request GET:/routes/admin-dashboard/stats
   */
  get_admin_stats = (params: RequestParams = {}) =>
    this.request<GetAdminStatsData, any>({
      path: `/routes/admin-dashboard/stats`,
      method: "GET",
      ...params,
    });

  /**
   * @description List all documents for admin management
   *
   * @tags dbtn/module:admin_dashboard, dbtn/hasAuth
   * @name list_admin_documents
   * @summary List Admin Documents
   * @request GET:/routes/admin-dashboard/documents
   */
  list_admin_documents = (query: ListAdminDocumentsParams, params: RequestParams = {}) =>
    this.request<ListAdminDocumentsData, ListAdminDocumentsError>({
      path: `/routes/admin-dashboard/documents`,
      method: "GET",
      query: query,
      ...params,
    });

  /**
   * @description Update the publishing status of a document
   *
   * @tags dbtn/module:admin_dashboard, dbtn/hasAuth
   * @name update_document_status
   * @summary Update Document Status
   * @request PUT:/routes/admin-dashboard/documents/{document_id}/status
   */
  update_document_status = (
    { documentId, ...query }: UpdateDocumentStatusParams,
    data: UpdateDocumentStatusRequest,
    params: RequestParams = {},
  ) =>
    this.request<UpdateDocumentStatusData, UpdateDocumentStatusError>({
      path: `/routes/admin-dashboard/documents/${documentId}/status`,
      method: "PUT",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Bulk publish/unpublish documents
   *
   * @tags dbtn/module:admin_dashboard, dbtn/hasAuth
   * @name publish_document
   * @summary Publish Document
   * @request POST:/routes/admin-dashboard/documents/publish
   */
  publish_document = (data: PublishDocumentRequest, params: RequestParams = {}) =>
    this.request<PublishDocumentData, PublishDocumentError>({
      path: `/routes/admin-dashboard/documents/publish`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Bulk update document statuses
   *
   * @tags dbtn/module:admin_dashboard, dbtn/hasAuth
   * @name bulk_update_status
   * @summary Bulk Update Status
   * @request POST:/routes/admin-dashboard/documents/bulk-status
   */
  bulk_update_status = (query: BulkUpdateStatusParams, data: BulkUpdateStatusPayload, params: RequestParams = {}) =>
    this.request<BulkUpdateStatusData, BulkUpdateStatusError>({
      path: `/routes/admin-dashboard/documents/bulk-status`,
      method: "POST",
      query: query,
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Create a new category
   *
   * @tags dbtn/module:admin_dashboard, dbtn/hasAuth
   * @name create_category
   * @summary Create Category
   * @request POST:/routes/admin-dashboard/categories
   */
  create_category = (data: AppApisAdminDashboardCategoryRequest, params: RequestParams = {}) =>
    this.request<CreateCategoryData, CreateCategoryError>({
      path: `/routes/admin-dashboard/categories`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Update a category
   *
   * @tags dbtn/module:admin_dashboard, dbtn/hasAuth
   * @name update_category
   * @summary Update Category
   * @request PUT:/routes/admin-dashboard/categories/{category_id}
   */
  update_category = (
    { categoryId, ...query }: UpdateCategoryParams,
    data: AppApisAdminDashboardCategoryRequest,
    params: RequestParams = {},
  ) =>
    this.request<UpdateCategoryData, UpdateCategoryError>({
      path: `/routes/admin-dashboard/categories/${categoryId}`,
      method: "PUT",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Delete a category
   *
   * @tags dbtn/module:admin_dashboard, dbtn/hasAuth
   * @name delete_category
   * @summary Delete Category
   * @request DELETE:/routes/admin-dashboard/categories/{category_id}
   */
  delete_category = ({ categoryId, ...query }: DeleteCategoryParams, params: RequestParams = {}) =>
    this.request<DeleteCategoryData, DeleteCategoryError>({
      path: `/routes/admin-dashboard/categories/${categoryId}`,
      method: "DELETE",
      ...params,
    });

  /**
   * @description Get metadata options for a specific category (jurisdiction, type, subject)
   *
   * @tags dbtn/module:admin_dashboard, dbtn/hasAuth
   * @name get_metadata_options
   * @summary Get Metadata Options
   * @request GET:/routes/admin-dashboard/metadata-options/{category}
   */
  get_metadata_options = ({ category, ...query }: GetMetadataOptionsParams, params: RequestParams = {}) =>
    this.request<GetMetadataOptionsData, GetMetadataOptionsError>({
      path: `/routes/admin-dashboard/metadata-options/${category}`,
      method: "GET",
      query: query,
      ...params,
    });

  /**
   * @description Create a new metadata option
   *
   * @tags dbtn/module:admin_dashboard, dbtn/hasAuth
   * @name create_metadata_option
   * @summary Create Metadata Option
   * @request POST:/routes/admin-dashboard/metadata-options
   */
  create_metadata_option = (data: MetadataOptionRequest, params: RequestParams = {}) =>
    this.request<CreateMetadataOptionData, CreateMetadataOptionError>({
      path: `/routes/admin-dashboard/metadata-options`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Update a metadata option
   *
   * @tags dbtn/module:admin_dashboard, dbtn/hasAuth
   * @name update_metadata_option
   * @summary Update Metadata Option
   * @request PUT:/routes/admin-dashboard/metadata-options/{option_id}
   */
  update_metadata_option = (
    { optionId, ...query }: UpdateMetadataOptionParams,
    data: MetadataOptionUpdate,
    params: RequestParams = {},
  ) =>
    this.request<UpdateMetadataOptionData, UpdateMetadataOptionError>({
      path: `/routes/admin-dashboard/metadata-options/${optionId}`,
      method: "PUT",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Delete a metadata option
   *
   * @tags dbtn/module:admin_dashboard, dbtn/hasAuth
   * @name delete_metadata_option
   * @summary Delete Metadata Option
   * @request DELETE:/routes/admin-dashboard/metadata-options/{option_id}
   */
  delete_metadata_option = ({ optionId, ...query }: DeleteMetadataOptionParams, params: RequestParams = {}) =>
    this.request<DeleteMetadataOptionData, DeleteMetadataOptionError>({
      path: `/routes/admin-dashboard/metadata-options/${optionId}`,
      method: "DELETE",
      ...params,
    });

  /**
   * @description Reorder metadata options within a category
   *
   * @tags dbtn/module:admin_dashboard, dbtn/hasAuth
   * @name reorder_metadata_options
   * @summary Reorder Metadata Options
   * @request PUT:/routes/admin-dashboard/metadata-options/reorder
   */
  reorder_metadata_options = (data: ReorderRequest, params: RequestParams = {}) =>
    this.request<ReorderMetadataOptionsData, ReorderMetadataOptionsError>({
      path: `/routes/admin-dashboard/metadata-options/reorder`,
      method: "PUT",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Create a new classification workflow (Admin only)
   *
   * @tags dbtn/module:classification_workflows, dbtn/hasAuth
   * @name create_workflow
   * @summary Create Workflow
   * @request POST:/routes/classification-workflows/admin/workflows
   */
  create_workflow = (data: ClassificationWorkflowCreate, params: RequestParams = {}) =>
    this.request<CreateWorkflowData, CreateWorkflowError>({
      path: `/routes/classification-workflows/admin/workflows`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description List classification workflows for admin with optional type filtering
   *
   * @tags dbtn/module:classification_workflows, dbtn/hasAuth
   * @name list_admin_workflows
   * @summary List Admin Workflows
   * @request GET:/routes/classification-workflows/admin/workflows
   */
  list_admin_workflows = (query: ListAdminWorkflowsParams, params: RequestParams = {}) =>
    this.request<ListAdminWorkflowsData, ListAdminWorkflowsError>({
      path: `/routes/classification-workflows/admin/workflows`,
      method: "GET",
      query: query,
      ...params,
    });

  /**
   * @description Get workflow by ID (Admin only)
   *
   * @tags dbtn/module:classification_workflows, dbtn/hasAuth
   * @name get_workflow_by_id
   * @summary Get Workflow By Id
   * @request GET:/routes/classification-workflows/admin/workflows/{workflow_id}
   */
  get_workflow_by_id = ({ workflowId, ...query }: GetWorkflowByIdParams, params: RequestParams = {}) =>
    this.request<GetWorkflowByIdData, GetWorkflowByIdError>({
      path: `/routes/classification-workflows/admin/workflows/${workflowId}`,
      method: "GET",
      ...params,
    });

  /**
   * @description Update a classification workflow (Admin only)
   *
   * @tags dbtn/module:classification_workflows, dbtn/hasAuth
   * @name update_workflow
   * @summary Update Workflow
   * @request PUT:/routes/classification-workflows/admin/workflows/{workflow_id}
   */
  update_workflow = (
    { workflowId, ...query }: UpdateWorkflowParams,
    data: ClassificationWorkflowUpdate,
    params: RequestParams = {},
  ) =>
    this.request<UpdateWorkflowData, UpdateWorkflowError>({
      path: `/routes/classification-workflows/admin/workflows/${workflowId}`,
      method: "PUT",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Delete a classification workflow (Admin only)
   *
   * @tags dbtn/module:classification_workflows, dbtn/hasAuth
   * @name delete_workflow
   * @summary Delete Workflow
   * @request DELETE:/routes/classification-workflows/admin/workflows/{workflow_id}
   */
  delete_workflow = ({ workflowId, ...query }: DeleteWorkflowParams, params: RequestParams = {}) =>
    this.request<DeleteWorkflowData, DeleteWorkflowError>({
      path: `/routes/classification-workflows/admin/workflows/${workflowId}`,
      method: "DELETE",
      ...params,
    });

  /**
   * @description Get all classification workflows for the authenticated user
   *
   * @tags dbtn/module:classification_workflows, dbtn/hasAuth
   * @name list_workflows
   * @summary List Workflows
   * @request GET:/routes/classification-workflows/workflows
   */
  list_workflows = (params: RequestParams = {}) =>
    this.request<ListWorkflowsData, any>({
      path: `/routes/classification-workflows/workflows`,
      method: "GET",
      ...params,
    });

  /**
   * @description Get a published workflow by ID for users
   *
   * @tags dbtn/module:classification_workflows, dbtn/hasAuth
   * @name get_published_workflow
   * @summary Get Published Workflow
   * @request GET:/routes/classification-workflows/workflows/{workflow_id}
   */
  get_published_workflow = ({ workflowId, ...query }: GetPublishedWorkflowParams, params: RequestParams = {}) =>
    this.request<GetPublishedWorkflowData, GetPublishedWorkflowError>({
      path: `/routes/classification-workflows/workflows/${workflowId}`,
      method: "GET",
      ...params,
    });
}
