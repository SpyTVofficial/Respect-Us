import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { Plus, Edit, Trash2, FileText, BookOpen, Calendar, User, Copy, Database } from 'lucide-react';
import { toast } from 'sonner';
import brain from 'brain';
import type {
  ClassificationNote
} from '../brain/data-contracts';

interface SharedMetadataTabProps {
  activeModule?: string;
}

const SharedMetadataTab: React.FC<SharedMetadataTabProps> = ({ activeModule = 'product_classification' }) => {
  const [notes, setNotes] = useState<ClassificationNote[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [editingNote, setEditingNote] = useState<ClassificationNote | null>(null);
  const [selectedModule, setSelectedModule] = useState(activeModule);
  const [formData, setFormData] = useState({
    note_key: '',
    title: '',
    content: '',
    tree_id: '',
    module_type: activeModule
  });

  const modules = [
    { value: 'product_classification', label: 'Product Classification' },
    { value: 'sanctions_embargoes', label: 'Sanctions & Embargoes' },
    { value: 'license_determination', label: 'License Determination' }
  ];

  useEffect(() => {
    loadData();
  }, [selectedModule]);

  const loadData = async () => {
    try {
      setLoading(true);
      
      // Load notes filtered by selected module
      const notesResponse = await brain.list_classification_notes({ module_type: selectedModule });
      if (notesResponse.ok) {
        const notesData = await notesResponse.json();
        // Sort notes alphabetically by note_key
        const sortedNotes = notesData.sort((a: ClassificationNote, b: ClassificationNote) => 
          a.note_key.localeCompare(b.note_key)
        );
        setNotes(sortedNotes);
      }
    } catch (error) {
      console.error('Error loading metadata:', error);
      toast.error('Failed to load metadata');
    } finally {
      setLoading(false);
    }
  };

  const handleCreateNote = async () => {
    try {
      if (!formData.note_key || !formData.title || !formData.content) {
        toast.error('Please fill in required fields');
        return;
      }

      const response = await brain.create_classification_note({
        note_key: formData.note_key,
        title: formData.title,
        content: formData.content,
        tree_id: formData.tree_id === 'global' ? null : formData.tree_id || null,
        module_type: selectedModule
      });

      if (response.ok) {
        toast.success('Metadata entry created successfully');
        setShowCreateDialog(false);
        resetForm();
        loadData();
      } else {
        const errorData = await response.json();
        toast.error(errorData.detail || 'Failed to create metadata entry');
      }
    } catch (error) {
      console.error('Error creating metadata entry:', error);
      toast.error('Failed to create metadata entry');
    }
  };

  const handleEditNote = (note: ClassificationNote) => {
    setEditingNote(note);
    setFormData({
      note_key: note.note_key,
      title: note.title,
      content: note.content,
      tree_id: note.tree_id || 'global',
      module_type: note.module_type || selectedModule
    });
    setShowEditDialog(true);
  };

  const handleUpdateNote = async () => {
    try {
      if (!editingNote || !formData.note_key || !formData.title || !formData.content) {
        toast.error('Please fill in required fields');
        return;
      }

      const response = await brain.update_classification_note(
        { noteId: editingNote.id! },
        {
          note_key: formData.note_key,
          title: formData.title,
          content: formData.content
        }
      );

      if (response.ok) {
        toast.success('Metadata entry updated successfully');
        setShowEditDialog(false);
        setEditingNote(null);
        resetForm();
        loadData();
      } else {
        const errorData = await response.json();
        toast.error(errorData.detail || 'Failed to update metadata entry');
      }
    } catch (error) {
      console.error('Error updating metadata entry:', error);
      toast.error('Failed to update metadata entry');
    }
  };

  const handleDeleteNote = async (noteId: number) => {
    try {
      const response = await brain.delete_classification_note({ noteId });
      if (response.ok) {
        toast.success('Metadata entry deleted successfully');
        loadData();
      } else {
        const errorData = await response.json();
        toast.error(errorData.detail || 'Failed to delete metadata entry');
      }
    } catch (error) {
      console.error('Error deleting metadata entry:', error);
      toast.error('Failed to delete metadata entry');
    }
  };

  const handleDuplicateNote = async (note: ClassificationNote) => {
    try {
      const duplicateData = {
        note_key: `${note.note_key}_copy`,
        title: `${note.title} (Copy)`,
        content: note.content,
        tree_id: note.tree_id,
        module_type: selectedModule
      };

      const response = await brain.create_classification_note(duplicateData);

      if (response.ok) {
        toast.success('Metadata entry duplicated successfully');
        loadData();
      } else {
        const errorData = await response.json();
        toast.error(errorData.detail || 'Failed to duplicate metadata entry');
      }
    } catch (error) {
      console.error('Error duplicating metadata entry:', error);
      toast.error('Failed to duplicate metadata entry');
    }
  };

  const resetForm = () => {
    setFormData({
      note_key: '',
      title: '',
      content: '',
      tree_id: '',
      module_type: selectedModule
    });
  };

  const getModuleLabel = (moduleType: string) => {
    const module = modules.find(m => m.value === moduleType);
    return module ? module.label : moduleType;
  };

  const formatDate = (dateString: string | null) => {
    if (!dateString) return 'N/A';
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h3 className="text-xl font-semibold text-blue-400">Shared Metadata Management</h3>
          <p className="text-gray-400 text-sm mt-1">Manage metadata and documentation across all modules</p>
        </div>
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <Label className="text-gray-300 text-sm">Module:</Label>
            <Select value={selectedModule} onValueChange={setSelectedModule}>
              <SelectTrigger className="w-48 bg-gray-800 border-gray-600 text-white">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-gray-800 border-gray-600">
                {modules.map(module => (
                  <SelectItem key={module.value} value={module.value} className="text-white">
                    {module.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <Button 
            onClick={() => {
              resetForm();
              setFormData(prev => ({ ...prev, module_type: selectedModule }));
              setShowCreateDialog(true);
            }}
            className="bg-blue-600 hover:bg-blue-700 text-white"
          >
            <Plus className="w-4 h-4 mr-2" />
            Create Entry
          </Button>
        </div>
      </div>

      {loading ? (
        <div className="text-center py-8">
          <p className="text-gray-400">Loading metadata...</p>
        </div>
      ) : (
        <div className="w-full">
          {notes.length === 0 ? (
            <div className="text-center py-8">
              <Database className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-400">No metadata entries found for {getModuleLabel(selectedModule)}</p>
              <p className="text-gray-500 text-sm">Create your first metadata entry to get started</p>
            </div>
          ) : (
            <div className="w-full overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="text-white min-w-[120px]">Key</TableHead>
                    <TableHead className="text-white min-w-[200px]">Title</TableHead>
                    <TableHead className="text-white min-w-[300px]">Content</TableHead>
                    <TableHead className="text-white min-w-[120px]">Module</TableHead>
                    <TableHead className="text-white min-w-[120px]">Tree/Scope</TableHead>
                    <TableHead className="text-white min-w-[150px]">Created At</TableHead>
                    <TableHead className="text-white min-w-[120px]">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {notes.map((note) => (
                    <TableRow key={note.id} className="border-gray-700 hover:bg-gray-800/50">
                      <TableCell className="text-blue-300 font-medium">
                        <div className="flex items-center gap-2">
                          <BookOpen className="w-4 h-4 text-blue-400" />
                          {note.note_key}
                        </div>
                      </TableCell>
                      <TableCell className="text-white">{note.title}</TableCell>
                      <TableCell className="text-gray-300">
                        <div className="max-w-[300px] truncate" title={note.content}>
                          {note.content}
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline" className="text-xs">
                          {getModuleLabel(note.module_type || 'product_classification')}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline" className="text-xs">
                          <FileText className="w-3 h-3 mr-1" />
                          {note.tree_id ? 'Specific Tree' : 'Global'}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-gray-400 text-sm">
                        <div className="flex items-center gap-1">
                          <Calendar className="w-3 h-3" />
                          {formatDate(note.created_at)}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex gap-1">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleEditNote(note)}
                            className="text-gray-400 hover:text-white"
                            title="Edit Entry"
                          >
                            <Edit className="w-4 h-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleDuplicateNote(note)}
                            className="text-gray-400 hover:text-blue-400"
                            title="Duplicate Entry"
                          >
                            <Copy className="w-4 h-4" />
                          </Button>
                          <AlertDialog>
                            <AlertDialogTrigger asChild>
                              <Button
                                variant="ghost"
                                size="sm"
                                className="text-gray-400 hover:text-red-400"
                                title="Delete Entry"
                              >
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </AlertDialogTrigger>
                            <AlertDialogContent className="bg-gray-900 border-gray-700">
                              <AlertDialogHeader>
                                <AlertDialogTitle className="text-white">Delete Metadata Entry</AlertDialogTitle>
                                <AlertDialogDescription className="text-gray-400">
                                  Are you sure you want to delete this metadata entry? This action cannot be undone.
                                </AlertDialogDescription>
                              </AlertDialogHeader>
                              <AlertDialogFooter>
                                <AlertDialogCancel className="bg-gray-800 border-gray-600 text-white hover:bg-gray-700">
                                  Cancel
                                </AlertDialogCancel>
                                <AlertDialogAction
                                  onClick={() => handleDeleteNote(note.id!)}
                                  className="bg-red-600 hover:bg-red-700 text-white"
                                >
                                  Delete
                                </AlertDialogAction>
                              </AlertDialogFooter>
                            </AlertDialogContent>
                          </AlertDialog>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </div>
      )}

      {/* Create Metadata Entry Dialog */}
      <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
        <DialogContent className="bg-gray-900 border-gray-700 text-white max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-blue-400">Create Metadata Entry</DialogTitle>
            <DialogDescription className="text-gray-400">
              Create a new metadata entry for {getModuleLabel(selectedModule)}
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="text-gray-300">Key *</Label>
                <Input
                  value={formData.note_key}
                  onChange={(e) => setFormData({ ...formData, note_key: e.target.value })}
                  className="bg-gray-800 border-gray-600 text-white"
                  placeholder="e.g., META001, REG-NOTE-1"
                />
              </div>
              <div className="space-y-2">
                <Label className="text-gray-300">Scope</Label>
                <Select value={formData.tree_id} onValueChange={(value) => setFormData({ ...formData, tree_id: value === 'global' ? '' : value })}>
                  <SelectTrigger className="bg-gray-800 border-gray-600 text-white">
                    <SelectValue placeholder="Global (all trees)" />
                  </SelectTrigger>
                  <SelectContent className="bg-gray-800 border-gray-600">
                    <SelectItem value="global" className="text-white">
                      Global (all trees)
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <div className="space-y-2">
              <Label className="text-gray-300">Title *</Label>
              <Input
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                className="bg-gray-800 border-gray-600 text-white"
                placeholder="Brief descriptive title"
              />
            </div>
            
            <div className="space-y-2">
              <Label className="text-gray-300">Content *</Label>
              <Textarea
                value={formData.content}
                onChange={(e) => setFormData({ ...formData, content: e.target.value })}
                className="bg-gray-800 border-gray-600 text-white"
                placeholder="Detailed metadata content"
                rows={6}
              />
            </div>
          </div>
          
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => setShowCreateDialog(false)}
              className="bg-gray-800 border-gray-600 text-white hover:bg-gray-700"
            >
              Cancel
            </Button>
            <Button 
              onClick={handleCreateNote}
              className="bg-blue-600 hover:bg-blue-700 text-white"
            >
              Create Entry
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Metadata Entry Dialog */}
      <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
        <DialogContent className="bg-gray-900 border-gray-700 text-white max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-blue-400">Edit Metadata Entry</DialogTitle>
            <DialogDescription className="text-gray-400">
              Update the metadata entry details
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="text-gray-300">Key *</Label>
                <Input
                  value={formData.note_key}
                  onChange={(e) => setFormData({ ...formData, note_key: e.target.value })}
                  className="bg-gray-800 border-gray-600 text-white"
                  placeholder="e.g., META001, REG-NOTE-1"
                />
              </div>
              <div className="space-y-2">
                <Label className="text-gray-300">Module</Label>
                <Input
                  value={getModuleLabel(editingNote?.module_type || 'product_classification')}
                  disabled
                  className="bg-gray-800 border-gray-600 text-gray-400"
                />
              </div>
            </div>
            
            <div className="space-y-2">
              <Label className="text-gray-300">Title *</Label>
              <Input
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                className="bg-gray-800 border-gray-600 text-white"
                placeholder="Brief descriptive title"
              />
            </div>
            
            <div className="space-y-2">
              <Label className="text-gray-300">Content *</Label>
              <Textarea
                value={formData.content}
                onChange={(e) => setFormData({ ...formData, content: e.target.value })}
                className="bg-gray-800 border-gray-600 text-white"
                placeholder="Detailed metadata content"
                rows={6}
              />
            </div>
          </div>
          
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => setShowEditDialog(false)}
              className="bg-gray-800 border-gray-600 text-white hover:bg-gray-700"
            >
              Cancel
            </Button>
            <Button 
              onClick={handleUpdateNote}
              className="bg-blue-600 hover:bg-blue-700 text-white"
            >
              Update Entry
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default SharedMetadataTab;
