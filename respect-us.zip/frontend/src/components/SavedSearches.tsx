import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Trash2, Play, Edit, Bell, BellOff, Clock, Search, Plus } from 'lucide-react';
import { toast } from 'sonner';
import brain from 'brain';
import { SavedSearchResponse, SavedSearchRequest, SavedSearchUpdate } from 'types';

export interface SavedSearchesProps {
  onSearchSelected?: (searchQuery: string, searchMode: string, filters?: any) => void;
}

export const SavedSearches: React.FC<SavedSearchesProps> = ({ onSearchSelected }) => {
  const [savedSearches, setSavedSearches] = useState<SavedSearchResponse[]>([]);
  const [loading, setLoading] = useState(true);
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [editingSearch, setEditingSearch] = useState<SavedSearchResponse | null>(null);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);

  const [newSearch, setNewSearch] = useState<SavedSearchRequest>({
    name: '',
    description: '',
    search_query: '',
    search_mode: 'simple',
    filters: {},
    alert_enabled: false,
    alert_frequency: 'daily'
  });

  useEffect(() => {
    loadSavedSearches();
  }, []);

  const loadSavedSearches = async () => {
    try {
      setLoading(true);
      const response = await brain.list_saved_searches();
      const searches = await response.json();
      setSavedSearches(searches);
    } catch (error) {
      console.error('Failed to load saved searches:', error);
      toast.error('Failed to load saved searches');
    } finally {
      setLoading(false);
    }
  };

  const createSavedSearch = async () => {
    try {
      if (!newSearch.name.trim() || !newSearch.search_query.trim()) {
        toast.error('Name and search query are required');
        return;
      }

      const response = await brain.create_saved_search(newSearch);
      await response.json();
      
      toast.success('Saved search created successfully');
      setIsCreateDialogOpen(false);
      setNewSearch({
        name: '',
        description: '',
        search_query: '',
        search_mode: 'simple',
        filters: {},
        alert_enabled: false,
        alert_frequency: 'daily'
      });
      loadSavedSearches();
    } catch (error) {
      console.error('Failed to create saved search:', error);
      toast.error('Failed to create saved search');
    }
  };

  const updateSavedSearch = async () => {
    if (!editingSearch) return;

    try {
      const updateData: SavedSearchUpdate = {
        name: editingSearch.name,
        description: editingSearch.description,
        search_query: editingSearch.search_query,
        search_mode: editingSearch.search_mode,
        filters: editingSearch.filters,
        alert_enabled: editingSearch.alert_enabled,
        alert_frequency: editingSearch.alert_frequency
      };

      const response = await brain.update_saved_search({ searchId: editingSearch.id.toString() }, updateData);
      await response.json();
      
      toast.success('Saved search updated successfully');
      setIsEditDialogOpen(false);
      setEditingSearch(null);
      loadSavedSearches();
    } catch (error) {
      console.error('Failed to update saved search:', error);
      toast.error('Failed to update saved search');
    }
  };

  const deleteSavedSearch = async (id: number) => {
    try {
      const response = await brain.delete_saved_search({ searchId: id.toString() });
      await response.json();
      
      toast.success('Saved search deleted successfully');
      loadSavedSearches();
    } catch (error) {
      console.error('Failed to delete saved search:', error);
      toast.error('Failed to delete saved search');
    }
  };

  const runSavedSearch = async (search: SavedSearchResponse) => {
    try {
      const response = await brain.run_saved_search({ searchId: search.id.toString() });
      const results = await response.json();
      
      toast.success(`Search executed: ${results.documents.length} documents found`);
      
      // Use the search in the parent component if callback provided
      if (onSearchSelected) {
        onSearchSelected(search.search_query, search.search_mode, search.filters);
      }
      
      loadSavedSearches(); // Refresh to update last_run timestamp
    } catch (error) {
      console.error('Failed to run saved search:', error);
      toast.error('Failed to run saved search');
    }
  };

  const formatDate = (date: string) => {
    return new Date(date).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getSearchModeColor = (mode: string) => {
    switch (mode) {
      case 'boolean': return 'bg-blue-500/20 text-blue-400';
      case 'phrase': return 'bg-green-500/20 text-green-400';
      case 'wildcard': return 'bg-purple-500/20 text-purple-400';
      case 'fuzzy': return 'bg-orange-500/20 text-orange-400';
      default: return 'bg-gray-500/20 text-gray-400';
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="text-gray-400">Loading saved searches...</div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold text-gray-200">Saved Searches</h3>
          <p className="text-sm text-gray-400">Manage your saved search queries and alerts</p>
        </div>
        
        <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-blue-600 hover:bg-blue-700">
              <Plus className="w-4 h-4 mr-2" />
              Create Search
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-gray-900 border-gray-700 max-w-2xl">
            <DialogHeader>
              <DialogTitle className="text-gray-200">Create Saved Search</DialogTitle>
              <DialogDescription className="text-gray-400">
                Save a search query with optional alerts for new matching documents
              </DialogDescription>
            </DialogHeader>
            
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-gray-300">Name *</Label>
                  <Input
                    value={newSearch.name}
                    onChange={(e) => setNewSearch({...newSearch, name: e.target.value})}
                    className="bg-gray-800 border-gray-600 text-gray-200"
                    placeholder="Export Control Updates"
                  />
                </div>
                <div>
                  <Label className="text-gray-300">Search Mode</Label>
                  <Select
                    value={newSearch.search_mode}
                    onValueChange={(value) => setNewSearch({...newSearch, search_mode: value})}
                  >
                    <SelectTrigger className="bg-gray-800 border-gray-600 text-gray-200">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-gray-800 border-gray-600">
                      <SelectItem value="simple">Simple</SelectItem>
                      <SelectItem value="boolean">Boolean</SelectItem>
                      <SelectItem value="phrase">Phrase</SelectItem>
                      <SelectItem value="wildcard">Wildcard</SelectItem>
                      <SelectItem value="fuzzy">Fuzzy</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div>
                <Label className="text-gray-300">Search Query *</Label>
                <Textarea
                  value={newSearch.search_query}
                  onChange={(e) => setNewSearch({...newSearch, search_query: e.target.value})}
                  className="bg-gray-800 border-gray-600 text-gray-200"
                  placeholder="export AND control NOT sanctions"
                  rows={2}
                />
              </div>
              
              <div>
                <Label className="text-gray-300">Description</Label>
                <Textarea
                  value={newSearch.description || ''}
                  onChange={(e) => setNewSearch({...newSearch, description: e.target.value})}
                  className="bg-gray-800 border-gray-600 text-gray-200"
                  placeholder="Monitor new export control regulations..."
                  rows={2}
                />
              </div>
              
              <div className="flex items-center space-x-2">
                <Switch
                  checked={newSearch.alert_enabled}
                  onCheckedChange={(checked) => setNewSearch({...newSearch, alert_enabled: checked})}
                />
                <Label className="text-gray-300">Enable alerts for new matches</Label>
              </div>
              
              {newSearch.alert_enabled && (
                <div>
                  <Label className="text-gray-300">Alert Frequency</Label>
                  <Select
                    value={newSearch.alert_frequency}
                    onValueChange={(value) => setNewSearch({...newSearch, alert_frequency: value})}
                  >
                    <SelectTrigger className="bg-gray-800 border-gray-600 text-gray-200">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-gray-800 border-gray-600">
                      <SelectItem value="immediate">Immediate</SelectItem>
                      <SelectItem value="daily">Daily</SelectItem>
                      <SelectItem value="weekly">Weekly</SelectItem>
                      <SelectItem value="monthly">Monthly</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              )}
            </div>
            
            <div className="flex justify-end space-x-2 pt-4">
              <Button
                variant="outline"
                onClick={() => setIsCreateDialogOpen(false)}
                className="border-gray-600 text-gray-300 hover:bg-gray-800"
              >
                Cancel
              </Button>
              <Button
                onClick={createSavedSearch}
                className="bg-blue-600 hover:bg-blue-700"
              >
                Create Search
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {savedSearches.length === 0 ? (
        <Card className="bg-gray-800/50 border-gray-700">
          <CardContent className="p-8 text-center">
            <Search className="w-12 h-12 text-gray-500 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-300 mb-2">No saved searches</h3>
            <p className="text-gray-500 mb-4">Create your first saved search to monitor regulatory updates</p>
            <Button
              onClick={() => setIsCreateDialogOpen(true)}
              className="bg-blue-600 hover:bg-blue-700"
            >
              <Plus className="w-4 h-4 mr-2" />
              Create Your First Search
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4">
          {savedSearches.map((search) => (
            <Card key={search.id} className="bg-gray-800/50 border-gray-700 hover:bg-gray-800/70 transition-colors">
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <CardTitle className="text-gray-200 text-base">{search.name}</CardTitle>
                      <Badge className={`text-xs ${getSearchModeColor(search.search_mode)}`}>
                        {search.search_mode}
                      </Badge>
                      {search.alert_enabled && (
                        <Badge className="bg-green-500/20 text-green-400 text-xs">
                          <Bell className="w-3 h-3 mr-1" />
                          {search.alert_frequency}
                        </Badge>
                      )}
                    </div>
                    {search.description && (
                      <CardDescription className="text-gray-400 text-sm">
                        {search.description}
                      </CardDescription>
                    )}
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => runSavedSearch(search)}
                      className="border-gray-600 text-gray-300 hover:bg-gray-700"
                    >
                      <Play className="w-4 h-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => {
                        setEditingSearch(search);
                        setIsEditDialogOpen(true);
                      }}
                      className="border-gray-600 text-gray-300 hover:bg-gray-700"
                    >
                      <Edit className="w-4 h-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => deleteSavedSearch(search.id)}
                      className="border-gray-600 text-red-400 hover:bg-red-900/20"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
              
              <CardContent className="pt-0">
                <div className="bg-gray-900/50 rounded p-3 mb-3">
                  <code className="text-sm text-gray-300">{search.search_query}</code>
                </div>
                
                <div className="flex items-center justify-between text-xs text-gray-500">
                  <div className="flex items-center gap-4">
                    <span>Created: {formatDate(search.created_at)}</span>
                    {search.last_run && (
                      <span className="flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        Last run: {formatDate(search.last_run)}
                      </span>
                    )}
                  </div>
                  {search.result_count !== null && (
                    <span>{search.result_count} results</span>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
      
      {/* Edit Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="bg-gray-900 border-gray-700 max-w-2xl">
          <DialogHeader>
            <DialogTitle className="text-gray-200">Edit Saved Search</DialogTitle>
            <DialogDescription className="text-gray-400">
              Update your saved search and alert settings
            </DialogDescription>
          </DialogHeader>
          
          {editingSearch && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-gray-300">Name *</Label>
                  <Input
                    value={editingSearch.name}
                    onChange={(e) => setEditingSearch({...editingSearch, name: e.target.value})}
                    className="bg-gray-800 border-gray-600 text-gray-200"
                  />
                </div>
                <div>
                  <Label className="text-gray-300">Search Mode</Label>
                  <Select
                    value={editingSearch.search_mode}
                    onValueChange={(value) => setEditingSearch({...editingSearch, search_mode: value})}
                  >
                    <SelectTrigger className="bg-gray-800 border-gray-600 text-gray-200">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-gray-800 border-gray-600">
                      <SelectItem value="simple">Simple</SelectItem>
                      <SelectItem value="boolean">Boolean</SelectItem>
                      <SelectItem value="phrase">Phrase</SelectItem>
                      <SelectItem value="wildcard">Wildcard</SelectItem>
                      <SelectItem value="fuzzy">Fuzzy</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div>
                <Label className="text-gray-300">Search Query *</Label>
                <Textarea
                  value={editingSearch.search_query}
                  onChange={(e) => setEditingSearch({...editingSearch, search_query: e.target.value})}
                  className="bg-gray-800 border-gray-600 text-gray-200"
                  rows={2}
                />
              </div>
              
              <div>
                <Label className="text-gray-300">Description</Label>
                <Textarea
                  value={editingSearch.description || ''}
                  onChange={(e) => setEditingSearch({...editingSearch, description: e.target.value})}
                  className="bg-gray-800 border-gray-600 text-gray-200"
                  rows={2}
                />
              </div>
              
              <div className="flex items-center space-x-2">
                <Switch
                  checked={editingSearch.alert_enabled}
                  onCheckedChange={(checked) => setEditingSearch({...editingSearch, alert_enabled: checked})}
                />
                <Label className="text-gray-300">Enable alerts for new matches</Label>
              </div>
              
              {editingSearch.alert_enabled && (
                <div>
                  <Label className="text-gray-300">Alert Frequency</Label>
                  <Select
                    value={editingSearch.alert_frequency}
                    onValueChange={(value) => setEditingSearch({...editingSearch, alert_frequency: value})}
                  >
                    <SelectTrigger className="bg-gray-800 border-gray-600 text-gray-200">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-gray-800 border-gray-600">
                      <SelectItem value="immediate">Immediate</SelectItem>
                      <SelectItem value="daily">Daily</SelectItem>
                      <SelectItem value="weekly">Weekly</SelectItem>
                      <SelectItem value="monthly">Monthly</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              )}
            </div>
          )}
          
          <div className="flex justify-end space-x-2 pt-4">
            <Button
              variant="outline"
              onClick={() => setIsEditDialogOpen(false)}
              className="border-gray-600 text-gray-300 hover:bg-gray-800"
            >
              Cancel
            </Button>
            <Button
              onClick={updateSavedSearch}
              className="bg-blue-600 hover:bg-blue-700"
            >
              Update Search
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};
