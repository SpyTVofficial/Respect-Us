import React, { useState, useEffect } from 'react';
import { ChevronDown, ChevronRight, FileText, Book, List, Hash, Tag, ExternalLink, Search, Filter } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { Separator } from '@/components/ui/separator';
import { toast } from 'sonner';
import brain from 'brain';
import { DocumentSectionsResponse } from 'types';

interface Props {
  documentId: number;
  documentTitle?: string;
  onSectionClick?: (sectionId: number, sectionTitle: string) => void;
  showTableOfContents?: boolean;
  showFilters?: boolean;
  showSearch?: boolean;
}

interface EnhancedSection {
  id: number;
  section_number: string;
  section_title: string;
  section_content: string;
  section_type: string;
  level: number;
  parent_section_id?: number;
  display_order: number;
  cross_references: string[];
  regulatory_references: string[];
  definitions: string[];
  keywords: string[];
  children?: EnhancedSection[];
}

interface TableOfContentsItem {
  id: string;
  title: string;
  level: number;
  children?: TableOfContentsItem[];
  section_id?: number;
}

const getSectionIcon = (sectionType: string) => {
  switch (sectionType.toLowerCase()) {
    case 'title':
    case 'chapter':
      return <Book className="w-4 h-4" />;
    case 'article':
    case 'section':
      return <FileText className="w-4 h-4" />;
    case 'subsection':
    case 'paragraph':
      return <List className="w-4 h-4" />;
    case 'annex':
    case 'appendix':
      return <Hash className="w-4 h-4" />;
    default:
      return <FileText className="w-4 h-4" />;
  }
};

const getSectionTypeColor = (sectionType: string) => {
  switch (sectionType.toLowerCase()) {
    case 'title':
      return 'bg-purple-100 text-purple-800 border-purple-200';
    case 'chapter':
      return 'bg-blue-100 text-blue-800 border-blue-200';
    case 'article':
      return 'bg-green-100 text-green-800 border-green-200';
    case 'section':
      return 'bg-orange-100 text-orange-800 border-orange-200';
    case 'subsection':
      return 'bg-yellow-100 text-yellow-800 border-yellow-200';
    case 'paragraph':
      return 'bg-gray-100 text-gray-800 border-gray-200';
    case 'annex':
    case 'appendix':
      return 'bg-indigo-100 text-indigo-800 border-indigo-200';
    case 'preamble':
      return 'bg-pink-100 text-pink-800 border-pink-200';
    case 'definitions':
      return 'bg-teal-100 text-teal-800 border-teal-200';
    default:
      return 'bg-gray-100 text-gray-800 border-gray-200';
  }
};

const TableOfContentsView: React.FC<{ toc: TableOfContentsItem[]; onSectionClick?: (sectionId: number, title: string) => void }> = ({ toc, onSectionClick }) => {
  const [expandedItems, setExpandedItems] = useState<Set<string>>(new Set());

  const toggleExpanded = (id: string) => {
    const newExpanded = new Set(expandedItems);
    if (newExpanded.has(id)) {
      newExpanded.delete(id);
    } else {
      newExpanded.add(id);
    }
    setExpandedItems(newExpanded);
  };

  const renderTocItem = (item: TableOfContentsItem) => {
    const hasChildren = item.children && item.children.length > 0;
    const isExpanded = expandedItems.has(item.id);
    const paddingLeft = `${item.level * 16}px`;

    return (
      <div key={item.id} className="border-l border-gray-200 dark:border-gray-700">
        <div 
          className="flex items-center gap-2 py-2 px-3 hover:bg-gray-50 dark:hover:bg-gray-800 cursor-pointer"
          style={{ paddingLeft }}
          onClick={() => {
            if (hasChildren) {
              toggleExpanded(item.id);
            }
            if (item.section_id && onSectionClick) {
              onSectionClick(item.section_id, item.title);
            }
          }}
        >
          {hasChildren && (
            <Button variant="ghost" size="sm" className="p-0 h-4 w-4">
              {isExpanded ? <ChevronDown className="w-3 h-3" /> : <ChevronRight className="w-3 h-3" />}
            </Button>
          )}
          {!hasChildren && <div className="w-4" />}
          <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
            {item.title}
          </span>
        </div>
        
        {hasChildren && isExpanded && (
          <div className="ml-2">
            {item.children!.map(child => renderTocItem(child))}
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="space-y-1">
      {toc.map(item => renderTocItem(item))}
    </div>
  );
};

const SectionView: React.FC<{ 
  sections: EnhancedSection[]; 
  onSectionClick?: (sectionId: number, sectionTitle: string) => void;
  searchTerm?: string;
  filterType?: string;
}> = ({ sections, onSectionClick, searchTerm, filterType }) => {
  const [expandedSections, setExpandedSections] = useState<Set<number>>(new Set());

  const toggleSection = (sectionId: number) => {
    const newExpanded = new Set(expandedSections);
    if (newExpanded.has(sectionId)) {
      newExpanded.delete(sectionId);
    } else {
      newExpanded.add(sectionId);
    }
    setExpandedSections(newExpanded);
  };

  const filteredSections = sections.filter(section => {
    if (filterType && filterType !== 'all' && section.section_type !== filterType) {
      return false;
    }
    if (searchTerm) {
      const searchLower = searchTerm.toLowerCase();
      return (
        section.section_title.toLowerCase().includes(searchLower) ||
        section.section_content.toLowerCase().includes(searchLower) ||
        section.keywords.some(keyword => keyword.toLowerCase().includes(searchLower))
      );
    }
    return true;
  });

  const renderSection = (section: EnhancedSection) => {
    const isExpanded = expandedSections.has(section.id);
    const hasChildren = section.children && section.children.length > 0;
    const paddingLeft = `${Math.max(0, section.level - 1) * 16}px`;

    return (
      <div key={section.id} className="border rounded-lg bg-white dark:bg-gray-900 shadow-sm" style={{ marginLeft: paddingLeft }}>
        <Collapsible open={isExpanded} onOpenChange={() => toggleSection(section.id)}>
          <CollapsibleTrigger asChild>
            <div className="flex items-center justify-between p-4 hover:bg-gray-50 dark:hover:bg-gray-800 cursor-pointer">
              <div className="flex items-center gap-3 flex-1">
                {getSectionIcon(section.section_type)}
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <h3 className="font-semibold text-lg text-gray-900 dark:text-gray-100">
                      {section.section_number && (
                        <span className="text-blue-600 dark:text-blue-400 mr-2">
                          {section.section_number}
                        </span>
                      )}
                      {section.section_title}
                    </h3>
                    <Badge className={`text-xs ${getSectionTypeColor(section.section_type)}`}>
                      {section.section_type}
                    </Badge>
                  </div>
                  
                  {/* Keywords and references preview */}
                  <div className="flex flex-wrap gap-1 mt-2">
                    {section.keywords.slice(0, 3).map((keyword, idx) => (
                      <Badge key={idx} variant="outline" className="text-xs">
                        <Tag className="w-3 h-3 mr-1" />
                        {keyword}
                      </Badge>
                    ))}
                    {section.regulatory_references.slice(0, 2).map((ref, idx) => (
                      <Badge key={idx} variant="outline" className="text-xs bg-blue-50 text-blue-700 border-blue-200">
                        <ExternalLink className="w-3 h-3 mr-1" />
                        {ref}
                      </Badge>
                    ))}
                  </div>
                </div>
              </div>
              
              <div className="flex items-center gap-2">
                {onSectionClick && (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={(e) => {
                      e.stopPropagation();
                      onSectionClick(section.id, section.section_title);
                    }}
                  >
                    View Details
                  </Button>
                )}
                <ChevronDown className={`w-5 h-5 transition-transform ${isExpanded ? 'rotate-180' : ''}`} />
              </div>
            </div>
          </CollapsibleTrigger>
          
          <CollapsibleContent>
            <div className="px-4 pb-4">
              <Separator className="mb-4" />
              
              {/* Section Content Preview */}
              <div className="mb-4">
                <p className="text-gray-700 dark:text-gray-300 text-sm line-clamp-3">
                  {section.section_content.substring(0, 300)}...
                </p>
              </div>
              
              {/* Enhanced metadata */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                {section.definitions.length > 0 && (
                  <div>
                    <h4 className="font-medium text-gray-900 dark:text-gray-100 mb-2">Definitions</h4>
                    <div className="space-y-1">
                      {section.definitions.slice(0, 3).map((def, idx) => (
                        <Badge key={idx} variant="outline" className="text-xs">
                          {def}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}
                
                {section.cross_references.length > 0 && (
                  <div>
                    <h4 className="font-medium text-gray-900 dark:text-gray-100 mb-2">Cross References</h4>
                    <div className="space-y-1">
                      {section.cross_references.slice(0, 3).map((ref, idx) => (
                        <Badge key={idx} variant="outline" className="text-xs">
                          {ref}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </CollapsibleContent>
        </Collapsible>
        
        {/* Render children sections */}
        {hasChildren && (
          <div className="ml-4 mt-2 space-y-2">
            {section.children!.map(child => renderSection(child))}
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="space-y-3">
      {filteredSections.map(section => renderSection(section))}
    </div>
  );
};

export const HierarchicalDocumentSections: React.FC<Props> = ({
  documentId,
  documentTitle,
  onSectionClick,
  showTableOfContents = true,
  showFilters = true,
  showSearch = true
}) => {
  const [sections, setSections] = useState<EnhancedSection[]>([]);
  const [tableOfContents, setTableOfContents] = useState<TableOfContentsItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState('all');
  const [view, setView] = useState<'sections' | 'toc'>('sections');

  // Build hierarchical structure from flat sections
  const buildHierarchy = (flatSections: any[]): EnhancedSection[] => {
    const sectionMap = new Map<number, EnhancedSection>();
    const roots: EnhancedSection[] = [];

    // First pass: create all sections
    flatSections.forEach(section => {
      const enhancedSection: EnhancedSection = {
        ...section,
        cross_references: JSON.parse(section.cross_references || '[]'),
        regulatory_references: JSON.parse(section.regulatory_references || '[]'),
        definitions: JSON.parse(section.definitions || '[]'),
        keywords: JSON.parse(section.keywords || '[]'),
        children: []
      };
      sectionMap.set(section.id, enhancedSection);
    });

    // Second pass: build hierarchy
    sectionMap.forEach(section => {
      if (section.parent_section_id && sectionMap.has(section.parent_section_id)) {
        const parent = sectionMap.get(section.parent_section_id)!;
        parent.children!.push(section);
      } else {
        roots.push(section);
      }
    });

    // Sort children by display_order
    const sortSections = (sections: EnhancedSection[]) => {
      sections.sort((a, b) => a.display_order - b.display_order);
      sections.forEach(section => {
        if (section.children && section.children.length > 0) {
          sortSections(section.children);
        }
      });
    };

    sortSections(roots);
    return roots;
  };

  const loadSections = async () => {
    try {
      setLoading(true);
      setError(null);
      
      const response = await brain.get_document_sections_admin({ documentId });
      
      if (response.ok) {
        const data: DocumentSectionsResponse = await response.json();
        const hierarchicalSections = buildHierarchy(data.sections);
        setSections(hierarchicalSections);
        
        // Also try to get table of contents from document if available
        try {
          const docResponse = await brain.get_document({ documentId });
          if (docResponse.ok) {
            const docData = await docResponse.json();
            if (docData.table_of_contents) {
              setTableOfContents(JSON.parse(docData.table_of_contents));
            }
          }
        } catch (tocError) {
          console.log('Could not load table of contents:', tocError);
        }
      } else {
        const errorData = await response.json().catch(() => ({ detail: 'Failed to load sections' }));
        setError(errorData.detail || 'Failed to load sections');
      }
    } catch (err) {
      console.error('Error loading sections:', err);
      setError('Failed to load document sections');
      toast.error('Failed to load document sections');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (documentId) {
      loadSections();
    }
  }, [documentId]);

  if (loading) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="animate-pulse space-y-4">
            <div className="h-4 bg-gray-200 rounded w-1/4"></div>
            <div className="h-4 bg-gray-200 rounded w-1/2"></div>
            <div className="h-4 bg-gray-200 rounded w-3/4"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (error) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="text-center">
            <p className="text-red-600 dark:text-red-400 mb-4">{error}</p>
            <Button onClick={loadSections} variant="outline">
              Try Again
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  const sectionTypes = Array.from(new Set(sections.flatMap(s => [s.section_type, ...(s.children?.map(c => c.section_type) || [])])));

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <FileText className="w-5 h-5" />
            Document Sections
            {documentTitle && (
              <span className="text-sm font-normal text-gray-600 dark:text-gray-400">
                - {documentTitle}
              </span>
            )}
          </CardTitle>
          
          {showTableOfContents && tableOfContents.length > 0 && (
            <div className="flex gap-2">
              <Button
                variant={view === 'sections' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setView('sections')}
              >
                <List className="w-4 h-4 mr-2" />
                Sections
              </Button>
              <Button
                variant={view === 'toc' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setView('toc')}
              >
                <Book className="w-4 h-4 mr-2" />
                Table of Contents
              </Button>
            </div>
          )}
        </div>
        
        {(showSearch || showFilters) && view === 'sections' && (
          <div className="flex flex-col sm:flex-row gap-4 mt-4">
            {showSearch && (
              <div className="flex-1">
                <Input
                  placeholder="Search sections, content, and keywords..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full"
                />
              </div>
            )}
            
            {showFilters && (
              <div className="w-48">
                <Select value={filterType} onValueChange={setFilterType}>
                  <SelectTrigger>
                    <SelectValue placeholder="Filter by type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Types</SelectItem>
                    {sectionTypes.map(type => (
                      <SelectItem key={type} value={type}>
                        {type.charAt(0).toUpperCase() + type.slice(1)}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}
          </div>
        )}
      </CardHeader>
      
      <CardContent>
        {sections.length === 0 ? (
          <div className="text-center py-8">
            <FileText className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-600 dark:text-gray-400">No sections found for this document.</p>
            <p className="text-sm text-gray-500 dark:text-gray-500 mt-2">
              Sections are automatically created when documents are uploaded with enhanced parsing enabled.
            </p>
          </div>
        ) : (
          <div>
            {view === 'toc' && tableOfContents.length > 0 ? (
              <TableOfContentsView toc={tableOfContents} onSectionClick={onSectionClick} />
            ) : (
              <SectionView 
                sections={sections} 
                onSectionClick={onSectionClick}
                searchTerm={searchTerm}
                filterType={filterType}
              />
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default HierarchicalDocumentSections;
