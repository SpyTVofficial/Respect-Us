import React, { useState, useEffect, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { Textarea } from '@/components/ui/textarea';
import { Plus, Edit, Trash2, GripVertical, Save, X, Globe, Tag, FileType, Download, Upload, ArrowUpDown, Check, StickyNote } from 'lucide-react';
import { toast } from 'sonner';
import brain from 'brain';
import type { MetadataOptionResponse, MetadataOptionRequest, MetadataOptionUpdate } from '../brain/data-contracts';
import OutcomesTab from './OutcomesTab';
import NotesTab from './NotesTab';
import {
  DndContext,
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  DragEndEvent,
} from '@dnd-kit/core';
import {
  arrayMove,
  SortableContext,
  sortableKeyboardCoordinates,
  verticalListSortingStrategy,
} from '@dnd-kit/sortable';
import {
  useSortable,
} from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';

interface DocumentMetadataManagementProps {
  onRefresh?: () => void;
}

type CategoryType = 'jurisdiction' | 'type' | 'subject' | 'outcome' | 'note';

// Sortable Item Component
interface SortableItemProps {
  option: MetadataOptionResponse;
  activeCategory: CategoryType;
  onEdit: (option: MetadataOptionResponse) => void;
  onDelete: (option: MetadataOptionResponse) => void;
  getCategoryLabel: (category: CategoryType) => string;
}

const SortableItem: React.FC<SortableItemProps> = ({ option, activeCategory, onEdit, onDelete, getCategoryLabel }) => {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
  } = useSortable({ id: option.id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
  };

  return (
    <div
      ref={setNodeRef}
      style={style}
      className="flex items-center justify-between p-3 bg-gray-700 rounded-lg hover:bg-gray-600 transition-colors"
    >
      <div className="flex items-center gap-3">
        <div
          {...attributes}
          {...listeners}
          className="cursor-grab active:cursor-grabbing"
        >
          <GripVertical className="h-4 w-4 text-gray-400" />
        </div>
        <div>
          <div className="flex items-center gap-2">
            <span className="font-medium text-white">{option.display_name}</span>
            {!option.is_active && (
              <Badge variant="secondary" className="text-xs">Inactive</Badge>
            )}
          </div>
          <div className="text-sm text-gray-400">
            Value: {option.value} • Order: {option.display_order}
          </div>
        </div>
      </div>
      <div className="flex items-center gap-2">
        <Button
          size="sm"
          variant="outline"
          onClick={() => onEdit(option)}
          className="h-8 w-8 p-0 bg-gray-600 hover:bg-gray-500 border-gray-500"
        >
          <Edit className="h-3 w-3" />
        </Button>
        <AlertDialog>
          <AlertDialogTrigger asChild>
            <Button
              size="sm"
              variant="outline"
              className="h-8 w-8 p-0 bg-red-700 hover:bg-red-600 border-red-600 text-red-300"
            >
              <Trash2 className="h-3 w-3" />
            </Button>
          </AlertDialogTrigger>
          <AlertDialogContent className="bg-gray-800 border-gray-700">
            <AlertDialogHeader>
              <AlertDialogTitle>Delete {getCategoryLabel(activeCategory)}</AlertDialogTitle>
              <AlertDialogDescription>
                Are you sure you want to delete "{option.display_name}"? This action cannot be undone and may affect existing documents.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel className="bg-gray-700 hover:bg-gray-600 border-gray-600">
                Cancel
              </AlertDialogCancel>
              <AlertDialogAction
                onClick={() => onDelete(option)}
                className="bg-red-600 hover:bg-red-700"
              >
                Delete
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </div>
  );
};

const DocumentMetadataManagement: React.FC<DocumentMetadataManagementProps> = ({ onRefresh }) => {
  const [activeCategory, setActiveCategory] = useState<CategoryType>('jurisdiction');
  const [jurisdictions, setJurisdictions] = useState<MetadataOptionResponse[]>([]);
  const [types, setTypes] = useState<MetadataOptionResponse[]>([]);
  const [subjects, setSubjects] = useState<MetadataOptionResponse[]>([]);
  const [loading, setLoading] = useState(true);
  
  // Dialog states
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [selectedOption, setSelectedOption] = useState<MetadataOptionResponse | null>(null);
  
  // Bulk import states
  const [showBulkImportDialog, setShowBulkImportDialog] = useState(false);
  const [showImportPreview, setShowImportPreview] = useState(false);
  const [bulkImportData, setBulkImportData] = useState('');
  const [importPreview, setImportPreview] = useState<MetadataOptionRequest[]>([]);
  const [importPreviewCount, setImportPreviewCount] = useState(0);
  
  // Form data
  const [formData, setFormData] = useState({
    value: '',
    display_name: '',
    display_order: 0,
    is_active: true
  });

  // Drag and drop sensors
  const sensors = useSensors(
    useSensor(PointerSensor),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    })
  );

  // Handle drag end for reordering
  const handleDragEnd = async (event: DragEndEvent) => {
    const { active, over } = event;

    if (over && active.id !== over.id) {
      const currentOptions = getCurrentOptions();
      const oldIndex = currentOptions.findIndex(item => item.id === active.id);
      const newIndex = currentOptions.findIndex(item => item.id === over.id);
      
      if (oldIndex !== -1 && newIndex !== -1) {
        const reorderedOptions = arrayMove(currentOptions, oldIndex, newIndex);
        
        // Update local state immediately for smooth UX
        const updatedOptions = reorderedOptions.map((option, index) => ({
          ...option,
          display_order: index + 1
        }));

        // Update the appropriate state
        switch (activeCategory) {
          case 'jurisdiction':
            setJurisdictions(updatedOptions);
            break;
          case 'type':
            setTypes(updatedOptions);
            break;
          case 'subject':
            setSubjects(updatedOptions);
            break;
        }

        // Send reorder request to backend
        try {
          const reorderData = {
            category: activeCategory,
            option_orders: updatedOptions.map((option, index) => ({
              id: option.id,
              display_order: index + 1
            }))
          };
          
          const response = await brain.reorder_metadata_options(reorderData);
          if (response.ok) {
            toast.success(`${getCategoryLabel(activeCategory)} options reordered successfully`);
            onRefresh?.();
          } else {
            toast.error(`Failed to reorder ${getCategoryLabel(activeCategory).toLowerCase()} options`);
            // Revert the change if API call failed
            await loadMetadataOptions(activeCategory);
          }
        } catch (error) {
          console.error('Error reordering options:', error);
          toast.error(`Failed to reorder ${getCategoryLabel(activeCategory).toLowerCase()} options`);
          // Revert the change if API call failed
          await loadMetadataOptions(activeCategory);
        }
      }
    }
  };

  // Load metadata options for a category
  const loadMetadataOptions = async (category: CategoryType) => {
    try {
      console.log(`🔄 Loading metadata for category: ${category}`);
      
      // Use the admin_dashboard API that accepts category parameter
      const response = await brain.get_metadata_options({ category });
      
      console.log(`📜 API Response status: ${response.status}, ok: ${response.ok}`);
      
      if (response.ok) {
        const data = await response.json();
        console.log(`📊 Raw API response data:`, data);
        
        // The admin_dashboard API returns an array of MetadataOptionResponse
        const options = Array.isArray(data) ? data : [];
        console.log(`📊 Parsed options (${options.length}):`, options);
        
        // Use React's functional state update to ensure fresh state
        switch (category) {
          case 'jurisdiction':
            setJurisdictions(prev => {
              console.log(`🔄 Updating jurisdictions from ${prev.length} to ${options.length}`);
              return options;
            });
            break;
          case 'type':
            setTypes(prev => {
              console.log(`🔄 Updating types from ${prev.length} to ${options.length}`);
              return options;
            });
            break;
          case 'subject':
            setSubjects(prev => {
              console.log(`🔄 Updating subjects from ${prev.length} to ${options.length}`);
              return options;
            });
            break;
        }
      } else {
        console.error(`❌ Failed to load ${category} options: HTTP ${response.status}`);
        const errorText = await response.text();
        console.error(`❌ Error response:`, errorText);
      }
    } catch (error) {
      console.error(`❌ Error loading ${category} options:`, error);
    }
  };

  // Load all metadata options
  const loadAllMetadata = async () => {
    setLoading(true);
    try {
      await Promise.all([
        loadMetadataOptions('jurisdiction'),
        loadMetadataOptions('type'),
        loadMetadataOptions('subject')
      ]);
    } finally {
      setLoading(false);
    }
  };

  // Create new option
  const handleCreate = async () => {
    try {
      const request: MetadataOptionRequest = {
        category: activeCategory,
        value: formData.value,
        display_name: formData.display_name,
        display_order: formData.display_order,
        is_active: formData.is_active
      };
      
      const response = await brain.create_metadata_option(request);
      if (response.ok) {
        toast.success(`${getCategoryLabel(activeCategory)} created successfully`);
        setShowCreateDialog(false);
        resetForm();
        await loadMetadataOptions(activeCategory);
        onRefresh?.();
      } else {
        toast.error(`Failed to create ${getCategoryLabel(activeCategory).toLowerCase()}`);
      }
    } catch (error) {
      console.error('Error creating option:', error);
      toast.error(`Failed to create ${getCategoryLabel(activeCategory).toLowerCase()}`);
    }
  };

  // Update option
  const handleUpdate = async () => {
    if (!selectedOption) return;
    
    try {
      const request: MetadataOptionUpdate = {
        value: formData.value,
        display_name: formData.display_name,
        display_order: formData.display_order,
        is_active: formData.is_active
      };
      
      const response = await brain.update_metadata_option(
        { optionId: selectedOption.id },
        request
      );
      
      if (response.ok) {
        toast.success(`${getCategoryLabel(activeCategory)} updated successfully`);
        setShowEditDialog(false);
        setSelectedOption(null);
        resetForm();
        await loadMetadataOptions(activeCategory);
        onRefresh?.();
      } else {
        toast.error(`Failed to update ${getCategoryLabel(activeCategory).toLowerCase()}`);
      }
    } catch (error) {
      console.error('Error updating option:', error);
      toast.error(`Failed to update ${getCategoryLabel(activeCategory).toLowerCase()}`);
    }
  };

  // Delete option
  const handleDelete = async (option: MetadataOptionResponse) => {
    try {
      const response = await brain.delete_metadata_option({ optionId: option.id });
      if (response.ok) {
        toast.success(`${getCategoryLabel(activeCategory)} deleted successfully`);
        await loadMetadataOptions(activeCategory);
        onRefresh?.();
      } else {
        toast.error(`Failed to delete ${getCategoryLabel(activeCategory).toLowerCase()}`);
      }
    } catch (error) {
      console.error('Error deleting option:', error);
      toast.error(`Failed to delete ${getCategoryLabel(activeCategory).toLowerCase()}`);
    }
  };

  // Open edit dialog
  const openEditDialog = (option: MetadataOptionResponse) => {
    setSelectedOption(option);
    setFormData({
      value: option.value,
      display_name: option.display_name,
      display_order: option.display_order,
      is_active: option.is_active
    });
    setShowEditDialog(true);
  };

  // Reset form
  const resetForm = () => {
    setFormData({
      value: '',
      display_name: '',
      display_order: 0,
      is_active: true
    });
  };

  // Get category label
  const getCategoryLabel = (category: CategoryType) => {
    switch (category) {
      case 'jurisdiction': return 'Jurisdiction';
      case 'type': return 'Regulation Type';
      case 'subject': return 'Subject';
      case 'outcome': return 'Outcome';
      case 'note': return 'Note';
    }
  };

  // Get category icon
  const getCategoryIcon = (category: CategoryType) => {
    switch (category) {
      case 'jurisdiction': return <Globe className="h-4 w-4" />;
      case 'type': return <FileType className="h-4 w-4" />;
      case 'subject': return <Tag className="h-4 w-4" />;
      case 'outcome': return <Check className="h-4 w-4" />;
      case 'note': return <StickyNote className="h-4 w-4" />;
    }
  };

  // Get current options
  const getCurrentOptions = () => {
    switch (activeCategory) {
      case 'jurisdiction': return jurisdictions;
      case 'type': return types;
      case 'subject': return subjects;
    }
  };

  // Bulk export functionality
  const handleExport = () => {
    const currentOptions = getCurrentOptions();
    const exportData = currentOptions.map(option => ({
      value: option.value,
      display_name: option.display_name,
      display_order: option.display_order,
      is_active: option.is_active
    }));
    
    const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${activeCategory}_metadata.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    toast.success(`${getCategoryLabel(activeCategory)} data exported successfully`);
  };

  // Parse bulk import data
  const parseBulkImportData = (data: string): MetadataOptionRequest[] => {
    try {
      const parsed = JSON.parse(data);
      if (!Array.isArray(parsed)) {
        throw new Error('Data must be an array');
      }
      
      return parsed.map((item, index) => ({
        category: activeCategory,
        value: item.value || `value_${index + 1}`,
        display_name: item.display_name || item.value || `Item ${index + 1}`,
        display_order: item.display_order || index + 1,
        is_active: item.is_active !== undefined ? item.is_active : true
      }));
    } catch (error) {
      throw new Error('Invalid JSON format');
    }
  };

  // Handle bulk import preview
  const handleImportPreview = () => {
    try {
      const preview = parseBulkImportData(bulkImportData);
      setImportPreview(preview);
      setImportPreviewCount(preview.length);
      setShowImportPreview(true);
      toast.success(`Preview generated: ${preview.length} items`);
    } catch (error) {
      setImportPreview([]);
      setImportPreviewCount(0);
      setShowImportPreview(false);
      toast.error(error instanceof Error ? error.message : 'Failed to parse import data');
    }
  };

  // Handle bulk import confirmation
  const handleBulkImport = async () => {
    try {
      console.log('🚀 Starting bulk import for category:', activeCategory);
      console.log('📊 Current state before import:', {
        jurisdiction_count: jurisdictions.length,
        types_count: types.length,
        subjects_count: subjects.length
      });
      
      // Convert to simple dictionaries as expected by the backend
      const options = importPreview.map(item => ({
        value: item.value,
        display_name: item.display_name,
        display_order: item.display_order,
        is_active: item.is_active
      }));

      const response = await brain.bulk_import_metadata_options(
        { category: activeCategory },
        {
          category: activeCategory,
          options: options,
          replace_existing: false
        }
      );

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.detail || 'Failed to bulk import metadata options');
      }

      const result = await response.json();
      console.log('✅ Bulk import result:', result);
      toast.success(result.message || `Successfully imported ${options.length} ${getCategoryLabel(activeCategory).toLowerCase()}(s)`);
      
      // Close dialogs and reset state
      setShowBulkImportDialog(false);
      setShowImportPreview(false);
      setBulkImportData('');
      setImportPreview([]);
      setImportPreviewCount(0);
      
      // Refresh the data to show new items
      console.log('🔄 Refreshing data for category:', activeCategory);
      await loadMetadataOptions(activeCategory);
      
      // Force a UI update by toggling loading state
      setLoading(true);
      setTimeout(() => setLoading(false), 100);
      
      console.log('📊 State after refresh:', {
        jurisdiction_count: jurisdictions.length,
        types_count: types.length,
        subjects_count: subjects.length
      });
      
      onRefresh?.();
      
    } catch (error) {
      console.error('❌ Error during bulk import:', error);
      toast.error(error instanceof Error ? error.message : 'Failed to import data');
    }
  };

  // Computed values to ensure fresh state
  const importCount = importPreviewCount;
  const isImportDisabled = importCount === 0;
  const importButtonText = `Import ${getCategoryLabel(activeCategory)} (${importCount} items)`;

  useEffect(() => {
    loadAllMetadata();
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center py-8">
        <div className="text-gray-400">Loading metadata options...</div>
      </div>
    );
  }

  const currentOptions = getCurrentOptions();

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-amber-400 mb-2">Document Metadata Management</h2>
          <p className="text-gray-400">Manage jurisdictions, regulation types, and subjects for document classification</p>
        </div>
        <Button
          onClick={() => {
            resetForm();
            setShowCreateDialog(true);
          }}
          className="bg-amber-600 hover:bg-amber-700 text-white"
        >
          <Plus className="h-4 w-4 mr-2" />
          Add {getCategoryLabel(activeCategory)}
        </Button>
      </div>

      {/* Category Tabs */}
      <Tabs value={activeCategory} onValueChange={(value) => setActiveCategory(value as CategoryType)}>
        <TabsList className="bg-gray-800 border-gray-700">
          <TabsTrigger value="jurisdiction" className="data-[state=active]:bg-amber-600">
            <Globe className="h-4 w-4 mr-2" />
            Jurisdictions ({jurisdictions.length})
          </TabsTrigger>
          <TabsTrigger value="type" className="data-[state=active]:bg-amber-600">
            <FileType className="h-4 w-4 mr-2" />
            Types ({types.length})
          </TabsTrigger>
          <TabsTrigger value="subject" className="data-[state=active]:bg-amber-600">
            <Tag className="h-4 w-4 mr-2" />
            Subjects ({subjects.length})
          </TabsTrigger>
          <TabsTrigger value="outcome" className="data-[state=active]:bg-amber-600">
            <Check className="h-4 w-4 mr-2" />
            Outcomes
          </TabsTrigger>
          <TabsTrigger value="note" className="data-[state=active]:bg-amber-600">
            <StickyNote className="h-4 w-4 mr-2" />
            Notes
          </TabsTrigger>
        </TabsList>

        {/* Standard Metadata Options Tabs */}
        {(activeCategory === 'jurisdiction' || activeCategory === 'type' || activeCategory === 'subject') && (
          <TabsContent value={activeCategory} className="space-y-4">
            <Card className="bg-gray-800 border-gray-700">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="flex items-center gap-2 text-amber-400">
                      {getCategoryIcon(activeCategory)}
                      {getCategoryLabel(activeCategory)} Management
                    </CardTitle>
                    <CardDescription>Manage {getCategoryLabel(activeCategory).toLowerCase()} options with drag-and-drop reordering</CardDescription>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => setShowBulkImportDialog(true)}
                      className="bg-gray-700 hover:bg-gray-600 border-gray-600"
                    >
                      <Upload className="h-4 w-4 mr-2" />
                      Bulk Import
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={handleExport}
                      disabled={currentOptions.length === 0}
                      className="bg-gray-700 hover:bg-gray-600 border-gray-600"
                    >
                      <Download className="h-4 w-4 mr-2" />
                      Export
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                {currentOptions.length === 0 ? (
                  <div className="text-center py-8 text-gray-400">
                    <div className="mb-4">{getCategoryIcon(activeCategory)}</div>
                    <p>No {getCategoryLabel(activeCategory).toLowerCase()} options found</p>
                    <p className="text-sm">Add your first {getCategoryLabel(activeCategory).toLowerCase()} to get started</p>
                  </div>
                ) : (
                  <div className="space-y-2">
                    <DndContext
                      collisionDetection={closestCenter}
                      onDragEnd={handleDragEnd}
                      sensors={sensors}
                    >
                      <SortableContext
                        items={currentOptions}
                        strategy={verticalListSortingStrategy}
                      >
                        {currentOptions
                          .sort((a, b) => a.display_order - b.display_order)
                          .map((option) => (
                            <SortableItem
                              key={option.id}
                              option={option}
                              activeCategory={activeCategory}
                              onEdit={openEditDialog}
                              onDelete={handleDelete}
                              getCategoryLabel={getCategoryLabel}
                            />
                          ))}
                      </SortableContext>
                    </DndContext>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        )}

        {/* Outcomes Tab */}
        <TabsContent value="outcome" className="space-y-4">
          <OutcomesTab />
        </TabsContent>

        {/* Notes Tab */}
        <TabsContent value="note" className="space-y-4">
          <NotesTab />
        </TabsContent>
      </Tabs>

      {/* Create Dialog */}
      <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
        <DialogContent className="bg-gray-800 border-gray-700">
          <DialogHeader>
            <DialogTitle>Add New {getCategoryLabel(activeCategory)}</DialogTitle>
            <DialogDescription>
              Create a new {getCategoryLabel(activeCategory).toLowerCase()} option for document classification
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="value">Value</Label>
              <Input
                id="value"
                value={formData.value}
                onChange={(e) => setFormData(prev => ({ ...prev, value: e.target.value }))}
                placeholder="Internal value (e.g., 'US', 'regulation', 'dual-use')"
                className="bg-gray-700 border-gray-600"
              />
            </div>
            <div>
              <Label htmlFor="display_name">Display Name</Label>
              <Input
                id="display_name"
                value={formData.display_name}
                onChange={(e) => setFormData(prev => ({ ...prev, display_name: e.target.value }))}
                placeholder="Display name (e.g., 'United States', 'Regulation', 'Dual-use Items')"
                className="bg-gray-700 border-gray-600"
              />
            </div>
            <div>
              <Label htmlFor="display_order">Display Order</Label>
              <Input
                id="display_order"
                type="number"
                value={formData.display_order}
                onChange={(e) => setFormData(prev => ({ ...prev, display_order: parseInt(e.target.value) || 0 }))}
                placeholder="0"
                className="bg-gray-700 border-gray-600"
              />
            </div>
            <div className="flex items-center space-x-2">
              <Switch
                id="is_active"
                checked={formData.is_active}
                onCheckedChange={(checked) => setFormData(prev => ({ ...prev, is_active: checked }))}
              />
              <Label htmlFor="is_active">Active</Label>
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setShowCreateDialog(false)}
              className="bg-gray-700 hover:bg-gray-600 border-gray-600"
            >
              <X className="h-4 w-4 mr-2" />
              Cancel
            </Button>
            <Button
              onClick={handleCreate}
              disabled={!formData.value || !formData.display_name}
              className="bg-amber-600 hover:bg-amber-700"
            >
              <Save className="h-4 w-4 mr-2" />
              Create {getCategoryLabel(activeCategory)}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Dialog */}
      <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
        <DialogContent className="bg-gray-800 border-gray-700">
          <DialogHeader>
            <DialogTitle>Edit {getCategoryLabel(activeCategory)}</DialogTitle>
            <DialogDescription>
              Update the {getCategoryLabel(activeCategory).toLowerCase()} option details
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="edit_value">Value</Label>
              <Input
                id="edit_value"
                value={formData.value}
                onChange={(e) => setFormData(prev => ({ ...prev, value: e.target.value }))}
                placeholder="Internal value"
                className="bg-gray-700 border-gray-600"
              />
            </div>
            <div>
              <Label htmlFor="edit_display_name">Display Name</Label>
              <Input
                id="edit_display_name"
                value={formData.display_name}
                onChange={(e) => setFormData(prev => ({ ...prev, display_name: e.target.value }))}
                placeholder="Display name"
                className="bg-gray-700 border-gray-600"
              />
            </div>
            <div>
              <Label htmlFor="edit_display_order">Display Order</Label>
              <Input
                id="edit_display_order"
                type="number"
                value={formData.display_order}
                onChange={(e) => setFormData(prev => ({ ...prev, display_order: parseInt(e.target.value) || 0 }))}
                className="bg-gray-700 border-gray-600"
              />
            </div>
            <div className="flex items-center space-x-2">
              <Switch
                id="edit_is_active"
                checked={formData.is_active}
                onCheckedChange={(checked) => setFormData(prev => ({ ...prev, is_active: checked }))}
              />
              <Label htmlFor="edit_is_active">Active</Label>
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                setShowEditDialog(false);
                setSelectedOption(null);
                resetForm();
              }}
              className="bg-gray-700 hover:bg-gray-600 border-gray-600"
            >
              <X className="h-4 w-4 mr-2" />
              Cancel
            </Button>
            <Button
              onClick={handleUpdate}
              disabled={!formData.value || !formData.display_name}
              className="bg-amber-600 hover:bg-amber-700"
            >
              <Save className="h-4 w-4 mr-2" />
              Update {getCategoryLabel(activeCategory)}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Bulk Import Dialog */}
      <Dialog open={showBulkImportDialog} onOpenChange={setShowBulkImportDialog}>
        <DialogContent className="bg-gray-800 border-gray-700">
          <DialogHeader>
            <DialogTitle>Bulk Import {getCategoryLabel(activeCategory)}</DialogTitle>
            <DialogDescription>
              Import multiple {getCategoryLabel(activeCategory).toLowerCase()} options at once. Paste a JSON array of objects with value, display_name, display_order, and is_active properties.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="bulk_import">Bulk Import Data (JSON Array)</Label>
              <Textarea
                value={bulkImportData}
                onChange={(e) => setBulkImportData(e.target.value)}
                placeholder={`Example:\n[\n  {\n    "value": "option1",\n    "display_name": "Option 1",\n    "display_order": 1,\n    "is_active": true\n  },\n  {\n    "value": "option2",\n    "display_name": "Option 2",\n    "display_order": 2,\n    "is_active": true\n  }\n]`}
                className="min-h-[300px] font-mono text-sm"
              />
            </div>
            <div className="flex justify-center">
              <Button
                onClick={handleImportPreview}
                disabled={!bulkImportData.trim()}
                className="bg-amber-600 hover:bg-amber-700"
              >
                <Upload className="h-4 w-4 mr-2" />
                Generate Preview
              </Button>
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                setShowBulkImportDialog(false);
                setBulkImportData('');
                setImportPreview([]);
                setImportPreviewCount(0);
                setShowImportPreview(false);
              }}
              className="bg-gray-700 hover:bg-gray-600 border-gray-600"
            >
              <X className="h-4 w-4 mr-2" />
              Cancel
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Bulk Import Preview */}
      <Dialog open={showImportPreview} onOpenChange={setShowImportPreview}>
        <DialogContent className="bg-gray-800 border-gray-700 max-w-4xl">
          <DialogHeader>
            <DialogTitle>Import Preview - {getCategoryLabel(activeCategory)}</DialogTitle>
            <DialogDescription>
              Review {importPreviewCount} items before importing. Check that all data looks correct.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 max-h-[60vh] overflow-y-auto">
            <div className="bg-gray-700 rounded-lg p-4">
              <h4 className="text-sm font-medium text-gray-300 mb-3">Items to be imported:</h4>
              <div className="space-y-2">
                {importPreview.map((item, index) => (
                  <div key={index} className="bg-gray-600 rounded p-3 text-sm">
                    <div className="grid grid-cols-4 gap-2">
                      <div>
                        <span className="text-gray-400">Value:</span>
                        <div className="font-mono">{item.value}</div>
                      </div>
                      <div>
                        <span className="text-gray-400">Display Name:</span>
                        <div>{item.display_name}</div>
                      </div>
                      <div>
                        <span className="text-gray-400">Order:</span>
                        <div>{item.display_order}</div>
                      </div>
                      <div>
                        <span className="text-gray-400">Active:</span>
                        <div className={item.is_active ? "text-green-400" : "text-red-400"}>
                          {item.is_active ? "Yes" : "No"}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                setShowImportPreview(false);
              }}
              className="bg-gray-700 hover:bg-gray-600 border-gray-600"
            >
              <X className="h-4 w-4 mr-2" />
              Back to Edit
            </Button>
            <Button
              onClick={handleBulkImport}
              disabled={importPreviewCount === 0}
              className="bg-green-600 hover:bg-green-700 disabled:bg-gray-500 disabled:hover:bg-gray-500"
            >
              <Save className="h-4 w-4 mr-2" />
              Confirm Import ({importPreviewCount} items)
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default DocumentMetadataManagement;
