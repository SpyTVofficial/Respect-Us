import React, { useState, useRef, useEffect } from 'react';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Check, ChevronsUpDown, X } from 'lucide-react';

interface ComboboxMultiSelectProps {
  options: { value: string; display_name: string }[];
  value: string[];
  onChange: (values: string[]) => void;
  placeholder: string;
  label: string;
  searchPlaceholder?: string;
  emptyMessage?: string;
  allowMultiple?: boolean;
}

const ComboboxMultiSelect: React.FC<ComboboxMultiSelectProps> = ({ 
  options, 
  value, 
  onChange, 
  placeholder, 
  label, 
  searchPlaceholder = "Search...",
  emptyMessage = "No options found.",
  allowMultiple = true
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [searchValue, setSearchValue] = useState("");
  const containerRef = useRef<HTMLDivElement>(null);

  // Ensure we have valid arrays
  const validOptions = Array.isArray(options) ? options.filter(opt => opt?.value && opt?.display_name) : [];
  const currentValue = Array.isArray(value) ? value : [];

  // Filter options based on search
  const filteredOptions = validOptions.filter(option =>
    option.display_name.toLowerCase().includes(searchValue.toLowerCase())
  );

  const handleOptionClick = (optionValue: string) => {
    console.log('=== OPTION CLICK DEBUG ===');
    console.log('Clicked option:', optionValue);
    console.log('allowMultiple:', allowMultiple);
    console.log('currentValue before:', currentValue);
    console.log('currentValue type:', typeof currentValue, Array.isArray(currentValue));
    
    if (!allowMultiple) {
      // Single select: replace current selection
      const newValue = currentValue.includes(optionValue) ? [] : [optionValue];
      console.log('Single select - newValue:', newValue);
      onChange(newValue);
      setIsOpen(false);
      return;
    }

    // Multi-select: toggle the option
    const newValue = currentValue.includes(optionValue)
      ? currentValue.filter(v => v !== optionValue)  // Remove if already selected
      : [...currentValue, optionValue];              // Add if not selected
    
    console.log('Multi-select - newValue:', newValue);
    console.log('=== END DEBUG ===');
    onChange(newValue);
    // Keep dropdown open for multi-select
  };

  const handleRemoveTag = (optionValue: string, event?: React.MouseEvent) => {
    if (event) {
      event.preventDefault();
      event.stopPropagation();
    }
    const newValue = currentValue.filter(v => v !== optionValue);
    onChange(newValue);
  };

  const getDisplayName = (val: string) => {
    const option = validOptions.find(opt => opt.value === val);
    return option?.display_name || val;
  };

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const toggleDropdown = (event: React.MouseEvent) => {
    event.preventDefault();
    event.stopPropagation();
    setIsOpen(!isOpen);
  };

  return (
    <div className="space-y-2 relative" ref={containerRef}>
      <Label className="text-gray-300">{label}</Label>
      
      {/* Main trigger button */}
      <button
        type="button"
        onClick={toggleDropdown}
        className="w-full flex items-center justify-between px-3 py-2 bg-gray-700 border border-gray-600 rounded-md text-white hover:bg-gray-600 focus:outline-none focus:ring-2 focus:ring-blue-500"
      >
        <span className="truncate">
          {currentValue.length === 0 ? (
            <span className="text-gray-400">{placeholder}</span>
          ) : currentValue.length === 1 ? (
            getDisplayName(currentValue[0])
          ) : (
            `${currentValue.length} selected`
          )}
        </span>
        <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
      </button>
      
      {/* Dropdown */}
      {isOpen && (
        <div className="absolute z-50 w-full mt-1 bg-gray-700 border border-gray-600 rounded-md shadow-lg">
          {/* Search input */}
          <div className="p-3 border-b border-gray-600">
            <input
              type="text"
              placeholder={searchPlaceholder}
              value={searchValue}
              onChange={(e) => setSearchValue(e.target.value)}
              className="w-full px-3 py-2 bg-gray-800 border border-gray-600 rounded text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
              onClick={(e) => e.stopPropagation()}
            />
          </div>
          
          {/* Options list */}
          <div className="max-h-64 overflow-auto p-1">
            {filteredOptions.length === 0 ? (
              <div className="text-gray-400 py-6 text-center">{emptyMessage}</div>
            ) : (
              filteredOptions.map((option) => {
                const isSelected = currentValue.includes(option.value);
                return (
                  <div
                    key={option.value}
                    onClick={(e) => {
                      e.stopPropagation();
                      handleOptionClick(option.value);
                    }}
                    className="flex items-center space-x-2 p-2 hover:bg-gray-600 cursor-pointer text-white rounded-sm"
                  >
                    <div className="w-4 h-4 flex items-center justify-center">
                      {isSelected && <Check className="h-4 w-4" />}
                    </div>
                    <span>{option.display_name}</span>
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}
      
      {/* Selected items as badges */}
      {currentValue.length > 0 && (
        <div className="flex flex-wrap gap-2 mt-2">
          {currentValue.map((val) => (
            <Badge
              key={val}
              variant="secondary"
              className="bg-gray-600 text-white hover:bg-gray-500 pr-1"
            >
              {getDisplayName(val)}
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  handleRemoveTag(val, e);
                }}
                className="ml-1 h-4 w-4 p-0 hover:bg-gray-500 rounded flex items-center justify-center"
              >
                <X className="h-3 w-3" />
              </button>
            </Badge>
          ))}
        </div>
      )}
    </div>
  );
};

export default ComboboxMultiSelect;
