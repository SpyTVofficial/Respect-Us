import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Plus, TreePine } from 'lucide-react';
import brain from 'brain';
import { toast } from 'sonner';
import type { SanctionsTree, SanctionsNode } from 'types';

interface SanctionsTreeCardsProps {
  onTreeSelect: (treeId: string) => void;
  selectedTreeId: string | null;
  onAddNodeClick: () => void;
  onAddTreeClick: () => void;
}

const SanctionsTreeCards: React.FC<SanctionsTreeCardsProps> = ({
  onTreeSelect,
  selectedTreeId,
  onAddNodeClick,
  onAddTreeClick
}) => {
  const [trees, setTrees] = useState<SanctionsTree[]>([]);
  const [loading, setLoading] = useState(true);

  // Load trees on component mount
  useEffect(() => {
    loadTrees();
  }, []);

  const loadTrees = async () => {
    try {
      setLoading(true);
      const response = await brain.list_sanctions_trees();
      const treesData = await response.json();
      setTrees(treesData);
      
      // Auto-select first tree if none selected
      if (treesData.length > 0 && !selectedTreeId) {
        onTreeSelect(treesData[0].id);
      }
    } catch (error) {
      console.error('Error loading trees:', error);
      toast.error('Failed to load decision trees');
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="text-center py-8 text-gray-400">
        Loading decision trees...
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header with Add Tree button */}
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold text-amber-400 flex items-center gap-2">
            <TreePine className="h-5 w-5" />
            Decision Trees
          </h3>
          <p className="text-gray-400 text-sm mt-1">
            Select a decision tree to manage its nodes and structure
          </p>
        </div>
        <div className="flex gap-2">
          <Button
            onClick={onAddTreeClick}
            className="bg-green-600 hover:bg-green-700 text-white"
          >
            <Plus className="h-4 w-4 mr-2" />
            Add Tree
          </Button>
          {selectedTreeId && (
            <Button
              onClick={onAddNodeClick}
              className="bg-amber-600 hover:bg-amber-700 text-white"
            >
              <Plus className="h-4 w-4 mr-2" />
              Add Node
            </Button>
          )}
        </div>
      </div>

      {/* Trees Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {trees.map((tree) => {
          const isSelected = tree.id === selectedTreeId;
          return (
            <Card
              key={tree.id}
              className={`cursor-pointer transition-all duration-200 bg-gray-800/30 border-gray-700 hover:bg-gray-800/50 ${
                isSelected
                  ? 'ring-2 ring-amber-500/50 border-amber-500/50 bg-gray-800/60'
                  : ''
              }`}
              onClick={() => onTreeSelect(tree.id)}
            >
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <CardTitle className="text-white text-base font-medium">
                    {tree.name}
                  </CardTitle>
                  {isSelected && (
                    <Badge className="bg-amber-500/20 text-amber-400 border-amber-500/30 text-xs">
                      Selected
                    </Badge>
                  )}
                </div>
                {tree.description && (
                  <p className="text-gray-400 text-sm mt-1">
                    {tree.description}
                  </p>
                )}
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-400">Jurisdiction:</span>
                    <Badge variant="outline" className="text-gray-300 border-gray-600">
                      {tree.jurisdiction || 'Not set'}
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-400">Category:</span>
                    <Badge variant="outline" className="text-gray-300 border-gray-600">
                      {tree.category || 'General'}
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-400">Status:</span>
                    <Badge 
                      className={`${
                        tree.status === 'published'
                          ? 'bg-green-500/20 text-green-400 border-green-500/30'
                          : 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30'
                      }`}
                    >
                      {tree.status || 'Draft'}
                    </Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* No trees message */}
      {trees.length === 0 && (
        <Card className="bg-gray-800/30 border-gray-700">
          <CardContent className="pt-6 text-center">
            <TreePine className="h-12 w-12 text-gray-600 mx-auto mb-4" />
            <p className="text-gray-400">No decision trees found</p>
            <p className="text-gray-500 text-sm mt-1">
              Create your first decision tree to get started
            </p>
            <Button
              onClick={onAddTreeClick}
              className="mt-4 bg-green-600 hover:bg-green-700 text-white"
            >
              <Plus className="h-4 w-4 mr-2" />
              Create First Tree
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default SanctionsTreeCards;
