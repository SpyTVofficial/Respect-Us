import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { ScrollArea } from '@/components/ui/scroll-area';
import { toast } from 'sonner';
import {
  CheckCircle,
  XCircle,
  Clock,
  Eye,
  FileText,
  MessageSquare,
  User,
  Calendar,
  Search,
  Filter,
  RefreshCw,
  Edit,
  Trash2,
  AlertTriangle,
  BookOpen,
  Globe,
  Star
} from 'lucide-react';
import brain from 'brain';
import { DocumentResponse } from 'types';

interface UserContribution {
  id: number;
  title: string;
  description?: string;
  content?: string;
  contribution_type: 'blog' | 'document' | 'article';
  status: 'pending' | 'approved' | 'rejected';
  submitted_by: string;
  submitted_by_name?: string;
  submitted_at: string;
  reviewed_by?: string;
  reviewed_at?: string;
  review_comments?: string;
  category?: string;
  tags?: string[];
  country_jurisdiction?: string[];
  author?: string;
  reading_time?: number;
  featured_status?: boolean;
}

interface Props {
  onRefresh?: () => void;
}

export function UserContributionsValidationTab({ onRefresh }: Props) {
  const [activeTab, setActiveTab] = useState('pending');
  const [contributions, setContributions] = useState<UserContribution[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [typeFilter, setTypeFilter] = useState('all');
  const [selectedContribution, setSelectedContribution] = useState<UserContribution | null>(null);
  const [showReviewDialog, setShowReviewDialog] = useState(false);
  const [reviewAction, setReviewAction] = useState<'approve' | 'reject'>('approve');
  const [reviewComments, setReviewComments] = useState('');
  const [processing, setProcessing] = useState(false);
  const [stats, setStats] = useState({
    pending: 0,
    approved: 0,
    rejected: 0,
    total: 0
  });

  useEffect(() => {
    loadContributions();
  }, [activeTab, searchQuery, typeFilter]);

  const loadContributions = async () => {
    try {
      setLoading(true);
      
      // For now, we'll simulate data until the backend API is created
      // In reality, this would call something like brain.list_user_contributions()
      const mockContributions: UserContribution[] = [
        {
          id: 1,
          title: "New ITAR Guidelines Update for 2024",
          description: "Comprehensive analysis of recent ITAR regulatory changes",
          content: "The International Traffic in Arms Regulations (ITAR) have undergone significant updates...",
          contribution_type: 'blog',
          status: 'pending',
          submitted_by: 'user123',
          submitted_by_name: 'John Smith',
          submitted_at: '2024-08-23T10:30:00Z',
          category: 'regulatory-updates',
          tags: ['ITAR', 'Regulations', '2024'],
          author: 'John Smith',
          reading_time: 8
        },
        {
          id: 2,
          title: "EAR Classification Best Practices",
          description: "Document outlining best practices for EAR classifications",
          contribution_type: 'document',
          status: 'pending',
          submitted_by: 'user456',
          submitted_by_name: 'Sarah Johnson',
          submitted_at: '2024-08-22T15:45:00Z',
          category: 'best-practices',
          tags: ['EAR', 'Classification', 'Best Practices'],
          country_jurisdiction: ['United States']
        },
        {
          id: 3,
          title: "EU Dual-Use Export Controls Analysis",
          description: "In-depth analysis of EU dual-use export control framework",
          contribution_type: 'article',
          status: 'approved',
          submitted_by: 'user789',
          submitted_by_name: 'Dr. Michael Chen',
          submitted_at: '2024-08-21T09:20:00Z',
          reviewed_by: 'admin',
          reviewed_at: '2024-08-23T11:00:00Z',
          review_comments: 'Excellent analysis, approved for publication',
          category: 'industry-analysis',
          tags: ['EU', 'Dual-Use', 'Export Controls'],
          featured_status: true
        }
      ];

      // Filter based on active tab and filters
      let filteredContributions = mockContributions;
      
      if (activeTab !== 'all') {
        filteredContributions = filteredContributions.filter(c => c.status === activeTab);
      }
      
      if (searchQuery) {
        filteredContributions = filteredContributions.filter(c => 
          c.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          c.description?.toLowerCase().includes(searchQuery.toLowerCase()) ||
          c.submitted_by_name?.toLowerCase().includes(searchQuery.toLowerCase())
        );
      }
      
      if (typeFilter !== 'all') {
        filteredContributions = filteredContributions.filter(c => c.contribution_type === typeFilter);
      }

      setContributions(filteredContributions);
      
      // Calculate stats
      setStats({
        pending: mockContributions.filter(c => c.status === 'pending').length,
        approved: mockContributions.filter(c => c.status === 'approved').length,
        rejected: mockContributions.filter(c => c.status === 'rejected').length,
        total: mockContributions.length
      });
      
    } catch (error) {
      console.error('Error loading contributions:', error);
      toast.error('Failed to load user contributions');
    } finally {
      setLoading(false);
    }
  };

  const handleReview = async () => {
    if (!selectedContribution) return;
    
    try {
      setProcessing(true);
      
      // Here we would call the backend API to approve/reject the contribution
      // await brain.review_user_contribution({
      //   contribution_id: selectedContribution.id,
      //   action: reviewAction,
      //   comments: reviewComments
      // });
      
      toast.success(`Contribution ${reviewAction}d successfully`);
      
      // Update local state
      setContributions(prev => prev.map(c => 
        c.id === selectedContribution.id 
          ? { 
              ...c, 
              status: reviewAction === 'approve' ? 'approved' : 'rejected',
              review_comments: reviewComments,
              reviewed_at: new Date().toISOString()
            }
          : c
      ));
      
      setShowReviewDialog(false);
      setSelectedContribution(null);
      setReviewComments('');
      onRefresh?.();
      
    } catch (error) {
      console.error('Error reviewing contribution:', error);
      toast.error('Failed to review contribution');
    } finally {
      setProcessing(false);
    }
  };

  const openReviewDialog = (contribution: UserContribution, action: 'approve' | 'reject') => {
    setSelectedContribution(contribution);
    setReviewAction(action);
    setShowReviewDialog(true);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30';
      case 'approved': return 'bg-green-500/20 text-green-400 border-green-500/30';
      case 'rejected': return 'bg-red-500/20 text-red-400 border-red-500/30';
      default: return 'bg-gray-500/20 text-gray-400 border-gray-500/30';
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'blog': return <MessageSquare className="h-4 w-4" />;
      case 'document': return <FileText className="h-4 w-4" />;
      case 'article': return <BookOpen className="h-4 w-4" />;
      default: return <FileText className="h-4 w-4" />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-gradient-to-br from-yellow-600/20 to-yellow-800/20 border-yellow-600/30">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-yellow-400">Pending Review</p>
                <p className="text-2xl font-bold text-white">{stats.pending}</p>
              </div>
              <Clock className="h-8 w-8 text-yellow-400" />
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-gradient-to-br from-green-600/20 to-green-800/20 border-green-600/30">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-green-400">Approved</p>
                <p className="text-2xl font-bold text-white">{stats.approved}</p>
              </div>
              <CheckCircle className="h-8 w-8 text-green-400" />
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-gradient-to-br from-red-600/20 to-red-800/20 border-red-600/30">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-red-400">Rejected</p>
                <p className="text-2xl font-bold text-white">{stats.rejected}</p>
              </div>
              <XCircle className="h-8 w-8 text-red-400" />
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-gradient-to-br from-blue-600/20 to-blue-800/20 border-blue-600/30">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-blue-400">Total</p>
                <p className="text-2xl font-bold text-white">{stats.total}</p>
              </div>
              <FileText className="h-8 w-8 text-blue-400" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters and Controls */}
      <Card className="bg-gray-800/50 border-gray-700">
        <CardContent className="p-4">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <Input
                  placeholder="Search contributions..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 bg-gray-700 border-gray-600 text-white"
                />
              </div>
            </div>
            <Select value={typeFilter} onValueChange={setTypeFilter}>
              <SelectTrigger className="w-48 bg-gray-700 border-gray-600">
                <SelectValue placeholder="Filter by type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                <SelectItem value="blog">Blog Posts</SelectItem>
                <SelectItem value="document">Documents</SelectItem>
                <SelectItem value="article">Articles</SelectItem>
              </SelectContent>
            </Select>
            <Button 
              onClick={loadContributions}
              variant="outline"
              className="border-gray-600 text-gray-300 hover:bg-gray-700"
              disabled={loading}
            >
              <RefreshCw className={`h-4 w-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
              Refresh
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Main Content Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-4 bg-gray-800/50">
          <TabsTrigger value="pending" className="data-[state=active]:bg-yellow-600">
            <Clock className="h-4 w-4 mr-2" />
            Pending ({stats.pending})
          </TabsTrigger>
          <TabsTrigger value="approved" className="data-[state=active]:bg-green-600">
            <CheckCircle className="h-4 w-4 mr-2" />
            Approved ({stats.approved})
          </TabsTrigger>
          <TabsTrigger value="rejected" className="data-[state=active]:bg-red-600">
            <XCircle className="h-4 w-4 mr-2" />
            Rejected ({stats.rejected})
          </TabsTrigger>
          <TabsTrigger value="all" className="data-[state=active]:bg-blue-600">
            <FileText className="h-4 w-4 mr-2" />
            All ({stats.total})
          </TabsTrigger>
        </TabsList>

        <TabsContent value={activeTab} className="space-y-4">
          {loading ? (
            <div className="space-y-4">
              {[1, 2, 3].map((i) => (
                <Card key={i} className="bg-gray-800/50 border-gray-700">
                  <CardContent className="p-6">
                    <div className="animate-pulse">
                      <div className="h-4 bg-gray-600 rounded w-1/2 mb-2"></div>
                      <div className="h-3 bg-gray-600 rounded w-3/4 mb-4"></div>
                      <div className="h-3 bg-gray-600 rounded w-1/4"></div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : contributions.length === 0 ? (
            <Card className="bg-gray-800/50 border-gray-700">
              <CardContent className="p-12 text-center">
                <FileText className="h-16 w-16 text-gray-600 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-white mb-2">No Contributions Found</h3>
                <p className="text-gray-400">
                  {activeTab === 'pending' 
                    ? 'No contributions are currently pending review.'
                    : `No ${activeTab} contributions found.`
                  }
                </p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-4">
              {contributions.map((contribution) => (
                <Card key={contribution.id} className="bg-gray-800/50 border-gray-700 hover:bg-gray-800/70 transition-colors">
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          {getTypeIcon(contribution.contribution_type)}
                          <h3 className="text-lg font-semibold text-white">{contribution.title}</h3>
                          <Badge className={getStatusColor(contribution.status)}>
                            {contribution.status.charAt(0).toUpperCase() + contribution.status.slice(1)}
                          </Badge>
                          {contribution.featured_status && (
                            <Badge className="bg-amber-500/20 text-amber-400 border-amber-500/30">
                              <Star className="h-3 w-3 mr-1" />
                              Featured
                            </Badge>
                          )}
                        </div>
                        
                        <p className="text-gray-400 mb-3">{contribution.description}</p>
                        
                        <div className="flex items-center gap-4 text-sm text-gray-500">
                          <div className="flex items-center gap-1">
                            <User className="h-4 w-4" />
                            {contribution.submitted_by_name || contribution.submitted_by}
                          </div>
                          <div className="flex items-center gap-1">
                            <Calendar className="h-4 w-4" />
                            {new Date(contribution.submitted_at).toLocaleDateString()}
                          </div>
                          {contribution.category && (
                            <div className="flex items-center gap-1">
                              <Filter className="h-4 w-4" />
                              {contribution.category.replace('-', ' ')}
                            </div>
                          )}
                          {contribution.reading_time && (
                            <div className="flex items-center gap-1">
                              <Clock className="h-4 w-4" />
                              {contribution.reading_time} min read
                            </div>
                          )}
                        </div>
                        
                        {contribution.tags && contribution.tags.length > 0 && (
                          <div className="flex flex-wrap gap-2 mt-3">
                            {contribution.tags.map((tag, index) => (
                              <Badge key={index} variant="outline" className="border-gray-600 text-gray-400">
                                {tag}
                              </Badge>
                            ))}
                          </div>
                        )}
                        
                        {contribution.review_comments && (
                          <div className="mt-4 p-3 bg-gray-700/50 border border-gray-600 rounded">
                            <p className="text-sm text-gray-300">
                              <strong>Review Comments:</strong> {contribution.review_comments}
                            </p>
                          </div>
                        )}
                      </div>
                      
                      <div className="flex flex-col gap-2 ml-4">
                        <Button 
                          size="sm" 
                          variant="outline"
                          className="border-gray-600 text-gray-300 hover:bg-gray-700"
                        >
                          <Eye className="h-4 w-4 mr-2" />
                          Preview
                        </Button>
                        
                        {contribution.status === 'pending' && (
                          <>
                            <Button 
                              size="sm" 
                              onClick={() => openReviewDialog(contribution, 'approve')}
                              className="bg-green-600 hover:bg-green-700 text-white"
                            >
                              <CheckCircle className="h-4 w-4 mr-2" />
                              Approve
                            </Button>
                            <Button 
                              size="sm" 
                              variant="destructive"
                              onClick={() => openReviewDialog(contribution, 'reject')}
                            >
                              <XCircle className="h-4 w-4 mr-2" />
                              Reject
                            </Button>
                          </>
                        )}
                        
                        {contribution.status === 'approved' && (
                          <Button 
                            size="sm" 
                            variant="outline"
                            className="border-blue-600 text-blue-400 hover:bg-blue-600/20"
                          >
                            <Edit className="h-4 w-4 mr-2" />
                            Edit
                          </Button>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>

      {/* Review Dialog */}
      <Dialog open={showReviewDialog} onOpenChange={setShowReviewDialog}>
        <DialogContent className="bg-gray-800 border-gray-700 text-white max-w-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              {reviewAction === 'approve' ? (
                <CheckCircle className="h-5 w-5 text-green-400" />
              ) : (
                <XCircle className="h-5 w-5 text-red-400" />
              )}
              {reviewAction === 'approve' ? 'Approve' : 'Reject'} Contribution
            </DialogTitle>
            <DialogDescription className="text-gray-400">
              {selectedContribution && (
                <span>Review: <strong>{selectedContribution.title}</strong></span>
              )}
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium text-white mb-2 block">Review Comments</label>
              <Textarea
                value={reviewComments}
                onChange={(e) => setReviewComments(e.target.value)}
                placeholder={`Add ${reviewAction === 'approve' ? 'approval' : 'rejection'} comments...`}
                className="bg-gray-700 border-gray-600 text-white"
                rows={4}
              />
            </div>
            
            <div className="flex justify-end gap-3">
              <Button 
                variant="outline" 
                onClick={() => setShowReviewDialog(false)}
                className="border-gray-600 text-gray-300 hover:bg-gray-700"
              >
                Cancel
              </Button>
              <Button 
                onClick={handleReview}
                disabled={processing}
                className={reviewAction === 'approve' 
                  ? 'bg-green-600 hover:bg-green-700' 
                  : 'bg-red-600 hover:bg-red-700'
                }
              >
                {processing ? (
                  <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                ) : reviewAction === 'approve' ? (
                  <CheckCircle className="h-4 w-4 mr-2" />
                ) : (
                  <XCircle className="h-4 w-4 mr-2" />
                )}
                {processing ? 'Processing...' : (reviewAction === 'approve' ? 'Approve' : 'Reject')}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

export default UserContributionsValidationTab;
