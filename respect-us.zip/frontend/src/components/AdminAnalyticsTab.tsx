import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  BarChart3, TrendingUp, Eye, Users, Search, DollarSign, 
  Clock, Download, BookOpen, Activity, Target, Database,
  FileText, Bookmark, MessageSquare, Calendar, Globe
} from 'lucide-react';
import { toast } from 'sonner';
import brain from 'brain';
import { 
  DocumentAnalytics, 
  UserBehaviorAnalytics, 
  SearchAnalytics,
  PricingAnalyticsResponse
} from '../brain/data-contracts';

interface Props {
  loading?: boolean;
}

export function AdminAnalyticsTab({ loading = false }: Props) {
  const [documentAnalytics, setDocumentAnalytics] = useState<DocumentAnalytics[]>([]);
  const [userBehaviorData, setUserBehaviorData] = useState<UserBehaviorAnalytics[]>([]);
  const [searchAnalyticsData, setSearchAnalyticsData] = useState<SearchAnalytics[]>([]);
  const [pricingAnalytics, setPricingAnalytics] = useState<PricingAnalyticsResponse[]>([]);
  const [activeSubTab, setActiveSubTab] = useState('overview');
  const [dataLoading, setDataLoading] = useState(true);
  const [timeRange, setTimeRange] = useState('30d');

  // Load all analytics data
  useEffect(() => {
    loadAnalyticsData();
  }, [timeRange]);

  const loadAnalyticsData = async () => {
    try {
      setDataLoading(true);
      
      // Load document analytics
      const docResponse = await brain.get_document_analytics({ 
        time_range: timeRange,
        limit: 50,
        sort_by: 'popularity_score'
      });
      if (docResponse.ok) {
        const docData = await docResponse.json();
        setDocumentAnalytics(docData);
      }
      
      // Load user behavior analytics
      const userResponse = await brain.get_user_behavior_analytics({ 
        time_range: timeRange,
        limit: 50
      });
      if (userResponse.ok) {
        const userData = await userResponse.json();
        setUserBehaviorData(userData);
      }
      
      // Load search analytics
      const searchResponse = await brain.get_search_analytics({ 
        limit: 50,
        min_frequency: 1
      });
      if (searchResponse.ok) {
        const searchData = await searchResponse.json();
        setSearchAnalyticsData(searchData);
      }
      
      // Load pricing analytics
      const pricingResponse = await brain.get_pricing_analytics();
      if (pricingResponse.ok) {
        const pricingData = await pricingResponse.json();
        setPricingAnalytics(pricingData);
      }
      
    } catch (error) {
      console.error('Error loading analytics data:', error);
      toast.error('Failed to load analytics data');
    } finally {
      setDataLoading(false);
    }
  };

  const refreshData = () => {
    loadAnalyticsData();
    toast.success('Analytics data refreshed');
  };

  if (loading || dataLoading) {
    return (
      <div className="space-y-6">
        <div className="bg-gray-800/30 backdrop-blur-sm border border-gray-700 rounded-lg p-6">
          <div className="animate-pulse">
            <div className="h-6 bg-gray-600 rounded w-1/4 mb-4"></div>
            <div className="h-4 bg-gray-600 rounded w-1/2 mb-6"></div>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              {[1, 2, 3, 4].map((i) => (
                <div key={i} className="h-24 bg-gray-600 rounded"></div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Calculate overview metrics
  const totalViews = documentAnalytics.reduce((sum, doc) => sum + doc.total_views, 0);
  const totalUniqueViewers = documentAnalytics.reduce((sum, doc) => sum + doc.unique_viewers, 0);
  const totalAnnotations = documentAnalytics.reduce((sum, doc) => sum + doc.annotations_count, 0);
  const totalDownloads = documentAnalytics.reduce((sum, doc) => sum + doc.downloads, 0);
  const totalSearches = searchAnalyticsData.reduce((sum, search) => sum + search.frequency, 0);
  const avgSearchSuccessRate = searchAnalyticsData.reduce((sum, search) => sum + search.success_rate, 0) / (searchAnalyticsData.length || 1);
  const totalActiveUsers = userBehaviorData.length;
  const totalCreditsConsumed = pricingAnalytics.reduce((sum, price) => sum + (price.min_credit_cost || 0), 0);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-gray-800/30 backdrop-blur-sm border border-gray-700 rounded-lg p-6">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-2xl font-semibold text-white mb-2 flex items-center">
              <BarChart3 className="w-6 h-6 mr-3 text-blue-400" />
              Analytics Dashboard
            </h2>
            <p className="text-gray-400">
              Comprehensive insights into platform usage, document engagement, and user behavior
            </p>
          </div>
          <div className="flex items-center space-x-4">
            <select
              value={timeRange}
              onChange={(e) => setTimeRange(e.target.value)}
              className="bg-gray-700 border border-gray-600 text-white rounded-lg px-3 py-2 text-sm"
            >
              <option value="7d">Last 7 days</option>
              <option value="30d">Last 30 days</option>
              <option value="90d">Last 3 months</option>
              <option value="1y">Last year</option>
            </select>
            <Button 
              onClick={refreshData}
              className="bg-blue-600 hover:bg-blue-700 text-white"
            >
              <Activity className="w-4 h-4 mr-2" />
              Refresh
            </Button>
          </div>
        </div>

        {/* Overview Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card className="bg-gradient-to-br from-blue-900/20 to-blue-800/20 border-blue-500/30">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-blue-300 text-sm font-medium">Total Views</p>
                  <p className="text-2xl font-bold text-white">{totalViews.toLocaleString()}</p>
                </div>
                <Eye className="w-8 h-8 text-blue-400" />
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-gradient-to-br from-green-900/20 to-green-800/20 border-green-500/30">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-green-300 text-sm font-medium">Active Users</p>
                  <p className="text-2xl font-bold text-white">{totalActiveUsers}</p>
                </div>
                <Users className="w-8 h-8 text-green-400" />
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-gradient-to-br from-purple-900/20 to-purple-800/20 border-purple-500/30">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-purple-300 text-sm font-medium">Total Searches</p>
                  <p className="text-2xl font-bold text-white">{totalSearches.toLocaleString()}</p>
                </div>
                <Search className="w-8 h-8 text-purple-400" />
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-gradient-to-br from-amber-900/20 to-amber-800/20 border-amber-500/30">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-amber-300 text-sm font-medium">Downloads</p>
                  <p className="text-2xl font-bold text-white">{totalDownloads.toLocaleString()}</p>
                </div>
                <Download className="w-8 h-8 text-amber-400" />
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Detailed Analytics Tabs */}
      <div className="bg-gray-800/30 backdrop-blur-sm border border-gray-700 rounded-lg">
        <Tabs value={activeSubTab} onValueChange={setActiveSubTab}>
          <div className="border-b border-gray-700 p-6">
            <TabsList className="grid w-full grid-cols-4 bg-gray-800/50">
              <TabsTrigger value="overview" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white">
                <BarChart3 className="w-4 h-4 mr-2" />
                Documents
              </TabsTrigger>
              <TabsTrigger value="users" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white">
                <Users className="w-4 h-4 mr-2" />
                User Behavior
              </TabsTrigger>
              <TabsTrigger value="search" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white">
                <Search className="w-4 h-4 mr-2" />
                Search Analytics
              </TabsTrigger>
              <TabsTrigger value="pricing" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white">
                <DollarSign className="w-4 h-4 mr-2" />
                Pricing & Usage
              </TabsTrigger>
            </TabsList>
          </div>

          {/* Document Analytics Tab */}
          <TabsContent value="overview" className="space-y-6 p-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="bg-gray-900/50 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white flex items-center">
                    <FileText className="w-5 h-5 mr-2 text-blue-400" />
                    Top Performing Documents
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {documentAnalytics.slice(0, 5).map((doc, index) => (
                      <div key={doc.document_id} className="flex items-center justify-between p-3 bg-gray-800/50 rounded-lg">
                        <div className="flex-1">
                          <p className="text-white font-medium text-sm truncate">{doc.title}</p>
                          <div className="flex items-center space-x-4 mt-1">
                            <span className="text-gray-400 text-xs flex items-center">
                              <Eye className="w-3 h-3 mr-1" />
                              {doc.total_views}
                            </span>
                            <span className="text-gray-400 text-xs flex items-center">
                              <Clock className="w-3 h-3 mr-1" />
                              {doc.avg_time_spent}m
                            </span>
                            <Badge className="text-xs">
                              {doc.jurisdiction}
                            </Badge>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="text-green-400 font-semibold text-sm">
                            {doc.popularity_score}%
                          </div>
                          <div className="text-gray-400 text-xs">Score</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gray-900/50 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white flex items-center">
                    <TrendingUp className="w-5 h-5 mr-2 text-green-400" />
                    Engagement Metrics
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="text-center p-4 bg-gray-800/50 rounded-lg">
                      <BookOpen className="w-6 h-6 text-blue-400 mx-auto mb-2" />
                      <div className="text-2xl font-bold text-white">{totalUniqueViewers.toLocaleString()}</div>
                      <div className="text-gray-400 text-sm">Unique Viewers</div>
                    </div>
                    <div className="text-center p-4 bg-gray-800/50 rounded-lg">
                      <MessageSquare className="w-6 h-6 text-purple-400 mx-auto mb-2" />
                      <div className="text-2xl font-bold text-white">{totalAnnotations}</div>
                      <div className="text-gray-400 text-sm">Annotations</div>
                    </div>
                    <div className="text-center p-4 bg-gray-800/50 rounded-lg">
                      <Bookmark className="w-6 h-6 text-amber-400 mx-auto mb-2" />
                      <div className="text-2xl font-bold text-white">
                        {documentAnalytics.reduce((sum, doc) => sum + doc.bookmarks_count, 0)}
                      </div>
                      <div className="text-gray-400 text-sm">Bookmarks</div>
                    </div>
                    <div className="text-center p-4 bg-gray-800/50 rounded-lg">
                      <Download className="w-6 h-6 text-green-400 mx-auto mb-2" />
                      <div className="text-2xl font-bold text-white">{totalDownloads}</div>
                      <div className="text-gray-400 text-sm">Downloads</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* User Behavior Tab */}
          <TabsContent value="users" className="space-y-6 p-6">
            <Card className="bg-gray-900/50 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center">
                  <Users className="w-5 h-5 mr-2 text-blue-400" />
                  User Engagement Levels
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {userBehaviorData.slice(0, 10).map((user, index) => (
                    <div key={user.user_id} className="flex items-center justify-between p-4 bg-gray-800/50 rounded-lg">
                      <div className="flex items-center space-x-4">
                        <div className="w-8 h-8 bg-blue-600/20 rounded-full flex items-center justify-center">
                          <Users className="w-4 h-4 text-blue-400" />
                        </div>
                        <div>
                          <p className="text-white font-medium">{user.user_id}</p>
                          <p className="text-gray-400 text-sm">
                            {user.total_sessions} sessions • {user.total_time_spent}h total
                          </p>
                        </div>
                      </div>
                      <div className="text-right">
                        <Badge 
                          className={`${
                            user.engagement_level === 'expert' ? 'bg-green-500/20 text-green-400 border-green-500/30' :
                            user.engagement_level === 'high' ? 'bg-blue-500/20 text-blue-400 border-blue-500/30' :
                            user.engagement_level === 'medium' ? 'bg-amber-500/20 text-amber-400 border-amber-500/30' :
                            'bg-gray-500/20 text-gray-400 border-gray-500/30'
                          }`}
                        >
                          {user.engagement_level}
                        </Badge>
                        <div className="text-gray-400 text-xs mt-1">
                          {user.most_active_jurisdiction}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Search Analytics Tab */}
          <TabsContent value="search" className="space-y-6 p-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="bg-gray-900/50 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white flex items-center">
                    <Search className="w-5 h-5 mr-2 text-purple-400" />
                    Popular Search Queries
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {searchAnalyticsData.slice(0, 8).map((search, index) => (
                      <div key={search.query} className="flex items-center justify-between p-3 bg-gray-800/50 rounded-lg">
                        <div className="flex-1">
                          <p className="text-white font-medium text-sm">"{search.query}"</p>
                          <div className="flex items-center space-x-2 mt-1">
                            <span className="text-gray-400 text-xs">
                              {search.frequency} searches
                            </span>
                            <span className="text-gray-400 text-xs">•</span>
                            <span className="text-gray-400 text-xs">
                              {(search.success_rate * 100).toFixed(1)}% success
                            </span>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="text-blue-400 font-semibold text-sm">
                            {search.avg_results_count}
                          </div>
                          <div className="text-gray-400 text-xs">Results</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gray-900/50 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white flex items-center">
                    <Target className="w-5 h-5 mr-2 text-green-400" />
                    Search Performance
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 gap-4">
                    <div className="text-center p-4 bg-gray-800/50 rounded-lg">
                      <Search className="w-6 h-6 text-purple-400 mx-auto mb-2" />
                      <div className="text-2xl font-bold text-white">{totalSearches.toLocaleString()}</div>
                      <div className="text-gray-400 text-sm">Total Searches</div>
                    </div>
                    <div className="text-center p-4 bg-gray-800/50 rounded-lg">
                      <TrendingUp className="w-6 h-6 text-green-400 mx-auto mb-2" />
                      <div className="text-2xl font-bold text-white">
                        {(avgSearchSuccessRate * 100).toFixed(1)}%
                      </div>
                      <div className="text-gray-400 text-sm">Average Success Rate</div>
                    </div>
                    <div className="text-center p-4 bg-gray-800/50 rounded-lg">
                      <Globe className="w-6 h-6 text-blue-400 mx-auto mb-2" />
                      <div className="text-2xl font-bold text-white">
                        {new Set(searchAnalyticsData.flatMap(s => s.jurisdictions_searched)).size}
                      </div>
                      <div className="text-gray-400 text-sm">Jurisdictions Searched</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Pricing Analytics Tab */}
          <TabsContent value="pricing" className="space-y-6 p-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="bg-gray-900/50 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white flex items-center">
                    <DollarSign className="w-5 h-5 mr-2 text-green-400" />
                    Pricing Tiers Usage
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {pricingAnalytics.map((pricing, index) => (
                      <div key={`${pricing.pricing_tier}-${pricing.is_premium}`} className="flex items-center justify-between p-4 bg-gray-800/50 rounded-lg">
                        <div className="flex items-center space-x-4">
                          <div className="w-8 h-8 bg-green-600/20 rounded-full flex items-center justify-center">
                            <DollarSign className="w-4 h-4 text-green-400" />
                          </div>
                          <div>
                            <p className="text-white font-medium">
                              {pricing.pricing_tier}
                              {pricing.is_premium && <Badge className="ml-2 text-xs bg-amber-500/20 text-amber-400 border-amber-500/30">Premium</Badge>}
                            </p>
                            <p className="text-gray-400 text-sm">
                              {pricing.document_count} documents • {pricing.priced_documents} priced
                            </p>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="text-green-400 font-semibold">
                            {pricing.avg_credit_cost?.toFixed(1) || 'N/A'}
                          </div>
                          <div className="text-gray-400 text-xs">Avg Credits</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gray-900/50 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white flex items-center">
                    <Database className="w-5 h-5 mr-2 text-blue-400" />
                    Usage Statistics
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 gap-4">
                    <div className="text-center p-4 bg-gray-800/50 rounded-lg">
                      <DollarSign className="w-6 h-6 text-green-400 mx-auto mb-2" />
                      <div className="text-2xl font-bold text-white">{totalCreditsConsumed}</div>
                      <div className="text-gray-400 text-sm">Total Credits Used</div>
                    </div>
                    <div className="text-center p-4 bg-gray-800/50 rounded-lg">
                      <FileText className="w-6 h-6 text-blue-400 mx-auto mb-2" />
                      <div className="text-2xl font-bold text-white">
                        {pricingAnalytics.reduce((sum, p) => sum + p.priced_documents, 0)}
                      </div>
                      <div className="text-gray-400 text-sm">Priced Documents</div>
                    </div>
                    <div className="text-center p-4 bg-gray-800/50 rounded-lg">
                      <BarChart3 className="w-6 h-6 text-purple-400 mx-auto mb-2" />
                      <div className="text-2xl font-bold text-white">
                        {pricingAnalytics.length}
                      </div>
                      <div className="text-gray-400 text-sm">Pricing Tiers</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

export default AdminAnalyticsTab;
