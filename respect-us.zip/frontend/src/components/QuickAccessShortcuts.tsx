import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import { 
  Star, 
  Clock, 
  TrendingUp, 
  Zap, 
  ArrowRight,
  Plus,
  X
} from 'lucide-react';
import { useNavigationSession } from 'utils/useNavigationSession';
import { 
  getQuickAccessShortcuts, 
  trackModuleAccess,
  getModuleById 
} from 'utils/navigationUtils';
import { QuickAccessShortcut } from 'utils/navigationTypes';

interface QuickAccessShortcutsProps {
  maxShortcuts?: number;
  showCategories?: boolean;
  layout?: 'grid' | 'list' | 'compact';
  className?: string;
}

export default function QuickAccessShortcuts({
  maxShortcuts = 8,
  showCategories = true,
  layout = 'grid',
  className = ''
}: QuickAccessShortcutsProps) {
  const navigate = useNavigate();
  const { favoriteModules, recentModules, toggleFavorite, isFavorite } = useNavigationSession();
  const [shortcuts, setShortcuts] = React.useState<QuickAccessShortcut[]>([]);
  
  React.useEffect(() => {
    const allShortcuts = getQuickAccessShortcuts();
    setShortcuts(allShortcuts.slice(0, maxShortcuts));
  }, [maxShortcuts, favoriteModules, recentModules]);
  
  const handleShortcutClick = (shortcut: QuickAccessShortcut) => {
    trackModuleAccess(shortcut.module);
    navigate(shortcut.path);
  };
  
  const handleToggleFavorite = (moduleId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    toggleFavorite(moduleId);
  };
  
  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'recent':
        return <Clock className="w-4 h-4" />;
      case 'favorite':
        return <Star className="w-4 h-4" />;
      case 'suggested':
        return <TrendingUp className="w-4 h-4" />;
      default:
        return <Zap className="w-4 h-4" />;
    }
  };
  
  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'recent':
        return 'text-blue-400';
      case 'favorite':
        return 'text-yellow-400';
      case 'suggested':
        return 'text-green-400';
      default:
        return 'text-purple-400';
    }
  };
  
  const groupedShortcuts = shortcuts.reduce((acc, shortcut) => {
    if (!acc[shortcut.category]) {
      acc[shortcut.category] = [];
    }
    acc[shortcut.category].push(shortcut);
    return acc;
  }, {} as Record<string, QuickAccessShortcut[]>);
  
  const renderShortcut = (shortcut: QuickAccessShortcut) => {
    const IconComponent = shortcut.icon;
    const module = getModuleById(shortcut.module);
    const isCurrentFavorite = isFavorite(shortcut.module);
    
    if (layout === 'compact') {
      return (
        <TooltipProvider key={shortcut.id}>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => handleShortcutClick(shortcut)}
                className="h-10 w-10 p-0 text-gray-400 hover:text-white hover:bg-gray-800/50 relative group"
              >
                <IconComponent className="w-5 h-5" />
                {shortcut.category === 'favorite' && (
                  <Star className="absolute -top-1 -right-1 w-3 h-3 text-yellow-400 fill-current" />
                )}
              </Button>
            </TooltipTrigger>
            <TooltipContent>
              <div className="text-center">
                <p className="font-medium">{shortcut.name}</p>
                <p className="text-xs text-gray-400">{shortcut.description}</p>
                {shortcut.hotkey && (
                  <Badge className="text-xs mt-1">{shortcut.hotkey}</Badge>
                )}
              </div>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
      );
    }
    
    if (layout === 'list') {
      return (
        <Card 
          key={shortcut.id}
          className="bg-gray-800/30 border-gray-700/50 hover:bg-gray-800/50 transition-all duration-200 cursor-pointer group"
          onClick={() => handleShortcutClick(shortcut)}
        >
          <CardContent className="p-4">
            <div className="flex items-center space-x-3">
              <div className={`${getCategoryColor(shortcut.category)}`}>
                <IconComponent className="w-5 h-5" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center space-x-2">
                  <h4 className="font-medium text-white truncate">{shortcut.name}</h4>
                  {shortcut.category === 'favorite' && (
                    <Star className="w-3 h-3 text-yellow-400 fill-current" />
                  )}
                  {shortcut.hotkey && (
                    <Badge className="text-xs bg-gray-700/50 text-gray-400">
                      {shortcut.hotkey}
                    </Badge>
                  )}
                </div>
                <p className="text-sm text-gray-400 truncate">{shortcut.description}</p>
              </div>
              <div className="flex items-center space-x-2">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={(e) => handleToggleFavorite(shortcut.module, e)}
                  className="h-8 w-8 p-0 text-gray-400 hover:text-yellow-400 opacity-0 group-hover:opacity-100 transition-opacity"
                >
                  <Star className={`w-3 h-3 ${isCurrentFavorite ? 'fill-current text-yellow-400' : ''}`} />
                </Button>
                <ArrowRight className="w-4 h-4 text-gray-500 opacity-0 group-hover:opacity-100 transition-opacity" />
              </div>
            </div>
          </CardContent>
        </Card>
      );
    }
    
    // Grid layout (default)
    return (
      <Card 
        key={shortcut.id}
        className="bg-gray-800/30 border-gray-700/50 hover:bg-gray-800/50 hover:border-gray-600/50 transition-all duration-200 cursor-pointer group relative overflow-hidden"
        onClick={() => handleShortcutClick(shortcut)}
      >
        {/* Glass overlay effect */}
        <div className="absolute inset-0 bg-gradient-to-br from-white/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
        
        <CardHeader className="pb-2 relative z-10">
          <div className="flex items-center justify-between">
            <div className={`${getCategoryColor(shortcut.category)} group-hover:scale-110 transition-transform duration-200`}>
              <IconComponent className="w-6 h-6" />
            </div>
            <div className="flex items-center space-x-1">
              {shortcut.category === 'favorite' && (
                <Star className="w-3 h-3 text-yellow-400 fill-current" />
              )}
              <Button
                variant="ghost"
                size="sm"
                onClick={(e) => handleToggleFavorite(shortcut.module, e)}
                className="h-6 w-6 p-0 text-gray-400 hover:text-yellow-400 opacity-0 group-hover:opacity-100 transition-opacity"
              >
                <Star className={`w-3 h-3 ${isCurrentFavorite ? 'fill-current text-yellow-400' : ''}`} />
              </Button>
            </div>
          </div>
        </CardHeader>
        
        <CardContent className="pt-0 relative z-10">
          <CardTitle className="text-sm font-semibold text-white mb-1 group-hover:text-blue-400 transition-colors">
            {shortcut.name}
          </CardTitle>
          <p className="text-xs text-gray-400 mb-3 line-clamp-2">
            {shortcut.description}
          </p>
          
          <div className="flex items-center justify-between">
            {shortcut.hotkey && (
              <Badge className="text-xs bg-gray-700/50 text-gray-400 border-gray-600/50">
                {shortcut.hotkey}
              </Badge>
            )}
            <ArrowRight className="w-3 h-3 text-gray-500 group-hover:text-white group-hover:translate-x-1 transition-all" />
          </div>
        </CardContent>
      </Card>
    );
  };
  
  if (shortcuts.length === 0) {
    return (
      <Card className={`bg-gray-800/30 border-gray-700/50 ${className}`}>
        <CardContent className="p-8 text-center">
          <Zap className="w-12 h-12 text-gray-500 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-300 mb-2">No Quick Access Items</h3>
          <p className="text-sm text-gray-400 mb-4">
            Start using modules to see your recent items and favorites here
          </p>
          <Button 
            onClick={() => navigate('/knowledge-base')}
            className="bg-blue-600 hover:bg-blue-700 text-white"
          >
            <Plus className="w-4 h-4 mr-2" />
            Explore Modules
          </Button>
        </CardContent>
      </Card>
    );
  }
  
  if (layout === 'compact') {
    return (
      <div className={`flex items-center space-x-2 ${className}`}>
        {shortcuts.slice(0, 6).map(renderShortcut)}
        {shortcuts.length > 6 && (
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => navigate('/user-dashboard')}
                  className="h-10 w-10 p-0 text-gray-400 hover:text-white hover:bg-gray-800/50"
                >
                  <Plus className="w-4 h-4" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p>View all shortcuts</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        )}
      </div>
    );
  }
  
  if (!showCategories) {
    const layoutClass = layout === 'grid' 
      ? 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4'
      : 'space-y-3';
    
    return (
      <div className={`${layoutClass} ${className}`}>
        {shortcuts.map(renderShortcut)}
      </div>
    );
  }
  
  return (
    <div className={`space-y-6 ${className}`}>
      {Object.entries(groupedShortcuts).map(([category, categoryShortcuts]) => {
        const layoutClass = layout === 'grid' 
          ? 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4'
          : 'space-y-3';
        
        return (
          <div key={category}>
            <div className="flex items-center space-x-2 mb-4">
              <div className={getCategoryColor(category)}>
                {getCategoryIcon(category)}
              </div>
              <h3 className="text-lg font-semibold text-white capitalize">
                {category.replace('_', ' ')}
              </h3>
              <Badge className="text-xs bg-gray-700/50 text-gray-400">
                {categoryShortcuts.length}
              </Badge>
            </div>
            
            <div className={layoutClass}>
              {categoryShortcuts.map(renderShortcut)}
            </div>
          </div>
        );
      })}
    </div>
  );
}
