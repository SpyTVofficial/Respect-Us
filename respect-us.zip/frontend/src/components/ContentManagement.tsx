



import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { 
  Plus, 
  Edit, 
  Trash2, 
  FileText, 
  MessageSquare, 
  Settings,
  AlertTriangle,
  Shield,
  Globe,
  Info,
  Eye,
  Save,
  X
} from 'lucide-react';
import { toast } from 'sonner';
import brain from 'brain';

interface ContentItem {
  id?: number;
  content_type: string;
  module_name: string;
  identifier: string;
  title: string;
  content: any;
  is_active: boolean;
  created_at?: string;
  updated_at?: string;
}

interface Props {
  onRefresh?: () => void;
}

export default function ContentManagement({ onRefresh }: Props) {
  const [activeTab, setActiveTab] = useState('end_use_checks');
  const [contentItems, setContentItems] = useState<ContentItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [selectedItem, setSelectedItem] = useState<ContentItem | null>(null);
  const [editForm, setEditForm] = useState<any>({});
  const [createForm, setCreateForm] = useState<any>({
    content_type: 'tooltip',
    module_name: 'end_use_checks',
    identifier: '',
    title: '',
    content: {},
    is_active: true
  });

  // Load content for active module
  useEffect(() => {
    loadContent();
  }, [activeTab]);

  const loadContent = async () => {
    try {
      setLoading(true);
      const response = await brain.get_content_by_module({ moduleName: activeTab });
      if (response.ok) {
        const data = await response.json();
        setContentItems(data.items || []);
      }
    } catch (error) {
      console.error('Error loading content:', error);
      toast.error('Failed to load content');
    } finally {
      setLoading(false);
    }
  };

  const initializeDefaults = async () => {
    try {
      setLoading(true);
      const response = await brain.initialize_default_content();
      if (response.ok) {
        const data = await response.json();
        toast.success(data.message);
        loadContent();
      }
    } catch (error) {
      console.error('Error initializing defaults:', error);
      toast.error('Failed to initialize default content');
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = (item: ContentItem) => {
    setSelectedItem(item);
    setEditForm({
      title: item.title,
      content: item.content,
      is_active: item.is_active
    });
    setShowEditDialog(true);
  };

  const handleSaveEdit = async () => {
    if (!selectedItem) return;
    
    try {
      const response = await brain.update_content_item(
        { contentId: selectedItem.id },
        editForm
      );
      
      if (response.ok) {
        toast.success('Content updated successfully');
        setShowEditDialog(false);
        loadContent();
      }
    } catch (error) {
      console.error('Error updating content:', error);
      toast.error('Failed to update content');
    }
  };

  const handleCreate = async () => {
    try {
      const response = await brain.create_content_item(createForm);
      
      if (response.ok) {
        toast.success('Content created successfully');
        setShowCreateDialog(false);
        setCreateForm({
          content_type: 'tooltip',
          module_name: activeTab,
          identifier: '',
          title: '',
          content: {},
          is_active: true
        });
        loadContent();
      }
    } catch (error) {
      console.error('Error creating content:', error);
      toast.error('Failed to create content');
    }
  };

  const handleDelete = async (item: ContentItem) => {
    if (!confirm('Are you sure you want to delete this content item?')) return;
    
    try {
      const response = await brain.delete_content_item({ contentId: item.id });
      
      if (response.ok) {
        toast.success('Content deleted successfully');
        loadContent();
      }
    } catch (error) {
      console.error('Error deleting content:', error);
      toast.error('Failed to delete content');
    }
  };

  const getContentTypeIcon = (type: string) => {
    switch (type) {
      case 'tooltip': return <MessageSquare className="h-4 w-4" />;
      case 'methodology_section': return <Settings className="h-4 w-4" />;
      case 'source_entry': return <FileText className="h-4 w-4" />;
      case 'methodology_overview': return <Info className="h-4 w-4" />;
      default: return <FileText className="h-4 w-4" />;
    }
  };

  const getContentTypeColor = (type: string) => {
    switch (type) {
      case 'tooltip': return 'bg-blue-600';
      case 'methodology_section': return 'bg-green-600';
      case 'source_entry': return 'bg-purple-600';
      case 'methodology_overview': return 'bg-orange-600';
      default: return 'bg-gray-600';
    }
  };

  const renderContentPreview = (item: ContentItem) => {
    const content = item.content;
    
    switch (item.content_type) {
      case 'tooltip':
        return (
          <div className="text-xs text-gray-400">
            Sources: {content.sources?.join(', ') || 'None'} • 
            Confidence: {content.confidence_level} • 
            {content.update_frequency}
          </div>
        );
      case 'methodology_section':
        return (
          <div className="text-xs text-gray-400">
            {content.description} • Icon: {content.icon} • Color: {content.color}
          </div>
        );
      case 'source_entry':
        return (
          <div className="text-xs text-gray-400">
            URL: {content.url} • Category: {content.category} • {content.update_frequency}
          </div>
        );
      case 'methodology_overview':
        return (
          <div className="text-xs text-gray-400">
            {content.description}
          </div>
        );
      case 'text_content':
      case 'explanation':
      case 'disclaimer':
        return (
          <div className="text-xs text-gray-400">
            {content.description && (
              <div className="mb-1">{content.description}</div>
            )}
            <div className="truncate">
              Text: {content.text ? `${content.text.substring(0, 50)}...` : 'No content'}
            </div>
            {content.version && (
              <div>Version: {content.version}</div>
            )}
          </div>
        );
      default:
        return <div className="text-xs text-gray-400">No preview available</div>;
    }
  };

  const renderEditForm = () => {
    if (!selectedItem) return null;
    
    const content = editForm.content || {};
    
    switch (selectedItem.content_type) {
      case 'tooltip':
        return (
          <div className="space-y-4">
            <div>
              <Label>Title</Label>
              <Input
                value={editForm.title || ''}
                onChange={(e) => setEditForm({...editForm, title: e.target.value})}
                className="bg-gray-700 border-gray-600"
              />
            </div>
            
            <div>
              <Label>Sources (one per line)</Label>
              <Textarea
                value={content.sources?.join('\n') || ''}
                onChange={(e) => setEditForm({
                  ...editForm, 
                  content: {
                    ...content, 
                    sources: e.target.value.split('\n').filter(s => s.trim())
                  }
                })}
                className="bg-gray-700 border-gray-600"
                rows={4}
              />
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Confidence Level</Label>
                <Select 
                  value={content.confidence_level || ''} 
                  onValueChange={(value) => setEditForm({
                    ...editForm, 
                    content: {...content, confidence_level: value}
                  })}
                >
                  <SelectTrigger className="bg-gray-700 border-gray-600">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="high">High</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="low">Low</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <Label>Update Frequency</Label>
                <Input
                  value={content.update_frequency || ''}
                  onChange={(e) => setEditForm({
                    ...editForm, 
                    content: {...content, update_frequency: e.target.value}
                  })}
                  className="bg-gray-700 border-gray-600"
                  placeholder="e.g., Updated monthly"
                />
              </div>
            </div>
            
            <div>
              <Label>Additional Information</Label>
              <Textarea
                value={content.additional_info || ''}
                onChange={(e) => setEditForm({
                  ...editForm, 
                  content: {...content, additional_info: e.target.value}
                })}
                className="bg-gray-700 border-gray-600"
                rows={3}
              />
            </div>
          </div>
        );
        
      case 'methodology_section':
        return (
          <div className="space-y-4">
            <div>
              <Label>Title</Label>
              <Input
                value={editForm.title || ''}
                onChange={(e) => setEditForm({...editForm, title: e.target.value})}
                className="bg-gray-700 border-gray-600"
              />
            </div>
            
            <div>
              <Label>Description</Label>
              <Input
                value={content.description || ''}
                onChange={(e) => setEditForm({
                  ...editForm, 
                  content: {...content, description: e.target.value}
                })}
                className="bg-gray-700 border-gray-600"
              />
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Icon</Label>
                <Input
                  value={content.icon || ''}
                  onChange={(e) => setEditForm({
                    ...editForm, 
                    content: {...content, icon: e.target.value}
                  })}
                  className="bg-gray-700 border-gray-600"
                  placeholder="e.g., AlertTriangle"
                />
              </div>
              
              <div>
                <Label>Color</Label>
                <Input
                  value={content.color || ''}
                  onChange={(e) => setEditForm({
                    ...editForm, 
                    content: {...content, color: e.target.value}
                  })}
                  className="bg-gray-700 border-gray-600"
                  placeholder="e.g., orange-400"
                />
              </div>
            </div>
            
            <div>
              <Label>Details</Label>
              <Textarea
                value={content.details || ''}
                onChange={(e) => setEditForm({
                  ...editForm, 
                  content: {...content, details: e.target.value}
                })}
                className="bg-gray-700 border-gray-600"
                rows={4}
              />
            </div>
          </div>
        );
        
      case 'methodology_overview':
        return (
          <div className="space-y-4">
            <div>
              <Label>Title</Label>
              <Input
                value={editForm.title || ''}
                onChange={(e) => setEditForm({...editForm, title: e.target.value})}
                className="bg-gray-700 border-gray-600"
              />
            </div>
            
            <div>
              <Label>Description</Label>
              <Textarea
                value={content.description || ''}
                onChange={(e) => setEditForm({
                  ...editForm, 
                  content: {...content, description: e.target.value}
                })}
                className="bg-gray-700 border-gray-600"
                rows={3}
              />
            </div>
            
            <div>
              <Label>Update Note</Label>
              <Input
                value={content.update_note || ''}
                onChange={(e) => setEditForm({
                  ...editForm, 
                  content: {...content, update_note: e.target.value}
                })}
                className="bg-gray-700 border-gray-600"
              />
            </div>
            
            <div>
              <Label>Confidence Note</Label>
              <Input
                value={content.confidence_note || ''}
                onChange={(e) => setEditForm({
                  ...editForm, 
                  content: {...content, confidence_note: e.target.value}
                })}
                className="bg-gray-700 border-gray-600"
              />
            </div>
          </div>
        );
        
      case 'text_content':
      case 'explanation':
      case 'disclaimer':
        return (
          <div className="space-y-4">
            <div>
              <Label>Title</Label>
              <Input
                value={editForm.title || ''}
                onChange={(e) => setEditForm({...editForm, title: e.target.value})}
                className="bg-gray-700 border-gray-600"
                placeholder="Enter content title"
              />
            </div>
            
            <div>
              <Label>Content Text</Label>
              <div className="space-y-2">
                <Textarea
                  value={content.text || ''}
                  onChange={(e) => setEditForm({
                    ...editForm, 
                    content: {...content, text: e.target.value}
                  })}
                  className="bg-gray-700 border-gray-600 font-mono text-sm"
                  rows={12}
                  placeholder="Enter the full text content...\n\nSupported formatting:\n• Use **bold** for bold text\n• Use bullet points with •\n• Use \n\n for paragraph breaks\n• Use **Headers:** for section headers"
                />
                <div className="text-xs text-gray-400">
                  <span className="font-medium">Formatting tips:</span> Use **text** for bold, • for bullets, \n\n for paragraphs
                </div>
              </div>
            </div>
            
            <div>
              <Label>Description/Summary</Label>
              <Textarea
                value={content.description || ''}
                onChange={(e) => setEditForm({
                  ...editForm, 
                  content: {...content, description: e.target.value}
                })}
                className="bg-gray-700 border-gray-600"
                rows={3}
                placeholder="Brief description of this content"
              />
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Version/Notes</Label>
                <Input
                  value={content.version || ''}
                  onChange={(e) => setEditForm({
                    ...editForm, 
                    content: {...content, version: e.target.value}
                  })}
                  className="bg-gray-700 border-gray-600"
                  placeholder="e.g., v1.0, Updated for Q4 2024"
                />
              </div>
              <div>
                <Label>Content Area</Label>
                <Select 
                  value={content.content_area || ''} 
                  onValueChange={(value) => setEditForm({
                    ...editForm, 
                    content: {...content, content_area: value}
                  })}
                >
                  <SelectTrigger className="bg-gray-700 border-gray-600">
                    <SelectValue placeholder="Select area" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="data_sources">Data Sources</SelectItem>
                    <SelectItem value="access_benefits">Access Benefits</SelectItem>
                    <SelectItem value="methodology">Methodology</SelectItem>
                    <SelectItem value="about_assessment">About Assessment</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            {/* Live Preview */}
            <div className="mt-6">
              <Label>Live Preview</Label>
              <div className="bg-gray-800 border border-gray-600 rounded-md p-4 mt-2 max-h-64 overflow-y-auto">
                <div className="prose prose-invert prose-sm max-w-none">
                  {content.text ? (
                    <div dangerouslySetInnerHTML={{
                      __html: content.text
                        .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
                        .replace(/\n\n/g, '</p><p>')
                        .replace(/^(.+)$/, '<p>$1</p>')
                        .replace(/• /g, '</p><ul><li>')
                        .replace(/<\/p><ul><li>(.+?)(<p>|$)/g, '<ul><li>$1</li></ul>$2')
                    }}
                  />
                  ) : (
                    <p className="text-gray-400 italic">Preview will appear here as you type...</p>
                  )}
                </div>
              </div>
            </div>
          </div>
        );
        
      default:
        return (
          <div>
            <Label>Content (JSON)</Label>
            <Textarea
              value={JSON.stringify(content, null, 2)}
              onChange={(e) => {
                try {
                  const parsed = JSON.parse(e.target.value);
                  setEditForm({...editForm, content: parsed});
                } catch (err) {
                  // Invalid JSON, don't update
                }
              }}
              className="bg-gray-700 border-gray-600 font-mono text-sm"
              rows={10}
            />
          </div>
        );
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-semibold text-white mb-2">Content Management</h2>
          <p className="text-gray-400">Manage methodology cards, tooltips, and source information</p>
        </div>
        <div className="flex gap-2">
          <Button
            onClick={initializeDefaults}
            variant="outline"
            className="border-blue-600 text-blue-400 hover:bg-blue-900/30"
          >
            <Settings className="h-4 w-4 mr-2" />
            Initialize Defaults
          </Button>
          <Button
            onClick={() => setShowCreateDialog(true)}
            className="bg-blue-600 hover:bg-blue-700"
          >
            <Plus className="h-4 w-4 mr-2" />
            Add Content
          </Button>
        </div>
      </div>

      {/* Module Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid grid-cols-5 bg-gray-800/50">
          <TabsTrigger value="end_use_checks" className="data-[state=active]:bg-blue-600">
            End-Use Checks
          </TabsTrigger>
          <TabsTrigger value="risk_assessment" className="data-[state=active]:bg-blue-600">
            Risk Assessment
          </TabsTrigger>
          <TabsTrigger value="sanctions" className="data-[state=active]:bg-blue-600">
            Sanctions
          </TabsTrigger>
          <TabsTrigger value="classification" className="data-[state=active]:bg-blue-600">
            Classification
          </TabsTrigger>
          <TabsTrigger value="pdf_reports" className="data-[state=active]:bg-blue-600">
            PDF Reports
          </TabsTrigger>
        </TabsList>

        <TabsContent value={activeTab} className="mt-6">
          <Card className="bg-gray-800/50 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <FileText className="h-5 w-5" />
                {activeTab.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase())} Content
              </CardTitle>
              <CardDescription className="text-gray-400">
                Manage all content items for this module
              </CardDescription>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="text-center py-8">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-400 mx-auto"></div>
                  <p className="text-gray-400 mt-2">Loading content...</p>
                </div>
              ) : contentItems.length === 0 ? (
                <div className="text-center py-8">
                  <FileText className="h-12 w-12 text-gray-500 mx-auto mb-4" />
                  <p className="text-gray-400 mb-4">No content items found for this module</p>
                  <Button
                    onClick={initializeDefaults}
                    variant="outline"
                    className="border-blue-600 text-blue-400 hover:bg-blue-900/30"
                  >
                    Initialize Default Content
                  </Button>
                </div>
              ) : (
                <div className="space-y-4">
                  {/* Content type filter tabs */}
                  <div className="flex gap-2 mb-4">
                    {['all', 'tooltip', 'methodology_section', 'methodology_overview', 'source_entry'].map(type => {
                      const filteredCount = type === 'all' 
                        ? contentItems.length 
                        : contentItems.filter(item => item.content_type === type).length;
                      
                      return (
                        <Badge
                          key={type}
                          variant={type === 'all' ? 'default' : 'outline'}
                          className="cursor-pointer hover:bg-gray-700"
                        >
                          {type.replace('_', ' ')} ({filteredCount})
                        </Badge>
                      );
                    })}
                  </div>
                  
                  {/* Content items table */}
                  <Table>
                    <TableHeader>
                      <TableRow className="border-gray-700">
                        <TableHead className="text-gray-300">Type</TableHead>
                        <TableHead className="text-gray-300">Title</TableHead>
                        <TableHead className="text-gray-300">Identifier</TableHead>
                        <TableHead className="text-gray-300">Preview</TableHead>
                        <TableHead className="text-gray-300">Status</TableHead>
                        <TableHead className="text-gray-300">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {contentItems.map((item) => (
                        <TableRow key={item.id} className="border-gray-700 hover:bg-gray-800/50">
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <div className={`p-1 rounded ${getContentTypeColor(item.content_type)} text-white`}>
                                {getContentTypeIcon(item.content_type)}
                              </div>
                              <span className="text-gray-300 text-sm">
                                {item.content_type.replace('_', ' ')}
                              </span>
                            </div>
                          </TableCell>
                          <TableCell className="text-white font-medium">{item.title}</TableCell>
                          <TableCell className="text-gray-400 font-mono text-sm">{item.identifier}</TableCell>
                          <TableCell className="max-w-xs">
                            {renderContentPreview(item)}
                          </TableCell>
                          <TableCell>
                            <Badge variant={item.is_active ? 'default' : 'secondary'}>
                              {item.is_active ? 'Active' : 'Inactive'}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <Button
                                size="sm"
                                variant="ghost"
                                onClick={() => handleEdit(item)}
                                className="text-blue-400 hover:text-blue-300 hover:bg-blue-900/20"
                              >
                                <Edit className="h-4 w-4" />
                              </Button>
                              <Button
                                size="sm"
                                variant="ghost"
                                onClick={() => handleDelete(item)}
                                className="text-red-400 hover:text-red-300 hover:bg-red-900/20"
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Edit Dialog */}
      <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
        <DialogContent className="bg-gray-800 border-gray-700 max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-white">Edit Content Item</DialogTitle>
            <DialogDescription className="text-gray-400">
              Modify the content item details
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-6">
            {renderEditForm()}
            
            <div className="flex items-center gap-2">
              <input
                type="checkbox"
                checked={editForm.is_active}
                onChange={(e) => setEditForm({...editForm, is_active: e.target.checked})}
                className="rounded"
              />
              <Label>Active</Label>
            </div>
          </div>
          
          <div className="flex justify-end gap-2 pt-4 border-t border-gray-700">
            <Button
              variant="outline"
              onClick={() => setShowEditDialog(false)}
              className="border-gray-600 text-gray-300"
            >
              <X className="h-4 w-4 mr-2" />
              Cancel
            </Button>
            <Button
              onClick={handleSaveEdit}
              className="bg-blue-600 hover:bg-blue-700"
            >
              <Save className="h-4 w-4 mr-2" />
              Save Changes
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Create Dialog */}
      <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
        <DialogContent className="bg-gray-800 border-gray-700 max-w-2xl">
          <DialogHeader>
            <DialogTitle className="text-white">Create Content Item</DialogTitle>
            <DialogDescription className="text-gray-400">
              Add a new content item to the module
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Content Type</Label>
                <Select 
                  value={createForm.content_type} 
                  onValueChange={(value) => setCreateForm({...createForm, content_type: value})}
                >
                  <SelectTrigger className="bg-gray-700 border-gray-600">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="tooltip">Tooltip</SelectItem>
                    <SelectItem value="methodology_section">Methodology Section</SelectItem>
                    <SelectItem value="methodology_overview">Methodology Overview</SelectItem>
                    <SelectItem value="source_entry">Source Entry</SelectItem>
                    <SelectItem value="text_content">Text Content</SelectItem>
                    <SelectItem value="explanation">Report Explanation</SelectItem>
                    <SelectItem value="disclaimer">Report Disclaimer</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <Label>Module</Label>
                <Select 
                  value={createForm.module_name} 
                  onValueChange={(value) => setCreateForm({...createForm, module_name: value})}
                >
                  <SelectTrigger className="bg-gray-700 border-gray-600">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="end_use_checks">End-Use Checks</SelectItem>
                    <SelectItem value="risk_assessment">Risk Assessment</SelectItem>
                    <SelectItem value="sanctions">Sanctions</SelectItem>
                    <SelectItem value="classification">Classification</SelectItem>
                    <SelectItem value="pdf_reports">PDF Reports</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <div>
              <Label>Identifier</Label>
              <Input
                value={createForm.identifier}
                onChange={(e) => setCreateForm({...createForm, identifier: e.target.value})}
                className="bg-gray-700 border-gray-600"
                placeholder="unique_identifier"
              />
            </div>
            
            <div>
              <Label>Title</Label>
              <Input
                value={createForm.title}
                onChange={(e) => setCreateForm({...createForm, title: e.target.value})}
                className="bg-gray-700 border-gray-600"
                placeholder="Content title"
              />
            </div>
          </div>
          
          <div className="flex justify-end gap-2 pt-4 border-t border-gray-700">
            <Button
              variant="outline"
              onClick={() => setShowCreateDialog(false)}
              className="border-gray-600 text-gray-300"
            >
              Cancel
            </Button>
            <Button
              onClick={handleCreate}
              className="bg-blue-600 hover:bg-blue-700"
            >
              Create
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
