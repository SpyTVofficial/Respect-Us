import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { AlertTriangle, Coins, CreditCard } from 'lucide-react';
import { toast } from 'sonner';
import brain from 'brain';

interface CreditConfirmationProps {
  open: boolean;
  onClose: () => void;
  onConfirm: () => void;
  componentName: string;
  actionName: string;
  resourceId?: string;
  description?: string;
}

interface CreditCheckResult {
  required_credits: number;
  current_balance: number;
  is_free: boolean;
  can_proceed: boolean;
  message: string;
}

export const CreditConfirmationDialog: React.FC<CreditConfirmationProps> = ({
  open,
  onClose,
  onConfirm,
  componentName,
  actionName,
  resourceId,
  description
}) => {
  const [creditCheck, setCreditCheck] = useState<CreditCheckResult | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [showPurchaseOptions, setShowPurchaseOptions] = useState(false);

  useEffect(() => {
    if (open) {
      checkCredits();
    }
  }, [open, componentName, actionName]);

  const checkCredits = async () => {
    try {
      setIsLoading(true);
      const response = await brain.reserve_credits({
        component_name: componentName,
        action_name: actionName,
        resource_id: resourceId
      });

      if (response.ok) {
        const data = await response.json();
        setCreditCheck(data);
      } else {
        toast.error('Failed to check credit requirements');
      }
    } catch (error) {
      console.error('Error checking credits:', error);
      toast.error('Failed to check credit requirements');
    } finally {
      setIsLoading(false);
    }
  };

  const handleConfirm = async () => {
    if (!creditCheck) return;

    if (creditCheck.is_free) {
      onConfirm();
      return;
    }

    if (!creditCheck.can_proceed) {
      setShowPurchaseOptions(true);
      return;
    }

    try {
      setIsProcessing(true);
      
      // Consume credits
      const response = await brain.consume_credits({
        component_name: componentName,
        action_name: actionName,
        resource_id: resourceId,
        description: description || `${componentName} - ${actionName}`
      });

      if (response.ok) {
        const result = await response.json();
        if (result.is_free || result.credits_consumed > 0) {
          toast.success(
            result.is_free 
              ? 'Action completed successfully'
              : `${result.credits_consumed} credits consumed. New balance: ${result.new_balance}`
          );
          onConfirm();
        } else {
          toast.error('Failed to process credit transaction');
        }
      } else {
        const error = await response.json();
        toast.error(error.detail || 'Failed to consume credits');
      }
    } catch (error) {
      console.error('Error consuming credits:', error);
      toast.error('Failed to process payment');
    } finally {
      setIsProcessing(false);
    }
  };

  const formatActionName = (name: string) => {
    return name.split('_').map(word => 
      word.charAt(0).toUpperCase() + word.slice(1)
    ).join(' ');
  };

  const formatComponentName = (name: string) => {
    return name.split('_').map(word => 
      word.charAt(0).toUpperCase() + word.slice(1)
    ).join(' ');
  };

  if (isLoading) {
    return (
      <Dialog open={open} onOpenChange={onClose}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Checking Credit Requirements</DialogTitle>
          </DialogHeader>
          <div className="flex items-center justify-center py-8">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  if (!creditCheck) {
    return null;
  }

  return (
    <>
      <Dialog open={open && !showPurchaseOptions} onOpenChange={onClose}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center">
              {creditCheck.is_free ? (
                <Coins className="h-5 w-5 mr-2 text-green-500" />
              ) : (
                <CreditCard className="h-5 w-5 mr-2 text-blue-500" />
              )}
              {creditCheck.is_free ? 'Free Action' : 'Credit Required'}
            </DialogTitle>
            <DialogDescription>
              {creditCheck.is_free 
                ? 'This action is currently free to use'
                : `This action requires ${creditCheck.required_credits} credits`
              }
            </DialogDescription>
          </DialogHeader>

          <Card>
            <CardContent className="p-4 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Action:</span>
                <Badge variant="outline">
                  {formatComponentName(componentName)} - {formatActionName(actionName)}
                </Badge>
              </div>

              {!creditCheck.is_free && (
                <>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Required Credits:</span>
                    <span className="font-bold text-blue-600">
                      {creditCheck.required_credits}
                    </span>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Your Balance:</span>
                    <span className={`font-bold ${
                      creditCheck.can_proceed ? 'text-green-600' : 'text-red-600'
                    }`}>
                      {creditCheck.current_balance}
                    </span>
                  </div>

                  {!creditCheck.can_proceed && (
                    <div className="flex items-center gap-2 p-3 bg-red-50 dark:bg-red-900/20 rounded-lg">
                      <AlertTriangle className="h-4 w-4 text-red-500" />
                      <span className="text-sm text-red-700 dark:text-red-300">
                        Insufficient credits. You need {creditCheck.required_credits - creditCheck.current_balance} more credits.
                      </span>
                    </div>
                  )}
                </>
              )}

              {description && (
                <div className="pt-2 border-t">
                  <span className="text-xs text-gray-500">{description}</span>
                </div>
              )}
            </CardContent>
          </Card>

          <DialogFooter>
            <Button variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button
              onClick={handleConfirm}
              disabled={isProcessing}
              className={creditCheck.is_free ? 'bg-green-600 hover:bg-green-700' : 'bg-blue-600 hover:bg-blue-700'}
            >
              {isProcessing ? 'Processing...' : (
                creditCheck.is_free ? 'Continue' : (
                  creditCheck.can_proceed ? `Use ${creditCheck.required_credits} Credits` : 'Buy Credits'
                )
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Purchase Options Dialog */}
      <Dialog open={showPurchaseOptions} onOpenChange={() => setShowPurchaseOptions(false)}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center">
              <CreditCard className="h-5 w-5 mr-2 text-blue-500" />
              Purchase Credits
            </DialogTitle>
            <DialogDescription>
              You need more credits to complete this action. Would you like to purchase credits now?
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            <div className="p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium">Required:</span>
                <span className="font-bold">{creditCheck.required_credits} credits</span>
              </div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium">Your Balance:</span>
                <span className="font-bold">{creditCheck.current_balance} credits</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium text-red-600">Shortage:</span>
                <span className="font-bold text-red-600">
                  {creditCheck.required_credits - creditCheck.current_balance} credits
                </span>
              </div>
            </div>
          </div>

          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => {
                setShowPurchaseOptions(false);
                onClose();
              }}
            >
              Cancel
            </Button>
            <Button
              onClick={() => {
                // Navigate to credit purchase page or open purchase dialog
                toast.info('Credit purchase feature coming soon');
                setShowPurchaseOptions(false);
                onClose();
              }}
              className="bg-blue-600 hover:bg-blue-700"
            >
              Buy Credits
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
};
