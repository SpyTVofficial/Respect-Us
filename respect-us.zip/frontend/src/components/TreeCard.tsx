import React from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Plus, Edit3, Copy, Trash2, Eye, Archive, CheckCircle } from 'lucide-react';
import { toast } from 'sonner';
import brain from 'brain';
import type { AppApisClassificationClassificationTree as ClassificationTree } from '../brain/data-contracts';

interface TreeCardProps {
  tree: ClassificationTree;
  isSelected: boolean;
  onTreeSelect: (tree: ClassificationTree) => void;
  onCreateNode: (tree: ClassificationTree) => void;
  onEditTree?: (tree: ClassificationTree) => void;
  onTreesReload: () => void;
  variant: 'classification' | 'introduction';
}

const TreeCard: React.FC<TreeCardProps> = ({
  tree,
  isSelected,
  onTreeSelect,
  onCreateNode,
  onEditTree,
  onTreesReload,
  variant
}) => {
  const colors = {
    classification: {
      border: isSelected ? 'border-amber-500 bg-amber-500/10' : 'border-gray-600 hover:border-gray-500 bg-gray-800/30',
      button: 'bg-amber-600 hover:bg-amber-700'
    },
    introduction: {
      border: isSelected ? 'border-blue-500 bg-blue-500/10' : 'border-gray-600 hover:border-gray-500 bg-gray-800/30',
      button: 'bg-blue-600 hover:bg-blue-700'
    }
  };

  // Status styling
  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case 'published':
        return 'bg-green-500/20 text-green-300 border-green-500/30';
      case 'archived':
        return 'bg-gray-500/20 text-gray-300 border-gray-500/30';
      default: // draft
        return 'bg-yellow-500/20 text-yellow-300 border-yellow-500/30';
    }
  };

  const handleEdit = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (onEditTree) {
      onEditTree(tree);
    } else {
      toast.info(`Edit ${variant} tree functionality available`);
    }
  };

  const handleDuplicate = async (e: React.MouseEvent) => {
    e.stopPropagation();
    try {
      if (variant === 'classification') {
        await brain.duplicate_classification_tree({ treeId: tree.id });
        toast.success('Classification tree duplicated successfully');
      } else {
        await brain.duplicate_introduction_tree({ treeId: tree.id });
        toast.success('Introduction tree duplicated successfully');
      }
      onTreesReload();
    } catch (error) {
      console.error('Error duplicating tree:', error);
      toast.error(`Failed to duplicate ${variant} tree`);
    }
  };

  const handleDelete = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (window.confirm(`Are you sure you want to delete this ${variant} tree? This action cannot be undone.`)) {
      try {
        if (variant === 'classification') {
          await brain.delete_classification_tree({ treeId: tree.id });
          toast.success('Classification tree deleted successfully');
        } else {
          await brain.delete_introduction_tree({ treeId: tree.id });
          toast.success('Introduction tree deleted successfully');
        }
        onTreesReload();
      } catch (error) {
        console.error('Error deleting tree:', error);
        toast.error(`Failed to delete ${variant} tree`);
      }
    }
  };

  const handleCreateNode = (e: React.MouseEvent) => {
    e.stopPropagation();
    onCreateNode(tree);
  };

  const handleQuickPublish = async (e: React.MouseEvent) => {
    e.stopPropagation();
    try {
      if (variant === 'classification') {
        await brain.update_classification_tree(
          { treeId: tree.id },
          { status: 'published' }
        );
      } else {
        await brain.update_introduction_tree(
          { treeId: tree.id },
          { status: 'published' }
        );
      }
      toast.success(`${variant === 'classification' ? 'Classification' : 'Introduction'} tree published successfully`);
      onTreesReload();
    } catch (error) {
      console.error('Error publishing tree:', error);
      toast.error('Failed to publish tree');
    }
  };

  const handleQuickArchive = async (e: React.MouseEvent) => {
    e.stopPropagation();
    try {
      if (variant === 'classification') {
        await brain.update_classification_tree(
          { treeId: tree.id },
          { status: 'archived' }
        );
      } else {
        await brain.update_introduction_tree(
          { treeId: tree.id },
          { status: 'archived' }
        );
      }
      toast.success(`${variant === 'classification' ? 'Classification' : 'Introduction'} tree archived successfully`);
      onTreesReload();
    } catch (error) {
      console.error('Error archiving tree:', error);
      toast.error('Failed to archive tree');
    }
  };

  return (
    <div
      className={`p-4 border rounded-lg cursor-pointer transition-all ${
        colors[variant].border
      }`}
      onClick={() => onTreeSelect(tree)}
    >
      <div className="flex justify-between items-start mb-2">
        <h3 className="font-semibold text-white">{tree.name}</h3>
        <Badge className={`text-xs ${getStatusColor(tree.status)}`}>
          {tree.status.charAt(0).toUpperCase() + tree.status.slice(1)}
        </Badge>
      </div>
      <p className="text-gray-400 text-sm mb-2">{tree.description}</p>
      <div className="flex gap-2 flex-wrap">
        <Badge variant="outline" className="text-xs">{tree.jurisdiction}</Badge>
        <Badge variant="outline" className="text-xs">{tree.category}</Badge>
        <Badge variant="outline" className="text-xs">v{tree.version}</Badge>
        {variant === 'introduction' && (
          <Badge className="bg-blue-500/20 text-blue-300 border-blue-500/30 text-xs">Introduction</Badge>
        )}
      </div>
      
      {isSelected && (
        <div className="mt-4 pt-4 border-t border-gray-600">
          {/* Quick Status Actions */}
          {tree.status !== 'published' && (
            <div className="mb-3">
              <Button
                size="sm"
                onClick={handleQuickPublish}
                className="bg-green-600 hover:bg-green-700 text-white mr-2"
                title="Quick Publish"
              >
                <CheckCircle className="w-4 h-4 mr-1" />
                Publish
              </Button>
              {tree.status !== 'archived' && (
                <Button
                  size="sm"
                  variant="outline"
                  onClick={handleQuickArchive}
                  className="border-gray-600 text-gray-300 hover:bg-gray-700"
                  title="Quick Archive"
                >
                  <Archive className="w-4 h-4 mr-1" />
                  Archive
                </Button>
              )}
            </div>
          )}
          
          <div className="flex gap-2 mb-3">
            <Button
              size="sm"
              variant="outline"
              onClick={handleEdit}
              className="border-gray-600 text-gray-300 hover:bg-gray-700 flex-1"
              title="Edit Tree"
            >
              <Edit3 className="w-4 h-4 mr-1" />
              Edit
            </Button>
            <Button
              size="sm"
              variant="outline"
              onClick={handleDuplicate}
              className="border-gray-600 text-gray-300 hover:bg-gray-700 flex-1"
              title="Duplicate Tree"
            >
              <Copy className="w-4 h-4 mr-1" />
              Duplicate
            </Button>
            <Button
              size="sm"
              variant="outline"
              onClick={handleDelete}
              className="border-red-600 text-red-300 hover:bg-red-700/20"
              title="Delete Tree"
            >
              <Trash2 className="w-4 h-4" />
            </Button>
          </div>
          <Button
            onClick={handleCreateNode}
            className={`${colors[variant].button} text-white w-full`}
          >
            <Plus className="w-4 h-4 mr-2" />
            Add Node
          </Button>
        </div>
      )}
    </div>
  );
};

export default TreeCard;
