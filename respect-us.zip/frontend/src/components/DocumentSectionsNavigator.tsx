
import React, { useState, useEffect } from 'react';
import { ChevronRight, ChevronDown, FileIcon, Hash, Search, Eye, Bookmark } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import brain from 'brain';
import { DocumentStructure, AppApisDocumentSectionsDocumentSection as DocumentSection } from '../brain/data-contracts';

interface Props {
  documentId: number;
  onSectionSelect?: (section: DocumentSection) => void;
  selectedSectionId?: number;
}

interface ExpandedState {
  [sectionId: number]: boolean;
}

const DocumentSectionsNavigator: React.FC<Props> = ({ 
  documentId, 
  onSectionSelect, 
  selectedSectionId 
}) => {
  const [documentStructure, setDocumentStructure] = useState<DocumentStructure | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<DocumentSection[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [expanded, setExpanded] = useState<ExpandedState>({});

  // Load document sections
  useEffect(() => {
    const loadDocumentSections = async () => {
      try {
        setLoading(true);
        const response = await brain.get_document_sections({ document_id: documentId });
        const data = await response.json();
        setDocumentStructure(data);
        
        // Auto-expand first level by default
        const firstLevelExpanded: ExpandedState = {};
        data.sections?.forEach((section: DocumentSection) => {
          if (!section.parent_section_id) {
            firstLevelExpanded[section.id!] = true;
          }
        });
        setExpanded(firstLevelExpanded);
        
      } catch (err) {
        console.error('Error loading document sections:', err);
        setError('Failed to load document sections');
      } finally {
        setLoading(false);
      }
    };

    if (documentId) {
      loadDocumentSections();
    }
  }, [documentId]);

  // Search sections
  useEffect(() => {
    const searchSections = async () => {
      if (!searchQuery.trim()) {
        setSearchResults([]);
        setIsSearching(false);
        return;
      }

      try {
        setIsSearching(true);
        const response = await brain.search_sections({
          query: searchQuery,
          document_id: documentId,
          limit: 20,
          offset: 0
        });
        const data = await response.json();
        setSearchResults(data.sections || []);
      } catch (err) {
        console.error('Error searching sections:', err);
        setSearchResults([]);
      } finally {
        setIsSearching(false);
      }
    };

    const timeoutId = setTimeout(searchSections, 300);
    return () => clearTimeout(timeoutId);
  }, [searchQuery, documentId]);

  const toggleExpanded = (sectionId: number) => {
    setExpanded(prev => ({
      ...prev,
      [sectionId]: !prev[sectionId]
    }));
  };

  const handleSectionClick = (section: DocumentSection) => {
    onSectionSelect?.(section);
  };

  const getSectionIcon = (sectionNumber: string | null) => {
    if (!sectionNumber) return <FileIcon className="h-4 w-4" />;
    
    if (sectionNumber.match(/^\d+$/)) {
      return <Hash className="h-4 w-4" />; // Chapters
    } else if (sectionNumber.includes('.')) {
      return <FileIcon className="h-4 w-4" />; // Subsections
    }
    return <FileIcon className="h-4 w-4" />;
  };

  const getSectionTypeColor = (sectionNumber: string | null) => {
    if (!sectionNumber) return 'bg-slate-500/20 text-slate-300';
    
    if (sectionNumber.match(/^\d+$/)) {
      return 'bg-blue-500/20 text-blue-300'; // Chapters
    } else if (sectionNumber.includes('.')) {
      return 'bg-purple-500/20 text-purple-300'; // Subsections
    }
    return 'bg-slate-500/20 text-slate-300';
  };

  const renderSection = (section: DocumentSection, level: number = 0) => {
    const hasSubsections = documentStructure?.sections.some(s => s.parent_section_id === section.id);
    const isExpanded = expanded[section.id!];
    const isSelected = selectedSectionId === section.id;
    const indentLevel = level * 24;

    return (
      <div key={section.id} className="group">
        <div 
          className={`
            flex items-center p-3 cursor-pointer transition-all duration-200 rounded-lg mx-2 mb-1
            ${isSelected 
              ? 'bg-blue-500/20 border border-blue-500/30 text-blue-300' 
              : 'hover:bg-white/5 border border-transparent'
            }
          `}
          style={{ marginLeft: `${indentLevel}px` }}
          onClick={() => handleSectionClick(section)}
        >
          {/* Expand/Collapse Button */}
          <div className="flex items-center mr-3">
            {hasSubsections ? (
              <Button
                variant="ghost"
                size="sm"
                className="h-6 w-6 p-0 hover:bg-white/10"
                onClick={(e) => {
                  e.stopPropagation();
                  toggleExpanded(section.id!);
                }}
              >
                {isExpanded ? (
                  <ChevronDown className="h-3 w-3" />
                ) : (
                  <ChevronRight className="h-3 w-3" />
                )}
              </Button>
            ) : (
              <div className="h-6 w-6" />
            )}
          </div>

          {/* Section Icon */}
          <div className="mr-3 text-slate-400">
            {getSectionIcon(section.section_number)}
          </div>

          {/* Section Content */}
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1">
              {section.section_number && (
                <Badge 
                  variant="outline" 
                  className={`text-xs ${getSectionTypeColor(section.section_number)}`}
                >
                  {section.section_number}
                </Badge>
              )}
              <span className="font-medium text-white group-hover:text-blue-300 transition-colors">
                {section.section_title}
              </span>
            </div>
            
            {/* Preview of content */}
            <p className="text-sm text-slate-400 truncate">
              {section.section_content?.substring(0, 80)}...
            </p>
          </div>

          {/* Actions */}
          <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
            <Button variant="ghost" size="sm" className="h-8 w-8 p-0 hover:bg-white/10">
              <Eye className="h-3 w-3" />
            </Button>
            <Button variant="ghost" size="sm" className="h-8 w-8 p-0 hover:bg-white/10">
              <Bookmark className="h-3 w-3" />
            </Button>
          </div>
        </div>

        {/* Render subsections */}
        {hasSubsections && isExpanded && (
          <div className="ml-6">
            {documentStructure?.sections
              .filter(s => s.parent_section_id === section.id)
              .sort((a, b) => a.display_order - b.display_order)
              .map(subsection => renderSection(subsection, level + 1))
            }
          </div>
        )}
      </div>
    );
  };

  if (loading) {
    return (
      <Card className="bg-slate-900/50 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <FileIcon className="h-5 w-5" />
            Document Sections
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {[1, 2, 3, 4].map(i => (
              <div key={i} className="h-12 bg-slate-800/50 rounded-lg animate-pulse" />
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  if (error) {
    return (
      <Card className="bg-slate-900/50 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <FileIcon className="h-5 w-5" />
            Document Sections
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8 text-slate-400">
            <FileIcon className="h-12 w-12 mx-auto mb-4 opacity-50" />
            <p>{error}</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-slate-900/50 border-slate-700">
      <CardHeader>
        <CardTitle className="text-white flex items-center justify-between">
          <div className="flex items-center gap-2">
            <FileIcon className="h-5 w-5" />
            Document Sections
          </div>
          <Badge variant="outline" className="text-xs text-slate-300">
            {documentStructure?.total_sections || 0} sections
          </Badge>
        </CardTitle>
      </CardHeader>
      
      <CardContent className="space-y-4">
        {/* Search Bar */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-slate-400" />
          <Input
            type="text"
            placeholder="Search sections..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10 bg-slate-800/50 border-slate-600 text-white placeholder-slate-400"
          />
        </div>

        <Separator className="bg-slate-700" />

        {/* Results */}
        <ScrollArea className="h-96">
          {searchQuery && searchResults.length > 0 ? (
            // Search Results
            <div className="space-y-2">
              <p className="text-sm text-slate-400 mb-3">
                Found {searchResults.length} results for "{searchQuery}"
              </p>
              {searchResults.map(section => (
                <div
                  key={section.id}
                  className="p-3 bg-slate-800/30 rounded-lg cursor-pointer hover:bg-slate-800/50 transition-colors"
                  onClick={() => handleSectionClick(section)}
                >
                  <div className="flex items-center gap-2 mb-1">
                    {section.section_number && (
                      <Badge variant="outline" className="text-xs text-slate-300">
                        {section.section_number}
                      </Badge>
                    )}
                    <span className="font-medium text-white">
                      {section.section_title}
                    </span>
                  </div>
                  <p className="text-sm text-slate-400 line-clamp-2">
                    {section.section_content}
                  </p>
                </div>
              ))}
            </div>
          ) : searchQuery && !isSearching ? (
            // No Search Results
            <div className="text-center py-8 text-slate-400">
              <Search className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p>No sections found for "{searchQuery}"</p>
            </div>
          ) : (
            // Hierarchical Structure
            <div className="space-y-1">
              {documentStructure?.sections
                .filter(section => !section.parent_section_id)
                .sort((a, b) => a.display_order - b.display_order)
                .map(section => renderSection(section, 0))
              }
              
              {(!documentStructure?.sections || documentStructure.sections.length === 0) && (
                <div className="text-center py-8 text-slate-400">
                  <FileIcon className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p>No sections available for this document</p>
                </div>
              )}
            </div>
          )}
        </ScrollArea>
      </CardContent>
    </Card>
  );
};

export default DocumentSectionsNavigator;
