import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Calendar, Eye, Clock, ArrowRight, Star, Globe, Tag } from 'lucide-react';
import { DocumentResponse } from '../types';

interface Props {
  document: DocumentResponse;
  onDocumentClick: (documentId: string) => void;
}

const FeaturedArticleHero: React.FC<Props> = ({ document, onDocumentClick }) => {
  return (
    <Card className="bg-gradient-to-br from-purple-900/40 via-purple-800/30 to-blue-900/40 border border-purple-600/30 hover:border-purple-500/50 transition-all duration-500 group rounded-2xl overflow-hidden">
      <div className="relative">
        {/* Hero Image Area */}
        <div className="h-64 md:h-80 bg-gradient-to-br from-purple-600/30 via-blue-600/30 to-amber-600/30 relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
          
          {/* Featured Badge */}
          <div className="absolute top-6 left-6">
            <Badge className="bg-amber-500/20 text-amber-300 border-amber-500/40 backdrop-blur-sm">
              <Star className="w-3 h-3 mr-1 fill-current" />
              Featured Article
            </Badge>
          </div>
          
          {/* Content Overlay */}
          <div className="absolute bottom-0 left-0 right-0 p-8">
            <div className="space-y-4">
              {/* Article Metadata */}
              <div className="flex flex-wrap items-center gap-3 text-sm text-gray-300">
                <div className="flex items-center gap-1">
                  <Calendar className="w-4 h-4" />
                  <span>{new Date(document.created_at || '').toLocaleDateString()}</span>
                </div>
                <div className="flex items-center gap-1">
                  <Clock className="w-4 h-4" />
                  <span>{Math.floor(Math.random() * 15) + 5} min read</span>
                </div>
                <div className="flex items-center gap-1">
                  <Eye className="w-4 h-4" />
                  <span>{Math.floor(Math.random() * 5000) + 1000} views</span>
                </div>
              </div>
              
              {/* Title and Description */}
              <div className="space-y-3">
                <h1 className="text-2xl md:text-3xl lg:text-4xl font-bold text-white leading-tight group-hover:text-purple-200 transition-colors">
                  {document.title}
                </h1>
                
                <p className="text-gray-200 text-lg leading-relaxed max-w-3xl">
                  {document.description || 'Comprehensive analysis of the latest compliance trends, regulatory updates, and industry best practices for export control professionals.'}
                </p>
              </div>
              
              {/* Tags and Categories */}
              <div className="flex flex-wrap items-center gap-3">
                {document.document_type && (
                  <Badge className="bg-purple-500/20 text-purple-300 border-purple-500/30">
                    {document.document_type}
                  </Badge>
                )}
                {document.jurisdiction && (
                  <Badge className="bg-green-500/20 text-green-300 border-green-500/30">
                    <Globe className="w-3 h-3 mr-1" />
                    {document.jurisdiction}
                  </Badge>
                )}
                <Badge className="bg-blue-500/20 text-blue-300 border-blue-500/30">
                  <Tag className="w-3 h-3 mr-1" />
                  Analysis
                </Badge>
                <Badge className="bg-amber-500/20 text-amber-300 border-amber-500/30">
                  <Tag className="w-3 h-3 mr-1" />
                  Trending
                </Badge>
              </div>
            </div>
          </div>
        </div>
        
        {/* Action Section */}
        <CardContent className="p-8">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="space-y-2">
              <h3 className="text-lg font-semibold text-white">Featured Insight</h3>
              <p className="text-gray-400 text-sm">
                Stay ahead of compliance challenges with our expert analysis and regulatory intelligence.
              </p>
            </div>
            
            <Button 
              onClick={() => onDocumentClick(document.id)}
              size="lg"
              className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white border-0 shadow-lg hover:shadow-xl transition-all duration-300 group"
            >
              Read Full Article
              <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
            </Button>
          </div>
        </CardContent>
      </div>
    </Card>
  );
};

export default FeaturedArticleHero;
export { FeaturedArticleHero };
