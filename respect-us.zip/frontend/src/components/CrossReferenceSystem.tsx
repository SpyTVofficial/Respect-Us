import React, { useState, useEffect } from 'react';
import { Search, Link, ExternalLink, AlertCircle, CheckCircle, Clock, Zap } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Textarea } from '@/components/ui/textarea';
import brain from 'brain';
import { toast } from 'sonner';
import {
  RelatedDocument,
  CrossReference,
  DocumentLinkingResult,
  CrossReferenceRequest,
  CrossReferenceAnalysisRequest
} from 'types';

interface Props {
  documentId: number;
  documentTitle: string;
  isVisible: boolean;
  onClose: () => void;
}

const CrossReferenceSystem: React.FC<Props> = ({ documentId, documentTitle, isVisible, onClose }) => {
  const [activeTab, setActiveTab] = useState('related');
  const [relatedDocuments, setRelatedDocuments] = useState<RelatedDocument[]>([]);
  const [crossReferences, setCrossReferences] = useState<CrossReference[]>([]);
  const [analysisResult, setAnalysisResult] = useState<DocumentLinkingResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [analyzing, setAnalyzing] = useState(false);
  
  // Create cross-reference form state
  const [createForm, setCreateForm] = useState({
    targetDocumentId: '',
    referenceType: 'cites',
    referenceText: '',
    context: '',
    confidenceScore: 0.8
  });

  useEffect(() => {
    if (isVisible) {
      loadData();
    }
  }, [isVisible, documentId]);

  const loadData = async () => {
    if (!documentId) return;
    
    setLoading(true);
    try {
      // Load related documents and cross-references in parallel
      const [relatedResponse, crossRefsResponse] = await Promise.all([
        brain.get_related_documents_for_doc({ document_id: documentId }),
        brain.get_document_cross_references({ document_id: documentId })
      ]);
      
      const relatedData = await relatedResponse.json();
      const crossRefsData = await crossRefsResponse.json();
      
      setRelatedDocuments(relatedData);
      setCrossReferences(crossRefsData);
    } catch (error) {
      console.error('Error loading cross-reference data:', error);
      toast.error('Failed to load cross-reference data');
    } finally {
      setLoading(false);
    }
  };

  const analyzeDocument = async () => {
    setAnalyzing(true);
    try {
      const request: CrossReferenceAnalysisRequest = {
        auto_detect: true,
        confidence_threshold: 0.7,
        include_suggestions: true
      };
      
      const response = await brain.analyze_document_references({ document_id: documentId }, request);
      const result = await response.json();
      
      setAnalysisResult(result);
      setActiveTab('analysis');
      
      toast.success(`Analysis complete: ${result.cross_references_created} cross-references created`);
      
      // Reload data to show new cross-references
      await loadData();
    } catch (error) {
      console.error('Error analyzing document:', error);
      toast.error('Failed to analyze document references');
    } finally {
      setAnalyzing(false);
    }
  };

  const createCrossReference = async () => {
    if (!createForm.targetDocumentId || !createForm.referenceText) {
      toast.error('Please fill in required fields');
      return;
    }
    
    try {
      const request: CrossReferenceRequest = {
        target_document_id: parseInt(createForm.targetDocumentId),
        reference_type: createForm.referenceType,
        reference_text: createForm.referenceText,
        context: createForm.context,
        confidence_score: createForm.confidenceScore
      };
      
      const response = await brain.create_document_cross_reference({ document_id: documentId }, request);
      await response.json();
      
      toast.success('Cross-reference created successfully');
      
      // Reset form and reload data
      setCreateForm({
        targetDocumentId: '',
        referenceType: 'cites',
        referenceText: '',
        context: '',
        confidenceScore: 0.8
      });
      
      await loadData();
    } catch (error) {
      console.error('Error creating cross-reference:', error);
      toast.error('Failed to create cross-reference');
    }
  };

  const getReferenceTypeColor = (type: string) => {
    switch (type) {
      case 'cites': return 'bg-blue-500/20 text-blue-400 border-blue-500/30';
      case 'amends': return 'bg-amber-500/20 text-amber-400 border-amber-500/30';
      case 'repeals': return 'bg-red-500/20 text-red-400 border-red-500/30';
      case 'implements': return 'bg-green-500/20 text-green-400 border-green-500/30';
      case 'related': return 'bg-purple-500/20 text-purple-400 border-purple-500/30';
      default: return 'bg-gray-500/20 text-gray-400 border-gray-500/30';
    }
  };

  const getConfidenceColor = (score: number) => {
    if (score >= 0.8) return 'text-green-400';
    if (score >= 0.6) return 'text-amber-400';
    return 'text-red-400';
  };

  if (!isVisible) return null;

  return (
    <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
      <div className="bg-gray-900 rounded-lg shadow-2xl w-full max-w-6xl max-h-[90vh] overflow-hidden border border-gray-800">
        <div className="p-6 border-b border-gray-800 flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold text-white flex items-center gap-2">
              <Link className="h-6 w-6 text-blue-400" />
              Cross-Reference Analysis
            </h2>
            <p className="text-gray-400 mt-1">
              Analyze connections for: <span className="text-white">{documentTitle}</span>
            </p>
          </div>
          <div className="flex items-center gap-3">
            <Button
              onClick={analyzeDocument}
              disabled={analyzing}
              className="bg-blue-600 hover:bg-blue-700 text-white"
            >
              {analyzing ? (
                <>
                  <Clock className="mr-2 h-4 w-4 animate-spin" />
                  Analyzing...
                </>
              ) : (
                <>
                  <Zap className="mr-2 h-4 w-4" />
                  Auto-Analyze
                </>
              )}
            </Button>
            <Button
              onClick={onClose}
              variant="outline"
              className="border-gray-600 text-gray-300 hover:bg-gray-800"
            >
              Close
            </Button>
          </div>
        </div>

        <div className="p-6 overflow-y-auto max-h-[calc(90vh-120px)]">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
            <TabsList className="grid w-full grid-cols-4 bg-gray-800 border border-gray-700">
              <TabsTrigger value="related" className="data-[state=active]:bg-gray-700 text-gray-300">
                Related Documents ({relatedDocuments.length})
              </TabsTrigger>
              <TabsTrigger value="references" className="data-[state=active]:bg-gray-700 text-gray-300">
                Cross-References ({crossReferences.length})
              </TabsTrigger>
              <TabsTrigger value="create" className="data-[state=active]:bg-gray-700 text-gray-300">
                Create Reference
              </TabsTrigger>
              <TabsTrigger value="analysis" className="data-[state=active]:bg-gray-700 text-gray-300">
                Analysis Results
              </TabsTrigger>
            </TabsList>

            <TabsContent value="related" className="space-y-4">
              {loading ? (
                <div className="text-center py-8">
                  <Clock className="h-8 w-8 animate-spin mx-auto text-blue-400 mb-4" />
                  <p className="text-gray-400">Loading related documents...</p>
                </div>
              ) : relatedDocuments.length === 0 ? (
                <Alert className="bg-gray-800 border-gray-700">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription className="text-gray-300">
                    No related documents found. Try running auto-analysis to discover connections.
                  </AlertDescription>
                </Alert>
              ) : (
                <div className="grid gap-4">
                  {relatedDocuments.map((doc, index) => (
                    <Card key={index} className="bg-gray-800 border-gray-700 hover:bg-gray-750 transition-colors">
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <h4 className="font-medium text-white mb-2">{doc.title}</h4>
                            <div className="flex items-center gap-3 mb-2">
                              <Badge className={getReferenceTypeColor(doc.relationship_type)}>
                                {doc.relationship_type}
                              </Badge>
                              <span className={`text-sm font-medium ${getConfidenceColor(doc.similarity_score)}`}>
                                {(doc.similarity_score * 100).toFixed(1)}% match
                              </span>
                            </div>
                            <p className="text-gray-400 text-sm mb-2">{doc.jurisdiction}</p>
                            <p className="text-gray-300 text-sm">{doc.connection_details}</p>
                          </div>
                          <Button
                            size="sm"
                            variant="outline"
                            className="ml-4 border-gray-600 text-gray-300 hover:bg-gray-700"
                            onClick={() => {
                              setCreateForm(prev => ({
                                ...prev,
                                targetDocumentId: doc.document_id.toString(),
                                referenceType: doc.relationship_type,
                                referenceText: doc.connection_details,
                                confidenceScore: doc.similarity_score
                              }));
                              setActiveTab('create');
                            }}
                          >
                            <ExternalLink className="h-4 w-4" />
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </TabsContent>

            <TabsContent value="references" className="space-y-4">
              {crossReferences.length === 0 ? (
                <Alert className="bg-gray-800 border-gray-700">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription className="text-gray-300">
                    No cross-references exist yet. Create them manually or use auto-analysis.
                  </AlertDescription>
                </Alert>
              ) : (
                <div className="grid gap-4">
                  {crossReferences.map((ref) => (
                    <Card key={ref.id} className="bg-gray-800 border-gray-700">
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <div className="flex items-center gap-3 mb-2">
                              <Badge className={getReferenceTypeColor(ref.reference_type)}>
                                {ref.reference_type}
                              </Badge>
                              <span className={`text-sm font-medium ${getConfidenceColor(ref.confidence_score)}`}>
                                {(ref.confidence_score * 100).toFixed(1)}% confidence
                              </span>
                            </div>
                            <p className="text-white font-medium mb-2">{ref.reference_text}</p>
                            {ref.context && (
                              <p className="text-gray-400 text-sm mb-2">{ref.context}</p>
                            )}
                            <p className="text-xs text-gray-500">
                              Created {new Date(ref.created_at).toLocaleDateString()}
                            </p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </TabsContent>

            <TabsContent value="create" className="space-y-6">
              <Card className="bg-gray-800 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white">Create New Cross-Reference</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-2">
                        Target Document ID *
                      </label>
                      <Input
                        value={createForm.targetDocumentId}
                        onChange={(e) => setCreateForm(prev => ({ ...prev, targetDocumentId: e.target.value }))}
                        placeholder="Enter document ID"
                        className="bg-gray-700 border-gray-600 text-white"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-2">
                        Reference Type
                      </label>
                      <select
                        value={createForm.referenceType}
                        onChange={(e) => setCreateForm(prev => ({ ...prev, referenceType: e.target.value }))}
                        className="w-full p-2 bg-gray-700 border border-gray-600 text-white rounded-md"
                      >
                        <option value="cites">Cites</option>
                        <option value="amends">Amends</option>
                        <option value="repeals">Repeals</option>
                        <option value="implements">Implements</option>
                        <option value="related">Related</option>
                      </select>
                    </div>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">
                      Reference Text *
                    </label>
                    <Textarea
                      value={createForm.referenceText}
                      onChange={(e) => setCreateForm(prev => ({ ...prev, referenceText: e.target.value }))}
                      placeholder="Enter the text that contains the reference"
                      className="bg-gray-700 border-gray-600 text-white"
                      rows={3}
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">
                      Context
                    </label>
                    <Textarea
                      value={createForm.context}
                      onChange={(e) => setCreateForm(prev => ({ ...prev, context: e.target.value }))}
                      placeholder="Additional context or surrounding text"
                      className="bg-gray-700 border-gray-600 text-white"
                      rows={2}
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">
                      Confidence Score: {createForm.confidenceScore}
                    </label>
                    <input
                      type="range"
                      min="0"
                      max="1"
                      step="0.1"
                      value={createForm.confidenceScore}
                      onChange={(e) => setCreateForm(prev => ({ ...prev, confidenceScore: parseFloat(e.target.value) }))}
                      className="w-full"
                    />
                  </div>
                  
                  <Button
                    onClick={createCrossReference}
                    className="w-full bg-blue-600 hover:bg-blue-700 text-white"
                  >
                    <Link className="mr-2 h-4 w-4" />
                    Create Cross-Reference
                  </Button>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="analysis" className="space-y-4">
              {analysisResult ? (
                <div className="space-y-4">
                  <Card className="bg-gray-800 border-gray-700">
                    <CardHeader>
                      <CardTitle className="text-white flex items-center gap-2">
                        <CheckCircle className="h-5 w-5 text-green-400" />
                        Analysis Complete
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                        <div className="bg-gray-700 p-3 rounded-lg">
                          <p className="text-2xl font-bold text-blue-400">{analysisResult.cross_references_found}</p>
                          <p className="text-sm text-gray-400">References Found</p>
                        </div>
                        <div className="bg-gray-700 p-3 rounded-lg">
                          <p className="text-2xl font-bold text-green-400">{analysisResult.cross_references_created}</p>
                          <p className="text-sm text-gray-400">Auto-Created</p>
                        </div>
                        <div className="bg-gray-700 p-3 rounded-lg">
                          <p className="text-2xl font-bold text-purple-400">{analysisResult.related_documents.length}</p>
                          <p className="text-sm text-gray-400">Related Docs</p>
                        </div>
                        <div className="bg-gray-700 p-3 rounded-lg">
                          <p className="text-2xl font-bold text-amber-400">{analysisResult.processing_time_seconds.toFixed(2)}s</p>
                          <p className="text-sm text-gray-400">Processing Time</p>
                        </div>
                      </div>
                      
                      {analysisResult.suggestions.length > 0 && (
                        <div className="mt-4">
                          <h4 className="text-white font-medium mb-2">Suggestions:</h4>
                          <ul className="space-y-1">
                            {analysisResult.suggestions.map((suggestion, index) => (
                              <li key={index} className="text-gray-300 text-sm">• {suggestion}</li>
                            ))}
                          </ul>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </div>
              ) : (
                <Alert className="bg-gray-800 border-gray-700">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription className="text-gray-300">
                    Run auto-analysis to see detailed results and suggestions.
                  </AlertDescription>
                </Alert>
              )}
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
};

export default CrossReferenceSystem;
