
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { Scale, Plus, Edit3, Trash2, Eye, FileIcon, Users, Target, BarChart3, CheckCircle2, Clock, AlertTriangle, HelpCircle, ListChecks, ToggleLeft } from 'lucide-react';
import { toast } from 'sonner';
import brain from 'brain';

interface Question {
  text: string;
  type: string;
  required: boolean;
  options?: string[];
  notes_enabled?: boolean;
}

interface Section {
  title: string;
  questions: Question[];
}

interface Template {
  id: number;
  title: string;
  description: string;
  how_it_works: string;
  sections: Section[];
  status: string;
  created_at: string;
  updated_at: string;
  created_by: string;
}

interface RiskAssessmentAdminProps {
  onRefresh?: () => void;
}

const RiskAssessmentAdmin: React.FC<RiskAssessmentAdminProps> = ({ onRefresh }) => {
  const [templates, setTemplates] = useState<Template[]>([]);
  const [selectedTemplate, setSelectedTemplate] = useState<Template | null>(null);
  const [loading, setLoading] = useState(true);
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [isEditOpen, setIsEditOpen] = useState(false);
  const [isViewOpen, setIsViewOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  
  // Form data for creating/editing templates
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    how_it_works: '',
    status: 'draft',
    sections: [] as Section[]
  });
  
  // New section form
  const [newSection, setNewSection] = useState<Section>({
    title: '',
    questions: []
  });
  
  // New question form
  const [newQuestion, setNewQuestion] = useState<Question>({
    text: '',
    type: 'text',
    required: false,
    options: [],
    notes_enabled: false
  });

  useEffect(() => {
    loadTemplates();
  }, []);

  const loadTemplates = async () => {
    try {
      setLoading(true);
      const response = await brain.list_templates();
      if (response.ok) {
        const data = await response.json();
        setTemplates(data.templates || []);
      } else {
        toast.error('Failed to load templates');
      }
    } catch (error) {
      console.error('Error loading templates:', error);
      toast.error('Failed to load templates');
    } finally {
      setLoading(false);
    }
  };

  const handleCreateTemplate = async () => {
    try {
      const response = await brain.create_template({
        title: formData.title,
        description: formData.description,
        how_it_works: formData.how_it_works,
        sections: formData.sections,
        status: formData.status
      });
      
      if (response.ok) {
        toast.success('Template created successfully');
        setIsCreateOpen(false);
        resetForm();
        loadTemplates();
      } else {
        toast.error('Failed to create template');
      }
    } catch (error) {
      console.error('Error creating template:', error);
      toast.error('Failed to create template');
    }
  };

  const handleUpdateTemplate = async () => {
    if (!selectedTemplate) return;
    
    try {
      const response = await brain.update_template(
        { templateId: selectedTemplate.id },
        {
          title: formData.title,
          description: formData.description,
          how_it_works: formData.how_it_works,
          sections: formData.sections,
          status: formData.status
        }
      );
      
      if (response.ok) {
        toast.success('Template updated successfully');
        setIsEditOpen(false);
        resetForm();
        loadTemplates();
      } else {
        toast.error('Failed to update template');
      }
    } catch (error) {
      console.error('Error updating template:', error);
      toast.error('Failed to update template');
    }
  };

  const handleDeleteTemplate = async (templateId: number, templateTitle: string) => {
    try {
      const response = await brain.delete_template({ templateId });
      if (response.ok) {
        toast.success(`Template "${templateTitle}" deleted successfully`);
        loadTemplates();
      } else {
        toast.error('Failed to delete template');
      }
    } catch (error) {
      console.error('Error deleting template:', error);
      toast.error('Failed to delete template');
    }
  };

  const handleViewTemplate = async (template: Template) => {
    try {
      const response = await brain.get_template({ templateId: template.id });
      if (response.ok) {
        const data = await response.json();
        setSelectedTemplate(data.template);
        setIsViewOpen(true);
      } else {
        toast.error('Failed to load template details');
      }
    } catch (error) {
      console.error('Error loading template:', error);
      toast.error('Failed to load template details');
    }
  };

  const openEditDialog = (template: Template) => {
    setSelectedTemplate(template);
    setFormData({
      title: template.title,
      description: template.description,
      how_it_works: template.how_it_works || '',
      status: template.status,
      sections: template.sections || []
    });
    setIsEditOpen(true);
  };

  const resetForm = () => {
    setFormData({
      title: '',
      description: '',
      how_it_works: '',
      status: 'draft',
      sections: []
    });
    setSelectedTemplate(null);
  };

  const addSection = () => {
    if (newSection.title.trim()) {
      setFormData(prev => ({
        ...prev,
        sections: [...prev.sections, { ...newSection }]
      }));
      setNewSection({ title: '', questions: [] });
    }
  };

  const removeSection = (index: number) => {
    setFormData(prev => ({
      ...prev,
      sections: prev.sections.filter((_, i) => i !== index)
    }));
  };

  const addQuestion = (sectionIndex: number) => {
    if (newQuestion.text.trim()) {
      const updatedSections = [...formData.sections];
      updatedSections[sectionIndex].questions.push({ ...newQuestion });
      setFormData(prev => ({ ...prev, sections: updatedSections }));
      setNewQuestion({
        text: '',
        type: 'text',
        required: false,
        options: [],
        notes_enabled: false
      });
    }
  };

  const removeQuestion = (sectionIndex: number, questionIndex: number) => {
    const updatedSections = [...formData.sections];
    updatedSections[sectionIndex].questions.splice(questionIndex, 1);
    setFormData(prev => ({ ...prev, sections: updatedSections }));
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'active':
        return <Badge className="bg-green-600 hover:bg-green-700"><CheckCircle2 className="w-3 h-3 mr-1" />Active</Badge>;
      case 'draft':
        return <Badge variant="secondary"><Clock className="w-3 h-3 mr-1" />Draft</Badge>;
      case 'archived':
        return <Badge variant="outline"><AlertTriangle className="w-3 h-3 mr-1" />Archived</Badge>;
      default:
        return <Badge>{status}</Badge>;
    }
  };

  const getQuestionTypeIcon = (type: string) => {
    switch (type) {
      case 'rating':
        return <BarChart3 className="w-4 h-4" />;
      case 'multiple_choice':
        return <Target className="w-4 h-4" />;
      case 'boolean':
        return <CheckCircle2 className="w-4 h-4" />;
      default:
        return <FileIcon className="w-4 h-4" />;
    }
  };

  const filteredTemplates = templates.filter(template => {
    const matchesSearch = template.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         template.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === 'all' || template.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-slate-100 flex items-center gap-2">
            <Scale className="h-6 w-6" />
            Risk Assessment Templates
          </h2>
          <p className="text-slate-400 mt-1">
            Manage and configure risk assessment templates for compliance evaluation
          </p>
        </div>
        <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
          <DialogTrigger asChild>
            <Button className="bg-purple-600 hover:bg-purple-700">
              <Plus className="w-4 h-4 mr-2" />
              Create Template
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-gray-800 border-gray-700 max-w-4xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Create New Template</DialogTitle>
              <DialogDescription>
                Create a new risk assessment template with custom sections and questions
              </DialogDescription>
            </DialogHeader>
            
            <div className="space-y-6">
              {/* Basic Info */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="title">Template Title</Label>
                  <Input
                    id="title"
                    value={formData.title}
                    onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
                    className="bg-gray-700 border-gray-600"
                    placeholder="Enter template title..."
                  />
                </div>
                <div>
                  <Label htmlFor="status">Status</Label>
                  <Select value={formData.status} onValueChange={(value) => setFormData(prev => ({ ...prev, status: value }))}>
                    <SelectTrigger className="bg-gray-700 border-gray-600">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="draft">Draft</SelectItem>
                      <SelectItem value="active">Active</SelectItem>
                      <SelectItem value="archived">Archived</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div>
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                  className="bg-gray-700 border-gray-600"
                  placeholder="Describe the purpose and scope of this template..."
                  rows={3}
                />
              </div>
              
              <div>
                <Label htmlFor="how_it_works">How It Works</Label>
                <Textarea
                  id="how_it_works"
                  value={formData.how_it_works}
                  onChange={(e) => setFormData(prev => ({ ...prev, how_it_works: e.target.value }))}
                  className="bg-gray-700 border-gray-600"
                  placeholder="Explain how this template should be used..."
                  rows={3}
                />
              </div>

              {/* Sections */}
              <div>
                <Label className="text-lg font-semibold">Template Sections</Label>
                <div className="space-y-4 mt-2">
                  {formData.sections.map((section, sectionIndex) => (
                    <Card key={sectionIndex} className="bg-gray-700 border-gray-600">
                      <CardHeader className="pb-3">
                        <div className="flex items-center justify-between">
                          <CardTitle className="text-lg">{section.title}</CardTitle>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => removeSection(sectionIndex)}
                            className="text-red-400 hover:text-red-300 hover:bg-red-900/20"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-2">
                          {section.questions.map((question, questionIndex) => (
                            <div key={questionIndex} className="flex items-center justify-between p-3 bg-gray-800 rounded border border-gray-600">
                              <div className="flex items-center gap-3">
                                {getQuestionTypeIcon(question.type)}
                                <div>
                                  <p className="text-sm font-medium">{question.text}</p>
                                  <p className="text-xs text-gray-400">Type: {question.type} | Required: {question.required ? 'Yes' : 'No'}</p>
                                </div>
                              </div>
                              <Button
                                size="sm"
                                variant="ghost"
                                onClick={() => removeQuestion(sectionIndex, questionIndex)}
                                className="text-red-400 hover:text-red-300 hover:bg-red-900/20"
                              >
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </div>
                          ))}
                          
                          {/* Add Question Form */}
                          <div className="grid grid-cols-4 gap-2 p-3 bg-gray-800 rounded border border-gray-600">
                            <Input
                              placeholder="Question text..."
                              value={newQuestion.text}
                              onChange={(e) => setNewQuestion(prev => ({ ...prev, text: e.target.value }))}
                              className="col-span-2 bg-gray-700 border-gray-500"
                            />
                            <Select value={newQuestion.type} onValueChange={(value) => setNewQuestion(prev => ({ ...prev, type: value }))}>
                              <SelectTrigger className="bg-gray-700 border-gray-500">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="text">Text</SelectItem>
                                <SelectItem value="rating">Rating</SelectItem>
                                <SelectItem value="multiple_choice">Multiple Choice</SelectItem>
                                <SelectItem value="boolean">Yes/No</SelectItem>
                              </SelectContent>
                            </Select>
                            <Button
                              size="sm"
                              onClick={() => addQuestion(sectionIndex)}
                              disabled={!newQuestion.text.trim()}
                              className="bg-purple-600 hover:bg-purple-700"
                            >
                              Add
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                  
                  {/* Add Section Form */}
                  <div className="flex gap-2">
                    <Input
                      placeholder="Section title..."
                      value={newSection.title}
                      onChange={(e) => setNewSection(prev => ({ ...prev, title: e.target.value }))}
                      className="bg-gray-700 border-gray-600"
                    />
                    <Button
                      onClick={addSection}
                      disabled={!newSection.title.trim()}
                      className="bg-purple-600 hover:bg-purple-700"
                    >
                      Add Section
                    </Button>
                  </div>
                </div>
              </div>
              
              <div className="flex justify-end gap-2 pt-4">
                <Button variant="outline" onClick={() => setIsCreateOpen(false)}>
                  Cancel
                </Button>
                <Button onClick={handleCreateTemplate} className="bg-purple-600 hover:bg-purple-700">
                  Create Template
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Filters */}
      <div className="flex gap-4 items-center">
        <Input
          placeholder="Search templates..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="max-w-md bg-gray-800 border-gray-600"
        />
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-40 bg-gray-800 border-gray-600">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Status</SelectItem>
            <SelectItem value="active">Active</SelectItem>
            <SelectItem value="draft">Draft</SelectItem>
            <SelectItem value="archived">Archived</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Templates List */}
      <Card className="bg-gray-800 border-gray-700">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileIcon className="h-5 w-5" />
            Templates ({filteredTemplates.length})
          </CardTitle>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="text-center py-8 text-gray-400">
              <Scale className="h-12 w-12 mx-auto mb-4 opacity-50 animate-pulse" />
              <p>Loading templates...</p>
            </div>
          ) : filteredTemplates.length === 0 ? (
            <div className="text-center py-8 text-gray-400">
              <Scale className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p>No templates found</p>
              <p className="text-sm mt-2">
                {searchQuery || statusFilter !== 'all' ? 'Try adjusting your filters' : 'Create your first template to get started'}
              </p>
            </div>
          ) : (
            <div className="grid gap-4">
              {filteredTemplates.map((template) => (
                <div key={template.id} className="flex items-center justify-between p-4 bg-gray-700 rounded-lg border border-gray-600">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <h3 className="font-semibold text-slate-100">{template.title}</h3>
                      {getStatusBadge(template.status)}
                      <Badge variant="outline" className="text-xs">
                        {template.sections?.length || 0} sections
                      </Badge>
                    </div>
                    <p className="text-sm text-slate-400 mb-2">{template.description}</p>
                    <div className="flex items-center gap-4 text-xs text-slate-500">
                      <span>Created: {new Date(template.created_at).toLocaleDateString()}</span>
                      {template.updated_at && (
                        <span>Updated: {new Date(template.updated_at).toLocaleDateString()}</span>
                      )}
                      <span>ID: {template.id}</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleViewTemplate(template)}
                      className="h-8 w-8 p-0 border-gray-600 hover:bg-gray-600"
                    >
                      <Eye className="h-4 w-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => openEditDialog(template)}
                      className="h-8 w-8 p-0 border-gray-600 hover:bg-gray-600"
                    >
                      <Edit3 className="h-4 w-4" />
                    </Button>
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button
                          size="sm"
                          variant="outline"
                          className="h-8 w-8 p-0 border-red-600 text-red-400 hover:bg-red-900/20"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent className="bg-gray-800 border-gray-700">
                        <AlertDialogHeader>
                          <AlertDialogTitle>Delete Template</AlertDialogTitle>
                          <AlertDialogDescription>
                            Are you sure you want to delete "{template.title}"? This action cannot be undone.
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel className="bg-gray-700 border-gray-600 hover:bg-gray-600">
                            Cancel
                          </AlertDialogCancel>
                          <AlertDialogAction 
                            onClick={() => handleDeleteTemplate(template.id, template.title)}
                            className="bg-red-600 hover:bg-red-700"
                          >
                            Delete
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* View Template Dialog */}
      <Dialog open={isViewOpen} onOpenChange={setIsViewOpen}>
        <DialogContent className="bg-gray-800 border-gray-700 max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Scale className="h-5 w-5" />
              {selectedTemplate?.title}
            </DialogTitle>
            <DialogDescription>
              Template Details and Structure
            </DialogDescription>
          </DialogHeader>
          
          {selectedTemplate && (
            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-sm font-medium text-slate-300">Status</Label>
                  <div className="mt-1">{getStatusBadge(selectedTemplate.status)}</div>
                </div>
                <div>
                  <Label className="text-sm font-medium text-slate-300">Sections</Label>
                  <p className="mt-1 text-slate-100">{selectedTemplate.sections?.length || 0} sections</p>
                </div>
              </div>
              
              <div>
                <Label className="text-sm font-medium text-slate-300">Description</Label>
                <p className="mt-1 text-slate-100">{selectedTemplate.description}</p>
              </div>
              
              {selectedTemplate.how_it_works && (
                <div>
                  <Label className="text-sm font-medium text-slate-300">How It Works</Label>
                  <p className="mt-1 text-slate-100">{selectedTemplate.how_it_works}</p>
                </div>
              )}
              
              <div>
                <Label className="text-sm font-medium text-slate-300">Template Structure</Label>
                <div className="mt-2 space-y-3">
                  {selectedTemplate.sections?.map((section, index) => (
                    <Card key={index} className="bg-gray-700 border-gray-600">
                      <CardHeader className="pb-3">
                        <CardTitle className="text-lg flex items-center gap-2">
                          <Users className="h-4 w-4" />
                          {section.title}
                          <Badge variant="outline" className="text-xs">
                            {section.questions?.length || 0} questions
                          </Badge>
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-2">
                          {section.questions?.map((question, qIndex) => (
                            <div key={qIndex} className="flex items-center gap-3 p-2 bg-gray-800 rounded border border-gray-600">
                              {getQuestionTypeIcon(question.type)}
                              <div className="flex-1">
                                <p className="text-sm font-medium">{question.text}</p>
                                <div className="flex items-center gap-2 text-xs text-gray-400 mt-1">
                                  <span>Type: {question.type}</span>
                                  <span>•</span>
                                  <span>{question.required ? 'Required' : 'Optional'}</span>
                                  {question.notes_enabled && (
                                    <>
                                      <span>•</span>
                                      <span>Notes enabled</span>
                                    </>
                                  )}
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
              
              <div className="flex justify-end">
                <Button variant="outline" onClick={() => setIsViewOpen(false)}>
                  Close
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Edit Template Dialog */}
      <Dialog open={isEditOpen} onOpenChange={setIsEditOpen}>
        <DialogContent className="bg-gray-800 border-gray-700 max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Edit Template</DialogTitle>
            <DialogDescription>
              Modify the template configuration and structure
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-6">
            {/* Basic Info - Similar to create form */}
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="edit-title">Template Title</Label>
                <Input
                  id="edit-title"
                  value={formData.title}
                  onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
                  className="bg-gray-700 border-gray-600"
                />
              </div>
              <div>
                <Label htmlFor="edit-status">Status</Label>
                <Select value={formData.status} onValueChange={(value) => setFormData(prev => ({ ...prev, status: value }))}>
                  <SelectTrigger className="bg-gray-700 border-gray-600">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="draft">Draft</SelectItem>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="archived">Archived</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <div>
              <Label htmlFor="edit-description">Description</Label>
              <Textarea
                id="edit-description"
                value={formData.description}
                onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                className="bg-gray-700 border-gray-600"
                rows={3}
              />
            </div>
            
            <div>
              <Label htmlFor="edit-how-it-works">How It Works</Label>
              <Textarea
                id="edit-how-it-works"
                value={formData.how_it_works}
                onChange={(e) => setFormData(prev => ({ ...prev, how_it_works: e.target.value }))}
                className="bg-gray-700 border-gray-600"
                rows={3}
              />
            </div>
            
            <div className="flex justify-end gap-2 pt-4">
              <Button variant="outline" onClick={() => { setIsEditOpen(false); resetForm(); }}>
                Cancel
              </Button>
              <Button onClick={handleUpdateTemplate} className="bg-purple-600 hover:bg-purple-700">
                Update Template
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default RiskAssessmentAdmin;
