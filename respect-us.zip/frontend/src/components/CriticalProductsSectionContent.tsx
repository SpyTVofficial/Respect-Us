


import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { AlertCircle, BookOpen } from 'lucide-react';
import brain from 'brain';

interface SectionContentData {
  id: number | null;
  section_type: string;
  title: string;
  content: string;
  metadata: Record<string, any>;
  created_at: string | null;
  updated_at: string | null;
  has_content: boolean;
}

interface Props {
  sectionType: 'trade-codes' | 'measures' | 'restrictions' | 'jurisdictions' | 'product-classification';
  className?: string;
}

export const CriticalProductsSectionContent: React.FC<Props> = ({ sectionType, className = '' }) => {
  const [content, setContent] = useState<SectionContentData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const loadSectionContent = async () => {
      try {
        setLoading(true);
        setError(null);
        
        const response = await brain.get_critical_products_section_content({ sectionType });
        
        if (response.ok) {
          const data = await response.json();
          setContent(data);
        } else {
          throw new Error('Failed to load section content');
        }
      } catch (error) {
        console.error('Error loading section content:', error);
        setError('Failed to load explanatory content');
        
        // Set fallback content
        const fallbackContent: Record<string, { title: string; content: string }> = {
          'trade-codes': {
            title: 'Understanding Trade Codes',
            content: 'Trade codes are standardized numerical identifiers used to classify products for international trade and regulatory purposes. They help determine applicable export controls, licensing requirements, and compliance obligations.'
          },
          'measures': {
            title: 'Regulatory Measures Overview',
            content: 'Regulatory measures are specific controls, restrictions, or requirements imposed on products or technologies. These can include export licenses, end-use restrictions, or complete prohibitions depending on the destination and intended use.'
          },
          'restrictions': {
            title: 'Product Restrictions Guide',
            content: 'Product restrictions define limitations on the export, re-export, or transfer of specific items. Understanding these restrictions is crucial for compliance with export control regulations and avoiding violations.'
          },
          'jurisdictions': {
            title: 'Regulatory Jurisdictions',
            content: 'Different regulatory jurisdictions have varying export control frameworks. Understanding which jurisdiction\'s rules apply to your transactions is essential for proper compliance assessment.'
          }
        };
        
        const fallback = fallbackContent[sectionType];
        setContent({
          id: null,
          section_type: sectionType,
          title: fallback.title,
          content: fallback.content,
          metadata: {},
          created_at: null,
          updated_at: null,
          has_content: false
        });
      } finally {
        setLoading(false);
      }
    };

    loadSectionContent();
  }, [sectionType]);

  if (loading) {
    return (
      <Card className={`bg-gradient-to-br from-blue-900/20 to-blue-800/10 border-blue-500/30 backdrop-blur ${className}`}>
        <CardHeader>
          <Skeleton className="h-6 w-48" />
        </CardHeader>
        <CardContent>
          <Skeleton className="h-4 w-full mb-2" />
          <Skeleton className="h-4 w-5/6 mb-2" />
          <Skeleton className="h-4 w-4/5" />
        </CardContent>
      </Card>
    );
  }

  if (error && !content) {
    return (
      <Card className={`bg-red-900/20 border-red-500/30 backdrop-blur ${className}`}>
        <CardContent className="p-6 text-center">
          <AlertCircle className="h-8 w-8 text-red-400 mx-auto mb-4" />
          <p className="text-red-300">Unable to load explanatory content</p>
        </CardContent>
      </Card>
    );
  }

  if (!content) {
    return null;
  }

  return (
    <Card className={`bg-gradient-to-br from-blue-900/20 to-blue-800/10 border-blue-500/30 backdrop-blur ${className}`}>
      <CardHeader>
        <CardTitle className="text-white flex items-center gap-2">
          <BookOpen className="h-5 w-5 text-blue-400" />
          {content.title}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="prose prose-invert max-w-none">
          <p className="text-gray-300 leading-relaxed">
            {content.content}
          </p>
          
          {!content.has_content && (
            <div className="mt-4 text-xs text-blue-400/70 italic">
              This content can be customized through the Admin Dashboard CMS.
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default CriticalProductsSectionContent;
