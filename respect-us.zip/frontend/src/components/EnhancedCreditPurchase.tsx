
import React, { useState, useEffect } from 'react';
import { Coins, CreditCard, Check, X, Loader2, Star, Gift, Shield, Zap, TrendingUp, AlertTriangle } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Separator } from '@/components/ui/separator';
import { Progress } from '@/components/ui/progress';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { useUserGuardContext } from 'app/auth';
import { useCreditBalance } from 'utils/useCreditBalance';
import brain from 'brain';
import { toast } from 'sonner';

interface CreditPackage {
  id: number;
  name: string;
  credits: number;
  price_cents: number;
  currency: string;
  discount_percentage: number;
  is_active: boolean;
  expiry_months: number;
}

interface AutoRechargeConfig {
  enabled: boolean;
  threshold: number;
  package_id: number;
}

interface UsageProjection {
  daily_average: number;
  weekly_projection: number;
  monthly_projection: number;
  estimated_runtime_days: number;
}

interface Props {
  onPurchaseComplete?: () => void;
  showAutoRecharge?: boolean;
  compactMode?: boolean;
}

export default function EnhancedCreditPurchase({ 
  onPurchaseComplete, 
  showAutoRecharge = true,
  compactMode = false 
}: Props) {
  const { user } = useUserGuardContext();
  const { balance, refreshBalance } = useCreditBalance();
  const [packages, setPackages] = useState<CreditPackage[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedPackage, setSelectedPackage] = useState<CreditPackage | null>(null);
  const [autoRecharge, setAutoRecharge] = useState<AutoRechargeConfig>({
    enabled: false,
    threshold: 100,
    package_id: 0
  });
  const [usageProjection, setUsageProjection] = useState<UsageProjection | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [paymentStatus, setPaymentStatus] = useState<'idle' | 'processing' | 'success' | 'error'>('idle');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [showFreeTier, setShowFreeTier] = useState(false);

  useEffect(() => {
    fetchCreditPackages();
    checkFreeTierEligibility();
    fetchUsageProjection();
  }, []);

  const fetchCreditPackages = async () => {
    try {
      setIsLoading(true);
      const response = await brain.get_credit_packages();
      const data = await response.json();
      setPackages(data);
      
      // Set default auto-recharge package to smallest one
      if (data.length > 0) {
        setAutoRecharge(prev => ({ ...prev, package_id: data[0].id }));
      }
    } catch (error) {
      console.error('Failed to fetch credit packages:', error);
      toast.error('Failed to load credit packages');
    } finally {
      setIsLoading(false);
    }
  };

  const checkFreeTierEligibility = async () => {
    try {
      const response = await brain.check_free_tier_eligibility();
      const data = await response.json();
      setShowFreeTier(data.eligible);
    } catch (error) {
      console.error('Failed to check free tier eligibility:', error);
    }
  };

  const fetchUsageProjection = async () => {
    try {
      const response = await brain.get_user_usage_analytics({ days: 30 });
      const data = await response.json();
      
      // Calculate usage projections
      const dailyAverage = data.total_consumed / 30;
      const weeklyProjection = dailyAverage * 7;
      const monthlyProjection = dailyAverage * 30;
      const estimatedRuntime = balance ? Math.floor(balance.current_balance / dailyAverage) : 0;
      
      setUsageProjection({
        daily_average: dailyAverage,
        weekly_projection: weeklyProjection,
        monthly_projection: monthlyProjection,
        estimated_runtime_days: estimatedRuntime
      });
    } catch (error) {
      console.error('Failed to fetch usage projection:', error);
    }
  };

  const activateFreeTier = async () => {
    try {
      setIsProcessing(true);
      const response = await brain.activate_free_tier();
      const data = await response.json();
      
      if (data.success) {
        toast.success(`Welcome! ${data.credits_awarded} free credits added to your account.`);
        refreshBalance();
        setShowFreeTier(false);
        onPurchaseComplete?.();
      }
    } catch (error) {
      console.error('Failed to activate free tier:', error);
      toast.error('Failed to activate free credits');
    } finally {
      setIsProcessing(false);
    }
  };

  const processPurchase = async () => {
    if (!selectedPackage) return;

    try {
      setIsProcessing(true);
      setPaymentStatus('processing');
      
      // Create payment intent
      const paymentResponse = await brain.create_payment_intent({
        package_id: selectedPackage.id,
        credits: selectedPackage.credits,
        amount_cents: selectedPackage.price_cents
      });
      
      const paymentData = await paymentResponse.json();
      
      if (paymentData.success) {
        // Simulate payment processing
        await new Promise(resolve => setTimeout(resolve, 2000));
        
        // Process the credit purchase
        const purchaseResponse = await brain.admin_adjust_credits({
          user_id: user.sub,
          amount: selectedPackage.credits,
          reason: `Credit package purchase: ${selectedPackage.name}`
        });
        
        const purchaseResult = await purchaseResponse.json();
        
        if (purchaseResult.success) {
          // Set up auto-recharge if enabled
          if (autoRecharge.enabled) {
            await brain.configure_auto_recharge({
              threshold: autoRecharge.threshold,
              package_id: autoRecharge.package_id,
              enabled: true
            });
          }
          
          setPaymentStatus('success');
          toast.success(`Successfully purchased ${selectedPackage.credits.toLocaleString()} credits!`);
          refreshBalance();
          onPurchaseComplete?.();
          
          // Reset after success
          setTimeout(() => {
            setSelectedPackage(null);
            setPaymentStatus('idle');
            setErrorMessage(null);
          }, 3000);
        } else {
          throw new Error('Failed to process credit purchase');
        }
      } else {
        throw new Error(paymentData.message || 'Payment failed');
      }
    } catch (error) {
      console.error('Purchase failed:', error);
      setPaymentStatus('error');
      setErrorMessage(error instanceof Error ? error.message : 'Purchase failed');
      toast.error('Purchase failed. Please try again.');
    } finally {
      setIsProcessing(false);
    }
  };

  const formatPrice = (priceInCents: number, currency: string) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: currency,
      minimumFractionDigits: 2
    }).format(priceInCents / 100);
  };

  const formatPriceWithVATNotice = (priceInCents: number, currency: string) => {
    const basePrice = new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: currency,
      minimumFractionDigits: 2
    }).format(priceInCents / 100);
    return `${basePrice} + VAT if applicable`;
  };

  const calculateValuePerCredit = (priceInCents: number, credits: number) => {
    return (priceInCents / 100 / credits).toFixed(4);
  };

  const getMostPopularIndex = () => {
    return Math.floor(packages.length / 2);
  };

  const getRuntimeIndicator = (credits: number) => {
    if (!usageProjection || usageProjection.daily_average === 0) return null;
    
    const estimatedDays = Math.floor(credits / usageProjection.daily_average);
    const estimatedWeeks = Math.floor(estimatedDays / 7);
    
    if (estimatedWeeks > 4) {
      return `~${Math.floor(estimatedWeeks / 4)} months runtime`;
    } else if (estimatedWeeks > 0) {
      return `~${estimatedWeeks} weeks runtime`;
    } else {
      return `~${estimatedDays} days runtime`;
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="text-center">
          <Loader2 className="w-8 h-8 animate-spin text-blue-400 mx-auto mb-4" />
          <p className="text-gray-400">Loading credit packages...</p>
        </div>
      </div>
    );
  }

  return (
    <div className={`space-y-6 ${compactMode ? 'max-w-4xl' : 'max-w-6xl'} mx-auto`}>
      {/* Header */}
      {!compactMode && (
        <div className="text-center space-y-4">
          <h1 className="text-4xl font-bold text-white">Purchase Credits</h1>
          <p className="text-xl text-gray-400 max-w-2xl mx-auto">
            Power your compliance workflows with our flexible credit system. 
            Pay only for what you use, when you use it.
          </p>
          
          {balance && (
            <div className="inline-flex items-center space-x-2 bg-gray-800 px-4 py-2 rounded-lg">
              <Coins className="w-5 h-5 text-purple-400" />
              <span className="text-gray-300">Current Balance:</span>
              <span className="font-bold text-purple-400">{balance.current_balance.toLocaleString()}</span>
              <span className="text-gray-400">credits</span>
            </div>
          )}
        </div>
      )}

      {/* Free Tier Offer */}
      {showFreeTier && (
        <Alert className="bg-gradient-to-r from-purple-900/20 to-blue-900/20 border-purple-500/30">
          <Gift className="w-4 h-4" />
          <AlertDescription className="text-purple-300">
            <div className="flex items-center justify-between">
              <div>
                <strong>Welcome!</strong> Get 100 free credits to explore all compliance modules.
              </div>
              <Button 
                size="sm" 
                className="bg-purple-600 hover:bg-purple-700"
                onClick={activateFreeTier}
                disabled={isProcessing}
              >
                {isProcessing ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <>Claim Free Credits</>
                )}
              </Button>
            </div>
          </AlertDescription>
        </Alert>
      )}

      {/* Usage Projection */}
      {usageProjection && balance && (
        <Card className="bg-gray-900 border-gray-800">
          <CardHeader>
            <CardTitle className="text-white flex items-center space-x-2">
              <TrendingUp className="w-5 h-5" />
              <span>Usage Insights</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-blue-400">
                  {usageProjection.daily_average.toFixed(1)}
                </div>
                <div className="text-sm text-gray-400">Credits/day</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-green-400">
                  {usageProjection.monthly_projection.toFixed(0)}
                </div>
                <div className="text-sm text-gray-400">Projected monthly</div>
              </div>
              <div className="text-center">
                <div className={`text-2xl font-bold ${
                  usageProjection.estimated_runtime_days < 7 ? 'text-red-400' :
                  usageProjection.estimated_runtime_days < 30 ? 'text-yellow-400' :
                  'text-green-400'
                }`}>
                  {usageProjection.estimated_runtime_days}
                </div>
                <div className="text-sm text-gray-400">Days remaining</div>
              </div>
            </div>
            
            {usageProjection.estimated_runtime_days < 7 && (
              <Alert className="bg-red-900/20 border-red-500/30">
                <AlertTriangle className="w-4 h-4" />
                <AlertDescription className="text-red-300">
                  Low credit balance! Consider purchasing more credits to avoid workflow interruptions.
                </AlertDescription>
              </Alert>
            )}
          </CardContent>
        </Card>
      )}

      {/* Payment Status */}
      {paymentStatus === 'processing' && (
        <Alert className="bg-blue-900/20 border-blue-500/30">
          <Loader2 className="w-4 h-4 animate-spin" />
          <AlertDescription className="text-blue-300">
            Processing your payment... Please wait.
          </AlertDescription>
        </Alert>
      )}
      
      {paymentStatus === 'success' && (
        <Alert className="bg-green-900/20 border-green-500/30">
          <Check className="w-4 h-4" />
          <AlertDescription className="text-green-300">
            Payment successful! Your credits have been added to your account.
          </AlertDescription>
        </Alert>
      )}
      
      {paymentStatus === 'error' && (
        <Alert className="bg-red-900/20 border-red-500/30">
          <X className="w-4 h-4" />
          <AlertDescription className="text-red-300">
            {errorMessage}
          </AlertDescription>
        </Alert>
      )}

      {/* Credit Packages */}
      <div className={`grid gap-6 ${
        compactMode ? 'grid-cols-1 md:grid-cols-2' : 'grid-cols-1 md:grid-cols-2 lg:grid-cols-3'
      }`}>
        {packages.map((pkg, index) => {
          const isSelected = selectedPackage?.id === pkg.id;
          const isMostPopular = index === getMostPopularIndex();
          const pricePerCredit = calculateValuePerCredit(pkg.price_cents, pkg.credits);
          const runtimeEstimate = getRuntimeIndicator(pkg.credits);
          
          return (
            <Card 
              key={pkg.id} 
              className={`relative transition-all duration-300 cursor-pointer ${
                isSelected 
                  ? 'bg-purple-900/30 border-purple-500 ring-2 ring-purple-500/50' 
                  : 'bg-gray-900 border-gray-800 hover:border-gray-700'
              } ${isMostPopular ? 'ring-2 ring-yellow-500/50' : ''}`}
              onClick={() => setSelectedPackage(pkg)}
            >
              {isMostPopular && (
                <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                  <Badge className="bg-yellow-500 text-black font-medium px-3 py-1">
                    <Star className="w-3 h-3 mr-1" />
                    Most Popular
                  </Badge>
                </div>
              )}
              
              <CardHeader className="text-center pb-4">
                <CardTitle className="text-xl font-bold text-white">{pkg.name}</CardTitle>
                
                <div className="space-y-2">
                  <div className="text-3xl font-bold text-purple-400">
                    {pkg.credits.toLocaleString()}
                    <span className="text-sm text-gray-400 font-normal ml-1">credits</span>
                  </div>
                  
                  <div className="text-2xl font-bold text-white">
                    {formatPriceWithVATNotice(pkg.price_cents, pkg.currency)}
                  </div>
                  
                  <div className="text-sm text-gray-400">
                    {formatPrice(Number.parseFloat(pricePerCredit) * 100, pkg.currency)} per credit + VAT if applicable
                  </div>
                  
                  {runtimeEstimate && (
                    <div className="text-sm text-blue-400 font-medium">
                      {runtimeEstimate}
                    </div>
                  )}
                </div>
                
                {pkg.discount_percentage > 0 && (
                  <Badge className="bg-green-500/20 text-green-400 border-green-500/30">
                    <Gift className="w-3 h-3 mr-1" />
                    {pkg.discount_percentage}% OFF
                  </Badge>
                )}
              </CardHeader>
              
              <CardContent className="space-y-4">
                <Separator className="bg-gray-700" />
                
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between text-gray-300">
                    <span>Credits:</span>
                    <span className="font-medium">{pkg.credits.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between text-gray-300">
                    <span>Valid for:</span>
                    <span className="font-medium">{pkg.expiry_months} months</span>
                  </div>
                  <div className="flex justify-between text-gray-300">
                    <span>Value per credit:</span>
                    <span className="font-medium">{formatPrice(Number.parseFloat(pricePerCredit) * 100, pkg.currency)} + VAT if applicable</span>
                  </div>
                </div>
                
                <Button 
                  className={`w-full transition-all duration-300 ${
                    isSelected 
                      ? 'bg-purple-600 hover:bg-purple-700 text-white' 
                      : 'bg-gray-800 hover:bg-gray-700 text-gray-300'
                  }`}
                  onClick={(e) => {
                    e.stopPropagation();
                    setSelectedPackage(pkg);
                  }}
                >
                  {isSelected ? (
                    <>
                      <Check className="w-4 h-4 mr-2" />
                      Selected
                    </>
                  ) : (
                    'Select Package'
                  )}
                </Button>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Auto-Recharge Configuration */}
      {showAutoRecharge && selectedPackage && (
        <Card className="bg-gray-900 border-gray-800">
          <CardHeader>
            <CardTitle className="text-white flex items-center space-x-2">
              <Zap className="w-5 h-5" />
              <span>Auto-Recharge (Optional)</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center space-x-2">
              <Switch 
                checked={autoRecharge.enabled}
                onCheckedChange={(enabled) => setAutoRecharge(prev => ({ ...prev, enabled }))}
              />
              <Label className="text-gray-300">
                Automatically purchase credits when balance is low
              </Label>
            </div>
            
            {autoRecharge.enabled && (
              <div className="space-y-4 pl-6 border-l-2 border-purple-500/30">
                <div>
                  <Label className="text-gray-300">Recharge when balance drops below:</Label>
                  <Input 
                    type="number"
                    value={autoRecharge.threshold}
                    onChange={(e) => setAutoRecharge(prev => ({ 
                      ...prev, 
                      threshold: Number.parseInt(e.target.value) || 0 
                    }))}
                    className="mt-1 bg-gray-800 border-gray-700 text-white"
                  />
                </div>
                
                <div>
                  <Label className="text-gray-300">Auto-purchase package:</Label>
                  <select 
                    value={autoRecharge.package_id}
                    onChange={(e) => setAutoRecharge(prev => ({ 
                      ...prev, 
                      package_id: Number.parseInt(e.target.value) 
                    }))}
                    className="mt-1 w-full p-2 bg-gray-800 border border-gray-700 rounded text-white"
                  >
                    {packages.map(pkg => (
                      <option key={pkg.id} value={pkg.id}>
                        {pkg.name} - {pkg.credits.toLocaleString()} credits
                      </option>
                    ))}
                  </select>
                </div>
                
                <Alert className="bg-blue-900/20 border-blue-500/30">
                  <Shield className="w-4 h-4" />
                  <AlertDescription className="text-blue-300">
                    Auto-recharge ensures uninterrupted access to compliance tools. 
                    You can disable this anytime in your account settings.
                  </AlertDescription>
                </Alert>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Purchase Action */}
      {selectedPackage && (
        <Card className="bg-gray-900 border-gray-800">
          <CardHeader>
            <CardTitle className="text-white flex items-center space-x-2">
              <CreditCard className="w-5 h-5" />
              <span>Complete Purchase</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="bg-gray-800 p-4 rounded-lg space-y-2">
              <div className="flex justify-between items-center">
                <span className="text-gray-300">Package:</span>
                <span className="font-medium text-white">{selectedPackage.name}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-300">Credits:</span>
                <span className="font-medium text-purple-400">
                  {selectedPackage.credits.toLocaleString()}
                </span>
              </div>
              {autoRecharge.enabled && (
                <div className="flex justify-between items-center">
                  <span className="text-gray-300">Auto-recharge:</span>
                  <span className="font-medium text-blue-400">Enabled</span>
                </div>
              )}
              <Separator className="bg-gray-700" />
              <div className="flex justify-between items-center text-lg">
                <span className="text-gray-300">Total:</span>
                <span className="font-bold text-white">
                  {formatPriceWithVATNotice(selectedPackage.price_cents, selectedPackage.currency)}
                </span>
              </div>
            </div>
            
            <div className="flex space-x-4">
              <Button 
                variant="outline" 
                className="flex-1 border-gray-700 text-gray-300 hover:bg-gray-800"
                onClick={() => setSelectedPackage(null)}
                disabled={isProcessing}
              >
                Cancel
              </Button>
              <Button 
                className="flex-1 bg-purple-600 hover:bg-purple-700"
                onClick={processPurchase}
                disabled={isProcessing || paymentStatus === 'processing'}
              >
                {isProcessing ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Processing...
                  </>
                ) : (
                  <>
                    <CreditCard className="w-4 h-4 mr-2" />
                    Purchase Credits
                  </>
                )}
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
      
      {/* Help Text */}
      <div className="text-center text-gray-400 text-sm space-y-2">
        <p>Credits never expire and can be used across all compliance modules.</p>
        <p>Secure payment processing powered by Stripe. Your data is protected.</p>
      </div>
    </div>
  );
}
