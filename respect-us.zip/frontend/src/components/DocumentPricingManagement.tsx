
import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Checkbox } from '@/components/ui/checkbox';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { DollarSign, Edit, Trash2, Plus, Search, Filter, Download, TrendingUp, FileText, CreditCard } from 'lucide-react';
import { toast } from 'sonner';
import brain from 'brain';
import type { DocumentPricingResponse, BulkPricingUpdate, DocumentPricingStats } from 'brain/data-contracts';

interface DocumentPricingManagementProps {
  onRefresh?: () => void;
}

export default function DocumentPricingManagement({ onRefresh }: DocumentPricingManagementProps) {
  const [documents, setDocuments] = useState<DocumentPricingResponse[]>([]);
  const [stats, setStats] = useState<DocumentPricingStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [pricingFilter, setPricingFilter] = useState<string>('all');
  const [tierFilter, setTierFilter] = useState<string>('all');
  const [selectedDocuments, setSelectedDocuments] = useState<number[]>([]);
  const [showBulkUpdate, setShowBulkUpdate] = useState(false);
  const [editingDocument, setEditingDocument] = useState<DocumentPricingResponse | null>(null);
  const [showEditDialog, setShowEditDialog] = useState(false);
  
  // Form states
  const [editForm, setEditForm] = useState({
    credit_cost: null as number | null,
    is_premium: false,
    pricing_tier: 'free'
  });
  
  const [bulkForm, setBulkForm] = useState({
    credit_cost: null as number | null,
    is_premium: false,
    pricing_tier: 'free'
  });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      setLoading(true);
      
      const [docsResponse, statsResponse] = await Promise.all([
        brain.get_document_pricing({ page: 1, limit: 100 }),
        brain.get_document_pricing_stats()
      ]);
      
      if (docsResponse.ok) {
        const docsData = await docsResponse.json();
        setDocuments(Array.isArray(docsData) ? docsData : []);
      }
      
      if (statsResponse.ok) {
        const statsData = await statsResponse.json();
        setStats(statsData);
      }
      
    } catch (error) {
      console.error('Error loading document pricing data:', error);
      toast.error('Failed to load document pricing data');
    } finally {
      setLoading(false);
    }
  };

  const handleEditDocument = (document: DocumentPricingResponse) => {
    setEditingDocument(document);
    setEditForm({
      credit_cost: document.credit_cost,
      is_premium: document.is_premium,
      pricing_tier: document.pricing_tier
    });
    setShowEditDialog(true);
  };

  const handleUpdatePricing = async () => {
    if (!editingDocument) return;
    
    try {
      const response = await brain.update_document_pricing(editingDocument.id, editForm);
      
      if (response.ok) {
        toast.success('Document pricing updated successfully');
        setShowEditDialog(false);
        setEditingDocument(null);
        loadData();
        onRefresh?.();
      } else {
        const errorData = await response.json().catch(() => ({ detail: 'Update failed' }));
        toast.error(errorData.detail || 'Failed to update document pricing');
      }
    } catch (error) {
      console.error('Error updating document pricing:', error);
      toast.error('Failed to update document pricing');
    }
  };

  const handleBulkUpdate = async () => {
    if (selectedDocuments.length === 0) {
      toast.error('Please select documents to update');
      return;
    }
    
    try {
      const response = await brain.bulk_update_document_pricing({
        document_ids: selectedDocuments,
        ...bulkForm
      });
      
      if (response.ok) {
        toast.success(`Updated pricing for ${selectedDocuments.length} documents`);
        setShowBulkUpdate(false);
        setSelectedDocuments([]);
        loadData();
        onRefresh?.();
      } else {
        const errorData = await response.json().catch(() => ({ detail: 'Bulk update failed' }));
        toast.error(errorData.detail || 'Failed to update document pricing');
      }
    } catch (error) {
      console.error('Error bulk updating document pricing:', error);
      toast.error('Failed to update document pricing');
    }
  };

  const toggleDocumentSelection = (documentId: number) => {
    setSelectedDocuments(prev => 
      prev.includes(documentId)
        ? prev.filter(id => id !== documentId)
        : [...prev, documentId]
    );
  };

  const selectAllDocuments = () => {
    const filteredDocs = getFilteredDocuments();
    setSelectedDocuments(filteredDocs.map(doc => doc.id));
  };

  const clearSelection = () => {
    setSelectedDocuments([]);
  };

  const getFilteredDocuments = () => {
    return documents.filter(doc => {
      const matchesSearch = !searchQuery || 
        doc.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        doc.regulation_type?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        doc.country_jurisdiction?.toLowerCase().includes(searchQuery.toLowerCase());
      
      const matchesPricing = pricingFilter === 'all' ||
        (pricingFilter === 'premium' && doc.is_premium) ||
        (pricingFilter === 'free' && !doc.is_premium);
      
      const matchesTier = tierFilter === 'all' || doc.pricing_tier === tierFilter;
      
      return matchesSearch && matchesPricing && matchesTier;
    });
  };

  const getPricingBadge = (document: DocumentPricingResponse) => {
    if (!document.is_premium) {
      return <Badge variant="secondary" className="bg-green-600/20 text-green-400 border-green-600">Free</Badge>;
    }
    
    const cost = document.credit_cost || 0;
    const tier = document.pricing_tier;
    
    if (tier === 'basic' || cost <= 3) {
      return <Badge variant="secondary" className="bg-blue-600/20 text-blue-400 border-blue-600">📄 Basic ({cost} credits)</Badge>;
    } else if (tier === 'premium' || cost <= 10) {
      return <Badge variant="secondary" className="bg-purple-600/20 text-purple-400 border-purple-600">⭐ Premium ({cost} credits)</Badge>;
    } else {
      return <Badge variant="secondary" className="bg-orange-600/20 text-orange-400 border-orange-600">🏢 Enterprise ({cost} credits)</Badge>;
    }
  };

  const filteredDocuments = getFilteredDocuments();

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-400">Loading document pricing...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-white mb-2">💰 Document Pricing Management</h2>
          <p className="text-gray-400">Set credit costs for Knowledge Base document downloads and premium features</p>
        </div>
        <div className="flex gap-2">
          {selectedDocuments.length > 0 && (
            <Button
              onClick={() => setShowBulkUpdate(true)}
              className="bg-purple-600 hover:bg-purple-700 text-white"
            >
              <Edit className="h-4 w-4 mr-2" />
              Bulk Update ({selectedDocuments.length})
            </Button>
          )}
        </div>
      </div>

      {/* Stats Cards */}
      {stats && (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="bg-gradient-to-br from-blue-600/20 to-blue-800/20 border-blue-600/30">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-blue-200 text-sm">Total Documents</p>
                  <p className="text-2xl font-bold text-white">{stats.total_documents}</p>
                </div>
                <FileText className="h-8 w-8 text-blue-400" />
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-gradient-to-br from-green-600/20 to-green-800/20 border-green-600/30">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-green-200 text-sm">Free Documents</p>
                  <p className="text-2xl font-bold text-white">{stats.total_documents - stats.priced_documents}</p>
                </div>
                <Download className="h-8 w-8 text-green-400" />
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-gradient-to-br from-purple-600/20 to-purple-800/20 border-purple-600/30">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-purple-200 text-sm">Premium Documents</p>
                  <p className="text-2xl font-bold text-white">{stats.priced_documents}</p>
                </div>
                <CreditCard className="h-8 w-8 text-purple-400" />
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-gradient-to-br from-orange-600/20 to-orange-800/20 border-orange-600/30">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-orange-200 text-sm">Avg. Cost</p>
                  <p className="text-2xl font-bold text-white">{stats.avg_credit_cost?.toFixed(1) || '0'}</p>
                </div>
                <TrendingUp className="h-8 w-8 text-orange-400" />
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Filters */}
      <Card className="bg-gray-800/30 border-gray-700">
        <CardContent className="p-4">
          <div className="flex flex-wrap gap-4 items-center">
            <div className="flex-1 min-w-[300px]">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <Input
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search by title, type, or jurisdiction..."
                  className="pl-10 bg-gray-700 border-gray-600 text-white"
                />
              </div>
            </div>
            
            <Select value={pricingFilter} onValueChange={setPricingFilter}>
              <SelectTrigger className="w-[140px] bg-gray-700 border-gray-600 text-white">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-gray-800 border-gray-600">
                <SelectItem value="all" className="text-white">All Documents</SelectItem>
                <SelectItem value="free" className="text-white">Free Only</SelectItem>
                <SelectItem value="premium" className="text-white">Premium Only</SelectItem>
              </SelectContent>
            </Select>
            
            <Select value={tierFilter} onValueChange={setTierFilter}>
              <SelectTrigger className="w-[140px] bg-gray-700 border-gray-600 text-white">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-gray-800 border-gray-600">
                <SelectItem value="all" className="text-white">All Tiers</SelectItem>
                <SelectItem value="free" className="text-white">Free</SelectItem>
                <SelectItem value="basic" className="text-white">Basic</SelectItem>
                <SelectItem value="premium" className="text-white">Premium</SelectItem>
                <SelectItem value="enterprise" className="text-white">Enterprise</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Selection Controls */}
      {filteredDocuments.length > 0 && (
        <div className="flex items-center gap-4 text-sm text-gray-400">
          <Button
            variant="outline"
            size="sm"
            onClick={selectAllDocuments}
            className="border-gray-600 text-gray-300 hover:bg-gray-700"
          >
            Select All ({filteredDocuments.length})
          </Button>
          {selectedDocuments.length > 0 && (
            <Button
              variant="outline"
              size="sm"
              onClick={clearSelection}
              className="border-gray-600 text-gray-300 hover:bg-gray-700"
            >
              Clear Selection
            </Button>
          )}
          <span>{selectedDocuments.length} selected</span>
        </div>
      )}

      {/* Documents Table */}
      <Card className="bg-gray-800/30 border-gray-700">
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow className="border-gray-700">
                <TableHead className="w-12">
                  <Checkbox 
                    checked={selectedDocuments.length === filteredDocuments.length && filteredDocuments.length > 0}
                    onCheckedChange={(checked) => {
                      if (checked) {
                        selectAllDocuments();
                      } else {
                        clearSelection();
                      }
                    }}
                  />
                </TableHead>
                <TableHead className="text-white">Document</TableHead>
                <TableHead className="text-white">Type & Jurisdiction</TableHead>
                <TableHead className="text-white">Pricing</TableHead>
                <TableHead className="text-white">Status</TableHead>
                <TableHead className="text-white w-[100px]">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredDocuments.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} className="text-center py-8">
                    <div className="flex flex-col items-center">
                      <FileText className="h-12 w-12 text-gray-500 mb-4" />
                      <p className="text-gray-400">No documents found</p>
                      <p className="text-sm text-gray-500">Try adjusting your search or filters</p>
                    </div>
                  </TableCell>
                </TableRow>
              ) : (
                filteredDocuments.map((document) => (
                  <TableRow key={document.id} className="border-gray-700 hover:bg-gray-700/30">
                    <TableCell>
                      <Checkbox 
                        checked={selectedDocuments.includes(document.id)}
                        onCheckedChange={() => toggleDocumentSelection(document.id)}
                      />
                    </TableCell>
                    <TableCell>
                      <div>
                        <p className="font-medium text-white truncate max-w-[300px]">{document.title}</p>
                        <p className="text-sm text-gray-400">ID: {document.id}</p>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="text-sm">
                        <p className="text-gray-300">{document.regulation_type || 'N/A'}</p>
                        <p className="text-gray-400">{document.country_jurisdiction || 'N/A'}</p>
                      </div>
                    </TableCell>
                    <TableCell>
                      {getPricingBadge(document)}
                    </TableCell>
                    <TableCell>
                      <Badge 
                        variant="secondary" 
                        className={`${
                          document.publishing_status === 'published' 
                            ? 'bg-green-600/20 text-green-400 border-green-600'
                            : 'bg-yellow-600/20 text-yellow-400 border-yellow-600'
                        }`}
                      >
                        {document.publishing_status}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleEditDocument(document)}
                        className="border-gray-600 text-gray-300 hover:bg-gray-700"
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Edit Dialog */}
      <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
        <DialogContent className="bg-gray-900 border-gray-700 text-white max-w-md">
          <DialogHeader>
            <DialogTitle>Edit Document Pricing</DialogTitle>
            <DialogDescription className="text-gray-400">
              Update pricing for "{editingDocument?.title}"
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <Checkbox 
                id="edit-premium"
                checked={editForm.is_premium}
                onCheckedChange={(checked) => setEditForm(prev => ({ 
                  ...prev, 
                  is_premium: checked as boolean,
                  pricing_tier: checked ? 'premium' : 'free',
                  credit_cost: checked ? (prev.credit_cost || 3) : null
                }))}
              />
              <Label htmlFor="edit-premium" className="text-white cursor-pointer">
                Premium Document (Requires credits)
              </Label>
            </div>
            
            {editForm.is_premium && (
              <>
                <div className="space-y-2">
                  <Label className="text-white">Credit Cost</Label>
                  <Input
                    type="number"
                    min="1"
                    max="50"
                    value={editForm.credit_cost || ''}
                    onChange={(e) => setEditForm(prev => ({ 
                      ...prev, 
                      credit_cost: e.target.value ? parseInt(e.target.value) : null 
                    }))}
                    placeholder="e.g., 3"
                    className="bg-gray-800 border-gray-600 text-white"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label className="text-white">Pricing Tier</Label>
                  <Select 
                    value={editForm.pricing_tier} 
                    onValueChange={(value) => setEditForm(prev => ({ ...prev, pricing_tier: value }))}
                  >
                    <SelectTrigger className="bg-gray-800 border-gray-600 text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-gray-800 border-gray-600">
                      <SelectItem value="basic" className="text-white">📄 Basic (1-3 credits)</SelectItem>
                      <SelectItem value="premium" className="text-white">⭐ Premium (4-10 credits)</SelectItem>
                      <SelectItem value="enterprise" className="text-white">🏢 Enterprise (10+ credits)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </>
            )}
          </div>
          
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => setShowEditDialog(false)}
              className="border-gray-600 text-gray-300"
            >
              Cancel
            </Button>
            <Button 
              onClick={handleUpdatePricing}
              className="bg-blue-600 hover:bg-blue-700 text-white"
            >
              Update Pricing
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Bulk Update Dialog */}
      <Dialog open={showBulkUpdate} onOpenChange={setShowBulkUpdate}>
        <DialogContent className="bg-gray-900 border-gray-700 text-white max-w-md">
          <DialogHeader>
            <DialogTitle>Bulk Update Pricing</DialogTitle>
            <DialogDescription className="text-gray-400">
              Update pricing for {selectedDocuments.length} selected documents
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <Checkbox 
                id="bulk-premium"
                checked={bulkForm.is_premium}
                onCheckedChange={(checked) => setBulkForm(prev => ({ 
                  ...prev, 
                  is_premium: checked as boolean,
                  pricing_tier: checked ? 'premium' : 'free',
                  credit_cost: checked ? (prev.credit_cost || 3) : null
                }))}
              />
              <Label htmlFor="bulk-premium" className="text-white cursor-pointer">
                Premium Documents (Requires credits)
              </Label>
            </div>
            
            {bulkForm.is_premium && (
              <>
                <div className="space-y-2">
                  <Label className="text-white">Credit Cost</Label>
                  <Input
                    type="number"
                    min="1"
                    max="50"
                    value={bulkForm.credit_cost || ''}
                    onChange={(e) => setBulkForm(prev => ({ 
                      ...prev, 
                      credit_cost: e.target.value ? parseInt(e.target.value) : null 
                    }))}
                    placeholder="e.g., 3"
                    className="bg-gray-800 border-gray-600 text-white"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label className="text-white">Pricing Tier</Label>
                  <Select 
                    value={bulkForm.pricing_tier} 
                    onValueChange={(value) => setBulkForm(prev => ({ ...prev, pricing_tier: value }))}
                  >
                    <SelectTrigger className="bg-gray-800 border-gray-600 text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-gray-800 border-gray-600">
                      <SelectItem value="basic" className="text-white">📄 Basic (1-3 credits)</SelectItem>
                      <SelectItem value="premium" className="text-white">⭐ Premium (4-10 credits)</SelectItem>
                      <SelectItem value="enterprise" className="text-white">🏢 Enterprise (10+ credits)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </>
            )}
          </div>
          
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => setShowBulkUpdate(false)}
              className="border-gray-600 text-gray-300"
            >
              Cancel
            </Button>
            <Button 
              onClick={handleBulkUpdate}
              className="bg-purple-600 hover:bg-purple-700 text-white"
            >
              Update {selectedDocuments.length} Documents
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
