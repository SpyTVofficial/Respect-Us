


import React, { useState, useEffect, startTransition } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useNavigate } from 'react-router-dom';
import { useUser } from '@stackframe/react';
import brain from 'brain';
import { Coins, TrendingUp } from 'lucide-react';
import { toast } from 'sonner';

export const Header: React.FC = () => {
  const navigate = useNavigate();
  const user = useUser();
  const [creditBalance, setCreditBalance] = useState<number | null>(null);
  const [loading, setLoading] = useState(false);

  // Load credit balance for authenticated users
  useEffect(() => {
    if (user) {
      loadCreditBalance();
      // Update balance every 30 seconds
      const interval = setInterval(loadCreditBalance, 30000);
      return () => clearInterval(interval);
    }
  }, [user]);

  const loadCreditBalance = async () => {
    if (!user || loading) return;
    
    try {
      startTransition(() => {
        setLoading(true);
      });
      const response = await brain.get_credit_balance();
      const data = await response.json();
      startTransition(() => {
        setCreditBalance(data.current_balance);
      });
    } catch (error) {
      console.error('Error loading credit balance:', error);
    } finally {
      startTransition(() => {
        setLoading(false);
      });
    }
  };

  const handleBuyCredits = () => {
    navigate('/CreditPurchase');
  };

  const handleViewUsage = () => {
    navigate('/UsageAnalytics');
  };

  return (
    <header className="bg-gray-900 border-b border-gray-700 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <div className="flex items-center">
            <button 
              onClick={() => navigate('/')}
              className="flex items-center space-x-3 hover:opacity-80 transition-opacity"
            >
              <img 
                src="https://static.databutton.com/public/a180dafe-f6c8-4fb7-917a-f8d4b9bfe1b1/Original_jpg.jpg" 
                alt="RespectUs Logo" 
                className="h-10 w-auto"
              />
              <span className="text-2xl font-bold text-white">
                RespectUs
              </span>
            </button>
          </div>

          {/* Navigation and Credit Balance */}
          <div className="flex items-center space-x-4">
            {user && (
              <>
                {/* Credit Balance Display */}
                <div className="flex items-center space-x-2 bg-gray-800 px-3 py-2 rounded-lg border border-gray-600">
                  <Coins className="h-4 w-4 text-blue-400" />
                  <div className="flex items-center space-x-1">
                    <span className="text-sm font-medium text-gray-300">Credits:</span>
                    {loading ? (
                      <div className="w-8 h-4 bg-gray-700 animate-pulse rounded" />
                    ) : (
                      <Badge 
                        variant={creditBalance && creditBalance < 100 ? "destructive" : "default"}
                        className="font-semibold bg-gray-700 text-white border-gray-600"
                      >
                        {creditBalance?.toLocaleString() ?? '...'}
                      </Badge>
                    )}
                  </div>
                </div>

                {/* Quick Actions */}
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={handleViewUsage}
                  className="flex items-center space-x-1 border-gray-600 text-gray-300 hover:bg-gray-800 hover:text-white"
                >
                  <TrendingUp className="h-4 w-4" />
                  <span>Usage</span>
                </Button>

                <Button 
                  size="sm" 
                  onClick={handleBuyCredits}
                  className="bg-blue-600 hover:bg-blue-700 text-white"
                >
                  Buy Credits
                </Button>
              </>
            )}

            {/* User Menu */}
            {user ? (
              <div className="flex items-center space-x-2">
                <span className="text-sm text-gray-300">Welcome, {user.displayName || user.primaryEmail}</span>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  onClick={() => navigate('/auth/sign-out')}
                  className="text-gray-300 hover:bg-gray-800 hover:text-white"
                >
                  Sign Out
                </Button>
              </div>
            ) : (
              <div className="flex items-center space-x-2">
                <Button 
                  variant="ghost" 
                  size="sm" 
                  onClick={() => navigate('/auth/sign-in')}
                  className="text-gray-300 hover:bg-gray-800 hover:text-white"
                >
                  Sign In
                </Button>
                <Button 
                  size="sm" 
                  onClick={() => navigate('/auth/sign-up')}
                  className="bg-blue-600 hover:bg-blue-700 text-white"
                >
                  Sign Up
                </Button>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};
