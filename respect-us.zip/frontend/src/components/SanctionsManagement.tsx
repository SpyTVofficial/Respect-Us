import React, { useState, useEffect } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { toast } from 'sonner';
import { Copy, Plus, Trash2, TreePine, GitBranch, Settings, Edit } from 'lucide-react';
import brain from 'brain';
import SanctionsWorkflowsTab from './SanctionsWorkflowsTab';
import type {
  SanctionsTree,
  SanctionsNode,
  CreateSanctionsNodeRequest,
  UpdateSanctionsNodeRequest,
  SanctionsNodeOption,
  CreateSanctionsNodeOptionRequest,
  UpdateSanctionsNodeOptionRequest,
  SanctionsTreeCreate,
} from 'types';

interface SanctionsManagementProps {
  onRefresh?: () => void;
}

const SanctionsManagement: React.FC<SanctionsManagementProps> = ({ onRefresh }) => {
  const [activeTab, setActiveTab] = useState('trees');
  const [trees, setTrees] = useState<SanctionsTree[]>([]);
  const [currentTreeId, setCurrentTreeId] = useState<string>('');
  const [nodes, setNodes] = useState<SanctionsNode[]>([]);
  const [loading, setLoading] = useState(true);
  
  // Node management state
  const [selectedNodeForEdit, setSelectedNodeForEdit] = useState<SanctionsNode | null>(null);
  const [showEditNodeDialog, setShowEditNodeDialog] = useState(false);
  const [showCreateNodeDialog, setShowCreateNodeDialog] = useState(false);
  const [creatingNode, setCreatingNode] = useState(false);
  
  // Options management state
  const [showOptionsDialog, setShowOptionsDialog] = useState(false);
  const [selectedNodeForOptions, setSelectedNodeForOptions] = useState<SanctionsNode | null>(null);
  const [nodeOptions, setNodeOptions] = useState<SanctionsNodeOption[]>([]);
  const [loadingOptions, setLoadingOptions] = useState(false);
  const [showEditOptionDialog, setShowEditOptionDialog] = useState(false);
  const [selectedOptionForEdit, setSelectedOptionForEdit] = useState<SanctionsNodeOption | null>(null);
  const [editOptionData, setEditOptionData] = useState({
    option_text: '',
    option_value: '',
    routing_rule: '',
    regulatory_notes: '',
    display_order: 1,
    note: '',
  });
  
  // Tree creation state
  const [showCreateTreeDialog, setShowCreateTreeDialog] = useState(false);
  const [creatingTree, setCreatingTree] = useState(false);
  const [newTreeData, setNewTreeData] = useState<SanctionsTreeCreate>({
    name: '',
    description: '',
    jurisdiction: '',
    category: '',
    is_introduction_template: false,
    introduction_tree_id: null as string | null
  });

  // Tree edit state
  const [showEditTreeDialog, setShowEditTreeDialog] = useState(false);
  const [editingTree, setEditingTree] = useState<SanctionsTree | null>(null);
  const [editTreeData, setEditTreeData] = useState<SanctionsTreeCreate>({
    name: '',
    description: '',
    jurisdiction: '',
    category: '',
    is_introduction_template: false,
    introduction_tree_id: null as string | null
  });

  // Create node form data
  const [newNodeData, setNewNodeData] = useState({
    node_key: '',
    title: '',
    description: '',
    question_text: '',
    question_type: 'multiple_choice' as 'multiple_choice' | 'yes_no' | 'text_input' | 'numeric',
    parent_node_id: null as string | null,
    display_order: 0,
    is_root: false,
    notes: '',
  });
  
  // Edit node form data
  const [editNodeData, setEditNodeData] = useState({
    node_key: '',
    title: '',
    description: '',
    question_text: '',
    question_type: 'multiple_choice' as 'multiple_choice' | 'yes_no' | 'text_input' | 'numeric',
    parent_node_id: '',
    notes: '',
  });
  
  // New option form data
  const [newOptionData, setNewOptionData] = useState({
    option_text: '',
    option_value: '',
    routing_rule: '',
    regulatory_notes: '',
    display_order: 1,
    note: '',
  });

  // Load trees on component mount
  useEffect(() => {
    const initializeComponent = async () => {
      try {
        setLoading(true);
        const response = await brain.list_sanctions_trees();
        const treesData = await response.json();
        setTrees(treesData);
        
        if (treesData.length > 0) {
          const firstTreeId = treesData[0].id;
          setCurrentTreeId(firstTreeId);
          
          // Load nodes for the first tree
          try {
            const nodesResponse = await brain.list_sanctions_nodes({ treeId: firstTreeId });
            const nodesData = await nodesResponse.json();
            setNodes(nodesData);
          } catch (nodeError) {
            console.error('Error loading nodes:', nodeError);
            toast.error('Failed to load nodes');
          }
        }
      } catch (error) {
        console.error('Error loading trees:', error);
        toast.error('Failed to load decision trees');
      } finally {
        setLoading(false);
      }
    };
    
    initializeComponent();
  }, []);

  const loadNodes = async (treeId: string) => {
    if (!treeId) {
      console.warn('No tree ID provided to loadNodes');
      return;
    }
    try {
      setLoading(true);
      const response = await brain.list_sanctions_nodes({ treeId });
      const data = await response.json();
      setNodes(data);
    } catch (error) {
      console.error('Error loading nodes:', error);
      toast.error('Failed to load nodes');
    } finally {
      setLoading(false);
    }
  };

  const loadTrees = async () => {
    try {
      const response = await brain.list_sanctions_trees();
      const treesData = await response.json();
      setTrees(treesData);
    } catch (error) {
      console.error('Error loading trees:', error);
      toast.error('Failed to load decision trees');
    }
  };

  const loadOptions = async (treeId: string, nodeId: string) => {
    try {
      setLoadingOptions(true);
      const response = await brain.list_sanctions_node_options({ treeId, nodeId });
      const data = await response.json();
      setNodeOptions(data);
    } catch (error) {
      console.error('Error loading options:', error);
      toast.error('Failed to load node options');
      setNodeOptions([]);
    } finally {
      setLoadingOptions(false);
    }
  };

  const openEditNodeDialog = (node: SanctionsNode) => {
    setSelectedNodeForEdit(node);
    setEditNodeData({
      node_key: node.node_key || '',
      title: node.title || '',
      description: node.description || '',
      question_text: node.question_text || '',
      question_type: node.question_type || 'multiple_choice',
      parent_node_id: node.parent_node_id || '',
      notes: node.notes || '',
    });
    setShowEditNodeDialog(true);
  };

  const openOptionsDialog = (node: SanctionsNode) => {
    setSelectedNodeForOptions(node);
    loadOptions(node.tree_id, node.id);
    setShowOptionsDialog(true);
  };

  const handleUpdateNode = async () => {
    if (!selectedNodeForEdit) return;

    try {
      const updateData: UpdateSanctionsNodeRequest = {
        node_key: editNodeData.node_key,
        title: editNodeData.title,
        description: editNodeData.description,
        question_text: editNodeData.question_text,
        question_type: editNodeData.question_type,
        parent_node_id: editNodeData.parent_node_id || null,
        notes: editNodeData.notes,
      };

      await brain.update_sanctions_node(
        { treeId: selectedNodeForEdit.tree_id, nodeId: selectedNodeForEdit.id },
        updateData
      );

      toast.success('Node updated successfully');
      setShowEditNodeDialog(false);
      loadNodes(selectedNodeForEdit.tree_id);
    } catch (error) {
      console.error('Error updating node:', error);
      toast.error('Failed to update node');
    }
  };

  const handleAddOption = async () => {
    if (!selectedNodeForOptions) return;

    try {
      const optionData: CreateSanctionsNodeOptionRequest = {
        node_id: selectedNodeForOptions.id,
        option_text: newOptionData.option_text,
        option_value: newOptionData.option_value,
        routing_rule: newOptionData.routing_rule,
        regulatory_notes: newOptionData.regulatory_notes || null,
        display_order: newOptionData.display_order,
        note: newOptionData.note || null,
      };

      await brain.create_sanctions_node_option(
        { treeId: selectedNodeForOptions.tree_id, nodeId: selectedNodeForOptions.id },
        optionData
      );

      toast.success('Option added successfully');
      setNewOptionData({
        option_text: '',
        option_value: '',
        routing_rule: '',
        regulatory_notes: '',
        display_order: nodeOptions.length + 1,
        note: '',
      });
      loadOptions(selectedNodeForOptions.tree_id, selectedNodeForOptions.id);
    } catch (error) {
      console.error('Error adding option:', error);
      toast.error('Failed to add option');
    }
  };

  const handleDeleteOption = async (optionId: string) => {
    if (!selectedNodeForOptions) return;

    console.log('selectedNodeForOptions:', selectedNodeForOptions);
    console.log('nodeId:', selectedNodeForOptions.id);
    console.log('treeId:', selectedNodeForOptions.tree_id);
    console.log('optionId:', optionId);

    if (!selectedNodeForOptions.id) {
      console.error('Missing node ID');
      toast.error('Missing node ID - cannot delete option');
      return;
    }

    try {
      await brain.delete_sanctions_node_option({
        treeId: selectedNodeForOptions.tree_id,
        nodeId: selectedNodeForOptions.id,
        optionId,
      });

      toast.success('Option deleted successfully');
      loadOptions(selectedNodeForOptions.tree_id, selectedNodeForOptions.id);
    } catch (error) {
      console.error('Error deleting option:', error);
      toast.error('Failed to delete option');
    }
  };
  
  const handleDuplicateOption = async (option: SanctionsNodeOption) => {
    if (!selectedNodeForOptions) return;

    try {
      const duplicateData: CreateSanctionsNodeOptionRequest = {
        option_text: `${option.option_text} (Copy)`,
        option_value: option.option_value,
        routing_rule: option.routing_rule,
        regulatory_notes: option.regulatory_notes,
        display_order: nodeOptions.length + 1,
        note: option.note,
      };

      await brain.create_sanctions_node_option(
        { treeId: selectedNodeForOptions.tree_id, nodeId: selectedNodeForOptions.id },
        duplicateData
      );

      toast.success('Option duplicated successfully');
      loadOptions(selectedNodeForOptions.tree_id, selectedNodeForOptions.id);
    } catch (error) {
      console.error('Error duplicating option:', error);
      toast.error('Failed to duplicate option');
    }
  };
  
  const handleDeleteNode = async (nodeId: string) => {
    if (!currentTreeId) return;
    
    try {
      await brain.delete_sanctions_node({
        nodeId,
        treeId: currentTreeId,
      });
      
      toast.success('Node deleted successfully');
      loadNodes(currentTreeId);
    } catch (error) {
      console.error('Error deleting node:', error);
      toast.error('Failed to delete node');
    }
  };

  const handleTreeChange = (newTreeId: string) => {
    setCurrentTreeId(newTreeId);
    loadNodes(newTreeId);
  };

  const selectedTree = trees.find(tree => tree.id === currentTreeId);

  // Create new node
  const handleCreateNode = async () => {
    if (!currentTreeId) {
      toast.error('Please select a decision tree first');
      return;
    }

    try {
      setCreatingNode(true);
      const response = await brain.create_sanctions_node(
        { treeId: currentTreeId },
        newNodeData
      );
      if (response.ok) {
        toast.success('Tree node created successfully');
        setShowCreateNodeDialog(false);
        setNewNodeData({
          node_key: '',
          title: '',
          description: '',
          question_text: '',
          question_type: 'multiple_choice',
          parent_node_id: null,
          display_order: 0,
          is_root: false,
          notes: '',
        });
        loadNodes(currentTreeId);
      } else {
        const errorData = await response.json().catch(() => null);
        toast.error(`Failed to create node: ${errorData?.detail || 'Unknown error'}`);
      }
    } catch (error) {
      console.error('Error creating node:', error);
      toast.error('Failed to create node');
    } finally {
      setCreatingNode(false);
    }
  };

  // Create new tree
  const handleCreateTree = async () => {
    try {
      setCreatingTree(true);
      const response = await brain.create_sanctions_tree(newTreeData);
      if (response.ok) {
        toast.success('Tree created successfully');
        setShowCreateTreeDialog(false);
        setNewTreeData({
          name: '',
          description: '',
          jurisdiction: '',
          category: '',
          is_introduction_template: false,
          introduction_tree_id: null,
        });
        loadTrees();
      } else {
        const errorData = await response.json().catch(() => null);
        toast.error(`Failed to create tree: ${errorData?.detail || 'Unknown error'}`);
      }
    } catch (error) {
      console.error('Error creating tree:', error);
      toast.error('Failed to create tree');
    } finally {
      setCreatingTree(false);
    }
  };

  // Edit tree
  const handleEditTree = async (tree: SanctionsTree) => {
    setEditingTree(tree);
    setEditTreeData({
      name: tree.name,
      description: tree.description,
      jurisdiction: tree.jurisdiction,
      category: tree.category,
      is_introduction_template: tree.is_introduction_template,
      introduction_tree_id: tree.introduction_tree_id,
    });
    setShowEditTreeDialog(true);
  };

  // Update tree
  const handleUpdateTree = async () => {
    if (!editingTree) return;
    
    try {
      setCreatingTree(true);
      const response = await brain.update_sanctions_tree(
        { treeId: editingTree.id },
        editTreeData
      );
      if (response.ok) {
        toast.success('Tree updated successfully');
        setShowEditTreeDialog(false);
        setEditingTree(null);
        loadTrees();
      } else {
        const errorData = await response.json().catch(() => null);
        toast.error(`Failed to update tree: ${errorData?.detail || 'Unknown error'}`);
      }
    } catch (error) {
      console.error('Error updating tree:', error);
      toast.error('Failed to update tree');
    } finally {
      setCreatingTree(false);
    }
  };

  // Duplicate tree
  const handleDuplicateTree = async (tree: SanctionsTree) => {
    try {
      const response = await brain.duplicate_sanctions_tree({ treeId: tree.id });
      if (response.ok) {
        toast.success(`Tree "${tree.name}" duplicated successfully`);
        loadTrees();
      } else {
        const errorData = await response.json().catch(() => null);
        toast.error(`Failed to duplicate tree: ${errorData?.detail || 'Unknown error'}`);
      }
    } catch (error) {
      console.error('Error duplicating tree:', error);
      toast.error('Failed to duplicate tree');
    }
  };

  // Delete tree
  const handleDeleteTree = async (treeId: string) => {
    try {
      await brain.delete_sanctions_tree({ treeId });
      toast.success('Tree deleted successfully');
      loadTrees();
    } catch (error) {
      console.error('Error deleting tree:', error);
      toast.error('Failed to delete tree');
    }
  };

  // Duplicate node
  const handleDuplicateNode = async (node: SanctionsNode) => {
    if (!currentTreeId) return;
    
    try {
      const response = await brain.duplicate_sanctions_node({
        nodeId: node.id,
        treeId: currentTreeId
      });
      if (response.ok) {
        toast.success(`Node "${node.title}" duplicated successfully`);
        loadNodes(currentTreeId);
      } else {
        const errorData = await response.json().catch(() => null);
        toast.error(`Failed to duplicate node: ${errorData?.detail || 'Unknown error'}`);
      }
    } catch (error) {
      console.error('Error duplicating node:', error);
      toast.error('Failed to duplicate node');
    }
  };

  // Edit option
  const handleEditOption = (option: SanctionsNodeOption) => {
    setSelectedOptionForEdit(option);
    setEditOptionData({
      option_text: option.option_text,
      option_value: option.option_value,
      routing_rule: option.routing_rule || '',
      regulatory_notes: option.regulatory_notes || '',
      display_order: option.display_order,
      note: option.note || '',
    });
    setShowEditOptionDialog(true);
  };

  // Update option
  const handleUpdateOption = async () => {
    if (!selectedOptionForEdit || !selectedNodeForOptions) return;
    
    try {
      const updateData: UpdateSanctionsNodeOptionRequest = {
        option_text: editOptionData.option_text,
        option_value: editOptionData.option_value,
        routing_rule: editOptionData.routing_rule || null,
        regulatory_notes: editOptionData.regulatory_notes || null,
        display_order: editOptionData.display_order,
        note: editOptionData.note || null,
      };

      await brain.update_sanctions_node_option(
        { 
          optionId: selectedOptionForEdit.id,
          treeId: selectedNodeForOptions.tree_id,
          nodeId: selectedNodeForOptions.id 
        },
        updateData
      );

      toast.success('Option updated successfully');
      setShowEditOptionDialog(false);
      setSelectedOptionForEdit(null);
      loadOptions(selectedNodeForOptions.tree_id, selectedNodeForOptions.id);
    } catch (error) {
      console.error('Error updating option:', error);
      toast.error('Failed to update option');
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-amber-400 mb-2">Sanctions & Embargoes Administration</h1>
        <p className="text-gray-300">Manage sanctions decision trees and workflows</p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid grid-cols-2 w-fit bg-gray-800 border border-gray-700">
          <TabsTrigger value="trees" className="data-[state=active]:bg-amber-600 data-[state=active]:text-white">
            <TreePine className="w-4 h-4 mr-2" />
            Decision Trees
          </TabsTrigger>
          <TabsTrigger value="workflows" className="data-[state=active]:bg-purple-600 data-[state=active]:text-white">
            <GitBranch className="w-4 h-4 mr-2" />
            Workflows
          </TabsTrigger>
        </TabsList>

        <TabsContent value="trees" className="space-y-6">
          {/* Header with Add Tree Button */}
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-semibold text-amber-400">Decision Trees</h2>
            <Button
              onClick={() => setShowCreateTreeDialog(true)}
              className="bg-green-600 hover:bg-green-700 text-white"
            >
              <Plus className="h-4 w-4 mr-2" />
              CREATE TREE
            </Button>
          </div>

          {/* Trees Grid */}
          {loading ? (
            <div className="text-center py-8 text-gray-400">Loading trees...</div>
          ) : trees.length === 0 ? (
            <div className="text-center py-12">
              <TreePine className="h-12 w-12 text-gray-500 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-400 mb-2">No Decision Trees</h3>
              <p className="text-gray-500 mb-4">Create your first sanctions decision tree to get started.</p>
              <Button
                onClick={() => setShowCreateTreeDialog(true)}
                className="bg-green-600 hover:bg-green-700 text-white"
              >
                <Plus className="h-4 w-4 mr-2" />
                CREATE TREE
              </Button>
            </div>
          ) : (
            <div className="grid gap-4">
              {trees.map((tree) => (
                <Card 
                  key={tree.id} 
                  className={`bg-gray-900/50 border-gray-700/50 backdrop-blur hover:bg-gray-800/50 transition-colors cursor-pointer ${
                    currentTreeId === tree.id ? 'ring-2 ring-amber-500 border-amber-500' : ''
                  }`}
                  onClick={() => handleTreeChange(tree.id)}
                >
                  <CardHeader className="pb-3">
                    <div className="flex items-start justify-between">
                      <div className="space-y-1 flex-1">
                        <CardTitle className="text-lg font-semibold text-white flex items-center gap-2">
                          <TreePine className="h-5 w-5 text-amber-400" />
                          {tree.name}
                          {currentTreeId === tree.id && (
                            <Badge className="bg-amber-500/20 text-amber-400 border-amber-500/30 text-xs">
                              SELECTED
                            </Badge>
                          )}
                        </CardTitle>
                        {tree.description && (
                          <p className="text-sm text-gray-300">{tree.description}</p>
                        )}
                      </div>
                      <div className="flex gap-2" onClick={(e) => e.stopPropagation()}>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleDuplicateTree(tree)}
                          className="text-blue-400 border-blue-500 hover:bg-blue-500/10"
                        >
                          <Copy className="w-3 h-3 mr-1" />
                          DUPLICATE
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleEditTree(tree)}
                          className="text-amber-400 border-amber-500 hover:bg-amber-500/10"
                        >
                          <Edit className="w-3 h-3 mr-1" />
                          EDIT
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleDeleteTree(tree.id)}
                          className="text-red-400 border-red-500 hover:bg-red-500/10"
                        >
                          <Trash2 className="w-3 h-3 mr-1" />
                          DELETE
                        </Button>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-3 gap-4 text-sm">
                      <div>
                        <span className="text-gray-400">Jurisdiction:</span>
                        <p className="text-white">{tree.jurisdiction || 'Not specified'}</p>
                      </div>
                      <div>
                        <span className="text-gray-400">Category:</span>
                        <p className="text-white">{tree.category || 'Not specified'}</p>
                      </div>
                      <div>
                        <span className="text-gray-400">Nodes:</span>
                        <p className="text-white">{currentTreeId === tree.id ? nodes.length : '—'}</p>
                      </div>
                    </div>
                    {tree.is_introduction_template && (
                      <div className="mt-2">
                        <Badge className="bg-purple-500/20 text-purple-400 border-purple-500/30">
                          Introduction Template
                        </Badge>
                      </div>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          )}

          {/* Selected Tree Nodes Management */}
          {currentTreeId && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold text-white">Tree Nodes</h3>
                <Button
                  onClick={() => setShowCreateNodeDialog(true)}
                  className="bg-amber-600 hover:bg-amber-700 text-white"
                >
                  <Plus className="h-4 w-4 mr-2" />
                  ADD NODE
                </Button>
              </div>

              {/* Nodes List */}
              {nodes.length === 0 ? (
                <div className="text-center py-8 border border-gray-700 rounded-lg bg-gray-800/20">
                  <h4 className="text-gray-400 mb-2">No nodes in this tree</h4>
                  <p className="text-gray-500 text-sm mb-4">Add the first node to start building your decision tree.</p>
                  <Button
                    onClick={() => setShowCreateNodeDialog(true)}
                    className="bg-amber-600 hover:bg-amber-700 text-white"
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    ADD NODE
                  </Button>
                </div>
              ) : (
                <div className="grid gap-4">
                  {nodes.map((node) => (
                    <Card key={node.id} className="bg-gray-800/30 border-gray-700/50">
                      <CardHeader className="pb-3">
                        <div className="flex items-start justify-between">
                          <div className="space-y-1">
                            <CardTitle className="text-base font-semibold text-white">
                              {node.node_key && `${node.node_key} - `}{node.title}
                            </CardTitle>
                            {node.description && (
                              <p className="text-sm text-gray-300">{node.description}</p>
                            )}
                          </div>
                          <div className="flex gap-2">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleDuplicateNode(node)}
                              className="border-blue-600 text-blue-400 hover:bg-blue-600/10"
                            >
                              <Copy className="h-3 w-3 mr-1" />
                              DUPLICATE
                            </Button>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => openEditNodeDialog(node)}
                              className="border-blue-600 text-blue-400 hover:bg-blue-600/10"
                            >
                              EDIT
                            </Button>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => openOptionsDialog(node)}
                              className="border-amber-600 text-amber-400 hover:bg-amber-600/10"
                            >
                              OPTIONS
                            </Button>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleDeleteNode(node.id)}
                              className="border-red-600 text-red-400 hover:bg-red-600/10"
                            >
                              <Trash2 className="h-3 w-3 mr-1" />
                              DELETE
                            </Button>
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="grid grid-cols-2 gap-4 text-sm">
                          <div>
                            <span className="text-gray-400">Question:</span>
                            <p className="text-white">{node.question_text || ' No question set'}</p>
                          </div>
                          <div>
                            <span className="text-gray-400">Type:</span>
                            <Badge variant="secondary" className="ml-2 bg-gray-700 text-gray-300">
                              {node.question_type}
                            </Badge>
                          </div>
                        </div>
                        {node.is_root && (
                          <div className="mt-2">
                            <Badge className="bg-green-500/20 text-green-400 border-green-500/30">
                              Root Node
                            </Badge>
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Edit Node Dialog */}
          <Dialog open={showEditNodeDialog} onOpenChange={setShowEditNodeDialog}>
            <DialogContent className="bg-gray-900 border-gray-700 text-white max-w-4xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle className="text-amber-400">Edit Question/Node</DialogTitle>
                <DialogDescription className="text-gray-400">
                  Edit the question or node: {selectedNodeForEdit?.title}
                </DialogDescription>
              </DialogHeader>
              
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-gray-300">Node Key *</label>
                    <Input
                      value={editNodeData.node_key}
                      onChange={(e) => setEditNodeData({ ...editNodeData, node_key: e.target.value })}
                      className="bg-gray-900/50 border-gray-600 text-white placeholder:text-gray-400 focus:border-amber-500"
                      placeholder="e.g., SAN001, 1.1"
                    />
                    <p className="text-xs text-gray-400">Unique identifier for this node</p>
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-gray-300">Question Type</label>
                    <Select
                      value={editNodeData.question_type}
                      onValueChange={(value) => setEditNodeData({ ...editNodeData, question_type: value as any })}
                    >
                      <SelectTrigger className="bg-gray-900/50 border-gray-600 text-white">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="bg-gray-800 border-gray-600">
                        <SelectItem value="multiple_choice">Multiple Choice</SelectItem>
                        <SelectItem value="yes_no">Yes/No</SelectItem>
                        <SelectItem value="text_input">Text Input</SelectItem>
                        <SelectItem value="numeric">Numeric</SelectItem>
                      </SelectContent>
                    </Select>
                    <p className="text-xs text-gray-400">How users will answer this question</p>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-300">Title *</label>
                  <Input
                    value={editNodeData.title}
                    onChange={(e) => setEditNodeData({ ...editNodeData, title: e.target.value })}
                    className="bg-gray-900/50 border-gray-600 text-white placeholder:text-gray-400 focus:border-amber-500"
                    placeholder="Question or node title"
                  />
                  <p className="text-xs text-gray-400">Short, clear title for this question (max 500 characters)</p>
                </div>
                
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-300">Question Text *</label>
                  <Textarea
                    value={editNodeData.question_text}
                    onChange={(e) => setEditNodeData({ ...editNodeData, question_text: e.target.value })}
                    className="bg-gray-900/50 border-gray-600 text-white placeholder:text-gray-400 focus:border-amber-500 min-h-[100px]"
                    placeholder="The detailed question text that will be displayed to users"
                  />
                  <p className="text-xs text-gray-400">The full question that users will see and answer</p>
                </div>
                
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-300">Description</label>
                  <Textarea
                    value={editNodeData.description}
                    onChange={(e) => setEditNodeData({ ...editNodeData, description: e.target.value })}
                    className="bg-gray-900/50 border-gray-600 text-white placeholder:text-gray-400 focus:border-amber-500"
                    placeholder="Optional description or additional context"
                    rows={3}
                  />
                  <p className="text-xs text-gray-400">Additional context or explanation for this question</p>
                </div>
                
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-300">Parent Node</label>
                  <Select
                    value={editNodeData.parent_node_id || 'none'}
                    onValueChange={(value) => setEditNodeData({ ...editNodeData, parent_node_id: value === 'none' ? null : value })}
                  >
                    <SelectTrigger className="bg-gray-900/50 border-gray-600 text-white">
                      <SelectValue placeholder="Select parent node" />
                    </SelectTrigger>
                    <SelectContent className="bg-gray-800 border-gray-600">
                      <SelectItem value="none">No Parent (Root Level)</SelectItem>
                      {nodes.filter(n => n.id !== selectedNodeForEdit?.id).map((node) => (
                        <SelectItem key={node.id} value={node.id}>
                          {node.node_key} - {node.title}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <p className="text-xs text-gray-400">Which node leads to this question</p>
                </div>
                
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-300">Notes</label>
                  <Textarea
                    value={editNodeData.notes}
                    onChange={(e) => setEditNodeData({ ...editNodeData, notes: e.target.value })}
                    className="bg-gray-900/50 border-gray-600 text-white placeholder:text-gray-400 focus:border-amber-500"
                    placeholder="Optional field for additional information, regulatory context, or implementation notes"
                    rows={3}
                  />
                  <p className="text-xs text-gray-400">Internal documentation for system administrators</p>
                </div>
              </div>

              <div className="flex justify-end space-x-3 pt-4 border-t border-gray-700">
                <Button
                  variant="outline"
                  onClick={() => setShowEditNodeDialog(false)}
                  className="border-gray-600 text-gray-300 hover:bg-gray-700 hover:text-white"
                >
                  Cancel
                </Button>
                <Button
                  onClick={handleUpdateNode}
                  className="bg-amber-600 hover:bg-amber-700 text-white"
                  disabled={!editNodeData.title.trim() || !editNodeData.question_text.trim()}
                >
                  Update Node
                </Button>
              </div>
            </DialogContent>
          </Dialog>

          {/* Options Dialog - Matching Product Classification design */}
          <Dialog open={showOptionsDialog} onOpenChange={setShowOptionsDialog}>
            <DialogContent className="bg-gray-900 border-gray-700 text-white max-w-4xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle className="text-amber-400">Manage Node Options</DialogTitle>
                <DialogDescription className="text-gray-400">
                  Configure options for node: {selectedNodeForOptions?.node_key} - {selectedNodeForOptions?.title}
                </DialogDescription>
              </DialogHeader>
              
              <div className="space-y-6">
                {/* Create New Option */}
                <div className="border border-gray-700 rounded-lg p-4 bg-gray-800/30">
                  <h4 className="text-white font-semibold mb-3">Add New Option</h4>
                  <div className="grid grid-cols-2 gap-4 mb-4">
                    <div>
                      <Label className="text-gray-300">Option Text *</Label>
                      <Input
                        value={newOptionData.option_text}
                        onChange={(e) => setNewOptionData({ ...newOptionData, option_text: e.target.value })}
                        className="bg-gray-800 border-gray-600 text-white"
                        placeholder="e.g., Yes, No, Not Applicable"
                      />
                    </div>
                    <div>
                      <Label className="text-gray-300">Option Value *</Label>
                      <Input
                        value={newOptionData.option_value}
                        onChange={(e) => setNewOptionData({ ...newOptionData, option_value: e.target.value })}
                        className="bg-gray-800 border-gray-600 text-white"
                        placeholder="e.g., yes, no, na"
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4 mb-4">
                    <div>
                      <Label className="text-gray-300">Routing Rule</Label>
                      <Input
                        value={newOptionData.routing_rule}
                        onChange={(e) => setNewOptionData({ ...newOptionData, routing_rule: e.target.value })}
                        className="bg-gray-800 border-gray-600 text-white"
                        placeholder="{'->'} node_key or outcome: code; continue: target"
                      />
                      <div className="mt-2 p-3 bg-gray-800/50 rounded border border-gray-700">
                        <p className="text-gray-400 text-sm mb-2 font-medium">Enhanced Routing Syntax:</p>
                        <div className="space-y-1 text-xs">
                          <div className="text-gray-300">
                            <span className="text-amber-400">Simple navigation:</span> {'->'} next_node_key
                          </div>
                          <div className="text-gray-300">
                            <span className="text-amber-400">Final outcome:</span> {'->'} "outcome_code"
                          </div>
                          <div className="text-gray-300">
                            <span className="text-amber-400">Enhanced (outcome + continue):</span> outcome: "not_classified"; continue: dual_use_tree
                          </div>
                        </div>
                        <div className="mt-2 pt-2 border-t border-gray-700">
                          <p className="text-xs text-gray-500">
                            💡 Enhanced syntax shows an intermediate outcome but continues to another classification step
                          </p>
                        </div>
                      </div>
                    </div>
                    <div>
                      <Label className="text-gray-300">Display Order</Label>
                      <Input
                        type="number"
                        min="0"
                        value={newOptionData.display_order}
                        onChange={(e) => setNewOptionData({ ...newOptionData, display_order: parseInt(e.target.value) || 0 })}
                        className="bg-gray-800 border-gray-600 text-white"
                        placeholder="0"
                      />
                    </div>
                  </div>
                  <div className="mb-4">
                    <Label className="text-gray-300">Admin Note</Label>
                    <Textarea
                      value={newOptionData.note || ''}
                      onChange={(f) => setNewOptionData({ ...newOptionData, note: e.target.value })}
                      className="bg-gray-800 border-gray-600 text-white"
                      placeholder="Additional notes about this option..."
                      rows={3}
                    />
                  </div>
                  
                  {/* Regulatory Notes Section */}
                  <div className="mb-4 p-4 border border-purple-400/30 rounded-lg bg-purple-400/5">
                    <Label className="text-purple-400 font-medium">Regulatory Notes</Label>
                    <Textarea
                      value={newOptionData.regulatory_notes || ''}
                      onChange={(e) => setNewOptionData({ ...newOptionData, regulatory_notes: e.target.value })}
                      className="bg-gray-800 border-gray-600 text-white mt-2"
                      placeholder="Enter regulatory context and references..."
                      rows={3}
                    />
                  </div>
                  
                  <Button
                    onClick={handleAddOption}
                    disabled={!newOptionData.option_text.trim() || !newOptionData.option_value.trim()}
                    className="bg-green-600 hover:bg-green-700 text-white"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Add Option
                  </Button>
                </div>
                
                {/* Existing Options */}
                <div className="space-y-3">
                  <h4 className="text-white font-semibold">Existing Options</h4>
                  {loadingOptions ? (
                    <div className="text-center py-8 text-gray-400">Loading options...</div>
                  ) : nodeOptions.length === 0 ? (
                    <p className="text-gray-400 text-sm">No options found for this node.</p>
                  ) : (
                    nodeOptions.map((option, index) => (
                      <div key={option.id} className="border border-gray-700 rounded-lg p-3 bg-gray-800/20">
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center gap-3">
                            <span className="text-amber-400 font-medium">Option {index + 1}</span>
                            <span className="text-white font-medium">{option.option_text}</span>
                            <Badge variant="outline" className="border-gray-500 text-gray-300">
                              {option.option_value}
                            </Badge>
                          </div>
                          <div className="flex items-center gap-2">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleDuplicateOption(option)}
                              className="text-blue-400 border-blue-500 hover:bg-blue-500/10"
                            >
                              <Copy className="w-3 h-3 mr-1" />
                              DUPLICATE
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleEditOption(option)}
                              className="text-amber-400 border-amber-500 hover:bg-amber-500/10"
                            >
                              <Edit className="w-3 h-3 mr-1" />
                              EDIT
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleDeleteOption(option.id)}
                              className="text-red-400 border-red-500 hover:bg-red-500/10"
                            >
                              <Trash2 className="w-3 h-3 mr-1" />
                              Remove
                            </Button>
                          </div>
                        </div>
                        {option.routing_rule && (
                          <p className="text-gray-400 text-sm">Routes to: {option.routing_rule}</p>
                        )}
                        {option.note && (
                          <p className="text-gray-300 text-sm mt-1">
                            <span className="text-gray-500">Admin Note:</span> {option.note}
                          </p>
                        )}
                        {option.regulatory_notes && (
                          <p className="text-purple-300 text-sm mt-1">
                            <span className="text-purple-400">Regulatory Notes:</span> {option.regulatory_notes}
                          </p>
                        )}
                      </div>
                    ))
                  )}
                </div>
              </div>
              
              <DialogFooter>
                <Button
                  variant="outline"
                  onClick={() => setShowOptionsDialog(false)}
                  className="text-gray-300 border-gray-600 hover:bg-gray-700"
                >
                  Close
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>

          {/* Edit Option Dialog */}
          <Dialog open={showEditOptionDialog} onOpenChange={setShowEditOptionDialog}>
            <DialogContent className="bg-gray-900 border-gray-700 text-white max-w-2xl">
              <DialogHeader>
                <DialogTitle className="text-amber-400">Edit Option</DialogTitle>
                <DialogDescription className="text-gray-400">
                  Modify option for: {selectedNodeForOptions?.node_key} - {selectedNodeForOptions?.title}
                </DialogDescription>
              </DialogHeader>
              
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label className="text-gray-300">Option Text *</Label>
                    <Input
                      value={editOptionData.option_text}
                      onChange={(e) => setEditOptionData({ ...editOptionData, option_text: e.target.value })}
                      className="bg-gray-800 border-gray-600 text-white"
                      placeholder="e.g., Yes, No, Not Applicable"
                    />
                  </div>
                  <div>
                    <Label className="text-gray-300">Option Value *</Label>
                    <Input
                      value={editOptionData.option_value}
                      onChange={(e) => setEditOptionData({ ...editOptionData, option_value: e.target.value })}
                      className="bg-gray-800 border-gray-600 text-white"
                      placeholder="e.g., yes, no, na"
                    />
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label className="text-gray-300">Routing Rule</Label>
                    <Input
                      value={editOptionData.routing_rule}
                      onChange={(e) => setEditOptionData({ ...editOptionData, routing_rule: e.target.value })}
                      className="bg-gray-800 border-gray-600 text-white"
                      placeholder="{'->'} node_key or outcome: code; continue: target"
                    />
                  </div>
                  <div>
                    <Label className="text-gray-300">Display Order</Label>
                    <Input
                      type="number"
                      min="0"
                      value={editOptionData.display_order}
                      onChange={(e) => setEditOptionData({ ...editOptionData, display_order: parseInt(e.target.value) || 0 })}
                      className="bg-gray-800 border-gray-600 text-white"
                      placeholder="0"
                    />
                  </div>
                </div>
                
                <div>
                  <Label className="text-gray-300">Admin Note</Label>
                  <Textarea
                    value={editOptionData.note || ''}
                    onChange={(e) => setEditOptionData({ ...editOptionData, note: e.target.value })}
                    className="bg-gray-800 border-gray-600 text-white"
                    placeholder="Additional notes about this option..."
                    rows={3}
                  />
                </div>
                
                {/* Regulatory Notes Section */}
                <div className="p-4 border border-purple-400/30 rounded-lg bg-purple-400/5">
                  <Label className="text-purple-400 font-medium">Regulatory Notes</Label>
                  <Textarea
                    value={editOptionData.regulatory_notes || ''}
                    onChange={(e) => setEditOptionData({ ...editOptionData, regulatory_notes: e.target.value })}
                    className="bg-gray-800 border-gray-600 text-white mt-2"
                    placeholder="Enter regulatory context and references..."
                    rows={3}
                  />
                </div>
              </div>
              
              <DialogFooter>
                <Button
                  variant="outline"
                  onClick={() => setShowEditOptionDialog(false)}
                  className="border-gray-600 text-gray-300 hover:bg-gray-700 hover:text-white"
                >
                  Cancel
                </Button>
                <Button
                  onClick={handleUpdateOption}
                  className="bg-amber-600 hover:bg-amber-700 text-white"
                  disabled={!editOptionData.option_text.trim() || !editOptionData.option_value.trim()}
                >
                  Update Option
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>

          {/* Create Node Dialog - Matching Product Classification design */}
          {showCreateNodeDialog && (
            <Dialog open={showCreateNodeDialog} onOpenChange={setShowCreateNodeDialog}>
              <DialogContent className="bg-gray-900 border-gray-700 text-white max-w-1xl">
                <DialogHeader>
                  <DialogTitle className="text-amber-400">Add Node</DialogTitle>
                  <DialogDescription className="text-gray-400">
                    Add a new decision point to the sanctions tree
                  </DialogDescription>
                </DialogHeader>
                
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label className="text-gray-300">Node Key</Label>
                      <Input
                        value={newNodeData.node_key}
                        onChange={(e) => setNewNodeData({ ...newNodeData, node_key: e.target.value })}
                        className="bg-gray-800 border-gray-600 text-white"
                        placeholder="e.g., SAN001, 1.1"
                      />
                    </div>
                    <div>
                      <Label className="text-gray-300">Question Type</Label>
                      <Select
                        value={newNodeData.question_type}
                        onValueChange={(value) => setNewNodeData({ ...newNodeData, question_type: value as any })}
                      >
                        <SelectTrigger className="bg-gray-800 border-gray-600 text-white">
                          <SelectValue placeholder="Select type" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="multiple_choice">Multiple Choice</SelectItem>
                          <SelectItem value="yes_no">Yes/No</SelectItem>
                          <SelectItem value="text_input">Text Input</SelectItem>
                          <SelectItem value="numeric">Numeric</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div>
                    <Label className="text-gray-300">Title</Label>
                    <Input
                      value={newNodeData.title}
                      onChange={(e) => setNewNodeData({ ...newNodeData, title: e.target.value })}
                      className="bg-gray-800 border-gray-600 text-white"
                      placeholder="Brief title for this decision node"
                    />
                  </div>
                  <div>
                    <Label className="text-gray-300">Question Text</Label>
                    <Textarea
                      value={newNodeData.question_text}
                      onChange={(e) => setNewNodeData({ ...newNodeData, question_text: e.target.value })}
                      className="bg-gray-800 border-gray-600 text-white"
                      placeholder="What question should be asked at this decision point?"
                      rows={3}
                    />
                  </div>
                  <div>
                    <Label className="text-gray-300">Description</Label>
                    <Textarea
                      value={newNodeData.description || ''}
                      onChange={(e) => setNewNodeData({ ...newNodeData, description: e.target.value })}
                      className="bg-gray-800 border-gray-600 text-white"
                      placeholder="Additional context or guidance for this decision point"
                      rows={2}
                    />
                  </div>
                </div>

                <DialogFooter>
                  <Button
                    variant="outline"
                    onClick={() => setShowCreateNodeDialog(false)}
                    className="text-gray-300 border-gray-600 hover:bg-gray-700"
                    disabled={creatingNode}
                  >
                    Cancel
                  </Button>
                  <Button
                    onClick={handleCreateNode}
                    className="bg-amber-600 hover:bg-amber-700 text-white"
                    disabled={creatingNode || !newNodeData.node_key.trim() || !newNodeData.title.trim() || !newNodeData.question_text.trim()}
                  >
                    {creatingNode ? 'Creating...' : 'Add Node'}
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          )}
          
          {/* Create Tree Dialog */}
          <Dialog open={showCreateTreeDialog} onOpenChange={setShowCreateTreeDialog}>
            <DialogContent className="bg-gray-900 border-gray-700 text-white max-w-4xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle className="text-amber-400">Create Decision Tree</DialogTitle>
                <DialogDescription className="text-gray-400">
                  Add a new decision tree
                </DialogDescription>
              </DialogHeader>
              
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-gray-300">Name *</label>
                    <Input
                      value={newTreeData.name}
                      onChange={(e) => setNewTreeData({ ...newTreeData, name: e.target.value })}
                      className="bg-gray-900/50 border-gray-600 text-white placeholder:text-gray-400 focus:border-amber-500"
                      placeholder="Tree name"
                    />
                    <p className="text-xs text-gray-400">Short, clear name for the tree (max 500 characters)</p>
                  </div>
                  
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-gray-300">Description</label>
                    <Textarea
                      value={newTreeData.description}
                      onChange={(e) => setNewTreeData({ ...newTreeData, description: e.target.value })}
                      className="bg-gray-900/50 border-gray-600 text-white placeholder:text-gray-400 focus:border-amber-500"
                      placeholder="Optional description or additional context"
                      rows={3}
                    />
                    <p className="text-xs text-gray-400">Additional context or explanation for the tree</p>
                  </div>
                  
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-gray-300">Jurisdiction</label>
                    <Input
                      value={newTreeData.jurisdiction}
                      onChange={(e) => setNewTreeData({ ...newTreeData, jurisdiction: e.target.value })}
                      className="bg-gray-900/50 border-gray-600 text-white placeholder:text-gray-400 focus:border-amber-500"
                      placeholder="i.e., United States"
                    />
                    <p className="text-xs text-gray-400">The jurisdiction associated with the tree</p>
                  </div>
                  
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-gray-300">Category</label>
                    <Input
                      value={newTreeData.category}
                      onChange={(e) => setNewTreeData({ ...newTreeData, category: e.target.value })}
                      className="bg-gray-900/50 border-gray-600 text-white placeholder:text-gray-400 focus:border-amber-500"
                      placeholder="e.g., Sanctions"
                    />
                    <p className="text-xs text-gray-400">The category associated with the tree</p>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex items-center space-x-2 mt-6">
                      <Checkbox
                        id="is-introduction-template"
                        checked={newTreeData.is_introduction_template}
                        onCheckedChange={(checked) => setNewTreeData({ ...newTreeData, is_introduction_template: !!checked })}
                        className="border-gray-600 text-amber-500"
                      />
                      <label htmlFor="is-introduction-template" className="text-sm font-medium text-gray-300 cursor-pointer">
                        Is Introduction Template
                      </label>
                    </div>
                    <p className="text-xs text-gray-400">Check if this tree is an introduction template</p>
                  </div>
                  
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-gray-300">Introduction Tree ID</label>
                    <Input
                      value={newTreeData.introduction_tree_id || ''}
                      onChange={(e) => setNewTreeData({ ...newTreeData, introduction_tree_id: e.target.value })}
                      className="bg-gray-900/50 border-gray-600 text-white placeholder:text-gray-400 focus:border-amber-500"
                      placeholder="e.g., 12345"
                    />
                    <p className="text-xs text-gray-400">The ID of the introduction tree</p>
                  </div>
                </div>
              </div>

              <div className="flex justify-end space-x-3 pt-4 border-t border-gray-700">
                <Button
                  variant="outline"
                  onClick={() => setShowCreateTreeDialog(false)}
                  className="border-gray-600 text-gray-300 hover:bg-gray-700 hover:text-white"
                  disabled={creatingTree}
                >
                  Cancel
                </Button>
                <Button
                  onClick={handleCreateTree}
                  className="bg-amber-600 hover:bg-amber-700 text-white"
                  disabled={creatingTree || !newTreeData.name.trim()}
                >
                  {creatingTree ? 'Creating...' : 'Create Tree'}
                </Button>
              </div>
            </DialogContent>
          </Dialog>

          {/* Edit Tree Dialog */}
          <Dialog open={showEditTreeDialog} onOpenChange={setShowEditTreeDialog}>
            <DialogContent className="bg-gray-900 border-gray-700 text-white max-w-4xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle className="text-amber-400">Edit Decision Tree</DialogTitle>
                <DialogDescription className="text-gray-400">
                  Edit the decision tree: {editingTree?.name}
                </DialogDescription>
              </DialogHeader>
              
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-gray-300">Name *</label>
                    <Input
                      value={editTreeData.name}
                      onChange={(e) => setEditTreeData({ ...editTreeData, name: e.target.value })}
                      className="bg-gray-900/50 border-gray-600 text-white placeholder:text-gray-400 focus:border-amber-500"
                      placeholder="Tree name"
                    />
                    <p className="text-xs text-gray-400">Short, clear name for the tree (max 500 characters)</p>
                  </div>
                  
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-gray-300">Description</label>
                    <Textarea
                      value={editTreeData.description}
                      onChange={(e) => setEditTreeData({ ...editTreeData, description: e.target.value })}
                      className="bg-gray-900/50 border-gray-600 text-white placeholder:text-gray-400 focus:border-amber-500"
                      placeholder="Optional description or additional context"
                      rows={3}
                    />
                    <p className="text-xs text-gray-400">Additional context or explanation for the tree</p>
                  </div>
                  
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-gray-300">Jurisdiction</label>
                    <Input
                      value={editTreeData.jurisdiction}
                      onChange={(e) => setEditTreeData({ ...editTreeData, jurisdiction: e.target.value })}
                      className="bg-gray-900/50 border-gray-600 text-white placeholder:text-gray-400 focus:border-amber-500"
                      placeholder="i.e., United States"
                    />
                    <p className="text-xs text-gray-400">The jurisdiction associated with the tree</p>
                  </div>
                  
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-gray-300">Category</label>
                    <Input
                      value={editTreeData.category}
                      onChange={(e) => setEditTreeData({ ...editTreeData, category: e.target.value })}
                      className="bg-gray-900/50 border-gray-600 text-white placeholder:text-gray-400 focus:border-amber-500"
                      placeholder="e.g., Sanctions"
                    />
                    <p className="text-xs text-gray-400">The category associated with the tree</p>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex items-center space-x-2 mt-6">
                      <Checkbox
                        id="is-introduction-template"
                        checked={editTreeData.is_introduction_template}
                        onCheckedChange={(checked) => setEditTreeData({ ...editTreeData, is_introduction_template: !!checked })}
                        className="border-gray-600 text-amber-500"
                      />
                      <label htmlFor="is-introduction-template" className="text-sm font-medium text-gray-300 cursor-pointer">
                        Is Introduction Template
                      </label>
                    </div>
                    <p className="text-xs text-gray-400">Check if this tree is an introduction template</p>
                  </div>
                  
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-gray-300">Introduction Tree ID</label>
                    <Input
                      value={editTreeData.introduction_tree_id || ''}
                      onChange={(e) => setEditTreeData({ ...editTreeData, introduction_tree_id: e.target.value })}
                      className="bg-gray-900/50 border-gray-600 text-white placeholder:text-gray-400 focus:border-amber-500"
                      placeholder="e.g., 12345"
                    />
                    <p className="text-xs text-gray-400">The ID of the introduction tree</p>
                  </div>
                </div>
              </div>

              <div className="flex justify-end space-x-3 pt-4 border-t border-gray-700">
                <Button
                  variant="outline"
                  onClick={() => setShowEditTreeDialog(false)}
                  className="border-gray-600 text-gray-300 hover:bg-gray-700 hover:text-white"
                  disabled={creatingTree}
                >
                  Cancel
                </Button>
                <Button
                  onClick={handleUpdateTree}
                  className="bg-amber-600 hover:bg-amber-700 text-white"
                  disabled={creatingTree || !editTreeData.name.trim()}
                >
                  {creatingTree ? 'Updating...' : 'Update Tree'}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </TabsContent>

        <TabsContent value="workflows" className="space-y-6">
          <SanctionsWorkflowsTab />
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default SanctionsManagement;
