import React, { useState, useEffect, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Separator } from '@/components/ui/separator';
import { useEditor, EditorContent } from '@tiptap/react';
import StarterKit from '@tiptap/starter-kit';
import Image from '@tiptap/extension-image';
import Link from '@tiptap/extension-link';
import Underline from '@tiptap/extension-underline';
import TextStyle from '@tiptap/extension-text-style';
import Color from '@tiptap/extension-color';
import { toast } from 'sonner';
import brain from 'brain';
import {
  Save,
  FileText,
  Tag,
  Calendar,
  Globe,
  Building,
  Users,
  Activity,
  TrendingUp,
  Book,
  Lightbulb,
  Target,
  Zap,
  BookOpen,
  PenTool,
  Bold,
  Italic,
  Underline as UnderlineIcon,
  List,
  ListOrdered,
  Quote,
  ImageIcon,
  Loader2,
  Plus,
  X,
  Upload,
  Maximize,
  Minimize,
  Link as LinkIcon,
  Minus,
  Eye,
  Settings,
  Camera
} from 'lucide-react';
import { AdminDocumentResponse, AdminDocumentCreate } from 'types';
import { useUserGuardContext } from 'app/auth';
import { API_URL } from 'app';

interface Template {
  id: number;
  title: string;
  description?: string;
  content: string;
  category: string;
  created_at: string;
  updated_at: string;
}

interface DocumentAuthoringEditorProps {
  onSaveDocument?: () => void;
  existingDocument?: AdminDocumentResponse | null;
  onNavigateBack?: () => void;
}

// Multi-select component for metadata fields
interface ComboboxMultiSelectProps {
  options: { value: string; display_name: string }[];
  value: string[];
  onChange: (values: string[]) => void;
  placeholder: string;
  label: string;
  searchPlaceholder?: string;
  emptyMessage?: string;
  allowMultiple?: boolean;
}

export default function DocumentAuthoringEditor({ 
  onSaveDocument, 
  existingDocument = null, 
  onNavigateBack 
}: DocumentAuthoringEditorProps) {
  const { user } = useUserGuardContext();
  const [isLoading, setIsLoading] = useState(false);
  const [showCreateTemplateDialog, setShowCreateTemplateDialog] = useState(false);
  const [showImageDialog, setShowImageDialog] = useState(false);
  const [templates, setTemplates] = useState<Template[]>([]);
  const [wordCount, setWordCount] = useState(0);
  const [charCount, setCharCount] = useState(0);
  const [readingTime, setReadingTime] = useState(1);
  const [focusMode, setFocusMode] = useState(false);
  const [dragActive, setDragActive] = useState(false);
  
  const [documentData, setDocumentData] = useState<AdminDocumentCreate>({
    title: existingDocument?.title || '',
    description: existingDocument?.description || '',
    content: existingDocument?.content || '<p>Start writing your amazing blog article...</p>',
    country_jurisdiction: existingDocument?.country_jurisdiction || [],
    regulation_type: existingDocument?.regulation_type || [],
    subject: existingDocument?.subject || [],
    tags: existingDocument?.tags || [],
    category: existingDocument?.category || 'export-control',
    effective_date: existingDocument?.effective_date || '',
    source: existingDocument?.source || ''
  });
  
  const [newTag, setNewTag] = useState('');
  const [content, setContent] = useState(documentData.content);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [imageUrl, setImageUrl] = useState('');
  const [imageAlt, setImageAlt] = useState('');
  const [uploadingImage, setUploadingImage] = useState(false);

  // Add missing template state
  const [showTemplateDialog, setShowTemplateDialog] = useState(false);
  const [showLinkDialog, setShowLinkDialog] = useState(false);
  const [linkUrl, setLinkUrl] = useState('');
  const [linkText, setLinkText] = useState('');
  const [newTemplate, setNewTemplate] = useState({
    title: '',
    description: '',
    category: ''
  });

  // TipTap Editor Setup with Image extension
  const editor = useEditor({
    extensions: [
      StarterKit.configure({
        paragraph: {
          HTMLAttributes: {
            class: 'my-2',
          },
        },
        heading: {
          levels: [1, 2, 3, 4, 5, 6],
          HTMLAttributes: {
            class: 'font-bold text-white',
          },
        },
        hardBreak: {
          HTMLAttributes: {
            class: 'my-1',
          },
        },
      }),
      Image.configure({
        HTMLAttributes: {
          class: 'max-w-full h-auto rounded-lg shadow-lg my-4',
        },
      }),
      Link.configure({
        openOnClick: false,
        HTMLAttributes: {
          class: 'text-blue-400 underline hover:text-blue-300 cursor-pointer',
        },
      }),
      Underline,
      TextStyle,
      Color,
    ],
    content: documentData.content || '<p>Start writing your amazing blog article...</p>',
    onUpdate: ({ editor }) => {
      const html = editor.getHTML();
      setDocumentData(prev => ({ ...prev, content: html }));
      setContent(html);
      
      // Update statistics
      const plainText = editor.getText();
      const words = plainText.trim() ? plainText.trim().split(/\s+/).length : 0;
      const chars = plainText.length;
      const readingTimeCalc = Math.max(1, Math.ceil(words / 200)); // 200 WPM average
      
      setWordCount(words);
      setCharCount(chars);
      setReadingTime(readingTimeCalc);
    },
    editorProps: {
      attributes: {
        class: 'prose prose-invert prose-xl max-w-none focus:outline-none min-h-[600px] p-8 leading-relaxed text-gray-100',
        style: 'color: #f1f5f9 !important; line-height: 1.8; font-size: 18px;'
      },
      handleKeyDown: (view, event) => {
        // Ensure Enter key works properly
        if (event.key === 'Enter' && !event.shiftKey) {
          // Let TipTap handle the Enter key normally
          return false;
        }
        return false;
      },
      handlePaste: (view, event, slice) => {
        // Ensure pasted content is visible
        const transaction = view.state.tr.replaceSelection(slice);
        view.dispatch(transaction);
        return true;
      },
    },
    parseOptions: {
      preserveWhitespace: 'full',
    },
    editable: true,
    autofocus: false,
  });

  // Update editor content when documentData changes
  useEffect(() => {
    if (editor && documentData.content !== editor.getHTML()) {
      editor.commands.setContent(documentData.content || '<p>Start writing your amazing blog article...</p>');
    }
  }, [editor, documentData.content]);

  // Missing functionality implementations
  const handleSaveDocument = async () => {
    if (!documentData.title.trim()) {
      toast.error('Please enter a title for your article');
      return;
    }

    setIsLoading(true);
    try {
      // Create a text file with the article content
      const htmlContent = editor?.getHTML() || '';
      const textContent = editor?.getText() || '';
      
      // Create metadata for the document
      const metadata = {
        title: documentData.title,
        description: documentData.description,
        country_jurisdiction: documentData.country_jurisdiction,
        regulation_type: documentData.regulation_type,
        subject: documentData.subject,
        tags: documentData.tags.join(', '), // Convert array to string
        category: documentData.category,
        effective_date: documentData.effective_date || null,
        source: documentData.source || 'Blog Article',
        status: 'draft',
        file_type: 'authored',
        content_html: htmlContent,
        content_text: textContent
      };
      
      // Create a blob with the HTML content
      const blob = new Blob([htmlContent], { type: 'text/html' });
      const file = new File([blob], `${documentData.title.replace(/[^a-z0-9]/gi, '_').toLowerCase()}.html`, {
        type: 'text/html'
      });
      
      const uploadData = {
        file: file,
        metadata: JSON.stringify(metadata)
      };
      
      const response = await brain.upload_document(uploadData);
      
      if (response.ok) {
        toast.success('Article saved successfully!');
        
        if (onSaveDocument) {
          onSaveDocument();
        }
      } else {
        const errorData = await response.json().catch(() => ({ detail: 'Failed to save article' }));
        throw new Error(errorData.detail || 'Failed to save article');
      }
    } catch (error) {
      console.error('Save error:', error);
      toast.error(error instanceof Error ? error.message : 'Failed to save article. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const addTag = () => {
    if (newTag.trim() && !documentData.tags.includes(newTag.trim())) {
      setDocumentData(prev => ({
        ...prev,
        tags: [...prev.tags, newTag.trim()]
      }));
      setNewTag('');
    }
  };

  const removeTag = (index: number) => {
    setDocumentData(prev => ({
      ...prev,
      tags: prev.tags.filter((_, i) => i !== index)
    }));
  };

  const handleImageUpload = async (file?: File) => {
    const fileToUpload = file || selectedFile;
    
    if (!fileToUpload) {
      toast.error('Please select an image file');
      return;
    }

    setUploadingImage(true);
    try {
      console.log('🖼️ DocumentAuthor: Starting image upload:', fileToUpload.name, 'Size:', fileToUpload.size, 'Type:', fileToUpload.type);
      
      // Upload image to server using the new API
      const response = await brain.upload_image({ file: fileToUpload });
      
      if (response.ok) {
        const imageData = await response.json();
        console.log('🖼️ DocumentAuthor: Image upload response:', imageData);
        
        // Insert image into editor with the server URL
        if (editor && !editor.isDestroyed) {
          // Remove the leading /routes since API_URL already includes the routes path
          const cleanImageUrl = imageData.image_url.startsWith('/routes') ? imageData.image_url.substring('/routes'.length) : imageData.image_url;
          const fullImageUrl = imageData.image_url.startsWith('http') ? imageData.image_url : `${API_URL}${cleanImageUrl}`;
          
          console.log('🖼️ DocumentAuthor: Setting image URL:', fullImageUrl);
          
          editor.chain().focus().setImage({
            src: fullImageUrl,
            alt: imageAlt || fileToUpload.name
          }).run();
        }
        
        toast.success('Image added successfully!');
        setShowImageDialog(false);
        setSelectedFile(null);
        setImageUrl('');
        setImageAlt('');
      } else {
        const errorText = await response.text();
        console.error('🖼️ DocumentAuthor: Upload failed with status:', response.status, 'Error:', errorText);
        throw new Error(`Upload failed: ${response.status} - ${errorText}`);
      }
    } catch (error) {
      console.error('🖼️ DocumentAuthor: Image upload error:', error);
      toast.error('Failed to add image. Please try again.');
    } finally {
      setUploadingImage(false);
    }
  };

  const handleDragEnter = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    const files = e.dataTransfer.files;
    if (files && files[0]) {
      handleImageUpload(files[0]);
    }
  };

  // Reset function for form state
  const resetForm = () => {
    setDocumentData({
      title: '',
      description: '',
      category: 'export-control',
      source: 'Blog Article',
      content: '<p>Start writing your amazing blog article...</p>',
      tags: [],
      country_jurisdiction: [],
      regulation_type: [],
      subject: [],
      effective_date: null,
      version: '1.0', // Add missing version field
      author: '', // Add missing author field
      status: 'draft' // Add missing status field
    });
    setContent('<p>Start writing your amazing blog article...</p>');
    setNewTag('');
    setSelectedFile(null);
    setImageUrl('');
    setImageAlt('');
    setWordCount(0);
    setCharCount(0);
    setReadingTime(0);
    editor?.commands.setContent('<p>Start writing your amazing blog article...</p>');
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setSelectedFile(file);
    }
  };

  // Update word count, char count, and reading time
  useEffect(() => {
    const plainText = documentData.content.replace(/<[^>]*>/g, '');
    const words = plainText.trim() ? plainText.trim().split(/\s+/).length : 0;
    const chars = plainText.length;
    const readingTimeCalc = Math.max(1, Math.ceil(words / 200)); // 200 WPM average
    
    setWordCount(words);
    setCharCount(chars);
    setReadingTime(readingTimeCalc);
  }, [documentData.content]);

  // Sample templates
  useEffect(() => {
    setTemplates([
      {
        id: 1,
        title: 'Export Control Overview',
        description: 'Template for explaining export control concepts',
        content: '<h1>Understanding Export Controls</h1><p>Export controls are...</p>',
        category: 'Educational'
      },
      {
        id: 2,
        title: 'Compliance Guide',
        description: 'Step-by-step compliance template',
        content: '<h1>Compliance Guide</h1><h2>Step 1: Assessment</h2><p>Begin by...</p>',
        category: 'Guide'
      },
      {
        id: 3,
        title: 'News Update',
        description: 'Template for regulatory news updates',
        content: '<h1>Regulatory Update</h1><p><strong>Date:</strong> [Date]</p><p><strong>Summary:</strong> [Summary]</p>',
        category: 'News'
      }
    ]);
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-purple-900">
      {/* Modern Header Bar */}
      <div className="sticky top-0 z-50 bg-black/20 backdrop-blur-xl border-b border-white/10">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-blue-600 rounded-xl flex items-center justify-center">
                  <PenTool className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h1 className="text-xl font-bold text-white">Write Your Story</h1>
                  <p className="text-sm text-gray-400">Professional Blog Editor</p>
                </div>
              </div>
            </div>
            
            <div className="flex items-center gap-3">
              {/* Auto-save indicator */}
              <div className="flex items-center gap-2 px-3 py-1.5 bg-emerald-500/20 rounded-full border border-emerald-500/30">
                <div className="w-2 h-2 bg-emerald-400 rounded-full animate-pulse"></div>
                <span className="text-sm text-emerald-300 font-medium">Auto-saved</span>
              </div>
              
              {/* Focus Mode Toggle */}
              <Button
                onClick={() => setFocusMode(!focusMode)}
                variant="ghost"
                size="sm"
                className={`text-gray-300 hover:text-white transition-all duration-200 ${
                  focusMode ? 'bg-blue-500/20 text-blue-300' : ''
                }`}
              >
                <Eye className="w-4 h-4 mr-2" />
                Focus Mode
              </Button>
              
              {/* Save Button */}
              <Button
                onClick={handleSaveDocument}
                disabled={isLoading}
                className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white border-0 shadow-lg shadow-purple-500/25"
              >
                {isLoading ? (
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                ) : (
                  <Save className="w-4 h-4 mr-2" />
                )}
                {isLoading ? 'Saving...' : 'Save Article'}
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="max-w-7xl mx-auto px-6 py-8">
        <div className="grid grid-cols-12 gap-8">
          
          {/* Left Sidebar - Article Settings */}
          <div className="col-span-3">
            <Card className="bg-gray-900/40 backdrop-blur-xl border border-gray-700/30 shadow-2xl shadow-blue-500/10 ring-1 ring-gray-700/50">
              <CardHeader className="border-b border-gray-700/50 bg-gradient-to-r from-gray-800/60 to-gray-900/60 backdrop-blur-sm">
                <CardTitle className="text-gray-100 flex items-center gap-2 text-lg font-semibold">
                  <div className="w-8 h-8 bg-gradient-to-br from-blue-500/80 to-purple-600/80 rounded-lg flex items-center justify-center shadow-lg">
                    <Settings className="w-4 h-4 text-white" />
                  </div>
                  Article Settings
                </CardTitle>
                <CardDescription className="text-gray-400 mt-1">
                  Configure your blog article
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6 p-6 bg-gradient-to-b from-gray-900/20 to-gray-900/40 backdrop-blur-sm">
                {/* Article Title */}
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-3 flex items-center gap-2">
                    <div className="w-2 h-2 bg-blue-400 rounded-full"></div>
                    Title *
                  </label>
                  <Input
                    value={documentData.title}
                    onChange={(e) => setDocumentData(prev => ({ ...prev, title: e.target.value }))}
                    placeholder="Your amazing article title..."
                    className="bg-gray-800/60 backdrop-blur-sm border-gray-600/50 text-gray-100 placeholder:text-gray-500 focus:border-blue-400/70 focus:ring-blue-400/20 focus:ring-2 transition-all duration-200 shadow-inner"
                  />
                </div>

                {/* Article Description */}
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-3 flex items-center gap-2">
                    <div className="w-2 h-2 bg-purple-400 rounded-full"></div>
                    Description
                  </label>
                  <Textarea
                    value={documentData.description}
                    onChange={(e) => setDocumentData(prev => ({ ...prev, description: e.target.value }))}
                    placeholder="Brief description of your article..."
                    rows={3}
                    className="bg-gray-800/60 backdrop-blur-sm border-gray-600/50 text-gray-100 placeholder:text-gray-500 focus:border-purple-400/70 focus:ring-purple-400/20 focus:ring-2 transition-all duration-200 shadow-inner resize-none"
                  />
                </div>

                {/* Tags Input */}
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-3 flex items-center gap-2">
                    <div className="w-2 h-2 bg-emerald-400 rounded-full"></div>
                    Tags
                  </label>
                  <div className="flex flex-wrap gap-2 mb-3 min-h-[32px] p-2 bg-gray-800/30 rounded-lg border border-gray-700/50">
                    {documentData.tags.map((tag, index) => (
                      <Badge key={index} className="bg-blue-500/20 hover:bg-blue-500/30 text-blue-300 border border-blue-500/40 px-2 py-1 transition-all duration-200 shadow-sm">
                        {tag}
                        <button
                          onClick={() => removeTag(index)}
                          className="ml-2 text-blue-300 hover:text-red-400 transition-colors duration-200"
                        >
                          ×
                        </button>
                      </Badge>
                    ))}
                    {documentData.tags.length === 0 && (
                      <span className="text-gray-500 text-sm italic">No tags added yet</span>
                    )}
                  </div>
                  <div className="flex gap-2">
                    <Input
                      value={newTag}
                      onChange={(e) => setNewTag(e.target.value)}
                      onKeyPress={(e) => e.key === 'Enter' && addTag()}
                      placeholder="Add tag..."
                      className="bg-gray-800/60 backdrop-blur-sm border-gray-600/50 text-gray-100 placeholder:text-gray-500 focus:border-emerald-400/70 focus:ring-emerald-400/20 focus:ring-2 transition-all duration-200"
                    />
                    <Button
                      onClick={addTag}
                      size="sm"
                      className="bg-gradient-to-r from-emerald-600 to-emerald-700 hover:from-emerald-700 hover:to-emerald-800 text-white shadow-lg transition-all duration-200 hover:shadow-xl"
                    >
                      <Plus className="w-4 h-4" />
                    </Button>
                  </div>
                </div>

                {/* Writing Statistics */}
                <div className="space-y-4 pt-4 border-t border-gray-700/50">
                  <h4 className="text-sm font-semibold text-gray-300 flex items-center gap-2">
                    <div className="w-2 h-2 bg-amber-400 rounded-full"></div>
                    Writing Statistics
                  </h4>
                  <div className="grid grid-cols-1 gap-3">
                    <div className="bg-gradient-to-br from-gray-800/60 to-gray-900/60 backdrop-blur-sm rounded-xl p-4 border border-gray-700/40 shadow-lg hover:shadow-blue-500/10 transition-all duration-300">
                      <div className="text-2xl font-bold text-blue-400 mb-1">{wordCount}</div>
                      <div className="text-xs text-gray-500 uppercase tracking-wider">Words</div>
                    </div>
                    <div className="bg-gradient-to-br from-gray-800/60 to-gray-900/60 backdrop-blur-sm rounded-xl p-4 border border-gray-700/40 shadow-lg hover:shadow-purple-500/10 transition-all duration-300">
                      <div className="text-2xl font-bold text-purple-400 mb-1">{charCount}</div>
                      <div className="text-xs text-gray-500 uppercase tracking-wider">Characters</div>
                    </div>
                    <div className="bg-gradient-to-br from-gray-800/60 to-gray-900/60 backdrop-blur-sm rounded-xl p-4 border border-gray-700/40 shadow-lg hover:shadow-emerald-500/10 transition-all duration-300">
                      <div className="text-2xl font-bold text-emerald-400 mb-1">{readingTime}</div>
                      <div className="text-xs text-gray-500 uppercase tracking-wider">Min read</div>
                    </div>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="space-y-3 pt-4 border-t border-gray-700/50">
                  <Button
                    onClick={handleSaveDocument}
                    disabled={isLoading}
                    className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white font-medium shadow-lg hover:shadow-xl transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {isLoading ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        Saving...
                      </>
                    ) : (
                      <>
                        <Save className="w-4 h-4 mr-2" />
                        Save Article
                      </>
                    )}
                  </Button>
                  
                  <div className="grid grid-cols-2 gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setShowTemplateDialog(true)}
                      className="border-gray-600/50 text-gray-300 hover:bg-gray-700/60 hover:text-white transition-all duration-200 backdrop-blur-sm"
                    >
                      <FileText className="w-4 h-4 mr-1" />
                      Templates
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setShowImageDialog(true)}
                      className="border-gray-600/50 text-gray-300 hover:bg-gray-700/60 hover:text-white transition-all duration-200 backdrop-blur-sm"
                    >
                      <Camera className="w-4 h-4 mr-1" />
                      Add Image
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Main Editor Area */}
          <div className="col-span-9">
            <Card className="bg-gray-900/40 backdrop-blur-xl border border-gray-700/30 shadow-2xl shadow-purple-500/10 ring-1 ring-gray-700/50 min-h-[600px]">
              <CardHeader className="border-b border-gray-700/50 bg-gradient-to-r from-gray-800/60 to-gray-900/60 backdrop-blur-sm">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-gray-100 flex items-center gap-3 text-xl font-semibold">
                    <div className="w-10 h-10 bg-gradient-to-br from-purple-500/80 to-blue-600/80 rounded-xl flex items-center justify-center shadow-lg">
                      <PenTool className="w-5 h-5 text-white" />
                    </div>
                    Write Your Story
                  </CardTitle>
                  <div className="flex items-center gap-3">
                    <Badge className="bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 px-3 py-1 shadow-sm">
                      ● Auto-saved
                    </Badge>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="p-0 bg-gradient-to-b from-gray-900/20 to-gray-800/40 backdrop-blur-sm">
                {/* Enhanced Toolbar */}
                <div className="border-b border-gray-700/50 bg-gradient-to-r from-gray-800/40 to-gray-900/40 backdrop-blur-sm p-4">
                  <div className="flex flex-wrap items-center gap-3">
                    {/* Heading Buttons */}
                    <div className="flex items-center gap-2 mr-6">
                      <span className="text-xs text-gray-400 font-medium mr-2">Headings:</span>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => editor?.chain().focus().toggleHeading({ level: 1 }).run()}
                        className={`h-10 px-4 font-medium text-sm bg-gray-800/60 backdrop-blur-sm border-gray-600/50 text-gray-300 hover:bg-gray-700/80 hover:text-white transition-all duration-200 shadow-sm ${editor?.isActive('heading', { level: 1 }) ? 'bg-blue-600/80 text-white border-blue-500/60 shadow-blue-500/20' : ''}`}
                      >
                        H1
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => editor?.chain().focus().toggleHeading({ level: 2 }).run()}
                        className={`h-10 px-4 font-medium text-sm bg-gray-800/60 backdrop-blur-sm border-gray-600/50 text-gray-300 hover:bg-gray-700/80 hover:text-white transition-all duration-200 shadow-sm ${editor?.isActive('heading', { level: 2 }) ? 'bg-blue-600/80 text-white border-blue-500/60 shadow-blue-500/20' : ''}`}
                      >
                        H2
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => editor?.chain().focus().toggleHeading({ level: 3 }).run()}
                        className={`h-10 px-4 font-medium text-sm bg-gray-800/60 backdrop-blur-sm border-gray-600/50 text-gray-300 hover:bg-gray-700/80 hover:text-white transition-all duration-200 shadow-sm ${editor?.isActive('heading', { level: 3 }) ? 'bg-blue-600/80 text-white border-blue-500/60 shadow-blue-500/20' : ''}`}
                      >
                        H3
                      </Button>
                    </div>

                    {/* Formatting Buttons */}
                    <div className="flex items-center gap-2 mr-6">
                      <span className="text-xs text-gray-400 font-medium mr-1">Format:</span>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => editor?.chain().focus().toggleBold().run()}
                        className={`h-10 w-12 bg-gray-800/60 backdrop-blur-sm border-gray-600/50 text-gray-300 hover:bg-gray-700/80 hover:text-white transition-all duration-200 shadow-sm ${editor?.isActive('bold') ? 'bg-purple-600/80 text-white border-purple-500/60 shadow-purple-500/20' : ''}`}
                        title="Bold (Ctrl+B)"
                      >
                        <Bold className="w-5 h-5" />
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => editor?.chain().focus().toggleItalic().run()}
                        className={`h-10 w-12 bg-gray-800/60 backdrop-blur-sm border-gray-600/50 text-gray-300 hover:bg-gray-700/80 hover:text-white transition-all duration-200 shadow-sm ${editor?.isActive('italic') ? 'bg-purple-600/80 text-white border-purple-500/60 shadow-purple-500/20' : ''}`}
                        title="Italic (Ctrl+I)"
                      >
                        <Italic className="w-5 h-5" />
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => editor?.chain().focus().toggleUnderline().run()}
                        className={`h-10 w-12 bg-gray-800/60 backdrop-blur-sm border-gray-600/50 text-gray-300 hover:bg-gray-700/80 hover:text-white transition-all duration-200 shadow-sm ${editor?.isActive('underline') ? 'bg-purple-600/80 text-white border-purple-500/60 shadow-purple-500/20' : ''}`}
                        title="Underline (Ctrl+U)"
                      >
                        <UnderlineIcon className="w-5 h-5" />
                      </Button>
                    </div>

                    {/* Color Controls */}
                    <div className="flex items-center gap-2 mr-6">
                      <span className="text-xs text-gray-400 font-medium mr-1">Colors:</span>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => editor?.chain().focus().setColor('#ffffff').run()}
                        className="h-10 w-12 bg-gray-800/60 backdrop-blur-sm border-gray-600/50 text-white hover:bg-gray-700/80 transition-all duration-200 shadow-sm"
                        title="White Text"
                      >
                        <div className="w-4 h-4 bg-white rounded border border-gray-400" />
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => editor?.chain().focus().setColor('#3b82f6').run()}
                        className="h-10 w-12 bg-gray-800/60 backdrop-blur-sm border-gray-600/50 text-gray-300 hover:bg-gray-700/80 transition-all duration-200 shadow-sm"
                        title="Blue Text"
                      >
                        <div className="w-4 h-4 bg-blue-500 rounded" />
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => editor?.chain().focus().setColor('#10b981').run()}
                        className="h-10 w-12 bg-gray-800/60 backdrop-blur-sm border-gray-600/50 text-gray-300 hover:bg-gray-700/80 transition-all duration-200 shadow-sm"
                        title="Green Text"
                      >
                        <div className="w-4 h-4 bg-green-500 rounded" />
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => editor?.chain().focus().setColor('#f59e0b').run()}
                        className="h-10 w-12 bg-gray-800/60 backdrop-blur-sm border-gray-600/50 text-gray-300 hover:bg-gray-700/80 transition-all duration-200 shadow-sm"
                        title="Yellow Text"
                      >
                        <div className="w-4 h-4 bg-yellow-500 rounded" />
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => editor?.chain().focus().setColor('#ef4444').run()}
                        className="h-10 w-12 bg-gray-800/60 backdrop-blur-sm border-gray-600/50 text-gray-300 hover:bg-gray-700/80 transition-all duration-200 shadow-sm"
                        title="Red Text"
                      >
                        <div className="w-4 h-4 bg-red-500 rounded" />
                      </Button>
                    </div>

                    {/* List Buttons */}
                    <div className="flex items-center gap-2 mr-6">
                      <span className="text-xs text-gray-400 font-medium mr-1">Lists:</span>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => editor?.chain().focus().toggleBulletList().run()}
                        className={`h-10 w-12 bg-gray-800/60 backdrop-blur-sm border-gray-600/50 text-gray-300 hover:bg-gray-700/80 hover:text-white transition-all duration-200 shadow-sm ${editor?.isActive('bulletList') ? 'bg-emerald-600/80 text-white border-emerald-500/60 shadow-emerald-500/20' : ''}`}
                        title="Bullet List"
                      >
                        <List className="w-5 h-5" />
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => editor?.chain().focus().toggleOrderedList().run()}
                        className={`h-10 w-12 bg-gray-800/60 backdrop-blur-sm border-gray-600/50 text-gray-300 hover:bg-gray-700/80 hover:text-white transition-all duration-200 shadow-sm ${editor?.isActive('orderedList') ? 'bg-emerald-600/80 text-white border-emerald-500/60 shadow-emerald-500/20' : ''}`}
                        title="Numbered List"
                      >
                        <ListOrdered className="w-5 h-5" />
                      </Button>
                    </div>

                    {/* Blockquote and Separator */}
                    <div className="flex items-center gap-2 mr-6">
                      <span className="text-xs text-gray-400 font-medium mr-1">Special:</span>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => editor?.chain().focus().toggleBlockquote().run()}
                        className={`h-10 w-12 bg-gray-800/60 backdrop-blur-sm border-gray-600/50 text-gray-300 hover:bg-gray-700/80 hover:text-white transition-all duration-200 shadow-sm ${editor?.isActive('blockquote') ? 'bg-amber-600/80 text-white border-amber-500/60 shadow-amber-500/20' : ''}`}
                        title="Quote"
                      >
                        <Quote className="w-5 h-5" />
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => editor?.chain().focus().setHorizontalRule().run()}
                        className="h-10 w-12 bg-gray-800/60 backdrop-blur-sm border-gray-600/50 text-gray-300 hover:bg-gray-700/80 hover:text-white transition-all duration-200 shadow-sm"
                        title="Horizontal Line"
                      >
                        <Minus className="w-5 h-5" />
                      </Button>
                    </div>

                    {/* Image Button */}
                    <div className="flex items-center gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => setShowImageDialog(true)}
                        className="h-10 px-4 bg-gray-800/60 backdrop-blur-sm border-gray-600/50 text-gray-300 hover:bg-gray-700/80 hover:text-white transition-all duration-200 shadow-sm hover:shadow-lg"
                        title="Add Image"
                      >
                        <ImageIcon className="w-5 h-5 mr-2" />
                        Add Image
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => {
                          const { from, to } = editor?.state.selection || { from: 0, to: 0 };
                          const selectedText = editor?.state.doc.textBetween(from, to, '') || '';
                          setLinkText(selectedText);
                          setLinkUrl('');
                          setShowLinkDialog(true);
                        }}
                        className={`h-10 px-4 bg-gray-800/60 backdrop-blur-sm border-gray-600/50 text-gray-300 hover:bg-gray-700/80 hover:text-white transition-all duration-200 shadow-sm hover:shadow-lg ${editor?.isActive('link') ? 'bg-blue-600/80 text-white border-blue-500/60 shadow-blue-500/20' : ''}`}
                        title="Add Link"
                      >
                        <LinkIcon className="w-5 h-5 mr-2" />
                        Add Link
                      </Button>
                    </div>
                  </div>
                </div>

                {/* Editor Container with improved styling */}
                <div className="relative bg-gradient-to-b from-gray-900/40 to-gray-800/60 backdrop-blur-sm rounded-lg border border-gray-700/30 min-h-[600px]">
                  <EditorContent 
                    editor={editor}
                    className="prose prose-invert prose-xl max-w-none focus:outline-none min-h-[600px] p-8 leading-relaxed
                      [&_*]:!text-gray-100 [&_p]:!text-gray-100 [&_div]:!text-gray-100 [&_span]:!text-gray-100
                      [&_h1]:!text-white [&_h1]:!text-3xl [&_h1]:!font-bold [&_h1]:!mb-4 [&_h1]:!mt-6
                      [&_h2]:!text-white [&_h2]:!text-2xl [&_h2]:!font-bold [&_h2]:!mb-3 [&_h2]:!mt-5
                      [&_h3]:!text-white [&_h3]:!text-xl [&_h3]:!font-bold [&_h3]:!mb-2 [&_h3]:!mt-4
                      [&_strong]:!text-gray-100 [&_em]:!text-gray-100 [&_li]:!text-gray-100
                      [&_ul]:!text-gray-100 [&_ol]:!text-gray-100 [&_blockquote]:!text-gray-300
                      [&_code]:!text-gray-100 [&_pre]:!text-gray-100 [&_a]:!text-blue-400
                      [&_*[style*='color']]:!important
                      text-gray-100
                    "
                    style={{
                      color: '#f1f5f9 !important',
                      fontSize: '18px',
                      lineHeight: '1.8'
                    }}
                  />
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Enhanced Image Upload Dialog */}
      <Dialog open={showImageDialog} onOpenChange={setShowImageDialog}>
        <DialogContent className="bg-gray-900/95 backdrop-blur-xl border border-gray-700/50 text-white max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-xl font-semibold">
              <div className="w-8 h-8 bg-gradient-to-br from-emerald-500 to-blue-600 rounded-lg flex items-center justify-center">
                <ImageIcon className="w-4 h-4 text-white" />
              </div>
              Add Image to Article
            </DialogTitle>
            <DialogDescription className="text-gray-400">
              Upload an image to enhance your blog article
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-6 py-4">
            {/* File Upload Area */}
            <div className="space-y-4">
              <Label className="text-gray-300 font-medium">Select Image</Label>
              <div className="border-2 border-dashed border-gray-600/50 rounded-xl p-6 text-center bg-gray-800/30 hover:bg-gray-800/50 transition-all duration-200">
                <input
                  type="file"
                  accept="image/*"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) setSelectedFile(file);
                  }}
                  className="hidden"
                  id="image-upload"
                />
                <label htmlFor="image-upload" className="cursor-pointer">
                  <div className="space-y-3">
                    <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-600 rounded-xl flex items-center justify-center mx-auto">
                      <Upload className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <p className="text-white font-medium">Click to upload image</p>
                      <p className="text-sm text-gray-400">PNG, JPG, GIF up to 10MB</p>
                    </div>
                  </div>
                </label>
              </div>
              
              {selectedFile && (
                <div className="bg-gray-800/60 rounded-lg p-3">
                  <p className="text-sm text-gray-300">
                    <span className="font-medium">Selected:</span> {selectedFile.name}
                  </p>
                  <p className="text-xs text-gray-500">
                    {(selectedFile.size / 1024 / 1024).toFixed(2)} MB
                  </p>
                </div>
              )}
            </div>
            
            {/* Alt Text */}
            <div className="space-y-2">
              <Label htmlFor="image-alt" className="text-gray-300 font-medium">Alt Text (Optional)</Label>
              <Input
                id="image-alt"
                value={imageAlt}
                onChange={(e) => setImageAlt(e.target.value)}
                placeholder="Describe the image for accessibility..."
                className="bg-gray-800/60 border-gray-600/50 text-white placeholder:text-gray-500"
              />
            </div>
          </div>
          
          <DialogFooter className="gap-3">
            <Button
              variant="outline"
              onClick={() => setShowImageDialog(false)}
              className="border-gray-600/50 text-gray-300 hover:bg-gray-700/60"
            >
              Cancel
            </Button>
            <Button
              onClick={handleImageUpload}
              disabled={!selectedFile || uploadingImage}
              className="bg-gradient-to-r from-emerald-600 to-blue-600 hover:from-emerald-700 hover:to-blue-700 text-white"
            >
              {uploadingImage ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Uploading...
                </>
              ) : (
                <>
                  <Upload className="w-4 h-4 mr-2" />
                  Add to Article
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Template Dialog */}
      <Dialog open={showTemplateDialog} onOpenChange={setShowTemplateDialog}>
        <DialogContent className="bg-gray-900/95 backdrop-blur-xl border border-gray-700/50 text-white max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-xl font-semibold">
              <div className="w-8 h-8 bg-gradient-to-br from-purple-500 to-pink-600 rounded-lg flex items-center justify-center">
                <FileText className="w-4 h-4 text-white" />
              </div>
              Choose a Template
            </DialogTitle>
            <DialogDescription className="text-gray-400">
              Select a template to get started with your article
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            {/* Template Options */}
            <div className="space-y-3">
              <Button
                variant="outline"
                className="w-full justify-start text-left p-4 h-auto border-gray-600/50 hover:bg-gray-700/60"
                onClick={() => {
                  editor?.commands.setContent(`
                    <h1>Article Title</h1>
                    <p>Brief introduction that hooks the reader and explains what they'll learn...</p>
                    <h2>Key Point 1</h2>
                    <p>Detailed explanation of your first main point...</p>
                    <h2>Key Point 2</h2>
                    <p>Supporting details and examples...</p>
                    <h2>Conclusion</h2>
                    <p>Summarize the key takeaways and call to action...</p>
                  `);
                  setShowTemplateDialog(false);
                  toast.success('Blog article template applied!');
                }}
              >
                <div>
                  <div className="font-medium text-white">📰 Blog Article</div>
                  <div className="text-sm text-gray-400">Standard blog post structure</div>
                </div>
              </Button>
              
              <Button
                variant="outline"
                className="w-full justify-start text-left p-4 h-auto border-gray-600/50 hover:bg-gray-700/60"
                onClick={() => {
                  editor?.commands.setContent(`
                    <h1>How to: [Your Topic]</h1>
                    <p>Introduction explaining the problem and why this guide matters...</p>
                    <h2>What You'll Need</h2>
                    <ul><li>Item 1</li><li>Item 2</li><li>Item 3</li></ul>
                    <h2>Step 1: Getting Started</h2>
                    <p>Detailed instructions for the first step...</p>
                    <h2>Step 2: The Main Process</h2>
                    <p>Core instructions with examples...</p>
                    <h2>Step 3: Finishing Up</h2>
                    <p>Final steps and verification...</p>
                    <h2>Troubleshooting</h2>
                    <p>Common issues and solutions...</p>
                  `);
                  setShowTemplateDialog(false);
                  toast.success('How-to guide template applied!');
                }}
              >
                <div>
                  <div className="font-medium text-white">📋 How-To Guide</div>
                  <div className="text-sm text-gray-400">Step-by-step tutorial format</div>
                </div>
              </Button>
              
              <Button
                variant="outline"
                className="w-full justify-start text-left p-4 h-auto border-gray-600/50 hover:bg-gray-700/60"
                onClick={() => {
                  editor?.commands.setContent(`
                    <h1>Case Study: [Project Name]</h1>
                    <h2>Challenge</h2>
                    <p>Describe the problem or opportunity that needed to be addressed...</p>
                    <h2>Solution</h2>
                    <p>Explain the approach taken and why it was chosen...</p>
                    <h2>Implementation</h2>
                    <p>Details of how the solution was executed...</p>
                    <h2>Results</h2>
                    <ul><li>Key metric 1: Improvement</li><li>Key metric 2: Improvement</li><li>Key metric 3: Improvement</li></ul>
                    <h2>Lessons Learned</h2>
                    <p>Insights gained and recommendations for similar projects...</p>
                  `);
                  setShowTemplateDialog(false);
                  toast.success('Case study template applied!');
                }}
              >
                <div>
                  <div className="font-medium text-white">📊 Case Study</div>
                  <div className="text-sm text-gray-400">Professional case study format</div>
                </div>
              </Button>
            </div>
          </div>
          
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setShowTemplateDialog(false)}
              className="border-gray-600/50 text-gray-300 hover:bg-gray-700/60"
            >
              Cancel
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Link Dialog */}
      <Dialog open={showLinkDialog} onOpenChange={setShowLinkDialog}>
        <DialogContent className="bg-gray-900/95 backdrop-blur-xl border border-gray-700/50 shadow-2xl shadow-blue-500/10 ring-1 ring-gray-700/50">
          <DialogHeader>
            <DialogTitle className="text-xl font-semibold text-white flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-500/80 to-purple-600/80 rounded-xl flex items-center justify-center shadow-lg">
                <LinkIcon className="w-5 h-5 text-white" />
              </div>
              Add Link
            </DialogTitle>
            <DialogDescription className="text-gray-400">
              Create a link to external content or internal pages
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="linkText" className="text-gray-300 font-medium">Link Text</Label>
              <Input
                id="linkText"
                value={linkText}
                onChange={(e) => setLinkText(e.target.value)}
                placeholder="Enter the text to display"
                className="bg-gray-800/60 border-gray-600/50 text-white placeholder-gray-400 focus:border-blue-500/50 focus:ring-blue-500/20"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="linkUrl" className="text-gray-300 font-medium">URL</Label>
              <Input
                id="linkUrl"
                value={linkUrl}
                onChange={(e) => setLinkUrl(e.target.value)}
                placeholder="https://example.com"
                className="bg-gray-800/60 border-gray-600/50 text-white placeholder-gray-400 focus:border-blue-500/50 focus:ring-blue-500/20"
              />
            </div>
          </div>
          
          <DialogFooter className="flex gap-3">
            <Button
              variant="outline"
              onClick={() => {
                setShowLinkDialog(false);
                setLinkText('');
                setLinkUrl('');
              }}
              className="border-gray-600/50 text-gray-300 hover:bg-gray-700/60"
            >
              Cancel
            </Button>
            <Button
              onClick={() => {
                if (!linkUrl.trim()) {
                  toast.error('Please enter a URL');
                  return;
                }
                
                const url = linkUrl.startsWith('http') ? linkUrl : `https://${linkUrl}`;
                
                if (linkText.trim()) {
                  // Insert new link with custom text using proper TipTap command
                  editor?.chain().focus().insertContent(linkText).setLink({ href: url }).run();
                } else {
                  // Use URL as text if no custom text provided
                  editor?.chain().focus().insertContent(url).setLink({ href: url }).run();
                }
                
                setShowLinkDialog(false);
                setLinkText('');
                setLinkUrl('');
                toast.success('Link added successfully!');
              }}
              className="bg-blue-600 hover:bg-blue-700 text-white"
              disabled={!linkUrl.trim()}
            >
              <LinkIcon className="w-4 h-4 mr-2" />
              Add Link
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
