import React, { useState } from 'react';
import { SavedArticleResponse } from 'types';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  ExternalLink,
  BookmarkCheck,
  MoreHorizontal,
  Tag,
  Trash2,
  Calendar,
} from 'lucide-react';
import { getCategoryIcon } from 'utils/categoryUtils';
import { AssignCategoriesDialog } from 'components/AssignCategoriesDialog';

interface Props {
  article: SavedArticleResponse;
  onUnsave?: (articleId: number) => void;
  onCategoriesUpdated?: () => void;
}

export const SavedArticleCard: React.FC<Props> = ({
  article,
  onUnsave,
  onCategoriesUpdated
}) => {
  const [showCategoriesDialog, setShowCategoriesDialog] = useState(false);

  const handleUnsave = () => {
    if (confirm('Are you sure you want to remove this article from your saved collection?')) {
      onUnsave?.(article.id);
    }
  };

  const handleOpenArticle = () => {
    if (article.document_url) {
      window.open(article.document_url, '_blank');
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  };

  return (
    <>
      <Card className="bg-gray-800/40 backdrop-blur-sm border border-rose-500/20 hover:border-rose-400/40 transition-all group cursor-pointer hover:shadow-lg hover:shadow-rose-500/20 relative">
        <CardHeader className="pb-3">
          <div className="flex items-start justify-between">
            <div className="flex-1" onClick={handleOpenArticle}>
              <CardTitle className="text-sm font-semibold text-white group-hover:text-rose-200 transition-colors line-clamp-2">
                {article.document_title}
              </CardTitle>
              <div className="flex items-center gap-2 mt-2 text-xs text-gray-400">
                <Calendar className="w-3 h-3" />
                <span>Saved {formatDate(article.saved_at)}</span>
                {article.document_type && (
                  <>
                    <span>•</span>
                    <span className="capitalize">{article.document_type}</span>
                  </>
                )}
              </div>
            </div>
            
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  className="h-8 w-8 p-0 opacity-0 group-hover:opacity-100 transition-opacity"
                >
                  <MoreHorizontal className="w-4 h-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="bg-gray-800 border-gray-700">
                <DropdownMenuItem onClick={() => setShowCategoriesDialog(true)}>
                  <Tag className="w-4 h-4 mr-2" />
                  Manage Categories
                </DropdownMenuItem>
                {article.document_url && (
                  <DropdownMenuItem onClick={handleOpenArticle}>
                    <ExternalLink className="w-4 h-4 mr-2" />
                    Open Article
                  </DropdownMenuItem>
                )}
                <DropdownMenuItem 
                  onClick={handleUnsave}
                  className="text-red-400 focus:text-red-300"
                >
                  <Trash2 className="w-4 h-4 mr-2" />
                  Remove from Saved
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </CardHeader>
        
        <CardContent className="pt-0">
          {article.document_description && (
            <p className="text-sm text-gray-300 mb-3 line-clamp-2">
              {article.document_description}
            </p>
          )}
          
          {/* Categories */}
          <div className="flex flex-wrap gap-1">
            {article.categories && article.categories.length > 0 ? (
              article.categories.map((category) => {
                const IconComponent = getCategoryIcon(category.icon);
                return (
                  <Badge 
                    key={category.id} 
                    variant="secondary" 
                    className="text-xs flex items-center gap-1"
                    style={{ 
                      backgroundColor: `${category.color}20`,
                      color: category.color,
                      borderColor: `${category.color}40`
                    }}
                  >
                    <IconComponent className="w-3 h-3" />
                    {category.name}
                  </Badge>
                );
              })
            ) : (
              <Badge variant="outline" className="text-xs text-gray-500">
                Uncategorized
              </Badge>
            )}
          </div>

          {/* Action buttons */}
          <div className="flex items-center gap-2 mt-4">
            {article.document_url && (
              <Button 
                size="sm" 
                variant="outline"
                onClick={handleOpenArticle}
                className="flex-1 text-xs"
              >
                <ExternalLink className="w-3 h-3 mr-1" />
                Open
              </Button>
            )}
            <Button 
              size="sm" 
              variant="outline"
              onClick={() => setShowCategoriesDialog(true)}
              className="text-xs"
            >
              <Tag className="w-3 h-3 mr-1" />
              Categories
            </Button>
          </div>
        </CardContent>
      </Card>

      <AssignCategoriesDialog
        isOpen={showCategoriesDialog}
        onClose={() => setShowCategoriesDialog(false)}
        article={article}
        onCategoriesUpdated={onCategoriesUpdated}
      />
    </>
  );
};
