



import React, { useState, useEffect, useRef } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  Upload, 
  FileText, 
  X, 
  Check, 
  AlertCircle, 
  ChevronDown, 
  ChevronRight, 
  Clock, 
  Users, 
  Shield, 
  Calendar, 
  Tag, 
  FileCheck, 
  Settings, 
  Zap,
  Loader2,
  Download,
  Eye,
  Copy,
  Edit,
  Save,
  File,
  Image,
  Globe,
  Cpu,
  CheckCircle2
} from 'lucide-react';
import { cn } from 'utils/cn';
import brain from 'brain';
import { toast } from 'sonner';
import type { MetadataOption } from '../brain/data-contracts';
import ComboboxMultiSelect from './ComboboxMultiSelect';
import TagInput from './TagInput';

interface EnhancedDocumentUploadProps {
  open: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

interface UploadProgress {
  stage: 'uploading' | 'processing' | 'ocr' | 'complete' | 'error';
  progress: number;
  message: string;
}

const SUPPORTED_FORMATS = [
  { type: 'PDF', desc: 'Including scanned documents', icon: FileText, color: 'text-red-400' },
  { type: 'Word', desc: '.docx, .doc documents', icon: File, color: 'text-blue-400' },
  { type: 'Images', desc: 'JPG, PNG with OCR', icon: Image, color: 'text-green-400' },
  { type: 'HTML/XML', desc: 'Web and structured documents', icon: Globe, color: 'text-purple-400' }
];

const PROCESSING_STAGES = [
  { stage: 'uploading', label: 'Uploading Document', icon: Upload },
  { stage: 'processing', label: 'Processing Document', icon: Cpu },
  { stage: 'ocr', label: 'OCR & Text Extraction', icon: Eye },
  { stage: 'complete', label: 'Complete', icon: CheckCircle2 }
];

interface DocumentProcessingResponse {
  success: boolean;
  document_id: number;
  message: string;
  file_name: string;
  processing_status: string;
}

interface ProcessingStatusResponse {
  status: string;
  progress: number;
  message: string;
  result?: any;
}

interface EnhancedMetadataOptions {
  classification_levels: MetadataOption[];
  security_markings: MetadataOption[];
  document_types: MetadataOption[];
  compliance_frameworks: MetadataOption[];
  product_categories: MetadataOption[];
  review_schedules: MetadataOption[];
  geographic_scopes: MetadataOption[];
}

export default function EnhancedDocumentUpload({ open, onClose, onSuccess }: EnhancedDocumentUploadProps) {
  const [file, setFile] = useState<File | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [uploadProgress, setUploadProgress] = useState<UploadProgress | null>(null);
  const [processingResult, setProcessingResult] = useState<DocumentProcessingResponse | null>(null);
  const [loadingOptions, setLoadingOptions] = useState(false);
  const [enhancedOptions, setEnhancedOptions] = useState<EnhancedMetadataOptions | null>(null);
  const [jurisdictions, setJurisdictions] = useState<MetadataOption[]>([]);
  const [regulationTypes, setRegulationTypes] = useState<MetadataOption[]>([]);
  const [subjects, setSubjects] = useState<MetadataOption[]>([]);
  const [openSections, setOpenSections] = useState({
    basic: true,
    security: false,
    compliance: false,
    lifecycle: false,
    ownership: false,
    versioning: false,
    geography: false
  });
  // Enhanced document metadata state
  const [metadata, setMetadata] = useState({
    // Basic information
    title: '',
    description: '',
    issuing_authority: '',
    legal_status: 'in_force',
    version: '',
    source_url: '',
    
    // Date fields
    effective_date: '',
    last_updated: '',
    review_date: '',
    expiry_date: '',
    publication_date: '', // Add publication_date
    abrogation_date: '', // Add abrogation_date
    
    // Categorization - now arrays for multi-select
    country_jurisdiction: [] as string[],
    regulation_type: [] as string[],
    subject: [] as string[],
    tags: [] as string[],
    
    // Enhanced metadata fields
    classification_level: '',
    security_markings: [] as string[],
    access_control_list: [] as string[],
    document_type: '',
    compliance_framework: '',
    product_category: '',
    retention_period_years: null as number | null,
    review_schedule: '',
    document_owner: '',
    sme_reviewers: [] as string[],
    training_required: false,
    
    // Version control fields
    version_major: 1,
    version_minor: 0,
    
    // Workflow fields
    publishing_status: 'draft',
    document_language: 'en',
    geographic_scope: [] as string[],
    priority_level: 'medium',
    confidentiality_level: 'internal'
  });

  // Load metadata options on mount
  useEffect(() => {
    if (open) {
      loadMetadataOptions();
    }
  }, [open]);

  const loadMetadataOptions = async () => {
    try {
      setLoadingOptions(true);
      
      // Load enhanced metadata options and legacy options in parallel
      const [enhancedRes, jurisdictionsRes, typesRes, subjectsRes] = await Promise.all([
        brain.get_enhanced_metadata_options(),
        brain.get_metadata_options({ category: 'jurisdiction' }),
        brain.get_metadata_options({ category: 'type' }),
        brain.get_metadata_options({ category: 'subject' })
      ]);
      
      if (enhancedRes.ok) {
        const enhancedData = await enhancedRes.json();
        setEnhancedOptions(enhancedData);
      }
      
      if (jurisdictionsRes.ok) {
        const jurisdictionsData = await jurisdictionsRes.json();
        setJurisdictions(jurisdictionsData);
      }
      
      if (typesRes.ok) {
        const typesData = await typesRes.json();
        setRegulationTypes(typesData);
      }
      
      if (subjectsRes.ok) {
        const subjectsData = await subjectsRes.json();
        setSubjects(subjectsData);
      }
    } catch (error) {
      console.error('Error loading metadata options:', error);
      toast.error('Failed to load metadata options');
    } finally {
      setLoadingOptions(false);
    }
  };

  const toggleSection = (section: keyof typeof openSections) => {
    setOpenSections(prev => ({
      ...prev,
      [section]: !prev[section]
    }));
  };

  const handleFileSelect = (selectedFile: File) => {
    setFile(selectedFile);
    // Auto-fill title from filename
    if (!metadata.title) {
      const nameWithoutExt = selectedFile.name.replace(/\.[^/.]+$/, '');
      setMetadata(prev => ({ ...prev, title: nameWithoutExt }));
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const droppedFile = e.dataTransfer.files[0];
    if (droppedFile) {
      handleFileSelect(droppedFile);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const pollProcessingStatus = async (processingId: string): Promise<void> => {
    const maxAttempts = 30; // 30 seconds maximum
    let attempts = 0;

    const poll = async (): Promise<void> => {
      try {
        const response = await brain.get_processing_status({ processingId });
        if (response.ok) {
          const status: ProcessingStatusResponse = await response.json();
          
          setUploadProgress({
            stage: status.status === 'complete' ? 'complete' : 'processing',
            progress: status.progress,
            message: status.status === 'complete' ? 'Processing complete!' : 'Processing document...'
          });

          if (status.status === 'complete' && status.result) {
            setProcessingResult(status.result);
            setUploadProgress({
              stage: 'complete',
              progress: 100,
              message: 'Document processed successfully!'
            });
            return;
          }

          if (status.status === 'failed') {
            throw new Error(status.errors?.join(', ') || 'Processing failed');
          }

          // Continue polling
          attempts++;
          if (attempts < maxAttempts) {
            setTimeout(poll, 1000);
          } else {
            throw new Error('Processing timeout');
          }
        } else {
          throw new Error('Failed to check processing status');
        }
      } catch (error) {
        console.error('Processing error:', error);
        setUploadProgress({
          stage: 'error',
          progress: 0,
          message: error instanceof Error ? error.message : 'Processing failed'
        });
      }
    };

    await poll();
  };

  const handleUpload = async () => {
    if (!file) return;

    try {
      setUploadProgress({
        stage: 'uploading',
        progress: 0,
        message: 'Uploading document...'
      });

      // Use the knowledge base upload endpoint
      const uploadData = {
        file: file,
        metadata: JSON.stringify({
          title: metadata.title,
          description: metadata.description,
          country_jurisdiction: metadata.country_jurisdiction,
          regulation_type: metadata.regulation_type,
          subject: metadata.subject,
          issuing_authority: metadata.issuing_authority,
          publication_date: metadata.publication_date,
          effective_date: metadata.effective_date,
          legal_status: metadata.legal_status,
          version: metadata.version,
          badge: metadata.badge,
          document_url: metadata.document_url,
          source_url: metadata.source_url,
          tags: Array.isArray(metadata.tags) ? metadata.tags.join(', ') : metadata.tags,
          publishing_status: metadata.publishing_status,
          category_ids: metadata.category_ids
        })
      };

      const response = await brain.upload_document(uploadData);
      
      if (response.ok) {
        toast.success('Document uploaded successfully!');
        onSuccess();
        handleClose();
      } else {
        const errorData = await response.json().catch(() => ({ detail: 'Failed to save to Knowledge Base' }));
        toast.error(errorData.detail || 'Failed to save to Knowledge Base');
      }

    } catch (error) {
      console.error('Upload error:', error);
      setUploadProgress({
        stage: 'error',
        progress: 0,
        message: error instanceof Error ? error.message : 'Upload failed'
      });
      toast.error(error instanceof Error ? error.message : 'Upload failed');
    }
  };

  const handleClose = () => {
    setFile(null);
    setUploadProgress(null);
    setProcessingResult(null);
    setMetadata({
      title: '',
      description: '',
      issuing_authority: '',
      legal_status: 'in_force',
      version: '',
      source_url: '',
      
      effective_date: '',
      last_updated: '',
      review_date: '',
      expiry_date: '',
      publication_date: '', // Add publication_date
      abrogation_date: '', // Add abrogation_date
      
      country_jurisdiction: [] as string[],
      regulation_type: [] as string[],
      subject: [] as string[],
      tags: [] as string[],
      
      classification_level: '',
      security_markings: [] as string[],
      access_control_list: [] as string[],
      document_type: '',
      compliance_framework: '',
      product_category: '',
      retention_period_years: null as number | null,
      review_schedule: '',
      document_owner: '',
      sme_reviewers: [] as string[],
      training_required: false,
      
      // Version control fields
      version_major: 1,
      version_minor: 0,
      
      publishing_status: 'draft',
      document_language: 'en',
      geographic_scope: [] as string[],
      priority_level: 'medium',
      confidentiality_level: 'internal'
    });
    onClose();
  };

  const getFileIcon = (fileName: string) => {
    const ext = fileName.toLowerCase().split('.').pop();
    if (['pdf'].includes(ext || '')) return FileText;
    if (['jpg', 'jpeg', 'png', 'gif'].includes(ext || '')) return Image;
    if (['doc', 'docx'].includes(ext || '')) return File;
    return File;
  };

  const isUploading = uploadProgress !== null;
  const canUpload = file && metadata.title && metadata.country_jurisdiction && !isUploading;

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="bg-gray-900 border-gray-700 text-white max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-amber-400 text-xl flex items-center gap-2">
            <Zap className="h-6 w-6" />
            Enhanced Document Upload
          </DialogTitle>
          <DialogDescription className="text-gray-400">
            Upload regulatory documents with advanced OCR processing and text extraction
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* Supported Formats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {SUPPORTED_FORMATS.map((format) => {
              const IconComponent = format.icon;
              return (
                <div key={format.type} className="text-center p-3 rounded-lg border border-gray-700 bg-gray-800">
                  <IconComponent className={`h-6 w-6 mx-auto mb-2 ${format.color}`} />
                  <p className="font-medium text-sm">{format.type}</p>
                  <p className="text-xs text-gray-400">{format.desc}</p>
                </div>
              );
            })}
          </div>

          {/* File Upload Area */}
          <div
            className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
              isDragging
                ? 'border-blue-400 bg-blue-900/20'
                : 'border-gray-600 hover:border-gray-500'
            }`}
            onDrop={handleDrop}
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
          >
            {file ? (
              <div className="space-y-4">
                <div className="flex items-center justify-center gap-3">
                  {React.createElement(getFileIcon(file.name), { className: 'h-8 w-8 text-blue-400' })}
                  <div>
                    <p className="font-medium">{file.name}</p>
                    <p className="text-sm text-gray-400">
                      {(file.size / 1024 / 1024).toFixed(2)} MB
                    </p>
                  </div>
                </div>
                <Button
                  variant="outline"
                  onClick={() => setFile(null)}
                  className="border-gray-600 text-gray-300"
                >
                  Choose Different File
                </Button>
              </div>
            ) : (
              <div className="space-y-4">
                <Upload className="h-12 w-12 mx-auto text-gray-400" />
                <div>
                  <p className="text-lg font-medium">Drop your document here</p>
                  <p className="text-gray-400">or click to browse files</p>
                </div>
                <Input
                  type="file"
                  onChange={(e) => {
                    const selectedFile = e.target.files?.[0];
                    if (selectedFile) handleFileSelect(selectedFile);
                  }}
                  accept=".pdf,.doc,.docx,.html,.xml,.jpg,.jpeg,.png"
                  className="max-w-xs mx-auto"
                />
              </div>
            )}
          </div>

          {/* Processing Progress */}
          {uploadProgress && (
            <Card className="bg-gray-800 border-gray-700">
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Cpu className="h-5 w-5 text-blue-400" />
                  Document Processing
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>{uploadProgress.message}</span>
                    <span>{uploadProgress.progress}%</span>
                  </div>
                  <Progress value={uploadProgress.progress} className="h-2" />
                </div>
                
                <div className="grid grid-cols-4 gap-2">
                  {PROCESSING_STAGES.map((stage, index) => {
                    const IconComponent = stage.icon;
                    const isActive = PROCESSING_STAGES.findIndex(s => s.stage === uploadProgress.stage) >= index;
                    const isCurrent = stage.stage === uploadProgress.stage;
                    
                    return (
                      <div key={stage.stage} className="text-center">
                        <div className={`mx-auto w-8 h-8 rounded-full flex items-center justify-center mb-2 ${
                          isActive ? 'bg-blue-600' : 'bg-gray-700'
                        }`}>
                          {isCurrent && uploadProgress.stage !== 'complete' && uploadProgress.stage !== 'error' ? (
                            <Loader2 className="h-4 w-4 animate-spin" />
                          ) : (
                            <IconComponent className="h-4 w-4" />
                          )}
                        </div>
                        <p className={`text-xs ${
                          isActive ? 'text-white' : 'text-gray-400'
                        }`}>
                          {stage.label}
                        </p>
                      </div>
                    );
                  })}
                </div>

                {processingResult && (
                  <div className="mt-4 p-4 bg-gray-700 rounded-lg">
                    <h4 className="font-medium mb-2 flex items-center gap-2">
                      <CheckCircle2 className="h-4 w-4 text-green-400" />
                      Processing Results
                    </h4>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span>Document Type:</span>
                        <Badge variant="outline">{processingResult.document_type}</Badge>
                      </div>
                      <div className="flex justify-between">
                        <span>Processing Time:</span>
                        <span>{processingResult.processing_time.toFixed(2)}s</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Text Extracted:</span>
                        <span>{processingResult.success ? 'Yes' : 'Failed'}</span>
                      </div>
                      {processingResult.sections && processingResult.sections.length > 0 && (
                        <div className="flex justify-between">
                          <span>Sections Found:</span>
                          <span>{processingResult.sections.length}</span>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          {/* Metadata Form */}
          {!isUploading && (
            <div className="space-y-6">
              {/* Basic Information */}
              <Collapsible open={openSections.basic} onOpenChange={() => toggleSection('basic')}>
                <Card className="bg-gray-800 border-gray-700">
                  <CollapsibleTrigger className="w-full">
                    <CardHeader className="hover:bg-gray-700/50 transition-colors">
                      <div className="flex items-center justify-between">
                        <CardTitle className="text-lg text-white flex items-center gap-2">
                          <FileText className="h-5 w-5 text-blue-400" />
                          Basic Information
                        </CardTitle>
                        {openSections.basic ? <ChevronDown className="h-5 w-5" /> : <ChevronRight className="h-5 w-5" />}
                      </div>
                    </CardHeader>
                  </CollapsibleTrigger>
                  <CollapsibleContent>
                    <CardContent className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label className="text-white font-medium">Title *</Label>
                          <Input
                            value={metadata.title}
                            onChange={(e) => setMetadata(prev => ({ ...prev, title: e.target.value }))}
                            placeholder="Document title"
                            className="bg-gray-700 border-gray-600 text-white"
                            required
                          />
                        </div>
                        <div className="space-y-2">
                          <Label className="text-white font-medium">Issuing Authority</Label>
                          <Input
                            value={metadata.issuing_authority}
                            onChange={(e) => setMetadata(prev => ({ ...prev, issuing_authority: e.target.value }))}
                            placeholder="e.g., BIS, OFAC, EU Commission"
                            className="bg-gray-700 border-gray-600 text-white"
                          />
                        </div>
                      </div>

                      <div className="space-y-2">
                        <Label className="text-white font-medium">Description</Label>
                        <Textarea
                          value={metadata.description}
                          onChange={(e) => setMetadata(prev => ({ ...prev, description: e.target.value }))}
                          placeholder="Brief description of the document"
                          className="bg-gray-700 border-gray-600 text-white"
                          rows={3}
                        />
                      </div>

                      <div className="grid grid-cols-3 gap-4">
                        <div className="space-y-2">
                          <Label className="text-white font-medium">Country/Jurisdiction *</Label>
                          <ComboboxMultiSelect
                            options={jurisdictions}
                            value={metadata.country_jurisdiction}
                            onChange={(values) => setMetadata(prev => ({ ...prev, country_jurisdiction: values }))}
                            placeholder="Select jurisdictions"
                            label=""
                          />
                        </div>
                        <div className="space-y-2">
                          <Label className="text-white font-medium">Type</Label>
                          <ComboboxMultiSelect
                            options={regulationTypes}
                            value={metadata.regulation_type}
                            onChange={(values) => setMetadata(prev => ({ ...prev, regulation_type: values }))}
                            placeholder="Select types"
                            label=""
                          />
                        </div>
                        <div className="space-y-2">
                          <Label className="text-white font-medium">Subject</Label>
                          <ComboboxMultiSelect
                            options={subjects}
                            value={metadata.subject}
                            onChange={(values) => setMetadata(prev => ({ ...prev, subject: values }))}
                            placeholder="Select subjects"
                            label=""
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label className="text-white font-medium">Publication Date</Label>
                          <Input
                            type="date"
                            value={metadata.publication_date}
                            onChange={(e) => setMetadata(prev => ({ ...prev, publication_date: e.target.value }))}
                            className="bg-gray-700 border-gray-600 text-white"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label className="text-white font-medium">Effective Date</Label>
                          <Input
                            type="date"
                            value={metadata.effective_date}
                            onChange={(e) => setMetadata(prev => ({ ...prev, effective_date: e.target.value }))}
                            className="bg-gray-700 border-gray-600 text-white"
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label className="text-white font-medium">Abrogation Date</Label>
                          <Input
                            type="date"
                            value={metadata.abrogation_date}
                            onChange={(e) => setMetadata(prev => ({ ...prev, abrogation_date: e.target.value }))}
                            className="bg-gray-700 border-gray-600 text-white"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label className="text-white font-medium">Version</Label>
                          <Input
                            value={metadata.version}
                            onChange={(e) => setMetadata(prev => ({ ...prev, version: e.target.value }))}
                            placeholder="e.g., v1.0, 2024.1"
                            className="bg-gray-700 border-gray-600 text-white"
                          />
                        </div>
                      </div>

                      <div className="space-y-2">
                        <TagInput
                          value={metadata.tags}
                          onChange={(tags) => setMetadata(prev => ({ ...prev, tags }))}
                          label="Tags"
                          placeholder="Add tags (press Enter or comma to add)"
                          className=""
                        />
                      </div>
                    </CardContent>
                  </CollapsibleContent>
                </Card>
              </Collapsible>

              {/* Security & Access Control */}
              <Collapsible open={openSections.security} onOpenChange={() => toggleSection('security')}>
                <Card className="bg-gray-800 border-gray-700">
                  <CollapsibleTrigger className="w-full">
                    <CardHeader className="hover:bg-gray-700/50 transition-colors">
                      <div className="flex items-center justify-between">
                        <CardTitle className="text-lg text-white flex items-center gap-2">
                          <Shield className="h-5 w-5 text-red-400" />
                          Security & Access Control
                        </CardTitle>
                        {openSections.security ? <ChevronDown className="h-5 w-5" /> : <ChevronRight className="h-5 w-5" />}
                      </div>
                    </CardHeader>
                  </CollapsibleTrigger>
                  <CollapsibleContent>
                    <CardContent className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label className="text-white font-medium">Classification Level</Label>
                          <Select value={metadata.classification_level} onValueChange={(value) => setMetadata(prev => ({ ...prev, classification_level: value }))}>
                            <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                              <SelectValue placeholder="Select level" />
                            </SelectTrigger>
                            <SelectContent className="bg-gray-700 border-gray-600">
                              {enhancedOptions?.classification_levels.map((level) => (
                                <SelectItem key={level.value} value={level.value} className="text-white hover:bg-gray-600">
                                  {level.display_name}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="space-y-2">
                          <Label className="text-white font-medium">Training Required</Label>
                          <Select value={metadata.training_required ? 'true' : 'false'} onValueChange={(value) => setMetadata(prev => ({ ...prev, training_required: value === 'true' }))}>
                            <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent className="bg-gray-700 border-gray-600">
                              <SelectItem value="false" className="text-white hover:bg-gray-600">No</SelectItem>
                              <SelectItem value="true" className="text-white hover:bg-gray-600">Yes</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label className="text-white font-medium">Security Markings</Label>
                          <ComboboxMultiSelect
                            options={enhancedOptions?.security_markings || []}
                            value={metadata.security_markings}
                            onChange={(values) => setMetadata(prev => ({ ...prev, security_markings: values }))}
                            placeholder="Select security markings"
                            label=""
                          />
                        </div>
                        <div className="space-y-2">
                          <Label className="text-white font-medium">Access Control List</Label>
                          <TagInput
                            value={metadata.access_control_list}
                            onChange={(tags) => setMetadata(prev => ({ ...prev, access_control_list: tags }))}
                            label=""
                            placeholder="Add users/roles (press Enter or comma)"
                            className="bg-gray-700 border-gray-600 text-white"
                          />
                        </div>
                      </div>
                    </CardContent>
                  </CollapsibleContent>
                </Card>
              </Collapsible>

              {/* Compliance Information */}
              <Collapsible open={openSections.compliance} onOpenChange={() => toggleSection('compliance')}>
                <Card className="bg-gray-800 border-gray-700">
                  <CollapsibleTrigger className="w-full">
                    <CardHeader className="hover:bg-gray-700/50 transition-colors">
                      <div className="flex items-center justify-between">
                        <CardTitle className="text-lg text-white flex items-center gap-2">
                          <AlertCircle className="h-5 w-5 text-yellow-400" />
                          Compliance Information
                        </CardTitle>
                        {openSections.compliance ? <ChevronDown className="h-5 w-5" /> : <ChevronRight className="h-5 w-5" />}
                      </div>
                    </CardHeader>
                  </CollapsibleTrigger>
                  <CollapsibleContent>
                    <CardContent className="space-y-4">
                      <div className="grid grid-cols-3 gap-4">
                        <div className="space-y-2">
                          <Label className="text-white font-medium">Document Type</Label>
                          <Select value={metadata.document_type} onValueChange={(value) => setMetadata(prev => ({ ...prev, document_type: value }))}>
                            <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                              <SelectValue placeholder="Select type" />
                            </SelectTrigger>
                            <SelectContent className="bg-gray-700 border-gray-600">
                              {enhancedOptions?.document_types.map((type) => (
                                <SelectItem key={type.value} value={type.value} className="text-white hover:bg-gray-600">
                                  {type.display_name}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="space-y-2">
                          <Label className="text-white font-medium">Compliance Framework</Label>
                          <Select value={metadata.compliance_framework} onValueChange={(value) => setMetadata(prev => ({ ...prev, compliance_framework: value }))}>
                            <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                              <SelectValue placeholder="Select framework" />
                            </SelectTrigger>
                            <SelectContent className="bg-gray-700 border-gray-600">
                              {enhancedOptions?.compliance_frameworks.map((framework) => (
                                <SelectItem key={framework.value} value={framework.value} className="text-white hover:bg-gray-600">
                                  {framework.display_name}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="space-y-2">
                          <Label className="text-white font-medium">Product Category</Label>
                          <Select value={metadata.product_category} onValueChange={(value) => setMetadata(prev => ({ ...prev, product_category: value }))}>
                            <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                              <SelectValue placeholder="Select category" />
                            </SelectTrigger>
                            <SelectContent className="bg-gray-700 border-gray-600">
                              {enhancedOptions?.product_categories.map((category) => (
                                <SelectItem key={category.value} value={category.value} className="text-white hover:bg-gray-600">
                                  {category.display_name}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                    </CardContent>
                  </CollapsibleContent>
                </Card>
              </Collapsible>

              {/* Document Lifecycle */}
              <Collapsible open={openSections.lifecycle} onOpenChange={() => toggleSection('lifecycle')}>
                <Card className="bg-gray-800 border-gray-700">
                  <CollapsibleTrigger className="w-full">
                    <CardHeader className="hover:bg-gray-700/50 transition-colors">
                      <div className="flex items-center justify-between">
                        <CardTitle className="text-lg text-white flex items-center gap-2">
                          <Clock className="h-5 w-5 text-green-400" />
                          Document Lifecycle
                        </CardTitle>
                        {openSections.lifecycle ? <ChevronDown className="h-5 w-5" /> : <ChevronRight className="h-5 w-5" />}
                      </div>
                    </CardHeader>
                  </CollapsibleTrigger>
                  <CollapsibleContent>
                    <CardContent className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label className="text-white font-medium">Review Schedule</Label>
                          <Select value={metadata.review_schedule} onValueChange={(value) => setMetadata(prev => ({ ...prev, review_schedule: value }))}>
                            <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                              <SelectValue placeholder="Select schedule" />
                            </SelectTrigger>
                            <SelectContent className="bg-gray-700 border-gray-600">
                              {enhancedOptions?.review_schedules.map((schedule) => (
                                <SelectItem key={schedule.value} value={schedule.value} className="text-white hover:bg-gray-600">
                                  {schedule.display_name}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="space-y-2">
                          <Label className="text-white font-medium">Retention Period (Years)</Label>
                          <Input
                            type="number"
                            value={metadata.retention_period_years || ''}
                            onChange={(e) => setMetadata(prev => ({ ...prev, retention_period_years: e.target.value ? parseInt(e.target.value) : null }))}
                            placeholder="i.e., 7"
                            className="bg-gray-700 border-gray-600 text-white"
                          />
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label className="text-white font-medium">Next Review Date</Label>
                          <Input
                            type="date"
                            value={metadata.next_review_date}
                            onChange={(e) => setMetadata(prev => ({ ...prev, next_review_date: e.target.value }))}
                            className="bg-gray-700 border-gray-600 text-white"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label className="text-white font-medium">Expiration Date</Label>
                          <Input
                            type="date"
                            value={metadata.expiration_date}
                            onChange={(e) => setMetadata(prev => ({ ...prev, expiration_date: e.target.value }))}
                            className="bg-gray-700 border-gray-600 text-white"
                          />
                        </div>
                      </div>
                    </CardContent>
                  </CollapsibleContent>
                </Card>
              </Collapsible>

              {/* Document Ownership */}
              <Collapsible open={openSections.ownership} onOpenChange={() => toggleSection('ownership')}>
                <Card className="bg-gray-800 border-gray-700">
                  <CollapsibleTrigger className="w-full">
                    <CardHeader className="hover:bg-gray-700/50 transition-colors">
                      <div className="flex items-center justify-between">
                        <CardTitle className="text-lg text-white flex items-center gap-2">
                          <Users className="h-5 w-5 text-purple-400" />
                          Document Ownership
                        </CardTitle>
                        {openSections.ownership ? <ChevronDown className="h-5 w-5" /> : <ChevronRight className="h-5 w-5" />}
                      </div>
                    </CardHeader>
                  </CollapsibleTrigger>
                  <CollapsibleContent>
                    <CardContent className="space-y-4">
                      <div className="space-y-2">
                        <Label className="text-white font-medium">Document Owner</Label>
                        <Input
                          value={metadata.document_owner}
                          onChange={(e) => setMetadata(prev => ({ ...prev, document_owner: e.target.value }))}
                          placeholder="Owner name or email"
                          className="bg-gray-700 border-gray-600 text-white"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label className="text-white font-medium">SME Reviewers</Label>
                        <TagInput
                          value={metadata.sme_reviewers}
                          onChange={(tags) => setMetadata(prev => ({ ...prev, sme_reviewers: tags }))}
                          placeholder="Add reviewer names (press Enter or comma)"
                          className="bg-gray-700 border-gray-600 text-white"
                        />
                      </div>
                    </CardContent>
                  </CollapsibleContent>
                </Card>
              </Collapsible>

              {/* Version Control */}
              <Collapsible open={openSections.versioning} onOpenChange={() => toggleSection('versioning')}>
                <Card className="bg-gray-800 border-gray-700">
                  <CollapsibleTrigger className="w-full">
                    <CardHeader className="hover:bg-gray-700/50 transition-colors">
                      <div className="flex items-center justify-between">
                        <CardTitle className="text-lg text-white flex items-center gap-2">
                          <FileText className="h-5 w-5 text-orange-400" />
                          Version Control
                        </CardTitle>
                        {openSections.versioning ? <ChevronDown className="h-5 w-5" /> : <ChevronRight className="h-5 w-5" />}
                      </div>
                    </CardHeader>
                  </CollapsibleTrigger>
                  <CollapsibleContent>
                    <CardContent className="space-y-4">
                      <div className="grid grid-cols-4 gap-4">
                        <div className="space-y-2">
                          <Label className="text-white font-medium">Version Major</Label>
                          <Input
                            type="number"
                            value={metadata.version_major}
                            onChange={(e) => setMetadata(prev => ({ ...prev, version_major: parseInt(e.target.value) || 1 }))}
                            className="bg-gray-700 border-gray-600 text-white"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label className="text-white font-medium">Version Minor</Label>
                          <Input
                            type="number"
                            value={metadata.version_minor}
                            onChange={(e) => setMetadata(prev => ({ ...prev, version_minor: parseInt(e.target.value) || 0 }))}
                            className="bg-gray-700 border-gray-600 text-white"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label className="text-white font-medium">Status</Label>
                          <Select value={metadata.publishing_status} onValueChange={(value) => setMetadata(prev => ({ ...prev, publishing_status: value }))}>
                            <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent className="bg-gray-700 border-gray-600">
                              <SelectItem value="draft" className="text-white hover:bg-gray-600">Draft</SelectItem>
                              <SelectItem value="pending_validation" className="text-white hover:bg-gray-600">Pending Review</SelectItem>
                              <SelectItem value="published" className="text-white hover:bg-gray-600">Published</SelectItem>
                              <SelectItem value="archived" className="text-white hover:bg-gray-600">Archived</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="space-y-2">
                          <Label className="text-white font-medium">Legal Status</Label>
                          <Select value={metadata.legal_status} onValueChange={(value) => setMetadata(prev => ({ ...prev, legal_status: value }))}>
                            <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent className="bg-gray-700 border-gray-600">
                              <SelectItem value="in_force" className="text-white hover:bg-gray-600">In force</SelectItem>
                              <SelectItem value="proposed" className="text-white hover:bg-gray-600">Proposed</SelectItem>
                              <SelectItem value="voted" className="text-white hover:bg-gray-600">Voted</SelectItem>
                              <SelectItem value="abrogated" className="text-white hover:bg-gray-600">Abrogated</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                    </CardContent>
                  </CollapsibleContent>
                </Card>
              </Collapsible>

              {/* Geography */}
              <Collapsible open={openSections.geography} onOpenChange={() => toggleSection('geography')}>
                <Card className="bg-gray-800 border-gray-700">
                  <CollapsibleTrigger className="w-full">
                    <CardHeader className="hover:bg-gray-700/50 transition-colors">
                      <div className="flex items-center justify-between">
                        <CardTitle className="text-lg text-white flex items-center gap-2">
                          <Globe className="h-5 w-5 text-cyan-400" />
                          Geographic Scope
                        </CardTitle>
                        {openSections.geography ? <ChevronDown className="h-5 w-5" /> : <ChevronRight className="h-5 w-5" />}
                      </div>
                    </CardHeader>
                  </CollapsibleTrigger>
                  <CollapsibleContent>
                    <CardContent className="space-y-4">
                      <div className="space-y-2">
                        <Label className="text-white font-medium">Geographic Scope</Label>
                        <ComboboxMultiSelect
                          options={enhancedOptions?.geographic_scopes || []}
                          value={metadata.geographic_scope}
                          onChange={(values) => setMetadata(prev => ({ ...prev, geographic_scope: values }))}
                          placeholder="Select geographic scope"
                          label=""
                        />
                      </div>
                    </CardContent>
                  </CollapsibleContent>
                </Card>
              </Collapsible>
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex justify-end gap-4">
            <Button
              variant="outline"
              onClick={handleClose}
              disabled={isUploading}
              className="border-gray-600 text-gray-300"
            >
              {isUploading ? 'Processing...' : 'Cancel'}
            </Button>
            <Button
              onClick={handleUpload}
              disabled={!canUpload}
              className="bg-amber-600 hover:bg-amber-700 text-white"
            >
              {isUploading ? (
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              ) : (
                <Upload className="h-4 w-4 mr-2" />
              )}
              {isUploading ? 'Processing...' : 'Upload & Process'}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
