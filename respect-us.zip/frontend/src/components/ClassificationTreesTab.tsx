import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Plus, Edit3, Settings, Copy, Trash2, Hash, ArrowRight, Edit } from 'lucide-react';
import { toast } from 'sonner';
import brain from 'brain';
import TreeCard from './TreeCard';
import type {
  TreeNode,
  NodeOption,
  NodeOptionCreate,
  NodeOptionUpdate,
  TreeNodeUpdate,
  TreeNodeCreate,
  AppApisClassificationClassificationTree as ClassificationTree,
  MultiQuestionItem,
  OutcomeRule
} from '../brain/data-contracts';

interface ClassificationTreesTabProps {
  onCreateTree: () => void;
  onEditTree?: (tree: ClassificationTree) => void;
  onCreateNode: (tree: ClassificationTree) => void;
  onEditNode?: (node: TreeNode) => void;
  onManageNodeOptions?: (node: TreeNode) => void;
}

const ClassificationTreesTab: React.FC<ClassificationTreesTabProps> = ({
  onCreateTree,
  onEditTree,
  onCreateNode,
  onEditNode,
  onManageNodeOptions
}) => {
  const [classificationTrees, setClassificationTrees] = useState<ClassificationTree[]>([]);
  const [selectedTree, setSelectedTree] = useState<ClassificationTree | null>(null);
  const [treeNodes, setTreeNodes] = useState<TreeNode[]>([]);
  const [nodeOptions, setNodeOptions] = useState<{ [nodeId: string]: NodeOption[] }>({});
  const [loading, setLoading] = useState(true);
  const [editingNode, setEditingNode] = useState<TreeNode | null>(null);
  const [editNodeForm, setEditNodeForm] = useState({
    node_key: '',
    title: '',
    description: '',
    question_text: '',
    question_type: 'multiple_choice',
    notes: '',
    multi_questions: [] as MultiQuestionItem[],
    outcome_rules: [] as OutcomeRule[]
  });
  const [showEditNodeDialog, setShowEditNodeDialog] = useState(false);
  const [managingOptionsForNode, setManagingOptionsForNode] = useState<TreeNode | null>(null);
  const [showManageOptionsDialog, setShowManageOptionsDialog] = useState(false);
  const [editingOption, setEditingOption] = useState<NodeOption | null>(null);
  const [editOptionForm, setEditOptionForm] = useState({ option_text: '', option_value: '', routing_rule: '', regulatory_notes: '', note: '' });
  const [newOptionData, setNewOptionData] = useState({
    option_text: '',
    option_value: '',
    routing_rule: '',
    regulatory_notes: [] as string[],
    display_order: 0,
    note: ''
  });
  const [showEditOptionDialog, setShowEditOptionDialog] = useState(false);

  const loadClassificationTrees = async () => {
    try {
      setLoading(true);
      const response = await brain.list_classification_trees();
      if (response.ok) {
        const trees = await response.json();
        setClassificationTrees(trees);
      } else {
        toast.error('Failed to load classification trees');
      }
    } catch (error) {
      console.error('Error loading classification trees:', error);
      toast.error('Failed to load classification trees');
    } finally {
      setLoading(false);
    }
  };

  const loadTreeData = async (treeId: string) => {
    try {
      // Load tree nodes
      const nodesResponse = await brain.list_tree_nodes({ treeId });
      if (nodesResponse.ok) {
        const nodes = await nodesResponse.json();
        setTreeNodes(nodes);
        
        // Load options for each node
        const optionsMap: { [nodeId: string]: NodeOption[] } = {};
        for (const node of nodes) {
          try {
            const optionsResponse = await brain.list_node_options({ nodeId: node.id });
            if (optionsResponse.ok) {
              const options = await optionsResponse.json();
              optionsMap[node.id] = options;
            }
          } catch (error) {
            console.error(`Error loading options for node ${node.id}:`, error);
          }
        }
        setNodeOptions(optionsMap);
      }
    } catch (error) {
      console.error('Error loading tree data:', error);
      toast.error('Failed to load tree data');
    }
  };

  const handleTreeSelect = (tree: ClassificationTree) => {
    setSelectedTree(tree);
    loadTreeData(tree.id);
  };

  const handleTreesReload = () => {
    loadClassificationTrees();
    if (selectedTree) {
      // Check if selected tree still exists after reload
      loadClassificationTrees().then(() => {
        const stillExists = classificationTrees.find(t => t.id === selectedTree.id);
        if (!stillExists) {
          setSelectedTree(null);
          setTreeNodes([]);
          setNodeOptions({});
        }
      });
    }
  };

  const buildTreeStructure = (nodes: TreeNode[]) => {
    const sortedNodes = [...nodes].sort((a, b) => a.node_key.localeCompare(b.node_key));
    const nodeMap = new Map<string, TreeNode & { children: TreeNode[] }>();
    const rootNodes: (TreeNode & { children: TreeNode[] })[] = [];

    // First pass: create all nodes with children arrays
    for (const node of sortedNodes) {
      nodeMap.set(node.id, { ...node, children: [] });
    }

    // Second pass: build the tree structure
    for (const node of sortedNodes) {
      const nodeWithChildren = nodeMap.get(node.id)!;
      
      if (node.parent_node_id && nodeMap.has(node.parent_node_id)) {
        const parent = nodeMap.get(node.parent_node_id)!;
        parent.children.push(nodeWithChildren);
      } else {
        rootNodes.push(nodeWithChildren);
      }
    }

    return rootNodes;
  };

  const handleEditNode = (node: TreeNode) => {
    setEditingNode(node);
    setEditNodeForm({
      node_key: node.node_key,
      title: node.title,
      description: node.description || '',
      question_text: node.question_text,
      question_type: node.question_type,
      notes: node.notes || '',
      multi_questions: node.multi_questions || [],
      outcome_rules: node.outcome_rules || []
    });
    setShowEditNodeDialog(true);
  };

  const handleManageOptions = (node: TreeNode, e: React.MouseEvent) => {
    e.stopPropagation();
    console.log('🔧 MANAGE OPTIONS clicked for node:', node.title, node.id);
    console.log('🔧 Current nodeOptions:', nodeOptions[node.id]);
    console.log('🔧 Setting managingOptionsForNode to:', node);
    setManagingOptionsForNode(node);
    setShowManageOptionsDialog(true);
    console.log('🔧 Dialog should now be visible');
    console.log('🔧 showManageOptionsDialog state:', true);
    console.log('🔧 managingOptionsForNode state:', node);
  };

  const handleDuplicateNode = async (node: TreeNode, e: React.MouseEvent) => {
    e.stopPropagation();
    try {
      // Use create_tree_node instead of non-existent duplicate_tree_node
      const newNodeData: TreeNodeCreate = {
        node_key: `${node.node_key}_copy`,
        title: `${node.title} (Copy)`,
        description: node.description || '',
        question_text: node.question_text || '',
        question_type: node.question_type || 'multiple_choice',
        is_root: false,
        parent_node_id: node.parent_node_id,
        display_order: 0,
        notes: node.notes || ''
      };
      
      const duplicateResponse = await brain.create_tree_node({
        treeId: selectedTree.id
      }, newNodeData);
      
      toast.success('Node duplicated successfully');
      if (selectedTree) {
        loadTreeData(selectedTree.id);
      }
    } catch (error) {
      console.error('Error duplicating node:', error);
      toast.error('Failed to duplicate node');
    }
  };

  const handleDeleteNode = async (node: TreeNode, e: React.MouseEvent) => {
    e.stopPropagation();
    if (window.confirm(`Are you sure you want to delete node "${node.title}"? This action cannot be undone.`)) {
      try {
        await brain.delete_tree_node({ nodeId: node.id });
        toast.success('Node deleted successfully');
        if (selectedTree) {
          loadTreeData(selectedTree.id);
        }
      } catch (error) {
        console.error('Error deleting node:', error);
        toast.error('Failed to delete node');
      }
    }
  };

  const renderNode = (node: TreeNode & { children: TreeNode[] }, depth = 0) => {
    const options = nodeOptions[node.id] || [];

    return (
      <div key={node.id} className={`ml-${depth * 4}`}>
        <div className="border border-gray-600 rounded-lg p-4 bg-gray-800/30 mb-2">
          <div className="flex justify-between items-start">
            <div className="flex-1">
              <h4 className="font-semibold text-white">{node.title}</h4>
              <p className="text-gray-400 text-sm mt-1">{node.description}</p>
              <div className="flex items-center gap-2 mt-2">
                <Badge variant="outline" className="text-xs">
                  <Hash className="w-3 h-3 mr-1" />
                  {node.node_key}
                </Badge>
                <Badge variant="outline" className="text-xs">
                  {node.question_type}
                </Badge>
              </div>
              {node.question_text && (
                <div className="mt-2 p-2 bg-gray-700/50 rounded text-sm text-gray-300">
                  <strong>Question:</strong> {node.question_text}
                </div>
              )}
            </div>
            <div className="flex gap-2">
              <Button
                size="sm"
                variant="outline"
                onClick={(e) => {
                  e.stopPropagation();
                  handleEditNode(node);
                }}
                className="text-yellow-400 border-yellow-500 hover:bg-yellow-500/20"
                title="Edit Node"
              >
                <Edit className="w-3 h-3" />
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={(e) => handleManageOptions(node, e)}
                className="text-purple-400 border-purple-500 hover:bg-purple-500/20"
                title="Manage Options"
              >
                <Settings className="w-3 h-3" />
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={(e) => handleDuplicateNode(node, e)}
                className="text-blue-400 border-blue-500 hover:bg-blue-500/20"
                title="Duplicate Node"
              >
                <Copy className="w-3 h-3" />
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={(e) => handleDeleteNode(node, e)}
                className="text-red-400 border-red-500 hover:bg-red-500/20"
                title="Delete Node"
              >
                <Trash2 className="w-3 h-3" />
              </Button>
            </div>
          </div>
          
          {/* Show options for this node */}
          {options.length > 0 && (
            <div className="mt-4 border-t border-gray-600 pt-3">
              <div className="text-sm font-medium text-gray-300 mb-2">
                Options ({options.length}):
              </div>
              <div className="space-y-2">
                {options.map((option) => (
                  <div
                    key={option.id}
                    className="bg-gray-700/50 rounded p-2 border border-gray-600"
                  >
                    <div className="flex justify-between items-start">
                      <div className="flex-1">
                        <div className="font-medium text-white text-sm">
                          {option.option_text}
                        </div>
                        <div className="text-xs text-gray-400 mt-1">
                          Value: {option.option_value}
                        </div>
                        {option.routing_rule && (
                          <div className="text-xs text-green-400 mt-1">
                            <span className="font-semibold">Routes to:</span> {option.routing_rule}
                          </div>
                        )}
                      </div>
                      <div className="flex gap-1 ml-2">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={(e) => {
                            e.stopPropagation();
                            setEditingOption(option);
                            setEditOptionForm({
                              option_text: option.option_text,
                              option_value: option.option_value,
                              routing_rule: option.routing_rule || '',
                              regulatory_notes: option.regulatory_notes || [],
                              note: option.note || ''
                            });
                            setShowEditOptionDialog(true);
                          }}
                          className="text-yellow-400 border-yellow-500 hover:bg-yellow-500/20 h-6 w-6 p-0"
                          title="Edit Option"
                        >
                          <Edit className="w-3 h-3" />
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={async (e) => {
                            e.stopPropagation();
                            if (window.confirm(`Are you sure you want to delete the option "${option.option_text}"?`)) {
                              try {
                                await brain.delete_node_option({ optionId: option.id });
                                toast.success('Option deleted successfully');
                                if (selectedTree) {
                                  loadTreeData(selectedTree.id);
                                }
                              } catch (error) {
                                console.error('Error deleting option:', error);
                                toast.error('Failed to delete option');
                              }
                            }
                          }}
                          className="text-red-400 border-red-500 hover:bg-red-500/20 h-6 w-6 p-0"
                          title="Delete Option"
                        >
                          <Trash2 className="w-3 h-3" />
                        </Button>
                      </div>
                    </div>
                    
                    {/* Regulatory Notes */}
                    {option.regulatory_notes && Array.isArray(option.regulatory_notes) && option.regulatory_notes.length > 0 && (
                      <div className="text-xs text-purple-300 mb-1">
                        <span className="font-semibold">Regulatory Notes:</span>
                        <ul className="list-disc list-inside mt-1 ml-2">
                          {option.regulatory_notes.map((note, index) => (
                            <li key={index} className="text-gray-300">{note}</li>
                          ))}
                        </ul>
                      </div>
                    )}
                    
                    {/* Admin Note */}
                    {option.note && (
                      <div className="text-xs text-gray-400">
                        <span className="font-semibold">Note:</span> {option.note}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
        
        {node.children && node.children.map((child: TreeNode & { children: TreeNode[] }) => renderNode(child, depth + 1))}
      </div>
    );
  };

  const duplicateNode = async () => {
    if (!selectedTree || !editingNode) return;
    
    try {
      // Use the create_tree_node method with correct TreeNodeCreate structure
      const newNodeData: TreeNodeCreate = {
        node_key: `${editingNode.node_key}_copy`,
        title: `${editingNode.title} (Copy)`,
        description: editingNode.description || '',
        question_text: editingNode.question_text || '',
        question_type: editingNode.question_type || 'multiple_choice',
        is_root: false,
        parent_node_id: editingNode.parent_node_id,
        display_order: 0,
        notes: editingNode.notes || ''
      };

      const response = await brain.create_tree_node({
        treeId: selectedTree.id
      }, newNodeData);
      
      toast.success('Node duplicated successfully');
      if (selectedTree) {
        loadTreeData(selectedTree.id);
      }
      setShowEditNodeDialog(false);
    } catch (error) {
      console.error('Error duplicating node:', error);
      toast.error('Failed to duplicate node');
    }
  };

  const addOption = async (selectedNode: TreeNode, newOptionText: string) => {
    try {
      const currentOptions = nodeOptions[selectedNode.id] || [];
      const newOption: NodeOptionCreate = {
        option_text: newOptionText,
        option_value: newOptionText.toLowerCase().replace(/\s+/g, '_'),
        routing_rule: '',
        regulatory_notes: [],
        display_order: currentOptions.length,
        note: ''
      };
      await brain.create_node_option({
        nodeId: selectedNode.id
      }, newOption);
      toast.success('Option added successfully');
      if (selectedTree) {
        loadTreeData(selectedTree.id);
      }
    } catch (error) {
      console.error('Error adding option:', error);
      toast.error('Failed to add option');
    }
  };

  const handleCreateOption = async () => {
    if (!managingOptionsForNode || !newOptionData.option_text.trim() || !newOptionData.option_value.trim()) {
      toast.error('Please fill in required fields');
      return;
    }
    
    try {
      const response = await brain.create_node_option(
        { nodeId: managingOptionsForNode.id },
        {
          option_text: newOptionData.option_text,
          option_value: newOptionData.option_value,
          routing_rule: newOptionData.routing_rule || null,
          regulatory_notes: newOptionData.regulatory_notes.length > 0 ? newOptionData.regulatory_notes : null,
          display_order: (nodeOptions[managingOptionsForNode.id] || []).length,
          note: newOptionData.note || null
        }
      );
      
      if (response.ok) {
        toast.success('Option created successfully');
        setNewOptionData({
          option_text: '',
          option_value: '',
          routing_rule: '',
          regulatory_notes: [],
          display_order: 0,
          note: ''
        });
        // Reload the tree data to show the new option
        if (selectedTree) {
          loadTreeData(selectedTree.id);
        }
      } else {
        throw new Error('Failed to create option');
      }
    } catch (error) {
      console.error('Error creating option:', error);
      toast.error('Failed to create option');
    }
  };

  useEffect(() => {
    loadClassificationTrees();
  }, []);

  return (
    <div className="space-y-6">
      <Card className="bg-gray-800/50 border-gray-700">
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle className="text-amber-400">Classification Trees</CardTitle>
            <Button 
              onClick={onCreateTree}
              className="bg-amber-600 hover:bg-amber-700 text-white"
            >
              <Plus className="w-4 h-4 mr-2" />
              Create Classification Tree
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {loading ? (
            <p className="text-gray-400">Loading classification trees...</p>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {classificationTrees.map((tree) => (
                <TreeCard
                  key={tree.id}
                  tree={tree}
                  isSelected={selectedTree?.id === tree.id}
                  onTreeSelect={handleTreeSelect}
                  onCreateNode={onCreateNode}
                  onEditTree={onEditTree}
                  onTreesReload={handleTreesReload}
                  variant="classification"
                />
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {selectedTree && (
        <Card className="bg-gray-800/50 border-gray-700">
          <CardHeader>
            <CardTitle className="text-amber-400">Tree Structure: {selectedTree.name}</CardTitle>
          </CardHeader>
          <CardContent>
            {treeNodes.length === 0 ? (
              <p className="text-gray-400">No nodes found in this tree.</p>
            ) : (
              <div className="space-y-2">
                {buildTreeStructure(treeNodes).map((node) => renderNode(node))}
              </div>
            )}
          </CardContent>
        </Card>
      )}
      
      {showEditNodeDialog && (
        <Dialog open={showEditNodeDialog} onOpenChange={setShowEditNodeDialog}>
          <DialogContent className="bg-gray-900 border-gray-700 text-white max-w-4xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="text-amber-400">Edit Classification Node</DialogTitle>
              <DialogDescription className="text-gray-400">
                Modify node properties and classification details
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={async (e) => {
              e.preventDefault();
              try {
                const updateData: TreeNodeUpdate = {
                  node_key: editNodeForm.node_key,
                  title: editNodeForm.title,
                  description: editNodeForm.description,
                  question_text: editNodeForm.question_text,
                  question_type: editNodeForm.question_type,
                  notes: editNodeForm.notes || '',
                  multi_questions: editNodeForm.question_type === 'multi_question_assessment' ? editNodeForm.multi_questions : undefined,
                  outcome_rules: editNodeForm.question_type === 'multi_question_assessment' ? editNodeForm.outcome_rules : undefined
                };
                await brain.update_tree_node(
                  { treeId: selectedTree!.id, nodeId: editingNode!.id },
                  updateData
                );
                toast.success('Node updated successfully');
                if (selectedTree) {
                  loadTreeData(selectedTree.id);
                }
                setShowEditNodeDialog(false);
              } catch (error) {
                console.error('Error updating node:', error);
                toast.error('Failed to update node');
              }
            }}>
              <div className="space-y-4">
                <div>
                  <Label className="text-gray-300">Node Key</Label>
                  <Input
                    value={editNodeForm.node_key}
                    onChange={(e) => setEditNodeForm({ ...editNodeForm, node_key: e.target.value })}
                    className="bg-gray-800 border-gray-600 text-white"
                    placeholder="e.g., 6.3.1"
                  />
                </div>
                <div>
                  <Label className="text-gray-300">Title</Label>
                  <Input
                    value={editNodeForm.title}
                    onChange={(e) => setEditNodeForm({ ...editNodeForm, title: e.target.value })}
                    className="bg-gray-800 border-gray-600 text-white"
                    placeholder="Node title"
                  />
                </div>
                <div>
                  <Label className="text-gray-300">Description</Label>
                  <Textarea
                    value={editNodeForm.description}
                    onChange={(e) => setEditNodeForm({ ...editNodeForm, description: e.target.value })}
                    className="bg-gray-800 border-gray-600 text-white"
                    placeholder="Node description"
                    rows={2}
                  />
                </div>
                <div>
                  <Label className="text-gray-300">Question Text</Label>
                  <Textarea
                    value={editNodeForm.question_text}
                    onChange={(e) => setEditNodeForm({ ...editNodeForm, question_text: e.target.value })}
                    className="bg-gray-800 border-gray-600 text-white"
                    placeholder="Question to ask users"
                    rows={2}
                  />
                </div>
                <div>
                  <Label className="text-gray-300">Question Type</Label>
                  <Select value={editNodeForm.question_type} onValueChange={(value) => setEditNodeForm({ ...editNodeForm, question_type: value })}>
                    <SelectTrigger className="bg-gray-800 border-gray-600 text-white">
                      <SelectValue placeholder="Select question type" />
                    </SelectTrigger>
                    <SelectContent className="bg-gray-800 border-gray-600">
                      <SelectItem value="multiple_choice">Multiple Choice</SelectItem>
                      <SelectItem value="open_ended">Open Ended</SelectItem>
                      <SelectItem value="numeric">Numeric</SelectItem>
                      <SelectItem value="text_input">Text Input</SelectItem>
                      <SelectItem value="multi_question_assessment">Multi-Question Assessment</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Multi-Question Assessment Configuration */}
                {editNodeForm.question_type === 'multi_question_assessment' && (
                  <div className="space-y-4 border border-purple-600 rounded-lg p-4 bg-purple-900/20">
                    <h4 className="text-purple-300 font-semibold">Multi-Question Assessment Configuration</h4>
                    
                    {/* Questions Section */}
                    <div className="space-y-3">
                      <div className="flex justify-between items-center">
                        <Label className="text-gray-300">YES/NO Questions</Label>
                        <Button
                          type="button"
                          onClick={() => {
                            const newQuestion: MultiQuestionItem = {
                              key: `question_${editNodeForm.multi_questions.length + 1}`,
                              text: '',
                              order: editNodeForm.multi_questions.length
                            };
                            setEditNodeForm({
                              ...editNodeForm,
                              multi_questions: [...editNodeForm.multi_questions, newQuestion]
                            });
                          }}
                          size="sm"
                          className="bg-purple-600 hover:bg-purple-700"
                        >
                          <Plus className="w-4 h-4 mr-1" />
                          Add Question
                        </Button>
                      </div>
                      
                      {editNodeForm.multi_questions.map((question, index) => (
                        <div key={index} className="space-y-2">
                          <div className="flex gap-2 items-center">
                            <Input
                              value={question.key}
                              onChange={(e) => {
                                const updated = [...editNodeForm.multi_questions];
                                updated[index] = { ...updated[index], key: e.target.value };
                                setEditNodeForm({ ...editNodeForm, multi_questions: updated });
                              }}
                              placeholder="question_key"
                              className="bg-gray-800 border-gray-600 text-white w-32"
                            />
                            <Input
                              value={question.text}
                              onChange={(e) => {
                                const updated = [...editNodeForm.multi_questions];
                                updated[index] = { ...updated[index], text: e.target.value };
                                setEditNodeForm({ ...editNodeForm, multi_questions: updated });
                              }}
                              placeholder="Question text"
                              className="bg-gray-800 border-gray-600 text-white flex-1"
                            />
                            <Button
                              type="button"
                              onClick={() => {
                                const updated = editNodeForm.multi_questions.filter((_, i) => i !== index);
                                setEditNodeForm({ ...editNodeForm, multi_questions: updated });
                              }}
                              size="sm"
                              variant="destructive"
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                          <div className="ml-36">
                            <Input
                              value={question.regulatory_notes?.join(', ') || ''}
                              onChange={(e) => {
                                const updated = [...editNodeForm.multi_questions];
                                const noteIds = e.target.value ? e.target.value.split(',').map(id => id.trim()).filter(id => id) : [];
                                updated[index] = { ...updated[index], regulatory_notes: noteIds.length > 0 ? noteIds : null };
                                setEditNodeForm({ ...editNodeForm, multi_questions: updated });
                              }}
                              placeholder="Regulatory Notes (comma-separated note IDs)"
                              className="bg-gray-800 border-gray-600 text-white"
                            />
                          </div>
                        </div>
                      ))}
                    </div>

                    {/* Outcome Rules Section */}
                    <div className="space-y-3">
                      <div className="flex justify-between items-center">
                        <Label className="text-gray-300">Outcome Rules</Label>
                        <Button
                          type="button"
                          onClick={() => {
                            const newRule: OutcomeRule = {
                              name: `Rule ${editNodeForm.outcome_rules.length + 1}`,
                              description: '',
                              logic: { yes_count: 1 },
                              target: '',
                              target_type: 'node',
                              priority: editNodeForm.outcome_rules.length
                            };
                            setEditNodeForm({
                              ...editNodeForm,
                              outcome_rules: [...editNodeForm.outcome_rules, newRule]
                            });
                          }}
                          size="sm"
                          className="bg-purple-600 hover:bg-purple-700"
                        >
                          <Plus className="w-4 h-4 mr-1" />
                          Add Rule
                        </Button>
                      </div>
                      
                      {editNodeForm.outcome_rules.map((rule, index) => (
                        <div key={index} className="border border-gray-600 rounded p-3 space-y-2">
                          <div className="grid grid-cols-2 gap-2">
                            <Input
                              value={rule.name}
                              onChange={(e) => {
                                const updated = [...editNodeForm.outcome_rules];
                                updated[index] = { ...updated[index], name: e.target.value };
                                setEditNodeForm({ ...editNodeForm, outcome_rules: updated });
                              }}
                              placeholder="Rule name"
                              className="bg-gray-800 border-gray-600 text-white"
                            />
                            <Input
                              value={rule.target}
                              onChange={(e) => {
                                const updated = [...editNodeForm.outcome_rules];
                                updated[index] = { ...updated[index], target: e.target.value };
                                setEditNodeForm({ ...editNodeForm, outcome_rules: updated });
                              }}
                              placeholder="Target (node_key or outcome_code)"
                              className="bg-gray-800 border-gray-600 text-white"
                            />
                          </div>
                          <div className="grid grid-cols-3 gap-2">
                            <Input
                              type="number"
                              value={typeof rule.logic.yes_count === 'number' ? rule.logic.yes_count : ''}
                              onChange={(e) => {
                                const updated = [...editNodeForm.outcome_rules];
                                updated[index] = { 
                                  ...updated[index], 
                                  logic: { ...updated[index].logic, yes_count: parseInt(e.target.value) || 0 }
                                };
                                setEditNodeForm({ ...editNodeForm, outcome_rules: updated });
                              }}
                              placeholder="YES count"
                              className="bg-gray-800 border-gray-600 text-white"
                            />
                            <Input
                              type="number"
                              value={typeof rule.logic.no_count === 'number' ? rule.logic.no_count : ''}
                              onChange={(e) => {
                                const updated = [...editNodeForm.outcome_rules];
                                updated[index] = { 
                                  ...updated[index], 
                                  logic: { ...updated[index].logic, no_count: parseInt(e.target.value) || 0 }
                                };
                                setEditNodeForm({ ...editNodeForm, outcome_rules: updated });
                              }}
                              placeholder="NO count"
                              className="bg-gray-800 border-gray-600 text-white"
                            />
                            <Button
                              type="button"
                              onClick={() => {
                                const updated = editNodeForm.outcome_rules.filter((_, i) => i !== index);
                                setEditNodeForm({ ...editNodeForm, outcome_rules: updated });
                              }}
                              size="sm"
                              variant="destructive"
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                          <Textarea
                            value={rule.description || ''}
                            onChange={(e) => {
                              const updated = [...editNodeForm.outcome_rules];
                              updated[index] = { ...updated[index], description: e.target.value };
                              setEditNodeForm({ ...editNodeForm, outcome_rules: updated });
                            }}
                            placeholder="Rule description"
                            className="bg-gray-800 border-gray-600 text-white"
                            rows={2}
                          />
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                <div className="flex justify-end space-x-2 pt-4">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => {
                      setShowEditNodeDialog(false);
                      setEditingNode(null);
                    }}
                    className="border-gray-600 text-gray-400 hover:bg-gray-800"
                  >
                    Cancel
                  </Button>
                  <Button 
                    type="submit"
                    className="bg-amber-600 hover:bg-amber-700 text-white"
                  >
                    <Edit3 className="w-4 h-4 mr-2" />
                    Save Changes
                  </Button>
                </div>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      )}
      
      {showManageOptionsDialog && (
        <div className="fixed inset-0 flex items-center justify-center bg-black/50 z-50">
          <div className="bg-gray-900 p-6 rounded-lg max-w-4xl w-full max-h-[80vh] overflow-y-auto border border-gray-700">
            <h3 className="text-lg font-medium mb-4 text-white">Manage Options for: {managingOptionsForNode?.title}</h3>
            <form onSubmit={async (e) => {
              e.preventDefault();
              try {
                // Update each option individually
                const options = nodeOptions[managingOptionsForNode!.id] || [];
                for (const option of options) {
                  await brain.update_node_option(
                    { optionId: option.id },
                    {
                      option_text: option.option_text,
                      option_value: option.option_value,
                      routing_rule: option.routing_rule,
                      regulatory_notes: option.regulatory_notes,
                      display_order: option.display_order,
                      note: option.note
                    }
                  );
                }
                toast.success('Options updated successfully');
                if (selectedTree) {
                  loadTreeData(selectedTree.id);
                }
                setShowManageOptionsDialog(false);
              } catch (error) {
                console.error('Error updating options:', error);
                toast.error('Failed to update options');
              }
            }}>
              <div className="mb-6 border border-purple-600 rounded-lg p-4 bg-purple-900/20">
                <h4 className="text-purple-300 font-semibold mb-3">Add New Option</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                  <div>
                    <Label className="block text-xs font-medium text-gray-300 mb-1">Option Text *</Label>
                    <Input
                      value={newOptionData.option_text}
                      onChange={(e) => setNewOptionData({ ...newOptionData, option_text: e.target.value })}
                      className="bg-gray-800 border-gray-600 text-white"
                      placeholder="e.g., Yes, No, Not Applicable"
                    />
                  </div>
                  <div>
                    <Label className="block text-xs font-medium text-gray-300 mb-1">Option Value *</Label>
                    <Input
                      value={newOptionData.option_value}
                      onChange={(e) => setNewOptionData({ ...newOptionData, option_value: e.target.value })}
                      className="bg-gray-800 border-gray-600 text-white"
                      placeholder="e.g., yes, no, na"
                    />
                  </div>
                  <div>
                    <Label className="block text-xs font-medium text-amber-400 mb-1">Routing Rule</Label>
                    <Input
                      value={newOptionData.routing_rule}
                      onChange={(e) => setNewOptionData({ ...newOptionData, routing_rule: e.target.value })}
                      className="bg-amber-900/20 border-amber-600 text-white"
                      placeholder="e.g., -> 'next-node' or outcome: 'result'"
                    />
                  </div>
                  <div>
                    <Label className="block text-xs font-medium text-gray-300 mb-1">Admin Note</Label>
                    <Input
                      value={newOptionData.note}
                      onChange={(e) => setNewOptionData({ ...newOptionData, note: e.target.value })}
                      className="bg-gray-800 border-gray-600 text-white"
                      placeholder="Internal admin notes"
                    />
                  </div>
                  <div>
                    <Label className="block text-xs font-medium text-blue-400 mb-1">Display Order</Label>
                    <Input
                      type="number"
                      value={newOptionData.display_order}
                      onChange={(e) => setNewOptionData({ ...newOptionData, display_order: parseInt(e.target.value) || 0 })}
                      className="bg-blue-900/20 border-blue-600 text-white"
                      placeholder="0"
                    />
                  </div>
                </div>
                <div className="mb-4">
                  <Label className="block text-sm font-medium text-purple-400 mb-1">Regulatory Notes</Label>
                  <Textarea
                    value={newOptionData.regulatory_notes.join('\n')}
                    onChange={(e) => {
                      const notes = e.target.value.split('\n').filter(note => note.trim());
                      setNewOptionData({ ...newOptionData, regulatory_notes: notes });
                    }}
                    className="bg-purple-900/20 border-purple-600 text-white"
                    rows={3}
                    placeholder="Enter regulatory notes (one per line)"
                  />
                </div>
                <Button
                  type="button"
                  onClick={handleCreateOption}
                  disabled={!newOptionData.option_text.trim() || !newOptionData.option_value.trim()}
                  className="bg-purple-600 hover:bg-purple-700 text-white"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Add Option
                </Button>
              </div>

              <div className="mb-6">
                <Label className="block text-sm font-medium text-gray-300 mb-3">Existing Options</Label>
                <div className="space-y-4">
                  {(nodeOptions[managingOptionsForNode!.id] || []).map((option, index) => (
                    <div key={option.id} className="bg-gray-800/50 border border-gray-600 rounded-lg p-4">
                      <div className="flex justify-between items-start mb-3">
                        <div className="flex items-center gap-3">
                          <h4 className="text-white font-medium">Option {index + 1}</h4>
                          <Badge variant="outline" className="text-xs">{option.option_value}</Badge>
                          <Badge variant="outline" className="text-xs bg-blue-900/20 text-blue-400 border-blue-600">
                            Order: {option.display_order || 0}
                          </Badge>
                        </div>
                        <div className="flex gap-2">
                          <Button
                            type="button"
                            onClick={async () => {
                              if (!managingOptionsForNode) return;

                              try {
                                const duplicateData = {
                                  option_text: `${option.option_text} (Copy)`,
                                  option_value: `${option.option_value}_copy`,
                                  routing_rule: option.routing_rule || null,
                                  regulatory_notes: option.regulatory_notes || null,
                                  display_order: (nodeOptions[managingOptionsForNode.id] || []).length,
                                  note: option.note || null
                                };

                                const response = await brain.create_node_option(
                                  { nodeId: managingOptionsForNode.id },
                                  duplicateData
                                );

                                if (response.ok) {
                                  toast.success('Option duplicated successfully');
                                  if (selectedTree) {
                                    loadTreeData(selectedTree.id);
                                  }
                                } else {
                                  toast.error('Failed to duplicate option');
                                }
                              } catch (error) {
                                console.error('Error duplicating option:', error);
                                toast.error('Failed to duplicate option');
                              }
                            }}
                            className="bg-blue-600 hover:bg-blue-700 text-white px-3 py-1 rounded-md text-sm flex items-center gap-1"
                          >
                            <Copy className="w-3 h-3" />
                            DUPLICATE
                          </Button>
                          <button
                            type="button"
                            onClick={async () => {
                              try {
                                // Delete from backend
                                await brain.delete_node_option({ optionId: option.id });
                                
                                // Update UI state after successful deletion
                                const options = [...(nodeOptions[managingOptionsForNode!.id] || [])];
                                options.splice(options.findIndex(o => o.id === option.id), 1);
                                setNodeOptions({ ...nodeOptions, [managingOptionsForNode!.id]: options });
                                
                                toast.success('Option deleted successfully');
                              } catch (error) {
                                console.error('Error deleting option:', error);
                                toast.error('Failed to delete option');
                              }
                            }}
                            className="bg-red-500 hover:bg-red-600 text-white px-3 py-1 rounded-md text-sm"
                          >
                            Remove
                          </button>
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {/* Option Text */}
                        <div>
                          <Label className="block text-xs font-medium text-gray-400 mb-1">Option Text</Label>
                          <Textarea
                            value={option.option_text}
                            onChange={(e) => {
                              const options = [...(nodeOptions[managingOptionsForNode!.id] || [])];
                              options[options.findIndex(o => o.id === option.id)].option_text = e.target.value;
                              setNodeOptions({ ...nodeOptions, [managingOptionsForNode!.id]: options });
                            }}
                            className="w-full p-2 border border-gray-600 rounded-md bg-gray-800 text-white text-sm"
                            rows={3}
                          />
                        </div>
                        
                        {/* Option Value */}
                        <div>
                          <Label className="block text-xs font-medium text-gray-400 mb-1">Option Value</Label>
                          <Input
                            type="text"
                            value={option.option_value}
                            onChange={(e) => {
                              const options = [...(nodeOptions[managingOptionsForNode!.id] || [])];
                              options[options.findIndex(o => o.id === option.id)].option_value = e.target.value;
                              setNodeOptions({ ...nodeOptions, [managingOptionsForNode!.id]: options });
                            }}
                            className="w-full p-2 border border-gray-600 rounded-md bg-gray-800 text-white text-sm"
                          />
                        </div>
                        
                        {/* Routing Rule */}
                        <div>
                          <Label className="block text-xs font-medium text-amber-400 mb-1">Routing Rule</Label>
                          <Input
                            type="text"
                            value={option.routing_rule || ''}
                            onChange={(e) => {
                              const options = [...(nodeOptions[managingOptionsForNode!.id] || [])];
                              options[options.findIndex(o => o.id === option.id)].routing_rule = e.target.value || null;
                              setNodeOptions({ ...nodeOptions, [managingOptionsForNode!.id]: options });
                            }}
                            className="w-full p-2 border border-amber-600 rounded-md bg-amber-900/20 text-white text-sm"
                            placeholder="e.g., -> 'next-node' or outcome: 'result'"
                          />
                        </div>
                        
                        {/* Admin Note */}
                        <div>
                          <Label className="block text-xs font-medium text-gray-400 mb-1">Admin Note</Label>
                          <Input
                            type="text"
                            value={option.note || ''}
                            onChange={(e) => {
                              const options = [...(nodeOptions[managingOptionsForNode!.id] || [])];
                              options[options.findIndex(o => o.id === option.id)].note = e.target.value || null;
                              setNodeOptions({ ...nodeOptions, [managingOptionsForNode!.id]: options });
                            }}
                            className="w-full p-2 border border-gray-600 rounded-md bg-gray-800 text-white text-sm"
                            placeholder="Internal admin notes"
                          />
                        </div>
                        
                        {/* Display Order */}
                        <div>
                          <Label className="block text-xs font-medium text-blue-400 mb-1">Display Order</Label>
                          <Input
                            type="number"
                            value={option.display_order || 0}
                            onChange={(e) => {
                              const options = [...(nodeOptions[managingOptionsForNode!.id] || [])];
                              options[options.findIndex(o => o.id === option.id)].display_order = parseInt(e.target.value) || 0;
                              setNodeOptions({ ...nodeOptions, [managingOptionsForNode!.id]: options });
                            }}
                            className="w-full p-2 border border-blue-600 rounded-md bg-blue-900/20 text-white text-sm"
                            placeholder="0"
                          />
                        </div>
                      </div>
                      
                      {/* Regulatory Notes */}
                      <div className="mt-4">
                        <Label className="block text-xs font-medium text-purple-400 mb-1">Regulatory Notes</Label>
                        <Textarea
                          value={(option.regulatory_notes || []).join('\n')}
                          onChange={(e) => {
                            const options = [...(nodeOptions[managingOptionsForNode!.id] || [])];
                            const notes = e.target.value.split('\n').filter(note => note.trim());
                            options[options.findIndex(o => o.id === option.id)].regulatory_notes = notes.length > 0 ? notes : null;
                            setNodeOptions({ ...nodeOptions, [managingOptionsForNode!.id]: options });
                          }}
                          className="w-full p-2 border border-purple-600 rounded-md bg-purple-900/20 text-white text-sm"
                          rows={3}
                          placeholder="Enter regulatory notes (one per line)"
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
              
              <div className="flex gap-2">
                <button type="submit" className="bg-amber-600 hover:bg-amber-700 text-white px-4 py-2 rounded-md">
                  Save All Changes
                </button>
                <button 
                  type="button" 
                  onClick={() => setShowManageOptionsDialog(false)}
                  className="bg-gray-600 hover:bg-gray-700 text-white px-4 py-2 rounded-md"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
      
      {showEditOptionDialog && (
        <Dialog open={showEditOptionDialog} onOpenChange={setShowEditOptionDialog}>
          <DialogContent className="bg-gray-900 border-gray-700 text-white max-w-2xl">
            <DialogHeader>
              <DialogTitle className="text-amber-400">Edit Option</DialogTitle>
              <DialogDescription className="text-gray-400">
                Modify option properties
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={async (e) => {
              e.preventDefault();
              try {
                const updateData: NodeOptionUpdate = {
                  option_text: editOptionForm.option_text,
                  option_value: editOptionForm.option_value,
                  routing_rule: editOptionForm.routing_rule,
                  regulatory_notes: editOptionForm.regulatory_notes,
                  note: editOptionForm.note
                };
                await brain.update_node_option(
                  { optionId: editingOption!.id },
                  updateData
                );
                toast.success('Option updated successfully');
                if (selectedTree) {
                  loadTreeData(selectedTree.id);
                }
                setShowEditOptionDialog(false);
              } catch (error) {
                console.error('Error updating option:', error);
                toast.error('Failed to update option');
              }
            }}>
              <div className="space-y-4">
                <div>
                  <Label className="text-gray-300">Option Text</Label>
                  <Input
                    value={editOptionForm.option_text}
                    onChange={(e) => setEditOptionForm({ ...editOptionForm, option_text: e.target.value })}
                    className="bg-gray-800 border-gray-600 text-white"
                    placeholder="Option text"
                  />
                </div>
                <div>
                  <Label className="text-gray-300">Option Value</Label>
                  <Input
                    value={editOptionForm.option_value}
                    onChange={(e) => setEditOptionForm({ ...editOptionForm, option_value: e.target.value })}
                    className="bg-gray-800 border-gray-600 text-white"
                    placeholder="Option value"
                  />
                </div>
                <div>
                  <Label className="text-gray-300">Routing Rule</Label>
                  <Input
                    value={editOptionForm.routing_rule}
                    onChange={(e) => setEditOptionForm({ ...editOptionForm, routing_rule: e.target.value })}
                    className="bg-gray-800 border-gray-600 text-white"
                    placeholder="Routing rule"
                  />
                </div>
                <div>
                  <Label className="text-gray-300">Regulatory Notes</Label>
                  <Textarea
                    value={editOptionForm.regulatory_notes.join('\n')}
                    onChange={(e) => setEditOptionForm({ ...editOptionForm, regulatory_notes: e.target.value.split('\n').filter(note => note.trim()) })}
                    className="bg-gray-800 border-gray-600 text-white"
                    placeholder="Regulatory notes (one per line)"
                    rows={2}
                  />
                </div>
                <div>
                  <Label className="text-gray-300">Admin Note</Label>
                  <Input
                    value={editOptionForm.note}
                    onChange={(e) => setEditOptionForm({ ...editOptionForm, note: e.target.value })}
                    className="bg-gray-800 border-gray-600 text-white"
                    placeholder="Admin note"
                  />
                </div>
                <div className="flex justify-end space-x-2 pt-4">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => {
                      setShowEditOptionDialog(false);
                      setEditingOption(null);
                    }}
                    className="border-gray-600 text-gray-400 hover:bg-gray-800"
                  >
                    Cancel
                  </Button>
                  <Button 
                    type="submit"
                    className="bg-amber-600 hover:bg-amber-700 text-white"
                  >
                    <Edit3 className="w-4 h-4 mr-2" />
                    Save Changes
                  </Button>
                </div>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
};

export default ClassificationTreesTab;
