import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import {
  ChevronRight,
  ChevronDown,
  FileText,
  BookOpen,
  Hash,
  ArrowRight,
  ExternalLink,
  Search,
  Bookmark,
  Clock,
  Eye
} from 'lucide-react';
import { cn } from 'utils/cn';
import brain from 'brain';
import { toast } from 'sonner';

interface DocumentSection {
  id: string;
  title: string;
  content: string;
  section_number: string;
  section_type: 'chapter' | 'article' | 'section' | 'subsection' | 'paragraph';
  parent_id?: string;
  order_index: number;
  cross_references: string[];
  annotations_count: number;
}

interface DocumentSectionsViewerProps {
  documentId: number;
  className?: string;
  onSectionSelect?: (section: DocumentSection) => void;
}

const SECTION_ICONS = {
  chapter: BookOpen,
  article: FileText,
  section: Hash,
  subsection: Hash,
  paragraph: Hash
};

const SECTION_COLORS = {
  chapter: 'text-blue-400',
  article: 'text-green-400',
  section: 'text-yellow-400',
  subsection: 'text-purple-400',
  paragraph: 'text-gray-400'
};

export default function DocumentSectionsViewer({ 
  documentId, 
  className,
  onSectionSelect 
}: DocumentSectionsViewerProps) {
  const [sections, setSections] = useState<DocumentSection[]>([]);
  const [loading, setLoading] = useState(true);
  const [expandedSections, setExpandedSections] = useState<Set<string>>(new Set());
  const [selectedSection, setSelectedSection] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [bookmarkedSections, setBookmarkedSections] = useState<Set<string>>(new Set());

  useEffect(() => {
    loadDocumentSections();
  }, [documentId]);

  const loadDocumentSections = async () => {
    try {
      setLoading(true);
      const response = await brain.get_document_sections_admin({ documentId });
      
      if (response.ok) {
        const data = await response.json();
        setSections(data.sections || []);
        
        // Auto-expand top-level sections
        const topLevelSections = data.sections.filter((s: DocumentSection) => !s.parent_id);
        setExpandedSections(new Set(topLevelSections.map((s: DocumentSection) => s.id)));
      } else {
        toast.error('Failed to load document sections');
      }
    } catch (error) {
      console.error('Error loading document sections:', error);
      toast.error('Error loading document sections');
    } finally {
      setLoading(false);
    }
  };

  const toggleSection = (sectionId: string) => {
    const newExpanded = new Set(expandedSections);
    if (newExpanded.has(sectionId)) {
      newExpanded.delete(sectionId);
    } else {
      newExpanded.add(sectionId);
    }
    setExpandedSections(newExpanded);
  };

  const handleSectionSelect = (section: DocumentSection) => {
    setSelectedSection(section.id);
    onSectionSelect?.(section);
  };

  const toggleBookmark = (sectionId: string) => {
    const newBookmarks = new Set(bookmarkedSections);
    if (newBookmarks.has(sectionId)) {
      newBookmarks.delete(sectionId);
      toast.success('Bookmark removed');
    } else {
      newBookmarks.add(sectionId);
      toast.success('Section bookmarked');
    }
    setBookmarkedSections(newBookmarks);
  };

  const buildSectionTree = (sections: DocumentSection[]): DocumentSection[] => {
    const sectionMap = new Map<string, DocumentSection & { children: DocumentSection[] }>();
    const rootSections: (DocumentSection & { children: DocumentSection[] })[] = [];

    // Initialize all sections in the map with children array
    sections.forEach(section => {
      sectionMap.set(section.id, { ...section, children: [] });
    });

    // Build the tree structure
    sections.forEach(section => {
      const sectionWithChildren = sectionMap.get(section.id)!;
      if (section.parent_id && sectionMap.has(section.parent_id)) {
        const parent = sectionMap.get(section.parent_id)!;
        parent.children.push(sectionWithChildren);
      } else {
        rootSections.push(sectionWithChildren);
      }
    });

    // Sort by order_index
    const sortSections = (sections: (DocumentSection & { children: DocumentSection[] })[]) => {
      sections.sort((a, b) => a.order_index - b.order_index);
      sections.forEach(section => sortSections(section.children));
    };
    
    sortSections(rootSections);
    return rootSections;
  };

  const renderSection = (section: DocumentSection & { children: DocumentSection[] }, depth = 0) => {
    const IconComponent = SECTION_ICONS[section.section_type];
    const isExpanded = expandedSections.has(section.id);
    const isSelected = selectedSection === section.id;
    const isBookmarked = bookmarkedSections.has(section.id);
    const hasChildren = section.children.length > 0;
    const colorClass = SECTION_COLORS[section.section_type];

    // Filter by search query if provided
    if (searchQuery && !section.title.toLowerCase().includes(searchQuery.toLowerCase()) && 
        !section.content.toLowerCase().includes(searchQuery.toLowerCase())) {
      return null;
    }

    return (
      <div key={section.id} className="mb-1">
        <div
          className={cn(
            "flex items-center gap-2 p-2 rounded-lg cursor-pointer transition-all duration-200 hover:bg-gray-700/50",
            isSelected && "bg-blue-600/20 border border-blue-500/50",
            `ml-${depth * 4}`
          )}
          onClick={() => handleSectionSelect(section)}
        >
          {hasChildren && (
            <Button
              variant="ghost"
              size="sm"
              className="h-6 w-6 p-0 hover:bg-gray-600"
              onClick={(e) => {
                e.stopPropagation();
                toggleSection(section.id);
              }}
            >
              {isExpanded ? (
                <ChevronDown className="h-3 w-3" />
              ) : (
                <ChevronRight className="h-3 w-3" />
              )}
            </Button>
          )}
          
          <IconComponent className={cn("h-4 w-4", colorClass)} />
          
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2">
              <span className="text-xs text-gray-400 font-mono">
                {section.section_number}
              </span>
              <span className="font-medium text-white truncate">
                {section.title}
              </span>
            </div>
            
            <div className="flex items-center gap-2 mt-1">
              <Badge variant="outline" className="text-xs">
                {section.section_type}
              </Badge>
              
              {section.cross_references.length > 0 && (
                <Badge variant="outline" className="text-xs flex items-center gap-1">
                  <ExternalLink className="h-3 w-3" />
                  {section.cross_references.length} refs
                </Badge>
              )}
              
              {section.annotations_count > 0 && (
                <Badge variant="outline" className="text-xs flex items-center gap-1">
                  <Eye className="h-3 w-3" />
                  {section.annotations_count}
                </Badge>
              )}
            </div>
          </div>
          
          <Button
            variant="ghost"
            size="sm"
            className="h-6 w-6 p-0 hover:bg-gray-600"
            onClick={(e) => {
              e.stopPropagation();
              toggleBookmark(section.id);
            }}
          >
            <Bookmark 
              className={cn(
                "h-3 w-3",
                isBookmarked ? "text-amber-400 fill-amber-400" : "text-gray-400"
              )} 
            />
          </Button>
        </div>
        
        {hasChildren && isExpanded && (
          <div className="ml-4 border-l border-gray-600 pl-2">
            {section.children.map(child => renderSection(child, depth + 1))}
          </div>
        )}
      </div>
    );
  };

  const filteredSections = buildSectionTree(sections);

  if (loading) {
    return (
      <Card className={cn("bg-gray-800 border-gray-700", className)}>
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <FileText className="h-5 w-5" />
            Document Structure
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="animate-pulse">
                <div className="h-8 bg-gray-700 rounded-lg" />
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className={cn("bg-gray-800 border-gray-700", className)}>
      <CardHeader>
        <CardTitle className="text-white flex items-center gap-2">
          <FileText className="h-5 w-5" />
          Document Structure
        </CardTitle>
        
        {/* Search */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
          <input
            type="text"
            placeholder="Search sections..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>
      </CardHeader>
      
      <CardContent className="p-0">
        <ScrollArea className="h-96">
          <div className="p-4">
            {filteredSections.length === 0 ? (
              <div className="text-center py-8">
                <FileText className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-400">No sections found</p>
                <p className="text-sm text-gray-500 mt-1">
                  {searchQuery ? 'Try adjusting your search terms' : 'This document has no structured sections'}
                </p>
              </div>
            ) : (
              <div className="space-y-1">
                {filteredSections.map(section => renderSection(section))}
              </div>
            )}
          </div>
        </ScrollArea>
        
        {bookmarkedSections.size > 0 && (
          <>
            <Separator className="bg-gray-600" />
            <div className="p-4">
              <h4 className="text-sm font-medium text-gray-300 mb-2 flex items-center gap-2">
                <Bookmark className="h-4 w-4" />
                Bookmarked Sections ({bookmarkedSections.size})
              </h4>
              <div className="text-xs text-gray-400">
                Click on bookmarks to jump to sections
              </div>
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
}
