


import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Separator } from '@/components/ui/separator';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Users, UserPlus, Settings, Shield, Eye, Edit, Trash2, Calendar, Clock, Building, Mail, MoreHorizontal, Plus, Search, Filter, RefreshCw, Crown, Star, CheckCircle, XCircle, AlertCircle
} from 'lucide-react';
import { toast } from 'sonner';
import brain from 'brain';

interface TeamMember {
  id: string;
  email: string;
  full_name: string | null;
  role: string;
  status: string;
  invited_at: string;
  joined_at: string | null;
  permissions: any;
}

interface TeamInvitation {
  id: string;
  email: string;
  role: string;
  invited_at: string;
  expires_at: string;
  status: string;
}

interface UserCompanyContext {
  company_id: string | null;
  company_name: string | null;
  company_domain: string | null;
  user_role: string | null;
  permissions: any;
}

interface TeamManagementTabProps {
  userCompanyContext: UserCompanyContext | null;
  onCompanyContextUpdate: (context: UserCompanyContext) => void;
}

export default function TeamManagementTab({ userCompanyContext, onCompanyContextUpdate }: TeamManagementTabProps) {
  const [teamMembers, setTeamMembers] = useState<TeamMember[]>([]);
  const [pendingInvitations, setPendingInvitations] = useState<TeamInvitation[]>([]);
  const [showInviteDialog, setShowInviteDialog] = useState(false);
  const [showCreateCompanyDialog, setShowCreateCompanyDialog] = useState(false);
  const [showMemberDetailsDialog, setShowMemberDetailsDialog] = useState(false);
  const [selectedMember, setSelectedMember] = useState<TeamMember | null>(null);
  const [loading, setLoading] = useState(false);
  const [inviteLoading, setInviteLoading] = useState(false);
  
  // Company creation form
  const [companyForm, setCompanyForm] = useState({
    name: '',
    domain: '',
    billing_email: ''
  });

  // Invite form
  const [inviteForm, setInviteForm] = useState({
    email: '',
    role: 'viewer'
  });

  // Load team data
  useEffect(() => {
    if (userCompanyContext?.company_id) {
      loadTeamData();
    }
  }, [userCompanyContext?.company_id]);

  const loadTeamData = async () => {
    if (!userCompanyContext?.company_id) return;
    
    try {
      setLoading(true);
      const [membersResponse, invitationsResponse] = await Promise.all([
        brain.get_team_members({ companyId: userCompanyContext.company_id }),
        brain.get_pending_invitations({ companyId: userCompanyContext.company_id })
      ]);
      
      const membersData = await membersResponse.json();
      const invitationsData = await invitationsResponse.json();
      
      setTeamMembers(membersData.members || []);
      setPendingInvitations(invitationsData.invitations || []);
    } catch (error) {
      console.error('Error loading team data:', error);
      toast.error('Failed to load team data');
    } finally {
      setLoading(false);
    }
  };

  const handleCreateCompany = async () => {
    try {
      setLoading(true);
      const response = await brain.create_company({
        company_name: companyForm.name,
        company_domain: companyForm.domain,
        billing_email: companyForm.billing_email
      });
      
      if (response.ok) {
        const data = await response.json();
        
        // Create proper company context from the response
        const newCompanyContext: UserCompanyContext = {
          company_id: data.id,
          company_name: data.company_name,
          company_domain: data.company_domain,
          user_role: data.current_user_role || 'owner',
          permissions: {
            can_invite: true,
            can_remove_members: true,
            can_manage_billing: true,
            can_view_audit_logs: true,
            can_manage_settings: true
          }
        };
        
        onCompanyContextUpdate(newCompanyContext);
        setShowCreateCompanyDialog(false);
        setCompanyForm({ name: '', domain: '', billing_email: '' });
        toast.success('Company created successfully!');
      } else {
        toast.error('Failed to create company');
      }
    } catch (error) {
      console.error('Error creating company:', error);
      toast.error('Error creating company');
    } finally {
      setLoading(false);
    }
  };

  const handleInviteTeamMember = async () => {
    if (!userCompanyContext?.company_id) return;
    
    try {
      setInviteLoading(true);
      const response = await brain.invite_team_member(
        { companyId: parseInt(userCompanyContext.company_id) },
        {
          email: inviteForm.email,
          role_name: inviteForm.role
        }
      );
      
      if (response.ok) {
        toast.success('Invitation sent successfully!');
        setShowInviteDialog(false);
        setInviteForm({ email: '', role: 'viewer' });
        loadTeamData(); // Refresh the data
      } else {
        toast.error('Failed to send invitation');
      }
    } catch (error) {
      console.error('Error sending invitation:', error);
      toast.error('Error sending invitation');
    } finally {
      setInviteLoading(false);
    }
  };

  const handleRemoveMember = async (memberId: string) => {
    if (!userCompanyContext?.company_id) return;
    
    try {
      const response = await brain.remove_team_member({
        company_id: userCompanyContext.company_id,
        user_id: memberId
      });
      
      if (response.ok) {
        toast.success('Team member removed successfully');
        loadTeamData();
      } else {
        toast.error('Failed to remove team member');
      }
    } catch (error) {
      console.error('Error removing team member:', error);
      toast.error('Error removing team member');
    }
  };

  const getRoleBadgeColor = (role: string) => {
    switch (role) {
      case 'owner': return 'bg-purple-500/20 text-purple-300 border-purple-500/30';
      case 'admin': return 'bg-red-500/20 text-red-300 border-red-500/30';
      case 'manager': return 'bg-blue-500/20 text-blue-300 border-blue-500/30';
      case 'editor': return 'bg-green-500/20 text-green-300 border-green-500/30';
      case 'viewer': return 'bg-gray-500/20 text-gray-300 border-gray-500/30';
      default: return 'bg-gray-500/20 text-gray-300 border-gray-500/30';
    }
  };

  const getStatusBadgeColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-500/20 text-green-300 border-green-500/30';
      case 'pending': return 'bg-yellow-500/20 text-yellow-300 border-yellow-500/30';
      case 'suspended': return 'bg-red-500/20 text-red-300 border-red-500/30';
      default: return 'bg-gray-500/20 text-gray-300 border-gray-500/30';
    }
  };

  if (!userCompanyContext?.company_id) {
    return (
      <div className="space-y-6">
        <Card className="bg-gray-800/50 border-gray-700">
          <CardHeader>
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-blue-500/20 rounded-lg">
                <Building className="w-5 h-5 text-blue-400" />
              </div>
              <div>
                <CardTitle className="text-white">Create Your Company</CardTitle>
                <CardDescription className="text-gray-400">
                  Set up your organization to start managing team members and billing
                </CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-center py-8">
              <Building className="w-16 h-16 text-gray-600 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-white mb-2">No Company Account</h3>
              <p className="text-gray-400 mb-6 max-w-md mx-auto">
                Create a company account to invite team members, manage billing, and access enterprise features.
              </p>
              <Button 
                onClick={() => setShowCreateCompanyDialog(true)}
                className="bg-blue-600 hover:bg-blue-700 text-white"
              >
                <Building className="w-4 h-4 mr-2" />
                Create Company
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Create Company Dialog */}
        <Dialog open={showCreateCompanyDialog} onOpenChange={setShowCreateCompanyDialog}>
          <DialogContent className="bg-gray-800 border-gray-700 text-white">
            <DialogHeader>
              <DialogTitle>Create Company Account</DialogTitle>
              <DialogDescription className="text-gray-400">
                Set up your organization to manage team members and billing
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="company-name">Company Name</Label>
                <Input
                  id="company-name"
                  value={companyForm.name}
                  onChange={(e) => setCompanyForm(prev => ({ ...prev, name: e.target.value }))}
                  placeholder="Enter company name"
                  className="bg-gray-700 border-gray-600 text-white"
                />
              </div>
              <div>
                <Label htmlFor="company-domain">Company Domain (Optional)</Label>
                <Input
                  id="company-domain"
                  value={companyForm.domain}
                  onChange={(e) => setCompanyForm(prev => ({ ...prev, domain: e.target.value }))}
                  placeholder="example.com"
                  className="bg-gray-700 border-gray-600 text-white"
                />
              </div>
              <div>
                <Label htmlFor="billing-email">Billing Email (Optional)</Label>
                <Input
                  id="billing-email"
                  type="email"
                  value={companyForm.billing_email}
                  onChange={(e) => setCompanyForm(prev => ({ ...prev, billing_email: e.target.value }))}
                  placeholder="billing@example.com"
                  className="bg-gray-700 border-gray-600 text-white"
                />
              </div>
            </div>
            <DialogFooter>
              <Button 
                variant="outline" 
                onClick={() => setShowCreateCompanyDialog(false)}
                className="border-gray-600 text-gray-300 hover:bg-gray-700"
              >
                Cancel
              </Button>
              <Button 
                onClick={handleCreateCompany}
                disabled={!companyForm.name.trim() || loading}
                className="bg-blue-600 hover:bg-blue-700 text-white"
              >
                {loading ? 'Creating...' : 'Create Company'}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Company Overview */}
      <Card className="bg-gray-800/50 border-gray-700">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-blue-500/20 rounded-lg">
                <Building className="w-5 h-5 text-blue-400" />
              </div>
              <div>
                <CardTitle className="text-white">{userCompanyContext.company_name}</CardTitle>
                <CardDescription className="text-gray-400">
                  {userCompanyContext.company_domain || 'No domain set'} • {teamMembers.length} members
                </CardDescription>
              </div>
            </div>
            <Badge className={getRoleBadgeColor(userCompanyContext.user_role || '')}>
              {userCompanyContext.user_role}
            </Badge>
          </div>
        </CardHeader>
      </Card>

      {/* Team Management */}
      <Card className="bg-gray-800/50 border-gray-700">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-purple-500/20 rounded-lg">
                <Users className="w-5 h-5 text-purple-400" />
              </div>
              <div>
                <CardTitle className="text-white">Team Members</CardTitle>
                <CardDescription className="text-gray-400">
                  Manage your team and their access permissions
                </CardDescription>
              </div>
            </div>
            {userCompanyContext.permissions?.can_invite && (
              <Button 
                onClick={() => setShowInviteDialog(true)}
                className="bg-purple-600 hover:bg-purple-700 text-white"
              >
                <UserPlus className="w-4 h-4 mr-2" />
                Invite Member
              </Button>
            )}
          </div>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="text-center py-8">
              <RefreshCw className="w-8 h-8 text-gray-600 animate-spin mx-auto mb-2" />
              <p className="text-gray-400">Loading team data...</p>
            </div>
          ) : (
            <>
              {/* Active Team Members */}
              <div className="space-y-4">
                <h4 className="text-sm font-medium text-gray-300 uppercase tracking-wide">Active Members</h4>
                {teamMembers.length > 0 ? (
                  <Table>
                    <TableHeader>
                      <TableRow className="border-gray-700">
                        <TableHead className="text-gray-300">Member</TableHead>
                        <TableHead className="text-gray-300">Role</TableHead>
                        <TableHead className="text-gray-300">Status</TableHead>
                        <TableHead className="text-gray-300">Joined</TableHead>
                        <TableHead className="text-gray-300 w-[50px]"></TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {teamMembers.map((member) => (
                        <TableRow key={member.id} className="border-gray-700">
                          <TableCell>
                            <div className="flex items-center space-x-3">
                              <div className="w-8 h-8 bg-gray-600 rounded-full flex items-center justify-center">
                                <Users className="w-4 h-4 text-gray-300" />
                              </div>
                              <div>
                                <p className="text-white font-medium">
                                  {member.full_name || member.email}
                                </p>
                                <p className="text-gray-400 text-sm">{member.email}</p>
                              </div>
                            </div>
                          </TableCell>
                          <TableCell>
                            <Badge className={getRoleBadgeColor(member.role)}>
                              {member.role}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <Badge className={getStatusBadgeColor(member.status)}>
                              {member.status}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-gray-400">
                            {member.joined_at ? new Date(member.joined_at).toLocaleDateString() : 'Pending'}
                          </TableCell>
                          <TableCell>
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" size="sm" className="h-8 w-8 p-0 text-gray-400">
                                  <MoreHorizontal className="h-4 w-4" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent className="bg-gray-800 border-gray-700">
                                <DropdownMenuItem 
                                  onClick={() => {
                                    setSelectedMember(member);
                                    setShowMemberDetailsDialog(true);
                                  }}
                                  className="text-gray-300 hover:bg-gray-700"
                                >
                                  <Eye className="mr-2 h-4 w-4" />
                                  View Details
                                </DropdownMenuItem>
                                {userCompanyContext.permissions?.can_remove_members && member.role !== 'owner' && (
                                  <DropdownMenuItem 
                                    onClick={() => handleRemoveMember(member.id)}
                                    className="text-red-400 hover:bg-gray-700"
                                  >
                                    <Trash2 className="mr-2 h-4 w-4" />
                                    Remove
                                  </DropdownMenuItem>
                                )}
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                ) : (
                  <div className="text-center py-8">
                    <Users className="w-12 h-12 text-gray-600 mx-auto mb-2" />
                    <p className="text-gray-400">No team members yet</p>
                  </div>
                )}
              </div>

              {/* Pending Invitations */}
              {pendingInvitations.length > 0 && (
                <>
                  <Separator className="bg-gray-700" />
                  <div className="space-y-4">
                    <h4 className="text-sm font-medium text-gray-300 uppercase tracking-wide">Pending Invitations</h4>
                    <Table>
                      <TableHeader>
                        <TableRow className="border-gray-700">
                          <TableHead className="text-gray-300">Email</TableHead>
                          <TableHead className="text-gray-300">Role</TableHead>
                          <TableHead className="text-gray-300">Invited</TableHead>
                          <TableHead className="text-gray-300">Expires</TableHead>
                          <TableHead className="text-gray-300">Status</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {pendingInvitations.map((invitation) => (
                          <TableRow key={invitation.id} className="border-gray-700">
                            <TableCell className="text-white">{invitation.email}</TableCell>
                            <TableCell>
                              <Badge className={getRoleBadgeColor(invitation.role)}>
                                {invitation.role}
                              </Badge>
                            </TableCell>
                            <TableCell className="text-gray-400">
                              {new Date(invitation.invited_at).toLocaleDateString()}
                            </TableCell>
                            <TableCell className="text-gray-400">
                              {new Date(invitation.expires_at).toLocaleDateString()}
                            </TableCell>
                            <TableCell>
                              <Badge className="bg-yellow-500/20 text-yellow-300 border-yellow-500/30">
                                {invitation.status}
                              </Badge>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </>
              )}
            </>
          )}
        </CardContent>
      </Card>

      {/* Invite Team Member Dialog */}
      <Dialog open={showInviteDialog} onOpenChange={setShowInviteDialog}>
        <DialogContent className="bg-gray-800 border-gray-700 text-white">
          <DialogHeader>
            <DialogTitle>Invite Team Member</DialogTitle>
            <DialogDescription className="text-gray-400">
              Send an invitation to join your team with specified role and permissions
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="invite-email">Email Address</Label>
              <Input
                id="invite-email"
                type="email"
                value={inviteForm.email}
                onChange={(e) => setInviteForm(prev => ({ ...prev, email: e.target.value }))}
                placeholder="colleague@company.com"
                className="bg-gray-700 border-gray-600 text-white"
              />
            </div>
            <div>
              <Label htmlFor="invite-role">Role</Label>
              <Select value={inviteForm.role} onValueChange={(value) => setInviteForm(prev => ({ ...prev, role: value }))}>
                <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-gray-800 border-gray-700">
                  <SelectItem value="viewer" className="text-gray-300">Viewer - Read-only access</SelectItem>
                  <SelectItem value="editor" className="text-gray-300">Editor - Can create and edit</SelectItem>
                  <SelectItem value="manager" className="text-gray-300">Manager - Can manage team</SelectItem>
                  <SelectItem value="admin" className="text-gray-300">Admin - Full access</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => setShowInviteDialog(false)}
              className="border-gray-600 text-gray-300 hover:bg-gray-700"
            >
              Cancel
            </Button>
            <Button 
              onClick={handleInviteTeamMember}
              disabled={!inviteForm.email.trim() || inviteLoading}
              className="bg-purple-600 hover:bg-purple-700 text-white"
            >
              {inviteLoading ? 'Sending...' : 'Send Invitation'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Member Details Dialog */}
      <Dialog open={showMemberDetailsDialog} onOpenChange={setShowMemberDetailsDialog}>
        <DialogContent className="bg-gray-800 border-gray-700 text-white">
          <DialogHeader>
            <DialogTitle>Member Details</DialogTitle>
          </DialogHeader>
          {selectedMember && (
            <div className="space-y-4">
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-gray-600 rounded-full flex items-center justify-center">
                  <Users className="w-6 h-6 text-gray-300" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-white">
                    {selectedMember.full_name || selectedMember.email}
                  </h3>
                  <p className="text-gray-400">{selectedMember.email}</p>
                </div>
              </div>
              <Separator className="bg-gray-700" />
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-gray-300">Role</Label>
                  <p className="text-white mt-1">{selectedMember.role}</p>
                </div>
                <div>
                  <Label className="text-gray-300">Status</Label>
                  <p className="text-white mt-1">{selectedMember.status}</p>
                </div>
                <div>
                  <Label className="text-gray-300">Invited</Label>
                  <p className="text-white mt-1">{new Date(selectedMember.invited_at).toLocaleDateString()}</p>
                </div>
                <div>
                  <Label className="text-gray-300">Joined</Label>
                  <p className="text-white mt-1">
                    {selectedMember.joined_at ? new Date(selectedMember.joined_at).toLocaleDateString() : 'Not yet'}
                  </p>
                </div>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button 
              onClick={() => setShowMemberDetailsDialog(false)}
              className="bg-gray-700 hover:bg-gray-600 text-white"
            >
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
