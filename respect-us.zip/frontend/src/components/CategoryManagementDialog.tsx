


import React, { useState, useEffect } from 'react';
import { toast } from 'sonner';
import brain from 'brain';
import { CreateCategoryRequest, AppApisSavedArticlesCategoryResponse } from 'types';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { 
  Plus, 
  Folder, 
  FileText, 
  Star, 
  Shield, 
  AlertTriangle, 
  BookOpen,
  Trash2,
  Edit2
} from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  onCategoryCreated?: () => void;
}

const ICON_OPTIONS = [
  { name: 'folder', icon: Folder, label: 'Folder' },
  { name: 'file-text', icon: FileText, label: 'Document' },
  { name: 'star', icon: Star, label: 'Important' },
  { name: 'shield', icon: Shield, label: 'Compliance' },
  { name: 'alert-triangle', icon: AlertTriangle, label: 'Alert' },
  { name: 'book-open', icon: BookOpen, label: 'Reference' },
];

const COLOR_OPTIONS = [
  '#3B82F6', // Blue
  '#10B981', // Green  
  '#F59E0B', // Yellow
  '#EF4444', // Red
  '#8B5CF6', // Purple
  '#F97316', // Orange
  '#06B6D4', // Cyan
  '#84CC16', // Lime
];

export const CategoryManagementDialog: React.FC<Props> = ({
  isOpen,
  onClose,
  onCategoryCreated
}) => {
  const [categories, setCategories] = useState<AppApisSavedArticlesCategoryResponse[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isCreating, setIsCreating] = useState(false);
  const [newCategoryName, setNewCategoryName] = useState('');
  const [selectedIcon, setSelectedIcon] = useState('folder');
  const [selectedColor, setSelectedColor] = useState('#3B82F6');
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [editingCategory, setEditingCategory] = useState<AppApisSavedArticlesCategoryResponse | null>(null);
  const [editName, setEditName] = useState('');
  const [editIcon, setEditIcon] = useState('folder');
  const [editColor, setEditColor] = useState('#3B82F6');

  // Load categories
  const loadCategories = async () => {
    try {
      setIsLoading(true);
      const response = await brain.get_article_categories();
      const data = await response.json();
      setCategories(data);
    } catch (error) {
      console.error('Error loading categories:', error);
      toast.error('Failed to load categories');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      loadCategories();
    }
  }, [isOpen]);

  const handleCreateCategory = async () => {
    if (!newCategoryName.trim()) {
      toast.error('Category name is required');
      return;
    }

    try {
      setIsCreating(true);
      const request: CreateCategoryRequest = {
        name: newCategoryName.trim(),
        icon: selectedIcon,
        color: selectedColor,
      };

      await brain.create_article_category(request);
      toast.success('Category created successfully!');
      
      // Reset form
      setNewCategoryName('');
      setSelectedIcon('folder');
      setSelectedColor('#3B82F6');
      setShowCreateForm(false);
      
      // Reload categories
      await loadCategories();
      
      // Notify parent component
      onCategoryCreated?.();
    } catch (error) {
      console.error('Error creating category:', error);
      toast.error('Failed to create category');
    } finally {
      setIsCreating(false);
    }
  };

  const handleDeleteCategory = async (categoryId: number) => {
    try {
      await brain.delete_article_category({ categoryId });
      toast.success('Category deleted successfully!');
      await loadCategories();
      onCategoryCreated?.(); // Refresh parent
    } catch (error) {
      console.error('Error deleting category:', error);
      toast.error('Failed to delete category');
    }
  };

  const handleEditCategory = (category: AppApisSavedArticlesCategoryResponse) => {
    setEditingCategory(category);
    setEditName(category.name);
    setEditIcon(category.icon);
    setEditColor(category.color);
    setIsEditing(true);
  };

  const handleUpdateCategory = async () => {
    if (!editingCategory || !editName.trim()) {
      toast.error('Category name is required');
      return;
    }

    try {
      setIsCreating(true);
      await brain.update_article_category(
        { categoryId: editingCategory.id },
        {
          name: editName.trim(),
          icon: editIcon,
          color: editColor,
        }
      );
      toast.success('Category updated successfully!');
      
      // Reset edit form
      setIsEditing(false);
      setEditingCategory(null);
      setEditName('');
      setEditIcon('folder');
      setEditColor('#3B82F6');
      
      // Reload categories
      await loadCategories();
      
      // Notify parent component
      onCategoryCreated?.();
    } catch (error) {
      console.error('Error updating category:', error);
      toast.error('Failed to update category');
    } finally {
      setIsCreating(false);
    }
  };

  const cancelEdit = () => {
    setIsEditing(false);
    setEditingCategory(null);
    setEditName('');
    setEditIcon('folder');
    setEditColor('#3B82F6');
  };

  const getIconComponent = (iconName: string) => {
    const iconOption = ICON_OPTIONS.find(opt => opt.name === iconName);
    return iconOption?.icon || Folder;
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-gray-900 border-gray-800 text-white max-w-2xl">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold text-white">Manage Categories</DialogTitle>
          <DialogDescription className="text-gray-400">
            Create and organize categories for your saved articles.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* Create New Category Section */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-semibold text-white">Create New Category</h3>
              {!showCreateForm && !isEditing && (
                <Button
                  onClick={() => setShowCreateForm(true)}
                  className="bg-blue-600 hover:bg-blue-700"
                  size="sm"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Add Category
                </Button>
              )}
            </div>

            {/* Edit Category Form */}
            {isEditing && editingCategory && (
              <Card className="bg-gray-800 border-gray-700">
                <CardContent className="p-4 space-y-4">
                  <div className="flex items-center justify-between mb-4">
                    <h4 className="text-lg font-semibold text-white">Edit Category</h4>
                  </div>
                  
                  <div className="space-y-2">
                    <Label className="text-sm font-medium text-white">Category Name</Label>
                    <Input
                      value={editName}
                      onChange={(e) => setEditName(e.target.value)}
                      placeholder="Enter category name..."
                      className="bg-gray-700 border-gray-600 text-white"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label className="text-sm font-medium text-white">Icon</Label>
                    <div className="flex flex-wrap gap-2">
                      {ICON_OPTIONS.map((option) => {
                        const IconComponent = option.icon;
                        const isSelected = editIcon === option.name;
                        return (
                          <button
                            key={option.name}
                            onClick={() => setEditIcon(option.name)}
                            className={`p-2 rounded-lg border transition-colors ${
                              isSelected
                                ? 'border-blue-500 bg-blue-500/20'
                                : 'border-gray-600 hover:border-gray-500'
                            }`}
                            title={option.label}
                          >
                            <IconComponent className="w-4 h-4 text-white" />
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label className="text-sm font-medium text-white">Color</Label>
                    <div className="flex flex-wrap gap-2">
                      {COLOR_OPTIONS.map((color) => {
                        const isSelected = editColor === color;
                        return (
                          <button
                            key={color}
                            onClick={() => setEditColor(color)}
                            className={`w-8 h-8 rounded-lg border-2 transition-all ${
                              isSelected
                                ? 'border-white scale-110'
                                : 'border-gray-600 hover:border-gray-400'
                            }`}
                            style={{ backgroundColor: color }}
                            title={color}
                          />
                        );
                      })}
                    </div>
                  </div>

                  <div className="flex gap-2 pt-2">
                    <Button
                      onClick={handleUpdateCategory}
                      disabled={isCreating || !editName.trim()}
                      className="bg-green-600 hover:bg-green-700"
                    >
                      {isCreating ? 'Updating...' : 'Update Category'}
                    </Button>
                    <Button
                      onClick={cancelEdit}
                      variant="outline"
                      className="border-gray-600 text-gray-300 hover:bg-gray-800"
                    >
                      Cancel
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}

            {showCreateForm && !isEditing && (
              <Card className="bg-gray-800 border-gray-700">
                <CardContent className="p-4 space-y-4">
                  <div className="space-y-2">
                    <Label className="text-sm font-medium text-white">Category Name</Label>
                    <Input
                      value={newCategoryName}
                      onChange={(e) => setNewCategoryName(e.target.value)}
                      placeholder="Enter category name..."
                      className="bg-gray-700 border-gray-600 text-white"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label className="text-sm font-medium text-white">Icon</Label>
                    <div className="flex flex-wrap gap-2">
                      {ICON_OPTIONS.map((option) => {
                        const IconComponent = option.icon;
                        const isSelected = selectedIcon === option.name;
                        return (
                          <button
                            key={option.name}
                            onClick={() => setSelectedIcon(option.name)}
                            className={`p-2 rounded-lg border transition-colors ${
                              isSelected
                                ? 'border-blue-500 bg-blue-500/20'
                                : 'border-gray-600 hover:border-gray-500'
                            }`}
                            title={option.label}
                          >
                            <IconComponent className="w-4 h-4 text-white" />
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label className="text-sm font-medium text-white">Color</Label>
                    <div className="flex flex-wrap gap-2">
                      {COLOR_OPTIONS.map((color) => {
                        const isSelected = selectedColor === color;
                        return (
                          <button
                            key={color}
                            onClick={() => setSelectedColor(color)}
                            className={`w-8 h-8 rounded-lg border-2 transition-all ${
                              isSelected
                                ? 'border-white scale-110'
                                : 'border-gray-600 hover:border-gray-400'
                            }`}
                            style={{ backgroundColor: color }}
                            title={color}
                          />
                        );
                      })}
                    </div>
                  </div>

                  <div className="flex gap-2 pt-2">
                    <Button
                      onClick={handleCreateCategory}
                      disabled={isCreating || !newCategoryName.trim()}
                      className="bg-green-600 hover:bg-green-700"
                    >
                      {isCreating ? 'Creating...' : 'Create Category'}
                    </Button>
                    <Button
                      onClick={() => {
                        setShowCreateForm(false);
                        setNewCategoryName('');
                        setSelectedIcon('folder');
                        setSelectedColor('#3B82F6');
                      }}
                      variant="outline"
                      className="border-gray-600 text-gray-300 hover:bg-gray-800"
                    >
                      Cancel
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Existing Categories Section */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-white">Existing Categories</h3>
            
            {isLoading ? (
              <div className="text-center py-8 text-gray-400">Loading categories...</div>
            ) : categories.length === 0 ? (
              <div className="text-center py-8 text-gray-400">
                No categories yet. Create your first category above.
              </div>
            ) : (
              <div className="space-y-2 max-h-60 overflow-y-auto">
                {categories.map((category) => {
                  const IconComponent = getIconComponent(category.icon);
                  return (
                    <div
                      key={category.id}
                      className="flex items-center justify-between p-3 bg-gray-800 rounded-lg border border-gray-700"
                    >
                      <div className="flex items-center gap-3">
                        <div
                          className="p-2 rounded-lg"
                          style={{ backgroundColor: `${category.color}20` }}
                        >
                          <IconComponent 
                            className="w-4 h-4" 
                            style={{ color: category.color }} 
                          />
                        </div>
                        <div>
                          <span className="text-white font-medium">{category.name}</span>
                          <Badge variant="secondary" className="ml-2 text-xs">
                            {category.article_count} articles
                          </Badge>
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Button
                          onClick={() => handleDeleteCategory(category.id)}
                          variant="ghost"
                          size="sm"
                          className="text-red-400 hover:text-red-300 hover:bg-red-400/10"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                        <Button
                          onClick={() => handleEditCategory(category)}
                          variant="ghost"
                          size="sm"
                          className="text-blue-400 hover:text-blue-300 hover:bg-blue-400/10"
                        >
                          <Edit2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>

        <DialogFooter>
          <Button
            onClick={onClose}
            variant="outline"
            className="border-gray-600 text-gray-300 hover:bg-gray-800"
          >
            Close
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};
