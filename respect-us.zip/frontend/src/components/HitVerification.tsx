

import React, { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { AlertTriangle, CheckCircle, XCircle, Eye, Calendar, MapPin, User, Building, Hash, Shield, FileText, Globe, Clock } from 'lucide-react';
import { ScreeningMatch, HitVerificationRequest } from 'brain/data-contracts';
import brain from 'brain';
import { toast } from 'sonner';

export interface Props {
  match: ScreeningMatch;
  customerId: number;
  screeningId: number;
  onVerificationComplete: () => void;
}

export const HitVerification = ({ match, customerId, screeningId, onVerificationComplete }: Props) => {
  const [isOpen, setIsOpen] = useState(false);
  const [decision, setDecision] = useState<string>('');
  const [reason, setReason] = useState('');
  const [notes, setNotes] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleVerification = async () => {
    if (!decision) {
      toast.error('Please select a verification decision');
      return;
    }

    setIsSubmitting(true);
    try {
      const request: HitVerificationRequest = {
        match_id: match.id || 0,
        customer_id: customerId,
        screening_id: screeningId,
        verification_decision: decision,
        verification_reason: reason || undefined,
        verification_notes: notes || undefined,
      };

      await brain.verify_hit(request);
      
      toast.success(`Hit marked as ${decision === 'match' ? 'True Match' : 'False Positive'}`);
      setIsOpen(false);
      onVerificationComplete();
      
      // Reset form
      setDecision('');
      setReason('');
      setNotes('');
    } catch (error) {
      console.error('Hit verification failed:', error);
      toast.error('Failed to verify hit. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const getRiskBadgeColor = (riskLevel: string) => {
    switch (riskLevel.toLowerCase()) {
      case 'critical': return 'bg-red-600 text-white';
      case 'high': return 'bg-orange-500 text-white';
      case 'medium': return 'bg-yellow-500 text-black';
      case 'low': return 'bg-green-500 text-white';
      default: return 'bg-gray-500 text-white';
    }
  };

  const formatMatchScore = (score: number) => {
    return `${Math.round(score * 100)}%`;
  };

  const getMatchTypeDisplay = (type: string) => {
    switch (type.toLowerCase()) {
      case 'exact': return { label: 'Exact Match', color: 'bg-red-100 text-red-800' };
      case 'fuzzy': return { label: 'Fuzzy Match', color: 'bg-orange-100 text-orange-800' };
      case 'alias': return { label: 'Alias Match', color: 'bg-blue-100 text-blue-800' };
      case 'partial': return { label: 'Partial Match', color: 'bg-purple-100 text-purple-800' };
      default: return { label: type, color: 'bg-gray-100 text-gray-800' };
    }
  };

  const formatDate = (dateStr: string | null | undefined) => {
    if (!dateStr) return 'N/A';
    try {
      return new Date(dateStr).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
      });
    } catch {
      return dateStr;
    }
  };

  const matchTypeInfo = getMatchTypeDisplay(match.match_type);
  // Get sanctions details from match_details or a potential sanctions_details field
  const sanctionsDetails = match.match_details || {};

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button 
          variant="outline" 
          size="sm" 
          className="h-8 px-2 text-xs bg-amber-50 border-amber-200 hover:bg-amber-100 text-amber-800"
        >
          <Eye className="h-3 w-3 mr-1" />
          Verify Hit
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-5xl max-h-[90vh] overflow-y-auto bg-gray-900 border-gray-700">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold text-white flex items-center gap-2">
            <AlertTriangle className="h-5 w-5 text-amber-500" />
            Hit Verification Required
          </DialogTitle>
          <DialogDescription className="text-gray-300">
            Review all sanctions regulation details below and determine if this is a true positive match or false positive.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* Match Overview */}
          <Card className="bg-gray-800 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white flex items-center justify-between">
                <span>Match Overview</span>
                <div className="flex gap-2">
                  <Badge className={matchTypeInfo.color}>
                    {matchTypeInfo.label}
                  </Badge>
                  <Badge className={getRiskBadgeColor(match.risk_level)}>
                    {match.risk_level.toUpperCase()} RISK
                  </Badge>
                </div>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-3 gap-4">
                <div>
                  <Label className="text-gray-300 text-xs">Match Score</Label>
                  <div className="text-2xl font-bold text-white">
                    {formatMatchScore(match.match_score)}
                  </div>
                </div>
                <div>
                  <Label className="text-gray-300 text-xs">Matched Field</Label>
                  <div className="text-lg font-medium text-white capitalize">
                    {match.matched_field.replace('_', ' ')}
                  </div>
                </div>
                <div>
                  <Label className="text-gray-300 text-xs">Watchlist</Label>
                  <div className="text-lg font-medium text-white">
                    {match.watchlist_name || 'Unknown List'}
                  </div>
                </div>
              </div>
              
              <div>
                <Label className="text-gray-300 text-xs">Matched Value</Label>
                <div className="text-lg font-medium text-white bg-gray-700 p-2 rounded border">
                  {match.matched_value}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Comprehensive Sanctions Regulation Details */}
          <Card className="bg-gray-800 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Shield className="h-5 w-5" />
                Sanctions Regulation Details
              </CardTitle>
              <CardDescription className="text-gray-300">
                Complete regulatory information from official sanctions lists
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Entity Identity Information */}
              <div>
                <h4 className="text-white font-semibold mb-3 flex items-center gap-2">
                  <User className="h-4 w-4" />
                  Entity Identity
                </h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label className="text-gray-300 text-xs">Listed Name</Label>
                    <div className="text-white font-medium">
                      {match.entity_name || sanctionsDetails.name || 'N/A'}
                    </div>
                  </div>
                  
                  <div>
                    <Label className="text-gray-300 text-xs">Entity Type</Label>
                    <div className="text-white font-medium capitalize">
                      {sanctionsDetails.entity_type || 'N/A'}
                    </div>
                  </div>

                  {sanctionsDetails.citizenship && (
                    <div>
                      <Label className="text-gray-300 text-xs">Citizenship/Nationality</Label>
                      <div className="text-white font-medium">
                        {sanctionsDetails.citizenship}
                      </div>
                    </div>
                  )}

                  {sanctionsDetails.dob && (
                    <div>
                      <Label className="text-gray-300 text-xs flex items-center gap-1">
                        <Calendar className="h-3 w-3" />
                        Date of Birth
                      </Label>
                      <div className="text-white font-medium">
                        {formatDate(sanctionsDetails.dob)}
                      </div>
                    </div>
                  )}

                  {sanctionsDetails.position && (
                    <div>
                      <Label className="text-gray-300 text-xs">Position/Role</Label>
                      <div className="text-white font-medium">
                        {sanctionsDetails.position}
                      </div>
                    </div>
                  )}

                  {sanctionsDetails.location && (
                    <div>
                      <Label className="text-gray-300 text-xs flex items-center gap-1">
                        <MapPin className="h-3 w-3" />
                        Location
                      </Label>
                      <div className="text-white font-medium">
                        {sanctionsDetails.location}
                      </div>
                    </div>
                  )}
                </div>
              </div>

              <Separator className="bg-gray-600" />

              {/* Sanctions Program Information */}
              <div>
                <h4 className="text-white font-semibold mb-3 flex items-center gap-2">
                  <Globe className="h-4 w-4" />
                  Sanctions Program
                </h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label className="text-gray-300 text-xs">Sanctions Program</Label>
                    <div className="text-white font-medium">
                      {sanctionsDetails.sanctions_program || 'N/A'}
                    </div>
                  </div>

                  <div>
                    <Label className="text-gray-300 text-xs">Jurisdiction</Label>
                    <div className="text-white font-medium">
                      {sanctionsDetails.jurisdiction || 'N/A'}
                    </div>
                  </div>

                  <div>
                    <Label className="text-gray-300 text-xs">Source List</Label>
                    <div className="text-white font-medium">
                      {match.watchlist_name || 'N/A'}
                    </div>
                  </div>

                  {sanctionsDetails.sanctions_type && (
                    <div>
                      <Label className="text-gray-300 text-xs">Sanctions Type</Label>
                      <div className="text-white font-medium">
                        {sanctionsDetails.sanctions_type}
                      </div>
                    </div>
                  )}

                  {sanctionsDetails.date_added && (
                    <div>
                      <Label className="text-gray-300 text-xs flex items-center gap-1">
                        <Clock className="h-3 w-3" />
                        Listing Date
                      </Label>
                      <div className="text-white font-medium">
                        {formatDate(sanctionsDetails.date_added)}
                      </div>
                    </div>
                  )}

                  {sanctionsDetails.sector && (
                    <div>
                      <Label className="text-gray-300 text-xs">Sector/Industry</Label>
                      <div className="text-white font-medium">
                        {sanctionsDetails.sector}
                      </div>
                    </div>
                  )}
                </div>
              </div>

              <Separator className="bg-gray-600" />

              {/* Identification Information */}
              {(sanctionsDetails.identification_numbers || sanctionsDetails.passport_number || sanctionsDetails.national_id) && (
                <>
                  <div>
                    <h4 className="text-white font-semibold mb-3 flex items-center gap-2">
                      <Hash className="h-4 w-4" />
                      Identification Numbers
                    </h4>
                    <div className="grid grid-cols-1 gap-2">
                      {sanctionsDetails.identification_numbers && (
                        <div>
                          <Label className="text-gray-300 text-xs">ID Numbers</Label>
                          <div className="text-white font-medium">
                            {Array.isArray(sanctionsDetails.identification_numbers) 
                              ? sanctionsDetails.identification_numbers.join(', ')
                              : sanctionsDetails.identification_numbers}
                          </div>
                        </div>
                      )}
                      {sanctionsDetails.passport_number && (
                        <div>
                          <Label className="text-gray-300 text-xs">Passport Number</Label>
                          <div className="text-white font-medium">
                            {sanctionsDetails.passport_number}
                          </div>
                        </div>
                      )}
                      {sanctionsDetails.national_id && (
                        <div>
                          <Label className="text-gray-300 text-xs">National ID</Label>
                          <div className="text-white font-medium">
                            {sanctionsDetails.national_id}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                  <Separator className="bg-gray-600" />
                </>
              )}

              {/* Known Aliases */}
              {sanctionsDetails.aliases && sanctionsDetails.aliases.length > 0 && (
                <>
                  <div>
                    <h4 className="text-white font-semibold mb-3">Known Aliases & Alternative Names</h4>
                    <div className="flex flex-wrap gap-2">
                      {sanctionsDetails.aliases.map((alias: string, index: number) => (
                        <Badge key={index} variant="secondary" className="text-xs bg-blue-100 text-blue-800">
                          {alias}
                        </Badge>
                      ))}
                    </div>
                  </div>
                  <Separator className="bg-gray-600" />
                </>
              )}

              {/* Description & Additional Details */}
              {sanctionsDetails.description && (
                <div>
                  <h4 className="text-white font-semibold mb-3 flex items-center gap-2">
                    <FileText className="h-4 w-4" />
                    Regulatory Description
                  </h4>
                  <div className="text-white text-sm bg-gray-700 p-3 rounded border leading-relaxed">
                    {sanctionsDetails.description}
                  </div>
                </div>
              )}

              {/* Additional Raw Details */}
              {Object.keys(sanctionsDetails).length > 0 && (
                <div>
                  <h4 className="text-white font-semibold mb-3">Additional Regulatory Details</h4>
                  <div className="bg-gray-700 p-3 rounded border text-xs">
                    <pre className="text-gray-300 whitespace-pre-wrap overflow-x-auto">
                      {JSON.stringify(sanctionsDetails, null, 2)}
                    </pre>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Verification Decision */}
          <Card className="bg-gray-800 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white">Verification Decision</CardTitle>
              <CardDescription className="text-gray-300">
                Based on your review, is this a true positive match or false positive?
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label className="text-gray-300 text-sm font-medium">Decision *</Label>
                <Select value={decision} onValueChange={setDecision}>
                  <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                    <SelectValue placeholder="Select verification decision" />
                  </SelectTrigger>
                  <SelectContent className="bg-gray-700 border-gray-600">
                    <SelectItem value="match" className="text-white hover:bg-gray-600">
                      <div className="flex items-center gap-2">
                        <CheckCircle className="h-4 w-4 text-red-500" />
                        True Match - This is a positive hit
                      </div>
                    </SelectItem>
                    <SelectItem value="no_match" className="text-white hover:bg-gray-600">
                      <div className="flex items-center gap-2">
                        <XCircle className="h-4 w-4 text-green-500" />
                        False Positive - This is not a match
                      </div>
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label className="text-gray-300 text-sm font-medium">Reason</Label>
                <Select value={reason} onValueChange={setReason}>
                  <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                    <SelectValue placeholder="Select reason (optional)" />
                  </SelectTrigger>
                  <SelectContent className="bg-gray-700 border-gray-600">
                    {decision === 'match' ? (
                      <>
                        <SelectItem value="exact_name_match" className="text-white hover:bg-gray-600">
                          Exact name match
                        </SelectItem>
                        <SelectItem value="alias_confirmed" className="text-white hover:bg-gray-600">
                          Alias confirmed
                        </SelectItem>
                        <SelectItem value="additional_identifiers" className="text-white hover:bg-gray-600">
                          Additional identifiers match
                        </SelectItem>
                        <SelectItem value="manual_verification" className="text-white hover:bg-gray-600">
                          Manual verification confirmed
                        </SelectItem>
                      </>
                    ) : (
                      <>
                        <SelectItem value="different_person" className="text-white hover:bg-gray-600">
                          Different person with similar name
                        </SelectItem>
                        <SelectItem value="spelling_variation" className="text-white hover:bg-gray-600">
                          Common spelling variation
                        </SelectItem>
                        <SelectItem value="different_jurisdiction" className="text-white hover:bg-gray-600">
                          Different jurisdiction/location
                        </SelectItem>
                        <SelectItem value="insufficient_information" className="text-white hover:bg-gray-600">
                          Insufficient information to confirm
                        </SelectItem>
                        <SelectItem value="system_error" className="text-white hover:bg-gray-600">
                          System/algorithm error
                        </SelectItem>
                      </>
                    )}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label className="text-gray-300 text-sm font-medium">Additional Notes</Label>
                <Textarea
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Add any additional notes about this verification decision..."
                  className="bg-gray-700 border-gray-600 text-white placeholder-gray-400"
                  rows={3}
                />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Action Buttons */}
        <div className="flex justify-end gap-3 pt-4 border-t border-gray-700">
          <Button 
            variant="outline" 
            onClick={() => setIsOpen(false)}
            className="border-gray-600 text-gray-300 hover:bg-gray-700"
          >
            Cancel
          </Button>
          <Button 
            onClick={handleVerification}
            disabled={!decision || isSubmitting}
            className={`${decision === 'match' 
              ? 'bg-red-600 hover:bg-red-700' 
              : decision === 'no_match' 
              ? 'bg-green-600 hover:bg-green-700'
              : 'bg-blue-600 hover:bg-blue-700'
            } text-white`}
          >
            {isSubmitting ? 'Submitting...' : `Submit ${decision === 'match' ? 'True Match' : decision === 'no_match' ? 'False Positive' : 'Decision'}`}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};
