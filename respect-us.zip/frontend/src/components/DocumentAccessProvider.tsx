import React, { createContext, useContext, ReactNode } from 'react';
import { CreditConfirmationDialog } from './CreditConfirmationDialog';
import { useDocumentAccess, UseDocumentAccessOptions } from 'utils/useDocumentAccess';

interface DocumentAccessContextType {
  accessDocument: (documentId: number) => Promise<any>;
  accessDocumentSections: (documentId: number) => Promise<any>;
  isLoading: boolean;
}

const DocumentAccessContext = createContext<DocumentAccessContextType | null>(null);

export const useDocumentAccessContext = () => {
  const context = useContext(DocumentAccessContext);
  if (!context) {
    throw new Error('useDocumentAccessContext must be used within a DocumentAccessProvider');
  }
  return context;
};

interface DocumentAccessProviderProps {
  children: ReactNode;
  options?: UseDocumentAccessOptions;
}

export const DocumentAccessProvider: React.FC<DocumentAccessProviderProps> = ({
  children,
  options = {}
}) => {
  const {
    isLoading,
    creditConfirmation,
    accessDocument,
    accessDocumentSections,
    confirmCreditAccess,
    cancelCreditAccess,
  } = useDocumentAccess(options);
  
  const contextValue: DocumentAccessContextType = {
    accessDocument,
    accessDocumentSections,
    isLoading,
  };
  
  return (
    <DocumentAccessContext.Provider value={contextValue}>
      {children}
      
      {creditConfirmation && (
        <CreditConfirmationDialog
          open={!!creditConfirmation}
          onOpenChange={cancelCreditAccess}
          onConfirm={confirmCreditAccess}
          onCancel={cancelCreditAccess}
          documentTitle={creditConfirmation.documentTitle}
          requiredCredits={creditConfirmation.requiredCredits}
          currentBalance={creditConfirmation.currentBalance}
          isLoading={isLoading}
        />
      )}
    </DocumentAccessContext.Provider>
  );
};
