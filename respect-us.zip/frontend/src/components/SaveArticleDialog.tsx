

import React, { useState } from 'react';
import { toast } from 'sonner';
import brain from 'brain';
import { SaveArticleRequest } from 'types';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { CategorySelector } from 'components/CategorySelector';
import { Bookmark } from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  document: {
    id: string;
    title: string;
    description?: string;
    type?: string;
    url?: string;
  } | null;
  onSaved?: () => void;
}

export const SaveArticleDialog: React.FC<Props> = ({
  isOpen,
  onClose,
  document,
  onSaved
}) => {
  const [isLoading, setIsLoading] = useState(false);
  const [selectedCategoryIds, setSelectedCategoryIds] = useState<number[]>([]);
  const [customTitle, setCustomTitle] = useState(document?.title || '');
  const [customDescription, setCustomDescription] = useState(document?.description || '');

  // Update state when document changes
  React.useEffect(() => {
    if (document) {
      setCustomTitle(document.title || '');
      setCustomDescription(document.description || '');
      setSelectedCategoryIds([]);
    }
  }, [document]);

  const handleSave = async () => {
    if (!document) {
      toast.error('No document selected');
      return;
    }
    
    if (!customTitle.trim()) {
      toast.error('Title is required');
      return;
    }

    try {
      setIsLoading(true);
      
      const saveRequest: SaveArticleRequest = {
        document_id: String(document.id),
        document_title: customTitle,
        document_description: customDescription || undefined,
        document_type: document.type || undefined,
        document_url: document.url || undefined,
        category_ids: selectedCategoryIds,
      };

      await brain.save_article(saveRequest);
      toast.success('Article saved successfully');
      onSaved?.();
      onClose();
    } catch (error: any) {
      console.error('Error saving article:', error);
      if (error.message?.includes('already saved')) {
        toast.error('Article is already saved');
      } else {
        toast.error('Failed to save article');
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleClose = () => {
    if (!isLoading) {
      onClose();
      // Reset form when closing
      setSelectedCategoryIds([]);
      setCustomTitle(document?.title || '');
      setCustomDescription(document?.description || '');
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="bg-gray-900 border-gray-700 max-w-md">
        <DialogHeader>
          <DialogTitle className="text-white flex items-center gap-2">
            <Bookmark className="w-5 h-5 text-blue-400" />
            Save Article
          </DialogTitle>
          <DialogDescription className="text-gray-400">
            Save this article to your collection and organize it with categories.
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4">
          <div>
            <Label htmlFor="title" className="text-sm font-medium text-white">
              Title
            </Label>
            <Input
              id="title"
              value={customTitle}
              onChange={(e) => setCustomTitle(e.target.value)}
              placeholder="Enter article title"
              className="mt-1 bg-gray-800 border-gray-600"
            />
          </div>
          
          <div>
            <Label htmlFor="description" className="text-sm font-medium text-white">
              Description (Optional)
            </Label>
            <Textarea
              id="description"
              value={customDescription}
              onChange={(e) => setCustomDescription(e.target.value)}
              placeholder="Add a description or notes"
              className="mt-1 bg-gray-800 border-gray-600"
              rows={3}
            />
          </div>

          <CategorySelector
            selectedCategoryIds={selectedCategoryIds}
            onCategoryChange={setSelectedCategoryIds}
            multiSelect={true}
            placeholder="Select categories to organize this article"
          />
        </div>

        <DialogFooter>
          <Button
            variant="outline"
            onClick={handleClose}
            disabled={isLoading}
          >
            Cancel
          </Button>
          <Button
            onClick={handleSave}
            disabled={isLoading}
            className="bg-blue-600 hover:bg-blue-700"
          >
            {isLoading ? 'Saving...' : 'Save Article'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};
