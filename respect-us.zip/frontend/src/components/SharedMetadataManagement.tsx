import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import {
  Database,
  Plus,
  Edit,
  Trash2,
  Copy,
  Search,
  Filter,
  Upload,
  Download,
  Layers,
  FileText,
  Shield,
  Scale,
  Target,
  Tag
} from 'lucide-react';
import { toast } from 'sonner';
import brain from 'brain';
import { ClassificationNote, CreateNoteRequest } from '../brain/data-contracts';
import OutcomesTab from './OutcomesTab';
import DocumentMetadataManagement from './DocumentMetadataManagement';

interface MetadataNote extends ClassificationNote {
  module_type: string;
}

export default function SharedMetadataManagement() {
  const [activeTab, setActiveTab] = useState('notes');

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-gray-800/30 backdrop-blur-sm border border-gray-700 rounded-lg p-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-xl font-semibold text-white mb-2">Shared Metadata Management</h2>
            <p className="text-gray-400">Centralized metadata management for all compliance modules</p>
          </div>
        </div>
      </div>

      {/* Main Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <div className="bg-gray-800/30 backdrop-blur-sm border border-gray-700 rounded-lg p-4">
          <TabsList className="bg-gray-800/50 border-gray-600">
            <TabsTrigger 
              value="notes" 
              className="text-gray-300 data-[state=active]:text-white data-[state=active]:bg-blue-600/20"
            >
              <div className="flex items-center gap-2">
                <FileText className="h-4 w-4" />
                <span>Classification Notes</span>
              </div>
            </TabsTrigger>
            <TabsTrigger 
              value="outcomes" 
              className="text-gray-300 data-[state=active]:text-white data-[state=active]:bg-blue-600/20"
            >
              <div className="flex items-center gap-2">
                <Target className="h-4 w-4" />
                <span>Outcomes</span>
              </div>
            </TabsTrigger>
            <TabsTrigger 
              value="document-metadata" 
              className="text-gray-300 data-[state=active]:text-white data-[state=active]:bg-blue-600/20"
            >
              <div className="flex items-center gap-2">
                <Tag className="h-4 w-4" />
                <span>Document Metadata</span>
              </div>
            </TabsTrigger>
          </TabsList>
        </div>

        {/* Classification Notes Tab */}
        <TabsContent value="notes" className="space-y-6">
          <ClassificationNotesManagement />
        </TabsContent>

        {/* Outcomes Tab */}
        <TabsContent value="outcomes" className="space-y-6">
          <div className="bg-gray-800/30 backdrop-blur-sm border border-gray-700 rounded-lg p-6">
            <h3 className="text-lg font-semibold text-white mb-4">Classification Outcomes</h3>
            <p className="text-gray-400 mb-6">Manage shared classification outcomes across all modules</p>
            <OutcomesTab />
          </div>
        </TabsContent>

        {/* Document Metadata Tab */}
        <TabsContent value="document-metadata" className="space-y-6">
          <div className="bg-gray-800/30 backdrop-blur-sm border border-gray-700 rounded-lg p-6">
            <h3 className="text-lg font-semibold text-white mb-4">Document Metadata Options</h3>
            <p className="text-gray-400 mb-6">Manage document metadata categories, types, and subjects</p>
            <DocumentMetadataManagement />
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}

// Classification Notes Management Component
function ClassificationNotesManagement() {
  const [notes, setNotes] = useState<MetadataNote[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedModule, setSelectedModule] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  
  // Dialog states
  const [isCreateNoteOpen, setIsCreateNoteOpen] = useState(false);
  const [isEditNoteOpen, setIsEditNoteOpen] = useState(false);
  const [editingNote, setEditingNote] = useState<MetadataNote | null>(null);
  const [showExportDialog, setShowExportDialog] = useState(false);
  const [showImportDialog, setShowImportDialog] = useState(false);
  const [importFile, setImportFile] = useState<File | null>(null);

  // Form data
  const [newNoteData, setNewNoteData] = useState({
    note_key: '',
    title: '',
    content: '',
    tree_id: '',
    module_type: 'product_classification'
  });

  // Module definitions
  const modules = [
    { value: 'all', label: 'All Modules', icon: Database, color: 'gray' },
    { value: 'product_classification', label: 'Product Classification', icon: Layers, color: 'blue' },
    { value: 'sanctions', label: 'Sanctions & Embargoes', icon: Shield, color: 'red' },
    { value: 'license_determination', label: 'License Determination', icon: Scale, color: 'green' }
  ];

  useEffect(() => {
    loadNotes();
  }, []);

  const loadNotes = async () => {
    try {
      setLoading(true);
      const response = await brain.list_classification_notes({});
      if (response.ok) {
        const data = await response.json();
        setNotes(Array.isArray(data) ? data : []);
      }
    } catch (error) {
      console.error('Error loading metadata notes:', error);
      toast.error('Failed to load metadata notes');
    } finally {
      setLoading(false);
    }
  };

  const handleCreateNote = async () => {
    if (!newNoteData.note_key.trim() || !newNoteData.title.trim()) {
      toast.error('Note key and title are required');
      return;
    }

    try {
      const response = await brain.create_classification_note(newNoteData);
      if (response.ok) {
        toast.success('Metadata note created successfully');
        setIsCreateNoteOpen(false);
        setNewNoteData({
          note_key: '',
          title: '',
          content: '',
          tree_id: '',
          module_type: 'product_classification'
        });
        await loadNotes();
      } else {
        const errorData = await response.json().catch(() => ({ message: 'Failed to create note' }));
        toast.error(errorData.message || 'Failed to create metadata note');
      }
    } catch (error) {
      console.error('Error creating note:', error);
      toast.error('Failed to create metadata note');
    }
  };

  const handleUpdateNote = async () => {
    if (!editingNote) return;

    try {
      const response = await brain.update_classification_note({ noteId: editingNote.id }, newNoteData);
      if (response.ok) {
        toast.success('Metadata note updated successfully');
        setIsEditNoteOpen(false);
        setEditingNote(null);
        setNewNoteData({
          note_key: '',
          title: '',
          content: '',
          tree_id: '',
          module_type: 'product_classification'
        });
        await loadNotes();
      } else {
        toast.error('Failed to update metadata note');
      }
    } catch (error) {
      console.error('Error updating note:', error);
      toast.error('Failed to update metadata note');
    }
  };

  const handleDeleteNote = async (noteId: number) => {
    try {
      const response = await brain.delete_classification_note({ noteId });
      if (response.ok) {
        toast.success('Metadata note deleted successfully');
        await loadNotes();
      } else {
        toast.error('Failed to delete metadata note');
      }
    } catch (error) {
      console.error('Error deleting note:', error);
      toast.error('Failed to delete metadata note');
    }
  };

  const handleDuplicateNote = async (note: MetadataNote) => {
    try {
      const duplicatedNote = {
        note_key: `${note.note_key}_copy`,
        title: `${note.title} (Copy)`,
        content: note.content,
        tree_id: note.tree_id,
        module_type: note.module_type || 'product_classification'
      };
      
      const response = await brain.create_classification_note(duplicatedNote);
      if (response.ok) {
        toast.success('Metadata note duplicated successfully');
        await loadNotes();
      } else {
        toast.error('Failed to duplicate metadata note');
      }
    } catch (error) {
      console.error('Error duplicating note:', error);
      toast.error('Failed to duplicate metadata note');
    }
  };

  const handleEditNote = (note: MetadataNote) => {
    setEditingNote(note);
    setNewNoteData({
      note_key: note.note_key,
      title: note.title,
      content: note.content,
      tree_id: note.tree_id,
      module_type: note.module_type || 'product_classification'
    });
    setIsEditNoteOpen(true);
  };

  const handleExportNotes = async () => {
    try {
      const moduleType = selectedModule === 'all' ? 'product_classification' : selectedModule;
      const response = await brain.export_notes_to_excel({ 
        treeId: 'global',
        module_type: moduleType
      });
      
      if (response.ok) {
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `metadata_notes_${moduleType}_${new Date().toISOString().split('T')[0]}.xlsx`;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        document.body.removeChild(a);
        toast.success('Metadata notes exported successfully');
      } else {
        toast.error('Failed to export metadata notes');
      }
    } catch (error) {
      console.error('Error exporting notes:', error);
      toast.error('Failed to export metadata notes');
    }
  };

  const handleImportNotes = async () => {
    if (!importFile) {
      toast.error('Please select a file to import');
      return;
    }

    try {
      const moduleType = selectedModule === 'all' ? 'product_classification' : selectedModule;
      const response = await brain.import_notes_from_excel(
        { 
          treeId: 'global',
          module_type: moduleType
        },
        { file_content: importFile }
      );
      
      if (response.ok) {
        const result = await response.json();
        toast.success(`Import completed! ${result.imported_count} notes imported, ${result.error_count} errors`);
        setShowImportDialog(false);
        setImportFile(null);
        await loadNotes();
      } else {
        toast.error('Failed to import metadata notes');
      }
    } catch (error) {
      console.error('Error importing notes:', error);
      toast.error('Failed to import metadata notes');
    }
  };

  // Filter notes based on selected module and search query
  const filteredNotes = notes.filter(note => {
    const matchesModule = selectedModule === 'all' || (note.module_type || 'product_classification') === selectedModule;
    const matchesSearch = !searchQuery || 
      note.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      note.note_key.toLowerCase().includes(searchQuery.toLowerCase()) ||
      note.content.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesModule && matchesSearch;
  });

  // Get module statistics
  const moduleStats = modules.slice(1).map(module => ({
    ...module,
    count: notes.filter(note => (note.module_type || 'product_classification') === module.value).length
  }));

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-96">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-400">Loading metadata...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-gray-800/30 backdrop-blur-sm border border-gray-700 rounded-lg p-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-xl font-semibold text-white mb-2">Shared Metadata Management</h2>
            <p className="text-gray-400">Centralized metadata management for all compliance modules</p>
          </div>
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowExportDialog(true)}
              className="border-gray-600 text-gray-300 hover:bg-gray-700"
            >
              <Download className="h-4 w-4 mr-2" />
              Export
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowImportDialog(true)}
              className="border-gray-600 text-gray-300 hover:bg-gray-700"
            >
              <Upload className="h-4 w-4 mr-2" />
              Import
            </Button>
            <Button
              onClick={() => setIsCreateNoteOpen(true)}
              className="bg-blue-600 hover:bg-blue-700 text-white"
            >
              <Plus className="h-4 w-4 mr-2" />
              Add Metadata
            </Button>
          </div>
        </div>

        {/* Module Statistics */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {moduleStats.map((module) => {
            const IconComponent = module.icon;
            return (
              <Card key={module.value} className={`bg-gradient-to-br from-${module.color}-600/20 to-${module.color}-800/20 border-${module.color}-600/30`}>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className={`text-${module.color}-200 text-sm`}>{module.label}</p>
                      <p className="text-2xl font-bold text-white">{module.count}</p>
                    </div>
                    <IconComponent className={`h-8 w-8 text-${module.color}-400`} />
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>

      {/* Filters and Search */}
      <div className="bg-gray-800/30 backdrop-blur-sm border border-gray-700 rounded-lg p-4">
        <div className="flex items-center gap-4">
          <div className="flex-1">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Search metadata notes..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 bg-gray-700 border-gray-600 text-white"
              />
            </div>
          </div>
          <div className="w-64">
            <Select value={selectedModule} onValueChange={setSelectedModule}>
              <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                <SelectValue placeholder="Select module" />
              </SelectTrigger>
              <SelectContent className="bg-gray-700 border-gray-600">
                {modules.map((module) => {
                  const IconComponent = module.icon;
                  return (
                    <SelectItem key={module.value} value={module.value}>
                      <div className="flex items-center gap-2">
                        <IconComponent className="h-4 w-4" />
                        <span>{module.label}</span>
                      </div>
                    </SelectItem>
                  );
                })}
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>

      {/* Metadata Notes List */}
      <div className="bg-gray-800/30 backdrop-blur-sm border border-gray-700 rounded-lg">
        <div className="p-4 border-b border-gray-700">
          <h3 className="text-lg font-semibold text-white">
            Metadata Notes ({filteredNotes.length})
          </h3>
        </div>
        <div className="p-4">
          {filteredNotes.length === 0 ? (
            <div className="text-center py-8">
              <Database className="h-12 w-12 text-gray-500 mx-auto mb-4" />
              <p className="text-gray-400 mb-2">No metadata notes found</p>
              <p className="text-sm text-gray-500">
                {selectedModule === 'all' 
                  ? 'Start by creating your first metadata note'
                  : `No notes found for ${modules.find(m => m.value === selectedModule)?.label}`
                }
              </p>
              <Button
                onClick={() => setIsCreateNoteOpen(true)}
                className="mt-4 bg-blue-600 hover:bg-blue-700 text-white"
              >
                <Plus className="h-4 w-4 mr-2" />
                Create First Note
              </Button>
            </div>
          ) : (
            <div className="space-y-3">
              {filteredNotes.map((note) => {
                const module = modules.find(m => m.value === (note.module_type || 'product_classification'));
                const IconComponent = module?.icon || Database;
                
                return (
                  <Card key={note.id} className="bg-gray-700/30 border-gray-600 hover:bg-gray-700/50 transition-colors">
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-2">
                            <IconComponent className="h-5 w-5 text-blue-400" />
                            <div>
                              <h4 className="font-medium text-white">{note.title}</h4>
                              <div className="flex items-center gap-2 mt-1">
                                <Badge variant="outline" className="text-xs">
                                  {note.note_key}
                                </Badge>
                                {module && (
                                  <Badge 
                                    variant="secondary" 
                                    className={`text-xs bg-${module.color}-600/20 text-${module.color}-200`}
                                  >
                                    {module.label}
                                  </Badge>
                                )}
                              </div>
                            </div>
                          </div>
                          {note.content && (
                            <p className="text-sm text-gray-300 mt-2 line-clamp-2">
                              {note.content}
                            </p>
                          )}
                          <div className="flex items-center gap-4 mt-3 text-xs text-gray-400">
                            <span>Created: {new Date(note.created_at).toLocaleDateString()}</span>
                            {note.updated_at && (
                              <span>Updated: {new Date(note.updated_at).toLocaleDateString()}</span>
                            )}
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleEditNote(note)}
                            className="text-gray-400 hover:text-white"
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleDuplicateNote(note)}
                            className="text-gray-400 hover:text-white"
                          >
                            <Copy className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleDeleteNote(note.id)}
                            className="text-gray-400 hover:text-red-400"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {/* Create Note Dialog */}
      <Dialog open={isCreateNoteOpen} onOpenChange={setIsCreateNoteOpen}>
        <DialogContent className="bg-gray-800 border-gray-700 max-w-2xl">
          <DialogHeader>
            <DialogTitle className="text-white">Create Metadata Note</DialogTitle>
            <DialogDescription className="text-gray-400">
              Add a new metadata note that can be used across different modules
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="note-key" className="text-white">Note Key</Label>
                <Input
                  id="note-key"
                  value={newNoteData.note_key}
                  onChange={(e) => setNewNoteData(prev => ({ ...prev, note_key: e.target.value }))}
                  placeholder="unique_note_key"
                  className="bg-gray-700 border-gray-600 text-white"
                />
              </div>
              <div>
                <Label htmlFor="module-type" className="text-white">Module</Label>
                <Select 
                  value={newNoteData.module_type} 
                  onValueChange={(value) => setNewNoteData(prev => ({ ...prev, module_type: value }))}
                >
                  <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-gray-700 border-gray-600">
                    {modules.slice(1).map((module) => {
                      const IconComponent = module.icon;
                      return (
                        <SelectItem key={module.value} value={module.value}>
                          <div className="flex items-center gap-2">
                            <IconComponent className="h-4 w-4" />
                            <span>{module.label}</span>
                          </div>
                        </SelectItem>
                      );
                    })}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div>
              <Label htmlFor="title" className="text-white">Title</Label>
              <Input
                id="title"
                value={newNoteData.title}
                onChange={(e) => setNewNoteData(prev => ({ ...prev, title: e.target.value }))}
                placeholder="Note title"
                className="bg-gray-700 border-gray-600 text-white"
              />
            </div>
            <div>
              <Label htmlFor="content" className="text-white">Content</Label>
              <Textarea
                id="content"
                value={newNoteData.content}
                onChange={(e) => setNewNoteData(prev => ({ ...prev, content: e.target.value }))}
                placeholder="Note content and description"
                className="bg-gray-700 border-gray-600 text-white min-h-[120px]"
                rows={4}
              />
            </div>
            <div>
              <Label htmlFor="tree-id" className="text-white">Tree ID (Optional)</Label>
              <Input
                id="tree-id"
                value={newNoteData.tree_id}
                onChange={(e) => setNewNoteData(prev => ({ ...prev, tree_id: e.target.value }))}
                placeholder="Leave empty for global notes"
                className="bg-gray-700 border-gray-600 text-white"
              />
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setIsCreateNoteOpen(false)}
              className="border-gray-600 text-gray-300 hover:bg-gray-700"
            >
              Cancel
            </Button>
            <Button 
              onClick={handleCreateNote}
              className="bg-blue-600 hover:bg-blue-700 text-white"
            >
              Create Note
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Note Dialog */}
      <Dialog open={isEditNoteOpen} onOpenChange={setIsEditNoteOpen}>
        <DialogContent className="bg-gray-800 border-gray-700 max-w-2xl">
          <DialogHeader>
            <DialogTitle className="text-white">Edit Metadata Note</DialogTitle>
            <DialogDescription className="text-gray-400">
              Update the metadata note information
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="edit-note-key" className="text-white">Note Key</Label>
                <Input
                  id="edit-note-key"
                  value={newNoteData.note_key}
                  onChange={(e) => setNewNoteData(prev => ({ ...prev, note_key: e.target.value }))}
                  placeholder="unique_note_key"
                  className="bg-gray-700 border-gray-600 text-white"
                />
              </div>
              <div>
                <Label htmlFor="edit-module-type" className="text-white">Module</Label>
                <Select 
                  value={newNoteData.module_type} 
                  onValueChange={(value) => setNewNoteData(prev => ({ ...prev, module_type: value }))}
                >
                  <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-gray-700 border-gray-600">
                    {modules.slice(1).map((module) => {
                      const IconComponent = module.icon;
                      return (
                        <SelectItem key={module.value} value={module.value}>
                          <div className="flex items-center gap-2">
                            <IconComponent className="h-4 w-4" />
                            <span>{module.label}</span>
                          </div>
                        </SelectItem>
                      );
                    })}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div>
              <Label htmlFor="edit-title" className="text-white">Title</Label>
              <Input
                id="edit-title"
                value={newNoteData.title}
                onChange={(e) => setNewNoteData(prev => ({ ...prev, title: e.target.value }))}
                placeholder="Note title"
                className="bg-gray-700 border-gray-600 text-white"
              />
            </div>
            <div>
              <Label htmlFor="edit-content" className="text-white">Content</Label>
              <Textarea
                id="edit-content"
                value={newNoteData.content}
                onChange={(e) => setNewNoteData(prev => ({ ...prev, content: e.target.value }))}
                placeholder="Note content and description"
                className="bg-gray-700 border-gray-600 text-white min-h-[120px]"
                rows={4}
              />
            </div>
            <div>
              <Label htmlFor="edit-tree-id" className="text-white">Tree ID (Optional)</Label>
              <Input
                id="edit-tree-id"
                value={newNoteData.tree_id}
                onChange={(e) => setNewNoteData(prev => ({ ...prev, tree_id: e.target.value }))}
                placeholder="Leave empty for global notes"
                className="bg-gray-700 border-gray-600 text-white"
              />
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setIsEditNoteOpen(false)}
              className="border-gray-600 text-gray-300 hover:bg-gray-700"
            >
              Cancel
            </Button>
            <Button 
              onClick={handleUpdateNote}
              className="bg-blue-600 hover:bg-blue-700 text-white"
            >
              Update Note
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Export Dialog */}
      <Dialog open={showExportDialog} onOpenChange={setShowExportDialog}>
        <DialogContent className="bg-gray-800 border-gray-700">
          <DialogHeader>
            <DialogTitle className="text-white">Export Metadata Notes</DialogTitle>
            <DialogDescription className="text-gray-400">
              Export metadata notes to Excel format
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <p className="text-sm text-gray-300">
              This will export metadata notes for the currently selected module: <strong>{modules.find(m => m.value === selectedModule)?.label || 'All Modules'}</strong>
            </p>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setShowExportDialog(false)}
              className="border-gray-600 text-gray-300 hover:bg-gray-700"
            >
              Cancel
            </Button>
            <Button 
              onClick={() => {
                setShowExportDialog(false);
                handleExportNotes();
              }}
              className="bg-blue-600 hover:bg-blue-700 text-white"
            >
              <Download className="h-4 w-4 mr-2" />
              Export
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Import Dialog */}
      <Dialog open={showImportDialog} onOpenChange={setShowImportDialog}>
        <DialogContent className="bg-gray-800 border-gray-700">
          <DialogHeader>
            <DialogTitle className="text-white">Import Metadata Notes</DialogTitle>
            <DialogDescription className="text-gray-400">
              Import metadata notes from an Excel file
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="import-file" className="text-white">Select Excel File</Label>
              <Input
                id="import-file"
                type="file"
                accept=".xlsx,.xls"
                onChange={(e) => setImportFile(e.target.files?.[0] || null)}
                className="bg-gray-700 border-gray-600 text-white"
              />
            </div>
            <p className="text-sm text-gray-300">
              Notes will be imported for module: <strong>{modules.find(m => m.value === selectedModule)?.label || 'Product Classification'}</strong>
            </p>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                setShowImportDialog(false);
                setImportFile(null);
              }}
              className="border-gray-600 text-gray-300 hover:bg-gray-700"
            >
              Cancel
            </Button>
            <Button 
              onClick={handleImportNotes}
              disabled={!importFile}
              className="bg-blue-600 hover:bg-blue-700 text-white"
            >
              <Upload className="h-4 w-4 mr-2" />
              Import
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
