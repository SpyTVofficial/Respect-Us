
import React, { useState, useCallback } from 'react';
import SearchWidget, { SearchResult, createSearchConfig } from 'components/SearchWidget';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Globe, AlertTriangle, Shield, Ban, FileText, Calendar, MapPin, ExternalLink, Clock } from 'lucide-react';
import { toast } from 'sonner';
import brain from 'brain';
import { CountryRestriction, CountrySearchRequest } from 'brain/data-contracts';

interface CountryRestrictionsWidgetProps {
  open: boolean;
  onClose: () => void;
  onSelectionConfirmed?: (countries: CountryRestriction[]) => void;
  initialQuery?: string;
  multiSelect?: boolean;
}

export default function CountryRestrictionsWidget({
  open,
  onClose,
  onSelectionConfirmed,
  initialQuery = '',
  multiSelect = false
}: CountryRestrictionsWidgetProps) {
  const [restrictionTypes, setRestrictionTypes] = useState<string[]>([]);
  const [authorities, setAuthorities] = useState<string[]>([]);
  const [regions, setRegions] = useState<string[]>([]);
  const [riskLevels, setRiskLevels] = useState<string[]>([]);

  // Load filter options when component mounts
  React.useEffect(() => {
    const loadFilterOptions = async () => {
      try {
        const [typesRes, authoritiesRes, regionsRes, riskLevelsRes] = await Promise.all([
          brain.get_restriction_types(),
          brain.get_issuing_authorities(),
          brain.get_geographic_regions(),
          brain.get_country_risk_levels()
        ]);

        if (typesRes.ok) {
          const data = await typesRes.json();
          setRestrictionTypes(data);
        }
        if (authoritiesRes.ok) {
          const data = await authoritiesRes.json();
          setAuthorities(data);
        }
        if (regionsRes.ok) {
          const data = await regionsRes.json();
          setRegions(data);
        }
        if (riskLevelsRes.ok) {
          const data = await riskLevelsRes.json();
          setRiskLevels(data);
        }
      } catch (error) {
        console.error('Error loading filter options:', error);
      }
    };

    if (open) {
      loadFilterOptions();
    }
  }, [open]);

  const searchCountries = useCallback(async (query: string, filters: Record<string, any> = {}): Promise<SearchResult[]> => {
    try {
      const searchRequest: CountrySearchRequest = {
        query,
        restriction_type: filters.restriction_type || undefined,
        issuing_authority: filters.issuing_authority || undefined,
        risk_level: filters.risk_level || undefined,
        region: filters.region || undefined,
        include_expired: filters.include_expired === 'true',
        product_category: filters.product_category || undefined,
        limit: 50
      };

      const response = await brain.search_countries(searchRequest);
      
      if (!response.ok) {
        throw new Error('Search failed');
      }

      const data = await response.json();
      
      // Convert CountryRestriction to SearchResult
      return data.countries.map((country: CountryRestriction): SearchResult => ({
        id: country.id,
        title: `${country.country_name} (${country.country_code})`,
        description: country.description,
        details: {
          country_name: country.country_name,
          country_code: country.country_code,
          region: country.region,
          restriction_type: country.restriction_type,
          program_name: country.program_name,
          issuing_authority: country.issuing_authority,
          restrictions: country.restrictions,
          exemptions: country.exemptions,
          effective_date: country.effective_date,
          end_date: country.end_date,
          risk_level: country.risk_level,
          product_categories: country.product_categories,
          trade_restrictions: country.trade_restrictions,
          last_updated: country.last_updated,
          source_url: country.source_url,
          ...country.details
        },
        tags: [
          country.country_code,
          country.region,
          country.restriction_type,
          country.risk_level,
          country.issuing_authority
        ],
        type: 'country_restriction'
      }));
    } catch (error) {
      console.error('Country restrictions search error:', error);
      toast.error('Failed to search country restrictions');
      return [];
    }
  }, []);

  const handleSelectionConfirmed = (results: SearchResult[]) => {
    if (onSelectionConfirmed) {
      // Convert SearchResult back to CountryRestriction
      const countries: CountryRestriction[] = results.map(result => ({
        id: result.id,
        country_name: result.details?.country_name || '',
        country_code: result.details?.country_code || '',
        region: result.details?.region || '',
        restriction_type: result.details?.restriction_type || '',
        program_name: result.details?.program_name || '',
        issuing_authority: result.details?.issuing_authority || '',
        description: result.description || '',
        restrictions: result.details?.restrictions || [],
        exemptions: result.details?.exemptions || [],
        effective_date: result.details?.effective_date || new Date().toISOString().split('T')[0],
        end_date: result.details?.end_date,
        risk_level: result.details?.risk_level || 'unknown',
        product_categories: result.details?.product_categories || [],
        trade_restrictions: result.details?.trade_restrictions || {},
        last_updated: result.details?.last_updated || new Date().toISOString(),
        source_url: result.details?.source_url,
        details: result.details || {}
      }));
      
      onSelectionConfirmed(countries);
    }
  };

  const getRiskLevelColor = (riskLevel: string) => {
    switch (riskLevel) {
      case 'critical': return 'bg-red-700 text-white';
      case 'high': return 'bg-red-600 text-white';
      case 'medium': return 'bg-yellow-600 text-white';
      case 'low': return 'bg-green-600 text-white';
      default: return 'bg-gray-600 text-white';
    }
  };

  const getRestrictionIcon = (restrictionType: string) => {
    switch (restrictionType) {
      case 'comprehensive_embargo':
      case 'comprehensive_sanctions':
        return <Ban className="h-4 w-4" />;
      case 'targeted_sanctions':
        return <Shield className="h-4 w-4" />;
      case 'license_required':
        return <FileText className="h-4 w-4" />;
      default:
        return <AlertTriangle className="h-4 w-4" />;
    }
  };

  const formatRestrictionType = (type: string) => {
    return type.split('_').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ');
  };

  const CountryResultTemplate = ({ result }: { result: SearchResult }) => {
    const countryName = result.details?.country_name || '';
    const countryCode = result.details?.country_code || '';
    const region = result.details?.region || '';
    const restrictionType = result.details?.restriction_type || '';
    const riskLevel = result.details?.risk_level || 'unknown';
    const authority = result.details?.issuing_authority || '';
    const restrictions = result.details?.restrictions || [];
    const exemptions = result.details?.exemptions || [];
    const effectiveDate = result.details?.effective_date;
    const endDate = result.details?.end_date;
    const tradeRestrictions = result.details?.trade_restrictions || {};
    const productCategories = result.details?.product_categories || [];

    return (
      <Card className="cursor-pointer transition-all hover:shadow-md border border-gray-700 hover:border-gray-600 bg-gray-800">
        <CardHeader className="pb-2">
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-2">
              <Globe className="h-5 w-5 text-blue-400" />
              <div>
                <CardTitle className="text-lg text-white">
                  {countryName} <span className="text-sm font-normal text-gray-400">({countryCode})</span>
                </CardTitle>
                <div className="flex items-center gap-2 mt-1">
                  <div className="flex items-center gap-1 text-xs text-gray-400">
                    <MapPin className="h-3 w-3" />
                    <span>{region}</span>
                  </div>
                  <Badge variant="outline" className="text-xs border-gray-600 text-gray-300">
                    {authority}
                  </Badge>
                </div>
              </div>
            </div>
            <div className="flex flex-col gap-1 items-end">
              <Badge className={getRiskLevelColor(riskLevel)}>
                {riskLevel.replace('_', ' ').toUpperCase()}
              </Badge>
              <div className="flex items-center gap-1 text-xs text-orange-400">
                {getRestrictionIcon(restrictionType)}
                <span>{formatRestrictionType(restrictionType)}</span>
              </div>
            </div>
          </div>
        </CardHeader>
        
        <CardContent className="pt-0">
          {result.description && (
            <p className="text-sm text-gray-400 mb-3">{result.description}</p>
          )}

          {/* Trade Restrictions Summary */}
          {Object.keys(tradeRestrictions).length > 0 && (
            <div className="mb-3">
              <div className="text-xs font-medium text-blue-400 mb-2">Trade Restrictions:</div>
              <div className="grid grid-cols-1 gap-1 text-xs">
                {Object.entries(tradeRestrictions).map(([key, value]) => (
                  <div key={key} className="flex justify-between">
                    <span className="text-gray-400 capitalize">{key}:</span>
                    <span className="text-gray-300">{value as string}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Key Restrictions */}
          {restrictions.length > 0 && (
            <div className="mb-3">
              <div className="text-xs font-medium text-red-400 mb-1 flex items-center gap-1">
                <AlertTriangle className="h-3 w-3" />
                Key Restrictions:
              </div>
              <ul className="text-xs text-gray-400 space-y-1">
                {restrictions.slice(0, 3).map((restriction: string, index: number) => (
                  <li key={index} className="flex items-start gap-1">
                    <span className="text-red-400 mt-1">•</span>
                    <span>{restriction}</span>
                  </li>
                ))}
                {restrictions.length > 3 && (
                  <li className="text-gray-500 italic">... and {restrictions.length - 3} more</li>
                )}
              </ul>
            </div>
          )}

          {/* Exemptions */}
          {exemptions.length > 0 && (
            <div className="mb-3">
              <div className="text-xs font-medium text-green-400 mb-1">Available Exemptions:</div>
              <div className="flex flex-wrap gap-1">
                {exemptions.slice(0, 3).map((exemption: string, index: number) => (
                  <Badge key={index} variant="outline" className="text-xs border-green-600 text-green-300">
                    {exemption}
                  </Badge>
                ))}
                {exemptions.length > 3 && (
                  <Badge variant="outline" className="text-xs border-green-600 text-green-300">
                    +{exemptions.length - 3} more
                  </Badge>
                )}
              </div>
            </div>
          )}

          {/* Dates and Categories */}
          <div className="grid grid-cols-2 gap-3 text-xs text-gray-400 mb-3">
            <div>
              {effectiveDate && (
                <div className="flex items-center gap-1">
                  <Calendar className="h-3 w-3" />
                  <span>Since: {new Date(effectiveDate).toLocaleDateString()}</span>
                </div>
              )}
              {endDate && (
                <div className="flex items-center gap-1 mt-1">
                  <Clock className="h-3 w-3" />
                  <span>Until: {new Date(endDate).toLocaleDateString()}</span>
                </div>
              )}
            </div>
            <div>
              {productCategories.length > 0 && (
                <div>
                  <span className="font-medium">Affected Products:</span>
                  <div className="mt-1">
                    {productCategories.slice(0, 2).map((category: string, index: number) => (
                      <Badge key={index} variant="secondary" className="text-xs mr-1 mb-1">
                        {category}
                      </Badge>
                    ))}
                    {productCategories.length > 2 && (
                      <Badge variant="secondary" className="text-xs">
                        +{productCategories.length - 2}
                      </Badge>
                    )}
                  </div>
                </div>
              )}
            </div>
          </div>

          <div className="flex flex-wrap gap-1">
            <Badge variant="secondary" className="text-xs">
              {countryCode}
            </Badge>
            <Badge variant="secondary" className="text-xs">
              {region}
            </Badge>
            <Badge variant="secondary" className="text-xs">
              {formatRestrictionType(restrictionType)}
            </Badge>
          </div>
        </CardContent>
      </Card>
    );
  };

  const searchConfig = createSearchConfig({
    title: 'Search Country Restrictions',
    description: 'Search for country embargoes, sanctions, and geographic compliance restrictions',
    placeholder: 'Enter country name, code, or region...',
    searchFunction: searchCountries,
    multiSelect,
    repositoryLink: {
      label: 'View Restricted Items Catalog',
      url: '/knowledge-base?category=country-restrictions',
      description: 'Access complete country restrictions database and embargo information'
    },
    filters: [
      {
        label: 'Restriction Type',
        key: 'restriction_type',
        options: restrictionTypes.map(type => ({
          value: type,
          label: formatRestrictionType(type)
        }))
      },
      {
        label: 'Issuing Authority',
        key: 'issuing_authority',
        options: authorities.map(authority => ({
          value: authority,
          label: authority
        }))
      },
      {
        label: 'Region',
        key: 'region',
        options: regions.map(region => ({
          value: region,
          label: region
        }))
      },
      {
        label: 'Risk Level',
        key: 'risk_level',
        options: riskLevels.map(level => ({
          value: level,
          label: level.charAt(0).toUpperCase() + level.slice(1)
        }))
      },
      {
        label: 'Include Expired',
        key: 'include_expired',
        options: [
          { value: 'false', label: 'No' },
          { value: 'true', label: 'Yes' }
        ]
      }
    ],
    resultTemplate: CountryResultTemplate
  });

  return (
    <SearchWidget
      config={searchConfig}
      open={open}
      onClose={onClose}
      onSelectionConfirmed={handleSelectionConfirmed}
      initialQuery={initialQuery}
      className="country-restrictions-widget"
    />
  );
}

// Export types for use in other components
export type { CountryRestriction } from 'types';
