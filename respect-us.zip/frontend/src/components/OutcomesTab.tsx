import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { Plus, Edit, Trash2, Target, FileText, Shield, CheckCircle, Copy } from 'lucide-react';
import { toast } from 'sonner';
import brain from 'brain';
import type {
  TreeNode,
  NodeOption,
  ClassificationOutcome,
  ClassificationOutcomeCreate,
  AppApisClassificationClassificationTree as ClassificationTree,
  ClassificationNote
} from '../brain/data-contracts';

const OutcomesTab: React.FC = () => {
  const [outcomes, setOutcomes] = useState<ClassificationOutcome[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [editingOutcome, setEditingOutcome] = useState<ClassificationOutcome | null>(null);
  const [formData, setFormData] = useState({
    outcome_code: '',
    outcome_title: '',
    description: '',
    regulatory_basis: '',
    outcome_text: '',
    is_controlled: false,
    guidance_notes: ''
  });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      setLoading(true);
      
      // Load all outcomes
      const outcomesResponse = await brain.list_all_classification_outcomes();
      if (outcomesResponse.ok) {
        const outcomesData = await outcomesResponse.json();
        setOutcomes(outcomesData);
      }
    } catch (error) {
      console.error('Error loading outcomes data:', error);
      toast.error('Failed to load outcomes data');
    } finally {
      setLoading(false);
    }
  };

  const handleCreateOutcome = async () => {
    try {
      if (!formData.outcome_code || !formData.outcome_title || !formData.outcome_text) {
        toast.error('Please fill in required fields (code, title, and outcome text)');
        return;
      }

      // Validate character limits
      if (formData.outcome_code.length > 100) {
        toast.error('Outcome code must be 100 characters or less');
        return;
      }
      if (formData.outcome_title.length > 255) {
        toast.error('Outcome title must be 255 characters or less');
        return;
      }
      if (formData.outcome_text.length > 255) {
        toast.error('Outcome text must be 255 characters or less');
        return;
      }

      const response = await brain.create_tree_independent_outcome({
        outcome_code: formData.outcome_code,
        outcome_title: formData.outcome_title,
        description: formData.description || null,
        regulatory_basis: formData.regulatory_basis || null,
        outcome_text: formData.outcome_text || null,
        is_controlled: formData.is_controlled,
        guidance_notes: formData.guidance_notes || null
      });

      if (response.ok) {
        toast.success('Outcome created successfully');
        setShowCreateDialog(false);
        resetForm();
        loadData();
      } else {
        const errorData = await response.text();
        console.error('API Error:', errorData);
        toast.error('Failed to create outcome - please check your input');
      }
    } catch (error) {
      console.error('Error creating outcome:', error);
      toast.error('Failed to create outcome');
    }
  };

  const handleEditOutcome = (outcome: ClassificationOutcome) => {
    setEditingOutcome(outcome);
    setFormData({
      outcome_code: outcome.outcome_code,
      outcome_title: outcome.outcome_title,
      description: outcome.description || '',
      regulatory_basis: outcome.regulatory_basis || '',
      outcome_text: outcome.outcome_text || '',
      is_controlled: outcome.is_controlled || false,
      guidance_notes: outcome.guidance_notes || ''
    });
    setShowEditDialog(true);
  };

  const handleUpdateOutcome = async () => {
    try {
      if (!editingOutcome || !formData.outcome_code || !formData.outcome_title) {
        toast.error('Please fill in required fields');
        return;
      }

      const response = await brain.update_classification_outcome(
        { outcomeId: editingOutcome.id },
        {
          outcome_code: formData.outcome_code,
          outcome_title: formData.outcome_title,
          description: formData.description || null,
          regulatory_basis: formData.regulatory_basis || null,
          outcome_text: formData.outcome_text || null,
          is_controlled: formData.is_controlled,
          guidance_notes: formData.guidance_notes || null
        }
      );

      if (response.ok) {
        toast.success('Outcome updated successfully');
        setShowEditDialog(false);
        setEditingOutcome(null);
        resetForm();
        loadData();
      } else {
        toast.error('Failed to update outcome');
      }
    } catch (error) {
      console.error('Error updating outcome:', error);
      toast.error('Failed to update outcome');
    }
  };

  const handleDeleteOutcome = async (outcomeId: string) => {
    try {
      const response = await brain.delete_classification_outcome({ outcomeId });
      if (response.ok) {
        toast.success('Outcome deleted successfully');
        loadData();
      } else {
        toast.error('Failed to delete outcome');
      }
    } catch (error) {
      console.error('Error deleting outcome:', error);
      toast.error('Failed to delete outcome');
    }
  };

  const handleDuplicateOutcome = async (outcome: ClassificationOutcome) => {
    try {
      // Ensure outcome_code doesn't exceed 100 chars when adding '_copy'
      const baseCopyCode = `${outcome.outcome_code}_copy`;
      const finalCopyCode = baseCopyCode.length > 100 
        ? `${outcome.outcome_code.substring(0, 95)}_copy` 
        : baseCopyCode;
      
      const duplicateData: ClassificationOutcomeCreate = {
        outcome_code: finalCopyCode,
        outcome_title: `${outcome.outcome_title} (Copy)`,
        description: outcome.description,
        regulatory_basis: outcome.regulatory_basis,
        outcome_text: outcome.outcome_text || '',
        guidance_notes: outcome.guidance_notes,
        is_controlled: outcome.is_controlled
      };
      
      let response;
      if (outcome.tree_id) {
        // If outcome has a tree_id, create it under that tree
        response = await brain.create_classification_outcome(
          { treeId: outcome.tree_id },
          duplicateData
        );
      } else {
        // If it's a tree-independent outcome, create as tree-independent
        response = await brain.create_tree_independent_outcome(duplicateData);
      }
      
      if (response.ok) {
        toast.success('Outcome duplicated successfully');
        loadData();
      } else {
        const errorData = await response.json().catch(() => null);
        toast.error(`Failed to duplicate outcome: ${errorData?.detail || 'Unknown error'}`);
      }
    } catch (error) {
      console.error('Error duplicating outcome:', error);
      toast.error('Failed to duplicate outcome');
    }
  };

  const resetForm = () => {
    setFormData({
      outcome_code: '',
      outcome_title: '',
      description: '',
      regulatory_basis: '',
      outcome_text: '',
      is_controlled: false,
      guidance_notes: ''
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h3 className="text-xl font-semibold text-purple-400">Classification Outcomes</h3>
          <p className="text-gray-400 text-sm mt-1">Manage classification outcomes and their regulatory determinations</p>
        </div>
        <Button 
          onClick={() => {
            resetForm();
            setShowCreateDialog(true);
          }}
          className="bg-purple-600 hover:bg-purple-700 text-white"
        >
          <Plus className="w-4 h-4 mr-2" />
          Create Outcome
        </Button>
      </div>

      {loading ? (
        <div className="text-center py-8">
          <p className="text-gray-400">Loading outcomes...</p>
        </div>
      ) : (
        <div className="bg-gray-800/50 border border-gray-700 rounded-lg">
          {outcomes.length === 0 ? (
            <div className="text-center py-12">
              <Target className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-400">No classification outcomes found</p>
              <p className="text-gray-500 text-sm">Create your first outcome to get started</p>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow className="border-gray-700">
                  <TableHead className="text-purple-400">Code</TableHead>
                  <TableHead className="text-purple-400">Title</TableHead>
                  <TableHead className="text-purple-400">Tree ID</TableHead>
                  <TableHead className="text-purple-400">Status</TableHead>
                  <TableHead className="text-purple-400">Description</TableHead>
                  <TableHead className="text-purple-400 text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {outcomes.map((outcome) => (
                  <TableRow key={outcome.id} className="border-gray-700 hover:bg-gray-700/50">
                    <TableCell className="font-medium">
                      <div className="flex items-center gap-2">
                        <Target className="w-4 h-4 text-purple-400" />
                        <span className="text-white">{outcome.outcome_code}</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="text-purple-300 font-medium">{outcome.outcome_title}</div>
                    </TableCell>
                    <TableCell>
                      <div className="text-gray-400 text-sm">
                        {outcome.tree_id ? (
                          <Badge variant="outline" className="text-xs">
                            <FileText className="w-3 h-3 mr-1" />
                            {outcome.tree_id.substring(0, 8)}...
                          </Badge>
                        ) : (
                          <Badge variant="secondary" className="text-xs">
                            Independent
                          </Badge>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex gap-1">
                        {outcome.is_controlled && (
                          <Badge variant="destructive" className="text-xs">
                            <Shield className="w-3 h-3 mr-1" />
                            Controlled
                          </Badge>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="text-gray-400 text-sm max-w-xs">
                        {outcome.description ? (
                          <span className="line-clamp-2">{outcome.description}</span>
                        ) : (
                          <span className="text-gray-500 italic">No description</span>
                        )}
                      </div>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex gap-1 justify-end">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleEditOutcome(outcome)}
                          className="text-gray-400 hover:text-white h-8 w-8 p-0"
                        >
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleDuplicateOutcome(outcome)}
                          className="text-gray-400 hover:text-green-400 h-8 w-8 p-0"
                        >
                          <Copy className="w-4 h-4" />
                        </Button>
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button
                              variant="ghost"
                              size="sm"
                              className="text-gray-400 hover:text-red-400 h-8 w-8 p-0"
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent className="bg-gray-900 border-gray-700">
                            <AlertDialogHeader>
                              <AlertDialogTitle className="text-white">Delete Outcome</AlertDialogTitle>
                              <AlertDialogDescription className="text-gray-400">
                                Are you sure you want to delete outcome "{outcome.outcome_code}"? This action cannot be undone.
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel className="bg-gray-800 border-gray-600 text-white hover:bg-gray-700">
                                Cancel
                              </AlertDialogCancel>
                              <AlertDialogAction
                                onClick={() => handleDeleteOutcome(outcome.id)}
                                className="bg-red-600 hover:bg-red-700 text-white"
                              >
                                Delete
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </div>
      )}

      {/* Create Outcome Dialog */}
      <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
        <DialogContent className="bg-gray-900 border-gray-700 text-white max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-purple-400">Create Classification Outcome</DialogTitle>
            <DialogDescription className="text-gray-400">
              Create a new classification outcome for a decision tree
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            <div className="space-y-2">
              <Label className="text-gray-300">Outcome Code *</Label>
              <Input
                value={formData.outcome_code}
                onChange={(e) => setFormData({ ...formData, outcome_code: e.target.value })}
                className="bg-gray-800 border-gray-600 text-white"
                placeholder="e.g., EAR99, ITAR"
                maxLength={100}
              />
              <div className="text-xs text-gray-500 text-right">
                {formData.outcome_code.length}/100 characters
              </div>
            </div>
            
            <div className="space-y-2">
              <Label className="text-gray-300">Outcome Title *</Label>
              <Input
                value={formData.outcome_title}
                onChange={(e) => setFormData({ ...formData, outcome_title: e.target.value })}
                className="bg-gray-800 border-gray-600 text-white"
                placeholder="Brief descriptive title"
                maxLength={255}
              />
              <div className="text-xs text-gray-500 text-right">
                {formData.outcome_title.length}/255 characters
              </div>
            </div>
            
            <div className="space-y-2">
              <Label className="text-gray-300">Description</Label>
              <Textarea
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                className="bg-gray-800 border-gray-600 text-white"
                placeholder="Detailed description of the outcome"
                rows={3}
              />
            </div>
            
            <div className="space-y-2">
              <Label className="text-gray-300">Regulatory Basis</Label>
              <Textarea
                value={formData.regulatory_basis}
                onChange={(e) => setFormData({ ...formData, regulatory_basis: e.target.value })}
                className="bg-gray-800 border-gray-600 text-white"
                placeholder="Legal or regulatory basis for this outcome"
                rows={2}
              />
            </div>
            
            <div className="space-y-2">
              <Label className="text-gray-300">Outcome Text *</Label>
              <Textarea
                value={formData.outcome_text}
                onChange={(e) => setFormData({ ...formData, outcome_text: e.target.value })}
                className="bg-gray-800 border-gray-600 text-white"
                placeholder="Detailed outcome explanation"
                rows={3}
              />
            </div>
            
            <div className="space-y-2">
              <Label className="text-gray-300">Guidance Notes</Label>
              <Textarea
                value={formData.guidance_notes}
                onChange={(e) => setFormData({ ...formData, guidance_notes: e.target.value })}
                className="bg-gray-800 border-gray-600 text-white"
                placeholder="Additional guidance or notes"
                rows={2}
              />
            </div>
            
            <div className="flex items-center space-x-2">
              <Checkbox
                id="is_controlled"
                checked={formData.is_controlled}
                onCheckedChange={(checked) => setFormData({ ...formData, is_controlled: checked as boolean })}
              />
              <Label htmlFor="is_controlled" className="text-gray-300 flex items-center gap-2">
                <Shield className="w-4 h-4" />
                This is a controlled outcome
              </Label>
            </div>
          </div>
          
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => setShowCreateDialog(false)}
              className="bg-gray-800 border-gray-600 text-white hover:bg-gray-700"
            >
              Cancel
            </Button>
            <Button 
              onClick={handleCreateOutcome}
              className="bg-purple-600 hover:bg-purple-700 text-white"
            >
              Create Outcome
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Outcome Dialog */}
      <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
        <DialogContent className="bg-gray-900 border-gray-700 text-white max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-purple-400">Edit Classification Outcome</DialogTitle>
            <DialogDescription className="text-gray-400">
              Update the classification outcome details
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            <div className="space-y-2">
              <Label className="text-gray-300">Outcome Code *</Label>
              <Input
                value={formData.outcome_code}
                onChange={(e) => setFormData({ ...formData, outcome_code: e.target.value })}
                className="bg-gray-800 border-gray-600 text-white"
                placeholder="e.g., EAR99, ITAR"
                maxLength={100}
              />
              <div className="text-xs text-gray-500 text-right">
                {formData.outcome_code.length}/100 characters
              </div>
            </div>
            
            <div className="space-y-2">
              <Label className="text-gray-300">Outcome Title *</Label>
              <Input
                value={formData.outcome_title}
                onChange={(e) => setFormData({ ...formData, outcome_title: e.target.value })}
                className="bg-gray-800 border-gray-600 text-white"
                placeholder="Brief descriptive title"
                maxLength={255}
              />
              <div className="text-xs text-gray-500 text-right">
                {formData.outcome_title.length}/255 characters
              </div>
            </div>
            
            <div className="space-y-2">
              <Label className="text-gray-300">Description</Label>
              <Textarea
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                className="bg-gray-800 border-gray-600 text-white"
                placeholder="Detailed description of the outcome"
                rows={3}
              />
            </div>
            
            <div className="space-y-2">
              <Label className="text-gray-300">Regulatory Basis</Label>
              <Textarea
                value={formData.regulatory_basis}
                onChange={(e) => setFormData({ ...formData, regulatory_basis: e.target.value })}
                className="bg-gray-800 border-gray-600 text-white"
                placeholder="Legal or regulatory basis for this outcome"
                rows={2}
              />
            </div>
            
            <div className="space-y-2">
              <Label className="text-gray-300">Outcome Text</Label>
              <Textarea
                value={formData.outcome_text}
                onChange={(e) => setFormData({ ...formData, outcome_text: e.target.value })}
                className="bg-gray-800 border-gray-600 text-white"
                placeholder="Detailed outcome explanation"
                rows={3}
              />
            </div>
            
            <div className="space-y-2">
              <Label className="text-gray-300">Guidance Notes</Label>
              <Textarea
                value={formData.guidance_notes}
                onChange={(e) => setFormData({ ...formData, guidance_notes: e.target.value })}
                className="bg-gray-800 border-gray-600 text-white"
                placeholder="Additional guidance or notes"
                rows={2}
              />
            </div>
            
            <div className="flex items-center space-x-2">
              <Checkbox
                id="edit_is_controlled"
                checked={formData.is_controlled}
                onCheckedChange={(checked) => setFormData({ ...formData, is_controlled: checked as boolean })}
              />
              <Label htmlFor="edit_is_controlled" className="text-gray-300 flex items-center gap-2">
                <Shield className="w-4 h-4" />
                This is a controlled outcome
              </Label>
            </div>
          </div>
          
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => setShowEditDialog(false)}
              className="bg-gray-800 border-gray-600 text-white hover:bg-gray-700"
            >
              Cancel
            </Button>
            <Button 
              onClick={handleUpdateOutcome}
              className="bg-purple-600 hover:bg-purple-700 text-white"
            >
              Update Outcome
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default OutcomesTab;
