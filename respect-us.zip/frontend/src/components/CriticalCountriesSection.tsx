












import React, { useState, useEffect, useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { 
  Search, Plus, Edit, Trash2, Download, Globe, Shield, CheckCircle, 
  Table2, Grid3X3, ArrowUpDown, ChevronUp, ChevronDown, MapPin 
} from 'lucide-react';
import { toast } from 'sonner';
import brain from 'brain';

// Hook for debouncing search input
function useDebounce<T>(value: T, delay: number): T {
  const [debouncedValue, setDebouncedValue] = useState<T>(value);

  useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedValue(value);
    }, delay);

    return () => {
      clearTimeout(handler);
    };
  }, [value, delay]);

  return debouncedValue;
}

// Risk level colors
const getRiskLevelColor = (level: string): string => {
  switch (level?.toLowerCase()) {
    case 'low': return 'bg-green-600';
    case 'medium': return 'bg-yellow-600';
    case 'high': return 'bg-orange-600';
    case 'critical': return 'bg-red-600';
    default: return 'bg-gray-600';
  }
};

const getRiskLevelTextColor = (level: string): string => {
  switch (level?.toLowerCase()) {
    case 'low': return 'text-green-400';
    case 'medium': return 'text-yellow-400';
    case 'high': return 'text-orange-400';
    case 'critical': return 'text-red-400';
    default: return 'text-gray-400';
  }
};

// Helper function to format risk level display
const formatRiskLevel = (level: string | null | undefined): string => {
  if (!level) return 'N/A';
  return level.toUpperCase();
}

// Helper function to detect if country is a territory
const isTerritory = (countryName: string): boolean => {
  const name = countryName.toLowerCase();
  
  // Exact list of territories as defined by the user
  const territories = [
    'abkhazia',
    'gaza strip',
    'hong kong',
    'indian kashmir',
    'northern cyprus',
    'pakistani kashmir',
    'russian-occupied territories of ukraine',
    'south ossetia',
    'transnistria',
    'west bank',
    'western sahara'
  ];
  
  return territories.includes(name);
}

export default function CriticalCountriesSection() {
  const [countries, setCountries] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [riskFilter, setRiskFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [viewMode, setViewMode] = useState<'table' | 'cards'>('table');
  const [showAddCountry, setShowAddCountry] = useState(false);
  const [showEditCountry, setShowEditCountry] = useState(false);
  const [selectedCountry, setSelectedCountry] = useState<any>(null);
  const [stats, setStats] = useState<any>(null);
  const [sortField, setSortField] = useState<string>('country_name');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');

  // Debounced search term to prevent excessive filtering
  const debouncedSearchTerm = useDebounce(searchTerm, 300);

  // Form state for adding/editing countries
  const [countryForm, setCountryForm] = useState<any>({
    name: '',
    abbreviation: '',
    iso_code: '',
    risk_level: 'medium',
    is_active: true,
    notes: '',
    // Arms embargo fields
    un_arms_embargo: false,
    us_arms_embargo: false,
    eu_arms_embargo: false,
    other_arms_embargo: false,
    arms_risk: 'low',
    us_arms_embargo_notes: '',
    eu_arms_embargo_notes: '',
    // Chemical/Biological weapons fields
    cwc_1993_signatory: false,
    cwc_1993_ratified: false,
    cwc_violations: false,
    bwc_1972_signatory: false,
    bwc_1972_ratified: false,
    bwc_violation: false,
    chemical_risk: 'low',
    biological_risk: 'low',
    // Nuclear fields
    npt_signatory: false,
    npt_ratified: false,
    ctbt_signatory: false,
    iaea_signatory: false,
    nsg_1974_signatory: false,
    nuclear_violations: false,
    nuclear_risk: 'low',
    nsg_notes: '',
    // Human rights and freedom fields
    varieties_of_democracy: '',
    human_rights_risk_score: 50,
    political_rights_score: 50,
    freedom_in_the_world: false,
    freedom_risk: 'low',
    human_rights_freedoms_risk: 'low',
    obstacles_to_access: '',
    limits_on_content: '',
    regime_type: '',
    democracy_status: ''
  });

  // Load countries data
  useEffect(() => {
    loadCountries();
  }, []);

  const loadCountries = async () => {
    try {
      setLoading(true);
      const response = await brain.get_critical_countries_list({
        limit: 100,
        offset: 0,
        search: debouncedSearchTerm || undefined,
        risk_level: riskFilter === 'all' ? undefined : riskFilter,
        is_active: statusFilter === 'all' ? undefined : statusFilter === 'active'
      });
      const data = await response.json();
      console.log('📊 Retrieved', data.countries?.length || 0, 'countries (total:', data.total_count || 0, ')');
      setCountries(data.countries || []);
      setStats(data.stats || null);
    } catch (error) {
      console.error('❌ Error loading countries:', error);
      toast.error('Failed to load countries');
    } finally {
      setLoading(false);
    }
  };

  // Reset form
  const resetForm = () => {
    setCountryForm({
      name: '',
      abbreviation: '',
      iso_code: '',
      risk_level: 'medium',
      is_active: true,
      notes: '',
      un_arms_embargo: false,
      us_arms_embargo: false,
      eu_arms_embargo: false,
      other_arms_embargo: false,
      arms_risk: 'low',
      us_arms_embargo_notes: '',
      eu_arms_embargo_notes: '',
      cwc_1993_signatory: false,
      cwc_1993_ratified: false,
      cwc_violations: false,
      bwc_1972_signatory: false,
      bwc_1972_ratified: false,
      bwc_violation: false,
      chemical_risk: 'low',
      biological_risk: 'low',
      npt_signatory: false,
      npt_ratified: false,
      ctbt_signatory: false,
      iaea_signatory: false,
      nsg_1974_signatory: false,
      nuclear_violations: false,
      nuclear_risk: 'low',
      nsg_notes: '',
      varieties_of_democracy: '',
      human_rights_risk_score: 50,
      political_rights_score: 50,
      freedom_in_the_world: false,
      freedom_risk: 'low',
      human_rights_freedoms_risk: 'low',
      obstacles_to_access: '',
      limits_on_content: '',
      regime_type: '',
      democracy_status: ''
    });
  };

  // Handle adding new country
  const handleAddCountry = async () => {
    try {
      const response = await brain.create_critical_country(countryForm);
      const result = await response.json();
      toast.success('Country added successfully!');
      setShowAddCountry(false);
      resetForm();
      loadCountries();
    } catch (error) {
      console.error('❌ Error adding country:', error);
      toast.error('Failed to add country');
    }
  };

  // Handle editing country
  const handleEditCountry = (country: any) => {
    setSelectedCountry(country);
    setCountryForm({
      name: country.country_name || country.name || '',
      abbreviation: country.abbreviation || '',
      iso_code: country.iso_code || '',
      risk_level: country.risk_level || 'medium',
      is_active: country.is_active !== false,
      notes: country.notes || '',
      un_arms_embargo: country.un_arms_embargo || false,
      us_arms_embargo: country.us_arms_embargo || false,
      eu_arms_embargo: country.eu_arms_embargo || false,
      other_arms_embargo: country.other_arms_embargo || false,
      arms_risk: country.arms_risk || 'low',
      us_arms_embargo_notes: country.us_arms_embargo_notes || '',
      eu_arms_embargo_notes: country.eu_arms_embargo_notes || '',
      cwc_1993_signatory: country.cwc_1993_signatory || false,
      cwc_1993_ratified: country.cwc_1993_ratified || false,
      cwc_violations: country.cwc_violations || false,
      bwc_1972_signatory: country.bwc_1972_signatory || false,
      bwc_1972_ratified: country.bwc_1972_ratified || false,
      bwc_violation: country.bwc_violation || false,
      chemical_risk: country.chemical_risk || 'low',
      biological_risk: country.biological_risk || 'low',
      npt_signatory: country.npt_signatory || false,
      npt_ratified: country.npt_ratified || false,
      ctbt_signatory: country.ctbt_signatory || false,
      iaea_signatory: country.iaea_signatory || false,
      nsg_1974_signatory: country.nsg_1974_signatory || false,
      nuclear_violations: country.nuclear_violations || false,
      nuclear_risk: country.nuclear_risk || 'low',
      nsg_notes: country.nsg_notes || '',
      varieties_of_democracy: country.varieties_of_democracy || '',
      human_rights_risk_score: country.human_rights_risk_score || 50,
      political_rights_score: country.political_rights_score || 50,
      freedom_in_the_world: country.freedom_in_the_world || false,
      freedom_risk: country.freedom_risk || 'low',
      human_rights_freedoms_risk: country.human_rights_freedoms_risk || 'low',
      obstacles_to_access: country.obstacles_to_access || '',
      limits_on_content: country.limits_on_content || '',
      regime_type: country.regime_type || '',
      democracy_status: country.democracy_status || ''
    });
    setShowEditCountry(true);
  };

  // Handle updating country
  const handleUpdateCountry = async () => {
    if (!selectedCountry) return;
    
    try {
      const response = await brain.update_critical_country(
        { countryId: selectedCountry.id },
        countryForm
      );
      const result = await response.json();
      toast.success('Country updated successfully!');
      setShowEditCountry(false);
      setSelectedCountry(null);
      resetForm();
      loadCountries();
    } catch (error) {
      console.error('❌ Error updating country:', error);
      toast.error('Failed to update country');
    }
  };

  // Handle deleting country
  const handleDeleteCountry = async (countryId: number) => {
    if (!confirm(`Are you sure you want to delete ${countryId}?`)) {
      return;
    }

    try {
      const response = await brain.delete_critical_country({ countryId: countryId });
      toast.success('Country deleted successfully!');
      loadCountries();
    } catch (error) {
      console.error('❌ Error deleting country:', error);
      toast.error('Failed to delete country');
    }
  };

  // Filtered and sorted countries
  const filteredAndSortedCountries = useMemo(() => {
    console.log('Computing filteredAndSortedCountries with', countries.length, 'countries');
    
    let filtered = countries.filter(country => {
      const matchesSearch = !debouncedSearchTerm || 
        (country.country_name || country.name || '').toLowerCase().includes(debouncedSearchTerm.toLowerCase()) ||
        (country.abbreviation || '').toLowerCase().includes(debouncedSearchTerm.toLowerCase()) ||
        (country.iso_code || '').toLowerCase().includes(debouncedSearchTerm.toLowerCase());
      
      const matchesRisk = riskFilter === 'all' || country.risk_level === riskFilter;
      const matchesStatus = statusFilter === 'all' || 
        (statusFilter === 'active' && country.is_active !== false) ||
        (statusFilter === 'inactive' && country.is_active === false);
      
      return matchesSearch && matchesRisk && matchesStatus;
    });

    // Sort the filtered results
    filtered.sort((a, b) => {
      let aValue = a[sortField] || '';
      let bValue = b[sortField] || '';
      
      // Handle country name field specifically
      if (sortField === 'country_name') {
        aValue = a.country_name || a.name || '';
        bValue = b.country_name || b.name || '';
      }
      
      if (typeof aValue === 'string' && typeof bValue === 'string') {
        aValue = aValue.toLowerCase();
        bValue = bValue.toLowerCase();
      }
      
      if (sortDirection === 'asc') {
        return aValue < bValue ? -1 : aValue > bValue ? 1 : 0;
      } else {
        return aValue > bValue ? -1 : aValue < bValue ? 1 : 0;
      }
    });

    return filtered;
  }, [countries, debouncedSearchTerm, riskFilter, statusFilter, sortField, sortDirection]);

  const handleSort = (field: string) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-8">
        <div className="text-gray-400">Loading critical countries...</div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Stats Cards */}
      {stats && (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="bg-gray-800/50 border-gray-700">
            <CardContent className="p-4">
              <div className="flex items-center gap-2">
                <Globe className="h-5 w-5 text-blue-400" />
                <div>
                  <div className="text-sm text-gray-400">Total Countries</div>
                  <div className="text-xl font-semibold text-white">{stats.total_countries || 0}</div>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-gray-800/50 border-gray-700">
            <CardContent className="p-4">
              <div className="flex items-center gap-2">
                <AlertTriangle className="h-5 w-5 text-red-400" />
                <div>
                  <div className="text-sm text-gray-400">High Risk</div>
                  <div className="text-xl font-semibold text-white">{stats.by_risk_level?.high || 0}</div>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-gray-800/50 border-gray-700">
            <CardContent className="p-4">
              <div className="flex items-center gap-2">
                <Shield className="h-5 w-5 text-orange-400" />
                <div>
                  <div className="text-sm text-gray-400">Arms Embargoes</div>
                  <div className="text-xl font-semibold text-white">{stats.by_arms_embargo?.with_embargo || 0}</div>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-gray-800/50 border-gray-700">
            <CardContent className="p-4">
              <div className="flex items-center gap-2">
                <CheckCircle className="h-5 w-5 text-green-400" />
                <div>
                  <div className="text-sm text-gray-400">Active</div>
                  <div className="text-xl font-semibold text-white">{stats.by_status?.active || 0}</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* View Toggle and Export */}
      <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
        <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <Input
              placeholder="Search countries..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 bg-gray-700 border-gray-600 text-white w-64"
            />
          </div>
          
          <Select value={riskFilter} onValueChange={setRiskFilter}>
            <SelectTrigger className="bg-gray-700 border-gray-600 text-white w-40">
              <SelectValue placeholder="Risk Level" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Risks</SelectItem>
              <SelectItem value="low">Low Risk</SelectItem>
              <SelectItem value="medium">Medium Risk</SelectItem>
              <SelectItem value="high">High Risk</SelectItem>
              <SelectItem value="critical">Critical Risk</SelectItem>
            </SelectContent>
          </Select>
          
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="bg-gray-700 border-gray-600 text-white w-32">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="active">Active</SelectItem>
              <SelectItem value="inactive">Inactive</SelectItem>
            </SelectContent>
          </Select>
        </div>
        
        <div className="flex gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setViewMode(viewMode === 'table' ? 'cards' : 'table')}
            className="border-gray-600 text-gray-300 hover:bg-gray-700"
          >
            {viewMode === 'table' ? <Grid3X3 className="h-4 w-4 mr-2" /> : <Table2 className="h-4 w-4 mr-2" />}
            {viewMode === 'table' ? 'Cards' : 'Table'}
          </Button>
          <Button
            variant="outline"
            size="sm"
            className="border-gray-600 text-gray-300 hover:bg-gray-700"
          >
            <Download className="h-4 w-4 mr-2" />
            Export
          </Button>
          <Button
            onClick={() => setShowAddCountry(true)}
            className="bg-blue-600 hover:bg-blue-700 text-white"
          >
            <Plus className="h-4 w-4 mr-2" />
            Add Country
          </Button>
        </div>
      </div>

      {/* Results count */}
      <div className="text-sm text-gray-400">
        Showing {filteredAndSortedCountries.length} of {countries.length} countries
      </div>

      {/* Table or Cards View */}
      {viewMode === 'table' ? (
        <Card className="bg-gray-800/50 border-gray-700">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="border-gray-700">
                  <TableHead 
                    className="text-gray-300 cursor-pointer hover:text-white min-w-[150px] select-none"
                    onClick={() => handleSort('country_name')}
                  >
                    <div className="flex items-center gap-1">
                      Country 
                      <ArrowUpDown className="h-3 w-3 opacity-50" />
                      {sortField === 'country_name' && (sortDirection === 'asc' ? 
                        <ChevronUp className="h-3 w-3 text-blue-400" /> : 
                        <ChevronDown className="h-3 w-3 text-blue-400" />
                      )}
                    </div>
                  </TableHead>
                  <TableHead 
                    className="text-gray-300 cursor-pointer hover:text-white min-w-[80px] select-none"
                    onClick={() => handleSort('iso_code')}
                  >
                    <div className="flex items-center gap-1">
                      ISO 
                      <ArrowUpDown className="h-3 w-3 opacity-50" />
                      {sortField === 'iso_code' && (sortDirection === 'asc' ? 
                        <ChevronUp className="h-3 w-3 text-blue-400" /> : 
                        <ChevronDown className="h-3 w-3 text-blue-400" />
                      )}
                    </div>
                  </TableHead>
                  <TableHead 
                    className="text-gray-300 cursor-pointer hover:text-white min-w-[100px] select-none"
                    onClick={() => handleSort('risk_level')}
                  >
                    <div className="flex items-center gap-1">
                      Overall Risk 
                      <ArrowUpDown className="h-3 w-3 opacity-50" />
                      {sortField === 'risk_level' && (sortDirection === 'asc' ? 
                        <ChevronUp className="h-3 w-3 text-blue-400" /> : 
                        <ChevronDown className="h-3 w-3 text-blue-400" />
                      )}
                    </div>
                  </TableHead>
                  <TableHead className="text-gray-300 min-w-[120px]">Arms Embargo</TableHead>
                  <TableHead 
                    className="text-gray-300 cursor-pointer hover:text-white min-w-[120px] select-none"
                    onClick={() => handleSort('export_control_risk')}
                  >
                    <div className="flex items-center gap-1">
                      Export Control 
                      <ArrowUpDown className="h-3 w-3 opacity-50" />
                      {sortField === 'export_control_risk' && (sortDirection === 'asc' ? 
                        <ChevronUp className="h-3 w-3 text-blue-400" /> : 
                        <ChevronDown className="h-3 w-3 text-blue-400" />
                      )}
                    </div>
                  </TableHead>
                  <TableHead 
                    className="text-gray-300 cursor-pointer hover:text-white min-w-[100px] select-none"
                    onClick={() => handleSort('nuclear_risk')}
                  >
                    <div className="flex items-center gap-1">
                      Nuclear Risk 
                      <ArrowUpDown className="h-3 w-3 opacity-50" />
                      {sortField === 'nuclear_risk' && (sortDirection === 'asc' ? 
                        <ChevronUp className="h-3 w-3 text-blue-400" /> : 
                        <ChevronDown className="h-3 w-3 text-blue-400" />
                      )}
                    </div>
                  </TableHead>
                  <TableHead 
                    className="text-gray-300 cursor-pointer hover:text-white min-w-[100px] select-none"
                    onClick={() => handleSort('chemical_risk')}
                  >
                    <div className="flex items-center gap-1">
                      Chemical Risk 
                      <ArrowUpDown className="h-3 w-3 opacity-50" />
                      {sortField === 'chemical_risk' && (sortDirection === 'asc' ? 
                        <ChevronUp className="h-3 w-3 text-blue-400" /> : 
                        <ChevronDown className="h-3 w-3 text-blue-400" />
                      )}
                    </div>
                  </TableHead>
                  <TableHead 
                    className="text-gray-300 cursor-pointer hover:text-white min-w-[100px] select-none"
                    onClick={() => handleSort('biological_risk')}
                  >
                    <div className="flex items-center gap-1">
                      Biological Risk 
                      <ArrowUpDown className="h-3 w-3 opacity-50" />
                      {sortField === 'biological_risk' && (sortDirection === 'asc' ? 
                        <ChevronUp className="h-3 w-3 text-blue-400" /> : 
                        <ChevronDown className="h-3 w-3 text-blue-400" />
                      )}
                    </div>
                  </TableHead>
                  <TableHead 
                    className="text-gray-300 cursor-pointer hover:text-white min-w-[100px] select-none"
                    onClick={() => handleSort('sanctions_risk')}
                  >
                    <div className="flex items-center gap-1">
                      Sanctions 
                      <ArrowUpDown className="h-3 w-3 opacity-50" />
                      {sortField === 'sanctions_risk' && (sortDirection === 'asc' ? 
                        <ChevronUp className="h-3 w-3 text-blue-400" /> : 
                        <ChevronDown className="h-3 w-3 text-blue-400" />
                      )}
                    </div>
                  </TableHead>
                  <TableHead 
                    className="text-gray-300 cursor-pointer hover:text-white min-w-[120px] select-none"
                    onClick={() => handleSort('human_rights_freedoms_risk')}
                  >
                    <div className="flex items-center gap-1">
                      Human Rights & Freedom 
                      <ArrowUpDown className="h-3 w-3 opacity-50" />
                      {sortField === 'human_rights_freedoms_risk' && (sortDirection === 'asc' ? 
                        <ChevronUp className="h-3 w-3 text-blue-400" /> : 
                        <ChevronDown className="h-3 w-3 text-blue-400" />
                      )}
                    </div>
                  </TableHead>
                  <TableHead className="text-gray-300 min-w-[100px]">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredAndSortedCountries.map((country) => (
                  <TableRow key={country.id} className="border-gray-700 hover:bg-gray-800/50">
                    <TableCell className="text-gray-200">
                      <div className="flex items-center gap-2">
                        {country.country_name}
                        {isTerritory(country.country_name) && (
                          <div className="flex items-center gap-1 text-xs text-blue-400">
                            <MapPin className="h-3 w-3" />
                            <span>Territory</span>
                          </div>
                        )}
                      </div>
                    </TableCell>
                    <TableCell className="text-gray-200">
                      {country.iso_code || 'N/A'}
                    </TableCell>
                    <TableCell>
                      <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
                        getRiskLevelColor(country.risk_level)
                      } text-white`}>
                        {formatRiskLevel(country.risk_level)}
                      </span>
                    </TableCell>
                    <TableCell className="text-gray-200">
                      {country.arms_embargo ? (
                        <span className="text-red-400">Yes</span>
                      ) : (
                        <span className="text-green-400">No</span>
                      )}
                    </TableCell>
                    <TableCell>
                      <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
                        getRiskLevelColor(country.export_control_risk)
                      } text-white`}>
                        {formatRiskLevel(country.export_control_risk)}
                      </span>
                    </TableCell>
                    <TableCell>
                      <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
                        getRiskLevelColor(country.nuclear_risk)
                      } text-white`}>
                        {formatRiskLevel(country.nuclear_risk)}
                      </span>
                    </TableCell>
                    <TableCell>
                      <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
                        getRiskLevelColor(country.chemical_risk)
                      } text-white`}>
                        {formatRiskLevel(country.chemical_risk)}
                      </span>
                    </TableCell>
                    <TableCell>
                      <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
                        getRiskLevelColor(country.biological_risk)
                      } text-white`}>
                        {formatRiskLevel(country.biological_risk)}
                      </span>
                    </TableCell>
                    <TableCell>
                      <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
                        getRiskLevelColor(country.sanctions_risk)
                      } text-white`}>
                        {formatRiskLevel(country.sanctions_risk)}
                      </span>
                    </TableCell>
                    <TableCell>
                      <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
                        getRiskLevelColor(country.human_rights_freedoms_risk)
                      } text-white`}>
                        {formatRiskLevel(country.human_rights_freedoms_risk)}
                      </span>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => setEditingCountry(country)}
                          className="text-blue-400 hover:text-blue-300 hover:bg-blue-900/20"
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleDeleteCountry(country.id)}
                          className="text-red-400 hover:text-red-300 hover:bg-red-900/20"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredAndSortedCountries.map((country) => (
            <Card key={country.id} className="bg-gray-800/50 border-gray-700">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-white text-lg">
                    {country.country_name || country.name}
                  </CardTitle>
                  <Badge 
                    variant={country.is_active !== false ? "default" : "secondary"}
                    className={country.is_active !== false ? "bg-green-600 text-white" : "bg-gray-600 text-gray-300"}
                  >
                    {country.is_active !== false ? 'Active' : 'Inactive'}
                  </Badge>
                </div>
                <div className="text-sm text-gray-400">
                  {country.iso_code || country.abbreviation}
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-gray-400">Risk Level:</span>
                  <Badge className={`${getRiskLevelColor(country.risk_level)} text-white`}>
                    {country.risk_level || 'medium'}
                  </Badge>
                </div>
                
                <div className="flex items-center justify-between">
                  <span className="text-gray-400">Arms Embargo:</span>
                  {(country.un_arms_embargo || country.us_arms_embargo || country.eu_arms_embargo) ? (
                    <Badge className="bg-red-600 text-white">Yes</Badge>
                  ) : (
                    <Badge variant="outline" className="border-gray-600 text-gray-400">No</Badge>
                  )}
                </div>
                
                <div className="flex items-center justify-between">
                  <span className="text-gray-400">Nuclear Risk:</span>
                  <Badge className={`${getRiskLevelColor(country.nuclear_risk)} text-white`}>
                    {country.nuclear_risk || 'low'}
                  </Badge>
                </div>
                
                <div className="flex gap-2 pt-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleEditCountry(country)}
                    className="flex-1 border-gray-600 text-blue-400 hover:bg-gray-700"
                  >
                    <Edit className="h-4 w-4 mr-2" />
                    Edit
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleDeleteCountry(country.id)}
                    className="border-gray-600 text-red-400 hover:bg-gray-700"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Add Country Dialog */}
      <Dialog open={showAddCountry} onOpenChange={setShowAddCountry}>
        <DialogContent className="bg-gray-800 border-gray-700 max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-white">Add Critical Country</DialogTitle>
            <DialogDescription>
              Add a new country to the critical countries database with comprehensive risk assessment data.
            </DialogDescription>
          </DialogHeader>
          <Tabs defaultValue="basic" className="w-full">
            <TabsList className="grid w-full grid-cols-5 bg-gray-700">
              <TabsTrigger value="basic">Basic Info</TabsTrigger>
              <TabsTrigger value="arms">Arms Embargo</TabsTrigger>
              <TabsTrigger value="weapons">WMD</TabsTrigger>
              <TabsTrigger value="nuclear">Nuclear</TabsTrigger>
              <TabsTrigger value="rights">Rights & Freedom</TabsTrigger>
            </TabsList>

            <TabsContent value="basic" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <Label className="text-white">Country Name</Label>
                  <Input
                    value={countryForm.name}
                    onChange={(e) => setCountryForm({...countryForm, name: e.target.value})}
                    placeholder="i.e., United States"
                    className="bg-gray-700 border-gray-600 text-white"
                  />
                </div>
                <div>
                  <Label className="text-white">Abbreviation</Label>
                  <Input
                    value={countryForm.abbreviation}
                    onChange={(e) => setCountryForm({...countryForm, abbreviation: e.target.value})}
                    placeholder="i.e., USA"
                    className="bg-gray-700 border-gray-600 text-white"
                  />
                </div>
                <div>
                  <Label className="text-white">ISO Code</Label>
                  <Input
                    value={countryForm.iso_code}
                    onChange={(e) => setCountryForm({...countryForm, iso_code: e.target.value})}
                    placeholder="i.e., USA"
                    className="bg-gray-700 border-gray-600 text-white"
                  />
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label className="text-white">Overall Risk Level</Label>
                  <Select 
                    value={countryForm.risk_level}
                    onValueChange={(value) => setCountryForm({...countryForm, risk_level: value})}
                  >
                    <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">Low</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="high">High</SelectItem>
                      <SelectItem value="critical">Critical</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex items-center space-x-2 pt-6">
                  <Checkbox 
                    checked={countryForm.is_active}
                    onCheckedChange={(checked) => setCountryForm({...countryForm, is_active: !!checked})}
                  />
                  <Label className="text-white">Active</Label>
                </div>
              </div>
              <div>
                <Label className="text-white">Notes</Label>
                <Textarea
                  value={countryForm.notes}
                  onChange={(e) => setCountryForm({...countryForm, notes: e.target.value})}
                  placeholder="General notes about this country..."
                  className="bg-gray-700 border-gray-600 text-white"
                />
              </div>
            </TabsContent>
            
            <TabsContent value="arms" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="flex items-center space-x-2">
                  <Checkbox 
                    checked={countryForm.un_arms_embargo || false}
                    onCheckedChange={(checked) => setCountryForm({...countryForm, un_arms_embargo: !!checked})}
                  />
                  <Label className="text-white">UN Arms Embargo</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox 
                    checked={countryForm.us_arms_embargo || false}
                    onCheckedChange={(checked) => setCountryForm({...countryForm, us_arms_embargo: !!checked})}
                  />
                  <Label className="text-white">US Arms Embargo</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox 
                    checked={countryForm.eu_arms_embargo || false}
                    onCheckedChange={(checked) => setCountryForm({...countryForm, eu_arms_embargo: !!checked})}
                  />
                  <Label className="text-white">EU Arms Embargo</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox 
                    checked={countryForm.other_arms_embargo || false}
                    onCheckedChange={(checked) => setCountryForm({...countryForm, other_arms_embargo: !!checked})}
                  />
                  <Label className="text-white">Other Arms Embargo</Label>
                </div>
              </div>
              <div>
                <Label className="text-white">Arms Risk Level</Label>
                <Select 
                  value={countryForm.arms_risk || 'low'}
                  onValueChange={(value) => setCountryForm({...countryForm, arms_risk: value})}
                >
                  <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="low">Low</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="high">High</SelectItem>
                    <SelectItem value="critical">Critical</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label className="text-white">US Arms Embargo Notes</Label>
                  <Textarea
                    value={countryForm.us_arms_embargo_notes || ''}
                    onChange={(e) => setCountryForm({...countryForm, us_arms_embargo_notes: e.target.value})}
                    placeholder="Notes about US arms embargo..."
                    className="bg-gray-700 border-gray-600 text-white"
                  />
                </div>
                <div>
                  <Label className="text-white">EU Arms Embargo Notes</Label>
                  <Textarea
                    value={countryForm.eu_arms_embargo_notes || ''}
                    onChange={(e) => setCountryForm({...countryForm, eu_arms_embargo_notes: e.target.value})}
                    placeholder="Notes about EU arms embargo..."
                    className="bg-gray-700 border-gray-600 text-white"
                  />
                </div>
              </div>
            </TabsContent>

            <TabsContent value="weapons" className="space-y-4">
              <div className="space-y-4">
                <h3 className="text-lg font-semibold text-white">Chemical Weapons Convention</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      checked={countryForm.cwc_1993_signatory || false}
                      onCheckedChange={(checked) => setCountryForm({...countryForm, cwc_1993_signatory: !!checked})}
                    />
                    <Label className="text-white">CWC 1993 Signatory</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      checked={countryForm.cwc_1993_ratified || false}
                      onCheckedChange={(checked) => setCountryForm({...countryForm, cwc_1993_ratified: !!checked})}
                    />
                    <Label className="text-white">CWC 1993 Ratified</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      checked={countryForm.cwc_violations || false}
                      onCheckedChange={(checked) => setCountryForm({...countryForm, cwc_violations: !!checked})}
                    />
                    <Label className="text-white">CWC Violations</Label>
                  </div>
                </div>
                <div>
                  <Label className="text-white">Chemical Risk Level</Label>
                  <Select 
                    value={countryForm.chemical_risk || 'low'}
                    onValueChange={(value) => setCountryForm({...countryForm, chemical_risk: value})}
                  >
                    <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">Low</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="high">High</SelectItem>
                      <SelectItem value="critical">Critical</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div className="space-y-4">
                <h3 className="text-lg font-semibold text-white">Biological Weapons Convention</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      checked={countryForm.bwc_1972_signatory || false}
                      onCheckedChange={(checked) => setCountryForm({...countryForm, bwc_1972_signatory: !!checked})}
                    />
                    <Label className="text-white">BWC 1972 Signatory</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      checked={countryForm.bwc_1972_ratified || false}
                      onCheckedChange={(checked) => setCountryForm({...countryForm, bwc_1972_ratified: !!checked})}
                    />
                    <Label className="text-white">BWC 1972 Ratified</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      checked={countryForm.bwc_violation || false}
                      onCheckedChange={(checked) => setCountryForm({...countryForm, bwc_violation: !!checked})}
                    />
                    <Label className="text-white">BWC Violations</Label>
                  </div>
                </div>
                <div>
                  <Label className="text-white">Biological Risk Level</Label>
                  <Select 
                    value={countryForm.biological_risk || 'low'}
                    onValueChange={(value) => setCountryForm({...countryForm, biological_risk: value})}
                  >
                    <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">Low</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="high">High</SelectItem>
                      <SelectItem value="critical">Critical</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="nuclear" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="flex items-center space-x-2">
                  <Checkbox 
                    checked={countryForm.npt_signatory || false}
                    onCheckedChange={(checked) => setCountryForm({...countryForm, npt_signatory: !!checked})}
                  />
                  <Label className="text-white">NPT Signatory</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox 
                    checked={countryForm.npt_ratified || false}
                    onCheckedChange={(checked) => setCountryForm({...countryForm, npt_ratified: !!checked})}
                  />
                  <Label className="text-white">NPT Ratified</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox 
                    checked={countryForm.ctbt_signatory || false}
                    onCheckedChange={(checked) => setCountryForm({...countryForm, ctbt_signatory: !!checked})}
                  />
                  <Label className="text-white">CTBT Signatory</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox 
                    checked={countryForm.iaea_signatory || false}
                    onCheckedChange={(checked) => setCountryForm({...countryForm, iaea_signatory: !!checked})}
                  />
                  <Label className="text-white">IAEA Signatory</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox 
                    checked={countryForm.nsg_1974_signatory || false}
                    onCheckedChange={(checked) => setCountryForm({...countryForm, nsg_1974_signatory: !!checked})}
                  />
                  <Label className="text-white">NSG 1974 Signatory</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox 
                    checked={countryForm.nuclear_violations || false}
                    onCheckedChange={(checked) => setCountryForm({...countryForm, nuclear_violations: !!checked})}
                  />
                  <Label className="text-white">Nuclear Violations</Label>
                </div>
              </div>
              <div>
                <Label className="text-white">Nuclear Risk Level</Label>
                <Select 
                  value={countryForm.nuclear_risk || 'low'}
                  onValueChange={(value) => setCountryForm({...countryForm, nuclear_risk: value})}
                >
                  <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="low">Low</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="high">High</SelectItem>
                    <SelectItem value="critical">Critical</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-white">NSG Notes</Label>
                <Textarea
                  value={countryForm.nsg_notes || ''}
                  onChange={(e) => setCountryForm({...countryForm, nsg_notes: e.target.value})}
                  placeholder="Notes about Nuclear Suppliers Group..."
                  className="bg-gray-700 border-gray-600 text-white"
                />
              </div>
            </TabsContent>

            <TabsContent value="rights" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label className="text-white">Human Rights Risk Score (0-100)</Label>
                  <Input
                    type="number"
                    min="0"
                    max="100"
                    value={countryForm.human_rights_risk_score || 0}
                    onChange={(e) => setCountryForm({...countryForm, human_rights_risk_score: parseInt(e.target.value) || 0})}
                    className="bg-gray-700 border-gray-600 text-white"
                  />
                </div>
                <div>
                  <Label className="text-white">Political Rights Score (0-100)</Label>
                  <Input
                    type="number"
                    min="0"
                    max="100"
                    value={countryForm.political_rights_score || 0}
                    onChange={(e) => setCountryForm({...countryForm, political_rights_score: parseInt(e.target.value) || 0})}
                    className="bg-gray-700 border-gray-600 text-white"
                  />
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label className="text-white">Democracy Status</Label>
                  <Select 
                    value={countryForm.democracy_status || 'free'}
                    onValueChange={(value) => setCountryForm({...countryForm, democracy_status: value})}
                  >
                    <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="free">Free</SelectItem>
                      <SelectItem value="partly_free">Partly Free</SelectItem>
                      <SelectItem value="not_free">Not Free</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className="text-white">Freedom Risk Level</Label>
                  <Select 
                    value={countryForm.freedom_risk || 'low'}
                    onValueChange={(value) => setCountryForm({...countryForm, freedom_risk: value})}
                  >
                    <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">Low</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="high">High</SelectItem>
                      <SelectItem value="critical">Critical</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox 
                  checked={countryForm.freedom_in_the_world || false}
                  onCheckedChange={(checked) => setCountryForm({...countryForm, freedom_in_the_world: !!checked})}
                />
                <Label className="text-white">Freedom in the World</Label>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label className="text-white">Regime Type</Label>
                  <Input
                    value={countryForm.regime_type || ''}
                    onChange={(e) => setCountryForm({...countryForm, regime_type: e.target.value})}
                    placeholder="e.g., Democracy, Autocracy..."
                    className="bg-gray-700 border-gray-600 text-white"
                  />
                </div>
                <div>
                  <Label className="text-white">Varieties of Democracy</Label>
                  <Input
                    value={countryForm.varieties_of_democracy || ''}
                    onChange={(e) => setCountryForm({...countryForm, varieties_of_democracy: e.target.value})}
                    placeholder="Democracy index score..."
                    className="bg-gray-700 border-gray-600 text-white"
                  />
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label className="text-white">Obstacles to Access</Label>
                  <Textarea
                    value={countryForm.obstacles_to_access || ''}
                    onChange={(e) => setCountryForm({...countryForm, obstacles_to_access: e.target.value})}
                    placeholder="Information access restrictions..."
                    className="bg-gray-700 border-gray-600 text-white"
                  />
                </div>
                <div>
                  <Label className="text-white">Limits on Content</Label>
                  <Textarea
                    value={countryForm.limits_on_content || ''}
                    onChange={(e) => setCountryForm({...countryForm, limits_on_content: e.target.value})}
                    placeholder="Content restrictions..."
                    className="bg-gray-700 border-gray-600 text-white"
                  />
                </div>
              </div>
              <div>
                <Label className="text-white">Human Rights & Freedoms Risk</Label>
                <Select 
                  value={countryForm.human_rights_freedoms_risk || 'low'}
                  onValueChange={(value) => setCountryForm({...countryForm, human_rights_freedoms_risk: value})}
                >
                  <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="low">Low</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="high">High</SelectItem>
                    <SelectItem value="critical">Critical</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </TabsContent>
          </Tabs>
          <div className="flex justify-end gap-2 pt-4">
            <Button variant="outline" onClick={() => { setShowAddCountry(false); resetForm(); }}>Cancel</Button>
            <Button onClick={handleAddCountry} className="bg-blue-600 hover:bg-blue-700">Add Country</Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Edit Country Dialog */}
      <Dialog open={showEditCountry} onOpenChange={setShowEditCountry}>
        <DialogContent className="bg-gray-800 border-gray-700 max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-white">Edit Critical Country</DialogTitle>
            <DialogDescription>
              Edit {selectedCountry?.country_name || selectedCountry?.name} risk assessment data
            </DialogDescription>
          </DialogHeader>
          <Tabs defaultValue="basic" className="w-full">
            <TabsList className="grid w-full grid-cols-5 bg-gray-700">
              <TabsTrigger value="basic">Basic Info</TabsTrigger>
              <TabsTrigger value="arms">Arms Embargo</TabsTrigger>
              <TabsTrigger value="weapons">WMD</TabsTrigger>
              <TabsTrigger value="nuclear">Nuclear</TabsTrigger>
              <TabsTrigger value="rights">Rights & Freedom</TabsTrigger>
            </TabsList>

            <TabsContent value="basic" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <Label className="text-white">Country Name</Label>
                  <Input
                    value={countryForm.name || ''}
                    onChange={(e) => setCountryForm({...countryForm, name: e.target.value})}
                    placeholder="i.e., United States"
                    className="bg-gray-700 border-gray-600 text-white"
                  />
                </div>
                <div>
                  <Label className="text-white">Abbreviation</Label>
                  <Input
                    value={countryForm.abbreviation || ''}
                    onChange={(e) => setCountryForm({...countryForm, abbreviation: e.target.value})}
                    placeholder="i.e., USA"
                    className="bg-gray-700 border-gray-600 text-white"
                  />
                </div>
                <div>
                  <Label className="text-white">ISO Code</Label>
                  <Input
                    value={countryForm.iso_code || ''}
                    onChange={(e) => setCountryForm({...countryForm, iso_code: e.target.value})}
                    placeholder="i.e., USA"
                    className="bg-gray-700 border-gray-600 text-white"
                  />
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label className="text-white">Overall Risk Level</Label>
                  <Select 
                    value={countryForm.risk_level || 'medium'}
                    onValueChange={(value) => setCountryForm({...countryForm, risk_level: value})}
                  >
                    <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">Low</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="high">High</SelectItem>
                      <SelectItem value="critical">Critical</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex items-center space-x-2 pt-6">
                  <Checkbox 
                    checked={countryForm.is_active || false}
                    onCheckedChange={(checked) => setCountryForm({...countryForm, is_active: !!checked})}
                  />
                  <Label className="text-white">Active</Label>
                </div>
              </div>
              <div>
                <Label className="text-white">Notes</Label>
                <Textarea
                  value={countryForm.notes || ''}
                  onChange={(e) => setCountryForm({...countryForm, notes: e.target.value})}
                  placeholder="General notes about this country..."
                  className="bg-gray-700 border-gray-600 text-white"
                />
              </div>
            </TabsContent>
          </Tabs>
          <div className="flex justify-end gap-2 pt-4">
            <Button variant="outline" onClick={() => { setShowEditCountry(false); setSelectedCountry(null); resetForm(); }}>Cancel</Button>
            <Button onClick={handleUpdateCountry} className="bg-blue-600 hover:bg-blue-700">Update Country</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
