import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
  CommandSeparator,
} from '@/components/ui/command';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import { 
  Search, 
  Clock, 
  Star, 
  TrendingUp, 
  FileText, 
  Package,
  Zap,
  ArrowRight
} from 'lucide-react';
import { 
  searchModules, 
  getQuickAccessShortcuts, 
  NavigationSessionManager,
  trackModuleAccess 
} from 'utils/navigationUtils';
import { SearchResult, QuickAccessShortcut } from 'utils/navigationTypes';

interface AdvancedNavigationSearchProps {
  placeholder?: string;
  showShortcuts?: boolean;
  showRecentSearches?: boolean;
  className?: string;
  onSearchSelect?: (result: SearchResult) => void;
}

export default function AdvancedNavigationSearch({
  placeholder = "Search modules, features, and content...",
  showShortcuts = true,
  showRecentSearches = true,
  className = '',
  onSearchSelect
}: AdvancedNavigationSearchProps) {
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState('');
  const [searchResults, setSearchResults] = useState<SearchResult[]>([]);
  const [shortcuts, setShortcuts] = useState<QuickAccessShortcut[]>([]);
  const [recentSearches, setRecentSearches] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const searchTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  
  useEffect(() => {
    if (open) {
      // Load shortcuts and recent searches when opened
      setShortcuts(getQuickAccessShortcuts());
      loadRecentSearches();
    }
  }, [open]);
  
  useEffect(() => {
    // Debounced search
    if (searchTimeoutRef.current) {
      clearTimeout(searchTimeoutRef.current);
    }
    
    if (query.trim()) {
      setIsLoading(true);
      searchTimeoutRef.current = setTimeout(() => {
        performSearch(query);
        setIsLoading(false);
      }, 300);
    } else {
      setSearchResults([]);
      setIsLoading(false);
    }
    
    return () => {
      if (searchTimeoutRef.current) {
        clearTimeout(searchTimeoutRef.current);
      }
    };
  }, [query]);
  
  const loadRecentSearches = () => {
    const stored = localStorage.getItem('respectus_recent_searches');
    if (stored) {
      try {
        setRecentSearches(JSON.parse(stored));
      } catch (e) {
        console.warn('Failed to parse recent searches:', e);
      }
    }
  };
  
  const saveSearchQuery = (searchQuery: string) => {
    const current = recentSearches.filter(s => s !== searchQuery);
    const updated = [searchQuery, ...current].slice(0, 10);
    localStorage.setItem('respectus_recent_searches', JSON.stringify(updated));
    setRecentSearches(updated);
  };
  
  const performSearch = (searchQuery: string) => {
    // Search modules
    const moduleResults = searchModules(searchQuery);
    
    // TODO: Add content search when backend APIs are available
    // const contentResults = await searchContent(searchQuery);
    
    setSearchResults(moduleResults);
  };
  
  const handleResultSelect = (result: SearchResult) => {
    // Track analytics
    trackModuleAccess(result.module);
    saveSearchQuery(query);
    
    // Navigate or callback
    if (onSearchSelect) {
      onSearchSelect(result);
    } else {
      navigate(result.path);
    }
    
    // Close search
    setOpen(false);
    setQuery('');
  };
  
  const handleShortcutSelect = (shortcut: QuickAccessShortcut) => {
    trackModuleAccess(shortcut.module);
    navigate(shortcut.path);
    setOpen(false);
  };
  
  const handleRecentSearchSelect = (searchQuery: string) => {
    setQuery(searchQuery);
    performSearch(searchQuery);
  };
  
  const getResultIcon = (result: SearchResult) => {
    switch (result.type) {
      case 'module':
        return <Package className="w-4 h-4" />;
      case 'document':
        return <FileText className="w-4 h-4" />;
      case 'feature':
        return <Zap className="w-4 h-4" />;
      default:
        return <Search className="w-4 h-4" />;
    }
  };
  
  const getShortcutIcon = (shortcut: QuickAccessShortcut) => {
    const IconComponent = shortcut.icon;
    return <IconComponent className="w-4 h-4" />;
  };
  
  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'recent':
        return <Clock className="w-4 h-4" />;
      case 'favorite':
        return <Star className="w-4 h-4" />;
      case 'suggested':
        return <TrendingUp className="w-4 h-4" />;
      default:
        return <Zap className="w-4 h-4" />;
    }
  };
  
  const groupedShortcuts = shortcuts.reduce((acc, shortcut) => {
    if (!acc[shortcut.category]) {
      acc[shortcut.category] = [];
    }
    acc[shortcut.category].push(shortcut);
    return acc;
  }, {} as Record<string, QuickAccessShortcut[]>);
  
  return (
    <div className={`relative ${className}`}>
      <Popover open={open} onOpenChange={setOpen}>
        <PopoverTrigger asChild>
          <Button
            variant="outline"
            role="combobox"
            aria-expanded={open}
            className="w-64 justify-start text-left font-normal bg-gray-800/50 border-gray-600 text-gray-400 hover:text-white hover:bg-gray-800/70 backdrop-blur-sm"
          >
            <Search className="mr-2 h-4 w-4 shrink-0" />
            <span className="truncate">
              {query || placeholder}
            </span>
          </Button>
        </PopoverTrigger>
        <PopoverContent 
          className="w-96 p-0 bg-gray-900/95 backdrop-blur-lg border-gray-700" 
          align="start"
        >
          <Command className="bg-transparent">
            <CommandInput
              placeholder={placeholder}
              value={query}
              onValueChange={setQuery}
              className="border-0 bg-transparent text-white placeholder-gray-400"
            />
            <CommandList className="max-h-96">
              {/* Loading State */}
              {isLoading && (
                <div className="py-6 text-center text-sm text-gray-400">
                  <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-blue-400 mx-auto mb-2"></div>
                  Searching...
                </div>
              )}
              
              {/* Search Results */}
              {!isLoading && query && searchResults.length > 0 && (
                <CommandGroup heading="Search Results">
                  {searchResults.slice(0, 8).map((result) => (
                    <CommandItem
                      key={result.id}
                      value={result.id}
                      onSelect={() => handleResultSelect(result)}
                      className="cursor-pointer hover:bg-gray-800 text-gray-300 hover:text-white"
                    >
                      <div className="flex items-start space-x-3 w-full">
                        <div className="text-blue-400 mt-0.5">
                          {getResultIcon(result)}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center space-x-2">
                            <span className="font-medium truncate">{result.title}</span>
                            <Badge className="text-xs bg-gray-700/50 text-gray-400">
                              {result.type}
                            </Badge>
                          </div>
                          <p className="text-xs text-gray-400 mt-1 line-clamp-2">
                            {result.description}
                          </p>
                        </div>
                        <ArrowRight className="w-3 h-3 text-gray-500" />
                      </div>
                    </CommandItem>
                  ))}
                </CommandGroup>
              )}
              
              {/* No Results */}
              {!isLoading && query && searchResults.length === 0 && (
                <CommandEmpty className="py-6 text-center text-sm text-gray-400">
                  No results found for "{query}"
                </CommandEmpty>
              )}
              
              {/* Recent Searches */}
              {!query && showRecentSearches && recentSearches.length > 0 && (
                <>
                  <CommandGroup heading="Recent Searches">
                    {recentSearches.slice(0, 5).map((searchQuery, index) => (
                      <CommandItem
                        key={index}
                        value={`recent-${index}`}
                        onSelect={() => handleRecentSearchSelect(searchQuery)}
                        className="cursor-pointer hover:bg-gray-800 text-gray-300 hover:text-white"
                      >
                        <Clock className="mr-3 h-4 w-4 text-gray-400" />
                        <span className="truncate">{searchQuery}</span>
                      </CommandItem>
                    ))}
                  </CommandGroup>
                  <CommandSeparator className="bg-gray-700" />
                </>
              )}
              
              {/* Quick Access Shortcuts */}
              {!query && showShortcuts && Object.keys(groupedShortcuts).length > 0 && (
                <>
                  {Object.entries(groupedShortcuts).map(([category, categoryShortcuts]) => (
                    <React.Fragment key={category}>
                      <CommandGroup 
                        heading={
                          <div className="flex items-center space-x-2">
                            {getCategoryIcon(category)}
                            <span className="capitalize">
                              {category.replace('_', ' ')}
                            </span>
                          </div>
                        }
                      >
                        {categoryShortcuts.slice(0, 4).map((shortcut) => (
                          <CommandItem
                            key={shortcut.id}
                            value={shortcut.id}
                            onSelect={() => handleShortcutSelect(shortcut)}
                            className="cursor-pointer hover:bg-gray-800 text-gray-300 hover:text-white"
                          >
                            <div className="flex items-center space-x-3 w-full">
                              <div className="text-blue-400">
                                {getShortcutIcon(shortcut)}
                              </div>
                              <div className="flex-1 min-w-0">
                                <div className="font-medium truncate">{shortcut.name}</div>
                                {shortcut.hotkey && (
                                  <Badge className="text-xs bg-gray-700/50 text-gray-400 mt-1">
                                    {shortcut.hotkey}
                                  </Badge>
                                )}
                              </div>
                              <ArrowRight className="w-3 h-3 text-gray-500" />
                            </div>
                          </CommandItem>
                        ))}
                      </CommandGroup>
                      {Object.keys(groupedShortcuts).indexOf(category) < Object.keys(groupedShortcuts).length - 1 && (
                        <CommandSeparator className="bg-gray-700" />
                      )}
                    </React.Fragment>
                  ))}
                </>
              )}
              
              {/* Empty State */}
              {!query && (!showShortcuts || Object.keys(groupedShortcuts).length === 0) && 
               (!showRecentSearches || recentSearches.length === 0) && (
                <div className="py-8 text-center text-sm text-gray-400">
                  <Search className="w-8 h-8 mx-auto mb-2 text-gray-500" />
                  <p>Start typing to search modules and content</p>
                </div>
              )}
            </CommandList>
          </Command>
        </PopoverContent>
      </Popover>
    </div>
  );
}
