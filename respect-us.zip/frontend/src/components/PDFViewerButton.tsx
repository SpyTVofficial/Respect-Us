
import React, { useState, startTransition } from 'react';
import { Button } from '@/components/ui/button';
import { Eye } from 'lucide-react';
import { PDFLoader } from './PDFLoader';

interface Props {
  documentId: number;
  documentTitle: string;
  variant?: 'default' | 'outline' | 'ghost';
  size?: 'sm' | 'default' | 'lg';
  className?: string;
}

export const PDFViewerButton: React.FC<Props> = ({ 
  documentId, 
  documentTitle, 
  variant = 'outline',
  size = 'sm',
  className = ''
}) => {
  const [showPDF, setShowPDF] = useState(false);

  const handleOpenPDF = () => {
    startTransition(() => {
      setShowPDF(true);
    });
  };

  const handleClosePDF = () => {
    startTransition(() => {
      setShowPDF(false);
    });
  };

  return (
    <>
      <Button
        variant={variant}
        size={size}
        onClick={handleOpenPDF}
        className={className}
      >
        <Eye className="w-4 h-4 mr-2" />
        View PDF
      </Button>
      
      <PDFLoader
        documentId={documentId}
        documentTitle={documentTitle}
        isOpen={showPDF}
        onClose={handleClosePDF}
      />
    </>
  );
};
