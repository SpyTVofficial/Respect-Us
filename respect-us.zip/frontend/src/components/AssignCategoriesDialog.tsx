import React, { useState, useEffect } from 'react';
import { toast } from 'sonner';
import brain from 'brain';
import { SavedArticleResponse, AssignCategoriesRequest } from 'types';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { CategorySelector } from 'components/CategorySelector';
import { Tag } from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  article: SavedArticleResponse;
  onCategoriesUpdated?: () => void;
}

export const AssignCategoriesDialog: React.FC<Props> = ({
  isOpen,
  onClose,
  article,
  onCategoriesUpdated
}) => {
  const [isLoading, setIsLoading] = useState(false);
  const [selectedCategoryIds, setSelectedCategoryIds] = useState<number[]>([]);

  // Initialize with current categories when article changes
  useEffect(() => {
    if (article && article.categories) {
      setSelectedCategoryIds(article.categories.map(cat => cat.id));
    }
  }, [article]);

  const handleAssignCategories = async () => {
    try {
      setIsLoading(true);
      
      const request: AssignCategoriesRequest = {
        category_ids: selectedCategoryIds,
      };

      await brain.assign_categories_to_article(
        { articleId: article.id },
        request
      );
      
      toast.success('Categories updated successfully');
      onCategoriesUpdated?.();
      onClose();
    } catch (error: any) {
      console.error('Error assigning categories:', error);
      toast.error('Failed to update categories');
    } finally {
      setIsLoading(false);
    }
  };

  const handleClose = () => {
    if (!isLoading) {
      onClose();
      // Reset to original categories when closing without saving
      if (article && article.categories) {
        setSelectedCategoryIds(article.categories.map(cat => cat.id));
      }
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="bg-gray-900 border-gray-700 max-w-md">
        <DialogHeader>
          <DialogTitle className="text-white flex items-center gap-2">
            <Tag className="w-5 h-5 text-blue-400" />
            Manage Categories
          </DialogTitle>
          <DialogDescription className="text-gray-400">
            Assign categories to organize "{article.document_title}" in your collection.
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4">
          <CategorySelector
            selectedCategoryIds={selectedCategoryIds}
            onCategoryChange={setSelectedCategoryIds}
            multiSelect={true}
            placeholder="Select categories for this article"
          />
        </div>

        <DialogFooter>
          <Button
            variant="outline"
            onClick={handleClose}
            disabled={isLoading}
          >
            Cancel
          </Button>
          <Button
            onClick={handleAssignCategories}
            disabled={isLoading}
            className="bg-blue-600 hover:bg-blue-700"
          >
            {isLoading ? 'Updating...' : 'Update Categories'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};
