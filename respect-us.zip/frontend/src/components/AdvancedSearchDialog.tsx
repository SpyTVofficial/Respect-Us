import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Search,
  Plus,
  Minus,
  HelpCircle,
  BookOpen,
  Filter,
  Calendar,
  MapPin,
  Tag,
  FileText,
  Save,
  Clock,
  Star,
  X
} from 'lucide-react';
import { cn } from 'utils/cn';
import brain from 'brain';
import { toast } from 'sonner';

interface AdvancedSearchDialogProps {
  open: boolean;
  onClose: () => void;
  onSearch: (searchCriteria: SearchCriteria) => void;
  initialQuery?: string;
}

interface SearchCriteria {
  query: string;
  booleanMode: boolean;
  searchFields: string[];
  filters: {
    jurisdiction: string[];
    regulationType: string[];
    subject: string[];
    dateRange: {
      start?: string;
      end?: string;
    };
    status: string[];
    tags: string[];
    documentType: string[];
  };
  sortBy: string;
  sortOrder: 'asc' | 'desc';
}

interface SavedSearch {
  id: string;
  name: string;
  criteria: SearchCriteria;
  createdAt: string;
  alertEnabled: boolean;
}

const SEARCH_FIELDS = [
  { value: 'title', label: 'Title' },
  { value: 'content', label: 'Content' },
  { value: 'description', label: 'Description' },
  { value: 'tags', label: 'Tags' },
  { value: 'issuing_authority', label: 'Issuing Authority' },
  { value: 'subject', label: 'Subject' }
];

const SORT_OPTIONS = [
  { value: 'relevance', label: 'Relevance' },
  { value: 'title', label: 'Title' },
  { value: 'publication_date', label: 'Publication Date' },
  { value: 'effective_date', label: 'Effective Date' },
  { value: 'created_at', label: 'Created Date' },
  { value: 'updated_at', label: 'Last Updated' }
];

const BOOLEAN_OPERATORS = [
  { symbol: 'AND', description: 'Both terms must be present', example: 'export AND control' },
  { symbol: 'OR', description: 'Either term can be present', example: 'sanctions OR embargoes' },
  { symbol: 'NOT', description: 'Exclude the following term', example: 'technology NOT software' },
  { symbol: '""', description: 'Exact phrase match', example: '"dual use"' },
  { symbol: '*', description: 'Wildcard for partial matches', example: 'regulat*' },
  { symbol: '()', description: 'Group terms together', example: '(export OR import) AND license' }
];

export default function AdvancedSearchDialog({ 
  open, 
  onClose, 
  onSearch, 
  initialQuery = '' 
}: AdvancedSearchDialogProps) {
  const [searchCriteria, setSearchCriteria] = useState<SearchCriteria>({
    query: initialQuery,
    booleanMode: false,
    searchFields: ['title', 'content'],
    filters: {
      jurisdiction: [],
      regulationType: [],
      subject: [],
      dateRange: {},
      status: ['published'],
      tags: [],
      documentType: []
    },
    sortBy: 'relevance',
    sortOrder: 'desc'
  });

  const [savedSearches, setSavedSearches] = useState<SavedSearch[]>([]);
  const [showSaveDialog, setShowSaveDialog] = useState(false);
  const [searchName, setSearchName] = useState('');
  const [alertEnabled, setAlertEnabled] = useState(false);
  const [availableOptions, setAvailableOptions] = useState({
    jurisdictions: [] as string[],
    regulationTypes: [] as string[],
    subjects: [] as string[],
    documentTypes: [] as string[],
    tags: [] as string[]
  });

  useEffect(() => {
    if (open) {
      loadAvailableOptions();
      loadSavedSearches();
    }
  }, [open]);

  const loadAvailableOptions = async () => {
    try {
      // Load available filter options from documents
      const response = await brain.get_enhanced_metadata_options();
      if (response.ok) {
        const data = await response.json();
        setAvailableOptions({
          jurisdictions: data.jurisdictions?.map((j: any) => j.value) || [],
          regulationTypes: data.regulation_types?.map((r: any) => r.value) || [],
          subjects: data.subjects?.map((s: any) => s.value) || [],
          documentTypes: data.document_types?.map((d: any) => d.value) || [],
          tags: data.product_categories?.map((p: any) => p.value) || []
        });
      }
    } catch (error) {
      console.error('Error loading filter options:', error);
    }
  };

  const loadSavedSearches = () => {
    // Load from localStorage for now
    const saved = localStorage.getItem('kb_saved_searches');
    if (saved) {
      setSavedSearches(JSON.parse(saved));
    }
  };

  const handleSearch = () => {
    if (!searchCriteria.query.trim()) {
      toast.error('Please enter a search query');
      return;
    }
    
    onSearch(searchCriteria);
    onClose();
  };

  const handleSaveSearch = () => {
    if (!searchName.trim()) {
      toast.error('Please enter a name for the saved search');
      return;
    }

    const newSearch: SavedSearch = {
      id: Date.now().toString(),
      name: searchName,
      criteria: { ...searchCriteria },
      createdAt: new Date().toISOString(),
      alertEnabled
    };

    const updated = [...savedSearches, newSearch];
    setSavedSearches(updated);
    localStorage.setItem('kb_saved_searches', JSON.stringify(updated));
    
    setShowSaveDialog(false);
    setSearchName('');
    setAlertEnabled(false);
    toast.success('Search saved successfully!');
    
    if (alertEnabled) {
      toast.info('Alert enabled - you\'ll be notified of new matching documents');
    }
  };

  const loadSavedSearch = (saved: SavedSearch) => {
    setSearchCriteria(saved.criteria);
    toast.success(`Loaded search: ${saved.name}`);
  };

  const deleteSavedSearch = (id: string) => {
    const updated = savedSearches.filter(s => s.id !== id);
    setSavedSearches(updated);
    localStorage.setItem('kb_saved_searches', JSON.stringify(updated));
    toast.success('Saved search deleted');
  };

  const toggleFilter = (filterType: keyof SearchCriteria['filters'], value: string) => {
    setSearchCriteria(prev => ({
      ...prev,
      filters: {
        ...prev.filters,
        [filterType]: prev.filters[filterType].includes(value)
          ? prev.filters[filterType].filter(v => v !== value)
          : [...prev.filters[filterType], value]
      }
    }));
  };

  const updateSearchField = (field: string, checked: boolean) => {
    setSearchCriteria(prev => ({
      ...prev,
      searchFields: checked
        ? [...prev.searchFields, field]
        : prev.searchFields.filter(f => f !== field)
    }));
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="bg-gray-900 border-gray-700 max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-white flex items-center gap-2">
            <Search className="h-5 w-5" />
            Advanced Search
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Search Query */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <Label className="text-white">Search Query</Label>
              <div className="flex items-center gap-2">
                <Checkbox 
                  id="boolean-mode"
                  checked={searchCriteria.booleanMode}
                  onCheckedChange={(checked) => 
                    setSearchCriteria(prev => ({ ...prev, booleanMode: !!checked }))
                  }
                />
                <Label htmlFor="boolean-mode" className="text-sm text-gray-300">
                  Boolean Search Mode
                </Label>
              </div>
            </div>
            
            <Textarea
              value={searchCriteria.query}
              onChange={(e) => setSearchCriteria(prev => ({ ...prev, query: e.target.value }))}
              placeholder={searchCriteria.booleanMode 
                ? 'Enter Boolean search query (e.g., "export control" AND (sanctions OR embargoes))'
                : 'Enter search terms...'}
              className="bg-gray-800 border-gray-600 text-white min-h-[80px]"
            />
            
            {searchCriteria.booleanMode && (
              <Card className="bg-gray-800 border-gray-600">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm text-gray-300 flex items-center gap-2">
                    <HelpCircle className="h-4 w-4" />
                    Boolean Operators
                  </CardTitle>
                </CardHeader>
                <CardContent className="pt-0">
                  <div className="grid grid-cols-2 gap-3 text-xs">
                    {BOOLEAN_OPERATORS.map((op) => (
                      <div key={op.symbol} className="space-y-1">
                        <div className="flex items-center gap-2">
                          <Badge variant="outline" className="font-mono">{op.symbol}</Badge>
                          <span className="text-gray-300">{op.description}</span>
                        </div>
                        <div className="text-gray-400 font-mono pl-2">{op.example}</div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Search Fields */}
          <div className="space-y-3">
            <Label className="text-white">Search In</Label>
            <div className="grid grid-cols-3 gap-3">
              {SEARCH_FIELDS.map((field) => (
                <div key={field.value} className="flex items-center space-x-2">
                  <Checkbox
                    id={field.value}
                    checked={searchCriteria.searchFields.includes(field.value)}
                    onCheckedChange={(checked) => updateSearchField(field.value, !!checked)}
                  />
                  <Label htmlFor={field.value} className="text-sm text-gray-300">
                    {field.label}
                  </Label>
                </div>
              ))}
            </div>
          </div>

          <Separator className="bg-gray-600" />

          {/* Filters */}
          <div className="space-y-4">
            <Label className="text-white flex items-center gap-2">
              <Filter className="h-4 w-4" />
              Filters
            </Label>
            
            <div className="grid grid-cols-2 gap-4">
              {/* Jurisdiction Filter */}
              <div className="space-y-2">
                <Label className="text-sm text-gray-300 flex items-center gap-1">
                  <MapPin className="h-3 w-3" />
                  Jurisdiction
                </Label>
                <ScrollArea className="h-32 border border-gray-600 rounded p-2">
                  {availableOptions.jurisdictions.map((jurisdiction) => (
                    <div key={jurisdiction} className="flex items-center space-x-2 py-1">
                      <Checkbox
                        id={`jurisdiction-${jurisdiction}`}
                        checked={searchCriteria.filters.jurisdiction.includes(jurisdiction)}
                        onCheckedChange={() => toggleFilter('jurisdiction', jurisdiction)}
                      />
                      <Label htmlFor={`jurisdiction-${jurisdiction}`} className="text-xs text-gray-300">
                        {jurisdiction}
                      </Label>
                    </div>
                  ))}
                </ScrollArea>
              </div>

              {/* Regulation Type Filter */}
              <div className="space-y-2">
                <Label className="text-sm text-gray-300 flex items-center gap-1">
                  <FileText className="h-3 w-3" />
                  Regulation Type
                </Label>
                <ScrollArea className="h-32 border border-gray-600 rounded p-2">
                  {availableOptions.regulationTypes.map((type) => (
                    <div key={type} className="flex items-center space-x-2 py-1">
                      <Checkbox
                        id={`type-${type}`}
                        checked={searchCriteria.filters.regulationType.includes(type)}
                        onCheckedChange={() => toggleFilter('regulationType', type)}
                      />
                      <Label htmlFor={`type-${type}`} className="text-xs text-gray-300">
                        {type}
                      </Label>
                    </div>
                  ))}
                </ScrollArea>
              </div>
            </div>

            {/* Date Range */}
            <div className="space-y-2">
              <Label className="text-sm text-gray-300 flex items-center gap-1">
                <Calendar className="h-3 w-3" />
                Date Range
              </Label>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <Label className="text-xs text-gray-400">From</Label>
                  <Input
                    type="date"
                    value={searchCriteria.filters.dateRange.start || ''}
                    onChange={(e) => setSearchCriteria(prev => ({
                      ...prev,
                      filters: {
                        ...prev.filters,
                        dateRange: { ...prev.filters.dateRange, start: e.target.value }
                      }
                    }))}
                    className="bg-gray-800 border-gray-600 text-white"
                  />
                </div>
                <div>
                  <Label className="text-xs text-gray-400">To</Label>
                  <Input
                    type="date"
                    value={searchCriteria.filters.dateRange.end || ''}
                    onChange={(e) => setSearchCriteria(prev => ({
                      ...prev,
                      filters: {
                        ...prev.filters,
                        dateRange: { ...prev.filters.dateRange, end: e.target.value }
                      }
                    }))}
                    className="bg-gray-800 border-gray-600 text-white"
                  />
                </div>
              </div>
            </div>
          </div>

          <Separator className="bg-gray-600" />

          {/* Sort Options */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label className="text-sm text-gray-300">Sort By</Label>
              <Select 
                value={searchCriteria.sortBy} 
                onValueChange={(value) => setSearchCriteria(prev => ({ ...prev, sortBy: value }))}
              >
                <SelectTrigger className="bg-gray-800 border-gray-600 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {SORT_OPTIONS.map((option) => (
                    <SelectItem key={option.value} value={option.value}>
                      {option.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label className="text-sm text-gray-300">Order</Label>
              <Select 
                value={searchCriteria.sortOrder} 
                onValueChange={(value: 'asc' | 'desc') => setSearchCriteria(prev => ({ ...prev, sortOrder: value }))}
              >
                <SelectTrigger className="bg-gray-800 border-gray-600 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="desc">Descending</SelectItem>
                  <SelectItem value="asc">Ascending</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Saved Searches */}
          {savedSearches.length > 0 && (
            <>
              <Separator className="bg-gray-600" />
              <div className="space-y-3">
                <Label className="text-white flex items-center gap-2">
                  <Star className="h-4 w-4" />
                  Saved Searches
                </Label>
                <ScrollArea className="h-32">
                  <div className="space-y-2">
                    {savedSearches.map((saved) => (
                      <div key={saved.id} className="flex items-center justify-between p-2 bg-gray-800 rounded border border-gray-600">
                        <div className="flex-1">
                          <div className="flex items-center gap-2">
                            <span className="text-sm text-white">{saved.name}</span>
                            {saved.alertEnabled && (
                              <Badge variant="outline" className="text-xs">
                                <Clock className="h-3 w-3 mr-1" />
                                Alert
                              </Badge>
                            )}
                          </div>
                          <p className="text-xs text-gray-400 truncate">{saved.criteria.query}</p>
                        </div>
                        <div className="flex items-center gap-1">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => loadSavedSearch(saved)}
                            className="h-6 w-6 p-0"
                          >
                            <BookOpen className="h-3 w-3" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => deleteSavedSearch(saved.id)}
                            className="h-6 w-6 p-0 text-red-400 hover:text-red-300"
                          >
                            <X className="h-3 w-3" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </div>
            </>
          )}

          {/* Actions */}
          <div className="flex justify-between items-center pt-4">
            <div className="flex gap-2">
              <Button
                variant="outline"
                onClick={() => setShowSaveDialog(true)}
                className="border-gray-600 text-gray-300 hover:bg-gray-700"
              >
                <Save className="h-4 w-4 mr-2" />
                Save Search
              </Button>
            </div>
            
            <div className="flex gap-2">
              <Button variant="outline" onClick={onClose}>
                Cancel
              </Button>
              <Button onClick={handleSearch} className="bg-blue-600 hover:bg-blue-700">
                <Search className="h-4 w-4 mr-2" />
                Search
              </Button>
            </div>
          </div>
        </div>

        {/* Save Search Dialog */}
        <Dialog open={showSaveDialog} onOpenChange={setShowSaveDialog}>
          <DialogContent className="bg-gray-800 border-gray-700">
            <DialogHeader>
              <DialogTitle className="text-white">Save Search</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label className="text-white">Search Name</Label>
                <Input
                  value={searchName}
                  onChange={(e) => setSearchName(e.target.value)}
                  placeholder="Enter a name for this search..."
                  className="bg-gray-700 border-gray-600 text-white"
                />
              </div>
              
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="enable-alert"
                  checked={alertEnabled}
                  onCheckedChange={(checked) => setAlertEnabled(!!checked)}
                />
                <Label htmlFor="enable-alert" className="text-sm text-gray-300">
                  Enable alerts for new matching documents
                </Label>
              </div>
              
              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setShowSaveDialog(false)}>
                  Cancel
                </Button>
                <Button onClick={handleSaveSearch} className="bg-green-600 hover:bg-green-700">
                  Save
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </DialogContent>
    </Dialog>
  );
}
