import React from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import ProductClassificationAdmin from './ProductClassificationAdmin';
import IntroductionTreesTab from './IntroductionTreesTab';
import { AppApisClassificationClassificationTree as ClassificationTree, TreeNode, NodeOption, ClassificationOutcome } from '../brain/data-contracts';

interface Props {
  // Tree management
  classificationTrees: ClassificationTree[];
  selectedTree: ClassificationTree | null;
  treeNodes: TreeNode[];
  nodeOptions: { [nodeId: string]: NodeOption[] };
  classificationOutcomes: ClassificationOutcome[];
  
  // Dialog states
  isCreateTreeOpen: boolean;
  isCreateNodeOpen: boolean;
  isCreateOutcomeOpen: boolean;
  isCreateNoteOpen: boolean;
  isEditNoteOpen: boolean;
  selectedNote: any;
  newNoteData: any;
  classificationNotes: any[];
  showCreateNoteDialog: any;
  newTreeData: any;
  newNodeData: any;
  newOutcomeData: any;
  
  // Handlers
  setIsCreateTreeOpen: (open: boolean) => void;
  setIsCreateNodeOpen: (open: boolean) => void;
  setIsCreateOutcomeOpen: (open: boolean) => void;
  setIsCreateNoteOpen: (open: boolean) => void;
  setIsEditNoteOpen: (open: boolean) => void;
  setSelectedNote: (note: any) => void;
  setNewTreeData: (data: any) => void;
  setNewNodeData: (data: any) => void;
  setNewOutcomeData: (data: any) => void;
  setNewNoteData: (data: any) => void;
  setShowCreateNoteDialog: (show: any) => void;
  loadTreeDetails: (tree: ClassificationTree) => void;
  handleCreateTree: () => void;
  handleCreateNode: () => void;
  handleCreateOutcome: () => void;
  handleCreateNote: () => void;
  handleUpdateNote: () => void;
  handleDeleteTree: (treeId: string, treeName: string) => void;
  handleDeleteNote: (noteId: number) => void;
  handleDuplicateTree: (treeId: string, treeName: string) => void;
  loadClassificationNotes: () => void;
}

const ProductClassificationWithIntroTrees: React.FC<Props> = (props) => {
  const {
    classificationTrees,
    selectedTree,
    treeNodes,
    nodeOptions,
    setIsCreateTreeOpen,
    loadTreeDetails,
    handleDuplicateTree,
    setIsCreateNodeOpen
  } = props;

  const handleSelectTree = (tree: ClassificationTree) => {
    loadTreeDetails(tree);
  };

  const setSelectedNode = (node: TreeNode) => {
    console.log('Setting selected node:', node);
  };

  const handleDeleteNode = (nodeId: string) => {
    console.log('Deleting node:', nodeId);
  };

  return (
    <div className="space-y-6 p-6 bg-gray-900 min-h-screen">
      <div className="border-b border-gray-700 pb-4">
        <h2 className="text-2xl font-bold text-amber-400 mb-2">Product Classification Management</h2>
        <p className="text-gray-400">Manage classification trees, nodes, outcomes, and regulatory notes</p>
      </div>

      <Tabs defaultValue="trees" className="space-y-6">
        <TabsList className="bg-gray-800 border-gray-700">
          <TabsTrigger value="trees" className="data-[state=active]:bg-amber-600">Classification Trees</TabsTrigger>
          <TabsTrigger value="introduction-trees" className="data-[state=active]:bg-amber-600">Introduction Trees</TabsTrigger>
          <TabsTrigger value="outcomes" className="data-[state=active]:bg-amber-600">Outcomes</TabsTrigger>
          <TabsTrigger value="notes" className="data-[state=active]:bg-amber-600">Regulatory Notes</TabsTrigger>
        </TabsList>

        {/* Introduction Trees Tab */}
        <TabsContent value="introduction-trees" className="space-y-6">
          <IntroductionTreesTab
            classificationTrees={classificationTrees}
            selectedTree={selectedTree}
            treeNodes={treeNodes}
            nodeOptions={nodeOptions}
            setIsCreateTreeOpen={setIsCreateTreeOpen}
            handleSelectTree={handleSelectTree}
            handleDuplicateTree={handleDuplicateTree}
            setSelectedNode={setSelectedNode}
            setIsCreateNodeOpen={setIsCreateNodeOpen}
            handleDeleteNode={handleDeleteNode}
          />
        </TabsContent>

        {/* Original tabs - wrapped in invisible container to hide their tab triggers */}
        <div className="[&_.tabs-trigger]:hidden">
          <ProductClassificationAdmin {...props} />
        </div>
      </Tabs>
    </div>
  );
};

export default ProductClassificationWithIntroTrees;
