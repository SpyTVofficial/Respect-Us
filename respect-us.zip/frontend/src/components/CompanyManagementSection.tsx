

import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Users, Crown, Settings } from 'lucide-react';
import { toast } from 'sonner';
import brain from 'brain';

interface UserCompanyContext {
  company_id: number;
  company_name: string;
  company_domain?: string;
  user_role: string;
  permissions: {
    can_invite: boolean;
    can_remove_members: boolean;
    team_management: boolean;
    billing_management: boolean;
    audit_logs: boolean;
    user_management: boolean;
  };
}

interface CompanyManagementSectionProps {
  userCompanyContext: UserCompanyContext | null;
  setUserCompanyContext: React.Dispatch<React.SetStateAction<UserCompanyContext | null>>;
  loadUserProfile: () => Promise<void>;
}

interface CreateCompanyForm {
  company_name: string;
  company_domain: string;
  max_team_members: number;
}

export default function CompanyManagementSection({ 
  userCompanyContext, 
  setUserCompanyContext, 
  loadUserProfile 
}: CompanyManagementSectionProps) {
  const navigate = useNavigate();

  const [showCreateCompanyDialog, setShowCreateCompanyDialog] = useState(false);
  const [createCompanyForm, setCreateCompanyForm] = useState<CreateCompanyForm>({
    company_name: '',
    company_domain: '',
    max_team_members: 10
  });
  const [isCreating, setIsCreating] = useState(false);

  const handleCreateCompany = async () => {
    if (!createCompanyForm.company_name.trim()) {
      toast.error('Company name is required');
      return;
    }

    setIsCreating(true);
    try {
      const response = await brain.create_company(createCompanyForm);
      if (response.ok) {
        const data = await response.json();
        // Set company context from the created company data
        setUserCompanyContext({
          company_id: data.id,
          company_name: data.company_name,
          company_domain: data.company_domain,
          user_role: data.current_user_role || 'owner',
          permissions: {
            can_invite: true,
            can_remove_members: true,
            team_management: true,
            billing_management: true,
            audit_logs: true,
            user_management: true
          }
        });
        setShowCreateCompanyDialog(false);
        setCreateCompanyForm({
          company_name: '',
          company_domain: '',
          max_team_members: 10
        });
        toast.success('Company created successfully!');
        await loadUserProfile(); // Reload user profile to get company context
      } else {
        const errorData = await response.json();
        toast.error(errorData.detail || 'Failed to create company');
      }
    } catch (error) {
      console.error('Error creating company:', error);
      toast.error('Failed to create company');
    } finally {
      setIsCreating(false);
    }
  };

  const getRoleIcon = (role: string) => {
    switch (role.toLowerCase()) {
      case 'owner':
        return <Crown className="w-4 h-4 text-yellow-400" />;
      case 'admin':
        return <Settings className="w-4 h-4 text-blue-400" />;
      default:
        return <Users className="w-4 h-4 text-gray-400" />;
    }
  };

  const getRoleBadgeColor = (role: string) => {
    switch (role.toLowerCase()) {
      case 'owner':
        return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30';
      case 'admin':
        return 'bg-blue-500/20 text-blue-400 border-blue-500/30';
      case 'manager':
        return 'bg-purple-500/20 text-purple-400 border-purple-500/30';
      case 'editor':
        return 'bg-green-500/20 text-green-400 border-green-500/30';
      case 'viewer':
        return 'bg-gray-500/20 text-gray-400 border-gray-500/30';
      default:
        return 'bg-gray-500/20 text-gray-400 border-gray-500/30';
    }
  };

  if (!userCompanyContext) {
    return (
      <>
        <Card className="bg-gray-900/50 border-gray-700 backdrop-blur-sm">
          <CardContent className="p-8">
            <div className="text-center space-y-4">
              <div className="mx-auto w-16 h-16 bg-blue-600/20 rounded-full flex items-center justify-center">
                <Building className="w-8 h-8 text-blue-400" />
              </div>
              <div>
                <h3 className="text-xl font-semibold text-white mb-2">Set Up Your Company</h3>
                <p className="text-gray-400 mb-6 max-w-md mx-auto">
                  Create your company profile to start inviting team members and managing enterprise features
                </p>
              </div>
              <Button
                onClick={() => setShowCreateCompanyDialog(true)}
                className="bg-blue-600 hover:bg-blue-700 text-white"
              >
                <Building className="w-4 h-4 mr-2" />
                Create Company
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Create Company Dialog */}
        <Dialog open={showCreateCompanyDialog} onOpenChange={setShowCreateCompanyDialog}>
          <DialogContent className="bg-gray-900 border-gray-700">
            <DialogHeader>
              <DialogTitle className="text-white flex items-center">
                <Building className="w-5 h-5 mr-2 text-blue-400" />
                Create Company
              </DialogTitle>
              <DialogDescription className="text-gray-400">
                Set up your company profile to enable team management and enterprise features.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="company-name" className="text-sm font-medium text-gray-200">
                  Company Name *
                </Label>
                <Input
                  id="company-name"
                  value={createCompanyForm.company_name}
                  onChange={(e) => setCreateCompanyForm(prev => ({ ...prev, company_name: e.target.value }))}
                  placeholder="Your Company Ltd."
                  className="bg-gray-800/50 border-gray-600 text-white placeholder-gray-400 focus:border-blue-500"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="company-domain" className="text-sm font-medium text-gray-200">
                  Company Domain (Optional)
                </Label>
                <Input
                  id="company-domain"
                  value={createCompanyForm.company_domain}
                  onChange={(e) => setCreateCompanyForm(prev => ({ ...prev, company_domain: e.target.value }))}
                  placeholder="yourcompany.com"
                  className="bg-gray-800/50 border-gray-600 text-white placeholder-gray-400 focus:border-blue-500"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="max-members" className="text-sm font-medium text-gray-200">
                  Maximum Team Members
                </Label>
                <Select
                  value={createCompanyForm.max_team_members.toString()}
                  onValueChange={(value) => setCreateCompanyForm(prev => ({ ...prev, max_team_members: parseInt(value) }))}
                >
                  <SelectTrigger className="bg-gray-800/50 border-gray-600 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="5">5 members</SelectItem>
                    <SelectItem value="10">10 members</SelectItem>
                    <SelectItem value="25">25 members</SelectItem>
                    <SelectItem value="50">50 members</SelectItem>
                    <SelectItem value="100">100 members</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex items-center justify-end space-x-2 pt-4">
                <Button
                  variant="outline"
                  onClick={() => setShowCreateCompanyDialog(false)}
                  className="border-gray-600 text-gray-300 hover:bg-gray-800"
                  disabled={isCreating}
                >
                  Cancel
                </Button>
                <Button
                  onClick={handleCreateCompany}
                  disabled={!createCompanyForm.company_name || isCreating}
                  className="bg-blue-600 hover:bg-blue-700 text-white"
                >
                  {isCreating ? (
                    <div className="flex items-center gap-2">
                      <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                      Creating...
                    </div>
                  ) : (
                    <>
                      <Building className="w-4 h-4 mr-2" />
                      Create Company
                    </>
                  )}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </>
    );
  }

  return (
    <Card className="bg-gray-900/50 border-gray-700 backdrop-blur-sm">
      <CardHeader>
        <CardTitle className="text-white flex items-center">
          <Building className="w-5 h-5 mr-2 text-blue-400" />
          Company Information
        </CardTitle>
        <CardDescription className="text-gray-400">
          Manage your company profile and enterprise settings
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Company Overview */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <div>
              <Label className="text-sm font-medium text-gray-200">Company Name</Label>
              <p className="text-white font-semibold text-lg">{userCompanyContext.company_name}</p>
            </div>
            {userCompanyContext.company_domain && (
              <div>
                <Label className="text-sm font-medium text-gray-200">Company Domain</Label>
                <p className="text-gray-300">{userCompanyContext.company_domain}</p>
              </div>
            )}
          </div>
          <div className="space-y-4">
            <div>
              <Label className="text-sm font-medium text-gray-200">Your Role</Label>
              <div className="flex items-center space-x-2 mt-1">
                {getRoleIcon(userCompanyContext.user_role)}
                <span className={`px-2 py-1 rounded-full text-xs font-medium border ${getRoleBadgeColor(userCompanyContext.user_role)}`}>
                  {userCompanyContext.user_role.charAt(0).toUpperCase() + userCompanyContext.user_role.slice(1)}
                </span>
              </div>
            </div>
            <div>
              <Label className="text-sm font-medium text-gray-200">Company ID</Label>
              <p className="text-gray-400 text-sm font-mono">{userCompanyContext.company_id}</p>
            </div>
          </div>
        </div>

        {/* Permissions Overview */}
        <div className="space-y-4">
          <h3 className="text-lg font-semibold text-white">Your Permissions</h3>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
            <div className={`p-3 rounded-lg border ${
              userCompanyContext.permissions.can_invite 
                ? 'bg-green-500/10 border-green-500/30 text-green-400' 
                : 'bg-gray-500/10 border-gray-500/30 text-gray-400'
            }`}>
              <div className="text-xs font-medium">Invite Members</div>
              <div className="text-xs opacity-80">
                {userCompanyContext.permissions.can_invite ? 'Allowed' : 'Restricted'}
              </div>
            </div>
            <div className={`p-3 rounded-lg border ${
              userCompanyContext.permissions.can_remove_members 
                ? 'bg-green-500/10 border-green-500/30 text-green-400' 
                : 'bg-gray-500/10 border-gray-500/30 text-gray-400'
            }`}>
              <div className="text-xs font-medium">Remove Members</div>
              <div className="text-xs opacity-80">
                {userCompanyContext.permissions.can_remove_members ? 'Allowed' : 'Restricted'}
              </div>
            </div>
            <div className={`p-3 rounded-lg border ${
              userCompanyContext.permissions.team_management 
                ? 'bg-green-500/10 border-green-500/30 text-green-400' 
                : 'bg-gray-500/10 border-gray-500/30 text-gray-400'
            }`}>
              <div className="text-xs font-medium">Team Management</div>
              <div className="text-xs opacity-80">
                {userCompanyContext.permissions.team_management ? 'Allowed' : 'Restricted'}
              </div>
            </div>
            <div className={`p-3 rounded-lg border ${
              userCompanyContext.permissions.billing_management 
                ? 'bg-green-500/10 border-green-500/30 text-green-400' 
                : 'bg-gray-500/10 border-gray-500/30 text-gray-400'
            }`}>
              <div className="text-xs font-medium">Billing Management</div>
              <div className="text-xs opacity-80">
                {userCompanyContext.permissions.billing_management ? 'Allowed' : 'Restricted'}
              </div>
            </div>
            <div className={`p-3 rounded-lg border ${
              userCompanyContext.permissions.audit_logs 
                ? 'bg-green-500/10 border-green-500/30 text-green-400' 
                : 'bg-gray-500/10 border-gray-500/30 text-gray-400'
            }`}>
              <div className="text-xs font-medium">Audit Logs</div>
              <div className="text-xs opacity-80">
                {userCompanyContext.permissions.audit_logs ? 'Allowed' : 'Restricted'}
              </div>
            </div>
            <div className={`p-3 rounded-lg border ${
              userCompanyContext.permissions.user_management 
                ? 'bg-green-500/10 border-green-500/30 text-green-400' 
                : 'bg-gray-500/10 border-gray-500/30 text-gray-400'
            }`}>
              <div className="text-xs font-medium">User Management</div>
              <div className="text-xs opacity-80">
                {userCompanyContext.permissions.user_management ? 'Allowed' : 'Restricted'}
              </div>
            </div>
          </div>
        </div>

        {/* Quick Actions */}
        {(userCompanyContext.user_role === 'owner' || userCompanyContext.user_role === 'admin') && (
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-white">Quick Actions</h3>
            <div className="flex flex-wrap gap-3">
              <Button
                variant="outline"
                className="border-blue-500/30 text-blue-400 hover:bg-blue-500/10"
                onClick={() => navigate('/user-dashboard?tab=team')}
              >
                <Users className="w-4 h-4 mr-2" />
                Manage Team
              </Button>
              <Button
                variant="outline"
                className="border-green-500/30 text-green-400 hover:bg-green-500/10"
                onClick={() => navigate('/user-dashboard?tab=management')}
              >
                <Settings className="w-4 h-4 mr-2" />
                Company Settings
              </Button>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
