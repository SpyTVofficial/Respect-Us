











import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Plus, Edit, Trash2, TrendingUp, CreditCard, Users, Euro, Settings, Package, Edit2 } from 'lucide-react';
import { toast } from 'sonner';
import brain from 'brain';
import type { ComponentPricing, PricingFeatureFlag, CreditPackage, PricingAnalytics } from 'types';

interface Props {
  className?: string;
}

const AdminPricingControl: React.FC<Props> = ({ className }) => {
  const [componentPricing, setComponentPricing] = useState<ComponentPricing[]>([]);
  const [featureFlags, setFeatureFlags] = useState<PricingFeatureFlag[]>([]);
  const [creditPackages, setCreditPackages] = useState<CreditPackage[]>([]);
  const [pricingAnalytics, setPricingAnalytics] = useState<PricingAnalytics[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('component-pricing');
  
  // Credit price configuration state
  const [baseCreditPrice, setBaseCreditPrice] = useState<number>(0.10);
  const [editingCreditPrice, setEditingCreditPrice] = useState(false);
  const [tempCreditPrice, setTempCreditPrice] = useState<string>('0.10');
  
  // Component pricing editing state
  const [editingPricing, setEditingPricing] = useState<{ id: number; cost: number } | null>(null);

  // Credit package management state
  const [showPackageDialog, setShowPackageDialog] = useState(false);
  const [editingPackage, setEditingPackage] = useState<CreditPackage | null>(null);
  const [packageForm, setPackageForm] = useState({
    name: '',
    credits: 0,
    price_cents: 0,
    discount_percentage: 0,
    is_active: true,
    expiry_months: 12
  });

  // New state for enhanced features
  const [showNewPricingDialog, setShowNewPricingDialog] = useState(false);
  const [showCreditAdjustDialog, setShowCreditAdjustDialog] = useState(false);
  const [showBulkUpdateDialog, setShowBulkUpdateDialog] = useState(false);
  const [showAuditLogDialog, setShowAuditLogDialog] = useState(false);
  const [comprehensiveAnalytics, setComprehensiveAnalytics] = useState<any>(null);
  const [auditLog, setAuditLog] = useState<any[]>([]);
  const [bulkUpdates, setBulkUpdates] = useState<any[]>([]);
  const [newPricingForm, setNewPricingForm] = useState({
    component_name: '',
    action_name: '',
    credit_cost: 0,
    effective_from: new Date().toISOString().split('T')[0]
  });
  const [creditAdjustForm, setCreditAdjustForm] = useState({
    user_id: '',
    amount: 0,
    reason: ''
  });

  // Module Access Pricing state
  const [showModulePricingDialog, setShowModulePricingDialog] = useState(false);
  const [editingModulePricing, setEditingModulePricing] = useState<any>(null);
  const [modulePricing, setModulePricing] = useState<any[]>([]);
  const [newModulePricingForm, setNewModulePricingForm] = useState({
    module_name: '',
    module_title: '',
    pricing_type: 'credits',
    credit_cost: 0,
    price_eur: 0,
    description: '',
    is_active: true
  });

  useEffect(() => {
    loadPricingData();
  }, []);

  const loadPricingData = async () => {
    try {
      setLoading(true);
      const [pricingResponse, flagsResponse, analyticsResponse, comprehensiveResponse, modulePricingResponse] = await Promise.all([
        brain.get_component_pricing(),
        brain.get_pricing_feature_flags(),
        brain.get_pricing_analytics(),
        brain.get_comprehensive_pricing_analytics(),
        brain.get_module_pricing_configurations()
      ]);

      const pricingData = await pricingResponse.json();
      const flagsData = await flagsResponse.json();
      const analyticsData = await analyticsResponse.json();
      const comprehensiveData = await comprehensiveResponse.json();
      const modulePricingData = await modulePricingResponse.json();

      setComponentPricing(pricingData);
      setFeatureFlags(flagsData);
      setPricingAnalytics(analyticsData);
      setComprehensiveAnalytics(comprehensiveData);
      setModulePricing(modulePricingData);
      
      // Load credit packages and base price separately
      await fetchCreditPackages();
      await fetchBaseCreditPrice();
    } catch (error) {
      console.error('Error loading pricing data:', error);
      toast.error('Failed to load pricing data');
    } finally {
      setLoading(false);
    }
  };

  const loadAuditLog = async () => {
    try {
      const response = await brain.get_pricing_audit_log();
      if (response.ok) {
        const data = await response.json();
        setAuditLog(data);
      }
    } catch (error) {
      console.error('Error loading audit log:', error);
      toast.error('Failed to load audit log');
    }
  };

  const performBulkUpdate = async () => {
    try {
      const response = await brain.bulk_update_pricing({
        updates: bulkUpdates,
        apply_to: 'all',
        effective_date: new Date().toISOString()
      });
      
      if (response.ok) {
        toast.success('Bulk pricing update completed successfully');
        setShowBulkUpdateDialog(false);
        setBulkUpdates([]);
        await loadPricingData();
      }
    } catch (error) {
      console.error('Error performing bulk update:', error);
      toast.error('Failed to perform bulk update');
    }
  };

  const createNewPricing = async () => {
    try {
      const response = await brain.create_component_pricing(newPricingForm);
      if (response.ok) {
        const newPricing = await response.json();
        setComponentPricing(prev => [...prev, newPricing]);
        setShowNewPricingDialog(false);
        setNewPricingForm({
          component_name: '',
          action_name: '',
          credit_cost: 0,
          effective_from: new Date().toISOString().split('T')[0]
        });
        toast.success('New pricing configuration created successfully');
      }
    } catch (error) {
      console.error('Error creating pricing:', error);
      toast.error('Failed to create pricing configuration');
    }
  };

  const adjustUserCredits = async () => {
    try {
      const response = await brain.admin_adjust_credits(creditAdjustForm);
      if (response.ok) {
        setShowCreditAdjustDialog(false);
        setCreditAdjustForm({ user_id: '', amount: 0, reason: '' });
        toast.success('User credits adjusted successfully');
      }
    } catch (error) {
      console.error('Error adjusting credits:', error);
      toast.error('Failed to adjust user credits');
    }
  };

  // Module pricing operations
  const handleCreateModulePricing = () => {
    setEditingModulePricing(null);
    setNewModulePricingForm({
      module_name: '',
      module_title: '',
      pricing_type: 'credits',
      credit_cost: 0,
      price_eur: 0,
      description: '',
      is_active: true
    });
    setShowModulePricingDialog(true);
  };

  const handleEditModulePricing = (module: any) => {
    setEditingModulePricing(module);
    setNewModulePricingForm({
      module_name: module.module_name,
      module_title: module.module_title,
      pricing_type: module.pricing_type,
      credit_cost: module.credit_cost || 0,
      price_eur: module.price_eur || 0,
      description: module.description || '',
      is_active: module.is_active
    });
    setShowModulePricingDialog(true);
  };

  const handleSaveModulePricing = async () => {
    try {
      if (editingModulePricing) {
        // Update existing module pricing
        const response = await brain.update_module_pricing_configuration(
          newModulePricingForm.module_name,
          {
            pricing_type: newModulePricingForm.pricing_type,
            credit_cost: newModulePricingForm.pricing_type === 'credits' ? newModulePricingForm.credit_cost : null,
            price_eur: newModulePricingForm.pricing_type === 'eur' ? newModulePricingForm.price_eur : null,
            description: newModulePricingForm.description,
            is_active: newModulePricingForm.is_active
          }
        );
        
        if (response.ok) {
          const updatedModule = await response.json();
          setModulePricing(prev => 
            prev.map(module => module.id === editingModulePricing.id ? updatedModule : module)
          );
          toast.success('Module pricing updated successfully');
        } else {
          toast.error('Failed to update module pricing');
        }
      } else {
        // Create new module pricing
        const response = await brain.create_module_pricing_configuration({
          module_name: newModulePricingForm.module_name,
          module_title: newModulePricingForm.module_title,
          pricing_type: newModulePricingForm.pricing_type,
          credit_cost: newModulePricingForm.pricing_type === 'credits' ? newModulePricingForm.credit_cost : null,
          price_eur: newModulePricingForm.pricing_type === 'eur' ? newModulePricingForm.price_eur : null,
          description: newModulePricingForm.description
        });
        
        if (response.ok) {
          const newModule = await response.json();
          setModulePricing(prev => [...prev, newModule]);
          toast.success('Module pricing created successfully');
        } else {
          toast.error('Failed to create module pricing');
        }
      }
      setShowModulePricingDialog(false);
    } catch (error) {
      console.error('Error saving module pricing:', error);
      toast.error('Failed to save module pricing');
    }
  };

  const handleDeleteModulePricing = async (module: any) => {
    if (confirm(`Are you sure you want to delete pricing for "${module.module_title}"?`)) {
      try {
        const response = await brain.delete_module_pricing_configuration({ moduleName: module.module_name });
        
        if (response.ok) {
          setModulePricing(prev => prev.filter(m => m.id !== module.id));
          toast.success('Module pricing deleted successfully');
        } else {
          toast.error('Failed to delete module pricing');
        }
      } catch (error) {
        console.error('Error deleting module pricing:', error);
        toast.error('Failed to delete module pricing');
      }
    }
  };

  const updateFeatureFlag = async (componentName: string, enabled: boolean) => {
    try {
      const response = await brain.update_pricing_feature_flag(
        { componentName },
        {
          is_pricing_enabled: enabled,
          rollout_strategy: enabled ? 'full' : 'disabled',
          rollout_percentage: enabled ? 100 : 0
        }
      );

      if (response.ok) {
        setFeatureFlags(prev => 
          prev.map(flag => 
            flag.component_name === componentName 
              ? { ...flag, is_pricing_enabled: enabled }
              : flag
          )
        );
        toast.success(`Pricing ${enabled ? 'enabled' : 'disabled'} for ${componentName}`);
      }
    } catch (error) {
      console.error('Error updating feature flag:', error);
      toast.error('Failed to update pricing settings');
    }
  };

  const updatePricingCost = async (pricingId: number, newCost: number) => {
    if (newCost <= 0) {
      toast.error('Credit cost must be greater than 0');
      return;
    }
    
    try {
      const response = await brain.update_component_pricing(
        { pricingId },
        { credit_cost: newCost }
      );

      if (response.ok) {
        const updatedPricing = await response.json();
        setComponentPricing(prev => 
          prev.map(pricing => 
            pricing.id === pricingId 
              ? { ...pricing, credit_cost: updatedPricing.credit_cost }
              : pricing
          )
        );
        setEditingPricing(null);
        toast.success('Pricing updated successfully');
      } else {
        const errorData = await response.json().catch(() => ({ detail: 'Unknown error' }));
        toast.error(`Failed to update pricing: ${errorData.detail || 'Unknown error'}`);
      }
    } catch (error) {
      console.error('Error updating pricing:', error);
      toast.error('Failed to update pricing');
    }
  };

  const togglePricingActive = async (pricingId: number, isActive: boolean) => {
    try {
      const response = await brain.update_component_pricing(
        { pricingId },
        { credit_cost: componentPricing.find(p => p.id === pricingId)?.credit_cost || 0, is_active: isActive }
      );

      if (response.ok) {
        setComponentPricing(prev => 
          prev.map(pricing => 
            pricing.id === pricingId 
              ? { ...pricing, is_active: isActive }
              : pricing
          )
        );
        toast.success(`Pricing ${isActive ? 'activated' : 'deactivated'}`);
      }
    } catch (error) {
      console.error('Error toggling pricing:', error);
      toast.error('Failed to update pricing status');
    }
  };

  const deletePricing = async (pricingId: number, componentName: string, actionName: string) => {
    try {
      // Instead of deleting, deactivate the pricing configuration
      const response = await brain.update_component_pricing(
        { pricingId },
        { 
          credit_cost: componentPricing.find(p => p.id === pricingId)?.credit_cost || 0, 
          is_active: false 
        }
      );
      
      if (response.ok) {
        setComponentPricing(prev => 
          prev.map(pricing => 
            pricing.id === pricingId 
              ? { ...pricing, is_active: false }
              : pricing
          )
        );
        toast.success('Pricing configuration deactivated successfully');
      } else {
        toast.error('Failed to deactivate pricing configuration');
      }
    } catch (error) {
      console.error('Error deactivating pricing:', error);
      toast.error('Failed to deactivate pricing configuration');
    }
  };

  const formatComponentName = (name: string) => {
    return name.split('_').map(word => 
      word.charAt(0).toUpperCase() + word.slice(1)
    ).join(' ');
  };

  const groupPricingByComponent = () => {
    const grouped: { [key: string]: ComponentPricing[] } = {};
    componentPricing.forEach(pricing => {
      if (!grouped[pricing.component_name]) {
        grouped[pricing.component_name] = [];
      }
      grouped[pricing.component_name].push(pricing);
    });
    return grouped;
  };

  // Save credit price function
  const saveCreditPrice = async () => {
    try {
      const newPrice = parseFloat(tempCreditPrice);
      if (isNaN(newPrice) || newPrice <= 0) {
        toast.error('Please enter a valid price greater than 0');
        return;
      }
      
      const response = await brain.update_base_credit_price({
        price_eur_per_credit: newPrice
      });

      if (response.ok) {
        const data = await response.json();
        setBaseCreditPrice(data.price_eur_per_credit);
        setIsEditingCreditPrice(false);
        toast.success('Credit price updated successfully');
      } else {
        toast.error('Failed to update credit price');
      }
    } catch (error) {
      console.error('Error saving credit price:', error);
      toast.error('Failed to update credit price');
    }
  };

  const cancelCreditPriceEdit = () => {
    setTempCreditPrice(baseCreditPrice.toString());
    setEditingCreditPrice(false);
  };

  // Credit package operations
  const handleCreatePackage = () => {
    setEditingPackage(null);
    setPackageForm({
      name: '',
      credits: 0,
      price_cents: 0,
      discount_percentage: 0,
      is_active: true,
      expiry_months: 12
    });
    setShowPackageDialog(true);
  };

  const handleEditPackage = (pkg: CreditPackage) => {
    setEditingPackage(pkg);
    setPackageForm({
      name: pkg.name,
      credits: pkg.credits,
      price_cents: pkg.price_cents,
      discount_percentage: pkg.discount_percentage || 0,
      is_active: pkg.is_active,
      expiry_months: pkg.expiry_months || 12
    });
    setShowPackageDialog(true);
  };

  const handleSavePackage = async () => {
    try {
      if (editingPackage) {
        // Update existing package
        const response = await brain.update_credit_package(
          { packageId: editingPackage.id },
          {
            name: packageForm.name,
            credits: packageForm.credits,
            price_cents: packageForm.price_cents,
            discount_percentage: packageForm.discount_percentage,
            is_active: packageForm.is_active,
            expiry_months: packageForm.expiry_months
          }
        );
        
        if (response.ok) {
          const updatedPackage = await response.json();
          setCreditPackages(prev => 
            prev.map(pkg => pkg.id === editingPackage.id ? updatedPackage : pkg)
          );
          toast.success('Credit package updated successfully');
        } else {
          toast.error('Failed to update credit package');
        }
      } else {
        // Create new package
        const response = await brain.create_credit_package({
          name: packageForm.name,
          credits: packageForm.credits,
          price_cents: packageForm.price_cents,
          currency: 'EUR',
          discount_percentage: packageForm.discount_percentage,
          is_active: packageForm.is_active,
          expiry_months: packageForm.expiry_months
        });
        
        if (response.ok) {
          const newPackage = await response.json();
          setCreditPackages(prev => [...prev, newPackage]);
          toast.success('Credit package created successfully');
        } else {
          toast.error('Failed to create credit package');
        }
      }
      setShowPackageDialog(false);
      await fetchCreditPackages();
    } catch (error) {
      toast.error(editingPackage ? 'Failed to update credit package' : 'Failed to create credit package');
      console.error('Save package error:', error);
    }
  };

  const handleDeletePackage = async (pkg: CreditPackage) => {
    if (confirm(`Are you sure you want to delete the package "${pkg.name}"?`)) {
      try {
        const response = await brain.delete_credit_package({ packageId: pkg.id });
        
        if (response.ok) {
          setCreditPackages(prev => prev.filter(p => p.id !== pkg.id));
          toast.success('Credit package deleted successfully');
        } else {
          toast.error('Failed to delete credit package');
        }
      } catch (error) {
        toast.error('Failed to delete credit package');
        console.error('Delete package error:', error);
      }
    }
  };

  const fetchCreditPackages = async () => {
    try {
      const response = await brain.get_all_credit_packages();
      if (response.ok) {
        const data = await response.json();
        setCreditPackages(data);
      }
    } catch (error) {
      console.error('Error fetching credit packages:', error);
    }
  };

  const fetchBaseCreditPrice = async () => {
    try {
      const response = await brain.get_base_credit_price();
      if (response.ok) {
        const data = await response.json();
        setBaseCreditPrice(data.price_eur_per_credit);
      }
    } catch (error) {
      console.error('Error fetching base credit price:', error);
      setBaseCreditPrice(0.10); // fallback default
    }
  };

  if (loading) {
    return (
      <div className="bg-gray-800/30 backdrop-blur-sm border border-gray-700 rounded-lg p-6">
        <div className="flex items-center justify-center h-32">
          <div className="text-gray-400">Loading pricing data...</div>
        </div>
      </div>
    );
  }

  return (
    <div className={`space-y-6 ${className || ''}`}>
      {/* Credit Price Configuration Section */}
      <Card className="bg-gray-800/50 border-gray-700">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-white flex items-center gap-2">
                <Euro className="h-5 w-5 text-yellow-400" />
                Credit Price Configuration
              </CardTitle>
              <CardDescription className="text-gray-400">
                Set the base price in EUR for 1 credit
              </CardDescription>
            </div>
            <div className="flex items-center gap-3">
              {editingCreditPrice ? (
                <div className="flex items-center gap-2">
                  <div className="flex items-center bg-gray-700/50 rounded-lg px-3 py-2">
                    <Euro className="h-4 w-4 text-gray-400 mr-1" />
                    <Input
                      type="number"
                      step="0.01"
                      min="0"
                      value={tempCreditPrice}
                      onChange={(e) => setTempCreditPrice(e.target.value)}
                      className="w-20 bg-transparent border-none p-0 text-white focus:ring-0"
                      autoFocus
                    />
                  </div>
                  <Button
                    size="sm"
                    onClick={saveCreditPrice}
                    className="bg-green-600 hover:bg-green-700"
                  >
                    Save
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={cancelCreditPriceEdit}
                    className="border-gray-600 text-gray-300"
                  >
                    Cancel
                  </Button>
                </div>
              ) : (
                <div className="flex items-center gap-3">
                  <div className="bg-yellow-900/30 px-4 py-2 rounded-lg border border-yellow-600/30">
                    <div className="text-lg font-bold text-yellow-200">
                      €{baseCreditPrice.toFixed(2)} per credit
                    </div>
                  </div>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => {
                      setTempCreditPrice(baseCreditPrice.toString());
                      setEditingCreditPrice(true);
                    }}
                    className="border-gray-600 text-gray-300 hover:bg-gray-700"
                  >
                    <Settings className="h-4 w-4 mr-1" />
                    Edit
                  </Button>
                </div>
              )}
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-gray-700/30 p-4 rounded-lg">
              <div className="text-sm text-gray-400">Current Price</div>
              <div className="text-2xl font-bold text-white">€{baseCreditPrice.toFixed(2)}</div>
              <div className="text-xs text-gray-500">Per credit</div>
            </div>
            <div className="bg-gray-700/30 p-4 rounded-lg">
              <div className="text-sm text-gray-400">100 Credits</div>
              <div className="text-2xl font-bold text-white">€{(baseCreditPrice * 100).toFixed(2)}</div>
              <div className="text-xs text-gray-500">Package pricing</div>
            </div>
            <div className="bg-gray-700/30 p-4 rounded-lg">
              <div className="text-sm text-gray-400">1000 Credits</div>
              <div className="text-2xl font-bold text-white">€{(baseCreditPrice * 1000).toFixed(2)}</div>
              <div className="text-xs text-gray-500">Bulk pricing</div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-6 bg-gray-800 border border-gray-700">
          <TabsTrigger value="component-pricing" className="text-gray-300 data-[state=active]:bg-gray-700 data-[state=active]:text-white">
            Component Pricing
          </TabsTrigger>
          <TabsTrigger value="module-pricing" className="text-gray-300 data-[state=active]:bg-gray-700 data-[state=active]:text-white">
            Module Access
          </TabsTrigger>
          <TabsTrigger value="feature-flags" className="text-gray-300 data-[state=active]:bg-gray-700 data-[state=active]:text-white">
            Feature Flags
          </TabsTrigger>
          <TabsTrigger value="credit-packages" className="text-gray-300 data-[state=active]:bg-gray-700 data-[state=active]:text-white">
            Credit Packages
          </TabsTrigger>
          <TabsTrigger value="analytics" className="text-gray-300 data-[state=active]:bg-gray-700 data-[state=active]:text-white">
            Analytics
          </TabsTrigger>
          <TabsTrigger value="audit" className="text-gray-300 data-[state=active]:bg-gray-700 data-[state=active]:text-white">
            Audit Log
          </TabsTrigger>
        </TabsList>

        {/* Component Pricing Tab */}
        <TabsContent value="component-pricing" className="space-y-4">
          <Card className="bg-gray-800/50 border-gray-700">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="text-white">Component Pricing Configuration</CardTitle>
                  <CardDescription className="text-gray-400">
                    Manage credit costs for different components and actions
                  </CardDescription>
                </div>
                <div className="flex gap-2">
                  <Button
                    onClick={() => setShowNewPricingDialog(true)}
                    className="bg-green-600 hover:bg-green-700"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    New Pricing
                  </Button>
                  <Button
                    onClick={() => setShowCreditAdjustDialog(true)}
                    variant="outline"
                    className="border-gray-600 text-gray-300 hover:bg-gray-700"
                  >
                    <CreditCard className="w-4 h-4 mr-2" />
                    Adjust Credits
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow className="border-gray-700">
                    <TableHead className="text-gray-300">Component</TableHead>
                    <TableHead className="text-gray-300">Action</TableHead>
                    <TableHead className="text-gray-300">Credit Cost</TableHead>
                    <TableHead className="text-gray-300">EUR Cost</TableHead>
                    <TableHead className="text-gray-300">Effective From</TableHead>
                    <TableHead className="text-gray-300">Status</TableHead>
                    <TableHead className="text-gray-300">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {componentPricing.filter(pricing => pricing.is_active).map((pricing) => (
                    <TableRow key={pricing.id} className="border-gray-700">
                      <TableCell className="text-white font-medium">
                        {formatComponentName(pricing.component_name)}
                      </TableCell>
                      <TableCell className="text-gray-300">
                        {pricing.action_name.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase())}
                      </TableCell>
                      <TableCell className="text-gray-300">
                        {editingPricing?.id === pricing.id ? (
                          <div className="flex items-center gap-2">
                            <Input
                              type="number"
                              value={editingPricing.cost}
                              onChange={(e) => setEditingPricing({ ...editingPricing, cost: Number(e.target.value) })}
                              className="w-20 bg-gray-700 border-gray-600 text-white"
                              onBlur={() => updatePricingCost(pricing.id, editingPricing.cost)}
                              onKeyPress={(e) => e.key === 'Enter' && updatePricingCost(pricing.id, editingPricing.cost)}
                              autoFocus
                            />
                            <Button
                              size="sm"
                              onClick={() => updatePricingCost(pricing.id, editingPricing.cost)}
                              className="bg-green-600 hover:bg-green-700 px-2"
                            >
                              ✓
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => setEditingPricing(null)}
                              className="border-gray-600 text-gray-300 hover:bg-gray-700 px-2"
                            >
                              ✕
                            </Button>
                          </div>
                        ) : (
                          <span className="text-white">
                            {pricing.credit_cost} credits
                          </span>
                        )}
                      </TableCell>
                      <TableCell className="text-gray-300">
                        <span className="text-yellow-400 font-medium">
                          €{(pricing.credit_cost * baseCreditPrice).toFixed(2)}
                        </span>
                      </TableCell>
                      <TableCell className="text-gray-300">
                        {new Date(pricing.effective_from).toLocaleDateString()}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Badge variant={pricing.is_active ? "default" : "secondary"} className={pricing.is_active ? "bg-green-600" : "bg-gray-600"}>
                            {pricing.is_active ? 'Active' : 'Inactive'}
                          </Badge>
                          <Switch
                            checked={pricing.is_active}
                            onCheckedChange={(checked) => togglePricingActive(pricing.id, checked)}
                            className="scale-75"
                          />
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1">
                          <Button
                            size="sm"
                            variant="outline"
                            className="border-gray-600 text-gray-300 hover:bg-gray-700 px-2"
                            onClick={() => setEditingPricing({ id: pricing.id, cost: pricing.credit_cost })}
                          >
                            <Edit className="h-3 w-3" />
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            className="border-red-600 text-red-400 hover:bg-red-900/20 px-2"
                            onClick={() => {
                              if (confirm(`Delete pricing for ${pricing.component_name}/${pricing.action_name}?`)) {
                                deletePricing(pricing.id, pricing.component_name, pricing.action_name);
                              }
                            }}
                          >
                            <Trash2 className="h-3 w-3" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
              
              {componentPricing.filter(pricing => pricing.is_active).length === 0 && (
                <div className="text-center text-gray-400 py-8">
                  <Settings className="w-12 h-12 mx-auto mb-4 opacity-50" />
                  <p>No active pricing configurations found</p>
                  <p className="text-sm">Create your first pricing configuration to get started</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Module Access Pricing Tab */}
        <TabsContent value="module-pricing" className="space-y-6">
          <Card className="bg-gray-800/50 border-gray-700">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="text-white flex items-center gap-2">
                    <Settings className="h-5 w-5 text-purple-400" />
                    Module Access Pricing
                  </CardTitle>
                  <CardDescription className="text-gray-400">
                    Configure pricing for module access (Risk Assessment, Validation, etc.)
                  </CardDescription>
                </div>
                <Button
                  onClick={() => handleCreateModulePricing()}
                  className="bg-purple-600 hover:bg-purple-700"
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Add Module Pricing
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow className="border-gray-700">
                      <TableHead className="text-gray-300">Module</TableHead>
                      <TableHead className="text-gray-300">Pricing Type</TableHead>
                      <TableHead className="text-gray-300">Cost</TableHead>
                      <TableHead className="text-gray-300">Status</TableHead>
                      <TableHead className="text-gray-300">Description</TableHead>
                      <TableHead className="text-gray-300">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {modulePricing.map((module) => (
                      <TableRow key={module.id} className="border-gray-700">
                        <TableCell className="text-white">
                          <div>
                            <div className="font-medium">{module.module_title}</div>
                            <div className="text-sm text-gray-400">{module.module_name}</div>
                          </div>
                        </TableCell>
                        <TableCell className="text-gray-300">
                          <Badge variant={module.pricing_type === 'credits' ? 'default' : 'secondary'}>
                            {module.pricing_type === 'credits' ? 'Credits' : 'EUR'}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-white">
                          {module.pricing_type === 'credits' 
                            ? `${module.credit_cost?.toLocaleString()} credits`
                            : `€${module.price_eur}`
                          }
                        </TableCell>
                        <TableCell>
                          <Badge variant={module.is_active ? 'default' : 'secondary'}>
                            {module.is_active ? 'Active' : 'Inactive'}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-gray-300 max-w-xs truncate">
                          {module.description || 'No description'}
                        </TableCell>
                        <TableCell>
                          <div className="flex gap-2">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleEditModulePricing(module)}
                              className="border-gray-600 text-gray-300 hover:bg-gray-700"
                            >
                              <Edit className="h-3 w-3" />
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleDeleteModulePricing(module)}
                              className="border-red-600 text-red-400 hover:bg-red-600/20"
                            >
                              <Trash2 className="h-3 w-3" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                    {modulePricing.length === 0 && (
                      <TableRow>
                        <TableCell colSpan={6} className="text-center text-gray-400 py-8">
                          No module pricing configurations found. Add one to get started.
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Feature Flags Tab */}
        <TabsContent value="feature-flags" className="space-y-4">
          <Card className="bg-gray-800/50 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white">Pricing Feature Flags</CardTitle>
              <CardDescription className="text-gray-400">
                Enable or disable pricing features across the platform
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {featureFlags.map((flag) => (
                  <div key={flag.id} className="flex items-center justify-between p-4 bg-gray-700/30 rounded-lg border border-gray-600">
                    <div className="flex-1">
                      <div className="flex items-center gap-3">
                        <h3 className="text-white font-medium">{flag.component_name}</h3>
                        <Badge variant="outline" className="border-gray-500 text-gray-300">
                          {flag.flag_key}
                        </Badge>
                      </div>
                      <p className="text-gray-400 text-sm mt-1">
                        Control pricing behavior for {flag.component_name} component
                      </p>
                      {flag.description && (
                        <p className="text-gray-500 text-xs mt-1">{flag.description}</p>
                      )}
                    </div>
                    <div className="flex items-center gap-3">
                      <Switch
                        checked={flag.is_enabled}
                        onCheckedChange={(checked) => updateFeatureFlag(flag.component_name, checked)}
                      />
                      <span className={`text-sm font-medium ${
                        flag.is_enabled ? 'text-green-400' : 'text-gray-500'
                      }`}>
                        {flag.is_enabled ? 'Enabled' : 'Disabled'}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Credit Packages Tab */}
        <TabsContent value="credit-packages" className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-lg font-semibold text-white">Credit Packages</h3>
                <p className="text-sm text-gray-400">Manage available credit packages for users</p>
              </div>
              <Button onClick={handleCreatePackage} className="bg-blue-600 hover:bg-blue-700">
                <Plus className="w-4 h-4 mr-2" />
                Create Package
              </Button>
            </div>

            <div className="bg-gray-900 rounded-lg border border-gray-700">
              <Table>
                <TableHeader>
                  <TableRow className="border-gray-700">
                    <TableHead className="text-gray-300">Package Name</TableHead>
                    <TableHead className="text-gray-300">Credits</TableHead>
                    <TableHead className="text-gray-300">Price</TableHead>
                    <TableHead className="text-gray-300">Discount</TableHead>
                    <TableHead className="text-gray-300">Status</TableHead>
                    <TableHead className="text-gray-300">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {creditPackages.map((pkg) => (
                    <TableRow key={pkg.id} className="border-gray-700">
                      <TableCell className="text-white font-medium">{pkg.name}</TableCell>
                      <TableCell className="text-gray-300">{pkg.credits.toLocaleString()}</TableCell>
                      <TableCell className="text-gray-300">€{(pkg.price_cents / 100).toFixed(2)}</TableCell>
                      <TableCell className="text-gray-300">
                        {pkg.discount_percentage ? `${pkg.discount_percentage}%` : 'None'}
                      </TableCell>
                      <TableCell>
                        <Badge variant={pkg.is_active ? "default" : "secondary"}>
                          {pkg.is_active ? 'Active' : 'Inactive'}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleEditPackage(pkg)}
                            className="text-blue-400 hover:text-blue-300 hover:bg-blue-900/20"
                          >
                            <Edit2 className="w-4 h-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleDeletePackage(pkg)}
                            className="text-red-400 hover:text-red-300 hover:bg-red-900/20"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
              
              {creditPackages.length === 0 && (
                <div className="p-8 text-center text-gray-400">
                  <Package className="w-12 h-12 mx-auto mb-4 opacity-50" />
                  <p>No credit packages found</p>
                  <p className="text-sm">Create your first package to get started</p>
                </div>
              )}
            </div>
          </TabsContent>

        {/* Analytics Tab */}
        <TabsContent value="analytics" className="space-y-4">
          <div className="flex justify-between items-center mb-6">
            <div>
              <h3 className="text-lg font-semibold text-white">Comprehensive Analytics</h3>
              <p className="text-sm text-gray-400">Revenue tracking, usage patterns, and pricing insights</p>
            </div>
            <div className="flex gap-2">
              <Button 
                onClick={() => setShowBulkUpdateDialog(true)}
                className="bg-purple-600 hover:bg-purple-700"
              >
                <Settings className="w-4 h-4 mr-2" />
                Bulk Operations
              </Button>
              <Button 
                onClick={() => {
                  setShowAuditLogDialog(true);
                  loadAuditLog();
                }}
                variant="outline"
                className="border-gray-600 text-gray-300 hover:bg-gray-700"
              >
                <TrendingUp className="w-4 h-4 mr-2" />
                Audit Log
              </Button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
            <Card className="bg-gray-800/50 border-gray-700">
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between">
                  <CardDescription className="text-gray-400">Total Revenue</CardDescription>
                  <TrendingUp className="h-4 w-4 text-green-400" />
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-white">
                  €{comprehensiveAnalytics?.total_revenue?.toFixed(2) || '0.00'}
                </div>
                <p className="text-xs text-gray-400">+{comprehensiveAnalytics?.revenue_growth_percentage?.toFixed(1) || '0'}% from last month</p>
              </CardContent>
            </Card>
            
            <Card className="bg-gray-800/50 border-gray-700">
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between">
                  <CardDescription className="text-gray-400">Credits Consumed</CardDescription>
                  <CreditCard className="h-4 w-4 text-blue-400" />
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-white">
                  {comprehensiveAnalytics?.total_credits_consumed?.toLocaleString() || '0'}
                </div>
                <p className="text-xs text-gray-400">Across all components</p>
              </CardContent>
            </Card>
            
            <Card className="bg-gray-800/50 border-gray-700">
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between">
                  <CardDescription className="text-gray-400">Active Users</CardDescription>
                  <Users className="h-4 w-4 text-purple-400" />
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-white">
                  {comprehensiveAnalytics?.active_users || '0'}
                </div>
                <p className="text-xs text-gray-400">+{comprehensiveAnalytics?.user_growth_percentage?.toFixed(1) || '0'}% from last month</p>
              </CardContent>
            </Card>

            <Card className="bg-gray-800/50 border-gray-700">
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between">
                  <CardDescription className="text-gray-400">Avg. Cost per User</CardDescription>
                  <Euro className="h-4 w-4 text-yellow-400" />
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-white">
                  €{comprehensiveAnalytics?.avg_cost_per_user?.toFixed(2) || '0.00'}
                </div>
                <p className="text-xs text-gray-400">Per active user</p>
              </CardContent>
            </Card>
          </div>

          {/* Component Usage Analytics */}
          <Card className="bg-gray-800/50 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white">Component Usage & Revenue</CardTitle>
              <CardDescription className="text-gray-400">
                Breakdown by component and pricing tier
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow className="border-gray-700">
                    <TableHead className="text-gray-300">Component</TableHead>
                    <TableHead className="text-gray-300">Usage Count</TableHead>
                    <TableHead className="text-gray-300">Credits Consumed</TableHead>
                    <TableHead className="text-gray-300">Revenue</TableHead>
                    <TableHead className="text-gray-300">Avg. Cost</TableHead>
                    <TableHead className="text-gray-300">Growth</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {comprehensiveAnalytics?.component_analytics?.map((component: any, index: number) => (
                    <TableRow key={index} className="border-gray-700">
                      <TableCell className="text-white font-medium">{component.component_name}</TableCell>
                      <TableCell className="text-gray-300">{component.usage_count?.toLocaleString()}</TableCell>
                      <TableCell className="text-gray-300">{component.credits_consumed?.toLocaleString()}</TableCell>
                      <TableCell className="text-gray-300">€{component.revenue?.toFixed(2)}</TableCell>
                      <TableCell className="text-gray-300">{component.avg_credit_cost?.toFixed(1)} credits</TableCell>
                      <TableCell>
                        <span className={`text-sm font-medium ${
                          (component.growth_percentage || 0) >= 0 ? 'text-green-400' : 'text-red-400'
                        }`}>
                          {(component.growth_percentage || 0) >= 0 ? '+' : ''}{component.growth_percentage?.toFixed(1) || '0'}%
                        </span>
                      </TableCell>
                    </TableRow>
                  )) || (
                    <TableRow className="border-gray-700">
                      <TableCell colSpan={6} className="text-center text-gray-400 py-8">
                        No analytics data available
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>

          {/* Legacy Analytics Table */}
          <Card className="bg-gray-800/50 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white">Pricing Configuration Analytics</CardTitle>
              <CardDescription className="text-gray-400">
                Legacy pricing tier analysis
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow className="border-gray-700">
                    <TableHead className="text-gray-300">Pricing Tier</TableHead>
                    <TableHead className="text-gray-300">Premium</TableHead>
                    <TableHead className="text-gray-300">Documents</TableHead>
                    <TableHead className="text-gray-300">Avg Cost</TableHead>
                    <TableHead className="text-gray-300">Min Cost</TableHead>
                    <TableHead className="text-gray-300">Max Cost</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {pricingAnalytics.map((analytics, index) => (
                    <TableRow key={index} className="border-gray-700">
                      <TableCell className="text-white font-medium">{analytics.pricing_tier || 'Standard'}</TableCell>
                      <TableCell>
                        <Badge variant={analytics.is_premium ? "default" : "secondary"} className={analytics.is_premium ? "bg-yellow-600" : "bg-gray-600"}>
                          {analytics.is_premium ? 'Premium' : 'Standard'}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-gray-300">{analytics.document_count}</TableCell>
                      <TableCell className="text-gray-300">
                        {analytics.avg_credit_cost ? `${analytics.avg_credit_cost.toFixed(2)} credits` : 'N/A'}
                      </TableCell>
                      <TableCell className="text-gray-300">{analytics.min_credit_cost} credits</TableCell>
                      <TableCell className="text-gray-300">{analytics.max_credit_cost} credits</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Credit Package Dialog */}
      <Dialog open={showPackageDialog} onOpenChange={setShowPackageDialog}>
        <DialogContent className="bg-gray-900 border-gray-700 text-white max-w-md">
          <DialogHeader>
            <DialogTitle className="text-white">
              {editingPackage ? 'Edit Credit Package' : 'Create Credit Package'}
            </DialogTitle>
            <DialogDescription className="text-gray-400">
              {editingPackage ? 'Update the credit package details' : 'Create a new credit package for users to purchase'}
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            <div>
              <Label htmlFor="package-name" className="text-gray-300">Package Name</Label>
              <Input
                id="package-name"
                value={packageForm.name}
                onChange={(e) => setPackageForm(prev => ({ ...prev, name: e.target.value }))}
                placeholder="i.e., Starter Pack, Professional, Enterprise"
                className="bg-gray-800 border-gray-600 text-white placeholder-gray-400"
              />
            </div>
            
            <div>
              <Label htmlFor="package-credits" className="text-gray-300">Credits</Label>
              <Input
                id="package-credits"
                type="number"
                value={packageForm.credits}
                onChange={(e) => setPackageForm(prev => ({ ...prev, credits: parseInt(e.target.value) || 0 }))}
                placeholder="i.e., 100, 500, 1000"
                className="bg-gray-800 border-gray-600 text-white placeholder-gray-400"
              />
            </div>
            
            <div>
              <Label htmlFor="package-price" className="text-gray-300">Price (EUR)</Label>
              <Input
                id="package-price"
                type="number"
                step="0.01"
                value={packageForm.price_cents / 100}
                onChange={(e) => setPackageForm(prev => ({ ...prev, price_cents: Math.round(parseFloat(e.target.value) * 100) || 0 }))}
                placeholder="e.g., 9.99, 49.99, 199.99"
                className="bg-gray-800 border-gray-600 text-white placeholder-gray-400"
              />
            </div>
            
            <div>
              <Label htmlFor="package-discount" className="text-gray-300">Discount Percentage (Optional)</Label>
              <Input
                id="package-discount"
                type="number"
                min="0"
                max="100"
                value={packageForm.discount_percentage}
                onChange={(e) => setPackageForm(prev => ({ ...prev, discount_percentage: parseInt(e.target.value) || 0 }))}
                placeholder="i.e., 10, 20, 50"
                className="bg-gray-800 border-gray-600 text-white placeholder-gray-400"
              />
            </div>
            
            <div>
              <Label htmlFor="package-expiry" className="text-gray-300">Expiry Period (Months)</Label>
              <Input
                id="package-expiry"
                type="number"
                min="1"
                max="120"
                value={packageForm.expiry_months}
                onChange={(e) => setPackageForm(prev => ({ ...prev, expiry_months: parseInt(e.target.value) || 12 }))}
                placeholder="i.e., 12, 24, 36"
                className="bg-gray-800 border-gray-600 text-white placeholder-gray-400"
              />
              <p className="text-xs text-gray-500 mt-1">
                Credits will expire {packageForm.expiry_months} months after purchase
              </p>
            </div>
            
            <div className="flex items-center space-x-2">
              <Checkbox
                id="package-active"
                checked={packageForm.is_active}
                onCheckedChange={(checked) => setPackageForm(prev => ({ ...prev, is_active: !!checked }))}
                className="border-gray-600"
              />
              <Label htmlFor="package-active" className="text-gray-300">Package is active</Label>
            </div>
            
            {packageForm.credits > 0 && packageForm.price_cents > 0 && (
              <div className="bg-gray-800/50 p-3 rounded-lg border border-gray-600">
                <div className="text-sm text-gray-400">Price per credit:</div>
                <div className="text-lg font-bold text-white">
                  €{((packageForm.price_cents / 100) / packageForm.credits).toFixed(4)}
                </div>
              </div>
            )}
          </div>
          
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setShowPackageDialog(false)}
              className="border-gray-600 text-gray-300 hover:bg-gray-700"
            >
              Cancel
            </Button>
            <Button
              onClick={handleSavePackage}
              disabled={!packageForm.name || packageForm.credits <= 0 || packageForm.price_cents <= 0}
              className="bg-blue-600 hover:bg-blue-700"
            >
              {editingPackage ? 'Update Package' : 'Create Package'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Bulk Operations Dialog */}
      <Dialog open={showBulkUpdateDialog} onOpenChange={setShowBulkUpdateDialog}>
        <DialogContent className="bg-gray-900 border-gray-700 text-white max-w-2xl">
          <DialogHeader>
            <DialogTitle className="text-white flex items-center gap-2">
              <Settings className="h-5 w-5 text-purple-400" />
              Bulk Pricing Operations
            </DialogTitle>
            <DialogDescription className="text-gray-400">
              Apply pricing changes across multiple components and actions
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-6">
            <div className="grid grid-cols-2 gap-4">
              <Button
                onClick={() => {
                  setBulkUpdates([
                    { type: 'percentage_increase', value: 10, scope: 'all' },
                    { type: 'minimum_cost', value: 1, scope: 'all' }
                  ]);
                }}
                className="bg-blue-600 hover:bg-blue-700 text-left flex-col h-auto p-4"
              >
                <div className="font-semibold">Apply 10% Increase</div>
                <div className="text-xs opacity-75">Increase all pricing by 10%</div>
              </Button>
              
              <Button
                onClick={() => {
                  setBulkUpdates([
                    { type: 'set_minimum', value: 2, scope: 'all' }
                  ]);
                }}
                className="bg-green-600 hover:bg-green-700 text-left flex-col h-auto p-4"
              >
                <div className="font-semibold">Set Minimum 2 Credits</div>
                <div className="text-xs opacity-75">Ensure all actions cost at least 2 credits</div>
              </Button>
              
              <Button
                onClick={() => {
                  setBulkUpdates([
                    { type: 'premium_multiplier', value: 1.5, scope: 'premium_only' }
                  ]);
                }}
                className="bg-yellow-600 hover:bg-yellow-700 text-left flex-col h-auto p-4"
              >
                <div className="font-semibold">Premium 1.5x Multiplier</div>
                <div className="text-xs opacity-75">Apply 1.5x multiplier to premium features</div>
              </Button>
              
              <Button
                onClick={() => {
                  setBulkUpdates([
                    { type: 'emergency_override', value: 0, scope: 'all', reason: 'Emergency free access' }
                  ]);
                }}
                variant="destructive"
                className="text-left flex-col h-auto p-4"
              >
                <div className="font-semibold">Emergency Free Access</div>
                <div className="text-xs opacity-75">Set all pricing to 0 credits</div>
              </Button>
            </div>
            
            {bulkUpdates.length > 0 && (
              <div className="bg-gray-800/50 p-4 rounded-lg border border-gray-600">
                <h4 className="text-white font-medium mb-2">Queued Operations:</h4>
                <div className="space-y-2">
                  {bulkUpdates.map((update, index) => (
                    <div key={index} className="text-sm text-gray-300 bg-gray-700/50 p-2 rounded">
                      <span className="font-medium">{update.type.replace('_', ' ').toUpperCase()}:</span> {update.value} 
                      <span className="text-gray-400">({update.scope})</span>
                      {update.reason && <span className="text-yellow-400"> - {update.reason}</span>}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
          
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                setShowBulkUpdateDialog(false);
                setBulkUpdates([]);
              }}
              className="border-gray-600 text-gray-300 hover:bg-gray-700"
            >
              Cancel
            </Button>
            <Button
              onClick={performBulkUpdate}
              disabled={bulkUpdates.length === 0}
              className="bg-purple-600 hover:bg-purple-700"
            >
              Apply Changes
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Audit Log Dialog */}
      <Dialog open={showAuditLogDialog} onOpenChange={setShowAuditLogDialog}>
        <DialogContent className="bg-gray-900 border-gray-700 text-white max-w-4xl max-h-[80vh]">
          <DialogHeader>
            <DialogTitle className="text-white flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-green-400" />
              Pricing Audit Log
            </DialogTitle>
            <DialogDescription className="text-gray-400">
              Track all pricing changes and administrative actions
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 max-h-96 overflow-y-auto">
            {auditLog.length > 0 ? (
              <Table>
                <TableHeader>
                  <TableRow className="border-gray-700">
                    <TableHead className="text-gray-300">Timestamp</TableHead>
                    <TableHead className="text-gray-300">Action</TableHead>
                    <TableHead className="text-gray-300">Component</TableHead>
                    <TableHead className="text-gray-300">Changes</TableHead>
                    <TableHead className="text-gray-300">User</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {auditLog.map((entry: any, index: number) => (
                    <TableRow key={index} className="border-gray-700">
                      <TableCell className="text-gray-300 text-sm">
                        {new Date(entry.timestamp).toLocaleString()}
                      </TableCell>
                      <TableCell className="text-white font-medium">{entry.action}</TableCell>
                      <TableCell className="text-gray-300">{entry.component_name || 'Global'}</TableCell>
                      <TableCell className="text-gray-300 max-w-xs truncate">
                        {entry.changes ? JSON.stringify(entry.changes) : entry.description}
                      </TableCell>
                      <TableCell className="text-gray-300">{entry.user_id || 'System'}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            ) : (
              <div className="text-center text-gray-400 py-8">
                <TrendingUp className="w-12 h-12 mx-auto mb-4 opacity-50" />
                <p>No audit log entries found</p>
                <p className="text-sm">Pricing changes will appear here</p>
              </div>
            )}
          </div>
          
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setShowAuditLogDialog(false)}
              className="border-gray-600 text-gray-300 hover:bg-gray-700"
            >
              Close
            </Button>
            <Button
              onClick={() => {
                // Export audit log functionality
                const dataStr = JSON.stringify(auditLog, null, 2);
                const dataBlob = new Blob([dataStr], { type: 'application/json' });
                const url = URL.createObjectURL(dataBlob);
                const link = document.createElement('a');
                link.href = url;
                link.download = `pricing-audit-log-${new Date().toISOString().split('T')[0]}.json`;
                link.click();
                URL.revokeObjectURL(url);
                toast.success('Audit log exported successfully');
              }}
              className="bg-blue-600 hover:bg-blue-700"
            >
              Export Log
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* New Pricing Configuration Dialog */}
      <Dialog open={showNewPricingDialog} onOpenChange={setShowNewPricingDialog}>
        <DialogContent className="bg-gray-900 border-gray-700 text-white max-w-md">
          <DialogHeader>
            <DialogTitle className="text-white">Create New Pricing Configuration</DialogTitle>
            <DialogDescription className="text-gray-400">
              Add pricing for a new component and action combination
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            <div>
              <Label htmlFor="component-name" className="text-gray-300">Component Name</Label>
              <Input
                id="component-name"
                value={newPricingForm.component_name}
                onChange={(e) => setNewPricingForm(prev => ({ ...prev, component_name: e.target.value }))}
                placeholder="e.g., knowledge_base, sanctions_screening"
                className="bg-gray-800 border-gray-600 text-white placeholder-gray-400"
              />
            </div>
            
            <div>
              <Label htmlFor="action-name" className="text-gray-300">Action Name</Label>
              <Input
                id="action-name"
                value={newPricingForm.action_name}
                onChange={(e) => setNewPricingForm(prev => ({ ...prev, action_name: e.target.value }))}
                placeholder="e.g., view_document, perform_screening"
                className="bg-gray-800 border-gray-600 text-white placeholder-gray-400"
              />
            </div>
            
            <div>
              <Label htmlFor="credit-cost" className="text-gray-300">Credit Cost</Label>
              <Input
                id="credit-cost"
                type="number"
                min="0"
                value={newPricingForm.credit_cost}
                onChange={(e) => setNewPricingForm(prev => ({ ...prev, credit_cost: parseInt(e.target.value) || 0 }))}
                placeholder="e.g., 1, 2, 5"
                className="bg-gray-800 border-gray-600 text-white placeholder-gray-400"
              />
            </div>
            
            <div>
              <Label htmlFor="effective-from" className="text-gray-300">Effective From</Label>
              <Input
                id="effective-from"
                type="date"
                value={newPricingForm.effective_from}
                onChange={(e) => setNewPricingForm(prev => ({ ...prev, effective_from: e.target.value }))}
                className="bg-gray-800 border-gray-600 text-white"
              />
            </div>
          </div>
          
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setShowNewPricingDialog(false)}
              className="border-gray-600 text-gray-300 hover:bg-gray-700"
            >
              Cancel
            </Button>
            <Button
              onClick={createNewPricing}
              disabled={!newPricingForm.component_name || !newPricingForm.action_name || newPricingForm.credit_cost <= 0}
              className="bg-green-600 hover:bg-green-700"
            >
              Create Pricing
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Credit Adjustment Dialog */}
      <Dialog open={showCreditAdjustDialog} onOpenChange={setShowCreditAdjustDialog}>
        <DialogContent className="bg-gray-900 border-gray-700 text-white max-w-md">
          <DialogHeader>
            <DialogTitle className="text-white">Adjust User Credits</DialogTitle>
            <DialogDescription className="text-gray-400">
              Manually adjust credits for a specific user account
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            <div>
              <Label htmlFor="user-id" className="text-gray-300">User ID</Label>
              <Input
                id="user-id"
                value={creditAdjustForm.user_id}
                onChange={(e) => setCreditAdjustForm(prev => ({ ...prev, user_id: e.target.value }))}
                placeholder="Enter user ID"
                className="bg-gray-800 border-gray-600 text-white placeholder-gray-400"
              />
            </div>
            
            <div>
              <Label htmlFor="credit-amount" className="text-gray-300">Credit Amount</Label>
              <Input
                id="credit-amount"
                type="number"
                value={creditAdjustForm.amount}
                onChange={(e) => setCreditAdjustForm(prev => ({ ...prev, amount: parseInt(e.target.value) || 0 }))}
                placeholder="Positive to add, negative to subtract"
                className="bg-gray-800 border-gray-600 text-white placeholder-gray-400"
              />
            </div>
            
            <div>
              <Label htmlFor="adjustment-reason" className="text-gray-300">Reason</Label>
              <Input
                id="adjustment-reason"
                value={creditAdjustForm.reason}
                onChange={(e) => setCreditAdjustForm(prev => ({ ...prev, reason: e.target.value }))}
                placeholder="e.g., Refund, Bonus credits, Error correction"
                className="bg-gray-800 border-gray-600 text-white placeholder-gray-400"
              />
            </div>
          </div>
          
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setShowCreditAdjustDialog(false)}
              className="border-gray-600 text-gray-300 hover:bg-gray-700"
            >
              Cancel
            </Button>
            <Button
              onClick={adjustUserCredits}
              disabled={!creditAdjustForm.user_id || creditAdjustForm.amount === 0 || !creditAdjustForm.reason}
              className="bg-orange-600 hover:bg-orange-700"
            >
              Adjust Credits
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Module Access Pricing Dialog */}
      <Dialog open={showModulePricingDialog} onOpenChange={setShowModulePricingDialog}>
        <DialogContent className="bg-gray-900 border-gray-700 text-white max-w-md">
          <DialogHeader>
            <DialogTitle className="text-white">Add Module Pricing</DialogTitle>
            <DialogDescription className="text-gray-400">
              Configure pricing for a new module
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            <div>
              <Label htmlFor="module-name" className="text-gray-300">Module Name</Label>
              <Input
                id="module-name"
                value={newModulePricingForm.module_name}
                onChange={(e) => setNewModulePricingForm(prev => ({ ...prev, module_name: e.target.value }))}
                placeholder="Enter module name"
                className="bg-gray-800 border-gray-600 text-white placeholder-gray-400"
              />
            </div>
            
            <div>
              <Label htmlFor="module-title" className="text-gray-300">Module Title</Label>
              <Input
                id="module-title"
                value={newModulePricingForm.module_title}
                onChange={(e) => setNewModulePricingForm(prev => ({ ...prev, module_title: e.target.value }))}
                placeholder="Enter module title"
                className="bg-gray-800 border-gray-600 text-white placeholder-gray-400"
              />
            </div>
            
            <div>
              <Label htmlFor="module-type" className="text-gray-300">Module Type</Label>
              <Select
                id="module-type"
                value={newModulePricingForm.pricing_type}
                onChange={(e) => setNewModulePricingForm(prev => ({ ...prev, pricing_type: e.target.value }))}
                className="bg-gray-800 border-gray-600 text-white placeholder-gray-400"
              >
                <SelectItem value="credits">Credits</SelectItem>
                <SelectItem value="eur">EUR</SelectItem>
              </Select>
            </div>
            
            <div>
              <Label htmlFor="module-cost" className="text-gray-300">Module Cost</Label>
              <Input
                id="module-cost"
                type="number"
                value={newModulePricingForm.credit_cost}
                onChange={(e) => setNewModulePricingForm(prev => ({ ...prev, credit_cost: parseInt(e.target.value) || 0 }))}
                placeholder="Enter module cost"
                className="bg-gray-800 border-gray-600 text-white placeholder-gray-400"
              />
            </div>
            
            <div>
              <Label htmlFor="module-status" className="text-gray-300">Module Status</Label>
              <Select
                id="module-status"
                value={newModulePricingForm.is_active}
                onChange={(e) => setNewModulePricingForm(prev => ({ ...prev, is_active: !!e.target.value }))}
                className="bg-gray-800 border-gray-600 text-white placeholder-gray-400"
              >
                <SelectItem value="true">Active</SelectItem>
                <SelectItem value="false">Inactive</SelectItem>
              </Select>
            </div>
            
            <div>
              <Label htmlFor="module-description" className="text-gray-300">Module Description</Label>
              <Input
                id="module-description"
                value={newModulePricingForm.description}
                onChange={(e) => setNewModulePricingForm(prev => ({ ...prev, description: e.target.value }))}
                placeholder="Enter module description"
                className="bg-gray-800 border-gray-600 text-white placeholder-gray-400"
              />
            </div>
          </div>
          
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setShowModulePricingDialog(false)}
              className="border-gray-600 text-gray-300 hover:bg-gray-700"
            >
              Cancel
            </Button>
            <Button
              onClick={() => {
                if (newModulePricingForm) {
                  setModulePricing(prev => [...prev, newModulePricingForm]);
                  setShowModulePricingDialog(false);
                }
              }}
              disabled={!newModulePricingForm.module_name || !newModulePricingForm.module_title || !newModulePricingForm.pricing_type || (newModulePricingForm.pricing_type === 'credits' && !newModulePricingForm.credit_cost) || (newModulePricingForm.pricing_type === 'eur' && !newModulePricingForm.price_eur)}
              className="bg-purple-600 hover:bg-purple-700"
            >
              {editingModulePricing ? 'Update Module Pricing' : 'Add Module Pricing'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export { AdminPricingControl };
