import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { MessageCircle, Send, User, Calendar, Heart, Reply } from 'lucide-react';
import { useUserGuardContext } from 'app/auth';
import { format } from 'date-fns';
import { toast } from 'sonner';

interface Comment {
  id: string;
  author_name: string;
  author_email: string;
  content: string;
  created_at: string;
  reply_to?: string;
  likes_count: number;
  is_approved: boolean;
}

interface BlogCommentsProps {
  contentId: string;
  contentTitle: string;
}

export default function BlogComments({ contentId, contentTitle }: BlogCommentsProps) {
  const { user } = useUserGuardContext();
  const [comments, setComments] = useState<Comment[]>([]);
  const [newComment, setNewComment] = useState('');
  const [loading, setLoading] = useState(false);
  const [showCommentForm, setShowCommentForm] = useState(false);
  const [replyTo, setReplyTo] = useState<string | null>(null);
  const [userName, setUserName] = useState(user?.displayName || '');
  const [userEmail, setUserEmail] = useState(user?.primaryEmail || '');

  // Mock comments for now since we don't have a comments API
  useEffect(() => {
    // In a real implementation, you would fetch comments from an API
    const mockComments: Comment[] = [
      {
        id: '1',
        author_name: 'John Smith',
        author_email: 'john@example.com',
        content: 'Great article! Very informative and well-written. The insights on compliance regulations are particularly helpful.',
        created_at: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
        likes_count: 3,
        is_approved: true
      },
      {
        id: '2',
        author_name: 'Sarah Johnson',
        author_email: 'sarah@example.com',
        content: 'Thank you for sharing this. I have been looking for exactly this kind of information for my compliance work.',
        created_at: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(),
        likes_count: 1,
        is_approved: true
      }
    ];
    
    setComments(mockComments);
  }, [contentId]);

  const handleSubmitComment = async () => {
    if (!newComment.trim() || !userName.trim() || !userEmail.trim()) {
      toast.error('Please fill in all fields');
      return;
    }

    setLoading(true);
    try {
      // In a real implementation, you would submit to an API
      const comment: Comment = {
        id: Date.now().toString(),
        author_name: userName,
        author_email: userEmail,
        content: newComment,
        created_at: new Date().toISOString(),
        reply_to: replyTo || undefined,
        likes_count: 0,
        is_approved: false // Comments would need approval in a real system
      };

      // Add to local state (in real implementation, refresh from API)
      setComments(prev => [comment, ...prev]);
      setNewComment('');
      setReplyTo(null);
      setShowCommentForm(false);
      
      toast.success('Comment submitted! It will be visible after moderation.');
    } catch (error) {
      console.error('Error submitting comment:', error);
      toast.error('Failed to submit comment');
    } finally {
      setLoading(false);
    }
  };

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(n => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  const approvedComments = comments.filter(c => c.is_approved);
  const pendingComments = comments.filter(c => !c.is_approved && c.author_email === userEmail);

  return (
    <div className="space-y-6">
      {/* Comments Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <MessageCircle className="w-5 h-5 text-blue-600" />
          <h3 className="text-lg font-semibold text-gray-900">
            Comments ({approvedComments.length})
          </h3>
        </div>
        
        {!showCommentForm && (
          <Button 
            onClick={() => setShowCommentForm(true)}
            variant="outline"
            className="flex items-center gap-2"
          >
            <MessageCircle className="w-4 h-4" />
            Add Comment
          </Button>
        )}
      </div>

      {/* Comment Form */}
      {showCommentForm && (
        <Card className="border-blue-200">
          <CardHeader>
            <CardTitle className="text-base">
              {replyTo ? 'Reply to Comment' : 'Add a Comment'}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Input
                placeholder="Your name"
                value={userName}
                onChange={(e) => setUserName(e.target.value)}
                className="border-gray-300"
              />
              <Input
                type="email"
                placeholder="Your email"
                value={userEmail}
                onChange={(e) => setUserEmail(e.target.value)}
                className="border-gray-300"
              />
            </div>
            
            <Textarea
              placeholder="Share your thoughts on this article..."
              value={newComment}
              onChange={(e) => setNewComment(e.target.value)}
              rows={4}
              className="border-gray-300"
            />
            
            <div className="flex justify-between items-center">
              <p className="text-sm text-gray-500">
                Comments are moderated and will be published after review.
              </p>
              
              <div className="flex gap-2">
                <Button 
                  variant="outline" 
                  onClick={() => {
                    setShowCommentForm(false);
                    setReplyTo(null);
                    setNewComment('');
                  }}
                >
                  Cancel
                </Button>
                <Button 
                  onClick={handleSubmitComment}
                  disabled={loading || !newComment.trim()}
                  className="flex items-center gap-2"
                >
                  {loading ? (
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  ) : (
                    <Send className="w-4 h-4" />
                  )}
                  Submit Comment
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Pending Comments Notice */}
      {pendingComments.length > 0 && (
        <Card className="border-amber-200 bg-amber-50">
          <CardContent className="pt-4">
            <div className="flex items-center gap-2 text-amber-800">
              <Calendar className="w-4 h-4" />
              <span className="text-sm font-medium">
                You have {pendingComments.length} comment{pendingComments.length !== 1 ? 's' : ''} pending moderation.
              </span>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Comments List */}
      <div className="space-y-4">
        {approvedComments.length === 0 ? (
          <Card>
            <CardContent className="pt-8 pb-8 text-center">
              <MessageCircle className="w-12 h-12 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-500 mb-4">No comments yet. Be the first to share your thoughts!</p>
              {!showCommentForm && (
                <Button 
                  onClick={() => setShowCommentForm(true)}
                  className="flex items-center gap-2 mx-auto"
                >
                  <MessageCircle className="w-4 h-4" />
                  Start the Discussion
                </Button>
              )}
            </CardContent>
          </Card>
        ) : (
          approvedComments.map((comment, index) => (
            <div key={comment.id}>
              <Card className="hover:shadow-md transition-shadow">
                <CardContent className="pt-4">
                  <div className="flex gap-4">
                    <Avatar className="w-10 h-10">
                      <AvatarImage src={`https://api.dicebear.com/7.x/initials/svg?seed=${comment.author_name}`} />
                      <AvatarFallback className="bg-blue-100 text-blue-600">
                        {getInitials(comment.author_name)}
                      </AvatarFallback>
                    </Avatar>
                    
                    <div className="flex-1 space-y-2">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-medium text-gray-900">{comment.author_name}</span>
                        <span className="text-gray-400">•</span>
                        <span className="text-sm text-gray-500">
                          {format(new Date(comment.created_at), 'MMM dd, yyyy')}
                        </span>
                        {comment.reply_to && (
                          <Badge variant="secondary" className="text-xs">
                            <Reply className="w-3 h-3 mr-1" />
                            Reply
                          </Badge>
                        )}
                      </div>
                      
                      <p className="text-gray-700 leading-relaxed">{comment.content}</p>
                      
                      <div className="flex items-center gap-4 pt-2">
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="text-gray-500 hover:text-red-500 flex items-center gap-1"
                        >
                          <Heart className="w-4 h-4" />
                          {comment.likes_count > 0 && <span>{comment.likes_count}</span>}
                        </Button>
                        
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="text-gray-500 hover:text-blue-500 flex items-center gap-1"
                          onClick={() => {
                            setReplyTo(comment.id);
                            setShowCommentForm(true);
                          }}
                        >
                          <Reply className="w-4 h-4" />
                          Reply
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              {index < approvedComments.length - 1 && <Separator className="my-4" />}
            </div>
          ))
        )}
      </div>

      {approvedComments.length > 0 && (
        <div className="text-center pt-4">
          <p className="text-sm text-gray-500">
            Thank you for engaging with our content! Your feedback helps us improve.
          </p>
        </div>
      )}
    </div>
  );
}
