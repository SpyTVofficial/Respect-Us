import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Search, Zap } from "lucide-react";
import AdvancedSearchDialog from "./AdvancedSearchDialog";
import { DocumentResponse, DocumentSearchRequest } from '../brain/data-contracts';

interface Props {
  onSearchResults: (results: DocumentResponse[], searchRequest: DocumentSearchRequest) => void;
  className?: string;
}

export default function AdvancedSearchButton({ onSearchResults, className }: Props) {
  const [showDialog, setShowDialog] = useState(false);

  return (
    <>
      <Button
        onClick={() => setShowDialog(true)}
        className={`bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white shadow-lg ${className}`}
      >
        <Zap className="h-4 w-4 mr-2" />
        Advanced Search
      </Button>
      
      <AdvancedSearchDialog
        open={showDialog}
        onClose={() => setShowDialog(false)}
        onSearchResults={onSearchResults}
      />
    </>
  );
}
