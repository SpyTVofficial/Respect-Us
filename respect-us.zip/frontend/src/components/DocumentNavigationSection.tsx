import React from 'react';
import { Button } from '@/components/ui/button';
import { Map, FileText, ArrowRight, ChevronRight } from 'lucide-react';

interface Props {
  onBrowseByJurisdiction: () => void;
  onViewAllDocuments: () => void;
}

export const DocumentNavigationSection: React.FC<Props> = ({
  onBrowseByJurisdiction,
  onViewAllDocuments
}) => {
  return (
    <div className="bg-gradient-to-r from-primary/5 to-primary/10 dark:from-primary/10 dark:to-primary/20 rounded-xl p-8 border border-primary/20 shadow-lg">
      <div className="text-center space-y-6">
        <div className="space-y-2">
          <h2 className="text-3xl font-bold text-gray-900 dark:text-gray-100">Explore Our Document Repository</h2>
          <p className="text-lg text-gray-600 dark:text-gray-400 max-w-2xl mx-auto">
            Access comprehensive regulatory intelligence through our organized collection of compliance documents
          </p>
        </div>
        
        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
          <Button 
            size="lg" 
            className="px-8 py-6 text-lg font-semibold bg-primary hover:bg-primary/90 shadow-lg hover:shadow-xl transition-all duration-300 group"
            onClick={onBrowseByJurisdiction}
          >
            <Map className="mr-3 h-5 w-5 group-hover:scale-110 transition-transform" />
            Browse by Jurisdiction
            <ChevronRight className="ml-3 h-5 w-5 group-hover:translate-x-1 transition-transform" />
          </Button>
          
          <div className="text-gray-400 font-medium">OR</div>
          
          <Button 
            variant="outline" 
            size="lg" 
            className="px-8 py-6 text-lg font-semibold border-2 hover:bg-primary/5 hover:border-primary/30 shadow-md hover:shadow-lg transition-all duration-300 group"
            onClick={onViewAllDocuments}
          >
            <FileText className="mr-3 h-5 w-5 group-hover:scale-110 transition-transform" />
            View All Documents
            <ArrowRight className="ml-3 h-5 w-5 group-hover:translate-x-1 transition-transform" />
          </Button>
        </div>
        
        <div className="flex justify-center items-center gap-8 text-sm text-gray-500 dark:text-gray-400">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
            <span>Live Updates</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 bg-blue-500 rounded-full animate-pulse"></div>
            <span>Expert Curated</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 bg-purple-500 rounded-full animate-pulse"></div>
            <span>Always Current</span>
          </div>
        </div>
      </div>
    </div>
  );
};
