import React from 'react';
import {
  Document,
  Page,
  Text,
  View,
  StyleSheet,
  Font,
  Image
} from '@react-pdf/renderer';
import { CustomerProfile, ScreeningResult, ScreeningMatch } from 'brain/data-contracts';

// Define styles for the PDF report
const styles = StyleSheet.create({
  page: {
    flexDirection: 'column',
    backgroundColor: '#FFFFFF',
    padding: 40,
    fontFamily: 'Helvetica'
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 30,
    paddingBottom: 20,
    borderBottom: '2px solid #E5E7EB'
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#1F2937'
  },
  subtitle: {
    fontSize: 12,
    color: '#6B7280',
    marginTop: 4
  },
  logo: {
    width: 120,
    height: 40
  },
  section: {
    marginBottom: 20
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#374151',
    marginBottom: 10,
    paddingBottom: 5,
    borderBottom: '1px solid #E5E7EB'
  },
  infoGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginBottom: 10
  },
  infoItem: {
    width: '50%',
    marginBottom: 8
  },
  label: {
    fontSize: 10,
    color: '#6B7280',
    fontWeight: 'bold'
  },
  value: {
    fontSize: 10,
    color: '#1F2937',
    marginTop: 2
  },
  riskBadge: {
    padding: '4 8',
    borderRadius: 4,
    fontSize: 10,
    fontWeight: 'bold',
    textAlign: 'center',
    minWidth: 60
  },
  riskCritical: {
    backgroundColor: '#FEE2E2',
    color: '#DC2626'
  },
  riskHigh: {
    backgroundColor: '#FEF3C7',
    color: '#D97706'
  },
  riskMedium: {
    backgroundColor: '#FEF9E7',
    color: '#CA8A04'
  },
  riskLow: {
    backgroundColor: '#ECFDF5',
    color: '#059669'
  },
  riskNone: {
    backgroundColor: '#F3F4F6',
    color: '#6B7280'
  },
  table: {
    display: 'flex',
    flexDirection: 'column',
    border: '1px solid #E5E7EB',
    borderRadius: 4
  },
  tableHeader: {
    flexDirection: 'row',
    backgroundColor: '#F9FAFB',
    borderBottom: '1px solid #E5E7EB',
    padding: 8
  },
  tableRow: {
    flexDirection: 'row',
    borderBottom: '1px solid #E5E7EB',
    padding: 8
  },
  tableCell: {
    fontSize: 9,
    color: '#374151',
    flex: 1,
    paddingRight: 8
  },
  tableCellHeader: {
    fontSize: 9,
    fontWeight: 'bold',
    color: '#1F2937',
    flex: 1,
    paddingRight: 8
  },
  summary: {
    backgroundColor: '#F9FAFB',
    padding: 15,
    borderRadius: 4,
    marginBottom: 20
  },
  summaryTitle: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#1F2937',
    marginBottom: 8
  },
  summaryText: {
    fontSize: 10,
    color: '#6B7280',
    lineHeight: 1.4
  },
  footer: {
    position: 'absolute',
    bottom: 30,
    left: 40,
    right: 40,
    fontSize: 8,
    color: '#6B7280',
    borderTop: '1px solid #E5E7EB',
    paddingTop: 10,
    textAlign: 'center'
  }
});

interface Props {
  customer: CustomerProfile;
  screening: ScreeningResult;
  matches?: ScreeningMatch[];
  generatedBy: string;
  reportId: string;
}

export const ScreeningReport: React.FC<Props> = ({
  customer,
  screening,
  matches = [],
  generatedBy,
  reportId
}) => {
  const getRiskStyle = (riskLevel: string) => {
    switch (riskLevel?.toLowerCase()) {
      case 'critical': return [styles.riskBadge, styles.riskCritical];
      case 'high': return [styles.riskBadge, styles.riskHigh];
      case 'medium': return [styles.riskBadge, styles.riskMedium];
      case 'low': return [styles.riskBadge, styles.riskLow];
      default: return [styles.riskBadge, styles.riskNone];
    }
  };

  const formatDate = (date: string | Date | undefined) => {
    if (!date) return 'N/A';
    return new Date(date).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getSummaryText = () => {
    if (screening.high_risk_matches > 0) {
      return `HIGH RISK: This customer has ${screening.high_risk_matches} high-risk matches and requires immediate review. Do not proceed with business relationship until matches are verified and appropriate due diligence is completed.`;
    } else if (screening.total_matches > 0) {
      return `POTENTIAL MATCHES: This customer has ${screening.total_matches} potential matches that require review. Verify matches before proceeding with business relationship.`;
    } else {
      return `CLEARED: No matches found in sanctions and watchlists. Customer cleared for business relationship based on current screening criteria.`;
    }
  };

  return (
    <Document>
      <Page size="A4" style={styles.page}>
        {/* Header */}
        <View style={styles.header}>
          <View>
            <Text style={styles.title}>Customer Screening Report</Text>
            <Text style={styles.subtitle}>Respectus Compliance Platform</Text>
          </View>
          <View>
            <Text style={[styles.subtitle, { textAlign: 'right' }]}>Report ID: {reportId}</Text>
            <Text style={[styles.subtitle, { textAlign: 'right' }]}>Generated: {formatDate(new Date())}</Text>
          </View>
        </View>

        {/* Executive Summary */}
        <View style={styles.summary}>
          <Text style={styles.summaryTitle}>Executive Summary</Text>
          <Text style={styles.summaryText}>{getSummaryText()}</Text>
        </View>

        {/* Customer Information */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Customer Information</Text>
          <View style={styles.infoGrid}>
            <View style={styles.infoItem}>
              <Text style={styles.label}>Customer Name</Text>
              <Text style={styles.value}>{customer.customer_name}</Text>
            </View>
            <View style={styles.infoItem}>
              <Text style={styles.label}>Customer Type</Text>
              <Text style={styles.value}>{customer.customer_type}</Text>
            </View>
            <View style={styles.infoItem}>
              <Text style={styles.label}>Legal Name</Text>
              <Text style={styles.value}>{customer.legal_name || 'N/A'}</Text>
            </View>
            <View style={styles.infoItem}>
              <Text style={styles.label}>Country</Text>
              <Text style={styles.value}>{customer.country || 'N/A'}</Text>
            </View>
            <View style={styles.infoItem}>
              <Text style={styles.label}>Risk Category</Text>
              <Text style={getRiskStyle(customer.risk_category)}>
                {customer.risk_category?.toUpperCase()}
              </Text>
            </View>
            <View style={styles.infoItem}>
              <Text style={styles.label}>Date of Birth</Text>
              <Text style={styles.value}>{customer.date_of_birth || 'N/A'}</Text>
            </View>
          </View>
        </View>

        {/* Screening Results */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Screening Results</Text>
          <View style={styles.infoGrid}>
            <View style={styles.infoItem}>
              <Text style={styles.label}>Screening Date</Text>
              <Text style={styles.value}>{formatDate(screening.screening_date)}</Text>
            </View>
            <View style={styles.infoItem}>
              <Text style={styles.label}>Risk Level</Text>
              <Text style={getRiskStyle(screening.risk_level)}>
                {screening.risk_level?.toUpperCase()}
              </Text>
            </View>
            <View style={styles.infoItem}>
              <Text style={styles.label}>Total Matches</Text>
              <Text style={styles.value}>{screening.total_matches}</Text>
            </View>
            <View style={styles.infoItem}>
              <Text style={styles.label}>High Risk Matches</Text>
              <Text style={styles.value}>{screening.high_risk_matches}</Text>
            </View>
            <View style={styles.infoItem}>
              <Text style={styles.label}>Risk Score</Text>
              <Text style={styles.value}>{(screening.overall_risk_score * 100).toFixed(1)}%</Text>
            </View>
            <View style={styles.infoItem}>
              <Text style={styles.label}>Screened By</Text>
              <Text style={styles.value}>{generatedBy}</Text>
            </View>
          </View>
        </View>

        {/* Matches Table */}
        {matches.length > 0 && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Match Details</Text>
            <View style={styles.table}>
              <View style={styles.tableHeader}>
                <Text style={styles.tableCellHeader}>Match Type</Text>
                <Text style={styles.tableCellHeader}>Matched Field</Text>
                <Text style={styles.tableCellHeader}>Matched Value</Text>
                <Text style={styles.tableCellHeader}>Score</Text>
                <Text style={styles.tableCellHeader}>Risk Level</Text>
                <Text style={styles.tableCellHeader}>Status</Text>
              </View>
              {matches.map((match, index) => (
                <View key={index} style={styles.tableRow}>
                  <Text style={styles.tableCell}>{match.match_type}</Text>
                  <Text style={styles.tableCell}>{match.matched_field}</Text>
                  <Text style={styles.tableCell}>{match.matched_value}</Text>
                  <Text style={styles.tableCell}>{(match.match_score * 100).toFixed(1)}%</Text>
                  <Text style={[styles.tableCell, getRiskStyle(match.risk_level)]}>
                    {match.risk_level?.toUpperCase()}
                  </Text>
                  <Text style={styles.tableCell}>
                    {match.is_false_positive || match.false_positive ? 'False Positive' :
                     match.verification_decision === 'match' ? 'Verified Match' :
                     match.verification_decision === 'no_match' ? 'No Match' : 'Pending Review'}
                  </Text>
                </View>
              ))}
            </View>
          </View>
        )}

        {/* Footer */}
        <Text style={styles.footer}>
          This report was generated by Respectus Compliance Platform on {formatDate(new Date())}.
          This document contains confidential information and should be handled according to your organization's data security policies.
        </Text>
      </Page>
    </Document>
  );
};

export default ScreeningReport;
