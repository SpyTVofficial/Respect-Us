import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Globe, Languages, CheckCircle, Clock, AlertCircle, Star,
  Download, Upload, Eye, MessageSquare, Sparkles
} from 'lucide-react';
import brain from 'brain';
import { MultilingualSupport as MultilingualSupportData, TranslationRequest } from 'types';
import { toast } from 'sonner';

interface Props {
  documentId: number;
  currentLanguage?: string;
  onLanguageChange?: (language: string) => void;
  embedded?: boolean; // For embedding in other components
}

interface SupportedLanguage {
  code: string;
  name: string;
  native_name: string;
}

interface TranslationStatus {
  document_id: number;
  target_language: string;
  status: string;
  estimated_completion: string;
  message: string;
}

export const MultilingualSupport: React.FC<Props> = ({ 
  documentId, 
  currentLanguage = 'en',
  onLanguageChange,
  embedded = false 
}) => {
  const [multilingualData, setMultilingualData] = useState<MultilingualSupportData | null>(null);
  const [supportedLanguages, setSupportedLanguages] = useState<SupportedLanguage[]>([]);
  const [loading, setLoading] = useState(true);
  const [translationLoading, setTranslationLoading] = useState(false);
  const [selectedTargetLanguage, setSelectedTargetLanguage] = useState<string>('');
  const [showTranslationDialog, setShowTranslationDialog] = useState(false);
  const [translationPriority, setTranslationPriority] = useState<'low' | 'normal' | 'high' | 'urgent'>('normal');
  const [autoTranslate, setAutoTranslate] = useState(true);

  const loadMultilingualData = async () => {
    try {
      setLoading(true);
      
      const [translationsRes, languagesRes] = await Promise.all([
        brain.get_document_translations({ documentId }),
        brain.get_supported_languages()
      ]);

      const [translations, languages] = await Promise.all([
        translationsRes.json(),
        languagesRes.json()
      ]);

      setMultilingualData(translations);
      setSupportedLanguages(languages.supported_languages || []);
      
    } catch (error) {
      console.error('Error loading multilingual data:', error);
      toast.error('Failed to load translation information');
    } finally {
      setLoading(false);
    }
  };

  const handleRequestTranslation = async () => {
    if (!selectedTargetLanguage) {
      toast.error('Please select a target language');
      return;
    }

    try {
      setTranslationLoading(true);

      const request: TranslationRequest = {
        document_id: documentId,
        target_language: selectedTargetLanguage,
        priority: translationPriority,
        auto_translate: autoTranslate
      };

      const response = await brain.request_translation(request);
      const result = await response.json();

      toast.success(`Translation request submitted for ${getLanguageName(selectedTargetLanguage)}`);
      setShowTranslationDialog(false);
      setSelectedTargetLanguage('');
      
      // Reload data to show updated status
      loadMultilingualData();
      
    } catch (error) {
      console.error('Error requesting translation:', error);
      toast.error('Failed to request translation');
    } finally {
      setTranslationLoading(false);
    }
  };

  const getLanguageName = (code: string): string => {
    const language = supportedLanguages.find(lang => lang.code === code);
    return language ? `${language.name} (${language.native_name})` : code.toUpperCase();
  };

  const getQualityColor = (score: number): string => {
    if (score >= 0.9) return 'text-green-400';
    if (score >= 0.8) return 'text-blue-400';
    if (score >= 0.7) return 'text-yellow-400';
    return 'text-red-400';
  };

  const getAvailableForTranslation = (): SupportedLanguage[] => {
    if (!multilingualData) return supportedLanguages;
    
    const availableCodes = [multilingualData.original_language, ...multilingualData.available_translations];
    return supportedLanguages.filter(lang => !availableCodes.includes(lang.code));
  };

  useEffect(() => {
    loadMultilingualData();
  }, [documentId]);

  if (loading) {
    return (
      <div className="flex items-center justify-center py-6">
        <div className="text-center">
          <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-primary mx-auto mb-2"></div>
          <p className="text-sm text-muted-foreground">Loading translations...</p>
        </div>
      </div>
    );
  }

  if (!multilingualData) {
    return (
      <div className="text-center py-6">
        <Languages className="h-8 w-8 text-muted-foreground mx-auto mb-2" />
        <p className="text-sm text-muted-foreground">Translation data unavailable</p>
      </div>
    );
  }

  const EmbeddedView = () => (
    <div className="space-y-4">
      {/* Language Selector */}
      <div className="flex items-center gap-3">
        <Globe className="h-4 w-4 text-blue-400" />
        <Select 
          value={currentLanguage} 
          onValueChange={onLanguageChange}
        >
          <SelectTrigger className="w-48">
            <SelectValue placeholder="Select language" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value={multilingualData.original_language}>
              <div className="flex items-center gap-2">
                <Badge variant="outline" className="text-green-400 border-green-400">Original</Badge>
                {getLanguageName(multilingualData.original_language)}
              </div>
            </SelectItem>
            {multilingualData.available_translations.map((langCode) => (
              <SelectItem key={langCode} value={langCode}>
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-3 w-3 text-green-400" />
                  {getLanguageName(langCode)}
                </div>
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        {/* Translation Quality Indicator */}
        {currentLanguage !== multilingualData.original_language && (
          <div className="flex items-center gap-1">
            <Star className={`h-4 w-4 ${getQualityColor(multilingualData.translation_quality_score)}`} />
            <span className={`text-sm ${getQualityColor(multilingualData.translation_quality_score)}`}>
              {(multilingualData.translation_quality_score * 100).toFixed(0)}%
            </span>
          </div>
        )}

        {/* Request Translation Button */}
        {getAvailableForTranslation().length > 0 && (
          <Dialog open={showTranslationDialog} onOpenChange={setShowTranslationDialog}>
            <DialogTrigger asChild>
              <Button variant="outline" size="sm">
                <Languages className="h-4 w-4 mr-2" />
                Request Translation
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Request Document Translation</DialogTitle>
                <DialogDescription>
                  Request a new translation for this regulatory document
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <label className="text-sm font-medium mb-2 block">Target Language</label>
                  <Select value={selectedTargetLanguage} onValueChange={setSelectedTargetLanguage}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select target language" />
                    </SelectTrigger>
                    <SelectContent>
                      {getAvailableForTranslation().map((lang) => (
                        <SelectItem key={lang.code} value={lang.code}>
                          {lang.name} ({lang.native_name})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="text-sm font-medium mb-2 block">Priority</label>
                  <Select value={translationPriority} onValueChange={(value: any) => setTranslationPriority(value)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">Low - Standard processing</SelectItem>
                      <SelectItem value="normal">Normal - 24-48 hours</SelectItem>
                      <SelectItem value="high">High - Next business day</SelectItem>
                      <SelectItem value="urgent">Urgent - Same day</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    id="auto-translate"
                    checked={autoTranslate}
                    onChange={(e) => setAutoTranslate(e.target.checked)}
                    className="rounded"
                  />
                  <label htmlFor="auto-translate" className="text-sm">
                    Enable automatic translation (faster, may require review)
                  </label>
                </div>

                <div className="flex gap-2 pt-4">
                  <Button 
                    onClick={handleRequestTranslation} 
                    disabled={translationLoading || !selectedTargetLanguage}
                    className="flex-1"
                  >
                    {translationLoading ? 'Requesting...' : 'Request Translation'}
                  </Button>
                  <Button 
                    variant="outline" 
                    onClick={() => setShowTranslationDialog(false)}
                  >
                    Cancel
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        )}
      </div>
    </div>
  );

  const FullView = () => (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Globe className="h-5 w-5 text-blue-500" />
          Multilingual Support
        </CardTitle>
        <CardDescription>
          Translation status and language options for this document
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <Tabs defaultValue="overview" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="translations">Translations</TabsTrigger>
            <TabsTrigger value="request">Request New</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Original Language */}
              <div className="p-4 bg-gray-800/30 rounded-lg">
                <div className="flex items-center gap-2 mb-2">
                  <Badge variant="outline" className="text-green-400 border-green-400">
                    Original
                  </Badge>
                  <span className="font-medium">{getLanguageName(multilingualData.original_language)}</span>
                </div>
                <p className="text-sm text-muted-foreground">Source document language</p>
              </div>

              {/* Translation Quality */}
              <div className="p-4 bg-gray-800/30 rounded-lg">
                <div className="flex items-center gap-2 mb-2">
                  <Star className={`h-4 w-4 ${getQualityColor(multilingualData.translation_quality_score)}`} />
                  <span className="font-medium">
                    {(multilingualData.translation_quality_score * 100).toFixed(0)}% Quality Score
                  </span>
                </div>
                <p className="text-sm text-muted-foreground">Average translation quality</p>
              </div>

              {/* Translation Status */}
              <div className="p-4 bg-gray-800/30 rounded-lg">
                <div className="flex items-center gap-2 mb-2">
                  {multilingualData.auto_translated ? (
                    <Sparkles className="h-4 w-4 text-blue-400" />
                  ) : (
                    <MessageSquare className="h-4 w-4 text-purple-400" />
                  )}
                  <span className="font-medium">
                    {multilingualData.auto_translated ? 'Auto-translated' : 'Manual translation'}
                  </span>
                </div>
                <p className="text-sm text-muted-foreground">
                  {multilingualData.human_reviewed ? 'Human reviewed' : 'Awaiting review'}
                </p>
              </div>

              {/* Last Updated */}
              <div className="p-4 bg-gray-800/30 rounded-lg">
                <div className="flex items-center gap-2 mb-2">
                  <Clock className="h-4 w-4 text-gray-400" />
                  <span className="font-medium">Last Updated</span>
                </div>
                <p className="text-sm text-muted-foreground">
                  {new Date(multilingualData.last_updated).toLocaleDateString()}
                </p>
              </div>
            </div>
          </TabsContent>

          {/* Translations Tab */}
          <TabsContent value="translations" className="space-y-4">
            <div className="space-y-3">
              {/* Original Language */}
              <div className="flex items-center justify-between p-3 bg-gray-800/30 rounded-lg">
                <div className="flex items-center gap-3">
                  <CheckCircle className="h-5 w-5 text-green-400" />
                  <div>
                    <p className="font-medium">{getLanguageName(multilingualData.original_language)}</p>
                    <p className="text-xs text-muted-foreground">Original document</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant="outline" className="text-green-400 border-green-400">Original</Badge>
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => onLanguageChange?.(multilingualData.original_language)}
                  >
                    <Eye className="h-3 w-3 mr-1" />
                    View
                  </Button>
                </div>
              </div>

              {/* Available Translations */}
              {multilingualData.available_translations.map((langCode) => (
                <div key={langCode} className="flex items-center justify-between p-3 bg-gray-800/30 rounded-lg">
                  <div className="flex items-center gap-3">
                    <CheckCircle className="h-5 w-5 text-blue-400" />
                    <div>
                      <p className="font-medium">{getLanguageName(langCode)}</p>
                      <p className="text-xs text-muted-foreground">
                        Quality: {(multilingualData.translation_quality_score * 100).toFixed(0)}%
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    {multilingualData.human_reviewed && (
                      <Badge variant="outline" className="text-green-400 border-green-400">
                        Reviewed
                      </Badge>
                    )}
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => onLanguageChange?.(langCode)}
                    >
                      <Eye className="h-3 w-3 mr-1" />
                      View
                    </Button>
                  </div>
                </div>
              ))}

              {multilingualData.available_translations.length === 0 && (
                <div className="text-center py-8">
                  <Languages className="h-8 w-8 text-muted-foreground mx-auto mb-2" />
                  <p className="text-muted-foreground">No translations available yet</p>
                  <p className="text-sm text-muted-foreground">Request a translation to get started</p>
                </div>
              )}
            </div>
          </TabsContent>

          {/* Request New Tab */}
          <TabsContent value="request" className="space-y-4">
            {getAvailableForTranslation().length > 0 ? (
              <div className="space-y-4">
                <div>
                  <label className="text-sm font-medium mb-2 block">Target Language</label>
                  <Select value={selectedTargetLanguage} onValueChange={setSelectedTargetLanguage}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select target language" />
                    </SelectTrigger>
                    <SelectContent>
                      {getAvailableForTranslation().map((lang) => (
                        <SelectItem key={lang.code} value={lang.code}>
                          {lang.name} ({lang.native_name})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="text-sm font-medium mb-2 block">Priority Level</label>
                  <Select value={translationPriority} onValueChange={(value: any) => setTranslationPriority(value)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">
                        <div>
                          <p className="font-medium">Low Priority</p>
                          <p className="text-xs text-muted-foreground">Standard processing time</p>
                        </div>
                      </SelectItem>
                      <SelectItem value="normal">
                        <div>
                          <p className="font-medium">Normal Priority</p>
                          <p className="text-xs text-muted-foreground">24-48 hour delivery</p>
                        </div>
                      </SelectItem>
                      <SelectItem value="high">
                        <div>
                          <p className="font-medium">High Priority</p>
                          <p className="text-xs text-muted-foreground">Next business day</p>
                        </div>
                      </SelectItem>
                      <SelectItem value="urgent">
                        <div>
                          <p className="font-medium">Urgent Priority</p>
                          <p className="text-xs text-muted-foreground">Same day delivery</p>
                        </div>
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-3">
                  <div className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      id="auto-translate-full"
                      checked={autoTranslate}
                      onChange={(e) => setAutoTranslate(e.target.checked)}
                      className="rounded"
                    />
                    <label htmlFor="auto-translate-full" className="text-sm">
                      Enable automatic translation
                    </label>
                  </div>
                  <p className="text-xs text-muted-foreground pl-6">
                    Automatic translations are faster but may require human review for accuracy.
                  </p>
                </div>

                <Button 
                  onClick={handleRequestTranslation} 
                  disabled={translationLoading || !selectedTargetLanguage}
                  className="w-full"
                >
                  {translationLoading ? (
                    <>
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                      Submitting Request...
                    </>
                  ) : (
                    <>
                      <Upload className="h-4 w-4 mr-2" />
                      Submit Translation Request
                    </>
                  )}
                </Button>
              </div>
            ) : (
              <div className="text-center py-8">
                <CheckCircle className="h-8 w-8 text-green-400 mx-auto mb-2" />
                <p className="font-medium text-green-400">All Translations Complete</p>
                <p className="text-sm text-muted-foreground">This document is available in all supported languages</p>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );

  return embedded ? <EmbeddedView /> : <FullView />;
};
