

// Document access components
export { CreditConfirmationDialog } from './CreditConfirmationDialog';
export { DocumentAccessWrapper, withDocumentAccess } from './DocumentAccessWrapper';
export { DocumentAccessProvider, useDocumentAccessContext } from './DocumentAccessProvider';
export { DocumentViewerWithCredits } from './DocumentViewerWithCredits';

// Main components (alphabetically ordered)
export * from './AdminPricingControl';
export * from './AssessmentManagement';
export * from './BadgeManagement';
export * from './ClassificationTreesTab';
export * from './DocumentAuthoringEditor';
export * from './DocumentEditor';
export * from './DocumentMetadataManagement';
export * from './DocumentPricingManagement';
export * from './DocumentSectionsManagement';
export * from './DocumentSectionsNavigator';
export * from './IntroductionTreesTab';
export * from './NotesTab';
export * from './OutcomesTab';
export * from './ProductClassificationAdminSimplified';
export * from './RiskAssessmentAdmin';
export * from './TemplateSelectionDialog';
export * from './ToolsTab';
export * from './TreeCard';
export * from './ValidationTasks';
export * from './WorkflowsTab';
