import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ChevronLeft, ChevronRight, Info } from 'lucide-react';

interface WorkflowExecutionDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  executingWorkflow: any;
  currentTree: any;
  currentTreeIndex: number;
  totalTrees: number;
  currentNode: any;
  currentNodeIndex: number;
  selectedOption: string;
  setSelectedOption: (option: string) => void;
  setCurrentNodeIndex: (index: number) => void;
  resetWorkflow: () => void;
  handleNextStep: () => void;
  workflowResults: any[];
}

const WorkflowExecutionDialog: React.FC<WorkflowExecutionDialogProps> = ({
  open,
  onOpenChange,
  executingWorkflow,
  currentTree,
  currentTreeIndex,
  totalTrees,
  currentNode,
  currentNodeIndex,
  selectedOption,
  setSelectedOption,
  setCurrentNodeIndex,
  resetWorkflow,
  handleNextStep,
  workflowResults
}) => {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-hidden bg-gray-800 border-gray-700">
        <DialogHeader>
          <DialogTitle className="text-white">
            {executingWorkflow ? `Executing: ${executingWorkflow.name}` : 'Workflow Execution'}
          </DialogTitle>
        </DialogHeader>
        
        {executingWorkflow && (
          <div className="flex-1 overflow-hidden">
            {/* Progress Header */}
            <div className="mb-6 p-4 bg-gray-700/30 rounded-lg border border-gray-600/50">
              <div className="flex items-center justify-between mb-2">
                <h3 className="text-lg font-semibold text-white">
                  {currentTree ? currentTree.name : 'Starting Workflow'}
                </h3>
                <div className="text-sm text-gray-400">
                  Step {currentTree ? currentTreeIndex + 1 : 1} of {totalTrees}
                </div>
              </div>
              
              <div className="w-full bg-gray-600 rounded-full h-2">
                <div 
                  className="bg-purple-500 h-2 rounded-full transition-all duration-300"
                  style={{ width: `${((currentTree ? currentTreeIndex : 0) / totalTrees) * 100}%` }}
                ></div>
              </div>
              
              {currentTree && (
                <div className="mt-3">
                  <p className="text-gray-300 text-sm">{currentTree.description}</p>
                  <div className="flex items-center gap-2 mt-2">
                    <Badge className="bg-blue-500/20 text-blue-400 border-blue-500/30 text-xs">
                      {currentTree.jurisdiction}
                    </Badge>
                    <Badge className="bg-green-500/20 text-green-400 border-green-500/30 text-xs">
                      {currentTree.category}
                    </Badge>
                  </div>
                </div>
              )}
            </div>

            {/* Current Question/Node */}
            {currentNode && (
              <div className="mb-6">
                <Card className="bg-gray-700/30 border-gray-600/50">
                  <CardContent className="p-6">
                    <h4 className="text-lg font-semibold text-white mb-4">
                      {currentNode.question || currentNode.name}
                    </h4>
                    
                    {currentNode.description && (
                      <p className="text-gray-300 mb-6">{currentNode.description}</p>
                    )}
                    
                    {/* Options */}
                    {currentNode.options && currentNode.options.length > 0 && (
                      <div className="space-y-3">
                        <p className="text-sm font-medium text-purple-400 mb-3">Select an option:</p>
                        {currentNode.options.map((option: any) => (
                          <label
                            key={option.id}
                            className={`flex items-start space-x-3 p-4 rounded-lg border cursor-pointer transition-all ${
                              selectedOption === option.id
                                ? 'bg-purple-500/20 border-purple-500/50'
                                : 'bg-gray-600/30 border-gray-600/50 hover:bg-gray-600/50'
                            }`}
                          >
                            <input
                              type="radio"
                              name="treeOption"
                              value={option.id}
                              checked={selectedOption === option.id}
                              onChange={(e) => setSelectedOption(e.target.value)}
                              className="mt-1 text-purple-500 focus:ring-purple-500"
                            />
                            <div>
                              <div className="text-white font-medium">{option.label}</div>
                              {option.description && (
                                <div className="text-gray-400 text-sm mt-1">{option.description}</div>
                              )}
                            </div>
                          </label>
                        ))}
                      </div>
                    )}
                    
                    {/* Information Node */}
                    {(!currentNode.options || currentNode.options.length === 0) && (
                      <div className="bg-blue-500/10 border border-blue-500/30 rounded-lg p-4">
                        <div className="flex items-start gap-3">
                          <Info className="h-5 w-5 text-blue-400 mt-0.5 flex-shrink-0" />
                          <div className="text-blue-100">
                            This is an informational step. Click "Continue" to proceed.
                          </div>
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
            )}

            {/* Navigation Buttons */}
            <div className="flex items-center justify-between pt-4 border-t border-gray-700">
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  onClick={() => {
                    if (currentNodeIndex > 0) {
                      setCurrentNodeIndex(currentNodeIndex - 1);
                      setSelectedOption('');
                    }
                  }}
                  disabled={currentNodeIndex === 0}
                  className="border-gray-600 text-gray-300 hover:bg-gray-700"
                >
                  <ChevronLeft className="h-4 w-4 mr-1" />
                  Previous
                </Button>
              </div>
              
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  onClick={() => {
                    onOpenChange(false);
                    resetWorkflow();
                  }}
                  className="border-gray-600 text-gray-300 hover:bg-gray-700"
                >
                  Cancel
                </Button>
                
                <Button
                  onClick={handleNextStep}
                  disabled={currentNode?.options && currentNode.options.length > 0 && !selectedOption}
                  className="bg-purple-500 hover:bg-purple-600 text-white"
                >
                  {currentTreeIndex === totalTrees - 1 && 
                   currentNodeIndex === (currentTree?.nodes?.length || 1) - 1
                    ? 'Complete Assessment'
                    : 'Continue'
                  }
                  <ChevronRight className="h-4 w-4 ml-1" />
                </Button>
              </div>
            </div>
          </div>
        )}
        
        {/* Results Summary */}
        {workflowResults.length > 0 && !currentTree && (
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-white mb-4">Assessment Complete</h3>
            
            {workflowResults.map((result, index) => (
              <Card key={index} className="bg-gray-700/30 border-gray-600/50">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="font-medium text-white">{result.treeName}</h4>
                    <Badge 
                      className={`${
                        result.riskLevel === 'high' 
                          ? 'bg-red-500/20 text-red-400 border-red-500/30'
                          : result.riskLevel === 'medium'
                          ? 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30'
                          : 'bg-green-500/20 text-green-400 border-green-500/30'
                      }`}
                    >
                      {result.riskLevel} Risk
                    </Badge>
                  </div>
                  <p className="text-gray-300 text-sm">{result.recommendation}</p>
                  {result.additionalInfo && (
                    <div className="mt-2 text-xs text-gray-400">{result.additionalInfo}</div>
                  )}
                </CardContent>
              </Card>
            ))}
            
            <div className="flex justify-end gap-2 pt-4 border-t border-gray-700">
              <Button
                variant="outline"
                onClick={() => {
                  onOpenChange(false);
                  resetWorkflow();
                }}
                className="border-gray-600 text-gray-300 hover:bg-gray-700"
              >
                Close
              </Button>
              <Button
                onClick={() => {
                  console.log('Saving assessment results...', workflowResults);
                  // Here you would save the assessment results
                  onOpenChange(false);
                  resetWorkflow();
                }}
                className="bg-purple-500 hover:bg-purple-600 text-white"
              >
                Save Assessment
              </Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
};

export default WorkflowExecutionDialog;
