import React, { useEffect, useState } from 'react';
import { toast } from 'sonner';
import { useNavigate } from 'react-router-dom';
import { 
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription 
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Label } from '@/components/ui/label';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { 
  CheckCircle,
  XCircle,
  Eye,
  Plus,
  Search,
  Filter,
  Trash2,
  Clock,
  Download,
  FileText,
  ExternalLink,
  Upload,
  FolderOpen,
  Edit,
  Calendar,
  MoreHorizontal,
  X,
  RefreshCw,
  DollarSign,
  BadgeIcon,
  Layers,
  MessageSquare,
  Star,
  BookOpen,
  Settings,
  BarChart3,
  TrendingUp,
  ArrowUp,
  ArrowDown,
  Save
} from 'lucide-react';
import brain from 'brain';
import { API_URL } from "app";
import { AdminDocumentResponse } from 'brain/data-contracts';
import DocumentPricingManagement from './DocumentPricingManagement';
import BadgeManagement from './BadgeManagement';
import DocumentSectionsManagement from './DocumentSectionsManagement';
import SearchAndFilterDialogs from './SearchAndFilterDialogs';
import DocumentAuthoringEditor from './DocumentAuthoringEditor';
import EnhancedDocumentUpload from './EnhancedDocumentUpload';
import DocumentEditor from './DocumentEditor';

interface Props {
  documents: AdminDocumentResponse[];
  onDocumentsUpdate: () => void;
  loading?: boolean;
}

export function KnowledgeBaseAdminTab({ documents, onDocumentsUpdate, loading = false }: Props) {
  const navigate = useNavigate();
  const [knowledgeBaseSubTab, setKnowledgeBaseSubTab] = useState('document-upload');
  const [showDocumentDialog, setShowDocumentDialog] = useState(false);
  const [selectedDocument, setSelectedDocument] = useState<AdminDocumentResponse | null>(null);
  const [editFormData, setEditFormData] = useState<any>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [showSearchDialog, setShowSearchDialog] = useState(false);
  const [showFilterDialog, setShowFilterDialog] = useState(false);
  const [showAddDocumentDialog, setShowAddDocumentDialog] = useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [documentToDelete, setDocumentToDelete] = useState<AdminDocumentResponse | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);
  
  // Validation states
  const [pendingDocuments, setPendingDocuments] = useState<any[]>([]);
  const [loadingPending, setLoadingPending] = useState(false);
  const [processingAction, setProcessingAction] = useState<{ docId: number, action: string } | null>(null);
  
  // Add PDF preview state
  const [showPdfPreview, setShowPdfPreview] = useState(false);
  const [previewDocument, setPreviewDocument] = useState<any>(null);
  const [pdfUrl, setPdfUrl] = useState<string>('');

  // Blog post deletion states
  const [showBlogDeleteDialog, setShowBlogDeleteDialog] = useState(false);
  const [blogPostToDelete, setBlogPostToDelete] = useState<{ id: number, title: string } | null>(null);
  const [isDeletingBlogPost, setIsDeletingBlogPost] = useState(false);

  // Blog posts state
  const [blogPosts, setBlogPosts] = useState<any[]>([]);
  const [loadingBlogPosts, setLoadingBlogPosts] = useState(false);

  // Load blog posts
  const loadBlogPosts = async () => {
    setLoadingBlogPosts(true);
    try {
      const response = await brain.list_blog_documents({
        page: 1,
        per_page: 5,
        sort_by: 'created_at_desc'
      });
      if (response.ok) {
        const data = await response.json();
        setBlogPosts(data.documents || []);
      } else {
        console.error('Failed to load blog posts:', response.status);
        toast.error('Cannot load blog posts');
        setBlogPosts([]);
      }
    } catch (error) {
      console.error('Error loading blog posts:', error);
      toast.error('Cannot load blog posts');
      setBlogPosts([]);
    } finally {
      setLoadingBlogPosts(false);
    }
  };

  // Load blog posts on component mount
  useEffect(() => {
    loadBlogPosts();
  }, []);

  // Load pending documents for validation
  const loadPendingDocuments = async () => {
    setLoadingPending(true);
    try {
      const response = await brain.list_pending_documents();
      if (response.ok) {
        const data = await response.json();
        setPendingDocuments(data.documents || []);
      }
    } catch (error) {
      console.error('Error loading pending documents:', error);
      toast.error('Failed to load pending documents');
    } finally {
      setLoadingPending(false);
    }
  };

  // Handle blog post deletion
  const handleDeleteBlogPost = async () => {
    if (!blogPostToDelete) return;
    
    setIsDeletingBlogPost(true);
    try {
      // Call the actual delete document API
      const response = await brain.delete_document({ documentId: blogPostToDelete.id });
      
      if (response.ok) {
        toast.success(`Blog post "${blogPostToDelete.title}" deleted successfully`);
        setShowBlogDeleteDialog(false);
        setBlogPostToDelete(null);
        
        // Refresh the blog posts list after successful deletion
        await loadBlogPosts();
        // Also refresh the main documents list if callback is provided
        onDocumentsUpdate();
      } else {
        console.error('Failed to delete blog post:', response.status);
        toast.error('Failed to delete blog post');
      }
    } catch (error) {
      console.error('Error deleting blog post:', error);
      toast.error('Failed to delete blog post');
    } finally {
      setIsDeletingBlogPost(false);
    }
  };

  // Handle document approval
  const handleApproveDocument = async (documentId: number) => {
    try {
      setProcessingAction({ docId: documentId, action: 'approve' });
      
      const response = await brain.update_document_status(
        { documentId },
        { status: 'published' }
      );
      
      if (response.ok) {
        toast.success('Document approved and published successfully');
        loadPendingDocuments();
        onDocumentsUpdate();
      } else {
        toast.error('Failed to approve document');
      }
    } catch (error) {
      console.error('Error approving document:', error);
      toast.error('Failed to approve document');
    } finally {
      setProcessingAction(null);
    }
  };

  // Handle document rejection
  const handleRejectDocument = async (documentId: number) => {
    try {
      setProcessingAction({ docId: documentId, action: 'reject' });
      
      const response = await brain.update_document_status(
        { documentId },
        { status: 'rejected' }
      );
      
      if (response.ok) {
        toast.success('Document rejected successfully');
        loadPendingDocuments();
        onDocumentsUpdate();
      } else {
        toast.error('Failed to reject document');
      }
    } catch (error) {
      console.error('Error rejecting document:', error);
      toast.error('Failed to reject document');
    } finally {
      setProcessingAction(null);
    }
  };

  // PDF Preview function
  const handlePreviewDocument = async (document: any) => {
    try {
      setPreviewDocument(document);
      
      // Create PDF URL for viewing
      const pdfViewUrl = `${brain.baseUrl}/routes/knowledge-base/file/${document.id}`;
      setPdfUrl(pdfViewUrl);
      setShowPdfPreview(true);
    } catch (error) {
      console.error('Error loading PDF preview:', error);
      toast.error('Failed to load PDF preview');
    }
  };

  // Download PDF function
  const handleDownloadPdf = async (document: any) => {
    try {
      const response = await brain.download_document_file({ documentId: document.id });
      
      if (response.ok) {
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = document.file_name || `document-${document.id}.pdf`;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        document.body.removeChild(a);
      } else {
        toast.error('Failed to download document');
      }
    } catch (error) {
      console.error('Error downloading document:', error);
      toast.error('Failed to download document');
    }
  };

  // Load pending documents when validation tab is opened
  React.useEffect(() => {
    if (knowledgeBaseSubTab === 'document-validation') {
      loadPendingDocuments();
    }
  }, [knowledgeBaseSubTab]);

  const handleSaveDocument = async () => {
    console.log('🔄 START handleSaveDocument called');
    console.log('📄 selectedDocument:', selectedDocument);
    console.log('📝 editFormData:', editFormData);
    
    if (!selectedDocument) {
      console.error('❌ No document selected');
      toast.error('No document selected for editing');
      return;
    }

    if (!editFormData) {
      console.error('❌ No form data available');
      toast.error('Form data not initialized');
      return;
    }

    setIsSaving(true);
    console.log('💾 Saving document with ID:', selectedDocument.id);
    console.log('📊 Form data to save:', editFormData);
    
    try {
      const response = await brain.update_document(
        { documentId: selectedDocument.id },
        editFormData
      );
      
      console.log('✅ Update response:', response);
      
      if (response.ok) {
        const updatedDoc = await response.json();
        console.log('✅ Document updated successfully:', updatedDoc);
        toast.success('Document updated successfully');
        
        onDocumentsUpdate();
        setShowDocumentDialog(false);
        setSelectedDocument(null);
        setEditFormData(null);
      } else {
        console.error('❌ Update failed:', response.status);
        const errorData = await response.text();
        console.error('❌ Error details:', errorData);
        toast.error('Failed to update document');
      }
    } catch (error) {
      console.error('❌ Exception during save:', error);
      toast.error('Error saving document');
    } finally {
      setIsSaving(false);
      console.log('🔄 END handleSaveDocument');
    }
  };

  const handleDeleteDocument = async () => {
    if (!documentToDelete) {
      toast.error('No document selected for deletion');
      return;
    }

    setIsDeleting(true);
    console.log('🗑️ Deleting document with ID:', documentToDelete.id);
    
    try {
      const response = await brain.delete_document({ documentId: documentToDelete.id });
      
      if (response.ok) {
        console.log('✅ Delete successful');
        toast.success('Document deleted successfully');
        onDocumentsUpdate();
        setShowDeleteDialog(false);
        setDocumentToDelete(null);
      } else {
        console.error('❌ Delete failed:', response.status);
        toast.error('Failed to delete document');
      }
    } catch (error) {
      console.error('❌ Exception during delete:', error);
      toast.error('Failed to delete document');
    } finally {
      setIsDeleting(false);
    }
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="bg-gray-800/30 backdrop-blur-sm border border-gray-700 rounded-lg p-6">
          <div className="animate-pulse">
            <div className="h-6 bg-gray-600 rounded w-1/4 mb-4"></div>
            <div className="h-4 bg-gray-600 rounded w-1/2 mb-6"></div>
            <div className="h-10 bg-gray-600 rounded mb-4"></div>
            <div className="space-y-4">
              {[1, 2, 3].map((i) => (
                <div key={i} className="h-24 bg-gray-600 rounded"></div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="bg-gray-800/30 backdrop-blur-sm border border-gray-700 rounded-lg p-6">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-xl font-semibold text-white mb-2">Document Management</h2>
            <p className="text-gray-400">Manage knowledge base documents and content</p>
          </div>
        </div>
        
        <Tabs value={knowledgeBaseSubTab} onValueChange={setKnowledgeBaseSubTab} className="space-y-4">
          <TabsList className="grid w-full grid-cols-8 bg-gray-800/50 border-gray-600">
            <TabsTrigger value="document-upload" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white">
              <Upload className="h-4 w-4 mr-1" />
              Upload
            </TabsTrigger>
            <TabsTrigger value="blog-management" className="data-[state=active]:bg-purple-600 data-[state=active]:text-white">
              <MessageSquare className="h-4 w-4 mr-1" />
              Blog
            </TabsTrigger>
            <TabsTrigger value="featured-articles" className="data-[state=active]:bg-amber-600 data-[state=active]:text-white">
              <Star className="h-4 w-4 mr-1" />
              Featured
            </TabsTrigger>
            <TabsTrigger value="document-validation" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white">
              <CheckCircle className="h-4 w-4 mr-1" />
              Validation
            </TabsTrigger>
            <TabsTrigger value="document-repository" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white">
              <FolderOpen className="h-4 w-4 mr-1" />
              Repository
            </TabsTrigger>
            <TabsTrigger value="document-authoring" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white">
              <Edit className="h-4 w-4 mr-1" />
              Authoring
            </TabsTrigger>
            <TabsTrigger value="document-pricing" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white">
              <DollarSign className="h-4 w-4 mr-1" />
              Document Pricing
            </TabsTrigger>
            <TabsTrigger value="badge-management" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white">
              <BadgeIcon className="h-4 w-4 mr-2" />
              Badge Management
            </TabsTrigger>
            <TabsTrigger value="document-sections" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white">
              <Layers className="h-4 w-4 mr-2" />
              Document Sections
            </TabsTrigger>
          </TabsList>

          <TabsContent value="document-upload" className="space-y-6">
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="text-lg font-semibold text-white">Document Upload</h3>
                <Button onClick={() => setShowAddDocumentDialog(true)} className="bg-blue-600 hover:bg-blue-700">
                  <Upload className="h-4 w-4 mr-2" />
                  Upload Document
                </Button>
              </div>
              <p className="text-gray-400">Upload new documents to the knowledge base with enhanced metadata and compliance fields.</p>
            </div>
          </TabsContent>

          <TabsContent value="blog-management" className="space-y-6">
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <div>
                  <h3 className="text-lg font-semibold text-white">Blog Management</h3>
                  <p className="text-gray-400">Create and manage blog articles for the Export Control Intelligence Hub</p>
                </div>
                <div className="flex gap-2">
                  <Button 
                    onClick={() => navigate('/blog-admin')} 
                    className="bg-purple-600 hover:bg-purple-700"
                  >
                    <MessageSquare className="h-4 w-4 mr-2" />
                    Open Blog Admin
                  </Button>
                  <Button 
                    onClick={() => setShowAddDocumentDialog(true)} 
                    variant="outline"
                    className="border-purple-600 text-purple-400 hover:bg-purple-600/20"
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    Quick Create Blog
                  </Button>
                </div>
              </div>
              
              {/* Blog Management Overview Cards */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Card className="bg-gradient-to-br from-purple-600/20 to-purple-800/20 border-purple-600/30">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-purple-400">Published Articles</p>
                        <p className="text-2xl font-bold text-white">6</p>
                      </div>
                      <MessageSquare className="h-8 w-8 text-purple-400" />
                    </div>
                  </CardContent>
                </Card>
                
                <Card className="bg-gradient-to-br from-amber-600/20 to-amber-800/20 border-amber-600/30">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-amber-400">Featured Articles</p>
                        <p className="text-2xl font-bold text-white">2</p>
                      </div>
                      <Star className="h-8 w-8 text-amber-400" />
                    </div>
                  </CardContent>
                </Card>
                
                <Card className="bg-gradient-to-br from-green-600/20 to-green-800/20 border-green-600/30">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-green-400">Total Views</p>
                        <p className="text-2xl font-bold text-white">1.2k</p>
                      </div>
                      <Eye className="h-8 w-8 text-green-400" />
                    </div>
                  </CardContent>
                </Card>
              </div>
              
              {/* Blog Categories and Quick Actions */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card className="bg-gray-800/50 border-gray-700">
                  <CardHeader>
                    <CardTitle className="text-purple-400 flex items-center gap-2">
                      <BookOpen className="h-5 w-5" />
                      Blog Categories
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    {[
                      { name: 'Compliance News', count: 2, color: 'blue' },
                      { name: 'Regulatory Updates', count: 2, color: 'green' },
                      { name: 'Industry Analysis', count: 1, color: 'purple' },
                      { name: 'Best Practices', count: 1, color: 'amber' }
                    ].map((category) => (
                      <div key={category.name} className="flex items-center justify-between p-2 rounded border border-gray-600">
                        <span className="text-white">{category.name}</span>
                        <Badge className={`bg-${category.color}-500/20 text-${category.color}-400 border-${category.color}-500/30`}>
                          {category.count} articles
                        </Badge>
                      </div>
                    ))}
                  </CardContent>
                </Card>
                
                <Card className="bg-gray-800/50 border-gray-700">
                  <CardHeader>
                    <CardTitle className="text-purple-400 flex items-center gap-2">
                      <Settings className="h-5 w-5" />
                      Quick Actions
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <Button 
                      className="w-full justify-start bg-blue-600/20 border border-blue-600/30 text-blue-400 hover:bg-blue-600/30"
                      onClick={() => navigate('/blog-admin')}
                    >
                      <Edit className="h-4 w-4 mr-2" />
                      Manage All Blog Posts
                    </Button>
                    <Button 
                      className="w-full justify-start bg-green-600/20 border border-green-600/30 text-green-400 hover:bg-green-600/30"
                      onClick={() => setKnowledgeBaseSubTab('document-authoring')}
                    >
                      <Plus className="h-4 w-4 mr-2" />
                      Create New Article
                    </Button>
                    <Button 
                      className="w-full justify-start bg-amber-600/20 border border-amber-600/30 text-amber-400 hover:bg-amber-600/30"
                      onClick={() => {
                        toast.info('Featured Articles management coming soon!');
                        // TODO: Implement featured articles management
                      }}
                    >
                      <Star className="h-4 w-4 mr-2" />
                      Manage Featured Articles
                    </Button>
                    <Button 
                      className="w-full justify-start bg-purple-600/20 border border-purple-600/30 text-purple-400 hover:bg-purple-600/30"
                      onClick={() => {
                        toast.info('Blog Analytics dashboard coming soon!');
                        // TODO: Implement blog analytics
                      }}
                    >
                      <BarChart3 className="h-4 w-4 mr-2" />
                      View Blog Analytics
                    </Button>
                  </CardContent>
                </Card>
              </div>
              
              {/* Recent Blog Posts */}
              <Card className="bg-gray-800/50 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-purple-400 flex items-center gap-2">
                    <Clock className="h-5 w-5" />
                    Recent Blog Posts
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {loadingBlogPosts ? (
                      <div className="flex justify-center items-center py-8">
                        <div className="text-gray-400">Loading blog posts...</div>
                      </div>
                    ) : blogPosts.length === 0 ? (
                      <div className="flex flex-col items-center justify-center py-8 text-center">
                        <FileText className="h-8 w-8 text-gray-400 mb-2" />
                        <p className="text-gray-400">No blog posts found</p>
                      </div>
                    ) : (
                      blogPosts.map((post: any) => (
                        <div key={post.id} className="flex items-center justify-between p-3 rounded border border-gray-600 hover:bg-gray-700/50">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-1">
                              <h4 className="text-white font-medium">{post.title}</h4>
                              {post.featured_status && (
                                <Badge className="bg-amber-500/20 text-amber-400 border-amber-500/30">
                                  <Star className="h-3 w-3 mr-1" />
                                  Featured
                                </Badge>
                              )}
                            </div>
                            <div className="flex items-center gap-4 text-sm text-gray-400">
                              <span>By {post.author || post.uploaded_by || 'Unknown'}</span>
                              <span>{post.publication_date ? new Date(post.publication_date).toLocaleDateString() : (post.created_at ? new Date(post.created_at).toLocaleDateString() : 'Unknown')}</span>
                              <Badge variant="outline" className="border-gray-600 text-gray-400">
                                {post.article_type || post.regulation_type || post.document_type || 'Blog'}
                              </Badge>
                            </div>
                          </div>
                          <div className="flex gap-2">
                            <Button 
                              size="sm" 
                              variant="outline" 
                              onClick={() => {
                                setBlogPostToDelete({ id: post.id, title: post.title });
                                setShowBlogDeleteDialog(true);
                              }}
                              className="text-red-400 hover:text-red-300 hover:bg-red-900/20"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                  
                  <div className="mt-4 pt-4 border-t border-gray-600">
                    <Button 
                      className="w-full bg-purple-600 hover:bg-purple-700"
                      onClick={() => navigate('/blog-admin')}
                    >
                      View All Blog Posts
                      <ExternalLink className="h-4 w-4 ml-2" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="document-validation" className="space-y-6">
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="text-lg font-semibold text-white">Document Validation</h3>
                <div className="flex items-center gap-2">
                  <Clock className="h-4 w-4 text-yellow-400" />
                  <span className="text-sm text-gray-400">{pendingDocuments.length} documents pending approval</span>
                  <Button 
                    onClick={loadPendingDocuments} 
                    variant="outline" 
                    size="sm"
                    disabled={loadingPending}
                  >
                    {loadingPending ? 'Loading...' : 'Refresh'}
                  </Button>
                </div>
              </div>
              <p className="text-gray-400">Review and approve/reject uploaded documents before they appear in the Knowledge Base.</p>
              
              {loadingPending ? (
                <div className="flex justify-center items-center py-8">
                  <div className="text-gray-400">Loading pending documents...</div>
                </div>
              ) : pendingDocuments.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-12 text-center">
                  <CheckCircle className="h-12 w-12 text-green-400 mb-4" />
                  <h4 className="text-lg font-semibold text-white mb-2">All Caught Up!</h4>
                  <p className="text-gray-400">No documents are currently pending validation.</p>
                </div>
              ) : (
                <div className="grid gap-4">
                  {pendingDocuments.map((doc: any) => (
                    <Card key={doc.id} className="bg-gray-800/50 border-gray-700">
                      <CardContent className="p-6">
                        <div className="flex justify-between items-start">
                          <div className="flex-1 mr-6">
                            <div className="flex items-center gap-2 mb-2">
                              <h4 className="font-semibold text-white">{doc.title}</h4>
                              <Badge variant="outline" className="text-xs text-yellow-400 border-yellow-400">
                                <Clock className="h-3 w-3 mr-1" />
                                Pending
                              </Badge>
                            </div>
                            <p className="text-gray-400 text-sm mb-3">{doc.description}</p>
                            <div className="flex gap-2 mb-3">
                              {doc.country_jurisdiction?.map((country: string) => (
                                <Badge key={country} variant="outline" className="text-xs">
                                  {country}
                                </Badge>
                              ))}
                            </div>
                            <div className="text-xs text-gray-500">
                              <span>File: {doc.file_name}</span> • 
                              <span>Size: {doc.file_size ? Math.round(doc.file_size / 1024) + ' KB' : 'Unknown'}</span> • 
                              <span>Uploaded by: {doc.uploaded_by || 'Unknown'}</span>
                            </div>
                          </div>
                          <div className="flex flex-col gap-2">
                            <Button 
                              size="sm" 
                              className="bg-green-600 hover:bg-green-700 text-white"
                              onClick={() => handleApproveDocument(doc.id)}
                              disabled={processingAction?.docId === doc.id}
                            >
                              {processingAction?.docId === doc.id && processingAction?.action === 'approve' ? (
                                'Approving...'
                              ) : (
                                <>
                                  <CheckCircle className="h-4 w-4 mr-1" />
                                  Approve
                                </>
                              )}
                            </Button>
                            <Button 
                              size="sm" 
                              variant="outline"
                              className="text-red-400 hover:text-red-300 hover:bg-red-900/20 border-red-400"
                              onClick={() => handleRejectDocument(doc.id)}
                              disabled={processingAction?.docId === doc.id}
                            >
                              {processingAction?.docId === doc.id && processingAction?.action === 'reject' ? (
                                'Rejecting...'
                              ) : (
                                <>
                                  <XCircle className="h-4 w-4 mr-1" />
                                  Reject
                                </>
                              )}
                            </Button>
                            <Button 
                              size="sm" 
                              variant="outline"
                              onClick={() => handlePreviewDocument(doc)}
                            >
                              <Eye className="h-4 w-4 mr-1" />
                              Preview
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </div>
          </TabsContent>

          <TabsContent value="document-repository" className="space-y-6">
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="text-lg font-semibold text-white">Document Repository</h3>
                <div className="flex gap-2">
                  <Button onClick={() => setShowSearchDialog(true)} variant="outline" size="sm">
                    <Search className="h-4 w-4 mr-2" />
                    Search
                  </Button>
                  <Button onClick={() => setShowFilterDialog(true)} variant="outline" size="sm">
                    <Filter className="h-4 w-4 mr-2" />
                    Filter
                  </Button>
                </div>
              </div>
              
              <div className="grid gap-4">
                {documents.map((doc: any) => (
                  <Card key={doc.id} className="bg-gray-800/50 border-gray-700">
                    <CardContent className="p-4">
                      <div className="flex justify-between items-start">
                        <div className="flex-1">
                          <h4 className="font-semibold text-white mb-2">{doc.title}</h4>
                          <p className="text-gray-400 text-sm mb-2">{doc.description}</p>
                          <div className="flex gap-2 mb-2">
                            {doc.country_jurisdiction?.map((country: string) => (
                              <Badge key={country} variant="outline" className="text-xs">
                                {country}
                              </Badge>
                            ))}
                          </div>
                        </div>
                        <div className="flex gap-2">
                          <Button size="sm" variant="outline" onClick={() => {
                            setSelectedDocument(doc);
                            setEditFormData({ ...doc });
                            setShowDocumentDialog(true);
                          }}>
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button size="sm" variant="outline">
                            <Eye className="h-4 w-4" />
                          </Button>
                          <Button 
                            size="sm" 
                            variant="outline" 
                            onClick={() => {
                              setDocumentToDelete(doc);
                              setShowDeleteDialog(true);
                            }}
                            className="text-red-400 hover:text-red-300 hover:bg-red-900/20"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </TabsContent>

          <TabsContent value="document-authoring" className="space-y-6">
            <DocumentAuthoringEditor onSaveDocument={onDocumentsUpdate} />
          </TabsContent>

          <TabsContent value="document-pricing" className="space-y-6">
            <DocumentPricingManagement onRefresh={onDocumentsUpdate} />
          </TabsContent>

          <TabsContent value="badge-management" className="space-y-6">
            <BadgeManagement onRefresh={onDocumentsUpdate} />
          </TabsContent>

          <TabsContent value="document-sections" className="space-y-6">
            <DocumentSectionsManagement />
          </TabsContent>

          <TabsContent value="featured-articles" className="space-y-6">
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <div>
                  <h3 className="text-lg font-semibold text-white">Featured Articles Management</h3>
                  <p className="text-gray-400">Curate and manage featured content for the Knowledge Base showcase</p>
                </div>
                <div className="flex gap-2">
                  <Button className="bg-amber-600 hover:bg-amber-700">
                    <Star className="h-4 w-4 mr-2" />
                    Auto-Feature Top Articles
                  </Button>
                  <Button variant="outline" className="border-amber-600 text-amber-400 hover:bg-amber-600/20">
                    <RefreshCw className="h-4 w-4 mr-2" />
                    Refresh Rankings
                  </Button>
                </div>
              </div>
              
              {/* Featured Articles Stats */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <Card className="bg-gradient-to-br from-amber-600/20 to-amber-800/20 border-amber-600/30">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-amber-400">Currently Featured</p>
                        <p className="text-2xl font-bold text-white">6</p>
                      </div>
                      <Star className="h-8 w-8 text-amber-400" />
                    </div>
                  </CardContent>
                </Card>
                
                <Card className="bg-gradient-to-br from-blue-600/20 to-blue-800/20 border-blue-600/30">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-blue-400">Total Views</p>
                        <p className="text-2xl font-bold text-white">15.2k</p>
                      </div>
                      <Eye className="h-8 w-8 text-blue-400" />
                    </div>
                  </CardContent>
                </Card>
                
                <Card className="bg-gradient-to-br from-green-600/20 to-green-800/20 border-green-600/30">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-green-400">Avg. Engagement</p>
                        <p className="text-2xl font-bold text-white">8.5%</p>
                      </div>
                      <TrendingUp className="h-8 w-8 text-green-400" />
                    </div>
                  </CardContent>
                </Card>
                
                <Card className="bg-gradient-to-br from-purple-600/20 to-purple-800/20 border-purple-600/30">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-purple-400">Available Slots</p>
                        <p className="text-2xl font-bold text-white">2</p>
                      </div>
                      <Plus className="h-8 w-8 text-purple-400" />
                    </div>
                  </CardContent>
                </Card>
              </div>
              
              {/* Featured Articles Management */}
              <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
                {/* Currently Featured */}
                <Card className="bg-gray-800/50 border-gray-700">
                  <CardHeader>
                    <CardTitle className="text-amber-400 flex items-center gap-2">
                      <Star className="h-5 w-5" />
                      Currently Featured Articles
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {[
                      {
                        id: 1,
                        title: "ITAR Export License Requirements 2024",
                        type: "regulation",
                        views: 2450,
                        featured_since: "Aug 15, 2024",
                        engagement: 9.2,
                        priority: 1
                      },
                      {
                        id: 2,
                        title: "EAR Classification Best Practices",
                        type: "guidance",
                        views: 1890,
                        featured_since: "Aug 18, 2024",
                        engagement: 7.8,
                        priority: 2
                      },
                      {
                        id: 3,
                        title: "EU Export Control Framework Update",
                        type: "regulation",
                        views: 1650,
                        featured_since: "Aug 20, 2024",
                        engagement: 8.5,
                        priority: 3
                      }
                    ].map((article, index) => (
                      <div key={article.id} className="p-4 border border-amber-600/30 rounded-lg bg-amber-600/10">
                        <div className="flex items-start justify-between mb-3">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-1">
                              <Badge className="bg-amber-500/20 text-amber-400 border-amber-500/30">
                                #{article.priority}
                              </Badge>
                              <Badge variant="outline" className="border-gray-600 text-gray-400">
                                {article.type}
                              </Badge>
                            </div>
                            <h4 className="text-white font-medium mb-2">{article.title}</h4>
                            <div className="flex items-center gap-4 text-sm text-gray-400">
                              <span className="flex items-center gap-1">
                                <Eye className="h-3 w-3" />
                                {article.views.toLocaleString()} views
                              </span>
                              <span className="flex items-center gap-1">
                                <TrendingUp className="h-3 w-3" />
                                {article.engagement}% engagement
                              </span>
                              <span className="flex items-center gap-1">
                                <Calendar className="h-3 w-3" />
                                Since {article.featured_since}
                              </span>
                            </div>
                          </div>
                          <div className="flex flex-col gap-2">
                            <Button size="sm" variant="outline" className="border-amber-600 text-amber-400 hover:bg-amber-600/20">
                              <ArrowUp className="h-4 w-4" />
                            </Button>
                            <Button size="sm" variant="outline" className="border-amber-600 text-amber-400 hover:bg-amber-600/20">
                              <ArrowDown className="h-4 w-4" />
                            </Button>
                            <Button size="sm" variant="outline" className="border-red-600 text-red-400 hover:bg-red-600/20">
                              <X className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </CardContent>
                </Card>
                
                {/* Available for Featuring */}
                <Card className="bg-gray-800/50 border-gray-700">
                  <CardHeader>
                    <CardTitle className="text-blue-400 flex items-center gap-2">
                      <FileText className="h-5 w-5" />
                      Available for Featuring
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2 mb-4">
                      <Input 
                        placeholder="Search articles to feature..."
                        className="bg-gray-700 border-gray-600 text-white"
                      />
                      <div className="flex gap-2">
                        <Select>
                          <SelectTrigger className="bg-gray-700 border-gray-600">
                            <SelectValue placeholder="Filter by type" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="all">All Types</SelectItem>
                            <SelectItem value="regulation">Regulations</SelectItem>
                            <SelectItem value="guidance">Guidance</SelectItem>
                            <SelectItem value="blog">Blog Posts</SelectItem>
                          </SelectContent>
                        </Select>
                        <Select>
                          <SelectTrigger className="bg-gray-700 border-gray-600">
                            <SelectValue placeholder="Sort by" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="views">Most Views</SelectItem>
                            <SelectItem value="recent">Most Recent</SelectItem>
                            <SelectItem value="engagement">Best Engagement</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    
                    <div className="space-y-3 max-h-96 overflow-y-auto">
                      {[
                        {
                          id: 4,
                          title: "China Export Control Law Implementation",
                          type: "regulation",
                          views: 1234,
                          date: "Aug 22, 2024",
                          engagement: 6.7
                        },
                        {
                          id: 5,
                          title: "Sanctions Compliance Best Practices",
                          type: "guidance",
                          views: 987,
                          date: "Aug 21, 2024",
                          engagement: 8.1
                        },
                        {
                          id: 6,
                          title: "Q3 2024 Regulatory Changes Summary",
                          type: "blog",
                          views: 756,
                          date: "Aug 20, 2024",
                          engagement: 7.5
                        },
                        {
                          id: 7,
                          title: "OFAC SDN List Update Procedures",
                          type: "guidance",
                          views: 645,
                          date: "Aug 19, 2024",
                          engagement: 5.9
                        }
                      ].map((article) => (
                        <div key={article.id} className="p-3 border border-gray-600 rounded hover:bg-gray-700/50">
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <div className="flex items-center gap-2 mb-1">
                                <Badge variant="outline" className="border-gray-600 text-gray-400">
                                  {article.type}
                                </Badge>
                              </div>
                              <h5 className="text-white text-sm font-medium mb-1">{article.title}</h5>
                              <div className="flex items-center gap-3 text-xs text-gray-400">
                                <span className="flex items-center gap-1">
                                  <Eye className="h-3 w-3" />
                                  {article.views}
                                </span>
                                <span className="flex items-center gap-1">
                                  <TrendingUp className="h-3 w-3" />
                                  {article.engagement}%
                                </span>
                                <span>{article.date}</span>
                              </div>
                            </div>
                            <Button size="sm" className="bg-amber-600 hover:bg-amber-700">
                              <Star className="h-3 w-3 mr-1" />
                              Feature
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
              
              {/* Featured Articles Settings */}
              <Card className="bg-gray-800/50 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-amber-400 flex items-center gap-2">
                    <Settings className="h-5 w-5" />
                    Featured Articles Settings
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-3">
                      <Label className="text-white">Maximum Featured Articles</Label>
                      <Select>
                        <SelectTrigger className="bg-gray-700 border-gray-600">
                          <SelectValue placeholder="6 articles" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="4">4 articles</SelectItem>
                          <SelectItem value="6">6 articles</SelectItem>
                          <SelectItem value="8">8 articles</SelectItem>
                          <SelectItem value="10">10 articles</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div className="space-y-3">
                      <Label className="text-white">Auto-Rotation Period</Label>
                      <Select>
                        <SelectTrigger className="bg-gray-700 border-gray-600">
                          <SelectValue placeholder="Weekly" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="daily">Daily</SelectItem>
                          <SelectItem value="weekly">Weekly</SelectItem>
                          <SelectItem value="monthly">Monthly</SelectItem>
                          <SelectItem value="manual">Manual Only</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Checkbox id="auto-feature" />
                    <Label htmlFor="auto-feature" className="text-white">
                      Automatically feature high-performing articles
                    </Label>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Checkbox id="notify-changes" />
                    <Label htmlFor="notify-changes" className="text-white">
                      Notify administrators of featuring changes
                    </Label>
                  </div>
                  
                  <div className="pt-4 border-t border-gray-600">
                    <Button className="bg-amber-600 hover:bg-amber-700">
                      <Save className="h-4 w-4 mr-2" />
                      Save Settings
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>

      {/* Document Edit Dialog */}
      <Dialog open={showDocumentDialog} onOpenChange={setShowDocumentDialog}>
        <DialogContent className="bg-gray-800 border-gray-700 max-w-4xl max-h-[80vh] overflow-y-auto">
          {selectedDocument ? (
            <DocumentEditor
              documentId={selectedDocument.id}
              document={selectedDocument}
              onDocumentUpdated={(updatedDocument) => {
                // Update the document in the local state
                onDocumentsUpdate();
                setShowDocumentDialog(false);
              }}
              onClose={() => setShowDocumentDialog(false)}
            />
          ) : (
            <div className="p-4 text-white">
              <p>No document selected</p>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Delete Dialog */}
      <Dialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <DialogContent className="bg-gray-800 border-gray-600 text-white max-w-md">
          <DialogHeader>
            <DialogTitle className="text-red-400">Delete Document</DialogTitle>
            <DialogDescription className="text-gray-400">
              Are you sure you want to delete this document? This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          
          {documentToDelete && (
            <div className="space-y-4">
              <div className="bg-gray-700/50 border border-gray-600 rounded-lg p-4">
                <h4 className="font-semibold text-white mb-2">{documentToDelete.title}</h4>
                <p className="text-gray-400 text-sm">{documentToDelete.description}</p>
              </div>
              
              <div className="flex justify-end space-x-2">
                <Button 
                  variant="outline" 
                  onClick={() => {
                    setShowDeleteDialog(false);
                    setDocumentToDelete(null);
                  }}
                  disabled={isDeleting}
                >
                  Cancel
                </Button>
                <Button 
                  onClick={handleDeleteDocument}
                  disabled={isDeleting}
                  className="bg-red-600 hover:bg-red-700 text-white"
                >
                  {isDeleting ? 'Deleting...' : 'Delete Document'}
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Enhanced Document Upload Dialog */}
      <EnhancedDocumentUpload
        open={showAddDocumentDialog}
        onClose={() => setShowAddDocumentDialog(false)}
        onSuccess={() => {
          setShowAddDocumentDialog(false);
          onDocumentsUpdate();
        }}
      />

      {/* PDF Preview Modal */}
      {showPdfPreview && previewDocument && (
        <Dialog open={showPdfPreview} onOpenChange={setShowPdfPreview}>
          <DialogContent className="max-w-5xl h-[90vh] bg-gray-900 border-gray-700">
            <DialogHeader>
              <DialogTitle className="text-white flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Document Validation: {previewDocument.title}
              </DialogTitle>
              <DialogDescription className="text-gray-400">
                Review the document content and approve or reject for publication
              </DialogDescription>
            </DialogHeader>
            
            <div className="flex flex-col h-full">
              {/* Document Info Bar */}
              <div className="bg-gray-800/50 p-4 rounded-lg mb-4">
                <div className="flex justify-between items-center">
                  <div className="flex items-center gap-4">
                    <div>
                      <p className="text-white font-medium">{previewDocument.title}</p>
                      <p className="text-gray-400 text-sm">{previewDocument.description}</p>
                    </div>
                    <div className="flex gap-2">
                      {previewDocument.country_jurisdiction?.map((country: string) => (
                        <Badge key={country} variant="outline" className="text-xs">
                          {country}
                        </Badge>
                      ))}
                    </div>
                  </div>
                  
                  {/* Action Buttons */}
                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleDownloadPdf(previewDocument)}
                      className="text-blue-400 hover:text-blue-300"
                    >
                      <Download className="h-4 w-4 mr-1" />
                      Download
                    </Button>
                    <Button
                      size="sm"
                      className="bg-green-600 hover:bg-green-700 text-white"
                      onClick={() => {
                        handleApproveDocument(previewDocument.id);
                        setShowPdfPreview(false);
                      }}
                      disabled={processingAction?.docId === previewDocument.id}
                    >
                      <CheckCircle className="h-4 w-4 mr-1" />
                      Approve
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      className="text-red-400 hover:text-red-300 hover:bg-red-900/20 border-red-400"
                      onClick={() => {
                        handleRejectDocument(previewDocument.id);
                        setShowPdfPreview(false);
                      }}
                      disabled={processingAction?.docId === previewDocument.id}
                    >
                      <XCircle className="h-4 w-4 mr-1" />
                      Reject
                    </Button>
                  </div>
                </div>
              </div>
              
              {/* PDF Viewer */}
              <div className="flex-1 bg-gray-800 rounded-lg overflow-hidden">
                <iframe
                  src={pdfUrl}
                  className="w-full h-full border-0"
                  title={`PDF Preview: ${previewDocument.title}`}
                />
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}

      {/* Blog Post Delete Confirmation Dialog */}
      <AlertDialog open={showBlogDeleteDialog} onOpenChange={setShowBlogDeleteDialog}>
        <AlertDialogContent className="bg-gray-800 border-gray-700">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-white">
              Delete Blog Post
            </AlertDialogTitle>
            <AlertDialogDescription className="text-gray-400">
              Are you sure you want to delete "{blogPostToDelete?.title}"? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel 
              className="border-gray-600 text-gray-300 hover:bg-gray-700"
              disabled={isDeletingBlogPost}
            >
              Cancel
            </AlertDialogCancel>
            <AlertDialogAction 
              onClick={handleDeleteBlogPost}
              disabled={isDeletingBlogPost}
              className="bg-red-600 hover:bg-red-700 text-white"
            >
              {isDeletingBlogPost ? 'Deleting...' : 'Delete'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

export default KnowledgeBaseAdminTab;
