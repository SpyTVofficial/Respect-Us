import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { ChevronDown, ChevronRight, Edit, Trash2, Plus, FileText, Target, Settings, Eye, EyeOff, MoreHorizontal, Edit3, Copy, Save, X, AlertTriangle, CheckCircle, XCircle, Download, Upload, TreePine } from 'lucide-react';
import { toast } from 'sonner';
import brain from 'brain';
import EditOutcomeDialog from 'components/EditOutcomeDialog';
import type { 
  AppApisClassificationClassificationTree as ClassificationTree, 
  TreeNode, 
  NodeOption, 
  ClassificationOutcome, 
  TreeNodeCreate,
  NodeOptionCreate,
  NodeOptionUpdate,
  ClassificationOutcomeCreate,
  ClassificationNote, 
  CreateNoteRequest,
  UpdateNoteRequest
} from '../brain/data-contracts';

const ProductClassificationAdminComprehensive: React.FC = () => {
  const [classificationTrees, setClassificationTrees] = useState<ClassificationTree[]>([]);
  const [selectedTree, setSelectedTree] = useState<ClassificationTree | null>(null);
  const [treeNodes, setTreeNodes] = useState<TreeNode[]>([]);
  const [nodeOptions, setNodeOptions] = useState<{ [nodeId: string]: NodeOption[] }>({});
  const [loading, setLoading] = useState(true);
  
  // Add new state for notes and outcomes
  const [classificationNotes, setClassificationNotes] = useState<ClassificationNote[]>([]);
  const [classificationOutcomes, setClassificationOutcomes] = useState<ClassificationOutcome[]>([]);
  const [notesLoading, setNotesLoading] = useState(false);
  const [outcomesLoading, setOutcomesLoading] = useState(false);
  
  // Add new state for editing
  const [editingTree, setEditingTree] = useState<ClassificationTree | null>(null);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [editForm, setEditForm] = useState({ name: '', description: '' });
  const [saving, setSaving] = useState(false);
  
  // Add new state for editing nodes
  const [editingNode, setEditingNode] = useState<TreeNode | null>(null);
  const [showEditNodeDialog, setShowEditNodeDialog] = useState(false);
  const [editNodeForm, setEditNodeForm] = useState({
    node_key: '',
    title: '',
    description: '',
    question_text: '',
    question_type: '',
    parent_node_id: ''
  });
  const [updatingNode, setUpdatingNode] = useState(false);
  
  // Add new state for editing notes
  const [editingNote, setEditingNote] = useState<ClassificationNote | null>(null);
  const [showEditNoteDialog, setShowEditNoteDialog] = useState(false);
  const [editNoteForm, setEditNoteForm] = useState({ note_key: '', title: '', content: '' });
  
  // States for managing options
  const [showManageOptionsDialog, setShowManageOptionsDialog] = useState(false);
  const [managingOptionsForNode, setManagingOptionsForNode] = useState<TreeNode | null>(null);
  const [currentNodeOptions, setCurrentNodeOptions] = useState<NodeOption[]>([]);
  const [loadingOptions, setLoadingOptions] = useState(false);
  
  // State for creating new options
  const [newOptionData, setNewOptionData] = useState({
    option_text: '',
    option_value: '',
    routing_rule: '',
    display_order: 0,
    notes: ''
  });
  const [creatingOption, setCreatingOption] = useState(false);
  
  // Add expanded nodes state
  const [expandedNodes, setExpandedNodes] = useState<Set<string>>(new Set());
  
  // Add state for selected classification tree in create node dialog
  const [selectedClassificationTree, setSelectedClassificationTree] = useState<ClassificationTree | null>(null);
  const [isCreateNodeDialogOpen, setIsCreateNodeDialogOpen] = useState(false);
  
  // Add state for selected tab and current content
  const [activeTab, setActiveTab] = useState('trees');
  
  // Add states for creating
  const [isCreateTreeDialogOpen, setIsCreateTreeDialogOpen] = useState(false);
  const [isCreateIntroTreeDialogOpen, setIsCreateIntroTreeDialogOpen] = useState(false);
  const [isCreateOutcomeOpen, setIsCreateOutcomeOpen] = useState(false);
  const [isCreateNoteOpen, setIsCreateNoteOpen] = useState(false);
  
  // Add loading states for creation
  const [creatingTree, setCreatingTree] = useState(false);
  const [creatingIntroTree, setCreatingIntroTree] = useState(false);
  const [creatingNode, setCreatingNode] = useState(false);
  const [creatingIntroNode, setCreatingIntroNode] = useState(false);
  const [creatingOutcome, setCreatingOutcome] = useState(false);
  const [creatingNote, setCreatingNote] = useState(false);
  
  // Add data for creating new items
  const [newTreeData, setNewTreeData] = useState({
    name: '',
    description: '',
    jurisdiction: '',
    category: '',
    is_introduction_template: false
  });
  
  // Add state for Introduction Tree creation
  const [newIntroTreeData, setNewIntroTreeData] = useState({
    name: '',
    description: '',
    jurisdiction: '',
    category: ''
  });
  
  const [newNodeData, setNewNodeData] = useState({
    node_key: '',
    title: '',
    description: '',
    question_text: '',
    question_type: 'multiple_choice',
    display_order: 0,
    is_root: false,
    parent_node_id: null as string | null,
    notes: ''
  });
  
  const [newOutcomeData, setNewOutcomeData] = useState({
    outcome_code: '',
    outcome_title: '',
    description: '',
    regulatory_basis: '',
    outcome_text: '',
    classification_details: '',
    requirements: '',
    exemptions: '',
    additional_notes: ''
  });
  
  const [newNoteData, setNewNoteData] = useState({
    note_key: '',
    title: '',
    content: ''
  });

  // Add newIntroNodeData state for Introduction Trees
  const [newIntroNodeData, setNewIntroNodeData] = useState({
    node_key: '',
    title: '',
    description: '',
    question_text: '',
    question_type: 'multiple_choice',
    display_order: 0,
    is_root: false,
    parent_node_id: null as string | null,
    notes: '',
    routing_rule: ''
  });
  
  // Add states for editing outcomes
  const [editingOutcome, setEditingOutcome] = useState<ClassificationOutcome | null>(null);
  const [isEditOutcomeOpen, setIsEditOutcomeOpen] = useState(false);
  
  // Node visibility states
  const [nodeVisibility, setNodeVisibility] = useState<{ [nodeId: string]: boolean }>({});
  
  // Add new state for introduction trees
  const [introductionTrees, setIntroductionTrees] = useState<ClassificationTree[]>([]);
  const [selectedIntroTree, setSelectedIntroTree] = useState<ClassificationTree | null>(null);
  const [introTreeNodes, setIntroTreeNodes] = useState<TreeNode[]>([]);
  const [introLoading, setIntroLoading] = useState(true);
  
  // Add state for selected introduction tree in create node dialog
  const [selectedIntroClassificationTree, setSelectedIntroClassificationTree] = useState<ClassificationTree | null>(null);
  const [isCreateIntroNodeDialogOpen, setIsCreateIntroNodeDialogOpen] = useState(false);
  
  // Copy all the handlers and functions from the original file...
  const handleCreateTree = async () => {
    try {
      setCreatingTree(true);
      const response = await brain.create_classification_tree(newTreeData);
      if (response.ok) {
        toast.success('Classification tree created successfully');
        setIsCreateTreeDialogOpen(false);
        setNewTreeData({
          name: '',
          description: '',
          jurisdiction: '',
          category: '',
          is_introduction_template: false
        });
        loadClassificationData();
      } else {
        const errorData = await response.json().catch(() => null);
        toast.error(`Failed to create tree: ${errorData?.detail || 'Unknown error'}`);
      }
    } catch (error) {
      console.error('Error creating tree:', error);
      toast.error('Failed to create classification tree');
    } finally {
      setCreatingTree(false);
    }
  };
  
  const handleCreateNode = async () => {
    if (!selectedClassificationTree) {
      toast.error('Please select a classification tree first');
      return;
    }

    try {
      setCreatingNode(true);
      const response = await brain.create_tree_node(
        { treeId: selectedClassificationTree.id },
        newNodeData
      );
      if (response.ok) {
        toast.success('Tree node created successfully');
        setIsCreateNodeDialogOpen(false);
        setNewNodeData({
          node_key: '',
          title: '',
          description: '',
          question_text: '',
          question_type: 'multiple_choice',
          display_order: 0,
          is_root: false,
          parent_node_id: null as string | null,
          notes: ''
        });
        // Refresh the tree data
        if (selectedTree?.id === selectedClassificationTree.id) {
          loadTreeData(selectedClassificationTree.id);
        }
      } else {
        const errorData = await response.json().catch(() => null);
        toast.error(`Failed to create node: ${errorData?.detail || 'Unknown error'}`);
      }
    } catch (error) {
      console.error('Error creating node:', error);
      toast.error('Failed to create tree node');
    } finally {
      setCreatingNode(false);
    }
  };
  
  const handleCreateIntroNode = async () => {
    if (!selectedIntroClassificationTree) {
      toast.error('Please select an introduction tree first');
      return;
    }

    try {
      setCreatingIntroNode(true);
      const response = await brain.create_introduction_tree_node(
        { treeId: selectedIntroClassificationTree.id },
        newIntroNodeData
      );
      if (response.ok) {
        toast.success('Introduction tree node created successfully');
        setIsCreateIntroNodeDialogOpen(false);
        setNewIntroNodeData({
          node_key: '',
          title: '',
          description: '',
          question_text: '',
          question_type: 'multiple_choice',
          display_order: 0,
          is_root: false,
          parent_node_id: null as string | null,
          notes: '',
          routing_rule: ''
        });
        // Refresh the intro tree data
        if (selectedIntroTree?.id === selectedIntroClassificationTree.id) {
          loadIntroTreeData(selectedIntroClassificationTree.id);
        }
      } else {
        const errorData = await response.json().catch(() => null);
        toast.error(`Failed to create introduction node: ${errorData?.detail || 'Unknown error'}`);
      }
    } catch (error) {
      console.error('Error creating introduction node:', error);
      toast.error('Failed to create introduction tree node');
    } finally {
      setCreatingIntroNode(false);
    }
  };
  
  // Add all other handlers from the original file...
  const loadClassificationData = async () => {
    try {
      setLoading(true);
      const response = await brain.list_classification_trees();
      if (response.ok) {
        const data = await response.json();
        setClassificationTrees(data);
      } else {
        toast.error('Failed to load classification trees');
      }
    } catch (error) {
      console.error('Error loading classification data:', error);
      toast.error('Failed to load classification data');
    } finally {
      setLoading(false);
    }
  };
  
  const loadTreeData = async (treeId: string) => {
    try {
      console.log('🔄 Loading tree data for tree ID:', treeId);
      setLoading(true);
      const response = await brain.list_tree_nodes({ treeId });
      if (response.ok) {
        const data = await response.json();
        console.log('✅ Tree data loaded:', data.length, 'nodes');
        setTreeNodes(data);
        
        // Load options for each node
        const optionsData: { [nodeId: string]: NodeOption[] } = {};
        for (const node of data) {
          try {
            const optionsResponse = await brain.list_node_options({ nodeId: node.id });
            if (optionsResponse.ok) {
              const options = await optionsResponse.json();
              optionsData[node.id] = options;
            }
          } catch (error) {
            console.error(`Error loading options for node ${node.id}:`, error);
          }
        }
        setNodeOptions(optionsData);
      } else {
        console.error('❌ Failed to load tree data:', response.status);
        toast.error('Failed to load tree data');
      }
    } catch (error) {
      console.error('💥 Error loading tree data:', error);
      toast.error('Error loading tree data');
    } finally {
      setLoading(false);
    }
  };
  
  const loadIntroTreeData = async (treeId: string) => {
    try {
      console.log('🔄 Loading introduction tree data for tree ID:', treeId);
      setIntroLoading(true);
      const response = await brain.list_introduction_tree_nodes({ treeId });
      if (response.ok) {
        const data = await response.json();
        console.log('✅ Introduction tree data loaded:', data.length, 'nodes');
        setIntroTreeNodes(data);
        
        // Load options for each node
        const optionsData: { [nodeId: string]: NodeOption[] } = {};
        for (const node of data) {
          try {
            const optionsResponse = await brain.list_introduction_node_options({ nodeId: node.id });
            if (optionsResponse.ok) {
              const options = await optionsResponse.json();
              optionsData[node.id] = options;
            }
          } catch (error) {
            console.error(`Error loading options for introduction node ${node.id}:`, error);
          }
        }
        setIntroNodeOptions(optionsData);
      } else {
        console.error('❌ Failed to load introduction tree data:', response.status);
        toast.error('Failed to load introduction tree data');
      }
    } catch (error) {
      console.error('💥 Error loading introduction tree data:', error);
      toast.error('Error loading introduction tree data');
    } finally {
      setIntroLoading(false);
    }
  };
  
  const loadClassificationNotes = async () => {
    try {
      setNotesLoading(true);
      console.log('🔄 ProductClassificationAdminSimple: Loading notes globally');
      const response = await brain.list_classification_notes();
      if (response.ok) {
        const data = await response.json();
        console.log('📋 ProductClassificationAdminSimple: Loaded notes:', data.length);
        setClassificationNotes(data);
      } else {
        console.error('❌ ProductClassificationAdminSimple: Failed to load notes');
        toast.error('Failed to load classification notes');
      }
    } catch (error) {
      console.error('💥 ProductClassificationAdminSimple: Error loading notes:', error);
      toast.error('Failed to load classification notes');
    } finally {
      setNotesLoading(false);
    }
  };
  
  const loadClassificationOutcomes = async () => {
    try {
      setOutcomesLoading(true);
      // For now, load all outcomes by getting them from all trees
      // First get all trees, then load outcomes for each
      const allOutcomes: ClassificationOutcome[] = [];
      
      for (const tree of classificationTrees) {
        try {
          const response = await brain.list_classification_outcomes({ treeId: tree.id });
          if (response.ok) {
            const data = await response.json();
            allOutcomes.push(...data);
          }
        } catch (error) {
          console.error(`Error loading outcomes for tree ${tree.id}:`, error);
        }
      }
      
      setClassificationOutcomes(allOutcomes);
    } catch (error) {
      console.error('Error loading outcomes:', error);
      toast.error('Failed to load classification outcomes');
    } finally {
      setOutcomesLoading(false);
    }
  };
  
  // Add loadIntroductionTrees function
  const loadIntroductionTrees = async () => {
    try {
      setIntroLoading(true);
      const response = await brain.list_introduction_trees();
      if (response.ok) {
        const data = await response.json();
        console.log('✅ Introduction trees loaded:', data.length, 'trees');
        setIntroductionTrees(data);
      } else {
        console.error('❌ Failed to load introduction trees:', response.status);
        toast.error('Failed to load introduction trees');
      }
    } catch (error) {
      console.error('❌ Error loading introduction trees:', error);
      toast.error('Error loading introduction trees');
    } finally {
      setIntroLoading(false);
    }
  };
  
  useEffect(() => {
    loadClassificationData();
    loadClassificationNotes();
    loadClassificationOutcomes();
    loadIntroductionTrees();
  }, []);
  
  // Handle tree selection
  const handleTreeSelect = (tree: ClassificationTree) => {
    setSelectedTree(tree);
    setSelectedClassificationTree(tree); // Add this line to enable DUPLICATE functionality
    loadTreeData(tree.id);
  };
  
  const loadNodeOptions = async (nodeId: string) => {
    try {
      setLoadingOptions(true);
      const response = await brain.list_node_options({ nodeId });
      if (response.ok) {
        const data = await response.json();
        setCurrentNodeOptions(data);
      } else {
        toast.error('Failed to load node options');
      }
    } catch (error) {
      console.error('Error loading node options:', error);
      toast.error('Failed to load node options');
    } finally {
      setLoadingOptions(false);
    }
  };
  
  const handleUpdateNode = async () => {
    if (!editingNode) {
      toast.error('No node selected for update');
      return;
    }

    try {
      setUpdatingNode(true);
      const response = await brain.update_tree_node(
        { nodeId: editingNode.id },
        editNodeForm
      );
      if (response.ok) {
        toast.success('Node updated successfully');
        setShowEditNodeDialog(false);
        setEditNodeForm({
          node_key: '',
          title: '',
          description: '',
          question_text: '',
          question_type: '',
          parent_node_id: ''
        });
        // Refresh the tree data
        if (selectedTree?.id === selectedClassificationTree.id) {
          loadTreeData(selectedClassificationTree.id);
        }
      } else {
        const errorData = await response.json().catch(() => null);
        toast.error(`Failed to update node: ${errorData?.detail || 'Unknown error'}`);
      }
    } catch (error) {
      console.error('Error updating node:', error);
      toast.error('Failed to update tree node');
    } finally {
      setUpdatingNode(false);
    }
  };
  
  const buildTreeStructure = (nodes: TreeNode[]) => {
    // Sort nodes alphabetically by node_key
    const sortedNodes = [...nodes].sort((a, b) => a.node_key.localeCompare(b.node_key));
    
    const nodeMap = new Map<string, TreeNode & { children: TreeNode[] }>();
    const rootNodes: (TreeNode & { children: TreeNode[] })[] = [];
    
    // First pass: create all nodes with children arrays
    for (const node of sortedNodes) {
      nodeMap.set(node.id, { ...node, children: [] });
    }
    
    // Second pass: build the tree structure
    for (const node of sortedNodes) {
      const nodeWithChildren = nodeMap.get(node.id)!;
      
      if (node.parent_node_id && nodeMap.has(node.parent_node_id)) {
        const parent = nodeMap.get(node.parent_node_id)!;
        parent.children.push(nodeWithChildren);
        // Sort children alphabetically by node_key
        parent.children.sort((a, b) => a.node_key.localeCompare(b.node_key));
      } else {
        rootNodes.push(nodeWithChildren);
      }
    }
    
    // Sort root nodes alphabetically by node_key
    return rootNodes.sort((a, b) => a.node_key.localeCompare(b.node_key));
  };
  
  // Handle introduction tree selection
  const handleIntroTreeSelect = (tree: ClassificationTree) => {
    setSelectedIntroTree(tree);
    setSelectedIntroClassificationTree(tree); // Add this line to enable DUPLICATE functionality
    loadIntroTreeData(tree.id);
  };
  
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 text-white p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-amber-400 mb-2">Product Classification Administration</h1>
          <p className="text-gray-300">Manage classification trees, decision nodes, outcomes, and regulatory notes</p>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid grid-cols-5 w-fit bg-gray-800 border border-gray-700">
            <TabsTrigger value="trees" className="data-[state=active]:bg-amber-600 data-[state=active]:text-white">
              <TreePine className="w-4 h-4 mr-2" />
              Classification Trees
            </TabsTrigger>
            <TabsTrigger value="introduction" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white">
              <FileText className="w-4 h-4 mr-2" />
              Introduction Trees
            </TabsTrigger>
            <TabsTrigger value="outcomes" className="data-[state=active]:bg-purple-600 data-[state=active]:text-white">
              <Target className="w-4 h-4 mr-2" />
              Outcomes
            </TabsTrigger>
            <TabsTrigger value="notes" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white">
              <FileText className="w-4 h-4 mr-2" />
              Notes
            </TabsTrigger>
            <TabsTrigger value="tools" className="data-[state=active]:bg-green-600 data-[state=active]:text-white">
              <Settings className="w-4 h-4 mr-2" />
              Tools
            </TabsTrigger>
          </TabsList>

          <TabsContent value="trees" className="space-y-6">
            <Card className="bg-gray-800/50 border-gray-700">
              <CardHeader>
                <div className="flex justify-between items-center">
                  <CardTitle className="text-amber-400">Classification Trees</CardTitle>
                  <Button 
                    onClick={() => setIsCreateTreeDialogOpen(true)}
                    className="bg-amber-600 hover:bg-amber-700 text-white"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Create Tree
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                {loading ? (
                  <p className="text-gray-400">Loading classification trees...</p>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {classificationTrees.map((tree) => (
                      <div
                        key={tree.id}
                        className={`p-4 border rounded-lg cursor-pointer transition-all ${
                          selectedTree?.id === tree.id
                            ? 'border-amber-500 bg-amber-500/10'
                            : 'border-gray-600 hover:border-gray-500 bg-gray-800/30'
                        }`}
                        onClick={() => handleTreeSelect(tree)}
                      >
                        <h3 className="font-semibold text-white mb-2">{tree.name}</h3>
                        <p className="text-gray-400 text-sm mb-2">{tree.description}</p>
                        <div className="flex gap-2 flex-wrap">
                          <Badge variant="outline" className="text-xs">{tree.jurisdiction}</Badge>
                          <Badge variant="outline" className="text-xs">{tree.category}</Badge>
                        </div>
                        
                        {selectedTree?.id === tree.id && (
                          <div className="mt-4 pt-4 border-t border-gray-600">
                            <Button
                              onClick={(e) => {
                                e.stopPropagation();
                                setSelectedClassificationTree(tree);
                                setIsCreateNodeDialogOpen(true);
                              }}
                              className="bg-amber-600 hover:bg-amber-700 text-white w-full"
                            >
                              <Plus className="w-4 h-4 mr-2" />
                              Add Node
                            </Button>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            {selectedTree && (
              <Card className="bg-gray-800/50 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-amber-400">Tree Structure: {selectedTree.name}</CardTitle>
                </CardHeader>
                <CardContent>
                  {treeNodes.length === 0 ? (
                    <p className="text-gray-400">No nodes found in this tree.</p>
                  ) : (
                    <div className="space-y-2">
                      {buildTreeStructure(treeNodes).map((node) => (
                        <div key={node.id} className="border border-gray-600 rounded-lg p-4 bg-gray-800/30">
                          <div className="flex justify-between items-start">
                            <div className="flex-1">
                              <h4 className="font-semibold text-white">{node.title}</h4>
                              <p className="text-gray-400 text-sm mt-1">{node.description}</p>
                              <div className="flex items-center gap-2 mt-2">
                                <Badge variant="outline" className="text-xs">{node.node_key}</Badge>
                                <Badge variant="outline" className="text-xs">{node.question_type}</Badge>
                              </div>
                            </div>
                            <div className="flex gap-2">
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => {
                                  setEditingNode(node);
                                  setEditNodeForm({
                                    node_key: node.node_key,
                                    title: node.title,
                                    description: node.description || '',
                                    question_text: node.question_text,
                                    question_type: node.question_type,
                                    parent_node_id: node.parent_node_id || ''
                                  });
                                  setShowEditNodeDialog(true);
                                }}
                                className="border-gray-600 text-gray-300 hover:bg-gray-700"
                                title="Edit Node"
                              >
                                <Edit3 className="w-4 h-4" />
                              </Button>
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={async () => {
                                  console.log('📋 DUPLICATE button clicked for node:', node.id, node.title);
                                  console.log('🌳 Current selectedTree:', selectedTree?.id, selectedTree?.name);
                                  console.log('🌳 Current selectedClassificationTree:', selectedClassificationTree?.id, selectedClassificationTree?.name);
                                  
                                  // Use selectedTree as fallback if selectedClassificationTree is null
                                  const treeToUse = selectedClassificationTree || selectedTree;
                                  
                                  if (!treeToUse) {
                                    console.error('❌ No classification tree selected');
                                    toast.error('Please select a classification tree first by clicking on a tree in the left panel');
                                    return;
                                  }
                                  
                                  try {
                                    console.log('📋 Attempting to duplicate node:', {
                                      nodeId: node.id,
                                      treeId: treeToUse.id,
                                      originalKey: node.node_key,
                                      originalTitle: node.title
                                    });
                                    
                                    const duplicateData: TreeNodeCreate = {
                                      node_key: `${node.node_key}_copy_${Date.now()}`,
                                      title: `${node.title} (Copy)`,
                                      description: node.description || null,
                                      question_text: node.question_text,
                                      question_type: node.question_type,
                                      parent_node_id: node.parent_node_id || null,
                                      display_order: (node.display_order || 0) + 1,
                                      is_root: false,
                                      notes: node.notes || null
                                    };
                                    
                                    console.log('📋 Duplicate data being sent:', duplicateData);
                                    
                                    const response = await brain.create_tree_node(
                                      { treeId: treeToUse.id },
                                      duplicateData
                                    );
                                    
                                    console.log('📋 Duplicate response:', response.status, response.ok);
                                    
                                    if (response.ok) {
                                      console.log('✅ Node duplicated successfully');
                                      toast.success('Node duplicated successfully');
                                      console.log('🔄 Reloading tree data for:', treeToUse.id);
                                      await loadTreeData(treeToUse.id);
                                    } else {
                                      const errorData = await response.json().catch(() => null);
                                      console.error('❌ Duplicate failed:', response.status, errorData);
                                      toast.error(`Failed to duplicate node: ${errorData?.detail || 'Unknown error'}`);
                                    }
                                  } catch (error) {
                                    console.error('💥 Error duplicating node:', error);
                                    toast.error('Failed to duplicate node');
                                  }
                                }}
                                className="border-gray-600 text-gray-300 hover:bg-gray-700"
                                title="Duplicate Node"
                              >
                                <Copy className="w-4 h-4" />
                              </Button>
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => {
                                  setManagingOptionsForNode(node);
                                  setShowManageOptionsDialog(true);
                                  // Load options for this node when dialog opens
                                  loadNodeOptions(node.id);
                                }}
                                className="border-gray-600 text-gray-300 hover:bg-gray-700"
                                title="Manage Options"
                              >
                                <Settings className="w-4 h-4" />
                              </Button>
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={async () => {
                                  console.log('🔥 DELETE button clicked for node:', node.id, node.title);
                                  if (window.confirm(`Are you sure you want to delete the node "${node.title}"? This action cannot be undone.`)) {
                                    try {
                                      console.log('🗑️ Attempting to delete node:', node.id);
                                      const response = await brain.delete_tree_node({ nodeId: node.id });
                                      console.log('🗑️ Delete response:', response.status, response.ok);
                                      
                                      if (response.ok) {
                                        console.log('✅ Node deleted successfully');
                                        toast.success('Node deleted successfully');
                                        if (selectedClassificationTree) {
                                          console.log('🔄 Reloading tree data for:', selectedClassificationTree.id);
                                          await loadTreeData(selectedClassificationTree.id);
                                        }
                                      } else {
                                        const errorData = await response.json().catch(() => null);
                                        console.error('❌ Delete failed:', response.status, errorData);
                                        toast.error(`Failed to delete node: ${errorData?.detail || 'Unknown error'}`);
                                      }
                                    } catch (error) {
                                      console.error('💥 Error deleting node:', error);
                                      toast.error('Failed to delete node');
                                    }
                                  } else {
                                    console.log('❌ Delete cancelled by user');
                                  }
                                }}
                                className="border-gray-600 text-red-400 hover:bg-red-900/20 hover:border-red-500"
                                title="Delete Node"
                              >
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="outcomes">
            <Card className="bg-gray-800/50 border-gray-700">
              <CardHeader>
                <div className="flex justify-between items-center">
                  <CardTitle className="text-purple-400">Classification Outcomes</CardTitle>
                  <Button 
                    onClick={() => setIsCreateOutcomeOpen(true)}
                    className="bg-purple-600 hover:bg-purple-700 text-white"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Create Outcome
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                {outcomesLoading ? (
                  <p className="text-gray-400">Loading outcomes...</p>
                ) : (
                  <div className="space-y-4">
                    {classificationOutcomes.map((outcome) => (
                      <div key={outcome.id} className="border border-gray-600 rounded-lg p-4 bg-gray-800/30">
                        <div className="flex justify-between items-start">
                          <div className="flex-1">
                            <h4 className="font-semibold text-white">{outcome.outcome_title}</h4>
                            <p className="text-gray-400 text-sm mt-1">{outcome.description}</p>
                            <Badge variant="outline" className="text-xs mt-2">{outcome.outcome_code}</Badge>
                          </div>
                          <div className="flex gap-2">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => {
                                setEditingOutcome(outcome);
                                setIsEditOutcomeOpen(true);
                              }}
                              className="border-gray-600 text-gray-300 hover:bg-gray-700"
                            >
                              <Edit className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="notes">
            <Card className="bg-gray-800/50 border-gray-700">
              <CardHeader>
                <div className="flex justify-between items-center">
                  <CardTitle className="text-blue-400">Classification Notes</CardTitle>
                  <Button 
                    onClick={() => setIsCreateNoteOpen(true)}
                    className="bg-blue-600 hover:bg-blue-700 text-white"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Create Note
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                {notesLoading ? (
                  <p className="text-gray-400">Loading notes...</p>
                ) : (
                  <div className="space-y-4">
                    {classificationNotes.map((note) => (
                      <div key={note.id} className="border border-gray-600 rounded-lg p-4 bg-gray-800/30">
                        <div className="flex justify-between items-start">
                          <div className="flex-1">
                            <h4 className="font-semibold text-white">{note.title}</h4>
                            <p className="text-gray-400 text-sm mt-1">{note.content}</p>
                            <Badge variant="outline" className="text-xs mt-2">{note.note_key}</Badge>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="tools">
            <Card className="bg-gray-800/50 border-gray-700">
              <CardHeader>
                <CardTitle className="text-green-400">Import/Export Tools</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <h3 className="text-white font-semibold">Export Data</h3>
                    <div className="space-y-2">
                      <Button className="w-full bg-green-600 hover:bg-green-700 text-white">
                        <Download className="w-4 h-4 mr-2" />
                        Export Trees to Excel
                      </Button>
                      <Button className="w-full bg-green-600 hover:bg-green-700 text-white">
                        <Download className="w-4 h-4 mr-2" />
                        Export Outcomes to Excel
                      </Button>
                    </div>
                  </div>
                  <div className="space-y-4">
                    <h3 className="text-white font-semibold">Import Data</h3>
                    <div className="space-y-2">
                      <Button className="w-full bg-blue-600 hover:bg-blue-700 text-white">
                        <Upload className="w-4 h-4 mr-2" />
                        Import from Excel
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="introduction" className="space-y-6">
            <Card className="bg-gray-800/50 border-gray-700">
              <CardHeader>
                <div className="flex justify-between items-center">
                  <CardTitle className="text-blue-400">Introduction Trees</CardTitle>
                  <Button 
                    onClick={() => setIsCreateIntroTreeDialogOpen(true)}
                    className="bg-blue-600 hover:bg-blue-700 text-white"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Create Introduction Tree
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                {introLoading ? (
                  <p className="text-gray-400">Loading introduction trees...</p>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {introductionTrees.map((tree) => (
                      <div
                        key={tree.id}
                        className={`p-4 border rounded-lg cursor-pointer transition-all ${
                          selectedIntroTree?.id === tree.id
                            ? 'border-blue-500 bg-blue-500/10'
                            : 'border-gray-600 hover:border-gray-500 bg-gray-800/30'
                        }`}
                        onClick={() => handleIntroTreeSelect(tree)}
                      >
                        <h3 className="font-semibold text-white mb-2">{tree.name}</h3>
                        <p className="text-gray-400 text-sm mb-2">{tree.description}</p>
                        <div className="flex gap-2 flex-wrap">
                          <Badge variant="outline" className="text-xs">{tree.jurisdiction}</Badge>
                          <Badge variant="outline" className="text-xs">{tree.category}</Badge>
                          <Badge className="bg-blue-500/20 text-blue-300 border-blue-500/30 text-xs">Introduction</Badge>
                        </div>
                        
                        {selectedIntroTree?.id === tree.id && (
                          <div className="mt-4 pt-4 border-t border-gray-600">
                            <Button
                              onClick={(e) => {
                                e.stopPropagation();
                                setSelectedIntroClassificationTree(tree);
                                setIsCreateIntroNodeDialogOpen(true);
                              }}
                              className="bg-blue-600 hover:bg-blue-700 text-white w-full"
                            >
                              <Plus className="w-4 h-4 mr-2" />
                              Add Node
                            </Button>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            {selectedIntroTree && (
              <Card className="bg-gray-800/50 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-blue-400">Tree Structure: {selectedIntroTree.name}</CardTitle>
                </CardHeader>
                <CardContent>
                  {introTreeNodes.length === 0 ? (
                    <p className="text-gray-400">No nodes found in this introduction tree.</p>
                  ) : (
                    <div className="space-y-2">
                      {buildTreeStructure(introTreeNodes).map((node) => (
                        <div key={node.id} className="border border-gray-600 rounded-lg p-4 bg-gray-800/30">
                          <div className="flex justify-between items-start">
                            <div className="flex-1">
                              <h4 className="font-semibold text-white">{node.title}</h4>
                              <p className="text-gray-400 text-sm mt-1">{node.description}</p>
                              <div className="flex items-center gap-2 mt-2">
                                <Badge variant="outline" className="text-xs">{node.node_key}</Badge>
                                <Badge variant="outline" className="text-xs">{node.question_type}</Badge>
                              </div>
                            </div>
                            <div className="flex gap-2">
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={async () => {
                                  console.log('📋 DUPLICATE button clicked for introduction node:', node.id, node.title);
                                  
                                  const treeToUse = selectedIntroClassificationTree || selectedIntroTree;
                                  
                                  if (!treeToUse) {
                                    console.error('❌ No introduction tree selected');
                                    toast.error('Please select an introduction tree first');
                                    return;
                                  }
                                  
                                  try {
                                    const duplicateData = {
                                      node_key: `${node.node_key}_copy_${Date.now()}`,
                                      title: `${node.title} (Copy)`,
                                      description: node.description || null,
                                      question_text: node.question_text,
                                      question_type: node.question_type,
                                      parent_node_id: node.parent_node_id || null,
                                      display_order: (node.display_order || 0) + 1,
                                      is_root: false,
                                      notes: node.notes || null
                                    };
                                    
                                    const response = await brain.create_introduction_tree_node(
                                      { treeId: treeToUse.id },
                                      duplicateData
                                    );
                                    
                                    if (response.ok) {
                                      toast.success('Introduction node duplicated successfully');
                                      await loadIntroTreeData(treeToUse.id);
                                    } else {
                                      const errorData = await response.json().catch(() => null);
                                      toast.error(`Failed to duplicate introduction node: ${errorData?.detail || 'Unknown error'}`);
                                    }
                                  } catch (error) {
                                    console.error('💥 Error duplicating introduction node:', error);
                                    toast.error('Failed to duplicate introduction node');
                                  }
                                }}
                                className="border-gray-600 text-gray-300 hover:bg-gray-700"
                                title="Duplicate Node"
                              >
                                <Copy className="w-4 h-4" />
                              </Button>
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={async () => {
                                  if (window.confirm(`Are you sure you want to delete the introduction node "${node.title}"? This action cannot be undone.`)) {
                                    try {
                                      const response = await brain.delete_introduction_tree_node({ nodeId: node.id });
                                      
                                      if (response.ok) {
                                        toast.success('Introduction node deleted successfully');
                                        if (selectedIntroClassificationTree) {
                                          await loadIntroTreeData(selectedIntroClassificationTree.id);
                                        }
                                      } else {
                                        const errorData = await response.json().catch(() => null);
                                        toast.error(`Failed to delete introduction node: ${errorData?.detail || 'Unknown error'}`);
                                      }
                                    } catch (error) {
                                      console.error('💥 Error deleting introduction node:', error);
                                      toast.error('Failed to delete introduction node');
                                    }
                                  }
                                }}
                                className="border-gray-600 text-red-400 hover:bg-red-900/20 hover:border-red-500"
                                title="Delete Node"
                              >
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            )}
          </TabsContent>
        </Tabs>
      </div>

      {/* Create Tree Dialog */}
      {isCreateTreeDialogOpen && (
        <Dialog open={isCreateTreeDialogOpen} onOpenChange={setIsCreateTreeDialogOpen}>
          <DialogContent className="bg-gray-900 border-gray-700 text-white max-w-2xl">
            <DialogHeader>
              <DialogTitle className="text-amber-400">Create Classification Tree</DialogTitle>
              <DialogDescription className="text-gray-400">
                Create a new classification tree for product categorization
              </DialogDescription>
            </DialogHeader>
            
            <div className="space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-300">Tree Name *</label>
                <Input
                  value={newTreeData.name}
                  onChange={(e) => setNewTreeData({ ...newTreeData, name: e.target.value })}
                  className="bg-gray-900/50 border-gray-600 text-white placeholder:text-gray-400 focus:border-amber-500"
                  placeholder="Enter tree name"
                />
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-300">Description</label>
                <Textarea
                  value={newTreeData.description}
                  onChange={(e) => setNewTreeData({ ...newTreeData, description: e.target.value })}
                  className="bg-gray-900/50 border-gray-600 text-white placeholder:text-gray-400 focus:border-amber-500"
                  placeholder="Enter description"
                  rows={3}
                />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-300">Jurisdiction</label>
                  <Input
                    value={newTreeData.jurisdiction}
                    onChange={(e) => setNewTreeData({ ...newTreeData, jurisdiction: e.target.value })}
                    className="bg-gray-900/50 border-gray-600 text-white placeholder:text-gray-400 focus:border-amber-500"
                    placeholder="e.g., EU, US, Global"
                  />
                </div>
                
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-300">Category</label>
                  <Input
                    value={newTreeData.category}
                    onChange={(e) => setNewTreeData({ ...newTreeData, category: e.target.value })}
                    className="bg-gray-900/50 border-gray-600 text-white placeholder:text-gray-400 focus:border-amber-500"
                    placeholder="e.g., Dual-use, Military"
                  />
                </div>
              </div>
              
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="introduction-template"
                  checked={newTreeData.is_introduction_template}
                  onCheckedChange={(checked) => setNewTreeData({ ...newTreeData, is_introduction_template: !!checked })}
                  className="border-gray-600 text-amber-500"
                />
                <label htmlFor="introduction-template" className="text-sm font-medium text-gray-300 cursor-pointer">
                  Introduction Template
                </label>
              </div>
            </div>
            
            <div className="flex justify-end gap-2 pt-4">
              <Button
                variant="outline"
                onClick={() => setIsCreateTreeDialogOpen(false)}
                className="border-gray-600 text-gray-300 hover:bg-gray-700 hover:text-white"
                disabled={creatingTree}
              >
                Cancel
              </Button>
              <Button
                onClick={handleCreateTree}
                className="bg-amber-600 hover:bg-amber-700 text-white"
                disabled={creatingTree || !newTreeData.name.trim()}
              >
                {creatingTree ? 'Creating...' : 'Create Tree'}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      )}

      {/* COMPREHENSIVE Create Node Dialog */}
      {isCreateNodeDialogOpen && (
        <Dialog open={isCreateNodeDialogOpen} onOpenChange={setIsCreateNodeDialogOpen}>
          <DialogContent className="bg-gray-900 border-gray-700 text-white max-w-4xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="text-amber-400">Add Question/Node</DialogTitle>
              <DialogDescription className="text-gray-400">
                Add a new question or node to the classification tree: {selectedClassificationTree?.name}
              </DialogDescription>
            </DialogHeader>
            
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-300">Node Key *</label>
                  <Input
                    value={newNodeData.node_key}
                    onChange={(e) => setNewNodeData({ ...newNodeData, node_key: e.target.value })}
                    className="bg-gray-900/50 border-gray-600 text-white placeholder:text-gray-400 focus:border-amber-500"
                    placeholder="Unique identifier (e.g., 1.1, dual-use-check)"
                  />
                  <p className="text-xs text-gray-400">Must be unique within the tree (max 50 characters)</p>
                </div>
                
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-300">Question Type</label>
                  <Select
                    value={newNodeData.question_type}
                    onValueChange={(value) => setNewNodeData({ ...newNodeData, question_type: value })}
                  >
                    <SelectTrigger className="bg-gray-900/50 border-gray-600 text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-gray-800 border-gray-600">
                      <SelectItem value="multiple_choice">Multiple Choice</SelectItem>
                      <SelectItem value="yes_no">Yes/No</SelectItem>
                      <SelectItem value="text_input">Text Input</SelectItem>
                      <SelectItem value="numeric">Numeric</SelectItem>
                    </SelectContent>
                  </Select>
                  <p className="text-xs text-gray-400">How users will answer this question</p>
                </div>
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-300">Title *</label>
                <Input
                  value={newNodeData.title}
                  onChange={(e) => setNewNodeData({ ...newNodeData, title: e.target.value })}
                  className="bg-gray-900/50 border-gray-600 text-white placeholder:text-gray-400 focus:border-amber-500"
                  placeholder="Question or node title"
                />
                <p className="text-xs text-gray-400">Short, clear title for this question (max 500 characters)</p>
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-300">Question Text *</label>
                <Textarea
                  value={newNodeData.question_text}
                  onChange={(e) => setNewNodeData({ ...newNodeData, question_text: e.target.value })}
                  className="bg-gray-900/50 border-gray-600 text-white placeholder:text-gray-400 focus:border-amber-500 min-h-[100px]"
                  placeholder="The detailed question text that will be displayed to users"
                />
                <p className="text-xs text-gray-400">The full question that users will see and answer</p>
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-300">Description</label>
                <Textarea
                  value={newNodeData.description || ''}
                  onChange={(e) => setNewNodeData({ ...newNodeData, description: e.target.value })}
                  className="bg-gray-900/50 border-gray-600 text-white placeholder:text-gray-400 focus:border-amber-500"
                  placeholder="Optional description or additional context"
                  rows={3}
                />
                <p className="text-xs text-gray-400">Additional context or explanation for this question</p>
              </div>
              
              <div className="grid grid-cols-3 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-300">Parent Node</label>
                  <Select
                    value={newNodeData.parent_node_id || 'none'}
                    onValueChange={(value) => setNewNodeData({ ...newNodeData, parent_node_id: value === 'none' ? null : value })}
                  >
                    <SelectTrigger className="bg-gray-900/50 border-gray-600 text-white">
                      <SelectValue placeholder="Select parent node" />
                    </SelectTrigger>
                    <SelectContent className="bg-gray-800 border-gray-600">
                      <SelectItem value="none">No Parent (Root Level)</SelectItem>
                      {treeNodes.map((node) => (
                        <SelectItem key={node.id} value={node.id}>
                          {node.node_key} - {node.title}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <p className="text-xs text-gray-400">Which node leads to this question</p>
                </div>
                
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-300">Display Order</label>
                  <Input
                    type="number"
                    value={newNodeData.display_order}
                    onChange={(e) => setNewNodeData({ ...newNodeData, display_order: parseInt(e.target.value) || 0 })}
                    className="bg-gray-900/50 border-gray-600 text-white placeholder:text-gray-400 focus:border-amber-500"
                    placeholder="0"
                  />
                  <p className="text-xs text-gray-400">Order in which this appears</p>
                </div>
                
                <div className="space-y-2">
                  <div className="flex items-center space-x-2 mt-6">
                    <Checkbox
                      id="is-root"
                      checked={newNodeData.is_root}
                      onCheckedChange={(checked) => setNewNodeData({ ...newNodeData, is_root: !!checked })}
                      className="border-gray-600 text-amber-500"
                    />
                    <label htmlFor="is-root" className="text-sm font-medium text-gray-300 cursor-pointer">
                      Is Root Node
                    </label>
                  </div>
                  <p className="text-xs text-gray-400">Check if this is the starting node of the tree</p>
                </div>
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-300">Administrative Notes</label>
                <Textarea
                  value={newNodeData.notes || ''}
                  onChange={(e) => setNewNodeData({ ...newNodeData, notes: e.target.value })}
                  className="bg-gray-900/50 border-gray-600 text-white placeholder:text-gray-400 focus:border-amber-500"
                  placeholder="Internal notes for administrators (not visible to users)"
                  rows={2}
                />
                <p className="text-xs text-gray-400">Internal documentation for system administrators</p>
              </div>
            </div>

            {/* Notes Field */}
            <div className="space-y-2">
              <Label htmlFor="notes" className="text-sm font-medium text-white">
                Notes
              </Label>
              <Textarea
                id="notes"
                placeholder="Additional notes or comments about this node..."
                value={newNodeData.notes || ''}
                onChange={(e) => setNewNodeData({ ...newNodeData, notes: e.target.value })}
                className="bg-gray-800/50 border-gray-600 text-white placeholder-gray-400 focus:border-blue-500 focus:ring-blue-500/20 min-h-[80px] resize-none"
                rows={3}
              />
              <p className="text-xs text-gray-400">
                Optional field for additional information, regulatory context, or implementation notes
              </p>
            </div>

            <div className="flex justify-end space-x-3 pt-4 border-t border-gray-700">
              <Button
                variant="outline"
                onClick={() => setIsCreateNodeDialogOpen(false)}
                className="border-gray-600 text-gray-300 hover:bg-gray-700 hover:text-white"
                disabled={creatingNode}
              >
                Cancel
              </Button>
              <Button
                onClick={handleCreateNode}
                className="bg-amber-600 hover:bg-amber-700 text-white"
                disabled={creatingNode || !newNodeData.node_key.trim() || !newNodeData.title.trim() || !newNodeData.question_text.trim()}
              >
                {creatingNode ? 'Creating...' : 'Add Node'}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      )}

      {/* Edit Outcome Dialog */}
      <EditOutcomeDialog
        isOpen={isEditOutcomeOpen}
        onOpenChange={setIsEditOutcomeOpen}
        editingOutcome={editingOutcome}
        setEditingOutcome={setEditingOutcome}
        onSave={async (updatedOutcome) => {
          try {
            const response = await brain.update_classification_outcome(
              { outcomeId: updatedOutcome.id },
              updatedOutcome
            );
            if (response.ok) {
              toast.success('Outcome updated successfully');
              loadClassificationOutcomes();
            } else {
              toast.error('Failed to update outcome');
            }
          } catch (error) {
            console.error('Error updating outcome:', error);
            toast.error('Failed to update outcome');
          }
        }}
      />
      
      {/* Manage Options Dialog */}
      <Dialog open={showManageOptionsDialog} onOpenChange={setShowManageOptionsDialog}>
        <DialogContent className="bg-gray-900 border-gray-700 text-white max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-purple-400">Manage Node Options</DialogTitle>
            <DialogDescription className="text-gray-400">
              Configure options for node: {managingOptionsForNode?.node_key} - {managingOptionsForNode?.title}
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-6">
            {/* Create New Option */}
            <div className="border border-gray-700 rounded-lg p-4 bg-gray-800/30">
              <h4 className="text-white font-semibold mb-3">Add New Option</h4>
              <div className="grid grid-cols-2 gap-4 mb-4">
                <div>
                  <Label className="text-gray-300">Option Text *</Label>
                  <Input
                    value={newOptionData.option_text}
                    onChange={(e) => setNewOptionData({ ...newOptionData, option_text: e.target.value })}
                    placeholder="e.g., Yes, No, Not Applicable"
                    className="bg-gray-800 border-gray-600 text-white"
                  />
                </div>
                <div>
                  <Label className="text-gray-300">Option Value *</Label>
                  <Input
                    value={newOptionData.option_value}
                    onChange={(e) => setNewOptionData({ ...newOptionData, option_value: e.target.value })}
                    placeholder="e.g., yes, no, na"
                    className="bg-gray-800 border-gray-600 text-white"
                  />
                </div>
                <div>
                  <Label className="text-gray-300">Routing Rule</Label>
                  <Input
                    value={newOptionData.routing_rule}
                    onChange={(e) => setNewOptionData({ ...newOptionData, routing_rule: e.target.value })}
                    placeholder="e.g., NEXT_NODE_KEY or OUTCOME_CODE"
                    className="bg-gray-800 border-gray-600 text-white"
                  />
                </div>
                <div>
                  <Label className="text-gray-300">Display Order</Label>
                  <Input
                    type="number"
                    value={newOptionData.display_order}
                    onChange={(e) => setNewOptionData({ ...newOptionData, display_order: parseInt(e.target.value) || 0 })}
                    className="bg-gray-800 border-gray-600 text-white"
                  />
                </div>
              </div>
              <div>
                <Label className="text-gray-300">Notes</Label>
                <Textarea
                  value={newOptionData.notes}
                  onChange={(e) => setNewOptionData({ ...newOptionData, notes: e.target.value })}
                  placeholder="Optional notes about this option"
                  className="bg-gray-800 border-gray-600 text-white"
                  rows={3}
                />
              </div>
              <Button
                onClick={async () => {
                  if (!managingOptionsForNode || !newOptionData.option_text.trim() || !newOptionData.option_value.trim()) {
                    toast.error('Please fill in required fields');
                    return;
                  }
                  
                  try {
                    const response = await brain.create_node_option(
                      { nodeId: managingOptionsForNode.id },
                      {
                        option_text: newOptionData.option_text,
                        option_value: newOptionData.option_value,
                        routing_rule: newOptionData.routing_rule || '',
                        display_order: newOptionData.display_order,
                        regulatory_notes: [],
                        note: newOptionData.notes
                      }
                    );
                    
                    if (response.ok) {
                      toast.success('Option created successfully');
                      setNewOptionData({
                        option_text: '',
                        option_value: '',
                        routing_rule: '',
                        display_order: 0,
                        notes: ''
                      });
                      // Reload options for this node
                      if (managingOptionsForNode) {
                        loadNodeOptions(managingOptionsForNode.id);
                      }
                    } else {
                      toast.error('Failed to create option');
                    }
                  } catch (error) {
                    console.error('Error creating option:', error);
                    toast.error('Failed to create option');
                  }
                }}
                className="bg-purple-600 hover:bg-purple-700 text-white mt-4"
                disabled={!newOptionData.option_text.trim() || !newOptionData.option_value.trim()}
              >
                Add Option
              </Button>
            </div>

            {/* Existing Options */}
            <div className="border border-gray-700 rounded-lg p-4 bg-gray-800/30">
              <h4 className="text-white font-semibold mb-3">Existing Options</h4>
              {loadingOptions ? (
                <p className="text-gray-400">Loading options...</p>
              ) : currentNodeOptions.length === 0 ? (
                <p className="text-gray-400">No options configured for this node.</p>
              ) : (
                <div className="space-y-2">
                  {currentNodeOptions.map((option) => (
                    <div key={option.id} className="border border-gray-600 rounded p-3 bg-gray-800/50">
                      <div className="flex justify-between items-start">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <span className="font-medium text-white">{option.option_text}</span>
                            <Badge variant="outline" className="text-xs">{option.option_value}</Badge>
                          </div>
                          {option.routing_rule && (
                            <p className="text-sm text-blue-400">Routes to: {option.routing_rule}</p>
                          )}
                          {option.note && (
                            <p className="text-sm text-gray-400 mt-1">{option.note}</p>
                          )}
                        </div>
                        <div className="flex gap-1">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => {
                              // TODO: Implement edit option functionality
                              toast.info('Edit option functionality coming soon');
                            }}
                            className="border-gray-600 text-gray-300 hover:bg-gray-700"
                          >
                            <Edit3 className="w-3 h-3" />
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => {
                              // TODO: Implement delete option functionality
                              toast.info('Delete option functionality coming soon');
                            }}
                            className="border-gray-600 text-red-400 hover:bg-red-900/20 hover:border-red-500"
                          >
                            <Trash2 className="w-3 h-3" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
          
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setShowManageOptionsDialog(false)}
              className="text-gray-300 border-gray-600 hover:bg-gray-700"
            >
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Edit Node Dialog */}
      {showEditNodeDialog && (
        <Dialog open={showEditNodeDialog} onOpenChange={setShowEditNodeDialog}>
          <DialogContent className="bg-gray-900 border-gray-700 text-white max-w-4xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="text-amber-400">Edit Node</DialogTitle>
              <DialogDescription className="text-gray-400">
                Update the details of the selected node
              </DialogDescription>
            </DialogHeader>
            
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-300">Node Key *</label>
                  <Input
                    value={editNodeForm.node_key}
                    onChange={(e) => setEditNodeForm({ ...editNodeForm, node_key: e.target.value })}
                    className="bg-gray-900/50 border-gray-600 text-white placeholder:text-gray-400 focus:border-amber-500"
                    placeholder="Unique identifier (e.g., 1.1, dual-use-check)"
                  />
                  <p className="text-xs text-gray-400">Must be unique within the tree (max 50 characters)</p>
                </div>
                
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-300">Question Type</label>
                  <Select
                    value={editNodeForm.question_type}
                    onValueChange={(value) => setEditNodeForm({ ...editNodeForm, question_type: value })}
                  >
                    <SelectTrigger className="bg-gray-900/50 border-gray-600 text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-gray-800 border-gray-600">
                      <SelectItem value="multiple_choice">Multiple Choice</SelectItem>
                      <SelectItem value="yes_no">Yes/No</SelectItem>
                      <SelectItem value="text_input">Text Input</SelectItem>
                      <SelectItem value="numeric">Numeric</SelectItem>
                    </SelectContent>
                  </Select>
                  <p className="text-xs text-gray-400">How users will answer this question</p>
                </div>
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-300">Title *</label>
                <Input
                  value={editNodeForm.title}
                  onChange={(e) => setEditNodeForm({ ...editNodeForm, title: e.target.value })}
                  className="bg-gray-900/50 border-gray-600 text-white placeholder:text-gray-400 focus:border-amber-500"
                  placeholder="Question or node title"
                />
                <p className="text-xs text-gray-400">Short, clear title for this question (max 500 characters)</p>
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-300">Question Text *</label>
                <Textarea
                  value={editNodeForm.question_text}
                  onChange={(e) => setEditNodeForm({ ...editNodeForm, question_text: e.target.value })}
                  className="bg-gray-900/50 border-gray-600 text-white placeholder:text-gray-400 focus:border-amber-500 min-h-[100px]"
                  placeholder="The detailed question text that will be displayed to users"
                />
                <p className="text-xs text-gray-400">The full question that users will see and answer</p>
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-300">Description</label>
                <Textarea
                  value={editNodeForm.description || ''}
                  onChange={(e) => setEditNodeForm({ ...editNodeForm, description: e.target.value })}
                  className="bg-gray-900/50 border-gray-600 text-white placeholder:text-gray-400 focus:border-amber-500"
                  placeholder="Optional description or additional context"
                  rows={3}
                />
                <p className="text-xs text-gray-400">Additional context or explanation for this question</p>
              </div>
              
              <div className="grid grid-cols-3 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-300">Parent Node</label>
                  <Select
                    value={editNodeForm.parent_node_id || 'none'}
                    onValueChange={(value) => setEditNodeForm({ ...editNodeForm, parent_node_id: value === 'none' ? null : value })}
                  >
                    <SelectTrigger className="bg-gray-900/50 border-gray-600 text-white">
                      <SelectValue placeholder="Select parent node" />
                    </SelectTrigger>
                    <SelectContent className="bg-gray-800 border-gray-600">
                      <SelectItem value="none">No Parent (Root Level)</SelectItem>
                      {treeNodes.map((node) => (
                        <SelectItem key={node.id} value={node.id}>
                          {node.node_key} - {node.title}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <p className="text-xs text-gray-400">Which node leads to this question</p>
                </div>
                
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-300">Display Order</label>
                  <Input
                    type="number"
                    value={editNodeForm.display_order}
                    onChange={(e) => setEditNodeForm({ ...editNodeForm, display_order: parseInt(e.target.value) || 0 })}
                    className="bg-gray-900/50 border-gray-600 text-white placeholder:text-gray-400 focus:border-amber-500"
                    placeholder="0"
                  />
                  <p className="text-xs text-gray-400">Order in which this appears</p>
                </div>
                
                <div className="space-y-2">
                  <div className="flex items-center space-x-2 mt-6">
                    <Checkbox
                      id="is-root"
                      checked={editNodeForm.is_root}
                      onCheckedChange={(checked) => setEditNodeForm({ ...editNodeForm, is_root: !!checked })}
                      className="border-gray-600 text-amber-500"
                    />
                    <label htmlFor="is-root" className="text-sm font-medium text-gray-300 cursor-pointer">
                      Is Root Node
                    </label>
                  </div>
                  <p className="text-xs text-gray-400">Check if this is the starting node of the tree</p>
                </div>
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-300">Administrative Notes</label>
                <Textarea
                  value={editNodeForm.notes || ''}
                  onChange={(e) => setEditNodeForm({ ...editNodeForm, notes: e.target.value })}
                  className="bg-gray-900/50 border-gray-600 text-white placeholder:text-gray-400 focus:border-amber-500"
                  placeholder="Internal notes for administrators (not visible to users)"
                  rows={2}
                />
                <p className="text-xs text-gray-400">Internal documentation for system administrators</p>
              </div>
            </div>

            {/* Notes Field */}
            <div className="space-y-2">
              <Label htmlFor="notes" className="text-sm font-medium text-white">
                Notes
              </Label>
              <Textarea
                id="notes"
                placeholder="Additional notes or comments about this node..."
                value={editNodeForm.notes || ''}
                onChange={(e) => setEditNodeForm({ ...editNodeForm, notes: e.target.value })}
                className="bg-gray-800/50 border-gray-600 text-white placeholder-gray-400 focus:border-blue-500 focus:ring-blue-500/20 min-h-[80px] resize-none"
                rows={3}
              />
              <p className="text-xs text-gray-400">
                Optional field for additional information, regulatory context, or implementation notes
              </p>
            </div>

            <div className="flex justify-end space-x-3 pt-4 border-t border-gray-700">
              <Button
                variant="outline"
                onClick={() => setShowEditNodeDialog(false)}
                className="border-gray-600 text-gray-300 hover:bg-gray-700 hover:text-white"
                disabled={updatingNode}
              >
                Cancel
              </Button>
              <Button
                onClick={handleUpdateNode}
                className="bg-amber-600 hover:bg-amber-700 text-white"
                disabled={updatingNode || !editNodeForm.node_key.trim() || !editNodeForm.title.trim() || !editNodeForm.question_text.trim()}
              >
                {updatingNode ? 'Updating...' : 'Update Node'}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
};

export default ProductClassificationAdminComprehensive;
