import React from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import {
  CheckCircle,
  XCircle,
  AlertTriangle,
  Info,
  Scale,
  MapPin,
  FileText,
  Calendar,
  Building,
  Clock
} from 'lucide-react';
import type { CriticalProductSearchResult } from 'types';

interface Props {
  product: CriticalProductSearchResult | null;
  isOpen: boolean;
  onClose: () => void;
}

const ProductDetailModal: React.FC<Props> = ({ product, isOpen, onClose }) => {
  if (!product) return null;

  const getRiskLevelIcon = (riskLevel: string | null) => {
    switch (riskLevel) {
      case 'high':
        return <XCircle className="h-4 w-4 text-red-500" />;
      case 'medium':
        return <AlertTriangle className="h-4 w-4 text-yellow-500" />;
      case 'low':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      default:
        return <Info className="h-4 w-4 text-gray-400" />;
    }
  };

  const getRiskLevelColor = (riskLevel: string | null) => {
    switch (riskLevel) {
      case 'high':
        return 'bg-red-100 text-red-800 border-red-200 dark:bg-red-900/20 dark:text-red-400 dark:border-red-800';
      case 'medium':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200 dark:bg-yellow-900/20 dark:text-yellow-400 dark:border-yellow-800';
      case 'low':
        return 'bg-green-100 text-green-800 border-green-200 dark:bg-green-900/20 dark:text-green-400 dark:border-green-800';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200 dark:bg-gray-800 dark:text-gray-300 dark:border-gray-600';
    }
  };

  const getMeasureTypeColor = (measureType: string) => {
    switch (measureType) {
      case 'export_prohibition':
        return 'border-red-300 text-red-700 dark:border-red-700 dark:text-red-400';
      case 'import_prohibition':
        return 'border-red-300 text-red-700 dark:border-red-700 dark:text-red-400';
      case 'licensing_requirement':
        return 'border-yellow-300 text-yellow-700 dark:border-yellow-700 dark:text-yellow-400';
      case 'technical_assistance_prohibition':
        return 'border-orange-300 text-orange-700 dark:border-orange-700 dark:text-orange-400';
      case 'financing_prohibition':
        return 'border-purple-300 text-purple-700 dark:border-purple-700 dark:text-purple-400';
      default:
        return 'border-gray-300 text-gray-700 dark:border-gray-600 dark:text-gray-300';
    }
  };

  const formatDate = (dateString: string | null) => {
    if (!dateString) return 'Not specified';
    try {
      return new Date(dateString).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
      });
    } catch {
      return dateString;
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-3">
            <div className="flex items-center gap-2">
              <Badge variant="outline" className="font-mono text-lg px-3 py-1">
                {product.hs_code}
              </Badge>
              {product.cn_code && (
                <Badge variant="outline" className="font-mono px-2 py-1">
                  CN: {product.cn_code}
                </Badge>
              )}
              {product.risk_level && (
                <Badge className={`${getRiskLevelColor(product.risk_level)} px-2 py-1`}>
                  {getRiskLevelIcon(product.risk_level)}
                  <span className="ml-1">{product.risk_level.toUpperCase()} RISK</span>
                </Badge>
              )}
            </div>
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Product Overview */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Product Information
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h3 className="text-xl font-semibold mb-2">{product.description}</h3>
              </div>
              
              {(product.category || product.subcategory) && (
                <div className="space-y-2">
                  <h4 className="font-medium text-gray-700 dark:text-gray-300">Classification</h4>
                  <div className="flex flex-wrap gap-2">
                    {product.category && (
                      <Badge variant="secondary" className="px-3 py-1">
                        Category: {product.category}
                      </Badge>
                    )}
                    {product.subcategory && (
                      <Badge variant="outline" className="px-3 py-1">
                        Subcategory: {product.subcategory}
                      </Badge>
                    )}
                  </div>
                </div>
              )}

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-4 border-t">
                <div>
                  <h4 className="font-medium text-gray-700 dark:text-gray-300 mb-2">Trade Codes</h4>
                  <div className="space-y-1">
                    <div className="text-sm">
                      <span className="font-medium">HS Code:</span> {product.hs_code}
                    </div>
                    {product.cn_code && (
                      <div className="text-sm">
                        <span className="font-medium">CN Code:</span> {product.cn_code}
                      </div>
                    )}
                  </div>
                </div>
                
                <div>
                  <h4 className="font-medium text-gray-700 dark:text-gray-300 mb-2">Risk Assessment</h4>
                  <div className="flex items-center gap-2">
                    {getRiskLevelIcon(product.risk_level)}
                    <span className="font-medium">
                      {product.risk_level ? product.risk_level.charAt(0).toUpperCase() + product.risk_level.slice(1) : 'Not assessed'} Risk
                    </span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Restrictions and Measures */}
          {product.restrictions && product.restrictions.length > 0 ? (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Scale className="h-5 w-5 text-red-500" />
                  Applicable Restrictions ({product.restrictions.length})
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {product.restrictions.map((restriction: any, index: number) => (
                    <Card key={index} className="border-l-4 border-l-red-500">
                      <CardContent className="p-4">
                        <div className="space-y-3">
                          {/* Header with badges */}
                          <div className="flex items-center gap-2 flex-wrap">
                            <Badge variant="secondary" className="flex items-center gap-1">
                              <MapPin className="h-3 w-3" />
                              {restriction.jurisdiction}
                            </Badge>
                            <Badge 
                              variant="outline" 
                              className={`${getMeasureTypeColor(restriction.measure_type)}`}
                            >
                              {restriction.measure_type.replace('_', ' ').toUpperCase()}
                            </Badge>
                            {restriction.risk_level && (
                              <Badge className={getRiskLevelColor(restriction.risk_level)}>
                                {restriction.risk_level.toUpperCase()}
                              </Badge>
                            )}
                          </div>

                          {/* Regulation Reference */}
                          <div>
                            <h4 className="font-semibold text-lg">{restriction.regulation_reference}</h4>
                            {restriction.measure_description && (
                              <p className="text-gray-600 dark:text-gray-400 mt-1">
                                {restriction.measure_description}
                              </p>
                            )}
                          </div>

                          {/* Additional Details Grid */}
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-3 border-t">
                            {restriction.authority && (
                              <div className="flex items-center gap-2">
                                <Building className="h-4 w-4 text-gray-500" />
                                <div>
                                  <span className="text-sm font-medium">Authority:</span>
                                  <div className="text-sm text-gray-600 dark:text-gray-400">{restriction.authority}</div>
                                </div>
                              </div>
                            )}

                            {restriction.effective_date && (
                              <div className="flex items-center gap-2">
                                <Calendar className="h-4 w-4 text-gray-500" />
                                <div>
                                  <span className="text-sm font-medium">Effective Date:</span>
                                  <div className="text-sm text-gray-600 dark:text-gray-400">
                                    {formatDate(restriction.effective_date)}
                                  </div>
                                </div>
                              </div>
                            )}

                            {restriction.article_number && (
                              <div>
                                <span className="text-sm font-medium">Article:</span>
                                <div className="text-sm text-gray-600 dark:text-gray-400">{restriction.article_number}</div>
                              </div>
                            )}

                            {restriction.scope_notes && (
                              <div className="md:col-span-2">
                                <span className="text-sm font-medium">Scope Notes:</span>
                                <div className="text-sm text-gray-600 dark:text-gray-400 mt-1 p-2 bg-gray-50 dark:bg-gray-800 rounded">
                                  {restriction.scope_notes}
                                </div>
                              </div>
                            )}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          ) : (
            <Alert>
              <Info className="h-4 w-4" />
              <AlertDescription>
                <strong>No specific restrictions found</strong> for this product code in our database. 
                This does not guarantee the product is unrestricted. Please consult the relevant 
                export control authorities and current regulations for complete compliance guidance.
              </AlertDescription>
            </Alert>
          )}

          {/* Compliance Notes */}
          <Card className="border-amber-200 dark:border-amber-800 bg-amber-50 dark:bg-amber-900/10">
            <CardContent className="p-4">
              <div className="flex items-start gap-2">
                <AlertTriangle className="h-5 w-5 text-amber-600 dark:text-amber-400 mt-0.5" />
                <div>
                  <h4 className="font-medium text-amber-800 dark:text-amber-400 mb-2">Compliance Reminder</h4>
                  <p className="text-sm text-amber-700 dark:text-amber-300">
                    This information is provided for reference only. Export control regulations change frequently. 
                    Always verify current requirements with the relevant authorities before proceeding with any transaction.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default ProductDetailModal;
