import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { 
  Search, 
  AlertTriangle, 
  CheckCircle, 
  TrendingUp,
  Users,
  Activity,
  BarChart3
} from 'lucide-react';
import { CustomerProfile, ScreeningResult } from '../brain/data-contracts';

export interface ScreeningAnalyticsProps {
  customers: CustomerProfile[];
  screeningResults: ScreeningResult[];
}

const ScreeningAnalytics: React.FC<ScreeningAnalyticsProps> = ({
  customers,
  screeningResults
}) => {
  // Calculate analytics metrics
  const totalScreenings = screeningResults.length;
  const highRiskMatches = screeningResults.filter(r => ['high', 'critical'].includes(r.risk_level)).length;
  const completionRate = totalScreenings > 0 ? 
    ((screeningResults.filter(r => r.total_matches > 0).length / totalScreenings) * 100) : 0;
  
  const riskDistribution = {
    critical: screeningResults.filter(r => r.risk_level === 'critical').length,
    high: screeningResults.filter(r => r.risk_level === 'high').length,
    medium: screeningResults.filter(r => r.risk_level === 'medium').length,
    low: screeningResults.filter(r => r.risk_level === 'low').length
  };

  const customerTypeDistribution = {
    individuals: customers.filter(c => c.customer_type === 'individual').length,
    companies: customers.filter(c => ['company', 'entity', 'organization'].includes(c.customer_type || '')).length
  };

  const recentActivity = screeningResults
    .sort((a, b) => new Date(b.screening_date).getTime() - new Date(a.screening_date).getTime())
    .slice(0, 5);

  return (
    <div className="space-y-6">
      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="bg-gray-800/50 border-gray-700">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">Total Screenings</p>
                <p className="text-2xl font-bold text-white">{totalScreenings}</p>
              </div>
              <Search className="h-8 w-8 text-blue-400" />
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-gray-800/50 border-gray-700">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">High Risk Matches</p>
                <p className="text-2xl font-bold text-red-400">{highRiskMatches}</p>
              </div>
              <AlertTriangle className="h-8 w-8 text-red-400" />
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-gray-800/50 border-gray-700">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">Completion Rate</p>
                <p className="text-2xl font-bold text-green-400">{completionRate.toFixed(1)}%</p>
              </div>
              <CheckCircle className="h-8 w-8 text-green-400" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Detailed Analytics */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Risk Level Distribution */}
        <Card className="bg-gray-800/50 border-gray-700">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <BarChart3 className="h-5 w-5" />
              Risk Level Distribution
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-red-500 rounded"></div>
                  <span className="text-gray-300">Critical</span>
                </div>
                <span className="text-white font-medium">{riskDistribution.critical}</span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-orange-500 rounded"></div>
                  <span className="text-gray-300">High</span>
                </div>
                <span className="text-white font-medium">{riskDistribution.high}</span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-yellow-500 rounded"></div>
                  <span className="text-gray-300">Medium</span>
                </div>
                <span className="text-white font-medium">{riskDistribution.medium}</span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-green-500 rounded"></div>
                  <span className="text-gray-300">Low</span>
                </div>
                <span className="text-white font-medium">{riskDistribution.low}</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Customer Type Distribution */}
        <Card className="bg-gray-800/50 border-gray-700">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Users className="h-5 w-5" />
              Customer Distribution
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-blue-500 rounded"></div>
                  <span className="text-gray-300">Individuals</span>
                </div>
                <span className="text-white font-medium">{customerTypeDistribution.individuals}</span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-purple-500 rounded"></div>
                  <span className="text-gray-300">Entities</span>
                </div>
                <span className="text-white font-medium">{customerTypeDistribution.companies}</span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-gray-500 rounded"></div>
                  <span className="text-gray-300">Total Customers</span>
                </div>
                <span className="text-white font-medium">{customers.length}</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recent Activity */}
      <Card className="bg-gray-800/50 border-gray-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Activity className="h-5 w-5" />
            Recent Screening Activity
          </CardTitle>
        </CardHeader>
        <CardContent>
          {recentActivity.length === 0 ? (
            <div className="text-center py-8">
              <Activity className="h-8 w-8 text-gray-400 mx-auto mb-2" />
              <p className="text-gray-400">No recent screening activity</p>
            </div>
          ) : (
            <div className="space-y-3">
              {recentActivity.map((result, index) => {
                const customer = customers.find(c => c.id === result.customer_id);
                return (
                  <div key={result.id || index} className="flex items-center justify-between p-3 bg-slate-700/30 rounded-lg">
                    <div>
                      <div className="text-white font-medium">
                        {customer?.customer_name || 'Unknown Customer'}
                      </div>
                      <div className="text-gray-400 text-sm">
                        {new Date(result.screening_date).toLocaleDateString()} • 
                        {result.total_matches} matches • 
                        {result.risk_level} risk
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      {result.high_risk_matches > 0 && (
                        <div className="flex items-center gap-1 text-red-400">
                          <AlertTriangle className="h-4 w-4" />
                          <span className="text-sm">{result.high_risk_matches}</span>
                        </div>
                      )}
                      <div className={`px-2 py-1 rounded text-xs ${
                        result.risk_level === 'critical' ? 'bg-red-500/20 text-red-400' :
                        result.risk_level === 'high' ? 'bg-orange-500/20 text-orange-400' :
                        result.risk_level === 'medium' ? 'bg-yellow-500/20 text-yellow-400' :
                        'bg-green-500/20 text-green-400'
                      }`}>
                        {result.risk_level}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default ScreeningAnalytics;
