import React, { useState, useEffect, useRef } from 'react';
import { cn } from 'utils/cn';
import { toast } from 'sonner';
import { CheckCircle, X, ChevronDown, ChevronUp, Plus, Check, ChevronsUpDown, Settings, GitBranch, ArrowRight, PlayCircle, Edit } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { createPortal } from 'react-dom';
import brain from 'brain';
import type { ClassificationWorkflow, ClassificationWorkflowUpdate, ClassificationOutcome } from '../brain/data-contracts';

// Map ClassificationWorkflow to SanctionsWorkflow for display
interface SanctionsWorkflow {
  id: string;
  name: string;
  description: string;
  triggerCondition: string;
  conditionalRules: ConditionalRule[];
  outcomes: WorkflowOutcome[];
  status: string;
  pricing_tier?: string;
}

interface ConditionalRule {
  id: string;
  condition: string;
  q1Value?: string;
  q2Value?: string;
  q3Value?: string;
  targetTree?: string;
  targetNode?: string;
  outcome?: string;
  priority: number;
}

interface WorkflowOutcome {
  id: string;
  type: 'tree' | 'direct';
  target: string;
  description: string;
}

const SanctionsWorkflowsTab: React.FC = () => {
  const [workflows, setWorkflows] = useState<SanctionsWorkflow[]>([]);
  const [selectedWorkflow, setSelectedWorkflow] = useState<SanctionsWorkflow | null>(null);
  const [editingWorkflow, setEditingWorkflow] = useState<SanctionsWorkflow | null>(null);
  const [editFormData, setEditFormData] = useState<SanctionsWorkflow | null>(null);
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [activeTab, setActiveTab] = useState('overview');
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [availableOutcomes, setAvailableOutcomes] = useState<ClassificationOutcome[]>([]);
  const [loadingOutcomes, setLoadingOutcomes] = useState(false);
  const [dropdownOpen, setDropdownOpen] = useState<{ [key: string]: boolean }>({});
  
  // State for managing trees and nodes
  const [availableTrees, setAvailableTrees] = useState<Array<{id: string, name: string}>>([]);
  const [loadingTrees, setLoadingTrees] = useState(false);
  const [availableNodes, setAvailableNodes] = useState<{ [treeId: string]: { id: string; node_key: string; title: string }[] }>({});
  const [loadingNodes, setLoadingNodes] = useState<{ [treeId: string]: boolean }>({});

  // State for create workflow form
  const [createFormData, setCreateFormData] = useState({
    name: '',
    description: '',
    pricing_tier: 'basic',
    trigger_condition: '',
    status: 'draft'
  });
  const [creating, setCreating] = useState(false);

  // Load outcomes from backend
  useEffect(() => {
    const loadOutcomes = async () => {
      setLoadingOutcomes(true);
      try {
        console.log('🔄 Loading available outcomes...');
        const response = await brain.list_all_classification_outcomes();
        const data = await response.json();
        console.log('📋 Received outcomes:', data.length);
        setAvailableOutcomes(data);
      } catch (error) {
        console.error('❌ Error loading outcomes:', error);
        toast.error('Failed to load available outcomes');
      } finally {
        setLoadingOutcomes(false);
      }
    };

    loadOutcomes();
  }, []);

  // Load available trees
  const loadAvailableTrees = async () => {
    setLoadingTrees(true);
    try {
      console.log('🌳 Loading available trees...');
      const [sanctionsResponse, classificationResponse, introductionResponse] = await Promise.all([
        brain.list_sanctions_trees(),
        brain.list_classification_trees(), 
        brain.list_introduction_trees()
      ]);
      
      const trees = [];
      
      if (sanctionsResponse.ok) {
        const sanctionsData = await sanctionsResponse.json();
        trees.push(...sanctionsData.map((tree: any) => ({ 
          id: tree.id, 
          name: tree.name 
        })));
      }
      
      if (classificationResponse.ok) {
        const classificationData = await classificationResponse.json();
        trees.push(...classificationData.map((tree: any) => ({ 
          id: tree.id, 
          name: tree.name 
        })));
      }
      
      if (introductionResponse.ok) {
        const introductionData = await introductionResponse.json();
        trees.push(...introductionData.map((tree: any) => ({ 
          id: tree.id, 
          name: tree.name 
        })));
      }
      
      setAvailableTrees(trees);
      console.log('✅ Loaded trees:', trees.length);
    } catch (error) {
      console.error('❌ Error loading trees:', error);
      toast.error('Failed to load available trees');
    } finally {
      setLoadingTrees(false);
    }
  };
  
  // Load nodes for a specific tree
  const loadTreeNodes = async (treeId: string, treeType: string) => {
    if (availableNodes[treeId]) {
      return; // Already loaded
    }
    
    setLoadingNodes(prev => ({ ...prev, [treeId]: true }));
    try {
      console.log(`🔗 Loading nodes for ${treeType} tree ${treeId}...`);
      let response;
      
      switch (treeType) {
        case 'sanctions':
          response = await brain.list_sanctions_nodes({ treeId });
          break;
        case 'classification':
          response = await brain.list_tree_nodes({ treeId });
          break;
        case 'introduction':
          response = await brain.list_introduction_tree_nodes({ treeId });
          break;
        default:
          throw new Error(`Unknown tree type: ${treeType}`);
      }
      
      if (response.ok) {
        const nodesData = await response.json();
        const formattedNodes = nodesData.map((node: any) => ({
          id: node.id,
          node_key: node.node_key,
          title: node.title || node.node_key
        }));
        
        setAvailableNodes(prev => ({
          ...prev,
          [treeId]: formattedNodes
        }));
        console.log(`✅ Loaded ${formattedNodes.length} nodes for tree ${treeId}`);
      } else {
        throw new Error(`Failed to load nodes: ${response.status}`);
      }
    } catch (error) {
      console.error(`❌ Error loading nodes for tree ${treeId}:`, error);
      toast.error(`Failed to load nodes for selected tree`);
    } finally {
      setLoadingNodes(prev => ({ ...prev, [treeId]: false }));
    }
  };
  
  // Load nodes for a specific tree when selected
  const loadNodesForTree = async (treeId: string) => {
    if (!treeId || availableNodes[treeId]) {
      return; // No tree ID or already loaded
    }
    
    setLoadingNodes(prev => ({ ...prev, [treeId]: true }));
    try {
      console.log(`🔗 Loading nodes for tree ${treeId}...`);
      
      // Try different API endpoints based on tree type
      let response;
      try {
        // Try sanctions API first - this is the correct endpoint for sanctions trees
        response = await brain.list_sanctions_nodes({ treeId });
        console.log(`🔗 Tried sanctions API for tree ${treeId}`);
      } catch {
        try {
          // Try classification API
          response = await brain.list_tree_nodes({ treeId });
          console.log(`🔗 Tried classification API for tree ${treeId}`);
        } catch {
          try {
            // Try introduction API
            response = await brain.list_introduction_tree_nodes({ treeId });
            console.log(`🔗 Tried introduction API for tree ${treeId}`);
          } catch (error) {
            console.error(`❌ All APIs failed for tree ${treeId}:`, error);
            throw error;
          }
        }
      }
      
      if (response && response.ok) {
        const nodesData = await response.json();
        console.log(`📊 Raw nodes data for tree ${treeId}:`, nodesData);
        
        const formattedNodes = nodesData.map((node: any) => ({
          id: node.id || node.node_key || node.question_key,
          node_key: node.node_key || node.question_key || node.id,
          question_text: node.question_text || node.title || node.text || node.node_key || node.question_key
        }));
        
        setAvailableNodes(prev => ({
          ...prev,
          [treeId]: formattedNodes
        }));
        console.log(`✅ Loaded ${formattedNodes.length} nodes for tree ${treeId}:`, formattedNodes);
      } else {
        console.warn(`⚠️ Response not OK for tree ${treeId}:`, response?.status);
      }
    } catch (error) {
      console.error(`❌ Error loading nodes for tree ${treeId}:`, error);
      // Don't show error toast as it's expected that some APIs might fail
    } finally {
      setLoadingNodes(prev => ({ ...prev, [treeId]: false }));
    }
  };
  
  // Load trees when component mounts
  useEffect(() => {
    loadAvailableTrees();
  }, []);

  // Load nodes for trees that are already selected in rules when editFormData changes
  useEffect(() => {
    if (editFormData?.conditionalRules) {
      editFormData.conditionalRules.forEach(rule => {
        if (rule.targetTree && !availableNodes[rule.targetTree]) {
          console.log(`🔄 Auto-loading nodes for pre-selected tree: ${rule.targetTree}`);
          loadNodesForTree(rule.targetTree);
        }
      });
    }
  }, [editFormData, availableNodes]);

  // Load workflows from backend
  const loadWorkflows = async () => {
    setLoading(true);
    try {
      console.log('🔄 Loading sanctions workflows...');
      const response = await brain.list_workflows({ workflow_type: 'sanctions' });
      const data = await response.json();
      console.log('📋 Received workflows:', data.length);
      
      // Map ClassificationWorkflow to SanctionsWorkflow
      const mappedWorkflows: SanctionsWorkflow[] = data.map((workflow: any) => ({
        id: workflow.id,
        name: workflow.name,
        description: workflow.description,
        triggerCondition: workflow.trigger_condition || '',
        conditionalRules: (workflow.conditional_rules || []).map((rule: any) => ({
          id: rule.id || Math.random().toString(),
          condition: rule.condition || '',
          q1Value: rule.action ? JSON.parse(rule.action).q1Value : undefined,
          q2Value: rule.action ? JSON.parse(rule.action).q2Value : undefined,
          q3Value: rule.action ? JSON.parse(rule.action).q3Value : undefined,
          targetTree: rule.action ? JSON.parse(rule.action).targetTree : undefined,
          targetNode: rule.action ? JSON.parse(rule.action).targetNode : undefined,
          outcome: rule.action ? JSON.parse(rule.action).outcome : undefined,
          priority: rule.priority || 0
        })),
        outcomes: workflow.outcomes || [],
        status: workflow.status,
        pricing_tier: workflow.pricing_tier
      }));
      
      setWorkflows(mappedWorkflows);
    } catch (error) {
      console.error('❌ Error loading workflows:', error);
      toast.error('Failed to load workflows');
    } finally {
      setLoading(false);
    }
  };

  // Load workflows on component mount
  useEffect(() => {
    loadWorkflows();
  }, []);

  // Initialize form data when editing workflow changes
  useEffect(() => {
    if (editingWorkflow) {
      setEditFormData({ 
        ...editingWorkflow,
        // Ensure all fields have defined values
        name: editingWorkflow.name || '',
        description: editingWorkflow.description || '',
        triggerCondition: editingWorkflow.triggerCondition || '',
        conditionalRules: editingWorkflow.conditionalRules || [],
        outcomes: editingWorkflow.outcomes || [],
        status: editingWorkflow.status || 'draft'
      });
    } else {
      setEditFormData(null);
    }
  }, [editingWorkflow]);

  const getConditionBadgeColor = (rule: ConditionalRule) => {
    if (rule.targetTree) return 'bg-purple-500/20 text-purple-400';
    if (rule.outcome) return 'bg-green-500/20 text-green-400';
    return 'bg-gray-500/20 text-gray-400';
  };

  const renderWorkflowCard = (workflow: SanctionsWorkflow) => (
    <div key={workflow.id} className="space-y-2">
      <Card className="bg-gray-800/30 border-gray-700">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-white flex items-center gap-2">
                <GitBranch className="h-5 w-5 text-blue-400" />
                {workflow.name}
              </CardTitle>
              <CardDescription className="text-gray-400 mt-1">
                {workflow.description}
              </CardDescription>
            </div>
            <div className="flex items-center gap-2">
              <Badge className="bg-blue-500/20 text-blue-400 border-blue-500/30">
                {workflow.conditionalRules.length} Rules
              </Badge>
              <Badge className={`border ${
                workflow.status === 'published' ? 'bg-green-500/20 text-green-400 border-green-500/30' : 
                workflow.status === 'draft' ? 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30' :
                'bg-gray-500/20 text-gray-400 border-gray-500/30'
              }`}>
                {workflow.status}
              </Badge>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {/* Trigger Condition */}
            <div className="flex items-center gap-2 text-sm">
              <span className="text-gray-500">Trigger:</span>
              <Badge className="bg-orange-500/20 text-orange-400 border-orange-500/30">
                {workflow.triggerCondition}
              </Badge>
            </div>

            {/* Conditional Rules Preview */}
            <div className="space-y-2">
              <h4 className="text-sm font-medium text-gray-300">Conditional Logic:</h4>
              {workflow.conditionalRules.slice(0, 2).map((rule) => (
                <div key={rule.id} className="flex items-center gap-2 text-sm">
                  <div className="flex items-center gap-1">
                    {rule.q1Value && (
                      <Badge className="bg-gray-600/30 text-gray-300 text-xs">
                        Q1: {rule.q1Value}
                      </Badge>
                    )}
                    {rule.q2Value && (
                      <Badge className="bg-gray-600/30 text-gray-300 text-xs">
                        Q2: {rule.q2Value}
                      </Badge>
                    )}
                    {rule.q3Value && (
                      <Badge className="bg-gray-600/30 text-gray-300 text-xs">
                        Q3: {rule.q3Value}
                      </Badge>
                    )}
                  </div>
                  <ArrowRight className="h-3 w-3 text-gray-500" />
                  <Badge className={getConditionBadgeColor(rule)}>
                    {rule.targetTree || rule.outcome}
                  </Badge>
                </div>
              ))}
              {workflow.conditionalRules.length > 2 && (
                <div className="text-xs text-gray-500">
                  +{workflow.conditionalRules.length - 2} more rules
                </div>
              )}
            </div>

            {/* Actions */}
            <div className="flex gap-2 pt-2">
              <Button
                size="sm"
                className="bg-purple-500/20 hover:bg-purple-500/30 text-purple-400 border border-purple-500/30"
                onClick={() => setSelectedWorkflow(workflow)}
              >
                <PlayCircle className="h-4 w-4 mr-1" />
                View Details
              </Button>
              <Button
                size="sm"
                variant="ghost"
                className="text-gray-400 hover:text-white"
                onClick={() => {
                  console.log('Edit workflow:', workflow.name);
                  setEditingWorkflow(workflow);
                }}
              >
                <Edit className="h-4 w-4 mr-1" />
                Edit
              </Button>
              <Button
                size="sm"
                variant="ghost"
                className="text-gray-400 hover:text-white"
                onClick={() => {
                  console.log('Duplicate workflow:', workflow.name);
                  handleDuplicateWorkflow(workflow.id);
                }}
              >
                <Plus className="h-4 w-4 mr-1" />
                Duplicate
              </Button>
              
              {/* Status Change Dropdown */}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button
                    size="sm"
                    variant="ghost"
                    className="text-gray-400 hover:text-white"
                  >
                    <Settings className="h-4 w-4 mr-1" />
                    Status
                    <ChevronDown className="h-3 w-3 ml-1" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent className="bg-gray-800 border-gray-700">
                  <DropdownMenuLabel className="text-gray-300">Change Status</DropdownMenuLabel>
                  <DropdownMenuSeparator className="bg-gray-700" />
                  <DropdownMenuItem
                    className="text-yellow-400 hover:bg-gray-700 cursor-pointer"
                    onClick={() => handleStatusChange(workflow.id, 'draft', workflow.name)}
                    disabled={workflow.status === 'draft'}
                  >
                    {workflow.status === 'draft' && <Check className="h-4 w-4 mr-2" />}
                    Draft
                  </DropdownMenuItem>
                  <DropdownMenuItem
                    className="text-green-400 hover:bg-gray-700 cursor-pointer"
                    onClick={() => handleStatusChange(workflow.id, 'published', workflow.name)}
                    disabled={workflow.status === 'published'}
                  >
                    {workflow.status === 'published' && <Check className="h-4 w-4 mr-2" />}
                    Published
                  </DropdownMenuItem>
                  <DropdownMenuItem
                    className="text-gray-400 hover:bg-gray-700 cursor-pointer"
                    onClick={() => handleStatusChange(workflow.id, 'archived', workflow.name)}
                    disabled={workflow.status === 'archived'}
                  >
                    {workflow.status === 'archived' && <Check className="h-4 w-4 mr-2" />}
                    Archived
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
              
              <Button
                size="sm"
                variant="ghost"
                className="text-gray-400 hover:text-white"
                onClick={() => {
                  console.log('Delete workflow:', workflow.name);
                  handleDeleteWorkflow(workflow.id);
                }}
              >
                <X className="h-4 w-4 mr-1" />
                Delete
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );

  const renderDetailedWorkflow = () => {
    if (!selectedWorkflow) return null;

    return (
      <Dialog open={!!selectedWorkflow} onOpenChange={() => setSelectedWorkflow(null)}>
        <DialogContent className="bg-gray-900 border-gray-700 text-white max-w-4xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-blue-400 flex items-center gap-2">
              <GitBranch className="h-5 w-5" />
              {selectedWorkflow.name}
            </DialogTitle>
          </DialogHeader>
          
          <div className="space-y-6">
            {/* Workflow Overview */}
            <Card className="bg-gray-800/30 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white text-lg">Workflow Overview</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div>
                    <span className="text-gray-400">Description: </span>
                    <span className="text-white">{selectedWorkflow.description}</span>
                  </div>
                  <div>
                    <span className="text-gray-400">Trigger Condition: </span>
                    <Badge className="bg-orange-500/20 text-orange-400 border-orange-500/30">
                      {selectedWorkflow.triggerCondition}
                    </Badge>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Conditional Rules */}
            <Card className="bg-gray-800/30 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white text-lg">Conditional Rules</CardTitle>
                <CardDescription className="text-gray-400">
                  Rules are evaluated in priority order (1 = highest priority)
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {selectedWorkflow.conditionalRules.map((rule) => (
                    <div key={rule.id} className="border border-gray-700 rounded-lg p-4">
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-2">
                          <Badge className="bg-blue-500/20 text-blue-400 text-xs">
                            Priority {rule.priority}
                          </Badge>
                          <span className="text-white font-medium">{rule.condition}</span>
                        </div>
                        {rule.targetTree ? (
                          <CheckCircle className="h-4 w-4 text-green-400" />
                        ) : (
                          <Info className="h-4 w-4 text-blue-400" />
                        )}
                      </div>
                      
                      <div className="space-y-2">
                        {/* Input Conditions */}
                        <div className="flex items-center gap-2">
                          <span className="text-gray-400 text-sm">If:</span>
                          <div className="flex gap-1">
                            {rule.q1Value && (
                              <Badge className="bg-gray-600/30 text-gray-300 text-xs">
                                Q1 = {rule.q1Value}
                              </Badge>
                            )}
                            {rule.q2Value && (
                              <Badge className="bg-gray-600/30 text-gray-300 text-xs">
                                Q2 = {rule.q2Value}
                              </Badge>
                            )}
                            {rule.q3Value && (
                              <Badge className="bg-gray-600/30 text-gray-300 text-xs">
                                Q3 = {rule.q3Value}
                              </Badge>
                            )}
                            {!rule.q1Value && !rule.q2Value && !rule.q3Value && (
                              <Badge className="bg-gray-600/30 text-gray-300 text-xs">
                                Default condition
                              </Badge>
                            )}
                          </div>
                        </div>
                        
                        {/* Output */}
                        <div className="flex items-center gap-2">
                          <span className="text-gray-400 text-sm">Then:</span>
                          <ArrowRight className="h-3 w-3 text-gray-500" />
                          <Badge className={getConditionBadgeColor(rule)}>
                            {rule.targetTree ? `Route to: ${rule.targetTree}` : rule.outcome}
                          </Badge>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Possible Outcomes */}
            <Card className="bg-gray-800/30 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white text-lg">Possible Outcomes</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {selectedWorkflow.outcomes.map((outcome) => (
                    <div key={outcome.id} className="border border-gray-700 rounded-lg p-3">
                      <div className="flex items-center gap-2 mb-1">
                        {outcome.type === 'tree' ? (
                          <GitBranch className="h-4 w-4 text-purple-400" />
                        ) : (
                          <CheckCircle className="h-4 w-4 text-green-400" />
                        )}
                        <span className="text-white font-medium">{outcome.target}</span>
                      </div>
                      <p className="text-gray-400 text-sm">{outcome.description}</p>
                      <Badge className={outcome.type === 'tree' ? 'bg-purple-500/20 text-purple-400' : 'bg-green-500/20 text-green-400'}>
                        {outcome.type === 'tree' ? 'Specialized Tree' : 'Direct Outcome'}
                      </Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </DialogContent>
      </Dialog>
    );
  };

  const handleSaveWorkflow = async () => {
    if (!editFormData) {
      toast.error('No workflow data to save');
      return;
    }

    try {
      setSaving(true);
      console.log('💾 Saving workflow changes...', editFormData.id);
      
      // Prepare the update data with proper mapping to backend structure
      const updateData: ClassificationWorkflowUpdate = {
        name: editFormData.name,
        description: editFormData.description,
        status: editFormData.status,
        pricing_tier: editFormData.pricing_tier,
        conditional_rules: editFormData.conditionalRules.map(rule => ({
          id: rule.id,
          condition: rule.condition,
          action: JSON.stringify({
            q1Value: rule.q1Value,
            q2Value: rule.q2Value,
            q3Value: rule.q3Value,
            targetTree: rule.targetTree,
            targetNode: rule.targetNode,
            outcome: rule.outcome
          }),
          priority: rule.priority
        })),
        outcomes: editFormData.outcomes.map(outcome => ({
          id: outcome.id,
          title: outcome.target,
          description: outcome.description,
          action: outcome.type
        })),
        trigger_condition: editFormData.triggerCondition
      };
      
      console.log('📤 Update payload:', updateData);
      
      // Call the backend API to update the workflow
      const response = await brain.update_workflow(
        { workflowId: editFormData.id },
        updateData
      );
      
      if (response.ok) {
        const result = await response.json();
        console.log('✅ Workflow updated successfully:', result);
        
        // Reload workflows from backend to get the updated data
        await loadWorkflows();
        
        // Close the edit dialog
        setEditingWorkflow(null);
        setEditFormData(null);
        
        toast.success('Workflow updated successfully!');
      } else {
        const errorData = await response.json().catch(() => ({ detail: 'Unknown error' }));
        console.error('❌ Failed to update workflow:', errorData);
        toast.error(`Failed to update workflow: ${errorData.detail || 'Unknown error'}`);
      }
    } catch (error) {
      console.error('❌ Error updating workflow:', error);
      toast.error('An error occurred while updating the workflow');
    } finally {
      setSaving(false);
    }
  };

  const addNewRule = () => {
    if (!editFormData) return;
    
    const newRule: ConditionalRule = {
      id: `rule_${Date.now()}`,
      condition: 'New Condition',
      priority: editFormData.conditionalRules.length + 1,
      q1Value: '',
      q2Value: '',
      q3Value: '',
      targetTree: '',
      targetNode: '',
      outcome: ''
    };
    
    const updatedRules = [...editFormData.conditionalRules, newRule];
    setEditFormData({ ...editFormData, conditionalRules: updatedRules });
  };

  const removeRule = (ruleId: string) => {
    if (!editFormData) return;
    
    const updatedRules = editFormData.conditionalRules.filter(rule => rule.id !== ruleId);
    setEditFormData({ ...editFormData, conditionalRules: updatedRules });
  };

  // Handle clicking outside dropdown to close it
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      const target = event.target as Element;
      // Check if click is outside any dropdown
      if (!target.closest('.dropdown-container')) {
        setDropdownOpen({});
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  // Get nodes for a specific tree
  const getNodesForTree = (treeId: string) => {
    if (!treeId) return [];
    return availableNodes[treeId] || [];
  };

  // Create workflow handler
  const handleCreateWorkflow = async () => {
    try {
      setCreating(true);
      console.log('🚀 Creating new workflow...', createFormData);
      
      const response = await brain.create_workflow({
        name: createFormData.name,
        description: createFormData.description,
        pricing_tier: createFormData.pricing_tier as 'basic' | 'professional' | 'enterprise',
        trigger_condition: createFormData.trigger_condition,
        status: 'draft',
        workflow_type: 'sanctions',
        classification_tree_ids: [],
        conditional_rules: [],
        outcomes: []
      });
      
      if (response.ok) {
        toast.success('Workflow created successfully');
        setShowCreateDialog(false);
        setCreateFormData({
          name: '',
          description: '',
          pricing_tier: 'basic',
          trigger_condition: '',
          status: 'draft'
        });
        loadWorkflows();
      } else {
        toast.error('Failed to create workflow');
      }
    } catch (error) {
      console.error('Error creating workflow:', error);
      toast.error('Failed to create workflow');
    } finally {
      setCreating(false);
    }
  };

  // Delete workflow handler
  const handleDeleteWorkflow = async (workflowId: string) => {
    try {
      console.log('🗑 Deleting workflow...', workflowId);
      
      const response = await brain.delete_workflow({ workflowId });
      
      if (response.ok) {
        toast.success('Workflow deleted successfully');
        loadWorkflows();
      } else {
        const errorData = await response.json().catch(() => ({ detail: 'Unknown error' }));
        console.error('❌ Failed to delete workflow:', errorData);
        toast.error(`Failed to delete workflow: ${errorData.detail || 'Unknown error'}`);
      }
    } catch (error) {
      console.error('❌ Error deleting workflow:', error);
      toast.error('An error occurred while deleting the workflow');
    }
  };

  // Handle status change
  const handleStatusChange = async (workflowId: string, newStatus: string, workflowName: string) => {
    try {
      console.log(`🔄 Changing status of workflow ${workflowName} to ${newStatus}`);
      
      const response = await brain.update_workflow(
        { workflowId },
        { status: newStatus }
      );
      
      if (response.ok) {
        toast.success(`Workflow status changed to ${newStatus.toUpperCase()}`);
        loadWorkflows();
      } else {
        const errorData = await response.json().catch(() => ({ detail: 'Unknown error' }));
        console.error('❌ Failed to update workflow status:', errorData);
        toast.error(`Failed to update status: ${errorData.detail || 'Unknown error'}`);
      }
    } catch (error) {
      console.error('❌ Error updating workflow status:', error);
      toast.error('An error occurred while updating the workflow status');
    }
  };

  // Duplicate workflow handler
  const handleDuplicateWorkflow = async (workflowId: string) => {
    try {
      console.log('🔄 Duplicating workflow...', workflowId);
      
      // Find the workflow to duplicate
      const workflowToDuplicate = workflows.find(w => w.id === workflowId);
      if (!workflowToDuplicate) {
        toast.error('Workflow not found');
        return;
      }
      
      // Generate simple string IDs instead of UUIDs
      const generateStringId = () => {
        return `rule-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
      };

      console.log('🔄 Creating duplicate workflow data...');
      console.log('Original workflow:', workflowToDuplicate);

      // Create duplicate data structure matching create_workflow format
      const duplicateData = {
        name: `${workflowToDuplicate.name} (Copy)`,
        description: workflowToDuplicate.description || '',
        pricing_tier: workflowToDuplicate.pricing_tier || 'basic',
        status: 'draft', // Always create duplicates as draft
        trigger_condition: workflowToDuplicate.triggerCondition || 'automatic',
        workflow_type: 'sanctions', // Critical: This field is needed for filtering!
        introduction_tree_ids: [],
        classification_tree_ids: [],
        conditional_rules: workflowToDuplicate.conditionalRules?.map(rule => ({
          id: generateStringId(),
          condition: rule.condition,
          action: JSON.stringify({
            q1Value: rule.q1Value,
            q2Value: rule.q2Value, 
            q3Value: rule.q3Value,
            targetTree: rule.targetTree,
            targetNode: rule.targetNode,
            outcome: rule.outcome
          }),
          priority: rule.priority
        })) || [],
        outcomes: workflowToDuplicate.outcomes?.map(outcome => ({
          id: generateStringId(),
          title: outcome.title || '',
          description: outcome.description || '',
          action: outcome.action || ''
        })) || []
      };

      console.log('📤 Duplicate data to send:', duplicateData);
      console.log('📤 Duplicate data JSON:', JSON.stringify(duplicateData, null, 2));
      
      // Call the backend API to create the workflow
      const response = await brain.create_workflow(duplicateData);
      
      console.log('📡 API response status:', response.status);
      console.log('📡 API response ok:', response.ok);
      
      if (response.ok) {
        toast.success('Workflow duplicated successfully');
        loadWorkflows();
      } else {
        const errorData = await response.json().catch(() => ({ detail: 'Unknown error' }));
        console.error('❌ Failed to duplicate workflow - Status:', response.status);
        console.error('❌ Failed to duplicate workflow - Error:', errorData);
        toast.error(`Failed to duplicate workflow: ${errorData.detail || 'Unknown error'}`);
      }
    } catch (error) {
      console.error('❌ Error duplicating workflow:', error);
      toast.error('An error occurred while duplicating the workflow');
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-8">
        <div className="text-gray-400">Loading sanctions workflows...</div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-semibold text-white">Sanctions Workflows</h2>
          <p className="text-gray-400 mt-1">
            Manage conditional logic for Q4 routing in sanctions assessments
          </p>
        </div>
        <Button 
          className="bg-blue-600 hover:bg-blue-700"
          onClick={() => setShowCreateDialog(true)}
        >
          <Plus className="h-4 w-4 mr-2" />
          Create Workflow
        </Button>
      </div>

      {/* Workflows Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {workflows.map(renderWorkflowCard)}
      </div>

      {/* No workflows message */}
      {workflows.length === 0 && (
        <Card className="bg-gray-800/30 border-gray-700">
          <CardContent className="pt-6 text-center">
            <GitBranch className="h-12 w-12 text-gray-600 mx-auto mb-4" />
            <p className="text-gray-400">No sanctions workflows configured</p>
            <p className="text-gray-500 text-sm mt-1">
              Create workflows to handle conditional logic for Q4 routing
            </p>
          </CardContent>
        </Card>
      )}

      {/* Detailed Workflow Dialog */}
      {renderDetailedWorkflow()}

      {/* Edit Workflow Dialog */}
      <Dialog open={!!editingWorkflow} onOpenChange={() => setEditingWorkflow(null)}>
        <DialogContent className="bg-gray-900 border-gray-700 text-white max-w-4xl max-h-[90vh] flex flex-col">
          <DialogHeader className="flex-shrink-0">
            <DialogTitle className="text-white flex items-center gap-2">
              <Edit className="h-5 w-5 text-blue-400" />
              Edit Workflow: {editingWorkflow?.name}
            </DialogTitle>
            <DialogDescription className="text-gray-400">
              Modify the workflow configuration and conditional rules
            </DialogDescription>
          </DialogHeader>
          
          {/* Scrollable Content */}
          <div className="flex-1 overflow-y-auto pr-2">
            {editingWorkflow && editFormData && (
              <div className="space-y-6">
                {/* Basic Info */}
                <div className="space-y-4">
                  <div>
                    <label className="text-sm font-medium text-gray-300 mb-2 block">
                      Workflow Name
                    </label>
                    <input
                      type="text"
                      value={editFormData?.name || ''}
                      onChange={(e) => setEditFormData({ ...editFormData!, name: e.target.value })}
                      className="w-full bg-gray-800 border border-gray-600 rounded-md px-3 py-2 text-white"
                    />
                  </div>
                  
                  <div>
                    <label className="text-sm font-medium text-gray-300 mb-2 block">
                      Description
                    </label>
                    <textarea
                      value={editFormData?.description || ''}
                      onChange={(e) => setEditFormData({ ...editFormData!, description: e.target.value })}
                      rows={3}
                      className="w-full bg-gray-800 border border-gray-600 rounded-md px-3 py-2 text-white"
                    />
                  </div>
                  
                  <div>
                    <label className="text-sm font-medium text-gray-300 mb-2 block">
                      Trigger Condition
                    </label>
                    <input
                      type="text"
                      value={editFormData?.triggerCondition || ''}
                      onChange={(e) => setEditFormData({ ...editFormData!, triggerCondition: e.target.value })}
                      className="w-full bg-gray-800 border border-gray-600 rounded-md px-3 py-1 text-white"
                    />
                  </div>
                </div>
                
                {/* Conditional Rules - Now Editable */}
                <div>
                  <div className="flex justify-between items-center mb-4">
                    <h4 className="text-lg font-medium text-white flex items-center gap-2">
                      Conditional Rules
                    </h4>
                    <Button
                      size="sm"
                      variant="outline"
                      className="border-purple-500/30 text-purple-400 hover:bg-purple-500/10"
                      onClick={() => {
                        if (editFormData) {
                          const newRule: ConditionalRule = {
                            id: `rule-${Date.now()}`,
                            condition: 'New Condition',
                            q1Value: '',
                            q2Value: '',
                            q3Value: '',
                            targetTree: '',
                            targetNode: '',
                            outcome: '',
                            priority: editFormData.conditionalRules.length + 1
                          };
                          setEditFormData({
                            ...editFormData,
                            conditionalRules: [...editFormData.conditionalRules, newRule]
                          });
                        }
                      }}
                    >
                      <Plus className="h-4 w-4 mr-1" />
                      Add Rule
                    </Button>
                  </div>
                  <div className="space-y-4">
                    {editFormData.conditionalRules.map((rule, index) => (
                      <div key={rule.id} className="bg-gray-800/50 p-4 rounded-lg border border-gray-600 relative">
                        <div className="absolute top-2 right-2">
                          <Button
                            size="sm"
                            variant="ghost"
                            className="text-red-400 hover:text-red-300 hover:bg-red-500/10"
                            onClick={() => {
                              if (editFormData) {
                                const updatedRules = editFormData.conditionalRules.filter((_, i) => i !== index);
                                setEditFormData({
                                  ...editFormData,
                                  conditionalRules: updatedRules
                                });
                              }
                            }}
                          >
                            <X className="h-4 w-4" />
                          </Button>
                        </div>
                        
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <label className="text-sm font-medium text-gray-300 mb-1 block">
                              Condition Name
                            </label>
                            <input
                              type="text"
                              value={rule.condition || ''}
                              onChange={(e) => {
                                if (editFormData) {
                                  const updatedRules = [...editFormData.conditionalRules];
                                  updatedRules[index] = { ...rule, condition: e.target.value };
                                  setEditFormData({ ...editFormData, conditionalRules: updatedRules });
                                }
                              }}
                              className="w-full bg-gray-800 border border-gray-600 rounded-md px-3 py-2 text-white"
                            />
                          </div>
                          <div>
                            <label className="text-sm font-medium text-gray-300 mb-1 block">
                              Priority
                            </label>
                            <input
                              type="number"
                              value={rule.priority || 1}
                              onChange={(e) => {
                                if (editFormData) {
                                  const updatedRules = [...editFormData.conditionalRules];
                                  updatedRules[index] = { ...rule, priority: parseInt(e.target.value) || 1 };
                                  setEditFormData({ ...editFormData, conditionalRules: updatedRules });
                                }
                              }}
                              className="w-full bg-gray-800 border border-gray-600 rounded-md px-3 py-2 text-white"
                            />
                          </div>
                        </div>
                        
                        <div className="grid grid-cols-3 gap-4 mt-4">
                          <div>
                            <label className="text-sm font-medium text-gray-300 mb-1 block">
                              Q1 Value
                            </label>
                            <input
                              type="text"
                              value={rule.q1Value || ''}
                              onChange={(e) => {
                                if (editFormData) {
                                  const updatedRules = [...editFormData.conditionalRules];
                                  updatedRules[index] = { ...rule, q1Value: e.target.value };
                                  setEditFormData({ ...editFormData, conditionalRules: updatedRules });
                                }
                              }}
                              placeholder="e.g., EU"
                              className="w-full bg-gray-800 border border-gray-600 rounded-md px-3 py-2 text-white"
                            />
                          </div>
                          <div>
                            <label className="text-sm font-medium text-gray-300 mb-1 block">
                              Q2 Value
                            </label>
                            <input
                              type="text"
                              value={rule.q2Value || ''}
                              onChange={(e) => {
                                if (editFormData) {
                                  const updatedRules = [...editFormData.conditionalRules];
                                  updatedRules[index] = { ...rule, q2Value: e.target.value };
                                  setEditFormData({ ...editFormData, conditionalRules: updatedRules });
                                }
                              }}
                              placeholder="i.e., Export"
                              className="w-full bg-gray-800 border border-gray-600 rounded-md px-3 py-2 text-white"
                            />
                          </div>
                          <div>
                            <label className="text-sm font-medium text-gray-300 mb-1 block">
                              Q3 Value
                            </label>
                            <input
                              type="text"
                              value={rule.q3Value || ''}
                              onChange={(e) => {
                                if (editFormData) {
                                  const updatedRules = [...editFormData.conditionalRules];
                                  updatedRules[index] = { ...rule, q3Value: e.target.value };
                                  setEditFormData({ ...editFormData, conditionalRules: updatedRules });
                                }
                              }}
                              placeholder="i.e., Export"
                              className="w-full bg-gray-800 border border-gray-600 rounded-md px-3 py-2 text-white"
                            />
                          </div>
                        </div>
                        
                        <div className="grid grid-cols-2 gap-4 mt-4">
                          <div>
                            <label className="text-sm font-medium text-gray-300 mb-1 block">
                              Target Tree
                            </label>
                            <Select
                              value={rule.targetTree || ''}
                              onValueChange={(value) => {
                                if (editFormData) {
                                  const updatedRules = [...editFormData.conditionalRules];
                                  updatedRules[index] = { ...rule, targetTree: value, targetNode: '' }; // Reset target node when tree changes
                                  setEditFormData({ ...editFormData, conditionalRules: updatedRules });
                                  // Load nodes for the selected tree
                                  loadNodesForTree(value);
                                }
                              }}
                            >
                              <SelectTrigger className="w-full bg-gray-800 border border-gray-600 text-white">
                                <SelectValue placeholder="Select a tree..." />
                              </SelectTrigger>
                              <SelectContent className="bg-gray-800 border border-gray-600">
                                {availableTrees.map(tree => (
                                  <SelectItem key={tree.id} value={tree.id} className="text-white hover:bg-gray-700">
                                    {tree.name}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </div>
                          <div>
                            <label className="text-sm font-medium text-gray-300 mb-1 block">
                              Target Node/Question
                            </label>
                            <Select
                              value={rule.targetNode || ''}
                              onValueChange={(value) => {
                                if (editFormData) {
                                  const updatedRules = [...editFormData.conditionalRules];
                                  updatedRules[index] = { ...rule, targetNode: value };
                                  setEditFormData({ ...editFormData, conditionalRules: updatedRules });
                                }
                              }}
                              disabled={!rule.targetTree}
                            >
                              <SelectTrigger className="w-full bg-gray-800 border border-gray-600 text-white">
                                <SelectValue placeholder={rule.targetTree ? "Select a node/question..." : "Select a tree first"} />
                              </SelectTrigger>
                              <SelectContent className="bg-gray-800 border border-gray-600">
                                {getNodesForTree(rule.targetTree).map(node => (
                                  <SelectItem key={node.id} value={node.id} className="text-white hover:bg-gray-700">
                                    {node.node_key} - {node.question_text}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </div>
                          <div>
                            <label className="text-sm font-medium text-gray-300 mb-1 block">
                              Outcome
                            </label>
                            <div className="relative dropdown-container">
                              <Button
                                type="button"
                                variant="outline"
                                className={cn(
                                  "w-full justify-between bg-gray-800 border border-gray-600 text-white hover:bg-gray-700",
                                  !rule.outcome && "text-gray-400"
                                )}
                                disabled={loadingOutcomes}
                                onClick={() => {
                                  // Toggle dropdown visibility for this specific rule
                                  const dropdownKey = `outcome-${index}`;
                                  console.log('🔍 Outcome dropdown clicked for rule:', index, 'Current state:', dropdownOpen[dropdownKey]);
                                  console.log('📊 Available outcomes count:', availableOutcomes.length);
                                  setDropdownOpen(prev => {
                                    const newState = { ...prev, [dropdownKey]: !prev[dropdownKey] };
                                    console.log('🔄 Setting dropdown state:', newState);
                                    return newState;
                                  });
                                }}
                              >
                                {loadingOutcomes ? (
                                  "Loading outcomes..."
                                ) : rule.outcome ? (
                                  (() => {
                                    const selectedOutcome = availableOutcomes.find(o => o.outcome_code === rule.outcome);
                                    return selectedOutcome ? (
                                      <div className="flex flex-col items-start">
                                        <span className="font-medium">{selectedOutcome.outcome_code}</span>
                                        <span className="text-sm text-gray-400">{selectedOutcome.outcome_title}</span>
                                      </div>
                                    ) : (
                                      <span className="text-yellow-400">⚠️ {rule.outcome} (not found)</span>
                                    );
                                  })()
                                ) : (
                                  "Select an outcome..."
                                )}
                                < ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                              </Button>
                              
                              {/* Dropdown content */}
                              {dropdownOpen[`outcome-${index}`] && (
                                <div className="absolute top-full left-0 w-full bg-gray-800 border border-gray-600 rounded-md shadow-lg max-h-60 overflow-auto z-[100]" style={{ zIndex: 9999 }}>
                                  {/* None option */}
                                  <div
                                    className="flex items-center px-3 py-2 text-white hover:bg-gray-700 cursor-pointer border-b border-gray-700"
                                    onClick={() => {
                                      if (editFormData) {
                                        const updatedRules = [...editFormData.conditionalRules];
                                        updatedRules[index] = { ...rule, outcome: '' };
                                        setEditFormData({ ...editFormData, conditionalRules: updatedRules });
                                        // Close dropdown
                                        setDropdownOpen(prev => ({ ...prev, [`outcome-${index}`]: false }));
                                      }
                                    }}
                                  >
                                    <Check
                                      className={cn(
                                        "mr-2 h-4 w-4",
                                        !rule.outcome ? "opacity-100" : "opacity-0"
                                      )}
                                    />
                                    <span>None (no outcome)</span>
                                  </div>
                                  
                                  {/* Outcomes list */}
                                  {availableOutcomes.map(outcome => (
                                    <div
                                      key={outcome.id}
                                      className="flex items-center px-3 py-2 text-white hover:bg-gray-700 cursor-pointer border-b border-gray-700 last:border-b-0"
                                      onClick={() => {
                                        if (editFormData) {
                                          const updatedRules = [...editFormData.conditionalRules];
                                          updatedRules[index] = { ...rule, outcome: outcome.outcome_code };
                                          setEditFormData({ ...editFormData, conditionalRules: updatedRules });
                                          // Close dropdown
                                          setDropdownOpen(prev => ({ ...prev, [`outcome-${index}`]: false }));
                                        }
                                      }}
                                    >
                                      <Check
                                        className={cn(
                                          "mr-2 h-4 w-4 flex-shrink-0",
                                          rule.outcome === outcome.outcome_code ? "opacity-100" : "opacity-0"
                                        )}
                                      />
                                      <div className="flex flex-col min-w-0">
                                        <span className="font-medium text-sm">{outcome.outcome_code}</span>
                                        <span className="text-xs text-gray-400 truncate">{outcome.outcome_title}</span>
                                      </div>
                                    </div>
                                  ))}
                                </div>
                              )}
                              
                              {/* Portal-rendered dropdown for better positioning */}
                              {dropdownOpen[`outcome-${index}`] && typeof window !== 'undefined' && createPortal(
                                <div 
                                  className="fixed bg-gray-800 border border-gray-600 rounded-md shadow-xl max-h-80 overflow-auto z-[9999] min-w-[400px]"
                                  style={{
                                    top: '50%',
                                    left: '50%',
                                    transform: 'translate(-50%, -50%)',
                                    maxHeight: '400px'
                                  }}
                                >
                                  <div className="p-2 border-b border-gray-700 bg-gray-700">
                                    <div className="text-sm font-medium text-white">Select Outcome</div>
                                    <div className="text-xs text-gray-300">Choose an outcome for this rule</div>
                                  </div>
                                  
                                  {/* None option */}
                                  <div
                                    className="flex items-center px-3 py-3 text-white hover:bg-gray-700 cursor-pointer border-b border-gray-700"
                                    onClick={() => {
                                      if (editFormData) {
                                        const updatedRules = [...editFormData.conditionalRules];
                                        updatedRules[index] = { ...rule, outcome: '' };
                                        setEditFormData({ ...editFormData, conditionalRules: updatedRules });
                                        // Close dropdown
                                        setDropdownOpen(prev => ({ ...prev, [`outcome-${index}`]: false }));
                                      }
                                    }}
                                  >
                                    <Check
                                      className={cn(
                                        "mr-3 h-4 w-4",
                                        !rule.outcome ? "opacity-100 text-green-400" : "opacity-0"
                                      )}
                                    />
                                    <div>
                                      <div className="font-medium">None</div>
                                      <div className="text-sm text-gray-400">No outcome specified</div>
                                    </div>
                                  </div>
                                  
                                  {/* Outcomes list */}
                                  {availableOutcomes.map(outcome => (
                                    <div
                                      key={outcome.id}
                                      className="flex items-center px-3 py-3 text-white hover:bg-gray-700 cursor-pointer border-b border-gray-700 last:border-b-0"
                                      onClick={() => {
                                        if (editFormData) {
                                          const updatedRules = [...editFormData.conditionalRules];
                                          updatedRules[index] = { ...rule, outcome: outcome.outcome_code };
                                          setEditFormData({ ...editFormData, conditionalRules: updatedRules });
                                          // Close dropdown
                                          setDropdownOpen(prev => ({ ...prev, [`outcome-${index}`]: false }));
                                        }
                                      }}
                                    >
                                      <Check
                                        className={cn(
                                          "mr-3 h-4 w-4 flex-shrink-0",
                                          rule.outcome === outcome.outcome_code ? "opacity-100 text-green-400" : "opacity-0"
                                        )}
                                      />
                                      <div className="flex flex-col min-w-0">
                                        <span className="font-medium">{outcome.outcome_code}</span>
                                        <span className="text-sm text-gray-400">{outcome.outcome_title}</span>
                                      </div>
                                    </div>
                                  ))}
                                  
                                  <div className="p-2 border-t border-gray-700 bg-gray-800">
                                    <div className="text-xs text-gray-400">Showing {availableOutcomes.length} available outcomes</div>
                                  </div>
                                </div>,
                                document.body
                              )}
                            </div>
                            {loadingOutcomes && (
                              <p className="text-xs text-gray-500 mt-1">Loading available outcomes...</p>
                            )}
                            {rule.outcome && !availableOutcomes.some(o => o.outcome_code === rule.outcome) && (
                              <p className="text-xs text-yellow-400 mt-1">
                                ⚠️ Current outcome "{rule.outcome}" not found in available outcomes
                              </p>
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>
          
          {/* Fixed Action Buttons */}
          <DialogFooter className="flex-shrink-0 border-t border-gray-700 pt-4 mt-4">
            <Button 
              variant="outline" 
              onClick={() => {
                setEditingWorkflow(null);
                setEditFormData(null);
              }}
              disabled={saving}
            >
              Cancel
            </Button>
            <Button 
              onClick={handleSaveWorkflow}
              disabled={saving}
              className="bg-purple-600 hover:bg-purple-700"
            >
              {saving ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
                  Saving...
                </>
              ) : (
                'Save Changes'
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Create Workflow Dialog - Functional Form */}
      <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
        <DialogContent className="bg-gray-900 border-gray-700 text-white">
          <DialogHeader>
            <DialogTitle className="text-blue-400">Create Sanctions Workflow</DialogTitle>
          </DialogHeader>
          <div className="py-4">
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium text-gray-300 mb-2 block">
                  Workflow Name
                </label>
                <input
                  type="text"
                  value={createFormData.name}
                  onChange={(e) => setCreateFormData({ ...createFormData, name: e.target.value })}
                  className="w-full bg-gray-800 border border-gray-600 rounded-md px-3 py-2 text-white"
                />
              </div>
              
              <div>
                <label className="text-sm font-medium text-gray-300 mb-2 block">
                  Description
                </label>
                <textarea
                  value={createFormData.description}
                  onChange={(e) => setCreateFormData({ ...createFormData, description: e.target.value })}
                  rows={3}
                  className="w-full bg-gray-800 border border-gray-600 rounded-md px-3 py-2 text-white"
                />
              </div>
              
              <div>
                <label className="text-sm font-medium text-gray-300 mb-2 block">
                  Trigger Condition
                </label>
                <input
                  type="text"
                  value={createFormData.trigger_condition}
                  onChange={(e) => setCreateFormData({ ...createFormData, trigger_condition: e.target.value })}
                  className="w-full bg-gray-800 border border-gray-600 rounded-md px-3 py-1 text-white"
                />
              </div>
              
              <div>
                <label className="text-sm font-medium text-gray-300 mb-2 block">
                  Pricing Tier
                </label>
                <Select
                  value={createFormData.pricing_tier}
                  onValueChange={(value) => setCreateFormData({ ...createFormData, pricing_tier: value })}
                >
                  <SelectTrigger className="w-full bg-gray-800 border border-gray-600 text-white">
                    <SelectValue placeholder="Select a pricing tier..." />
                  </SelectTrigger>
                  <SelectContent className="bg-gray-800 border border-gray-600">
                    <SelectItem value="basic" className="text-white hover:bg-gray-700">
                      Basic
                    </SelectItem>
                    <SelectItem value="professional" className="text-white hover:bg-gray-700">
                      Professional
                    </SelectItem>
                    <SelectItem value="enterprise" className="text-white hover:bg-gray-700">
                      Enterprise
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setShowCreateDialog(false)} disabled={creating}>
              Cancel
            </Button>
            <Button 
              className="bg-blue-600 hover:bg-blue-700" 
              onClick={handleCreateWorkflow}
              disabled={creating || !createFormData.name.trim()}
            >
              {creating ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-1" />
                  Creating...
                </>
              ) : (
                'Create Workflow'
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default SanctionsWorkflowsTab;
