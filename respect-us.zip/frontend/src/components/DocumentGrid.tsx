import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { FileText, Eye, BarChart3, ExternalLink } from 'lucide-react';
import { DocumentResponse } from 'types';
import { APP_BASE_PATH } from 'app';

interface Props {
  documents: DocumentResponse[];
  onDocumentClick: (document: DocumentResponse) => void;
  onDocumentStructureClick: (document: DocumentResponse) => void;
}

export const DocumentGrid: React.FC<Props> = ({ 
  documents, 
  onDocumentClick, 
  onDocumentStructureClick 
}) => {
  const handlePDFView = (documentId: number, documentTitle: string) => {
    const pdfViewerPath = `pdf-viewer-tab?documentId=${documentId}&title=${encodeURIComponent(documentTitle)}`;
    const fullUrl = `${window.location.origin}${APP_BASE_PATH}/${pdfViewerPath}`;
    console.log('Opening PDF viewer:', { documentId, documentTitle, pdfViewerUrl: fullUrl });
    window.open(fullUrl, '_blank', 'noopener,noreferrer');
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {documents.map((document) => (
        <Card 
          key={document.id} 
          className="bg-gray-800/30 border-gray-700 hover:bg-gray-800/50 transition-colors group"
        >
          <CardHeader className="pb-2">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-2">
                <FileText className="h-5 w-5 text-blue-400" />
                <CardTitle className="text-lg font-semibold text-white truncate">
                  {document.title}
                </CardTitle>
              </div>
            </div>
            {document.description && (
              <CardDescription className="text-gray-300 line-clamp-2">
                {document.description}
              </CardDescription>
            )}
          </CardHeader>
          
          <CardContent className="pt-2">
            <div className="flex flex-wrap gap-2 mb-4">
              {document.file_type && (
                <Badge variant="secondary" className="bg-blue-900/30 text-blue-300">
                  {document.file_type.toUpperCase()}
                </Badge>
              )}
              {document.file_size && (
                <Badge variant="outline" className="border-gray-600 text-gray-300">
                  {(document.file_size / 1024 / 1024).toFixed(1)} MB
                </Badge>
              )}
            </div>
            
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => onDocumentClick(document)}
                className="flex-1 border-gray-600 hover:bg-gray-700"
              >
                <Eye className="h-4 w-4 mr-2" />
                View
              </Button>
              
              {/* PDF Viewer button for PDF documents */}
              {document.file_type === 'application/pdf' && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handlePDFView(document.id, document.title)}
                  className="flex-1 border-amber-600 text-amber-300 hover:bg-amber-600/20"
                >
                  <ExternalLink className="h-4 w-4 mr-2" />
                  PDF
                </Button>
              )}
              
              <Button
                variant="outline"
                size="sm"
                onClick={() => onDocumentStructureClick(document)}
                className="flex-1 border-gray-600 hover:bg-gray-700"
              >
                <BarChart3 className="h-4 w-4 mr-2" />
                Structure
              </Button>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
};
