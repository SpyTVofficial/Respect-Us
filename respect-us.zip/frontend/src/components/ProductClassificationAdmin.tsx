import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { ChevronDown, ChevronRight, Edit, Copy, Trash2, Plus, FileText, Target, Settings, Eye, EyeOff, Download, Upload } from 'lucide-react';
import { toast } from 'sonner';
import brain from 'brain';
import EditOutcomeDialog from './EditOutcomeDialog';
import IntroductionTreesTab from './IntroductionTreesTab';
import { validateRoutingRule, EXAMPLE_ROUTING_RULES } from 'utils/routingRules';
import {
  ClassificationTree,
  TreeNode,
  NodeOption,
  ClassificationOutcome,
  TreeNodeCreate,
  NodeOptionCreate,
  NodeOptionUpdate,
  ClassificationOutcomeCreate,
  ClassificationNote,
  NoteCreate
} from '../brain/data-contracts';

interface ProductClassificationAdminProps {
  // Tree management
  classificationTrees: ClassificationTree[];
  selectedTree: ClassificationTree | null;
  treeNodes: TreeNode[];
  nodeOptions: { [nodeId: string]: NodeOption[] };
  classificationOutcomes: ClassificationOutcome[];
  
  // Dialog states
  isCreateTreeOpen: boolean;
  isCreateNodeOpen: boolean;
  isCreateOutcomeOpen: boolean;
  isCreateNoteOpen: boolean;
  isEditNoteOpen: boolean;
  selectedNote: ClassificationNote | null;
  newNoteData: NoteCreate;
  classificationNotes: ClassificationNote[];
  showCreateNoteDialog: boolean;
  
  // Form data
  newTreeData: {
    name: string;
    description: string;
    regulation_category: string;
    version: string;
  };
  newNodeData: TreeNodeCreate;
  newOutcomeData: ClassificationOutcomeCreate;
  
  // Setters
  setIsCreateTreeOpen: (open: boolean) => void;
  setIsCreateNodeOpen: (open: boolean) => void;
  setIsCreateOutcomeOpen: (open: boolean) => void;
  setIsCreateNoteOpen: (open: boolean) => void;
  setIsEditNoteOpen: (open: boolean) => void;
  setSelectedNote: (note: ClassificationNote | null) => void;
  setNewNoteData: (data: NoteCreate) => void;
  setClassificationNotes: (notes: ClassificationNote[]) => void;
  setShowCreateNoteDialog: (show: boolean) => void;
  setNewTreeData: (data: any) => void;
  setNewNodeData: (data: TreeNodeCreate) => void;
  setNewOutcomeData: (data: ClassificationOutcomeCreate) => void;
  
  // Functions
  onTreeSelect: (tree: ClassificationTree) => void;
  loadTreeDetails: (tree: ClassificationTree) => void;
  handleCreateTree: () => void;
  handleCreateNode: () => void;
  handleCreateOutcome: () => void;
  handleCreateNote: () => void;
  handleUpdateNote: () => void;
  handleDeleteTree: (treeId: string, treeName: string) => void;
  handleDeleteNote: (noteId: number) => void;
  handleDuplicateTree: (treeId: string, treeName: string) => void;
  loadClassificationNotes: () => void;
}

const ProductClassificationAdmin: React.FC<ProductClassificationAdminProps> = ({
  classificationTrees,
  selectedTree,
  treeNodes,
  nodeOptions,
  classificationOutcomes,
  isCreateTreeOpen,
  isCreateNodeOpen,
  isCreateOutcomeOpen,
  isCreateNoteOpen,
  isEditNoteOpen,
  selectedNote,
  newNoteData,
  classificationNotes,
  showCreateNoteDialog,
  newTreeData,
  newNodeData,
  newOutcomeData,
  setIsCreateTreeOpen,
  setIsCreateNodeOpen,
  setIsCreateOutcomeOpen,
  setIsEditNoteOpen,
  setSelectedNote,
  setNewNoteData,
  setClassificationNotes,
  setShowCreateNoteDialog,
  setNewTreeData,
  setNewNodeData,
  setNewOutcomeData,
  onTreeSelect,
  loadTreeDetails,
  handleCreateTree,
  handleCreateNode,
  handleCreateOutcome,
  handleCreateNote,
  handleUpdateNote,
  handleDeleteTree,
  handleDeleteNote,
  handleDuplicateTree,
  loadClassificationNotes
}) => {
  // Local state for UI interactions ONLY (not duplicating props)
  const [expandedNodes, setExpandedNodes] = useState<Set<string>>(new Set());
  const [editingNode, setEditingNode] = useState<TreeNode | null>(null);
  const [isEditNodeOpen, setIsEditNodeOpen] = useState(false);
  const [managingOptionsForNode, setManagingOptionsForNode] = useState<TreeNode | null>(null);
  const [isManageOptionsOpen, setIsManageOptionsOpen] = useState(false);
  const [editingOutcome, setEditingOutcome] = useState<ClassificationOutcome | null>(null);
  const [isEditOutcomeOpen, setIsEditOutcomeOpen] = useState(false);
  const [newOptionData, setNewOptionData] = useState<NodeOptionCreate>({
    option_text: '',
    option_value: '',
    routing_rule: '',
    regulatory_notes: [],
    display_order: 0,
    note: ''
  });
  const [editingOption, setEditingOption] = useState<NodeOption | null>(null);
  const [isEditOptionOpen, setIsEditOptionOpen] = useState(false);
  const [editOptionData, setEditOptionData] = useState<NodeOptionUpdate>({
    option_text: '',
    option_value: '',
    routing_rule: '',
    regulatory_notes: [],
    display_order: 0
  });
  const [expandedOutcomes, setExpandedOutcomes] = useState<Set<string>>(new Set());
  const [isAddNoteOpen, setIsAddNoteOpen] = useState(false);
  const [selectedNodeForNote, setSelectedNodeForNote] = useState<TreeNode | null>(null);
  const [noteText, setNoteText] = useState('');
  const [noteKey, setNoteKey] = useState(''); // NEW: Note Key state
  const [importFile, setImportFile] = useState<File | null>(null);

  // Node action handlers
  const handleShowNode = (nodeId: string) => {
    const newExpanded = new Set(expandedNodes);
    if (newExpanded.has(nodeId)) {
      newExpanded.delete(nodeId);
    } else {
      newExpanded.add(nodeId);
    }
    setExpandedNodes(newExpanded);
  };

  const handleEditNode = (node: TreeNode) => {
    setEditingNode(node);
    setIsEditNodeOpen(true);
  };

  // IMPROVED: Enhanced duplicate node functionality
  const handleDuplicateNode = async (node: TreeNode) => {
    try {
      // Create duplicate with modified key
      const duplicateData: TreeNodeCreate = {
        node_key: `${node.node_key}_copy`,
        title: `${node.title} (Copy)`,
        description: node.description,
        question_text: node.question_text,
        question_type: node.question_type,
        is_root: false, // Duplicates should not be root nodes
        parent_node_id: node.parent_node_id,
        display_order: (node as any).display_order ? (node as any).display_order + 1 : 0,
        notes: (node as any).notes || '' // Add missing notes field
      };
      
      console.log('Duplicating node:', duplicateData);
      const response = await brain.create_tree_node({ treeId: node.tree_id }, duplicateData);
      
      if (!response.ok) {
        let errorMessage = 'Failed to duplicate node';
        try {
          const errorData = await response.json();
          errorMessage = errorData.detail || errorMessage;
        } catch {}
        toast.error(errorMessage);
        return;
      }
      
      toast.success('Node duplicated successfully');
      
      // FIXED: Reload tree details to refresh the view and ensure outcomes are loaded
      if (selectedTree) {
        console.log('Reloading tree details after duplication...');
        loadTreeDetails(selectedTree);
      }
    } catch (error) {
      console.error('Error duplicating node:', error);
      toast.error('Failed to duplicate node');
    }
  };

  // NEW: Add Note functionality with Note Key support
  const handleAddNote = (node: TreeNode) => {
    setSelectedNodeForNote(node);
    setNoteKey(''); // Reset note key
    setNoteText(''); // Reset note text
    setIsAddNoteOpen(true);
  };

  const handleSaveNote = async () => {
    if (!selectedNodeForNote || !noteKey.trim() || !noteText.trim()) {
      toast.error('Please fill in all required fields');
      return;
    }

    try {
      const noteData: NoteCreate = {
        note_key: noteKey.trim(),
        title: `Note for ${selectedNodeForNote.title}`,
        content: noteText.trim(),
        tree_id: selectedNodeForNote.tree_id
      };

      console.log('Creating note:', noteData);
      const response = await brain.create_classification_note(noteData);
      
      if (response.ok) {
        toast.success('Note created successfully');
        setIsAddNoteOpen(false);
        setSelectedNodeForNote(null);
        setNoteKey('');
        setNoteText('');
        console.log('🔄 Refreshing notes list after note creation...');
        await loadClassificationNotes();
        console.log('✅ Notes list refreshed successfully');
      } else {
        const errorData = await response.json().catch(() => null);
        toast.error(`Failed to create note: ${errorData?.detail || 'Unknown error'}`);
      }
    } catch (error) {
      console.error('Error creating note:', error);
      toast.error('Failed to create note');
    }
  };

  const handleSaveEditedNode = async () => {
    if (!editingNode || !editingNode.id) {
      toast.error('No node selected for editing');
      return;
    }

    try {
      const updateData = {
        node_key: editingNode.node_key,
        title: editingNode.title,
        description: editingNode.description,
        question_text: editingNode.question_text,
        question_type: editingNode.question_type,
        is_root: editingNode.is_root,
        parent_node_id: editingNode.parent_node_id,
        notes: (editingNode as any).notes || '' // Add missing notes field
      };
      
      console.log('Updating node:', updateData);
      const response = await brain.update_tree_node(
        { nodeId: editingNode.id },
        updateData
      );

      if (response.ok) {
        toast.success('Node updated successfully');
        setIsEditNodeOpen(false);
        setEditingNode(null);
        // Reload tree details
        if (selectedTree) {
          loadTreeDetails(selectedTree);
        }
      } else {
        const errorData = await response.json().catch(() => null);
        toast.error(`Failed to update node: ${errorData?.detail || 'Unknown error'}`);
      }
    } catch (error) {
      console.error('Error updating node:', error);
      toast.error('Failed to update node');
    }
  };

  const handleManageOptions = (node: TreeNode) => {
    setManagingOptionsForNode(node);
    setIsManageOptionsOpen(true);
  };

  const handleEditOutcome = (outcome: ClassificationOutcome) => {
    console.log('🎯 EDIT OUTCOME HANDLER called with:', outcome);
    setEditingOutcome(outcome);
    setIsEditOutcomeOpen(true);
  };

  const handleEditOption = (option: NodeOption) => {
    setEditingOption(option);
    setEditOptionData({
      option_text: option.option_text,
      option_value: option.option_value,
      routing_rule: option.routing_rule || '',
      regulatory_notes: option.regulatory_notes || [],
      display_order: option.display_order,
      note: option.note || ''
    });
    setIsEditOptionOpen(true);
  };

  const handleDuplicateOutcome = async (outcome: ClassificationOutcome) => {
    try {
      const duplicateData: ClassificationOutcomeCreate = {
        outcome_code: `${outcome.outcome_code}_copy`,
        outcome_title: `${outcome.outcome_title} (Copy)`,
        description: outcome.description,
        regulatory_basis: outcome.regulatory_basis,
        outcome_text: outcome.outcome_text,
        guidance_notes: outcome.guidance_notes,
        is_controlled: outcome.is_controlled
      };
      
      console.log('Duplicating outcome:', duplicateData);
      const response = await brain.create_classification_outcome(
        { treeId: outcome.tree_id },
        duplicateData
      );
      
      if (response.ok) {
        toast.success('Outcome duplicated successfully');
        // Reload tree details
        if (selectedTree) {
          loadTreeDetails(selectedTree);
        }
      } else {
        const errorData = await response.json().catch(() => null);
        toast.error(`Failed to duplicate outcome: ${errorData?.detail || 'Unknown error'}`);
      }
    } catch (error) {
      console.error('Error duplicating outcome:', error);
      toast.error('Failed to duplicate outcome');
    }
  };

  const handleDeleteOutcome = async (outcome: ClassificationOutcome) => {
    try {
      console.log('Deleting outcome:', outcome.id);
      const response = await brain.delete_classification_outcome({ outcomeId: outcome.id });
      
      if (response.ok) {
        toast.success('Outcome deleted successfully');
        // Reload tree details
        if (selectedTree) {
          loadTreeDetails(selectedTree);
        }
      } else {
        const errorData = await response.json().catch(() => null);
        toast.error(`Failed to delete outcome: ${errorData?.detail || 'Unknown error'}`);
      }
    } catch (error) {
      console.error('Error deleting outcome:', error);
      toast.error('Failed to delete outcome');
    }
  };

  const handleDeleteNode = async (nodeId: string, nodeKey: string) => {
    try {
      const response = await brain.delete_tree_node({ nodeId });
      
      if (response.ok) {
        toast.success(`Node "${nodeKey}" deleted successfully`);
        // Reload tree details
        if (selectedTree) {
          loadTreeDetails(selectedTree);
        }
      } else {
        const errorData = await response.json().catch(() => null);
        toast.error(`Failed to delete node: ${errorData?.detail || 'Unknown error'}`);
      }
    } catch (error) {
      console.error('Error deleting node:', error);
      toast.error('Failed to delete node');
    }
  };

  // Export Excel handler
  const handleExportExcel = async () => {
    if (!selectedTree) {
      toast.error('Please select a tree first');
      return;
    }

    if (classificationNotes.length === 0) {
      toast.error('No notes available to export');
      return;
    }

    try {
      const response = await brain.export_notes_to_excel({ 
        treeId: selectedTree.id,
        module_type: 'product_classification'
      });
      
      if (response.ok) {
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `regulatory_notes_${selectedTree.name}_${new Date().toISOString().split('T')[0]}.xlsx`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        window.URL.revokeObjectURL(url);
        
        toast.success(`Excel export completed! ${classificationNotes.length} notes exported`);
      } else {
        toast.error('Failed to export notes to Excel');
      }
    } catch (error) {
      console.error('Error exporting notes:', error);
      toast.error('Failed to export notes to Excel');
    }
  };

  // Import Excel handler
  const handleImportExcel = async () => {
    if (!selectedTree) {
      toast.error('Please select a tree first');
      return;
    }

    // Create file input element
    const fileInput = document.createElement('input');
    fileInput.type = 'file';
    fileInput.accept = '.xlsx,.xls';
    
    fileInput.onchange = async (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (!file) return;

      try {
        const response = await brain.import_notes_from_excel(
          { 
            treeId: selectedTree.id,
            module_type: 'product_classification'
          },
          { file_content: file }
        );
        
        if (response.ok) {
          const result = await response.json();
          toast.success(`Import completed! ${result.imported_count} notes imported, ${result.error_count} errors`);
          // Refresh the notes list
          loadClassificationNotes();
        } else {
          toast.error('Failed to import notes from Excel');
        }
      } catch (error) {
        console.error('Error importing notes:', error);
        toast.error('Failed to import notes from Excel');
      }
    };
    
    fileInput.click();
  };

  return (
    <div className="space-y-6 p-6 bg-gray-900 min-h-screen">
      <div className="border-b border-gray-700 pb-4">
        <h2 className="text-2xl font-bold text-amber-400 mb-2">Product Classification Management</h2>
        <p className="text-gray-400">Manage classification trees, nodes, outcomes, and regulatory notes</p>
      </div>

      <Tabs defaultValue="trees" className="space-y-6">
        <TabsList className="bg-gray-800 border-gray-700">
          <TabsTrigger value="trees" className="data-[state=active]:bg-amber-600">Classification Trees</TabsTrigger>
          <TabsTrigger value="outcomes" className="data-[state=active]:bg-amber-600">Outcomes</TabsTrigger>
          <TabsTrigger value="notes" className="data-[state=active]:bg-amber-600">Regulatory Notes</TabsTrigger>
        </TabsList>

        {/* Classification Trees Tab */}
        <TabsContent value="trees" className="space-y-6">
          <div className="flex justify-between items-center">
            <h3 className="text-xl font-semibold text-white">Classification Trees</h3>
            <Button 
              onClick={() => setIsCreateTreeOpen(true)}
              className="bg-amber-600 hover:bg-amber-700 text-white"
            >
              <Plus className="w-4 h-4 mr-2" />
              Create Tree
            </Button>
          </div>

          {/* Trees List */}
          <div className="grid gap-4">
            {classificationTrees.map((tree) => (
              <Card key={tree.id} className="bg-gray-800/50 border-gray-700 hover:border-amber-500/50 transition-colors">
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <Target className="w-6 h-6 text-amber-400" />
                      <div>
                        <CardTitle className="text-white text-lg">{tree.name}</CardTitle>
                        <p className="text-gray-400 text-sm">{tree.description}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge className="bg-amber-600/20 text-amber-400">
                        v{tree.version}
                      </Badge>
                      <Badge variant="outline" className="border-gray-600">
                        {tree.regulation_category}
                      </Badge>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="pt-0">
                  <div className="flex items-center gap-2 mb-3">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => {
                        onTreeSelect(tree);
                        loadTreeDetails(tree);
                      }}
                      className="text-gray-300 border-gray-600 hover:bg-gray-700"
                      disabled={selectedTree?.id === tree.id}
                    >
                      <Edit className="w-4 h-4 mr-1" />
                      {selectedTree?.id === tree.id ? 'Editing...' : 'Edit'}
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleDuplicateTree(tree.id, tree.name)}
                      className="text-blue-300 border-gray-600 hover:bg-gray-700"
                    >
                      <Copy className="w-4 h-4 mr-1" />
                      Duplicate
                    </Button>
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button
                          size="sm"
                          variant="outline"
                          className="text-red-400 border-gray-600 hover:bg-red-900/20"
                        >
                          <Trash2 className="w-4 h-4 mr-1" />
                          Delete
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent className="bg-gray-900 border-gray-700">
                        <AlertDialogHeader>
                          <AlertDialogTitle className="text-white">Delete Classification Tree</AlertDialogTitle>
                          <AlertDialogDescription className="text-gray-400">
                            Are you sure you want to delete "{tree.name}"? This action cannot be undone and will remove all nodes, outcomes, and notes associated with this tree.
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel className="bg-gray-700 text-white border-gray-600">Cancel</AlertDialogCancel>
                          <AlertDialogAction 
                            onClick={() => handleDeleteTree(tree.id, tree.name)}
                            className="bg-red-600 hover:bg-red-700"
                          >
                            Delete Tree
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  </div>
                  
                  {/* Tree Details Section */}
                  {selectedTree?.id === tree.id && (
                    <div className="mt-4 space-y-4 border-t border-gray-700 pt-4">
                      <div className="flex items-center justify-between">
                        <h4 className="text-lg font-semibold text-amber-400">Tree Structure</h4>
                        <Button 
                          onClick={() => setIsCreateNodeOpen(true)}
                          size="sm"
                          className="bg-amber-600 hover:bg-amber-700 text-white"
                        >
                          <Plus className="w-4 h-4 mr-1" />
                          Add Node
                        </Button>
                      </div>
                      
                      {/* Tree Nodes */}
                      <div className="space-y-3">
                        {treeNodes
                          .sort((a, b) => a.node_key.localeCompare(b.node_key))
                          .map((node) => (
                          <div key={node.id} className="border border-gray-700 rounded-lg p-4 bg-gray-800/30">
                            <div className="flex items-center justify-between mb-2">
                              <div className="flex items-center gap-2">
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  onClick={() => handleShowNode(node.id)}
                                  className="p-0 h-auto text-gray-400 hover:text-white"
                                >
                                  {expandedNodes.has(node.id) ? (
                                    <ChevronDown className="w-4 h-4" />
                                  ) : (
                                    <ChevronRight className="w-4 h-4" />
                                  )}
                                </Button>
                                <span className="text-white font-medium">{node.node_key}</span>
                                {node.is_root && (
                                  <Badge className="bg-green-600/20 text-green-400">ROOT</Badge>
                                )}
                              </div>
                              
                              <div className="flex items-center gap-1">
                                <Button 
                                  size="sm" 
                                  variant="outline" 
                                  onClick={() => handleEditNode(node)}
                                  className="text-yellow-400 border-yellow-500 hover:bg-yellow-500/20"
                                >
                                  <Edit className="w-3 h-3 mr-1" />
                                  EDIT
                                </Button>
                                
                                <Button 
                                  size="sm" 
                                  variant="outline" 
                                  onClick={() => handleManageOptions(node)}
                                  className="text-purple-400 border-purple-500 hover:bg-purple-500/20"
                                >
                                  <Settings className="w-3 h-3 mr-1" />
                                  OPTIONS
                                </Button>
                                
                                <Button 
                                  size="sm" 
                                  variant="outline" 
                                  onClick={() => handleDuplicateNode(node)}
                                  className="text-blue-400 border-blue-500 hover:bg-blue-500/20"
                                >
                                  <Copy className="w-3 h-3 mr-1" />
                                  DUPLICATE
                                </Button>
                                
                                <Button 
                                  size="sm" 
                                  variant="outline" 
                                  onClick={() => handleAddNote(node)}
                                  className="text-amber-400 border-amber-500 hover:bg-amber-500/20"
                                >
                                  <Edit className="w-3 h-3 mr-1" />
                                  Add Note
                                </Button>
                                
                                <Button 
                                  size="sm" 
                                  variant="outline" 
                                  onClick={() => handleDeleteNode(node.id, node.node_key)}
                                  className="text-red-400 border-red-500 hover:bg-red-500/20"
                                >
                                  <Trash2 className="w-3 h-3 mr-1" />
                                  DELETE
                                </Button>
                              </div>
                            </div>
                            
                            {/* Node Content - Show/Hide based on expanded state */}
                            {expandedNodes.has(node.id) && (
                              <div className="mt-3">
                                <h5 className="text-white font-medium mb-1">{node.title || 'No title'}</h5>
                                <p className="text-gray-400 text-sm mb-3">{node.question_text || 'No question text'}</p>
                                
                                {/* Node Options */}
                                <div className="space-y-2">
                                  {(nodeOptions[node.id] || [])
                                    .map((option) => (
                                      <div key={option.id} className="bg-gray-700/50 p-3 rounded border border-gray-600">
                                        <div className="flex items-center justify-between mb-1">
                                          <div className="flex items-center gap-3">
                                            <span className="text-white font-medium">{option.option_text}</span>
                                            <Badge variant="outline" className="border-gray-500 text-gray-300">
                                              {option.option_value}
                                            </Badge>
                                          </div>
                                          <div className="flex items-center gap-2">
                                            <Button
                                              size="sm"
                                              variant="outline"
                                              onClick={() => handleEditOption(option)}
                                              className="text-amber-400 border-amber-500 hover:bg-amber-500/10"
                                            >
                                              Edit
                                            </Button>
                                            <Button
                                              size="sm"
                                              variant="outline"
                                              onClick={async () => {
                                                try {
                                                  const response = await brain.delete_node_option({ optionId: option.id });
                                                  if (response.ok) {
                                                    toast.success('Option deleted successfully');
                                                    // Reload tree details
                                                    if (selectedTree) {
                                                      loadTreeDetails(selectedTree);
                                                    }
                                                  } else {
                                                    toast.error('Failed to delete option');
                                                  }
                                                } catch (error) {
                                                  console.error('Error deleting option:', error);
                                                  toast.error('Failed to delete option');
                                                }
                                              }}
                                              className="text-red-400 border-red-500 hover:bg-red-500/10"
                                            >
                                              Delete
                                            </Button>
                                          </div>
                                        </div>
                                        {option.routing_rule && (
                                          <p className="text-gray-400 text-sm">Routes to: {option.routing_rule}</p>
                                        )}
                                        {option.note && (
                                          <p className="text-gray-300 text-sm mt-1">
                                            <span className="text-gray-500">Note:</span> {option.note}
                                          </p>
                                        )}
                                      </div>
                                    ))
                                  }
                                </div>
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Classification Outcomes Tab */}
        <TabsContent value="outcomes" className="space-y-6">
          <div className="flex justify-between items-center">
            <h3 className="text-xl font-semibold text-white">Classification Outcomes</h3>
            <Button 
              onClick={() => setIsCreateOutcomeOpen(true)}
              className="bg-amber-600 hover:bg-amber-700 text-white"
            >
              <Plus className="w-4 h-4 mr-2" />
              Create Outcome
            </Button>
          </div>

          <div className="grid gap-4">
            {classificationOutcomes.map((outcome) => (
              <Card key={outcome.id} className="bg-gray-800/50 border-gray-700">
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <FileText className="w-6 h-6 text-amber-400" />
                      <div>
                        <CardTitle className="text-white text-lg">{outcome.outcome_code}</CardTitle>
                        <p className="text-gray-400 text-sm">{outcome.outcome_title}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge className={outcome.is_controlled ? 'bg-red-600/20 text-red-400' : 'bg-green-600/20 text-green-400'}>
                        {outcome.is_controlled ? 'CONTROLLED' : 'NOT CONTROLLED. PLEASE CHECK CATCH-ALL PROVISIONS'}
                      </Badge>
                      <Button 
                        size="sm" 
                        variant="outline" 
                        className="text-yellow-400 border-yellow-600 hover:bg-yellow-700"
                        onClick={() => {
                          console.log('🔥 EDIT BUTTON CLICKED!');
                          handleEditOutcome(outcome);
                        }}
                      >
                        <Edit className="w-4 h-4" />
                      </Button>
                      <Button 
                        size="sm" 
                        variant="outline" 
                        className="text-green-400 border-green-600 hover:bg-green-700"
                        onClick={() => handleDuplicateOutcome(outcome)}
                      >
                        <Copy className="w-4 h-4" />
                      </Button>
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button
                            size="sm"
                            variant="outline"
                            className="text-red-400 border-red-600 hover:bg-red-700"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent className="bg-gray-900 border-gray-700">
                          <AlertDialogHeader>
                            <AlertDialogTitle className="text-white">Delete Classification Outcome</AlertDialogTitle>
                            <AlertDialogDescription className="text-gray-400">
                              Are you sure you want to delete "{outcome.outcome_code}"? This action cannot be undone.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel className="bg-gray-700 text-white border-gray-600">Cancel</AlertDialogCancel>
                            <AlertDialogAction 
                              onClick={() => handleDeleteOutcome(outcome)}
                              className="bg-red-600 hover:bg-red-700"
                            >
                              Delete Outcome
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="pt-0">
                  <div className="space-y-2">
                    {outcome.description && (
                      <p className="text-gray-300 text-sm">{outcome.description}</p>
                    )}
                    {outcome.regulatory_basis && (
                      <div>
                        <span className="text-amber-400 text-sm font-medium">Regulatory Basis: </span>
                        <span className="text-gray-300 text-sm">{outcome.regulatory_basis}</span>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Classification Notes Tab */}
        <TabsContent value="notes" className="space-y-6">
          <div className="flex justify-between items-center">
            <h3 className="text-xl font-semibold text-white">Regulatory Notes</h3>
            <div className="flex items-center gap-2">
              <Button 
                onClick={handleExportExcel}
                variant="outline"
                className="border-green-600 text-green-400 hover:bg-green-600/20"
                disabled={!selectedTree || classificationNotes.length === 0}
              >
                <Download className="w-4 h-4 mr-2" />
                Export Excel
              </Button>
              <Button 
                onClick={handleImportExcel}
                variant="outline"
                className="border-blue-600 text-blue-400 hover:bg-blue-600/20"
                disabled={!selectedTree}
              >
                <Upload className="w-4 h-4 mr-2" />
                Import Excel
              </Button>
              <Button 
                onClick={() => {
                  // Reset form data and open Create Note dialog
                  setNewNoteData({
                    note_key: '',
                    title: '',
                    content: '',
                    tree_id: selectedTree?.id || ''
                  });
                  setIsCreateNoteOpen(true);
                }}
                className="bg-amber-600 hover:bg-amber-700 text-white"
              >
                <Plus className="w-4 h-4 mr-2" />
                Create Note
              </Button>
            </div>
          </div>

          <div className="grid gap-4">
            {classificationNotes
              .sort((a, b) => a.note_key.localeCompare(b.note_key))
              .map((note) => (
              <Card key={note.id} className="bg-gray-800/50 border-gray-700">
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <FileText className="w-6 h-6 text-amber-400" />
                      <div>
                        <CardTitle className="text-white text-lg">{note.note_key}</CardTitle>
                        <p className="text-gray-400 text-sm">{note.title}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          setSelectedNote(note);
                          setIsEditNoteOpen(true);
                          console.log('🔍 isEditNoteOpen should now be true');
                        }}
                        className="text-yellow-400 border-yellow-400/30 hover:bg-yellow-400/10"
                      >
                        <Edit className="w-4 h-4" />
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          // Create a copy of the note with modified key and title
                          const duplicateNote = {
                            note_key: `${note.note_key}_copy`,
                            title: `${note.title} (Copy)`,
                            content: note.content,
                            tree_id: note.tree_id
                          };
                          
                          setNewNoteData(duplicateNote);
                          setIsCreateNoteOpen(true);
                        }}
                        className="text-blue-400 border-blue-400/30 hover:bg-blue-400/10"
                      >
                        <Copy className="w-4 h-4" />
                      </Button>
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button
                            variant="outline"
                            size="sm"
                            className="text-red-400 border-red-400/30 hover:bg-red-400/10"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent className="bg-gray-900 border-gray-700">
                          <AlertDialogHeader>
                            <AlertDialogTitle className="text-white">Delete Note</AlertDialogTitle>
                            <AlertDialogDescription className="text-gray-400">
                              Are you sure you want to delete note "{note.note_key}"? This action cannot be undone.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel className="bg-gray-700 text-white border-gray-600">Cancel</AlertDialogCancel>
                            <AlertDialogAction 
                              onClick={() => handleDeleteNote(note.id)}
                              className="bg-red-600 hover:bg-red-700"
                            >
                              Delete Note
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="pt-0">
                  <p className="text-gray-300 text-sm">{note.content}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Create Tree Dialog */}
        <Dialog open={isCreateTreeOpen} onOpenChange={setIsCreateTreeOpen}>
          <DialogContent className="bg-gray-900 border-gray-700 text-white max-w-1xl">
            <DialogHeader>
              <DialogTitle className="text-amber-400">Create Classification Tree</DialogTitle>
              <DialogDescription className="text-gray-400">
                Create a new decision tree for product classification
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-gray-300">Tree Name</Label>
                  <Input
                    value={newTreeData.name}
                    onChange={(e) => setNewTreeData(prev => ({ ...prev, name: e.target.value }))}
                    className="bg-gray-800 border-gray-600 text-white"
                    placeholder="e.g., EU Military List Decision Tree"
                  />
                </div>
                <div>
                  <Label className="text-gray-300">Version</Label>
                  <Input
                    value={newTreeData.version}
                    onChange={(e) => setNewTreeData(prev => ({ ...prev, version: e.target.value }))}
                    className="bg-gray-800 border-gray-600 text-white"
                    placeholder="e.g., 1.0"
                  />
                </div>
              </div>
              <div>
                <Label className="text-gray-300">Description</Label>
                <Textarea
                  value={newTreeData.description}
                  onChange={(e) => setNewTreeData(prev => ({ ...prev, description: e.target.value }))}
                  className="bg-gray-800 border-gray-600 text-white"
                  placeholder="Describe the purpose and scope of this classification tree"
                  rows={3}
                />
              </div>
              <div>
                <Label className="text-gray-300">Regulation Category</Label>
                <Select value={newTreeData.regulation_category} onValueChange={(value) => setNewTreeData(prev => ({ ...prev, regulation_category: value }))}>
                  <SelectTrigger className="bg-gray-800 border-gray-600 text-white">
                    <SelectValue placeholder="Select category" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="dual-use">Dual-Use (EAR)</SelectItem>
                    <SelectItem value="military">Military List (ITAR)</SelectItem>
                    <SelectItem value="eu-dual-use">EU Dual-Use</SelectItem>
                    <SelectItem value="eu-military">EU Military List</SelectItem>
                    <SelectItem value="wassenaar">Wassenaar Arrangement</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <DialogFooter>
              <Button
                variant="outline"
                onClick={() => setIsCreateTreeOpen(false)}
                className="text-gray-300 border-gray-600 hover:bg-gray-700"
              >
                Cancel
              </Button>
              <Button
                onClick={handleCreateTree}
                disabled={!newTreeData.name.trim() || !newTreeData.regulation_category}
                className="bg-amber-600 hover:bg-amber-700 text-white disabled:opacity-50"
              >
                <Plus className="w-4 h-4 mr-2" />
                Create Tree
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Create Node Dialog */}
        <Dialog open={isCreateNodeOpen} onOpenChange={setIsCreateNodeOpen}>
          <DialogContent className="bg-gray-900 border-gray-700 text-white max-w-2xl">
            <DialogHeader>
              <DialogTitle className="text-amber-400">Create Decision Node</DialogTitle>
              <DialogDescription className="text-gray-400">
                Add a new decision point to the classification tree
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-gray-300">Node Key</Label>
                  <Input
                    value={newNodeData.node_key}
                    onChange={(e) => setNewNodeData(prev => ({ ...prev, node_key: e.target.value }))}
                    className="bg-gray-800 border-gray-600 text-white"
                    placeholder="i.e., ML22a, 3A001"
                  />
                </div>
                <div>
                  <Label className="text-gray-300">Question Type</Label>
                  <Select value={newNodeData.question_type} onValueChange={(value) => setNewNodeData(prev => ({ ...prev, question_type: value }))}>
                    <SelectTrigger className="bg-gray-800 border-gray-600 text-white">
                      <SelectValue placeholder="Select type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="multiple_choice">Multiple Choice</SelectItem>
                      <SelectItem value="yes_no">Yes/No</SelectItem>
                      <SelectItem value="text_input">Text Input</SelectItem>
                      <SelectItem value="numeric">Numeric</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div>
                <Label className="text-gray-300">Title</Label>
                <Input
                  value={newNodeData.title}
                  onChange={(e) => setNewNodeData(prev => ({ ...prev, title: e.target.value }))}
                  className="bg-gray-800 border-gray-600 text-white"
                  placeholder="Brief title for this decision node"
                />
              </div>
              <div>
                <Label className="text-gray-300">Question Text</Label>
                <Textarea
                  value={newNodeData.question_text}
                  onChange={(e) => setNewNodeData(prev => ({ ...prev, question_text: e.target.value }))}
                  className="bg-gray-800 border-gray-600 text-white"
                  placeholder="What question should be asked at this decision point?"
                  rows={3}
                />
              </div>
              <div>
                <Label className="text-gray-300">Description</Label>
                <Textarea
                  value={newNodeData.description || ''}
                  onChange={(e) => setNewNodeData(prev => ({ ...prev, description: e.target.value }))}
                  className="bg-gray-800 border-gray-600 text-white"
                  placeholder="Additional context or guidance for this decision point"
                  rows={2}
                />
              </div>
            </div>
            <DialogFooter>
              <Button
                variant="outline"
                onClick={() => setIsCreateNodeOpen(false)}
                className="text-gray-300 border-gray-600 hover:bg-gray-700"
              >
                Cancel
              </Button>
              <Button
                onClick={handleCreateNode}
                disabled={!newNodeData.node_key.trim() || !newNodeData.title.trim() || !newNodeData.question_text.trim()}
                className="bg-amber-600 hover:bg-amber-700 text-white disabled:opacity-50"
              >
                <Plus className="w-4 h-4 mr-2" />
                Create Node
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Create Outcome Dialog */}
        <Dialog open={isCreateOutcomeOpen} onOpenChange={setIsCreateOutcomeOpen}>
          <DialogContent className="bg-gray-900 border-gray-700 text-white max-w-2xl">
            <DialogHeader>
              <DialogTitle className="text-amber-400">Create Classification Outcome</DialogTitle>
              <DialogDescription className="text-gray-400">
                Define a classification result for the decision tree
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-gray-300">Outcome Code</Label>
                  <Input
                    value={newOutcomeData.outcome_code}
                    onChange={(e) => setNewOutcomeData(prev => ({ ...prev, outcome_code: e.target.value }))}
                    className="bg-gray-800 border-gray-600 text-white"
                    placeholder="e.g., EU-ML 22.a, 3A001"
                  />
                </div>
                <div className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    checked={newOutcomeData.is_controlled}
                    onChange={(e) => setNewOutcomeData(prev => ({ ...prev, is_controlled: e.target.checked }))}
                    className="w-4 h-4 rounded border-gray-600 bg-gray-800"
                  />
                  <Label className="text-gray-300">Controlled Item</Label>
                </div>
              </div>
              <div>
                <Label className="text-gray-300">Outcome Title</Label>
                <Input
                  value={newOutcomeData.outcome_title}
                  onChange={(e) => setNewOutcomeData(prev => ({ ...prev, outcome_title: e.target.value }))}
                  className="bg-gray-800 border-gray-600 text-white"
                  placeholder="e.g., Military List - Spacecraft Systems"
                />
              </div>
              <div>
                <Label className="text-gray-300">Description</Label>
                <Textarea
                  value={newOutcomeData.description || ''}
                  onChange={(e) => setNewOutcomeData(prev => ({ ...prev, description: e.target.value }))}
                  className="bg-gray-800 border-gray-600 text-white"
                  placeholder="Detailed description of this classification outcome"
                  rows={3}
                />
              </div>
              <div>
                <Label className="text-gray-300">Regulatory Basis</Label>
                <Textarea
                  value={newOutcomeData.regulatory_basis || ''}
                  onChange={(e) => setNewOutcomeData(prev => ({ ...prev, regulatory_basis: e.target.value }))}
                  className="bg-gray-800 border-gray-600 text-white"
                  placeholder="Legal or regulatory basis for this classification"
                  rows={2}
                />
              </div>
            </div>
            <DialogFooter>
              <Button
                variant="outline"
                onClick={() => setIsCreateOutcomeOpen(false)}
                className="text-gray-300 border-gray-600 hover:bg-gray-700"
              >
                Cancel
              </Button>
              <Button
                onClick={handleCreateOutcome}
                disabled={!newOutcomeData.outcome_code.trim() || !newOutcomeData.outcome_title.trim()}
                className="bg-amber-600 hover:bg-amber-700 text-white disabled:opacity-50"
              >
                <Plus className="w-4 h-4 mr-2" />
                Create Outcome
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* NEW: Add Note Dialog with Note Key field */}
        <Dialog open={isAddNoteOpen} onOpenChange={setIsAddNoteOpen}>
          <DialogContent className="bg-gray-900 border-gray-700 text-white max-w-2xl">
            <DialogHeader>
              <DialogTitle className="text-amber-400">Add Classification Note</DialogTitle>
              <DialogDescription className="text-gray-400">
                Add a regulatory note to the selected decision node
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label className="text-gray-300">Note Key *</Label>
                <Input
                  value={noteKey}
                  onChange={(e) => setNoteKey(e.target.value)}
                  className="bg-gray-800 border-gray-600 text-white"
                  placeholder="e.g., ML22a-guidance, 3A001-note"
                />
              </div>
              <div>
                <Label className="text-gray-300">Note Content *</Label>
                <Textarea
                  value={noteText}
                  onChange={(e) => setNoteText(e.target.value)}
                  className="bg-gray-800 border-gray-600 text-white"
                  placeholder="Enter the regulatory note content..."
                  rows={4}
                />
              </div>
              {selectedNodeForNote && (
                <div>
                  <Label className="text-gray-300">For Node:</Label>
                  <p className="text-amber-400">{selectedNodeForNote.title}</p>
                </div>
              )}
            </div>
            <DialogFooter>
              <Button
                variant="outline"
                onClick={() => {
                  setIsAddNoteOpen(false);
                  setSelectedNodeForNote(null);
                  setNoteKey('');
                  setNoteText('');
                }}
                className="text-gray-300 border-gray-600 hover:bg-gray-700"
              >
                Cancel
              </Button>
              <Button
                onClick={handleSaveNote}
                disabled={!noteKey.trim() || !noteText.trim()}
                className="bg-amber-600 hover:bg-amber-700 text-white disabled:opacity-50"
              >
                <Plus className="w-4 h-4 mr-2" />
                Create Note
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Edit Node Dialog */}
        <Dialog open={isEditNodeOpen} onOpenChange={setIsEditNodeOpen}>
          <DialogContent className="bg-gray-900 border-gray-700 text-white max-w-2xl">
            <DialogHeader>
              <DialogTitle className="text-amber-400">Edit Decision Node</DialogTitle>
              <DialogDescription className="text-gray-400">
                Modify the properties of this decision node
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-gray-300">Node Key</Label>
                  <Input
                    value={editingNode?.node_key || ''}
                    onChange={(e) => setEditingNode(prev => prev ? {...prev, node_key: e.target.value} : null)}
                    className="bg-gray-800 border-gray-600 text-white"
                    placeholder="e.g., ML22a, 3A001"
                  />
                </div>
                <div>
                  <Label className="text-gray-300">Question Type</Label>
                  <Select value={editingNode?.question_type || undefined} onValueChange={(value) => setEditingNode(prev => prev ? {...prev, question_type: value} : null)}>
                    <SelectTrigger className="bg-gray-800 border-gray-600 text-white">
                      <SelectValue placeholder="Select type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="multiple_choice">Multiple Choice</SelectItem>
                      <SelectItem value="yes_no">Yes/No</SelectItem>
                      <SelectItem value="text_input">Text Input</SelectItem>
                      <SelectItem value="numeric">Numeric</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div>
                <Label className="text-gray-300">Title</Label>
                <Input
                  value={editingNode?.title || ''}
                  onChange={(e) => setEditingNode(prev => prev ? {...prev, title: e.target.value} : null)}
                  className="bg-gray-800 border-gray-600 text-white"
                  placeholder="Brief title for this decision node"
                />
              </div>
              <div>
                <Label className="text-gray-300">Question Text</Label>
                <Textarea
                  value={editingNode?.question_text || ''}
                  onChange={(e) => setEditingNode(prev => prev ? {...prev, question_text: e.target.value} : null)}
                  className="bg-gray-800 border-gray-600 text-white"
                  placeholder="What question should be asked at this decision point?"
                  rows={3}
                />
              </div>
              <div>
                <Label className="text-gray-300">Description</Label>
                <Textarea
                  value={editingNode?.description || ''}
                  onChange={(e) => setEditingNode(prev => prev ? {...prev, description: e.target.value} : null)}
                  className="bg-gray-800 border-gray-600 text-white"
                  placeholder="Additional context or guidance for this decision point"
                  rows={2}
                />
              </div>
            </div>
            <DialogFooter>
              <Button
                variant="outline"
                onClick={() => {
                  setIsEditNodeOpen(false);
                  setEditingNode(null);
                }}
                className="text-gray-300 border-gray-600 hover:bg-gray-700"
              >
                Cancel
              </Button>
              <Button
                onClick={handleSaveEditedNode}
                className="bg-yellow-600 hover:bg-yellow-700 text-white"
              >
                Save Changes
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Edit Outcome Dialog */}
        <EditOutcomeDialog
          isOpen={isEditOutcomeOpen}
          onOpenChange={setIsEditOutcomeOpen}
          editingOutcome={editingOutcome}
          setEditingOutcome={setEditingOutcome}
          onSave={async () => {
            console.log('🚀 SAVE CALLBACK triggered!');
            if (!editingOutcome) {
              console.error('❌ No editing outcome!');
              return;
            }

            try {
              console.log('📤 Sending update request:', editingOutcome);
              const response = await brain.update_classification_outcome(
                { outcomeId: editingOutcome.id },
                {
                  outcome_code: editingOutcome.outcome_code,
                  outcome_title: editingOutcome.outcome_title,
                  description: editingOutcome.description,
                  regulatory_basis: editingOutcome.regulatory_basis,
                  guidance_notes: editingOutcome.guidance_notes,
                  is_controlled: editingOutcome.is_controlled
                }
              );

              console.log('📨 Update response:', response.ok, response.status);
              if (response.ok) {
                toast.success('Outcome updated successfully');
                setIsEditOutcomeOpen(false);
                setEditingOutcome(null);
                // Reload tree details
                if (selectedTree) {
                  console.log('🔄 Reloading tree details...');
                  loadTreeDetails(selectedTree);
                }
              } else {
                const errorData = await response.json().catch(() => null);
                console.error('❌ Update failed:', response.status, errorData);
                toast.error(`Failed to update outcome: ${errorData?.detail || 'Unknown error'}`);
              }
            } catch (error) {
              console.error('💥 Error updating outcome:', error);
              toast.error('Failed to update outcome');
            }
          }}
        />

        {/* Edit Note Dialog */}
        <Dialog open={isEditNoteOpen} onOpenChange={setIsEditNoteOpen}>
          <DialogContent className="bg-gray-900 border-gray-700 text-white max-w-2xl">
            <DialogHeader>
              <DialogTitle className="text-amber-400">Edit Classification Note</DialogTitle>
              <DialogDescription className="text-gray-400">
                Modify the regulatory note content and properties
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label className="text-gray-300">Note Key</Label>
                <Input
                  value={selectedNote?.note_key || ''}
                  onChange={(e) => setSelectedNote(prev => prev ? {...prev, note_key: e.target.value} : null)}
                  className="bg-gray-800 border-gray-600 text-white"
                  placeholder="e.g., ML22a-guidance, 3A001-note"
                />
              </div>
              <div>
                <Label className="text-gray-300">Title</Label>
                <Input
                  value={selectedNote?.title || ''}
                  onChange={(e) => setSelectedNote(prev => prev ? {...prev, title: e.target.value} : null)}
                  className="bg-gray-800 border-gray-600 text-white"
                  placeholder="Brief title for this note"
                />
              </div>
              <div>
                <Label className="text-gray-300">Content</Label>
                <Textarea
                  value={selectedNote?.content || ''}
                  onChange={(e) => setSelectedNote(prev => prev ? {...prev, content: e.target.value} : null)}
                  className="bg-gray-800 border-gray-600 text-white"
                  placeholder="Note content..."
                  rows={4}
                />
              </div>
            </div>
            <DialogFooter>
              <Button
                variant="outline"
                onClick={() => {
                  setIsEditNoteOpen(false);
                  setSelectedNote(null);
                }}
                className="text-gray-300 border-gray-600 hover:bg-gray-700"
              >
                Cancel
              </Button>
              <Button
                onClick={async () => {
                  console.log('UPDATE NOTE clicked, selectedNote:', selectedNote);
                  
                  if (!selectedNote?.id || !selectedNote.note_key.trim() || !selectedNote.title.trim()) {
                    toast.error('Please fill in all required fields');
                    return;
                  }

                  try {
                    console.log('Sending update request for note ID:', selectedNote.id);
                    const response = await brain.update_classification_note(
                      { noteId: selectedNote.id },
                      {
                        note_key: selectedNote.note_key,
                        title: selectedNote.title,
                        content: selectedNote.content,
                        tree_id: selectedNote.tree_id
                      }
                    );

                    console.log('Update response:', response.ok, response.status);
                    if (response.ok) {
                      toast.success('Note updated successfully');
                      setIsEditNoteOpen(false);
                      setSelectedNote(null);
                      // Reload notes
                      console.log('Reloading classification notes...');
                      loadClassificationNotes();
                    } else {
                      const errorData = await response.json().catch(() => null);
                      console.error('Update failed:', response.status, errorData);
                      toast.error(`Failed to update note: ${errorData?.detail || 'Unknown error'}`);
                    }
                  } catch (error) {
                    console.error('Error updating note:', error);
                    toast.error('Failed to update note');
                  }
                }}
                disabled={(() => {
                  const hasNoteKey = !!selectedNote?.note_key?.trim();
                  const hasTitle = !!selectedNote?.title?.trim();
                  const shouldBeDisabled = !hasNoteKey || !hasTitle;
                  
                  console.log('🔍 BUTTON STATE:', {
                    selectedNote_exists: !!selectedNote,
                    note_key: selectedNote?.note_key,
                    title: selectedNote?.title,
                    hasNoteKey,
                    hasTitle,
                    shouldBeDisabled
                  });
                  
                  return shouldBeDisabled;
                })()}
                className="bg-yellow-600 hover:bg-yellow-700 text-white"
              >
                <Edit className="w-4 h-4 mr-2" />
                Update Note
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Create Note Dialog - Used by Notes tab */}
        <Dialog open={isCreateNoteOpen} onOpenChange={setIsCreateNoteOpen}>
          <DialogContent className="bg-gray-900 border-gray-700 text-white max-w-2xl">
            <DialogHeader>
              <DialogTitle className="text-amber-400">Create Classification Note</DialogTitle>
              <DialogDescription className="text-gray-400">
                Create a new regulatory note for the classification system
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label className="text-gray-300">Note Key *</Label>
                <Input
                  value={newNoteData.note_key}
                  onChange={(e) => setNewNoteData(prev => ({ ...prev, note_key: e.target.value }))}
                  className="bg-gray-800 border-gray-600 text-white"
                  placeholder="e.g., ML22a-guidance, 3A001-note"
                />
              </div>
              <div>
                <Label className="text-gray-300">Title *</Label>
                <Input
                  value={newNoteData.title}
                  onChange={(e) => setNewNoteData(prev => ({ ...prev, title: e.target.value }))}
                  className="bg-gray-800 border-gray-600 text-white"
                  placeholder="Brief title for this note"
                />
              </div>
              <div>
                <Label className="text-gray-300">Content *</Label>
                <Textarea
                  value={newNoteData.content}
                  onChange={(e) => setNewNoteData(prev => ({ ...prev, content: e.target.value }))}
                  className="bg-gray-800 border-gray-600 text-white"
                  placeholder="Enter the regulatory note content..."
                  rows={4}
                />
              </div>
            </div>
            <DialogFooter>
              <Button
                variant="outline"
                onClick={() => {
                  setIsCreateNoteOpen(false);
                  // Reset form
                  setNewNoteData({
                    note_key: '',
                    title: '',
                    content: '',
                    tree_id: selectedTree?.id || ''
                  });
                }}
                className="text-gray-300 border-gray-600 hover:bg-gray-700"
              >
                Cancel
              </Button>
              <Button
                onClick={handleCreateNote}
                disabled={!newNoteData.note_key.trim() || !newNoteData.title.trim() || !newNoteData.content.trim()}
                className="bg-amber-600 hover:bg-amber-700 text-white disabled:opacity-50"
              >
                <Plus className="w-4 h-4 mr-2" />
                Create Note
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Manage Options Dialog - Missing Dialog Added */}
        <Dialog open={isManageOptionsOpen} onOpenChange={setIsManageOptionsOpen}>
          <DialogContent className="bg-gray-900 border-gray-700 text-white max-w-4xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="text-purple-400">Manage Node Options</DialogTitle>
              <DialogDescription className="text-gray-400">
                Configure options for node: {managingOptionsForNode?.node_key} - {managingOptionsForNode?.title}
              </DialogDescription>
            </DialogHeader>
            
            <div className="space-y-6">
              {/* Create New Option */}
              <div className="border border-gray-700 rounded-lg p-4 bg-gray-800/30">
                <h4 className="text-white font-semibold mb-3">Add New Option</h4>
                <div className="grid grid-cols-2 gap-4 mb-4">
                  <div>
                    <Label className="text-gray-300">Option Text *</Label>
                    <Input
                      value={newOptionData.option_text}
                      onChange={(e) => setNewOptionData(prev => ({ ...prev, option_text: e.target.value }))}
                      className="bg-gray-800 border-gray-600 text-white"
                      placeholder="e.g., Yes, No, Not Applicable"
                    />
                  </div>
                  <div>
                    <Label className="text-gray-300">Option Value *</Label>
                    <Input
                      value={newOptionData.option_value}
                      onChange={(e) => setNewOptionData(prev => ({ ...prev, option_value: e.target.value }))}
                      className="bg-gray-800 border-gray-600 text-white"
                      placeholder="e.g., yes, no, na"
                    />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4 mb-4">
                  <div>
                    <Label className="text-gray-300">Routing Rule</Label>
                    <Input
                      value={newOptionData.routing_rule || ''}
                      onChange={(e) => setNewOptionData(prev => ({ ...prev, routing_rule: e.target.value }))}
                      className="bg-gray-800 border-gray-600 text-white"
                      placeholder="-> node_key or outcome: code; continue: target"
                    />
                    <div className="mt-2 p-3 bg-gray-800/50 rounded border border-gray-700">
                      <p className="text-gray-400 text-sm mb-2 font-medium">Enhanced Routing Syntax:</p>
                      <div className="space-y-1 text-xs">
                        <div className="text-gray-300">
                          <span className="text-amber-400">Simple navigation:</span> {'->'} next_node_key
                        </div>
                        <div className="text-gray-300">
                          <span className="text-amber-400">Final outcome:</span> {'->'} "outcome_code"
                        </div>
                        <div className="text-gray-300">
                          <span className="text-amber-400">Enhanced (outcome + continue):</span> outcome: "not_classified"; continue: dual_use_tree
                        </div>
                      </div>
                      <div className="mt-2 pt-2 border-t border-gray-700">
                        <p className="text-xs text-gray-500">
                          💡 Enhanced syntax shows an intermediate outcome but continues to another classification step
                        </p>
                      </div>
                    </div>
                  </div>
                  <div>
                    <Label className="text-gray-300">Display Order</Label>
                    <Input
                      type="number"
                      min="0"
                      value={newOptionData.display_order}
                      onChange={(e) => setNewOptionData(prev => ({ ...prev, display_order: parseInt(e.target.value) || 0 }))}
                      className="bg-gray-800 border-gray-600 text-white"
                      placeholder="0"
                    />
                  </div>
                </div>
                <div className="mb-4">
                  <Label className="text-gray-300">Note</Label>
                  <Textarea
                    value={newOptionData.note || ''}
                    onChange={(e) => setNewOptionData(prev => ({ ...prev, note: e.target.value }))}
                    className="bg-gray-800 border-gray-600 text-white"
                    placeholder="Additional notes about this option..."
                    rows={3}
                  />
                </div>
                <Button
                  onClick={async () => {
                    if (!managingOptionsForNode || !newOptionData.option_text.trim() || !newOptionData.option_value.trim()) {
                      toast.error('Please fill in required fields');
                      return;
                    }
                    
                    try {
                      const response = await brain.create_node_option(
                        { nodeId: managingOptionsForNode.id },
                        newOptionData
                      );
                      
                      if (response.ok) {
                        toast.success('Option created successfully');
                        setNewOptionData({
                          option_text: '',
                          option_value: '',
                          routing_rule: '',
                          regulatory_notes: [],
                          display_order: 0,
                          note: ''
                        });
                        // Reload tree details to refresh options
                        if (selectedTree) {
                          loadTreeDetails(selectedTree);
                        }
                      } else {
                        toast.error('Failed to create option');
                      }
                    } catch (error) {
                      console.error('Error creating option:', error);
                      toast.error('Failed to create option');
                    }
                  }}
                  disabled={!newOptionData.option_text.trim() || !newOptionData.option_value.trim()}
                  className="bg-purple-600 hover:bg-purple-700 text-white"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Add Option
                </Button>
              </div>
              
              {/* Existing Options */}
              <div className="space-y-3">
                <h4 className="text-white font-semibold">Existing Options</h4>
                {managingOptionsForNode && nodeOptions[managingOptionsForNode.id] ? (
                  nodeOptions[managingOptionsForNode.id].map((option) => (
                    <div key={option.id} className="border border-gray-700 rounded-lg p-3 bg-gray-800/20">
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-3">
                          <span className="text-white font-medium">{option.option_text}</span>
                          <Badge variant="outline" className="border-gray-500 text-gray-300">
                            {option.option_value}
                          </Badge>
                        </div>
                        <div className="flex items-center gap-2">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleEditOption(option)}
                            className="text-amber-400 border-amber-500 hover:bg-amber-500/10"
                          >
                            Edit
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={async () => {
                              try {
                                const response = await brain.delete_node_option({ optionId: option.id });
                                if (response.ok) {
                                  toast.success('Option deleted successfully');
                                  // Reload tree details
                                  if (selectedTree) {
                                    loadTreeDetails(selectedTree);
                                  }
                                } else {
                                  toast.error('Failed to delete option');
                                }
                              } catch (error) {
                                console.error('Error deleting option:', error);
                                toast.error('Failed to delete option');
                              }
                            }}
                            className="text-red-400 border-red-500 hover:bg-red-500/10"
                          >
                            Delete
                          </Button>
                        </div>
                      </div>
                      {option.routing_rule && (
                        <p className="text-gray-400 text-sm">Routes to: {option.routing_rule}</p>
                      )}
                      {option.note && (
                        <p className="text-gray-300 text-sm mt-1">
                          <span className="text-gray-500">Note:</span> {option.note}
                        </p>
                      )}
                    </div>
                  ))
                ) : (
                  <p className="text-gray-400 text-sm">No options found for this node.</p>
                )}
              </div>
            </div>
            
            <DialogFooter>
              <Button
                variant="outline"
                onClick={() => setIsManageOptionsOpen(false)}
                className="text-gray-300 border-gray-600 hover:bg-gray-700"
              >
                Close
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Edit Option Dialog */}
        <Dialog open={isEditOptionOpen} onOpenChange={setIsEditOptionOpen}>
          <DialogContent className="bg-gray-900 border-gray-700 text-white max-w-2xl">
            <DialogHeader>
              <DialogTitle className="text-amber-400">Edit Node Option</DialogTitle>
            <DialogDescription className="text-gray-400">
              Modify the properties of this node option
            </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-gray-300">Option Text *</Label>
                  <Input
                    value={editOptionData.option_text}
                    onChange={(e) => setEditOptionData(prev => ({ ...prev, option_text: e.target.value }))}
                    className="bg-gray-800 border-gray-600 text-white"
                    placeholder="e.g., Yes, No, Not Applicable"
                  />
                </div>
                <div>
                  <Label className="text-gray-300">Option Value *</Label>
                  <Input
                    value={editOptionData.option_value}
                    onChange={(e) => setEditOptionData(prev => ({ ...prev, option_value: e.target.value }))}
                    className="bg-gray-800 border-gray-600 text-white"
                    placeholder="e.g., yes, no, na"
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4 mb-4">
                <div>
                  <Label className="text-gray-300">Routing Rule</Label>
                  <Input
                    value={editOptionData.routing_rule || ''}
                    onChange={(e) => setEditOptionData(prev => ({ ...prev, routing_rule: e.target.value }))}
                    className={`bg-gray-800 border-gray-600 text-white ${
                      editOptionData.routing_rule && !validateRoutingRule(editOptionData.routing_rule).isValid 
                        ? 'border-red-500' 
                        : ''
                    }`}
                    placeholder='Enhanced: outcome: "code"; continue: target OR Simple: -> node_key'
                  />
                  {editOptionData.routing_rule && (() => {
                    const validation = validateRoutingRule(editOptionData.routing_rule);
                    return !validation.isValid ? (
                      <div className="mt-1 space-y-1">
                        {validation.errors.map((error, index) => (
                          <p key={index} className="text-red-400 text-xs">{error}</p>
                        ))}
                      </div>
                    ) : validation.type === 'enhanced_outcome_continue' ? (
                      <p className="mt-1 text-green-400 text-xs">✓ Enhanced routing rule (outcome + continue)</p>
                    ) : validation.type === 'final_outcome' ? (
                      <p className="mt-1 text-blue-400 text-xs">✓ Final outcome rule</p>
                    ) : (
                      <p className="mt-1 text-gray-400 text-xs">✓ Simple navigation rule</p>
                    );
                  })()}
                </div>
                <div>
                  <Label className="text-gray-300">Display Order</Label>
                  <Input
                    type="number"
                    min="0"
                    value={editOptionData.display_order || 0}
                    onChange={(e) => setEditOptionData(prev => ({ ...prev, display_order: parseInt(e.target.value) || 0 }))}
                    className="bg-gray-800 border-gray-600 text-white"
                    placeholder="0"
                  />
                </div>
              </div>
              <div className="mb-4">
                <Label className="text-gray-300">Note</Label>
                <Textarea
                  value={editOptionData.note || ''}
                  onChange={(e) => setEditOptionData(prev => ({ ...prev, note: e.target.value }))}
                  className="bg-gray-800 border-gray-600 text-white"
                  placeholder="Additional notes about this option..."
                  rows={3}
                />
              </div>
            </div>
            <DialogFooter>
              <Button
                variant="outline"
                onClick={() => {
                  setIsEditOptionOpen(false);
                  setEditingOption(null);
                }}
                className="text-gray-300 border-gray-600 hover:bg-gray-700"
              >
                Cancel
              </Button>
              <Button
                onClick={async () => {
                  if (!editingOption || !editingOption.id) {
                    toast.error('No option selected for editing');
                    return;
                  }

                  try {
                    const updateData = {
                      option_text: editOptionData.option_text,
                      option_value: editOptionData.option_value,
                      routing_rule: editOptionData.routing_rule,
                      regulatory_notes: editOptionData.regulatory_notes,
                      display_order: editOptionData.display_order,
                      note: editOptionData.note
                    };
                    
                    console.log('Updating option:', updateData);
                    const response = await brain.update_node_option(
                      { optionId: editingOption.id },
                      updateData
                    );

                    if (response.ok) {
                      toast.success('Option updated successfully');
                      setIsEditOptionOpen(false);
                      setEditingOption(null);
                      // Reload tree details
                      if (selectedTree) {
                        loadTreeDetails(selectedTree);
                      }
                    } else {
                      const errorData = await response.json().catch(() => null);
                      toast.error(`Failed to update option: ${errorData?.detail || 'Unknown error'}`);
                    }
                  } catch (error) {
                    console.error('Error updating option:', error);
                    toast.error('Failed to update option');
                  }
                }}
                className="bg-yellow-600 hover:bg-yellow-700 text-white"
              >
                Save Changes
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Export Excel Button */}
        <Button 
          onClick={handleExportExcel}
          className="bg-amber-600 hover:bg-amber-700 text-white"
        >
          <Download className="w-4 h-4 mr-2" />
          Export Excel
        </Button>

        {/* Import Excel Button */}
        <Button 
          onClick={handleImportExcel}
          className="bg-amber-600 hover:bg-amber-700 text-white"
        >
          <Upload className="w-4 h-4 mr-2" />
          Import Excel
        </Button>
      </Tabs>
    </div>
  );
};

export default ProductClassificationAdmin;
