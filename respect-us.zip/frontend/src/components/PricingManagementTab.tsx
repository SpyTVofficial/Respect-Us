
import React from 'react';
import { AdminPricingControl } from 'components/AdminPricingControl';

interface Props {
  loading?: boolean;
}

export function PricingManagementTab({ loading = false }: Props) {
  if (loading) {
    return (
      <div className="space-y-6">
        <div className="bg-gray-800/30 backdrop-blur-sm border border-gray-700 rounded-lg p-6">
          <div className="animate-pulse">
            <div className="h-6 bg-gray-600 rounded w-1/4 mb-4"></div>
            <div className="h-4 bg-gray-600 rounded w-1/2 mb-6"></div>
            <div className="space-y-4">
              {[1, 2, 3].map((i) => (
                <div key={i} className="h-16 bg-gray-600 rounded"></div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="bg-gray-800/30 backdrop-blur-sm border border-gray-700 rounded-lg p-6">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-xl font-semibold text-white mb-2">Pricing & Credit Management</h2>
            <p className="text-gray-400">Configure component pricing, credit packages, billing settings, and user credit management</p>
          </div>
        </div>
        
        <AdminPricingControl />
      </div>
    </div>
  );
}

export default PricingManagementTab;
