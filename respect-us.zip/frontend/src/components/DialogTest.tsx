import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';

export default function DialogTest() {
  const [showDialog, setShowDialog] = useState(false);

  console.log('🧪 DialogTest render - showDialog:', showDialog);

  return (
    <div className="p-4">
      <Button onClick={() => {
        console.log('🧪 Button clicked, setting showDialog to true');
        setShowDialog(true);
      }}>
        Test Dialog
      </Button>
      
      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent className="bg-gray-800 border-gray-700">
          <DialogHeader>
            <DialogTitle className="text-white">
              Test Dialog Title
            </DialogTitle>
          </DialogHeader>
          
          <div className="text-white p-4">
            <p>This is a test dialog content.</p>
            <Button onClick={() => setShowDialog(false)} className="mt-4">
              Close
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
