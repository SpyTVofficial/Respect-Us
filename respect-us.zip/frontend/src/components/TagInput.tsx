import React, { useState, useRef, useEffect, KeyboardEvent } from 'react';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { X, Plus } from 'lucide-react';

interface TagInputProps {
  value: string[];
  onChange: (tags: string[]) => void;
  label: string;
  placeholder?: string;
  className?: string;
}

const TagInput: React.FC<TagInputProps> = ({
  value = [],
  onChange,
  label,
  placeholder = "Type a tag and press Enter",
  className = ""
}) => {
  const [inputValue, setInputValue] = useState('');
  const [isInputFocused, setIsInputFocused] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  // Ensure we have a valid array
  const currentTags = Array.isArray(value) ? value : [];

  const handleInputKeyDown = (e: KeyboardEvent<HTMLInputElement>) => {
    const trimmedValue = inputValue.trim();
    
    if (e.key === 'Enter' && trimmedValue) {
      e.preventDefault();
      addTag(trimmedValue);
    } else if (e.key === 'Backspace' && !inputValue && currentTags.length > 0) {
      // Remove last tag when backspace is pressed on empty input
      e.preventDefault();
      removeTag(currentTags[currentTags.length - 1]);
    } else if (e.key === ',' && trimmedValue) {
      e.preventDefault();
      addTag(trimmedValue);
    }
  };

  const addTag = (tagText: string) => {
    const cleanTag = tagText.trim().toLowerCase();
    if (cleanTag && !currentTags.includes(cleanTag)) {
      onChange([...currentTags, cleanTag]);
    }
    setInputValue('');
  };

  const removeTag = (tagToRemove: string) => {
    onChange(currentTags.filter(tag => tag !== tagToRemove));
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    
    // Handle comma-separated input for backwards compatibility
    if (value.includes(',')) {
      const parts = value.split(',');
      const newTags = parts.slice(0, -1).map(part => part.trim()).filter(Boolean);
      const remainingText = parts[parts.length - 1];
      
      // Add valid new tags
      const uniqueNewTags = newTags.filter(tag => !currentTags.includes(tag.toLowerCase()));
      if (uniqueNewTags.length > 0) {
        onChange([...currentTags, ...uniqueNewTags.map(tag => tag.toLowerCase())]);
      }
      
      setInputValue(remainingText);
    } else {
      setInputValue(value);
    }
  };

  const handleContainerClick = () => {
    inputRef.current?.focus();
  };

  return (
    <div className={`space-y-2 ${className}`}>
      <Label className="text-gray-300">{label}</Label>
      
      {/* Main container */}
      <div 
        onClick={handleContainerClick}
        className={`w-full min-h-[42px] px-3 py-2 bg-gray-700 border rounded-md cursor-text transition-colors ${
          isInputFocused 
            ? 'border-blue-500 ring-2 ring-blue-500/20' 
            : 'border-gray-600 hover:border-gray-500'
        }`}
      >
        {/* Tags and input container */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Existing tags */}
          {currentTags.map((tag, index) => (
            <Badge
              key={`${tag}-${index}`}
              variant="secondary"
              className="bg-blue-600/20 text-blue-300 border-blue-500/30 hover:bg-blue-600/30 pr-1 text-xs"
            >
              {tag}
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  removeTag(tag);
                }}
                className="ml-1 h-4 w-4 p-0 hover:bg-blue-500/30 rounded flex items-center justify-center transition-colors"
              >
                <X className="h-3 w-3" />
              </button>
            </Badge>
          ))}
          
          {/* Input field */}
          <input
            ref={inputRef}
            type="text"
            value={inputValue}
            onChange={handleInputChange}
            onKeyDown={handleInputKeyDown}
            onFocus={() => setIsInputFocused(true)}
            onBlur={() => setIsInputFocused(false)}
            placeholder={currentTags.length === 0 ? placeholder : ""}
            className="flex-1 min-w-[120px] bg-transparent border-none outline-none text-white placeholder-gray-400 text-sm"
          />
        </div>
      </div>
      
      {/* Help text */}
      <p className="text-xs text-gray-400">
        Type tags and press Enter or comma to add. Common tags: dual-use, military, technology, sanctions, export-control
      </p>
    </div>
  );
};

export default TagInput;
