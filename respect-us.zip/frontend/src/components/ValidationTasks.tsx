




import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { AlertTriangle, CheckCircle2, Clock, Eye, User, Calendar, FileIcon, Building, BookOpen, CheckSquare, XCircle, Upload, ClipboardList } from 'lucide-react';
import { toast } from 'sonner';
import brain from 'brain';
import { ValidationTaskItem, ValidationTaskDetail, AdminValidationRequest, AdminDocument, AdminTask, TaskUpdateRequest } from '../brain/data-contracts';

export interface ValidationTasksProps {
  onTaskUpdate?: () => void;
}

const ValidationTasks: React.FC<ValidationTasksProps> = ({ onTaskUpdate }) => {
  // Risk Assessment validation states
  const [tasks, setTasks] = useState<ValidationTaskItem[]>([]);
  const [selectedTask, setSelectedTask] = useState<ValidationTaskDetail | null>(null);
  const [loading, setLoading] = useState(true);
  const [reviewing, setReviewing] = useState(false);
  const [showDetailDialog, setShowDetailDialog] = useState(false);
  const [adminDecision, setAdminDecision] = useState<'approve' | 'request_changes'>('approve');
  const [adminComments, setAdminComments] = useState('');
  const [modifiedActionPlan, setModifiedActionPlan] = useState({
    high: '',
    medium: '',
    low: ''
  });
  const [modifiedOverallAssessment, setModifiedOverallAssessment] = useState({
    strengths: '',
    weaknesses: '',
    recommendations: ''
  });
  const [stats, setStats] = useState({ total_count: 0, pending_count: 0, completed_count: 0 });
  const [filterStatus, setFilterStatus] = useState<string>('all');

  // Knowledge Base document validation states
  const [pendingDocuments, setPendingDocuments] = useState<AdminDocument[]>([]);
  const [selectedDocument, setSelectedDocument] = useState<AdminDocument | null>(null);
  const [documentLoading, setDocumentLoading] = useState(true);
  const [documentReviewing, setDocumentReviewing] = useState(false);
  const [showDocumentDialog, setShowDocumentDialog] = useState(false);
  const [documentDecision, setDocumentDecision] = useState<'approve' | 'reject'>('approve');
  const [documentComments, setDocumentComments] = useState('');
  const [activeValidationType, setActiveValidationType] = useState('user-submissions');

  // User Submissions (Admin Tasks) states
  const [adminTasks, setAdminTasks] = useState<AdminTask[]>([]);
  const [selectedAdminTask, setSelectedAdminTask] = useState<AdminTask | null>(null);
  const [adminTasksLoading, setAdminTasksLoading] = useState(true);
  const [adminTaskReviewing, setAdminTaskReviewing] = useState(false);
  const [showAdminTaskDialog, setShowAdminTaskDialog] = useState(false);
  const [adminTaskDecision, setAdminTaskDecision] = useState<'approved' | 'rejected'>('approved');
  const [adminTaskNotes, setAdminTaskNotes] = useState('');

  useEffect(() => {
    if (activeValidationType === 'risk-assessments') {
      loadValidationTasks();
    } else if (activeValidationType === 'knowledge-base') {
      loadPendingDocuments();
    } else if (activeValidationType === 'user-submissions') {
      loadAdminTasks();
    }
  }, [filterStatus, activeValidationType]);

  const loadValidationTasks = async () => {
    try {
      setLoading(true);
      const response = await brain.get_admin_validation_tasks(
        filterStatus === 'all' ? {} : { status: filterStatus }
      );
      const data = await response.json();
      
      if (response.ok) {
        setTasks(data.tasks || []);
        setStats({
          total_count: data.total_count || 0,
          pending_count: data.pending_count || 0,
          completed_count: data.completed_count || 0
        });
      } else {
        toast.error('Failed to load validation tasks');
      }
    } catch (error) {
      console.error('Error loading validation tasks:', error);
      toast.error('Failed to load validation tasks');
    } finally {
      setLoading(false);
    }
  };

  const loadPendingDocuments = async () => {
    try {
      setDocumentLoading(true);
      const response = await brain.list_admin_documents();
      const data = await response.json();
      
      if (response.ok) {
        // Filter documents with pending_validation status
        const pending = (data || []).filter((doc: AdminDocument) => 
          doc.publishing_status === 'pending_validation'
        );
        setPendingDocuments(pending);
      } else {
        toast.error('Failed to load pending documents');
        setPendingDocuments([]);
      }
    } catch (error) {
      console.error('Error loading pending documents:', error);
      toast.error('Failed to load pending documents');
      setPendingDocuments([]);
    } finally {
      setDocumentLoading(false);
    }
  };

  const loadAdminTasks = async () => {
    try {
      setAdminTasksLoading(true);
      const response = filterStatus === 'pending' 
        ? await brain.get_pending_tasks()
        : await brain.list_admin_tasks();
      const data = await response.json();
      
      if (response.ok) {
        setAdminTasks(data || []);
      } else {
        toast.error('Failed to load admin tasks');
        setAdminTasks([]);
      }
    } catch (error) {
      console.error('Error loading admin tasks:', error);
      toast.error('Failed to load admin tasks');
      setAdminTasks([]);
    } finally {
      setAdminTasksLoading(false);
    }
  };

  const loadTaskDetail = async (validationId: string) => {
    try {
      const response = await brain.get_validation_task_detail({ validationId });
      const data = await response.json();
      
      if (response.ok) {
        setSelectedTask(data);
        
        // Pre-populate modification fields with current values
        setModifiedActionPlan(data.action_plan || { high: '', medium: '', low: '' });
        setModifiedOverallAssessment(data.overall_assessment || { strengths: '', weaknesses: '', recommendations: '' });
        setAdminComments('');
        setAdminDecision('approve');
        
        setShowDetailDialog(true);
      } else {
        toast.error('Failed to load task details');
      }
    } catch (error) {
      console.error('Error loading task details:', error);
      toast.error('Failed to load task details');
    }
  };

  const submitValidationResponse = async () => {
    if (!selectedTask) return;
    
    try {
      setReviewing(true);
      
      const requestData: AdminValidationRequest = {
        validation_id: selectedTask.validation_id,
        admin_decision: adminDecision,
        admin_comments: adminComments.trim() || undefined,
        modified_action_plan: adminDecision === 'request_changes' ? modifiedActionPlan : undefined,
        modified_overall_assessment: adminDecision === 'request_changes' ? modifiedOverallAssessment : undefined
      };
      
      const response = await brain.respond_to_validation(requestData);
      const result = await response.json();
      
      if (response.ok) {
        toast.success(
          adminDecision === 'approve' 
            ? 'Assessment validated successfully!' 
            : 'Revision request sent to user!'
        );
        
        if (result.email_sent) {
          toast.info('Email notification sent to user');
        }
        
        setShowDetailDialog(false);
        loadValidationTasks();
        onTaskUpdate?.();
      } else {
        toast.error(result.detail || 'Failed to submit validation response');
      }
    } catch (error) {
      console.error('Error submitting validation response:', error);
      toast.error('Failed to submit validation response');
    } finally {
      setReviewing(false);
    }
  };

  const handleDocumentValidation = async () => {
    if (!selectedDocument) return;
    
    try {
      setDocumentReviewing(true);
      
      const newStatus = documentDecision === 'approve' ? 'published' : 'rejected';
      
      // Update document status via the correct update_document_status endpoint
      const response = await brain.update_document_status(
        { documentId: selectedDocument.id },
        {
          status: newStatus,
          admin_comments: documentComments || undefined
        }
      );
      
      if (response.ok) {
        toast.success(`Document ${documentDecision === 'approve' ? 'approved' : 'rejected'} successfully`);
        setShowDocumentDialog(false);
        setDocumentComments('');
        loadPendingDocuments();
        onTaskUpdate?.();
      } else {
        toast.error('Failed to update document status');
      }
    } catch (error) {
      console.error('Error validating document:', error);
      toast.error('Failed to validate document');
    } finally {
      setDocumentReviewing(false);
    }
  };

  const handleAdminTaskReview = async (task: AdminTask) => {
    setSelectedAdminTask(task);
    setAdminTaskDecision('approved');
    setAdminTaskNotes('');
    setShowAdminTaskDialog(true);
  };

  const submitAdminTaskReview = async () => {
    if (!selectedAdminTask) return;
    
    try {
      setAdminTaskReviewing(true);
      
      const updateRequest: TaskUpdateRequest = {
        status: adminTaskDecision,
        notes: adminTaskNotes || undefined
      };
      
      const response = await brain.update_task(
        { taskId: selectedAdminTask.id },
        updateRequest
      );
      
      if (response.ok) {
        toast.success(`Task ${adminTaskDecision === 'approved' ? 'approved' : 'rejected'} successfully`);
        setShowAdminTaskDialog(false);
        loadAdminTasks();
        onTaskUpdate?.();
      } else {
        const errorData = await response.json();
        toast.error(errorData.detail || 'Failed to update task');
      }
    } catch (error) {
      console.error('Error updating admin task:', error);
      toast.error('Failed to update task');
    } finally {
      setAdminTaskReviewing(false);
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'submitted':
        return <Badge variant="outline" className="bg-blue-900/20 text-blue-300 border-blue-700">New</Badge>;
      case 'under_review':
        return <Badge variant="outline" className="bg-yellow-900/20 text-yellow-300 border-yellow-700">In Review</Badge>;
      case 'validated':
        return <Badge variant="outline" className="bg-green-900/20 text-green-300 border-green-700">Validated</Badge>;
      case 'needs_revision':
        return <Badge variant="outline" className="bg-red-900/20 text-red-300 border-red-700">Needs Revision</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  const getPriorityIcon = (priority: string) => {
    switch (priority) {
      case 'high':
        return <AlertTriangle className="w-4 h-4 text-red-400" />;
      case 'medium':
        return <Clock className="w-4 h-4 text-yellow-400" />;
      case 'low':
        return <CheckCircle2 className="w-4 h-4 text-green-400" />;
      default:
        return <Clock className="w-4 h-4 text-gray-400" />;
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString();
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-2 border-orange-600 border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header with stats */}
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold text-white">Validation Tasks</h3>
          <p className="text-sm text-gray-400">Review and manage validation requests</p>
        </div>
        <div className="flex items-center space-x-4">
          <Badge variant="outline" className="bg-blue-500/20 text-blue-400 border-blue-500">
            {activeValidationType === 'risk-assessments' ? stats.pending_count : 
             activeValidationType === 'knowledge-base' ? pendingDocuments.length :
             adminTasks.filter(task => task.status === 'pending').length} Pending
          </Badge>
          <Badge variant="outline" className="bg-green-500/20 text-green-400 border-green-500">
            {activeValidationType === 'risk-assessments' ? stats.completed_count : 
             activeValidationType === 'knowledge-base' ? 0 :
             adminTasks.filter(task => task.status === 'approved').length} Completed
          </Badge>
        </div>
      </div>

      {/* Validation Type Tabs */}
      <Tabs value={activeValidationType} onValueChange={setActiveValidationType}>
        <TabsList className="bg-gray-800/50 backdrop-blur-sm">
          <TabsTrigger value="user-submissions" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-500 data-[state=active]:to-blue-500">
            <Upload className="h-4 w-4 mr-2" />
            User Submissions
          </TabsTrigger>
          <TabsTrigger value="risk-assessments" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-500 data-[state=active]:to-blue-500">
            <AlertTriangle className="h-4 w-4 mr-2" />
            Risk Assessments
          </TabsTrigger>
          <TabsTrigger value="knowledge-base" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-500 data-[state=active]:to-blue-500">
            <FileText className="h-4 w-4 mr-2" />
            Knowledge Base
          </TabsTrigger>
        </TabsList>

        {/* User Submissions Tab */}
        <TabsContent value="user-submissions" className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Button
                variant={filterStatus === 'all' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setFilterStatus('all')}
                className={filterStatus === 'all' ? 'bg-gradient-to-r from-purple-500 to-blue-500' : ''}
              >
                All Tasks
              </Button>
              <Button
                variant={filterStatus === 'pending' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setFilterStatus('pending')}
                className={filterStatus === 'pending' ? 'bg-gradient-to-r from-purple-500 to-blue-500' : ''}
              >
                Pending Only
              </Button>
            </div>
          </div>

          {adminTasksLoading ? (
            <div className="grid gap-4">
              {[1, 2, 3].map((i) => (
                <Card key={i} className="bg-gray-800/50 border-gray-700">
                  <CardContent className="p-4">
                    <div className="animate-pulse space-y-3">
                      <div className="h-4 bg-gray-600 rounded w-3/4"></div>
                      <div className="h-3 bg-gray-600 rounded w-1/2"></div>
                      <div className="h-3 bg-gray-600 rounded w-1/4"></div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : adminTasks.length === 0 ? (
            <Card className="bg-gray-800/50 border-gray-700">
              <CardContent className="p-8 text-center">
                <Upload className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-white mb-2">No User Submissions</h3>
                <p className="text-gray-400">
                  {filterStatus === 'pending' ? 'No pending user submissions found.' : 'No user submissions found.'}
                </p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid gap-4">
              {adminTasks.map((task) => (
                <Card key={task.id} className="bg-gray-800/50 border-gray-700 hover:border-gray-600 transition-colors">
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center space-x-3 mb-2">
                          <FileIcon className="h-5 w-5 text-blue-400" />
                          <h4 className="font-semibold text-white">{task.title}</h4>
                          {getStatusBadge(task.status)}
                        </div>
                        <p className="text-gray-400 text-sm mb-3 line-clamp-2">{task.description}</p>
                        <div className="flex items-center space-x-4 text-xs text-gray-500">
                          <div className="flex items-center space-x-1">
                            <Calendar className="h-3 w-3" />
                            <span>{new Date(task.created_at).toLocaleDateString()}</span>
                          </div>
                          <div className="flex items-center space-x-1">
                            <User className="h-3 w-3" />
                            <span>User ID: {task.submitted_by.substring(0, 8)}...</span>
                          </div>
                          <Badge variant="outline" className="text-xs">
                            {task.type.replace('_', ' ')}
                          </Badge>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2 ml-4">
                        {task.status === 'pending' && (
                          <Button
                            size="sm"
                            onClick={() => handleAdminTaskReview(task)}
                            className="bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600"
                          >
                            <Eye className="h-4 w-4 mr-1" />
                            Review
                          </Button>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        {/* Risk Assessments Tab */}
        <TabsContent value="risk-assessments" className="space-y-4">
          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card className="bg-gray-900/50 border-gray-800">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-400">Total Tasks</p>
                    <p className="text-2xl font-bold text-white">{stats.total_count}</p>
                  </div>
                  <FileIcon className="h-8 w-8 text-blue-500" />
                </div>
              </CardContent>
            </Card>
            
            <Card className="bg-gray-900/50 border-gray-800">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-400">Pending Review</p>
                    <p className="text-2xl font-bold text-yellow-400">{stats.pending_count}</p>
                  </div>
                  <Clock className="h-8 w-8 text-yellow-500" />
                </div>
              </CardContent>
            </Card>
            
            <Card className="bg-gray-900/50 border-gray-800">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-400">Completed</p>
                    <p className="text-2xl font-bold text-green-400">{stats.completed_count}</p>
                  </div>
                  <CheckCircle2 className="h-8 w-8 text-green-500" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Filter Tabs */}
          <Tabs value={filterStatus} onValueChange={setFilterStatus}>
            <TabsList className="bg-gray-900/50 border-gray-800">
              <TabsTrigger value="all">All Tasks</TabsTrigger>
              <TabsTrigger value="submitted">Submitted</TabsTrigger>
              <TabsTrigger value="under_review">In Review</TabsTrigger>
              <TabsTrigger value="validated">Validated</TabsTrigger>
              <TabsTrigger value="needs_revision">Needs Revision</TabsTrigger>
            </TabsList>

            <TabsContent value={filterStatus} className="mt-6">
              {/* Validation Tasks List */}
              <div className="space-y-4">
                {tasks.length === 0 ? (
                  <Card className="bg-gray-900/50 border-gray-800">
                    <CardContent className="p-8 text-center">
                      <FileIcon className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                      <p className="text-gray-400">No validation tasks found</p>
                    </CardContent>
                  </Card>
                ) : (
                  tasks.map((task) => (
                    <Card key={task.validation_id} className="bg-gray-900/50 border-gray-800 hover:border-gray-700 transition-colors">
                      <CardContent className="p-6">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <div className="flex items-center gap-3 mb-3">
                              {getPriorityIcon(task.priority)}
                              <h3 className="text-lg font-semibold text-white">{task.assessment_title}</h3>
                              {getStatusBadge(task.status)}
                            </div>
                            
                            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 text-sm">
                              <div className="flex items-center gap-2 text-gray-300">
                                <Building className="w-4 h-4 text-gray-400" />
                                <span>{task.company_name}</span>
                              </div>
                              
                              <div className="flex items-center gap-2 text-gray-300">
                                <User className="w-4 h-4 text-gray-400" />
                                <span>{task.user_name}</span>
                              </div>
                              
                              <div className="flex items-center gap-2 text-gray-300">
                                <Calendar className="w-4 h-4 text-gray-400" />
                                <span>{formatDate(task.submitted_at)}</span>
                              </div>
                              
                              <div className="flex items-center gap-2 text-gray-300">
                                <AlertTriangle className="w-4 h-4 text-gray-400" />
                                <span className={`font-medium ${
                                  task.risk_level === 'high' ? 'text-red-400' :
                                  task.risk_level === 'medium' ? 'text-yellow-400' :
                                  'text-green-400'
                                }`}>
                                  {task.risk_level.toUpperCase()} ({task.risk_percentage.toFixed(1)}%)
                                </span>
                              </div>
                            </div>
                            
                            <div className="mt-3 text-sm text-gray-400">
                              <span className="font-medium text-gray-300">Template:</span> {task.template_title}
                            </div>
                          </div>
                          
                          <div className="ml-4">
                            <Button
                              onClick={() => loadTaskDetail(task.validation_id)}
                              variant="outline"
                              size="sm"
                              className="border-gray-600 text-gray-300 hover:bg-gray-800"
                            >
                              <Eye className="w-4 h-4 mr-2" />
                              Review
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))
                )}
              </div>
            </TabsContent>
          </Tabs>
        </TabsContent>

        {/* Knowledge Base Document Validation Tab */}
        <TabsContent value="knowledge-base" className="space-y-6">
          <div className="space-y-4">
            {documentLoading ? (
              <Card className="bg-gray-900/50 border-gray-800">
                <CardContent className="p-8 text-center">
                  <p className="text-gray-400">Loading pending documents...</p>
                </CardContent>
              </Card>
            ) : pendingDocuments.length === 0 ? (
              <Card className="bg-gray-900/50 border-gray-800">
                <CardContent className="p-8 text-center">
                  <FileText className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-400">No documents pending validation</p>
                </CardContent>
              </Card>
            ) : (
              pendingDocuments.map((document) => (
                <Card key={document.id} className="bg-gray-900/50 border-gray-800 hover:border-gray-700 transition-colors">
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-3">
                          <FileText className="w-5 h-5 text-blue-400" />
                          <h3 className="text-lg font-semibold text-white">{document.title}</h3>
                          <Badge variant="outline" className="text-yellow-400 border-yellow-400">
                            Pending Validation
                          </Badge>
                        </div>
                        
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm text-gray-300 mb-4">
                          <div>
                            <span className="text-gray-400">Jurisdiction:</span>
                            <p className="font-medium">{document.country_jurisdiction || 'Not specified'}</p>
                          </div>
                          <div>
                            <span className="text-gray-400">Type:</span>
                            <p className="font-medium">{document.regulation_type || 'Not specified'}</p>
                          </div>
                          <div>
                            <span className="text-gray-400">Subject:</span>
                            <p className="font-medium">{document.subject || 'Not specified'}</p>
                          </div>
                          <div>
                            <span className="text-gray-400">Uploaded:</span>
                            <p className="font-medium">{new Date(document.created_at).toLocaleDateString()}</p>
                          </div>
                        </div>
                        
                        {document.description && (
                          <p className="text-gray-300 text-sm mb-4">{document.description}</p>
                        )}
                        
                        {document.tags && document.tags.length > 0 && (
                          <div className="flex flex-wrap gap-2 mb-4">
                            {document.tags.map((tag, index) => (
                              <Badge key={index} variant="secondary" className="text-xs">
                                {tag}
                              </Badge>
                            ))}
                          </div>
                        )}
                      </div>
                      
                      <div className="flex gap-2 ml-4">
                        <Button
                          onClick={() => {
                            setSelectedDocument(document);
                            setDocumentDecision('approve');
                            setDocumentComments('');
                            setShowDocumentDialog(true);
                          }}
                          size="sm"
                          className="bg-green-600 hover:bg-green-700"
                        >
                          <CheckSquare className="w-4 h-4 mr-2" />
                          Approve
                        </Button>
                        <Button
                          onClick={() => {
                            setSelectedDocument(document);
                            setDocumentDecision('reject');
                            setDocumentComments('');
                            setShowDocumentDialog(true);
                          }}
                          size="sm"
                          variant="destructive"
                        >
                          <XCircle className="w-4 h-4 mr-2" />
                          Reject
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        </TabsContent>
      </Tabs>

      {/* Knowledge Base Document Validation Dialog */}
      <Dialog open={showDocumentDialog} onOpenChange={setShowDocumentDialog}>
        <DialogContent className="max-w-2xl bg-gray-900 border-gray-800">
          <DialogHeader>
            <DialogTitle className="text-white">
              {documentDecision === 'approve' ? 'Approve' : 'Reject'} Document: {selectedDocument?.title}
            </DialogTitle>
            <DialogDescription className="text-gray-400">
              {documentDecision === 'approve' 
                ? 'This document will be published and made available to users.'
                : 'This document will be rejected and removed from the system.'}
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            <div>
              <label className="text-sm text-gray-300 block mb-2">
                {documentDecision === 'approve' ? 'Approval Comments (Optional)' : 'Rejection Reason'}
              </label>
              <Textarea
                value={documentComments}
                onChange={(e) => setDocumentComments(e.target.value)}
                placeholder={documentDecision === 'approve' 
                  ? 'Add any comments about the approval...'
                  : 'Please provide a reason for rejection...'}
                className="bg-gray-800 border-gray-700 text-white"
                rows={4}
              />
            </div>
          </div>
          
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => setShowDocumentDialog(false)}
              className="border-gray-600 text-gray-300 hover:bg-gray-700"
            >
              Cancel
            </Button>
            <Button 
              onClick={handleDocumentValidation}
              disabled={documentReviewing || (documentDecision === 'reject' && !documentComments.trim())}
              className={documentDecision === 'approve' ? 'bg-green-600 hover:bg-green-700' : 'bg-red-600 hover:bg-red-700'}
            >
              {documentReviewing ? 'Processing...' : (documentDecision === 'approve' ? 'Approve Document' : 'Reject Document')}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Task Detail Dialog */}
      <Dialog open={showDetailDialog} onOpenChange={setShowDetailDialog}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto bg-gray-900 border-gray-800">
          <DialogHeader>
            <DialogTitle className="text-white">
              Review Validation Task: {selectedTask?.assessment_title}
            </DialogTitle>
            <DialogDescription className="text-gray-400">
              Submitted by {selectedTask?.user_name} ({selectedTask?.user_email}) on {selectedTask ? formatDate(selectedTask.submitted_at) : ''}
            </DialogDescription>
          </DialogHeader>
          
          {selectedTask && (
            <div className="space-y-6">
              {/* Assessment Overview */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <h4 className="font-semibold text-white mb-2">Risk Level</h4>
                  <Badge className={`${
                    selectedTask.risk_score.riskLevel === 'high' ? 'bg-red-900/20 text-red-300 border-red-700' :
                    selectedTask.risk_score.riskLevel === 'medium' ? 'bg-yellow-900/20 text-yellow-300 border-yellow-700' :
                    'bg-green-900/20 text-green-300 border-green-700'
                  }`}>
                    {selectedTask.risk_score.riskLevel?.toUpperCase()} ({selectedTask.risk_score.percentage?.toFixed(1)}%)
                  </Badge>
                </div>
                
                <div>
                  <h4 className="font-semibold text-white mb-2">Completion</h4>
                  <p className="text-gray-300">
                    {selectedTask.risk_score.answeredQuestions || 0} questions answered 
                    ({selectedTask.risk_score.completionRate?.toFixed(1) || 0}% complete)
                  </p>
                </div>
              </div>

              {/* Action Plan Review */}
              <div>
                <h4 className="font-semibold text-white mb-3">Action Plan</h4>
                <div className="space-y-3">
                  <div>
                    <label className="text-sm font-medium text-red-300">High Priority Actions</label>
                    <Textarea
                      value={modifiedActionPlan.high}
                      onChange={(e) => setModifiedActionPlan(prev => ({ ...prev, high: e.target.value }))}
                      className="mt-1 bg-gray-800 border-gray-700 text-white"
                      rows={2}
                    />
                  </div>
                  
                  <div>
                    <label className="text-sm font-medium text-yellow-300">Medium Priority Actions</label>
                    <Textarea
                      value={modifiedActionPlan.medium}
                      onChange={(e) => setModifiedActionPlan(prev => ({ ...prev, medium: e.target.value }))}
                      className="mt-1 bg-gray-800 border-gray-700 text-white"
                      rows={2}
                    />
                  </div>
                  
                  <div>
                    <label className="text-sm font-medium text-green-300">Low Priority Actions</label>
                    <Textarea
                      value={modifiedActionPlan.low}
                      onChange={(e) => setModifiedActionPlan(prev => ({ ...prev, low: e.target.value }))}
                      className="mt-1 bg-gray-800 border-gray-700 text-white"
                      rows={2}
                    />
                  </div>
                </div>
              </div>

              {/* Overall Assessment Review */}
              <div>
                <h4 className="font-semibold text-white mb-3">Overall Assessment</h4>
                <div className="space-y-3">
                  <div>
                    <label className="text-sm font-medium text-green-300">Strengths</label>
                    <Textarea
                      value={modifiedOverallAssessment.strengths}
                      onChange={(e) => setModifiedOverallAssessment(prev => ({ ...prev, strengths: e.target.value }))}
                      className="mt-1 bg-gray-800 border-gray-700 text-white"
                      rows={2}
                    />
                  </div>
                  
                  <div>
                    <label className="text-sm font-medium text-yellow-300">Areas for Improvement</label>
                    <Textarea
                      value={modifiedOverallAssessment.weaknesses}
                      onChange={(e) => setModifiedOverallAssessment(prev => ({ ...prev, weaknesses: e.target.value }))}
                      className="mt-1 bg-gray-800 border-gray-700 text-white"
                      rows={2}
                    />
                  </div>
                  
                  <div>
                    <label className="text-sm font-medium text-blue-300">Recommendations</label>
                    <Textarea
                      value={modifiedOverallAssessment.recommendations}
                      onChange={(e) => setModifiedOverallAssessment(prev => ({ ...prev, recommendations: e.target.value }))}
                      className="mt-1 bg-gray-800 border-gray-700 text-white"
                      rows={2}
                    />
                  </div>
                </div>
              </div>

              {/* Admin Decision */}
              <div>
                <h4 className="font-semibold text-white mb-3">Validation Decision</h4>
                <div className="space-y-3">
                  <div className="flex gap-4">
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="radio"
                        name="adminDecision"
                        value="approve"
                        checked={adminDecision === 'approve'}
                        onChange={(e) => setAdminDecision(e.target.value as 'approve' | 'request_changes')}
                        className="text-green-600"
                      />
                      <span className="text-green-300">Validated without changes</span>
                    </label>
                    
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="radio"
                        name="adminDecision"
                        value="request_changes"
                        checked={adminDecision === 'request_changes'}
                        onChange={(e) => setAdminDecision(e.target.value as 'approve' | 'request_changes')}
                        className="text-yellow-600"
                      />
                      <span className="text-yellow-300">Modifications proposed</span>
                    </label>
                  </div>
                  
                  <div>
                    <label className="text-sm font-medium text-gray-300">Admin Comments</label>
                    <Textarea
                      value={adminComments}
                      onChange={(e) => setAdminComments(e.target.value)}
                      placeholder="Add comments or feedback for the user..."
                      className="mt-1 bg-gray-800 border-gray-700 text-white"
                      rows={3}
                    />
                  </div>
                </div>
              </div>
            </div>
          )}
          
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setShowDetailDialog(false)}
              className="border-gray-600 text-gray-300 hover:bg-gray-800"
            >
              Cancel
            </Button>
            <Button
              onClick={submitValidationResponse}
              disabled={reviewing}
              className={`${
                adminDecision === 'approve' 
                  ? 'bg-green-600 hover:bg-green-700' 
                  : 'bg-yellow-600 hover:bg-yellow-700'
              }`}
            >
              {reviewing ? (
                <>
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                  Processing...
                </>
              ) : (
                adminDecision === 'approve' ? 'Validate Assessment' : 'Request Changes'
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Admin Task Review Dialog */}
      <Dialog open={showAdminTaskDialog} onOpenChange={setShowAdminTaskDialog}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto bg-gray-900 border-gray-700">
          <DialogHeader>
            <DialogTitle className="text-xl font-bold text-white flex items-center">
              <FileIcon className="h-5 w-5 mr-2 text-blue-400" />
              Review User Submission
            </DialogTitle>
            <DialogDescription className="text-gray-400">
              Review and decide on this user submission
            </DialogDescription>
          </DialogHeader>

          {selectedAdminTask && (
            <div className="space-y-6">
              {/* Task Details */}
              <div className="grid gap-4">
                <div>
                  <h3 className="text-lg font-semibold text-white mb-2">{selectedAdminTask.title}</h3>
                  <p className="text-gray-400 mb-4">{selectedAdminTask.description}</p>
                  
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="text-gray-500">Submission Type:</span>
                      <p className="text-white">{selectedAdminTask.type.replace('_', ' ')}</p>
                    </div>
                    <div>
                      <span className="text-gray-500">Submitted:</span>
                      <p className="text-white">{new Date(selectedAdminTask.created_at).toLocaleString()}</p>
                    </div>
                    <div>
                      <span className="text-gray-500">User ID:</span>
                      <p className="text-white">{selectedAdminTask.submitted_by}</p>
                    </div>
                    <div>
                      <span className="text-gray-500">Status:</span>
                      <div className="mt-1">{getStatusBadge(selectedAdminTask.status)}</div>
                    </div>
                  </div>
                </div>

                {/* Document Content/Details */}
                {selectedAdminTask.document_url && (
                  <div>
                    <h4 className="text-lg font-semibold text-white mb-2">Submitted Document</h4>
                    <div className="bg-gray-800/50 border border-gray-700 rounded-lg p-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <FileIcon className="h-8 w-8 text-blue-400" />
                          <div>
                            <p className="text-white font-medium">Document submitted</p>
                            <p className="text-gray-400 text-sm">Click to view the submitted document</p>
                          </div>
                        </div>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => window.open(selectedAdminTask.document_url, '_blank')}
                          className="border-gray-600 text-gray-300 hover:bg-gray-700"
                        >
                          <Eye className="h-4 w-4 mr-1" />
                          View Document
                        </Button>
                      </div>
                    </div>
                  </div>
                )}

                {/* Additional Details */}
                {selectedAdminTask.metadata && Object.keys(selectedAdminTask.metadata).length > 0 && (
                  <div>
                    <h4 className="text-lg font-semibold text-white mb-2">Additional Details</h4>
                    <div className="bg-gray-800/50 border border-gray-700 rounded-lg p-4">
                      <pre className="text-gray-300 text-sm whitespace-pre-wrap">
                        {JSON.stringify(selectedAdminTask.metadata, null, 2)}
                      </pre>
                    </div>
                  </div>
                )}
              </div>

              {/* Admin Decision Section */}
              {selectedAdminTask.status === 'pending' && (
                <div className="space-y-4 border-t border-gray-700 pt-6">
                  <h4 className="text-lg font-semibold text-white">Admin Decision</h4>
                  
                  {/* Decision Options */}
                  <div className="space-y-3">
                    <div className="flex items-center space-x-4">
                      <label className="flex items-center space-x-2 cursor-pointer">
                        <input
                          type="radio"
                          name="adminTaskDecision"
                          value="approved"
                          checked={adminTaskDecision === 'approved'}
                          onChange={(e) => setAdminTaskDecision(e.target.value as 'approved' | 'rejected')}
                          className="text-green-500"
                        />
                        <CheckCircle2 className="h-5 w-5 text-green-400" />
                        <span className="text-white">Approve Submission</span>
                      </label>
                    </div>
                    <div className="flex items-center space-x-4">
                      <label className="flex items-center space-x-2 cursor-pointer">
                        <input
                          type="radio"
                          name="adminTaskDecision"
                          value="rejected"
                          checked={adminTaskDecision === 'rejected'}
                          onChange={(e) => setAdminTaskDecision(e.target.value as 'approved' | 'rejected')}
                          className="text-red-500"
                        />
                        <XCircle className="h-5 w-5 text-red-400" />
                        <span className="text-white">Reject Submission</span>
                      </label>
                    </div>
                  </div>

                  {/* Admin Notes */}
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">
                      Admin Notes {adminTaskDecision === 'rejected' && <span className="text-red-400">*</span>}
                    </label>
                    <Textarea
                      value={adminTaskNotes}
                      onChange={(e) => setAdminTaskNotes(e.target.value)}
                      placeholder={adminTaskDecision === 'approved' 
                        ? "Optional: Add notes about the approval..."
                        : "Required: Explain why this submission is being rejected..."}
                      className="bg-gray-800 border-gray-700 text-white"
                      rows={4}
                    />
                  </div>
                </div>
              )}

              {/* Previous Notes (if any) */}
              {selectedAdminTask.notes && (
                <div className="border-t border-gray-700 pt-6">
                  <h4 className="text-lg font-semibold text-white mb-2">Previous Notes</h4>
                  <div className="bg-gray-800/50 border border-gray-700 rounded-lg p-4">
                    <p className="text-gray-300">{selectedAdminTask.notes}</p>
                  </div>
                </div>
              )}
            </div>
          )}

          <DialogFooter className="border-t border-gray-700 pt-4">
            <Button 
              variant="outline" 
              onClick={() => setShowAdminTaskDialog(false)}
              className="border-gray-600 text-gray-300 hover:bg-gray-700"
            >
              Cancel
            </Button>
            {selectedAdminTask?.status === 'pending' && (
              <Button
                onClick={submitAdminTaskReview}
                disabled={adminTaskReviewing || (adminTaskDecision === 'rejected' && !adminTaskNotes.trim())}
                className={adminTaskDecision === 'approved' 
                  ? "bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700" 
                  : "bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700"}
              >
                {adminTaskReviewing ? (
                  <>
                    <Clock className="h-4 w-4 mr-2 animate-spin" />
                    Processing...
                  </>
                ) : (
                  <>
                    {adminTaskDecision === 'approved' ? (
                      <CheckCircle2 className="h-4 w-4 mr-2" />
                    ) : (
                      <XCircle className="h-4 w-4 mr-2" />
                    )}
                    {adminTaskDecision === 'approved' ? 'Approve' : 'Reject'} Submission
                  </>
                )}
              </Button>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default ValidationTasks;
