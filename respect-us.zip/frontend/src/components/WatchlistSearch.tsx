



import React, { useState } from 'react';
import brain from 'brain';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Checkbox } from '@/components/ui/checkbox';
import { AlertTriangle, Search, FileText, Loader2, User, Building, Ship, Plane, Calendar, MapPin, Clock } from 'lucide-react';
import { toast } from 'sonner';
import { WatchlistHitVerification } from 'components/WatchlistHitVerification';

interface WatchlistEntry {
  id: number;
  list_name: string;
  entity_name: string;
  aliases: string[];
  entity_type: string;
  country: string | null;
  date_of_birth: string | null;
  identification_numbers: string[];
  sanctions_program: string;
  listing_date: string | null;
  last_updated: string;
  is_active: boolean;
  source_url: string | null;
  raw_data: any;
}

interface WatchlistSearchResult {
  watchlist_entry: WatchlistEntry;
  match_score: number;
  match_type: string;
  matched_field: string;
  risk_assessment: string;
}

export interface Props {
  className?: string;
}

const WatchlistSearch: React.FC<Props> = ({ className }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [entityType, setEntityType] = useState<string>('');
  const [country, setCountry] = useState('');
  const [dateOfBirth, setDateOfBirth] = useState('');
  const [exactMatch, setExactMatch] = useState(false);
  const [searchResults, setSearchResults] = useState<WatchlistSearchResult[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [searchPerformed, setSearchPerformed] = useState(false);
  const [verifiedResults, setVerifiedResults] = useState<Set<number>>(new Set());

  const handleVerificationComplete = (entryId: number) => {
    setVerifiedResults(prev => new Set([...prev, entryId]));
  };

  const handleSearch = async () => {
    if (!searchTerm.trim()) {
      toast.error('Please enter a search term');
      return;
    }

    setIsSearching(true);
    setSearchPerformed(false);

    try {
      const searchRequest = {
        search_term: searchTerm,
        entity_type: entityType || undefined,
        country: country || undefined,
        date_of_birth: dateOfBirth || undefined,
        exact_match: exactMatch,
        limit: 50
      };

      console.log('🔍 Searching watchlists with:', searchRequest);
      const response = await brain.search_watchlists(searchRequest);
      const results = await response.json();
      
      setSearchResults(results);
      setSearchPerformed(true);
      
      toast.success(`Found ${results.length} watchlist entries`);
      console.log('✅ Search results:', results);
    } catch (error) {
      console.error('❌ Search error:', error);
      toast.error('Failed to search watchlists. Please try again.');
      setSearchResults([]);
    } finally {
      setIsSearching(false);
    }
  };

  const handleClearSearch = () => {
    setSearchTerm('');
    setEntityType('');
    setCountry('');
    setDateOfBirth('');
    setExactMatch(false);
    setSearchResults([]);
    setSearchPerformed(false);
  };

  const getRiskBadgeColor = (risk: string) => {
    switch (risk.toLowerCase()) {
      case 'critical': return 'bg-red-600 hover:bg-red-700';
      case 'high': return 'bg-orange-600 hover:bg-orange-700';
      case 'medium': return 'bg-yellow-600 hover:bg-yellow-700';
      case 'low': return 'bg-green-600 hover:bg-green-700';
      default: return 'bg-gray-600 hover:bg-gray-700';
    }
  };

  const getEntityIcon = (entityType: string) => {
    switch (entityType) {
      case 'individual': return <User className="h-4 w-4" />;
      case 'company': return <Building className="h-4 w-4" />;
      case 'vessel': return <Ship className="h-4 w-4" />;
      case 'aircraft': return <Plane className="h-4 w-4" />;
      default: return <FileText className="h-4 w-4" />;
    }
  };

  const formatDate = (dateString: string | null) => {
    if (!dateString) return 'N/A';
    return new Date(dateString).toLocaleDateString();
  };

  return (
    <div className={`space-y-6 ${className}`}>
      {/* Search Form */}
      <Card className="bg-slate-800/30 border-slate-700/50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-white">
            <Search className="h-5 w-5 text-blue-400" />
            Direct Watchlist Search
          </CardTitle>
          <CardDescription className="text-gray-400">
            Enter any information (name, birth date, country) to search for sanctioned persons, entities, vessels, and aircraft
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Primary Search Field */}
          <div className="space-y-2">
            <Label htmlFor="searchTerm" className="text-sm font-medium text-gray-300">
              Search Term *
            </Label>
            <Input
              id="searchTerm"
              placeholder="Enter name, company, vessel, or aircraft..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="bg-slate-800 border-slate-600 text-white placeholder-gray-400"
              onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
            />
          </div>

          {/* Filters Row */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="entityType" className="text-sm font-medium text-gray-300">
                Entity Type
              </Label>
              <Select value={entityType} onValueChange={setEntityType}>
                <SelectTrigger className="bg-slate-800 border-slate-600">
                  <SelectValue placeholder="All types" />
                </SelectTrigger>
                <SelectContent className="bg-slate-800 border-slate-600">
                  <SelectItem value="individual">Individual</SelectItem>
                  <SelectItem value="company">Company</SelectItem>
                  <SelectItem value="vessel">Vessel</SelectItem>
                  <SelectItem value="aircraft">Aircraft</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="country" className="text-sm font-medium text-gray-300">
                Country
              </Label>
              <Input
                id="country"
                placeholder="Enter country..."
                value={country}
                onChange={(e) => setCountry(e.target.value)}
                className="bg-slate-800 border-slate-600 text-white placeholder-gray-400"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="dateOfBirth" className="text-sm font-medium text-gray-300">
                Date of Birth
              </Label>
              <Input
                id="dateOfBirth"
                type="date"
                value={dateOfBirth}
                onChange={(e) => setDateOfBirth(e.target.value)}
                className="bg-slate-800 border-slate-600 text-white"
              />
            </div>
          </div>

          {/* Search Options */}
          <div className="flex items-center space-x-4">
            <label className="flex items-center space-x-2 cursor-pointer">
              <Checkbox
                checked={exactMatch}
                onCheckedChange={(checked) => setExactMatch(checked as boolean)}
                className="border-slate-600 data-[state=checked]:bg-blue-600 data-[state=checked]:border-blue-600"
              />
              <span className="text-sm text-gray-300">Exact match only</span>
            </label>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-3">
            <Button 
              onClick={handleSearch} 
              disabled={isSearching || !searchTerm.trim()}
              className="bg-blue-600 hover:bg-blue-700 flex items-center gap-2"
            >
              {isSearching ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <Search className="h-4 w-4" />
              )}
              {isSearching ? 'Searching...' : 'Search Watchlists'}
            </Button>
            <Button 
              onClick={handleClearSearch} 
              variant="outline"
              className="border-slate-600 text-gray-300 hover:bg-slate-700"
            >
              Clear
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Search Results */}
      {searchPerformed && (
        <Card className="bg-slate-800/30 border-slate-700/50">
          <CardHeader>
            <CardTitle className="flex items-center justify-between text-white">
              <span className="flex items-center gap-2">
                <FileText className="h-5 w-5 text-purple-400" />
                Watchlist Search Results
              </span>
              <Badge variant="outline" className="border-slate-600">
                {searchResults.length} entries found
              </Badge>
            </CardTitle>
            {searchResults.length === 0 && (
              <CardDescription className="text-gray-400">
                No sanctioned persons, entities, vessels, or aircraft found matching your search criteria.
              </CardDescription>
            )}
          </CardHeader>
          {searchResults.length > 0 && (
            <CardContent>
              <div className="space-y-4">
                {searchResults.map((result, index) => (
                  <div key={index} className="bg-slate-700/50 rounded-lg p-6 border border-slate-600/50">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex items-center gap-3">
                        {getEntityIcon(result.watchlist_entry.entity_type)}
                        <div>
                          <h3 className="text-lg font-semibold text-white">
                            {result.watchlist_entry.entity_name}
                          </h3>
                          <p className="text-sm text-gray-400 capitalize">
                            {result.watchlist_entry.entity_type}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant="outline" className="border-slate-600">
                          {Math.round(result.match_score * 100)}% match
                        </Badge>
                        {verifiedResults.has(result.watchlist_entry.id) && (
                          <Badge className="bg-green-600 text-white">
                            Verified
                          </Badge>
                        )}
                        <WatchlistHitVerification 
                          result={result}
                          onVerificationComplete={() => handleVerificationComplete(result.watchlist_entry.id)}
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-4">
                      <div className="space-y-1">
                        <p className="text-xs text-gray-500 uppercase tracking-wide">Sanctions List</p>
                        <p className="text-sm font-medium text-gray-300">{result.watchlist_entry.list_name}</p>
                      </div>
                      <div className="space-y-1">
                        <p className="text-xs text-gray-500 uppercase tracking-wide">Program</p>
                        <p className="text-sm text-gray-300">{result.watchlist_entry.sanctions_program}</p>
                      </div>
                      {result.watchlist_entry.country && (
                        <div className="space-y-1">
                          <p className="text-xs text-gray-500 uppercase tracking-wide flex items-center gap-1">
                            <MapPin className="h-3 w-3" /> Country
                          </p>
                          <p className="text-sm text-gray-300">{result.watchlist_entry.country}</p>
                        </div>
                      )}
                      {result.watchlist_entry.date_of_birth && (
                        <div className="space-y-1">
                          <p className="text-xs text-gray-500 uppercase tracking-wide flex items-center gap-1">
                            <Calendar className="h-3 w-3" /> Date of Birth
                          </p>
                          <p className="text-sm text-gray-300">{formatDate(result.watchlist_entry.date_of_birth)}</p>
                        </div>
                      )}
                      {result.watchlist_entry.listing_date && (
                        <div className="space-y-1">
                          <p className="text-xs text-gray-500 uppercase tracking-wide flex items-center gap-1">
                            <Clock className="h-3 w-3" /> Listed
                          </p>
                          <p className="text-sm text-gray-300">{formatDate(result.watchlist_entry.listing_date)}</p>
                        </div>
                      )}
                    </div>

                    {result.watchlist_entry.aliases && result.watchlist_entry.aliases.length > 0 && (
                      <div className="space-y-2 mb-4">
                        <p className="text-xs text-gray-500 uppercase tracking-wide">Known Aliases</p>
                        <div className="flex flex-wrap gap-2">
                          {result.watchlist_entry.aliases.map((alias, aliasIndex) => (
                            <Badge key={aliasIndex} variant="secondary" className="bg-slate-600 text-gray-300">
                              {alias}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}

                    <Separator className="my-4 bg-slate-600" />
                    
                    <div className="flex items-center justify-between text-xs text-gray-500">
                      <span>Match: {result.match_type} on {result.matched_field}</span>
                      <span>Last updated: {formatDate(result.watchlist_entry.last_updated)}</span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          )}
        </Card>
      )}
    </div>
  );
};

export default WatchlistSearch;
