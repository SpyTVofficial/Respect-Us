
import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { Plus, Edit, Trash2, FileText, BookOpen, Calendar, User, Copy } from 'lucide-react';
import { toast } from 'sonner';
import brain from 'brain';
import type {
  TreeNode,
  NodeOption,
  ClassificationOutcome,
  AppApisClassificationClassificationTree as ClassificationTree,
  ClassificationNote
} from '../brain/data-contracts';

const NotesTab: React.FC = () => {
  const [notes, setNotes] = useState<ClassificationNote[]>([]);
  const [trees, setTrees] = useState<ClassificationTree[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [editingNote, setEditingNote] = useState<ClassificationNote | null>(null);
  const [formData, setFormData] = useState({
    note_key: '',
    title: '',
    content: '',
    tree_id: ''
  });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      setLoading(true);
      
      // Load all notes
      const notesResponse = await brain.list_classification_notes({});
      if (notesResponse.ok) {
        const notesData = await notesResponse.json();
        // Sort notes alphabetically by note_key
        const sortedNotes = notesData.sort((a: ClassificationNote, b: ClassificationNote) => 
          a.note_key.localeCompare(b.note_key)
        );
        setNotes(sortedNotes);
      }
      
      // Load trees for dropdown
      const treesResponse = await brain.list_classification_trees();
      if (treesResponse.ok) {
        const treesData = await treesResponse.json();
        setTrees(treesData);
      }
    } catch (error) {
      console.error('Error loading notes data:', error);
      toast.error('Failed to load notes data');
    } finally {
      setLoading(false);
    }
  };

  const handleCreateNote = async () => {
    try {
      if (!formData.note_key || !formData.title || !formData.content) {
        toast.error('Please fill in required fields');
        return;
      }

      const response = await brain.create_classification_note({
        note_key: formData.note_key,
        title: formData.title,
        content: formData.content,
        tree_id: formData.tree_id === 'global' ? null : formData.tree_id || null
      });

      if (response.ok) {
        toast.success('Note created successfully');
        setShowCreateDialog(false);
        resetForm();
        loadData();
      } else {
        const errorData = await response.json();
        toast.error(errorData.detail || 'Failed to create note');
      }
    } catch (error) {
      console.error('Error creating note:', error);
      toast.error('Failed to create note');
    }
  };

  const handleEditNote = (note: ClassificationNote) => {
    setEditingNote(note);
    setFormData({
      note_key: note.note_key,
      title: note.title,
      content: note.content,
      tree_id: note.tree_id || 'global'
    });
    setShowEditDialog(true);
  };

  const handleUpdateNote = async () => {
    try {
      if (!editingNote || !formData.note_key || !formData.title || !formData.content) {
        toast.error('Please fill in required fields');
        return;
      }

      const response = await brain.update_classification_note(
        { noteId: editingNote.id! },
        {
          note_key: formData.note_key,
          title: formData.title,
          content: formData.content
        }
      );

      if (response.ok) {
        toast.success('Note updated successfully');
        setShowEditDialog(false);
        setEditingNote(null);
        resetForm();
        loadData();
      } else {
        const errorData = await response.json();
        toast.error(errorData.detail || 'Failed to update note');
      }
    } catch (error) {
      console.error('Error updating note:', error);
      toast.error('Failed to update note');
    }
  };

  const handleDeleteNote = async (noteId: number) => {
    try {
      const response = await brain.delete_classification_note({ noteId });
      if (response.ok) {
        toast.success('Note deleted successfully');
        loadData();
      } else {
        const errorData = await response.json();
        toast.error(errorData.detail || 'Failed to delete note');
      }
    } catch (error) {
      console.error('Error deleting note:', error);
      toast.error('Failed to delete note');
    }
  };

  const handleDuplicateNote = async (note: ClassificationNote) => {
    try {
      const duplicateData = {
        note_key: `${note.note_key}_copy`,
        title: `${note.title} (Copy)`,
        content: note.content,
        tree_id: note.tree_id
      };

      const response = await brain.create_classification_note(duplicateData);

      if (response.ok) {
        toast.success('Note duplicated successfully');
        loadData();
      } else {
        const errorData = await response.json();
        toast.error(errorData.detail || 'Failed to duplicate note');
      }
    } catch (error) {
      console.error('Error duplicating note:', error);
      toast.error('Failed to duplicate note');
    }
  };

  const resetForm = () => {
    setFormData({
      note_key: '',
      title: '',
      content: '',
      tree_id: ''
    });
  };

  const getTreeName = (treeId: string | null) => {
    if (!treeId) return 'Global Note';
    const tree = trees.find(t => t.id === treeId);
    return tree ? tree.name : 'Unknown Tree';
  };

  const formatDate = (dateString: string | null) => {
    if (!dateString) return 'N/A';
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h3 className="text-xl font-semibold text-blue-400">Regulatory Notes</h3>
          <p className="text-gray-400 text-sm mt-1">Manage regulatory notes and documentation</p>
        </div>
        <Button 
          onClick={() => {
            resetForm();
            setShowCreateDialog(true);
          }}
          className="bg-blue-600 hover:bg-blue-700 text-white"
        >
          <Plus className="w-4 h-4 mr-2" />
          Create Note
        </Button>
      </div>

      {loading ? (
        <div className="text-center py-8">
          <p className="text-gray-400">Loading notes...</p>
        </div>
      ) : (
        <div className="w-full">
          {notes.length === 0 ? (
            <div className="text-center py-8">
              <FileText className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-400">No regulatory notes found</p>
              <p className="text-gray-500 text-sm">Create your first note to get started</p>
            </div>
          ) : (
            <div className="w-full overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="text-white min-w-[120px]">Note Key</TableHead>
                    <TableHead className="text-white min-w-[200px]">Title</TableHead>
                    <TableHead className="text-white min-w-[300px]">Content</TableHead>
                    <TableHead className="text-white min-w-[120px]">Tree</TableHead>
                    <TableHead className="text-white min-w-[150px]">Created At</TableHead>
                    <TableHead className="text-white min-w-[120px]">Created By</TableHead>
                    <TableHead className="text-white min-w-[120px]">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {notes.map((note) => (
                    <TableRow key={note.id} className="border-gray-700 hover:bg-gray-800/50">
                      <TableCell className="text-blue-300 font-medium">
                        <div className="flex items-center gap-2">
                          <BookOpen className="w-4 h-4 text-blue-400" />
                          {note.note_key}
                        </div>
                      </TableCell>
                      <TableCell className="text-white">{note.title}</TableCell>
                      <TableCell className="text-gray-300">
                        <div className="max-w-[300px] truncate" title={note.content}>
                          {note.content}
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline" className="text-xs">
                          <FileText className="w-3 h-3 mr-1" />
                          {getTreeName(note.tree_id)}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-gray-400 text-sm">
                        <div className="flex items-center gap-1">
                          <Calendar className="w-3 h-3" />
                          {formatDate(note.created_at)}
                        </div>
                      </TableCell>
                      <TableCell className="text-gray-400 text-sm">
                        {note.created_by && (
                          <div className="flex items-center gap-1">
                            <User className="w-3 h-3" />
                            {note.created_by.slice(0, 8)}...
                          </div>
                        )}
                      </TableCell>
                      <TableCell>
                        <div className="flex gap-1">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleEditNote(note)}
                            className="text-gray-400 hover:text-white"
                            title="Edit Note"
                          >
                            <Edit className="w-4 h-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleDuplicateNote(note)}
                            className="text-gray-400 hover:text-blue-400"
                            title="Duplicate Note"
                          >
                            <Copy className="w-4 h-4" />
                          </Button>
                          <AlertDialog>
                            <AlertDialogTrigger asChild>
                              <Button
                                variant="ghost"
                                size="sm"
                                className="text-gray-400 hover:text-red-400"
                                title="Delete Note"
                              >
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </AlertDialogTrigger>
                            <AlertDialogContent className="bg-gray-900 border-gray-700">
                              <AlertDialogHeader>
                                <AlertDialogTitle className="text-white">Delete Note</AlertDialogTitle>
                                <AlertDialogDescription className="text-gray-400">
                                  Are you sure you want to delete this note? This action cannot be undone.
                                </AlertDialogDescription>
                              </AlertDialogHeader>
                              <AlertDialogFooter>
                                <AlertDialogCancel className="bg-gray-800 border-gray-600 text-white hover:bg-gray-700">
                                  Cancel
                                </AlertDialogCancel>
                                <AlertDialogAction
                                  onClick={() => handleDeleteNote(note.id!)}
                                  className="bg-red-600 hover:bg-red-700 text-white"
                                >
                                  Delete
                                </AlertDialogAction>
                              </AlertDialogFooter>
                            </AlertDialogContent>
                          </AlertDialog>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </div>
      )}

      {/* Create Note Dialog */}
      <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
        <DialogContent className="bg-gray-900 border-gray-700 text-white max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-blue-400">Create Regulatory Note</DialogTitle>
            <DialogDescription className="text-gray-400">
              Create a new regulatory note for classification reference
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="text-gray-300">Note Key *</Label>
                <Input
                  value={formData.note_key}
                  onChange={(e) => setFormData({ ...formData, note_key: e.target.value })}
                  className="bg-gray-800 border-gray-600 text-white"
                  placeholder="e.g., REG001, ITAR-NOTE-1"
                />
              </div>
              <div className="space-y-2">
                <Label className="text-gray-300">Classification Tree (Optional)</Label>
                <Select value={formData.tree_id || 'global'} onValueChange={(value) => setFormData({ ...formData, tree_id: value === 'global' ? null : value })}>
                  <SelectTrigger className="bg-gray-800 border-gray-600 text-white">
                    <SelectValue placeholder="Global note (all trees)" />
                  </SelectTrigger>
                  <SelectContent className="bg-gray-800 border-gray-600">
                    <SelectItem value="global" className="text-white">
                      Global note (all trees)
                    </SelectItem>
                    {trees.map(tree => (
                      <SelectItem key={tree.id} value={tree.id} className="text-white">
                        {tree.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <div className="space-y-2">
              <Label className="text-gray-300">Title *</Label>
              <Input
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                className="bg-gray-800 border-gray-600 text-white"
                placeholder="Brief descriptive title"
              />
            </div>
            
            <div className="space-y-2">
              <Label className="text-gray-300">Content *</Label>
              <Textarea
                value={formData.content}
                onChange={(e) => setFormData({ ...formData, content: e.target.value })}
                className="bg-gray-800 border-gray-600 text-white"
                placeholder="Detailed regulatory note content"
                rows={6}
              />
            </div>
          </div>
          
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => setShowCreateDialog(false)}
              className="bg-gray-800 border-gray-600 text-white hover:bg-gray-700"
            >
              Cancel
            </Button>
            <Button 
              onClick={handleCreateNote}
              className="bg-blue-600 hover:bg-blue-700 text-white"
            >
              Create Note
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Note Dialog */}
      <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
        <DialogContent className="bg-gray-900 border-gray-700 text-white max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-blue-400">Edit Regulatory Note</DialogTitle>
            <DialogDescription className="text-gray-400">
              Update the regulatory note details
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="text-gray-300">Note Key *</Label>
                <Input
                  value={formData.note_key}
                  onChange={(e) => setFormData({ ...formData, note_key: e.target.value })}
                  className="bg-gray-800 border-gray-600 text-white"
                  placeholder="e.g., REG001, ITAR-NOTE-1"
                />
              </div>
              <div className="space-y-2">
                <Label className="text-gray-300">Classification Tree</Label>
                <Input
                  value={getTreeName(editingNote?.tree_id || null)}
                  disabled
                  className="bg-gray-800 border-gray-600 text-gray-400"
                />
              </div>
            </div>
            
            <div className="space-y-2">
              <Label className="text-gray-300">Title *</Label>
              <Input
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                className="bg-gray-800 border-gray-600 text-white"
                placeholder="Brief descriptive title"
              />
            </div>
            
            <div className="space-y-2">
              <Label className="text-gray-300">Content *</Label>
              <Textarea
                value={formData.content}
                onChange={(e) => setFormData({ ...formData, content: e.target.value })}
                className="bg-gray-800 border-gray-600 text-white"
                placeholder="Detailed regulatory note content"
                rows={6}
              />
            </div>
          </div>
          
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => setShowEditDialog(false)}
              className="bg-gray-800 border-gray-600 text-white hover:bg-gray-700"
            >
              Cancel
            </Button>
            <Button 
              onClick={handleUpdateNote}
              className="bg-blue-600 hover:bg-blue-700 text-white"
            >
              Update Note
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default NotesTab;
