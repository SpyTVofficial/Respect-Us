import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { AlertCircle, Building2, User, Mail, Phone, MapPin, CreditCard } from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert';

export interface CustomerDetails {
  company_name: string;
  contact_person: string;
  email: string;
  phone?: string;
  billing_address: string;
  city: string;
  postal_code: string;
  country: string;
  tax_id?: string;
  vat_number?: string;
}

interface Props {
  onSubmit: (details: CustomerDetails) => void;
  onCancel: () => void;
  isLoading?: boolean;
  initialData?: Partial<CustomerDetails>;
  title?: string;
  description?: string;
  onDetailsChange?: (details: Partial<CustomerDetails>) => void;
}

const CustomerOnboardingForm = ({
  onSubmit,
  onCancel,
  isLoading = false,
  initialData = {},
  title = "Customer Information",
  description = "Please provide your company details for billing and compliance purposes.",
  onDetailsChange
}: Props) => {
  const [formData, setFormData] = useState<CustomerDetails>({
    company_name: initialData.company_name || '',
    contact_person: initialData.contact_person || '',
    email: initialData.email || '',
    phone: initialData.phone || '',
    billing_address: initialData.billing_address || '',
    city: initialData.city || '',
    postal_code: initialData.postal_code || '',
    country: initialData.country || '',
    tax_id: initialData.tax_id || '',
    vat_number: initialData.vat_number || ''
  });

  const [noVatBusiness, setNoVatBusiness] = useState(false);

  const [errors, setErrors] = useState<Partial<Record<keyof CustomerDetails, string>>>({});

  const validateForm = (): boolean => {
    const newErrors: Partial<Record<keyof CustomerDetails, string>> = {};

    // Required fields
    if (!formData.company_name.trim()) {
      newErrors.company_name = 'Company name is required';
    }
    if (!formData.contact_person.trim()) {
      newErrors.contact_person = 'Contact person is required';
    }
    if (!formData.email.trim()) {
      newErrors.email = 'Email is required';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = 'Please enter a valid email address';
    }
    if (!formData.billing_address.trim()) {
      newErrors.billing_address = 'Billing address is required';
    }
    if (!formData.city.trim()) {
      newErrors.city = 'City is required';
    }
    if (!formData.postal_code.trim()) {
      newErrors.postal_code = 'Postal code is required';
    }
    if (!formData.country.trim()) {
      newErrors.country = 'Country is required';
    }
    
    // VAT validation - either VAT number OR no-VAT checkbox must be selected
    if (!formData.vat_number?.trim() && !noVatBusiness) {
      newErrors.vat_number = 'VAT number is required, or check "Business with no VAT number"';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validateForm()) {
      onSubmit(formData);
    }
  };

  const handleInputChange = (field: keyof CustomerDetails, value: string | boolean) => {
    setFormData(prev => {
      const updated = { ...prev, [field]: value };
      
      // Trigger VAT calculation when country or VAT number changes
      if ((field === 'country' || field === 'vat_number') && onDetailsChange) {
        onDetailsChange(updated);
      }
      
      return updated;
    });
    
    // Clear error when user starts typing
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: undefined }));
    }
  };

  const renderInputField = ({
    icon: Icon,
    label,
    field,
    type = "text",
    required = false,
    placeholder = ""
  }: {
    icon: any;
    label: string;
    field: keyof CustomerDetails;
    type?: string;
    required?: boolean;
    placeholder?: string;
  }) => {
    const value = (formData[field] as string) || '';
    const error = errors[field];
    
    return (
      <div className="space-y-2" key={field}>
        <Label htmlFor={field} className="text-sm font-medium text-gray-200 flex items-center gap-2">
          <Icon className="h-4 w-4" />
          {label}
          {required && <span className="text-red-400">*</span>}
        </Label>
        {field === 'billing_address' ? (
          <Textarea
            id={field}
            value={value}
            onChange={(e) => handleInputChange(field, e.target.value)}
            placeholder={placeholder}
            className={`bg-gray-800/50 border-gray-600 text-white placeholder-gray-400 focus:border-blue-500 ${
              error ? 'border-red-500' : ''
            }`}
            rows={3}
          />
        ) : (
          <Input
            id={field}
            type={type}
            value={value}
            onChange={(e) => handleInputChange(field, e.target.value)}
            placeholder={placeholder}
            className={`bg-gray-800/50 border-gray-600 text-white placeholder-gray-400 focus:border-blue-500 ${
              error ? 'border-red-500' : ''
            }`}
          />
        )}
        {error && (
          <p className="text-sm text-red-400 flex items-center gap-1">
            <AlertCircle className="h-3 w-3" />
            {error}
          </p>
        )}
      </div>
    );
  };

  return (
    <Card className="w-full max-w-2xl mx-auto bg-gray-900/90 backdrop-blur-sm border-gray-700">
      <CardHeader className="space-y-1">
        <CardTitle className="text-2xl font-bold text-white flex items-center gap-2">
          <Building2 className="h-6 w-6 text-blue-400" />
          {title}
        </CardTitle>
        <CardDescription className="text-gray-400">
          {description}
        </CardDescription>
      </CardHeader>

      <CardContent className="space-y-6">
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Company Information Section */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-white border-b border-gray-700 pb-2">
              Company Information
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {renderInputField({
                icon: Building2,
                label: "Company Name",
                field: "company_name",
                required: true,
                placeholder: "Your Company Ltd."
              })}
              {renderInputField({
                icon: User,
                label: "Contact Person",
                field: "contact_person",
                required: true,
                placeholder: "John Doe"
              })}
            </div>
          </div>

          {/* Contact Information Section */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-white border-b border-gray-700 pb-2">
              Contact Information
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {renderInputField({
                icon: Mail,
                label: "Email Address",
                field: "email",
                type: "email",
                required: true,
                placeholder: "john@company.com"
              })}
              {renderInputField({
                icon: Phone,
                label: "Phone Number",
                field: "phone",
                type: "tel",
                placeholder: "+1 (555) 123-4567"
              })}
            </div>
          </div>

          {/* Billing Address Section */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-white border-b border-gray-700 pb-2">
              Billing Address
            </h3>
            {renderInputField({
              icon: MapPin,
              label: "Address",
              field: "billing_address",
              required: true,
              placeholder: "123 Business Street, Suite 100"
            })}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {renderInputField({
                icon: MapPin,
                label: "City",
                field: "city",
                required: true,
                placeholder: "New York"
              })}
              {renderInputField({
                icon: MapPin,
                label: "Postal Code",
                field: "postal_code",
                required: true,
                placeholder: "10001"
              })}
              {renderInputField({
                icon: MapPin,
                label: "Country",
                field: "country",
                required: true,
                placeholder: "United States"
              })}
            </div>
          </div>

          {/* Tax Information Section */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-white border-b border-gray-700 pb-2">
              Tax Information
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {renderInputField({
                icon: CreditCard,
                label: "Tax ID",
                field: "tax_id",
                placeholder: "12-3456789"
              })}
              {renderInputField({
                icon: CreditCard,
                label: "VAT Number",
                field: "vat_number",
                required: !noVatBusiness,
                placeholder: "GB123456789"
              })}
            </div>
            <div className="flex items-center space-x-2">
              <input
                type="checkbox"
                id="no_vat_business"
                checked={noVatBusiness}
                onChange={(e) => setNoVatBusiness(e.target.checked)}
                className="w-4 h-4 text-blue-600 bg-gray-800 border-gray-600 rounded focus:ring-blue-500"
              />
              <Label htmlFor="no_vat_business" className="text-sm text-gray-200">
                Business with no VAT number
              </Label>
            </div>
            {errors.vat_number && (
              <p className="text-sm text-red-400 flex items-center gap-1">
                <AlertCircle className="h-3 w-3" />
                {errors.vat_number}
              </p>
            )}
          </div>

          {/* Data Processing Notice */}
          <Alert className="bg-blue-900/30 border-blue-700">
            <AlertCircle className="h-4 w-4 text-blue-400" />
            <AlertDescription className="text-blue-200">
              Your information will be used for billing, compliance, and service delivery purposes. 
              We follow strict data protection standards and will never share your data with third parties.
            </AlertDescription>
          </Alert>

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row gap-3 pt-4">
            <Button
              type="submit"
              disabled={isLoading}
              className="flex-1 bg-blue-600 hover:bg-blue-700 text-white font-medium py-3"
            >
              {isLoading ? (
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  Processing...
                </div>
              ) : (
                'Continue with Payment'
              )}
            </Button>
            <Button
              type="button"
              variant="outline"
              onClick={onCancel}
              disabled={isLoading}
              className="border-gray-600 text-gray-300 hover:bg-gray-800 hover:text-white"
            >
              Cancel
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
};

export default CustomerOnboardingForm;
export type { Props as CustomerOnboardingFormProps };