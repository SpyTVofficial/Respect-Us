import React, { useState, useEffect } from 'react';
import brain from 'brain';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { TreePine, FileText, Plus, Edit, Trash2, Target, AlertTriangle, Settings, Copy, FileCheck, Play, CheckCircle } from 'lucide-react';
import { toast } from 'sonner';
import { Checkbox } from '@/components/ui/checkbox';

// Define types for sanctions data
interface SanctionsTree {
  id: string;
  name: string;
  description: string;
  jurisdiction: string;
  category: string;
  version: string;
  status: string;
  created_by: string;
  created_at: string;
  updated_at: string;
  published_at?: string;
  introduction_tree_id?: string;
  is_introduction_template: boolean;
}

interface SanctionsNode {
  id: string;
  tree_id: string;
  node_key: string;
  title: string;
  description: string;
  question_text?: string;
  question_type?: string;
  parent_node_id?: string;
  display_order: number;
  is_root: boolean;
  notes?: string;
  metadata?: any;
  created_at: string;
  updated_at: string;
  children: SanctionsNode[];
}

interface SanctionsNodeOption {
  id: string;
  node_id: string;
  option_text: string;
  option_value: string;
  routing_rule?: string | null;
  regulatory_notes?: string | null;
  display_order: number;
  note?: string | null;
  created_at: string;
  updated_at: string;
}

// Workflow interfaces
interface WorkflowTemplate {
  id: string;
  name: string;
  description: string;
  category: string;
  is_published: boolean;
  created_at: string;
  updated_at: string;
  steps?: WorkflowStep[];
}

interface WorkflowStep {
  id: string;
  name: string;
  description: string;
  step_type: string;
  configuration: any;
  order_index: number;
}

interface WorkflowExecution {
  id: string;
  workflow_id: string;
  status: 'pending' | 'in_progress' | 'completed' | 'failed';
  current_step: number;
  results: any;
  created_at: string;
}

const SanctionsTreeManagement: React.FC = () => {
  const [activeTab, setActiveTab] = useState('trees');
  const [sanctionsTrees, setSanctionsTrees] = useState<SanctionsTree[]>([]);
  const [selectedTree, setSelectedTree] = useState<SanctionsTree | null>(null);
  const [treeNodes, setTreeNodes] = useState<SanctionsNode[]>([]);
  const [loading, setLoading] = useState(true);

  // Tree management dialogs
  const [showCreateTreeDialog, setShowCreateTreeDialog] = useState(false);
  const [showEditTreeDialog, setShowEditTreeDialog] = useState(false);
  const [editingTree, setEditingTree] = useState<SanctionsTree | null>(null);
  const [creatingTree, setCreatingTree] = useState(false);
  const [updatingTree, setUpdatingTree] = useState(false);
  
  // Tree form data
  const [newTreeData, setNewTreeData] = useState({
    name: '',
    description: '',
    jurisdiction: '',
    category: '',
    version: ''
  });
  
  const [editTreeData, setEditTreeData] = useState({
    name: '',
    description: '',
    jurisdiction: '',
    category: '',
    version: ''
  });

  // Node management dialogs
  const [showCreateNodeDialog, setShowCreateNodeDialog] = useState(false);
  const [showEditNodeDialog, setShowEditNodeDialog] = useState(false);
  const [editingNode, setEditingNode] = useState<SanctionsNode | null>(null);
  const [creatingNode, setCreatingNode] = useState(false);
  const [updatingNode, setUpdatingNode] = useState(false);
  
  // Node form data
  const [newNodeData, setNewNodeData] = useState({
    node_key: '',
    title: '',
    description: '',
    question_text: '',
    question_type: 'multiple_choice',
    parent_node_id: null as string | null,
    display_order: 0,
    is_root: false,
    notes: ''
  });
  
  const [editNodeData, setEditNodeData] = useState({
    node_key: '',
    title: '',
    description: '',
    question_text: '',
    question_type: 'multiple_choice',
    parent_node_id: null as string | null,
    display_order: 0,
    is_root: false,
    notes: ''
  });

  // Options management
  const [isManageOptionsOpen, setIsManageOptionsOpen] = useState(false);
  const [managingOptionsForNode, setManagingOptionsForNode] = useState<SanctionsNode | null>(null);
  const [isCreateOptionOpen, setIsCreateOptionOpen] = useState(false);
  const [isEditOptionOpen, setIsEditOptionOpen] = useState(false);
  const [editingOption, setEditingOption] = useState<SanctionsNodeOption | null>(null);
  const [nodeOptions, setNodeOptions] = useState<Record<string, SanctionsNodeOption[]>>({});
  const [newOptionData, setNewOptionData] = useState({
    option_text: '',
    option_value: '',
    routing_rule: '',
    regulatory_notes: '',
    display_order: 0,
    note: ''
  });

  // Workflow management
  const [availableWorkflows, setAvailableWorkflows] = useState<WorkflowTemplate[]>([]);
  const [selectedWorkflow, setSelectedWorkflow] = useState<WorkflowTemplate | null>(null);
  const [workflowExecutions, setWorkflowExecutions] = useState<WorkflowExecution[]>([]);
  const [loadingWorkflows, setLoadingWorkflows] = useState(false);
  const [executingWorkflow, setExecutingWorkflow] = useState(false);

  // Workflow execution dialog
  const [showWorkflowDialog, setShowWorkflowDialog] = useState(false);
  const [workflowProgress, setWorkflowProgress] = useState(0);
  const [workflowResults, setWorkflowResults] = useState<any>(null);

  // Add workflow creation dialog state
  const [showCreateWorkflowDialog, setShowCreateWorkflowDialog] = useState(false);
  const [creatingWorkflow, setCreatingWorkflow] = useState(false);
  const [newWorkflowData, setNewWorkflowData] = useState({
    name: '',
    description: '',
    category: 'sanctions',
    steps: [] as any[]
  });

  useEffect(() => {
    loadSanctionsTrees();
  }, []);

  // Load available workflows when workflows tab is accessed
  useEffect(() => {
    if (activeTab === 'workflows') {
      loadAvailableWorkflows();
    }
  }, [activeTab]);

  const loadSanctionsTrees = async () => {
    try {
      setLoading(true);
      const response = await brain.list_sanctions_trees();
      if (response.ok) {
        const trees = await response.json();
        setSanctionsTrees(trees);
      } else {
        toast.error('Failed to load sanctions trees');
      }
    } catch (error) {
      console.error('Error loading sanctions trees:', error);
      toast.error('Failed to load sanctions trees');
    } finally {
      setLoading(false);
    }
  };

  const loadTreeNodes = async (treeId: string) => {
    try {
      const response = await brain.list_sanctions_nodes({ treeId });
      if (response.ok) {
        const nodes = await response.json();
        setTreeNodes(nodes);
      } else {
        toast.error('Failed to load tree nodes');
      }
    } catch (error) {
      console.error('Error loading tree nodes:', error);
      toast.error('Failed to load tree nodes');
    }
  };

  const loadNodeOptions = async (nodeId: string) => {
    if (!selectedTree) return;
    
    try {
      const response = await brain.list_sanctions_node_options({ 
        treeId: selectedTree.id, 
        nodeId: nodeId 
      });
      if (response.ok) {
        const options = await response.json();
        setNodeOptions(prev => ({ ...prev, [nodeId]: options }));
      }
    } catch (error) {
      console.error(`Error loading options for node ${nodeId}:`, error);
    }
  };

  const handleCreateTree = async () => {
    try {
      setCreatingTree(true);
      const response = await brain.create_sanctions_tree(newTreeData);
      if (response.ok) {
        toast.success('Sanctions tree created successfully');
        setShowCreateTreeDialog(false);
        setNewTreeData({ name: '', description: '', jurisdiction: '', category: '', version: '' });
        await loadSanctionsTrees();
      } else {
        toast.error('Failed to create sanctions tree');
      }
    } catch (error) {
      console.error('Error creating tree:', error);
      toast.error('Failed to create sanctions tree');
    } finally {
      setCreatingTree(false);
    }
  };

  const handleEditTree = (tree: SanctionsTree) => {
    setEditingTree(tree);
    setEditTreeData({
      name: tree.name,
      description: tree.description,
      jurisdiction: tree.jurisdiction,
      category: tree.category,
      version: tree.version
    });
    setShowEditTreeDialog(true);
  };

  const handleUpdateTree = async () => {
    if (!editingTree) return;
    
    try {
      setUpdatingTree(true);
      const response = await brain.update_sanctions_tree({ treeId: editingTree.id }, editTreeData);
      if (response.ok) {
        toast.success('Sanctions tree updated successfully');
        setShowEditTreeDialog(false);
        setEditingTree(null);
        await loadSanctionsTrees();
      } else {
        toast.error('Failed to update sanctions tree');
      }
    } catch (error) {
      console.error('Error updating tree:', error);
      toast.error('Failed to update sanctions tree');
    } finally {
      setUpdatingTree(false);
    }
  };

  const handleDeleteTree = async (tree: SanctionsTree) => {
    if (!confirm(`Are you sure you want to delete "${tree.name}"?`)) return;
    
    try {
      const response = await brain.delete_sanctions_tree({ treeId: tree.id });
      if (response.ok) {
        toast.success('Sanctions tree deleted successfully');
        if (selectedTree?.id === tree.id) {
          setSelectedTree(null);
          setTreeNodes([]);
        }
        await loadSanctionsTrees();
      } else {
        toast.error('Failed to delete sanctions tree');
      }
    } catch (error) {
      console.error('Error deleting tree:', error);
      toast.error('Failed to delete sanctions tree');
    }
  };

  const handleSelectTree = (tree: SanctionsTree) => {
    setSelectedTree(tree);
    setActiveTab('nodes');
    loadTreeNodes(tree.id);
  };

  const handleCreateNode = async () => {
    if (!selectedTree) return;
    
    try {
      setCreatingNode(true);
      const response = await brain.create_sanctions_node({ treeId: selectedTree.id }, newNodeData);
      if (response.ok) {
        toast.success('Sanctions node created successfully');
        setShowCreateNodeDialog(false);
        setNewNodeData({
          node_key: '',
          title: '',
          description: '',
          question_text: '',
          question_type: 'multiple_choice',
          parent_node_id: null,
          display_order: 0,
          is_root: false,
          notes: ''
        });
        await loadTreeNodes(selectedTree.id);
      } else {
        toast.error('Failed to create sanctions node');
      }
    } catch (error) {
      console.error('Error creating node:', error);
      toast.error('Failed to create sanctions node');
    } finally {
      setCreatingNode(false);
    }
  };

  const handleEditNode = (node: SanctionsNode) => {
    setEditingNode(node);
    setEditNodeData({
      node_key: node.node_key,
      title: node.title,
      description: node.description,
      question_text: node.question_text || '',
      question_type: node.question_type || 'multiple_choice',
      parent_node_id: node.parent_node_id,
      display_order: node.display_order,
      is_root: node.is_root,
      notes: node.notes || ''
    });
    setShowEditNodeDialog(true);
  };

  const handleUpdateNode = async () => {
    if (!selectedTree || !editingNode) return;
    
    try {
      setUpdatingNode(true);
      const response = await brain.update_sanctions_node({ 
        treeId: selectedTree.id, 
        nodeId: editingNode.id 
      }, editNodeData);
      if (response.ok) {
        toast.success('Sanctions node updated successfully');
        setShowEditNodeDialog(false);
        setEditingNode(null);
        await loadTreeNodes(selectedTree.id);
      } else {
        toast.error('Failed to update sanctions node');
      }
    } catch (error) {
      console.error('Error updating node:', error);
      toast.error('Failed to update sanctions node');
    } finally {
      setUpdatingNode(false);
    }
  };

  const handleDeleteNode = async (node: SanctionsNode) => {
    if (!selectedTree || !confirm(`Are you sure you want to delete "${node.title}"?`)) return;
    
    try {
      const response = await brain.delete_sanctions_node({ treeId: selectedTree.id, nodeId: node.id });
      if (response.ok) {
        toast.success('Sanctions node deleted successfully');
        await loadTreeNodes(selectedTree.id);
      } else {
        toast.error('Failed to delete sanctions node');
      }
    } catch (error) {
      console.error('Error deleting node:', error);
      toast.error('Failed to delete sanctions node');
    }
  };

  const handleManageOptions = (node: SanctionsNode, e: React.MouseEvent) => {
    e.stopPropagation();
    setManagingOptionsForNode(node);
    setIsManageOptionsOpen(true);
    loadNodeOptions(node.id);
  };

  const handleDuplicateNode = async (node: SanctionsNode, e: React.MouseEvent) => {
    e.stopPropagation();
    try {
      const newNodeData = {
        node_key: `${node.node_key}_copy`,
        title: `${node.title} (Copy)`,
        description: node.description || '',
        question_text: node.question_text || '',
        question_type: node.question_type || 'multiple_choice',
        is_root: false,
        parent_node_id: node.parent_node_id,
        display_order: 0,
        notes: node.notes || ''
      };
      
      const duplicateResponse = await brain.create_sanctions_node({
        treeId: selectedTree!.id
      }, newNodeData);
      
      if (duplicateResponse.ok) {
        toast.success('Node duplicated successfully');
        if (selectedTree) {
          await loadTreeNodes(selectedTree.id);
        }
      } else {
        throw new Error('Failed to duplicate node');
      }
    } catch (error) {
      console.error('Error duplicating node:', error);
      toast.error('Failed to duplicate node');
    }
  };

  const loadAvailableWorkflows = async () => {
    try {
      setLoadingWorkflows(true);
      const response = await brain.list_workflows();
      if (response.ok) {
        const workflows = await response.json();
        setAvailableWorkflows(workflows);
      } else {
        toast.error('Failed to load workflows');
      }
    } catch (error) {
      console.error('Error loading workflows:', error);
      toast.error('Failed to load workflows');
    } finally {
      setLoadingWorkflows(false);
    }
  };

  const handleExecuteWorkflow = async (workflow: WorkflowTemplate) => {
    if (!selectedTree) return;
    
    try {
      setExecutingWorkflow(true);
      const response = await brain.execute_workflow({ 
        treeId: selectedTree.id, 
        workflowId: workflow.id 
      });
      if (response.ok) {
        const execution = await response.json();
        setWorkflowExecutions(prev => [...prev, execution]);
        setWorkflowProgress(execution.current_step);
        setWorkflowResults(execution.results);
        setShowWorkflowDialog(true);
      } else {
        toast.error('Failed to execute workflow');
      }
    } catch (error) {
      console.error('Error executing workflow:', error);
      toast.error('Failed to execute workflow');
    } finally {
      setExecutingWorkflow(false);
    }
  };

  const handleCreateWorkflow = async () => {
    try {
      setCreatingWorkflow(true);
      const response = await brain.create_workflow(newWorkflowData);
      if (response.ok) {
        toast.success('Workflow created successfully');
        setShowCreateWorkflowDialog(false);
        setNewWorkflowData({
          name: '',
          description: '',
          category: 'sanctions',
          steps: [] as any[]
        });
        loadAvailableWorkflows();
      } else {
        toast.error('Failed to create workflow');
      }
    } catch (error) {
      console.error('Error creating workflow:', error);
      toast.error('Failed to create workflow');
    } finally {
      setCreatingWorkflow(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-gray-800/30 backdrop-blur-sm border border-gray-700 rounded-lg p-6">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-xl font-semibold text-white mb-2">Sanctions & Embargoes Management</h2>
            <p className="text-gray-400">Manage sanctions trees and nodes for compliance screening</p>
          </div>
          <Button
            onClick={() => setShowCreateTreeDialog(true)}
            className="bg-amber-600 hover:bg-amber-700 text-white"
          >
            <Plus className="w-4 h-4 mr-2" />
            Create Sanctions Tree
          </Button>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-3 bg-gray-700/50">
            <TabsTrigger value="trees" className="data-[state=active]:bg-amber-600">
              <TreePine className="w-4 h-4 mr-2" />
              Sanctions Trees
            </TabsTrigger>
            <TabsTrigger value="nodes" className="data-[state=active]:bg-amber-600" disabled={!selectedTree}>
              <Target className="w-4 h-4 mr-2" />
              Tree Nodes
            </TabsTrigger>
            <TabsTrigger value="workflows" className="data-[state=active]:bg-purple-600">
              <FileCheck className="w-4 h-4 mr-2" />
              Workflows
            </TabsTrigger>
          </TabsList>

          <TabsContent value="trees" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {sanctionsTrees.map((tree) => (
                <Card 
                  key={tree.id} 
                  className="bg-gray-800/50 border-gray-600 hover:border-amber-500 transition-colors cursor-pointer"
                  onClick={() => handleSelectTree(tree)}
                >
                  <CardHeader className="pb-3">
                    <CardTitle className="text-white text-lg flex items-center gap-2">
                      <TreePine className="h-5 w-5 text-amber-400" />
                      {tree.name}
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <p className="text-gray-400 text-sm">{tree.description}</p>
                    <div className="flex justify-between text-xs text-gray-500">
                      <span>{tree.jurisdiction}</span>
                      <span>{tree.category}</span>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleEditTree(tree);
                        }}
                        className="text-gray-400 hover:text-white"
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleDeleteTree(tree);
                        }}
                        className="text-gray-400 hover:text-red-400"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="nodes" className="space-y-4">
            {selectedTree && (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-lg font-semibold text-white">{selectedTree.name} - Nodes</h3>
                    <p className="text-gray-400 text-sm">{selectedTree.description}</p>
                  </div>
                  <Button
                    onClick={() => setShowCreateNodeDialog(true)}
                    className="bg-green-600 hover:bg-green-700 text-white"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Add Node
                  </Button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {treeNodes.map((node) => (
                    <Card key={node.id} className="bg-gray-800/50 border-gray-600">
                      <CardHeader className="pb-3">
                        <CardTitle className="text-white text-base flex items-center gap-2">
                          <Target className="h-4 w-4 text-green-400" />
                          {node.title}
                          {node.is_root && (
                            <span className="text-xs bg-blue-600 text-white px-2 py-1 rounded">ROOT</span>
                          )}
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-3">
                        <p className="text-gray-400 text-sm">{node.description}</p>
                        <div className="flex justify-between text-xs text-gray-500">
                          <span>Key: {node.node_key}</span>
                          <span>Order: {node.display_order}</span>
                        </div>
                        <div className="flex gap-2">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleEditNode(node)}
                            className="text-gray-400 hover:text-white"
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={(e) => handleManageOptions(node, e)}
                            className="text-gray-400 hover:text-white"
                          >
                            <Settings className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={(e) => handleDuplicateNode(node, e)}
                            className="text-gray-400 hover:text-white"
                          >
                            <Copy className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleDeleteNode(node)}
                            className="text-gray-400 hover:text-red-400"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            )}
          </TabsContent>

          <TabsContent value="workflows" className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-lg font-semibold text-white">Available Workflows</h3>
                <p className="text-gray-400 text-sm">Browse and execute sanctions workflows</p>
              </div>
              <Button
                onClick={() => {
                  // Navigate to workflow creation or open creation dialog
                  toast.info('Workflow creation coming soon');
                }}
                className="bg-purple-600 hover:bg-purple-700 text-white"
              >
                <Plus className="w-4 h-4 mr-2" />
                Create Workflow
              </Button>
            </div>
            
            {availableWorkflows.length > 0 ? (
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {availableWorkflows.map((workflow) => (
                    <Card key={workflow.id} className="bg-gray-800/50 border-gray-600">
                      <CardHeader className="pb-3">
                        <CardTitle className="text-white text-base flex items-center gap-2">
                          <FileCheck className="h-4 w-4 text-purple-400" />
                          {workflow.name}
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-3">
                        <p className="text-gray-400 text-sm">{workflow.description}</p>
                        <div className="flex justify-between text-xs text-gray-500">
                          <span>Category: {workflow.category}</span>
                          <span>Published: {workflow.is_published ? 'Yes' : 'No'}</span>
                        </div>
                        <div className="flex gap-2">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => {
                              setSelectedWorkflow(workflow);
                              setShowWorkflowDialog(true);
                            }}
                            className="text-gray-400 hover:text-white"
                          >
                            <Play className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleExecuteWorkflow(workflow)}
                            disabled={executingWorkflow || !selectedTree}
                            className="text-purple-400 hover:text-purple-300"
                          >
                            {executingWorkflow ? (
                              <span className="text-xs">Running...</span>
                            ) : (
                              <CheckCircle className="h-4 w-4" />
                            )}
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            ) : (
              <div className="flex items-center justify-center">
                <p className="text-gray-400 text-sm">No workflows available</p>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>

      {/* Create Tree Dialog */}
      <Dialog open={showCreateTreeDialog} onOpenChange={setShowCreateTreeDialog}>
        <DialogContent className="bg-gray-800 border-gray-600 text-white max-w-md">
          <DialogHeader>
            <DialogTitle>Create Sanctions Tree</DialogTitle>
            <DialogDescription>Create a new sanctions tree for compliance screening</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="name">Tree Name</Label>
              <Input
                id="name"
                value={newTreeData.name}
                onChange={(e) => setNewTreeData(prev => ({ ...prev, name: e.target.value }))}
                className="bg-gray-700 border-gray-600 text-white"
                placeholder="e.g., EU Sanctions Framework"
              />
            </div>
            <div>
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                value={newTreeData.description}
                onChange={(e) => setNewTreeData(prev => ({ ...prev, description: e.target.value }))}
                className="bg-gray-700 border-gray-600 text-white"
                placeholder="Describe the purpose and scope of this sanctions tree"
              />
            </div>
            <div>
              <Label htmlFor="jurisdiction">Jurisdiction</Label>
              <Input
                id="jurisdiction"
                value={newTreeData.jurisdiction}
                onChange={(e) => setNewTreeData(prev => ({ ...prev, jurisdiction: e.target.value }))}
                className="bg-gray-700 border-gray-600 text-white"
                placeholder="e.g., EU, US, UK"
              />
            </div>
            <div>
              <Label htmlFor="category">Category</Label>
              <Input
                id="category"
                value={newTreeData.category}
                onChange={(e) => setNewTreeData(prev => ({ ...prev, category: e.target.value }))}
                className="bg-gray-700 border-gray-600 text-white"
                placeholder="e.g., Economic Sanctions, Trade Embargoes"
              />
            </div>
            <div>
              <Label htmlFor="version">Version</Label>
              <Input
                id="version"
                value={newTreeData.version}
                onChange={(e) => setNewTreeData(prev => ({ ...prev, version: e.target.value }))}
                className="bg-gray-700 border-gray-600 text-white"
                placeholder="e.g., 1.0"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowCreateTreeDialog(false)}>
              Cancel
            </Button>
            <Button
              onClick={handleCreateTree}
              disabled={creatingTree || !newTreeData.name.trim()}
              className="bg-amber-600 hover:bg-amber-700 text-white"
            >
              {creatingTree ? 'Creating...' : 'Create Tree'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Tree Dialog */}
      <Dialog open={showEditTreeDialog} onOpenChange={setShowEditTreeDialog}>
        <DialogContent className="bg-gray-800 border-gray-600 text-white max-w-md">
          <DialogHeader>
            <DialogTitle>Edit Sanctions Tree</DialogTitle>
            <DialogDescription>Update the sanctions tree details</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="edit-name">Tree Name</Label>
              <Input
                id="edit-name"
                value={editTreeData.name}
                onChange={(e) => setEditTreeData(prev => ({ ...prev, name: e.target.value }))}
                className="bg-gray-700 border-gray-600 text-white"
              />
            </div>
            <div>
              <Label htmlFor="edit-description">Description</Label>
              <Textarea
                id="edit-description"
                value={editTreeData.description}
                onChange={(e) => setEditTreeData(prev => ({ ...prev, description: e.target.value }))}
                className="bg-gray-700 border-gray-600 text-white"
              />
            </div>
            <div>
              <Label htmlFor="edit-jurisdiction">Jurisdiction</Label>
              <Input
                id="edit-jurisdiction"
                value={editTreeData.jurisdiction}
                onChange={(e) => setEditTreeData(prev => ({ ...prev, jurisdiction: e.target.value }))}
                className="bg-gray-700 border-gray-600 text-white"
              />
            </div>
            <div>
              <Label htmlFor="edit-category">Category</Label>
              <Input
                id="edit-category"
                value={editTreeData.category}
                onChange={(e) => setEditTreeData(prev => ({ ...prev, category: e.target.value }))}
                className="bg-gray-700 border-gray-600 text-white"
              />
            </div>
            <div>
              <Label htmlFor="edit-version">Version</Label>
              <Input
                id="edit-version"
                value={editTreeData.version}
                onChange={(e) => setEditTreeData(prev => ({ ...prev, version: e.target.value }))}
                className="bg-gray-700 border-gray-600 text-white"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowEditTreeDialog(false)}>
              Cancel
            </Button>
            <Button
              onClick={handleUpdateTree}
              disabled={updatingTree || !editTreeData.name.trim()}
              className="bg-amber-600 hover:bg-amber-700 text-white"
            >
              {updatingTree ? 'Updating...' : 'Update Tree'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Create Node Dialog */}
      <Dialog open={showCreateNodeDialog} onOpenChange={setShowCreateNodeDialog}>
        <DialogContent className="bg-gray-800 border-gray-600 text-white max-w-lg">
          <DialogHeader>
            <DialogTitle>Create Sanctions Node</DialogTitle>
            <DialogDescription>Add a new node to the sanctions tree</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="node-key">Node Key</Label>
              <Input
                id="node-key"
                value={newNodeData.node_key}
                onChange={(e) => setNewNodeData(prev => ({ ...prev, node_key: e.target.value }))}
                className="bg-gray-700 border-gray-600 text-white"
                placeholder="e.g., SANCTIONS_001"
              />
            </div>
            <div>
              <Label htmlFor="node-title">Title</Label>
              <Input
                id="node-title"
                value={newNodeData.title}
                onChange={(e) => setNewNodeData(prev => ({ ...prev, title: e.target.value }))}
                className="bg-gray-700 border-gray-600 text-white"
                placeholder="e.g., Country Sanctions Check"
              />
            </div>
            <div>
              <Label htmlFor="node-description">Description</Label>
              <Textarea
                id="node-description"
                value={newNodeData.description}
                onChange={(e) => setNewNodeData(prev => ({ ...prev, description: e.target.value }))}
                className="bg-gray-700 border-gray-600 text-white"
                placeholder="Describe what this node checks for"
              />
            </div>
            <div>
              <Label htmlFor="question-text">Question Text</Label>
              <Textarea
                id="question-text"
                value={newNodeData.question_text}
                onChange={(e) => setNewNodeData(prev => ({ ...prev, question_text: e.target.value }))}
                className="bg-gray-700 border-gray-600 text-white"
                placeholder="e.g., Which country is the transaction destined for?"
              />
            </div>
            <div>
              <Label htmlFor="question-type">Question Type</Label>
              <Select
                value={newNodeData.question_type}
                onValueChange={(value) => setNewNodeData(prev => ({ ...prev, question_type: value }))}
              >
                <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-gray-700 border-gray-600">
                  <SelectItem value="multiple_choice">Multiple Choice</SelectItem>
                  <SelectItem value="text">Text Input</SelectItem>
                  <SelectItem value="boolean">Yes/No</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-center space-x-2">
              <Checkbox
                id="is-root"
                checked={newNodeData.is_root}
                onCheckedChange={(checked) => setNewNodeData(prev => ({ ...prev, is_root: !!checked }))}
              />
              <Label htmlFor="is-root">Root Node</Label>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowCreateNodeDialog(false)}>
              Cancel
            </Button>
            <Button
              onClick={handleCreateNode}
              disabled={creatingNode || !newNodeData.node_key.trim() || !newNodeData.title.trim()}
              className="bg-green-600 hover:bg-green-700 text-white"
            >
              {creatingNode ? 'Creating...' : 'Create Node'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Node Dialog */}
      <Dialog open={showEditNodeDialog} onOpenChange={setShowEditNodeDialog}>
        <DialogContent className="bg-gray-800 border-gray-600 text-white max-w-lg">
          <DialogHeader>
            <DialogTitle>Edit Sanctions Node</DialogTitle>
            <DialogDescription>Update the sanctions node details</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="edit-node-key">Node Key</Label>
              <Input
                id="edit-node-key"
                value={editNodeData.node_key}
                onChange={(e) => setEditNodeData(prev => ({ ...prev, node_key: e.target.value }))}
                className="bg-gray-700 border-gray-600 text-white"
              />
            </div>
            <div>
              <Label htmlFor="edit-node-title">Title</Label>
              <Input
                id="edit-node-title"
                value={editNodeData.title}
                onChange={(e) => setEditNodeData(prev => ({ ...prev, title: e.target.value }))}
                className="bg-gray-700 border-gray-600 text-white"
              />
            </div>
            <div>
              <Label htmlFor="edit-display-order">Order</Label>
              <Input
                id="edit-display-order"
                type="number"
                value={editNodeData.display_order}
                onChange={(e) => setEditNodeData(prev => ({ ...prev, display_order: parseInt(e.target.value) || 0 }))}
                className="bg-gray-700 border-gray-600 text-white"
              />
            </div>
            <div>
              <Label htmlFor="edit-node-description">Description</Label>
              <Textarea
                id="edit-node-description"
                value={editNodeData.description}
                onChange={(e) => setEditNodeData(prev => ({ ...prev, description: e.target.value }))}
                className="bg-gray-700 border-gray-600 text-white"
              />
            </div>
            <div>
              <Label htmlFor="edit-question-text">Question Text</Label>
              <Textarea
                id="edit-question-text"
                value={editNodeData.question_text}
                onChange={(e) => setEditNodeData(prev => ({ ...prev, question_text: e.target.value }))}
                className="bg-gray-700 border-gray-600 text-white"
              />
            </div>
            <div>
              <Label htmlFor="edit-question-type">Question Type</Label>
              <Select
                value={editNodeData.question_type}
                onValueChange={(value) => setEditNodeData(prev => ({ ...prev, question_type: value }))}
              >
                <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-gray-700 border-gray-600">
                  <SelectItem value="multiple_choice">Multiple Choice</SelectItem>
                  <SelectItem value="text">Text Input</SelectItem>
                  <SelectItem value="boolean">Yes/No</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-center space-x-2">
              <Checkbox
                id="edit-is-root"
                checked={editNodeData.is_root}
                onCheckedChange={(checked) => setEditNodeData(prev => ({ ...prev, is_root: !!checked }))}
              />
              <Label htmlFor="edit-is-root">Root Node</Label>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowEditNodeDialog(false)}>
              Cancel
            </Button>
            <Button
              onClick={handleUpdateNode}
              disabled={updatingNode || !editNodeData.node_key.trim() || !editNodeData.title.trim()}
              className="bg-green-600 hover:bg-green-700 text-white"
            >
              {updatingNode ? 'Updating...' : 'Update Node'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Manage Options Dialog */}
      <Dialog open={isManageOptionsOpen} onOpenChange={setIsManageOptionsOpen}>
        <DialogContent className="bg-gray-800 border-gray-600 text-white max-w-4xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Manage Options - {managingOptionsForNode?.title}</DialogTitle>
            <DialogDescription>
              Configure options and routing rules for this sanctions node
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-6">
            {/* Existing Options */}
            {managingOptionsForNode && nodeOptions[managingOptionsForNode.id] && nodeOptions[managingOptionsForNode.id].length > 0 && (
              <div>
                <h4 className="text-sm font-medium text-gray-300 mb-3">Existing Options</h4>
                <div className="space-y-2">
                  {nodeOptions[managingOptionsForNode.id].map((option) => (
                    <div key={option.id} className="flex items-center justify-between p-3 bg-gray-700/50 rounded border border-gray-600">
                      <div className="flex-1">
                        <div className="font-medium text-white">{option.option_text}</div>
                        <div className="text-sm text-gray-400">Value: {option.option_value}</div>
                        {option.routing_rule && (
                          <div className="text-sm text-gray-400">Route: {option.routing_rule}</div>
                        )}
                      </div>
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => {
                            setEditingOption(option);
                            setIsEditOptionOpen(true);
                          }}
                          className="border-gray-600 text-gray-300 hover:bg-gray-600"
                        >
                          <Edit className="h-3 w-3" />
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => {
                            // Duplicate the option by pre-filling the new option form
                            setNewOptionData({
                              option_text: `${option.option_text} (Copy)`,
                              option_value: option.option_value,
                              routing_rule: option.routing_rule || '',
                              regulatory_notes: option.regulatory_notes || '',
                              display_order: (nodeOptions[managingOptionsForNode!.id]?.length || 0) + 1,
                              note: option.note || ''
                            });
                            toast.success('Option duplicated - modify and save below');
                          }}
                          className="border-green-600 text-green-400 hover:bg-green-900/20"
                          title="Duplicate Option"
                        >
                          <Copy className="h-3 w-3" />
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={async () => {
                            if (confirm('Delete this option?')) {
                              try {
                                const response = await brain.delete_sanctions_node_option({
                                  treeId: selectedTree!.id,
                                  nodeId: managingOptionsForNode.id,
                                  optionId: option.id
                                });
                                if (response.ok) {
                                  toast.success('Option deleted successfully');
                                  loadNodeOptions(managingOptionsForNode.id);
                                }
                              } catch (error) {
                                toast.error('Failed to delete option');
                              }
                            }
                          }}
                          className="border-red-600 text-red-400 hover:bg-red-900/20"
                        >
                          <Trash2 className="h-3 w-3" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
            
            {/* Add New Option Form */}
            <div>
              <h4 className="text-sm font-medium text-gray-300 mb-3">Add New Option</h4>
              <div className="space-y-4 p-4 bg-gray-700/30 rounded border border-gray-600">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="option-text">Option Text</Label>
                    <Input
                      id="option-text"
                      value={newOptionData.option_text}
                      onChange={(e) => setNewOptionData(prev => ({ ...prev, option_text: e.target.value }))}
                      className="bg-gray-700 border-gray-600 text-white"
                      placeholder="e.g., High Risk Country"
                    />
                  </div>
                  <div>
                    <Label htmlFor="option-value">Option Value</Label>
                    <Input
                      id="option-value"
                      value={newOptionData.option_value}
                      onChange={(e) => setNewOptionData(prev => ({ ...prev, option_value: e.target.value }))}
                      className="bg-gray-700 border-gray-600 text-white"
                      placeholder="e.g., high_risk"
                    />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="routing-rule">Routing Rule (Optional)</Label>
                    <Input
                      id="routing-rule"
                      value={newOptionData.routing_rule}
                      onChange={(e) => setNewOptionData(prev => ({ ...prev, routing_rule: e.target.value }))}
                      className="bg-gray-700 border-gray-600 text-white"
                      placeholder="e.g., next_node_key or outcome_code"
                    />
                  </div>
                  <div>
                    <Label htmlFor="display-order">Display Order</Label>
                    <Input
                      id="display-order"
                      type="number"
                      value={newOptionData.display_order}
                      onChange={(e) => setNewOptionData(prev => ({ ...prev, display_order: parseInt(e.target.value) || 0 }))}
                      className="bg-gray-700 border-gray-600 text-white"
                      placeholder="0"
                      min="0"
                    />
                  </div>
                </div>
                <div>
                  <Label htmlFor="regulatory-notes">Regulatory Notes (Optional)</Label>
                  <Textarea
                    id="regulatory-notes"
                    value={newOptionData.regulatory_notes}
                    onChange={(e) => setNewOptionData(prev => ({ ...prev, regulatory_notes: e.target.value }))}
                    className="bg-gray-700 border-gray-600 text-white"
                    placeholder="Additional regulatory context or guidance"
                  />
                </div>
                <Button
                  onClick={async () => {
                    if (!selectedTree || !managingOptionsForNode) return;
                    
                    try {
                      const response = await brain.create_sanctions_node_option({
                        treeId: selectedTree.id,
                        nodeId: managingOptionsForNode.id
                      }, newOptionData);
                      
                      if (response.ok) {
                        toast.success('Option added successfully');
                        setNewOptionData({
                          option_text: '',
                          option_value: '',
                          routing_rule: '',
                          regulatory_notes: '',
                          display_order: 0,
                          note: ''
                        });
                        loadNodeOptions(managingOptionsForNode.id);
                      } else {
                        toast.error('Failed to add option');
                      }
                    } catch (error) {
                      console.error('Error adding option:', error);
                      toast.error('Failed to add option');
                    }
                  }}
                  disabled={!newOptionData.option_text.trim() || !newOptionData.option_value.trim()}
                  className="bg-green-600 hover:bg-green-700 text-white"
                >
                  Add Option
                </Button>
              </div>
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsManageOptionsOpen(false)}>
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Option Dialog */}
      <Dialog open={isEditOptionOpen} onOpenChange={setIsEditOptionOpen}>
        <DialogContent className="bg-gray-800 border-gray-600 text-white max-w-md">
          <DialogHeader>
            <DialogTitle>Edit Option</DialogTitle>
            <DialogDescription>Update the option details</DialogDescription>
          </DialogHeader>
          {editingOption && (
            <div className="space-y-4">
              <div>
                <Label htmlFor="edit-option-text">Option Text</Label>
                <Input
                  id="edit-option-text"
                  value={editingOption.option_text}
                  onChange={(e) => setEditingOption(prev => prev ? { ...prev, option_text: e.target.value } : null)}
                  className="bg-gray-700 border-gray-600 text-white"
                />
              </div>
              <div>
                <Label htmlFor="edit-option-value">Option Value</Label>
                <Input
                  id="edit-option-value"
                  value={editingOption.option_value}
                  onChange={(e) => setEditingOption(prev => prev ? { ...prev, option_value: e.target.value } : null)}
                  className="bg-gray-700 border-gray-600 text-white"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="edit-routing-rule">Routing Rule</Label>
                  <Input
                    id="edit-routing-rule"
                    value={editingOption.routing_rule || ''}
                    onChange={(e) => setEditingOption(prev => prev ? { ...prev, routing_rule: e.target.value } : null)}
                    className="bg-gray-700 border-gray-600 text-white"
                  />
                </div>
                <div>
                  <Label htmlFor="edit-display-order">Display Order</Label>
                  <Input
                    id="edit-display-order"
                    type="number"
                    value={editingOption.display_order || 0}
                    onChange={(e) => setEditingOption(prev => prev ? { ...prev, display_order: parseInt(e.target.value) || 0 } : null)}
                    className="bg-gray-700 border-gray-600 text-white"
                    min="0"
                  />
                </div>
              </div>
              <div>
                <Label htmlFor="edit-regulatory-notes">Regulatory Notes</Label>
                <Textarea
                  id="edit-regulatory-notes"
                  value={editingOption.regulatory_notes || ''}
                  onChange={(e) => setEditingOption(prev => prev ? { ...prev, regulatory_notes: e.target.value } : null)}
                  className="bg-gray-700 border-gray-600 text-white"
                />
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => {
              setIsEditOptionOpen(false);
              setEditingOption(null);
            }}>
              Cancel
            </Button>
            <Button
              onClick={async () => {
                if (!selectedTree || !managingOptionsForNode || !editingOption) return;
                
                try {
                  const response = await brain.update_sanctions_node_option(
                    { 
                      treeId: selectedTree.id,
                      nodeId: managingOptionsForNode.id,
                      optionId: editingOption.id
                    },
                    {
                      option_text: editingOption.option_text,
                      option_value: editingOption.option_value,
                      routing_rule: editingOption.routing_rule || null,
                      regulatory_notes: editingOption.regulatory_notes || null,
                      display_order: editingOption.display_order || 0,
                      note: editingOption.note || null
                    }
                  );

                  if (response.ok) {
                    toast.success('Option updated successfully');
                    setIsEditOptionOpen(false);
                    setEditingOption(null);
                    loadNodeOptions(managingOptionsForNode.id);
                  } else {
                    toast.error('Failed to update option');
                  }
                } catch (error) {
                  console.error('Error updating option:', error);
                  toast.error('Failed to update option');
                }
              }}
              className="bg-amber-600 hover:bg-amber-700 text-white"
              disabled={!editingOption?.option_text.trim() || !editingOption?.option_value.trim()}
            >
              Update Option
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Workflow Execution Dialog */}
      <Dialog open={showWorkflowDialog} onOpenChange={setShowWorkflowDialog}>
        <DialogContent className="bg-gray-800 border-gray-600 text-white max-w-md">
          <DialogHeader>
            <DialogTitle>Workflow Execution</DialogTitle>
            <DialogDescription>View the progress and results of the workflow execution</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="workflow-progress">Progress</Label>
              <Input
                id="workflow-progress"
                type="number"
                value={workflowProgress}
                disabled
                className="bg-gray-700 border-gray-600 text-white"
              />
            </div>
            <div>
              <Label htmlFor="workflow-results">Results</Label>
              <Textarea
                id="workflow-results"
                value={JSON.stringify(workflowResults, null, 2)}
                disabled
                className="bg-gray-700 border-gray-600 text-white"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowWorkflowDialog(false)}>
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Workflow Creation Dialog */}
      <Dialog open={showCreateWorkflowDialog} onOpenChange={setShowCreateWorkflowDialog}>
        <DialogContent className="bg-gray-800 border-gray-600 text-white max-w-md">
          <DialogHeader>
            <DialogTitle>Create Workflow</DialogTitle>
            <DialogDescription>Create a new workflow for sanctions screening</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="workflow-name">Workflow Name</Label>
              <Input
                id="workflow-name"
                value={newWorkflowData.name}
                onChange={(e) => setNewWorkflowData(prev => ({ ...prev, name: e.target.value }))}
                className="bg-gray-700 border-gray-600 text-white"
                placeholder="i.e., Sanctions Screening Workflow"
              />
            </div>
            <div>
              <Label htmlFor="workflow-description">Description</Label>
              <Textarea
                id="workflow-description"
                value={newWorkflowData.description}
                onChange={(e) => setNewWorkflowData(prev => ({ ...prev, description: e.target.value }))}
                className="bg-gray-700 border-gray-600 text-white"
                placeholder="Describe the purpose and scope of this workflow"
              />
            </div>
            <div>
              <Label htmlFor="workflow-category">Category</Label>
              <Input
                id="workflow-category"
                value={newWorkflowData.category}
                onChange={(e) => setNewWorkflowData(prev => ({ ...prev, category: e.target.value }))}
                className="bg-gray-700 border-gray-600 text-white"
                placeholder="e.g., Sanctions, Trade Embargoes"
              />
            </div>
            <div>
              <Label htmlFor="workflow-steps">Steps</Label>
              <Textarea
                id="workflow-steps"
                value={JSON.stringify(newWorkflowData.steps, null, 2)}
                onChange={(e) => setNewWorkflowData(prev => ({ ...prev, steps: JSON.parse(e.target.value) }))}
                className="bg-gray-700 border-gray-600 text-white"
                placeholder="Define the workflow steps"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowCreateWorkflowDialog(false)}>
              Cancel
            </Button>
            <Button
              onClick={handleCreateWorkflow}
              disabled={creatingWorkflow || !newWorkflowData.name.trim()}
              className="bg-purple-600 hover:bg-purple-700 text-white"
            >
              {creatingWorkflow ? 'Creating...' : 'Create Workflow'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default SanctionsTreeManagement;
