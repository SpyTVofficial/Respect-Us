import React, { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
  Activity, 
  Eye, 
  MessageSquare, 
  Bookmark, 
  Share, 
  Download, 
  Edit, 
  Clock,
  User,
  RefreshCw
} from 'lucide-react';
import { useUserGuardContext } from 'app/auth';
import brain from 'brain';
import { CollaborationActivity } from 'types';
import { toast } from 'sonner';
import { formatDistanceToNow, format } from 'date-fns';

interface Props {
  documentId?: number;
  limit?: number;
  showFilters?: boolean;
}

const ACTIVITY_ICONS = {
  viewed: Eye,
  annotated: MessageSquare,
  bookmarked: Bookmark,
  shared: Share,
  downloaded: Download,
  edited: Edit,
  commented: MessageSquare,
  resolved: MessageSquare,
  created: Edit
};

const ACTIVITY_COLORS = {
  viewed: 'text-blue-400',
  annotated: 'text-green-400',
  bookmarked: 'text-yellow-400',
  shared: 'text-purple-400',
  downloaded: 'text-indigo-400',
  edited: 'text-orange-400',
  commented: 'text-green-400',
  resolved: 'text-emerald-400',
  created: 'text-blue-400'
};

const ACTIVITY_TYPES = [
  { value: '', label: 'All Activities' },
  { value: 'viewed', label: 'Views' },
  { value: 'annotated', label: 'Annotations' },
  { value: 'bookmarked', label: 'Bookmarks' },
  { value: 'shared', label: 'Shares' },
  { value: 'downloaded', label: 'Downloads' },
  { value: 'edited', label: 'Edits' }
];

export function ActivityFeed({ documentId, limit = 50, showFilters = true }: Props) {
  const { user } = useUserGuardContext();
  const [activities, setActivities] = useState<CollaborationActivity[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('');
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    loadActivities();
  }, [documentId, filter]);

  const loadActivities = async () => {
    try {
      setLoading(true);
      
      if (documentId) {
        // Load document-specific activity
        const response = await brain.get_document_activity({
          document_id: documentId,
          limit
        });
        
        if (response.ok) {
          const data = await response.json();
          setActivities(data);
        }
      } else {
        // For demo purposes, show sample activities
        const sampleActivities: CollaborationActivity[] = [
          {
            id: 1,
            document_id: 1,
            user_id: user.sub,
            activity_type: 'viewed',
            description: 'Viewed EU Export Control Regulation',
            metadata: { section: 'Article 3.2' },
            created_at: new Date(Date.now() - 1000 * 60 * 5).toISOString(), // 5 minutes ago
            user_name: 'You'
          },
          {
            id: 2,
            document_id: 1,
            user_id: 'other-user',
            activity_type: 'annotated',
            description: 'Added highlight annotation on dual-use goods section',
            metadata: { annotation_type: 'highlight' },
            created_at: new Date(Date.now() - 1000 * 60 * 15).toISOString(), // 15 minutes ago
            user_name: 'Compliance Expert'
          },
          {
            id: 3,
            document_id: 2,
            user_id: user.sub,
            activity_type: 'bookmarked',
            description: 'Bookmarked OFAC Sanctions Guidelines',
            metadata: { bookmark_title: 'Key Sanctions Reference' },
            created_at: new Date(Date.now() - 1000 * 60 * 30).toISOString(), // 30 minutes ago
            user_name: 'You'
          },
          {
            id: 4,
            document_id: 1,
            user_id: 'another-user',
            activity_type: 'commented',
            description: 'Added comment on licensing requirements',
            metadata: { comment_preview: 'This section needs clarification...' },
            created_at: new Date(Date.now() - 1000 * 60 * 45).toISOString(), // 45 minutes ago
            user_name: 'Legal Advisor'
          },
          {
            id: 5,
            document_id: 3,
            user_id: user.sub,
            activity_type: 'downloaded',
            description: 'Downloaded Customer Screening Guidelines PDF',
            metadata: { file_type: 'PDF' },
            created_at: new Date(Date.now() - 1000 * 60 * 60).toISOString(), // 1 hour ago
            user_name: 'You'
          }
        ];
        
        setActivities(sampleActivities);
      }
    } catch (error) {
      console.error('Error loading activities:', error);
      toast.error('Failed to load activity feed');
    } finally {
      setLoading(false);
    }
  };

  const refreshActivities = async () => {
    setRefreshing(true);
    await loadActivities();
    setRefreshing(false);
    toast.success('Activity feed refreshed');
  };

  const trackActivity = async (activityType: string, description: string) => {
    if (!documentId) return;
    
    try {
      await brain.track_document_activity({
        document_id: documentId,
        activity_type: activityType,
        description,
        metadata: {}
      });
    } catch (error) {
      console.error('Error tracking activity:', error);
    }
  };

  const filteredActivities = activities.filter(activity => {
    if (!filter) return true;
    return activity.activity_type === filter;
  });

  const getActivityIcon = (type: string) => {
    const IconComponent = ACTIVITY_ICONS[type as keyof typeof ACTIVITY_ICONS] || Activity;
    return IconComponent;
  };

  const getActivityColor = (type: string) => {
    return ACTIVITY_COLORS[type as keyof typeof ACTIVITY_COLORS] || 'text-gray-400';
  };

  return (
    <div className="w-full space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Activity className="h-5 w-5 text-purple-400" />
          <h3 className="text-lg font-semibold text-gray-100">Activity Feed</h3>
          <Badge variant="outline" className="border-gray-600">
            {filteredActivities.length}
          </Badge>
        </div>
        
        <Button 
          variant="outline" 
          size="sm" 
          onClick={refreshActivities}
          disabled={refreshing}
          className="border-gray-600 text-gray-300 hover:bg-gray-700"
        >
          <RefreshCw className={`h-4 w-4 mr-2 ${refreshing ? 'animate-spin' : ''}`} />
          Refresh
        </Button>
      </div>

      {/* Filters */}
      {showFilters && (
        <div className="flex gap-3">
          <Select value={filter} onValueChange={setFilter}>
            <SelectTrigger className="bg-gray-700 border-gray-600 w-48">
              <SelectValue placeholder="Filter by activity type" />
            </SelectTrigger>
            <SelectContent className="bg-gray-800 border-gray-600">
              {ACTIVITY_TYPES.map(type => (
                <SelectItem key={type.value} value={type.value} className="text-gray-200">
                  {type.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      )}

      {/* Activity List */}
      <div className="space-y-2">
        {loading ? (
          <div className="text-center py-8 text-gray-400">Loading activities...</div>
        ) : filteredActivities.length === 0 ? (
          <div className="text-center py-8 text-gray-400">
            {filter ? 'No activities match the selected filter.' : 'No activities yet.'}
          </div>
        ) : (
          filteredActivities.map((activity) => {
            const IconComponent = getActivityIcon(activity.activity_type);
            const iconColor = getActivityColor(activity.activity_type);
            
            return (
              <Card key={activity.id} className="bg-gray-800/20 border-gray-700/50 hover:bg-gray-800/40 transition-colors">
                <CardContent className="p-4">
                  <div className="flex items-start gap-3">
                    <div className={`p-2 rounded-full bg-gray-700/50 ${iconColor}`}>
                      <IconComponent className="h-4 w-4" />
                    </div>
                    
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-sm font-medium text-gray-200">
                          {activity.user_name === 'You' ? 'You' : activity.user_name}
                        </span>
                        <Badge 
                          variant="outline" 
                          className={`text-xs border-gray-600 ${iconColor}`}
                        >
                          {activity.activity_type}
                        </Badge>
                      </div>
                      
                      <p className="text-gray-300 text-sm mb-2">
                        {activity.description}
                      </p>
                      
                      {/* Metadata */}
                      {activity.metadata && Object.keys(activity.metadata).length > 0 && (
                        <div className="text-xs text-gray-400 mb-2">
                          {activity.metadata.section && (
                            <span>📍 {activity.metadata.section}</span>
                          )}
                          {activity.metadata.annotation_type && (
                            <span>• 📝 {activity.metadata.annotation_type}</span>
                          )}
                          {activity.metadata.bookmark_title && (
                            <span>• 🔖 {activity.metadata.bookmark_title}</span>
                          )}
                          {activity.metadata.comment_preview && (
                            <span>• 💬 "{activity.metadata.comment_preview}"</span>
                          )}
                          {activity.metadata.file_type && (
                            <span>• 📄 {activity.metadata.file_type}</span>
                          )}
                        </div>
                      )}
                      
                      <div className="flex items-center gap-2 text-xs text-gray-500">
                        <Clock className="h-3 w-3" />
                        <span>
                          {activity.created_at && formatDistanceToNow(new Date(activity.created_at), { addSuffix: true })}
                        </span>
                        <span>•</span>
                        <span>
                          {activity.created_at && format(new Date(activity.created_at), 'MMM d, HH:mm')}
                        </span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })
        )}
      </div>
      
      {/* Load More */}
      {filteredActivities.length >= limit && (
        <div className="text-center pt-4">
          <Button 
            variant="outline" 
            onClick={() => loadActivities()}
            className="border-gray-600 text-gray-300 hover:bg-gray-700"
          >
            Load More Activities
          </Button>
        </div>
      )}
    </div>
  );
}
