import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Separator } from '@/components/ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Building, Settings, CreditCard, Users, FileText, Activity,
  Edit, Save, X, Plus, Download, Receipt, Calendar, DollarSign
} from 'lucide-react';
import { toast } from 'sonner';
import brain from 'brain';

interface UserCompanyContext {
  company_id: number;
  company_name: string;
  company_domain?: string;
  user_role: string;
  permissions: {
    can_invite: boolean;
    can_remove_members: boolean;
    team_management: boolean;
    billing_management: boolean;
    audit_logs: boolean;
    user_management: boolean;
  };
}

interface CompanyProfile {
  id: number;
  company_name: string;
  company_slug: string;
  company_domain?: string;
  billing_email?: string;
  subscription_tier: string;
  max_team_members: number;
  is_active: boolean;
  sso_enabled: boolean;
  audit_logs_enabled: boolean;
  api_access_enabled: boolean;
}

interface CompanyManagementTabProps {
  userCompanyContext: UserCompanyContext | null;
  onCompanyContextUpdate: (context: UserCompanyContext) => void;
}

export default function CompanyManagementTab({ userCompanyContext, onCompanyContextUpdate }: CompanyManagementTabProps) {
  const [companyProfile, setCompanyProfile] = useState<CompanyProfile | null>(null);
  const [isEditingProfile, setIsEditingProfile] = useState(false);
  const [profileForm, setProfileForm] = useState({
    company_name: '',
    company_domain: '',
    billing_email: '',
    max_team_members: 10
  });
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);

  // Load company profile data
  useEffect(() => {
    if (userCompanyContext?.company_id) {
      loadCompanyProfile();
    }
  }, [userCompanyContext?.company_id]);

  const loadCompanyProfile = async () => {
    if (!userCompanyContext?.company_id) return;
    
    try {
      setLoading(true);
      const response = await brain.get_company_profile({ companyId: userCompanyContext.company_id });
      if (response.ok) {
        const data = await response.json();
        setCompanyProfile(data);
        setProfileForm({
          company_name: data.company_name,
          company_domain: data.company_domain || '',
          billing_email: data.billing_email || '',
          max_team_members: data.max_team_members
        });
      }
    } catch (error) {
      console.error('Error loading company profile:', error);
      toast.error('Failed to load company profile');
    } finally {
      setLoading(false);
    }
  };

  const handleSaveProfile = async () => {
    if (!userCompanyContext?.company_id) return;
    
    try {
      setSaving(true);
      const response = await brain.update_company_profile(
        { companyId: userCompanyContext.company_id },
        profileForm
      );
      
      if (response.ok) {
        const data = await response.json();
        setCompanyProfile(data);
        setIsEditingProfile(false);
        toast.success('Company profile updated successfully');
        
        // Update context if company name changed
        if (data.company_name !== userCompanyContext.company_name) {
          onCompanyContextUpdate({
            ...userCompanyContext,
            company_name: data.company_name,
            company_domain: data.company_domain
          });
        }
      } else {
        toast.error('Failed to update company profile');
      }
    } catch (error) {
      console.error('Error updating company profile:', error);
      toast.error('Failed to update company profile');
    } finally {
      setSaving(false);
    }
  };

  const handleCancelEdit = () => {
    if (companyProfile) {
      setProfileForm({
        company_name: companyProfile.company_name,
        company_domain: companyProfile.company_domain || '',
        billing_email: companyProfile.billing_email || '',
        max_team_members: companyProfile.max_team_members
      });
    }
    setIsEditingProfile(false);
  };

  if (!userCompanyContext?.company_id) {
    return (
      <div className="space-y-6">
        <Card className="bg-gray-800/50 border-gray-700">
          <CardHeader>
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-orange-500/20 rounded-lg">
                <Building className="w-5 h-5 text-orange-400" />
              </div>
              <div>
                <CardTitle className="text-white">Company Management</CardTitle>
                <CardDescription className="text-gray-400">
                  Create a company to access management features
                </CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-center py-8">
              <Building className="w-16 h-16 text-gray-600 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-white mb-2">No Company Account</h3>
              <p className="text-gray-400 mb-6 max-w-md mx-auto">
                Create a company account in the Team tab to access management features.
              </p>
              <Button 
                onClick={() => window.location.href = '#team'}
                className="bg-orange-600 hover:bg-orange-700 text-white"
              >
                <Building className="w-4 h-4 mr-2" />
                Go to Team Tab
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card className="bg-gray-800/50 border-gray-700">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-orange-500/20 rounded-lg">
                <Building className="w-5 h-5 text-orange-400" />
              </div>
              <div>
                <CardTitle className="text-white">Company Management</CardTitle>
                <CardDescription className="text-gray-400">
                  Manage your organization settings, billing, and administrative features
                </CardDescription>
              </div>
            </div>
            <Badge className="bg-purple-500/20 text-purple-300 border-purple-500/30">
              {userCompanyContext.user_role}
            </Badge>
          </div>
        </CardHeader>
      </Card>

      {/* Management Tabs */}
      <Tabs defaultValue="company" className="w-full">
        <TabsList className="grid w-full grid-cols-4 bg-gray-800/50 border border-gray-700">
          <TabsTrigger value="company" className="data-[state=active]:bg-orange-600 data-[state=active]:text-white">
            <Building className="w-4 h-4 mr-2" />
            Company
          </TabsTrigger>
          <TabsTrigger value="billing" className="data-[state=active]:bg-orange-600 data-[state=active]:text-white">
            <CreditCard className="w-4 h-4 mr-2" />
            Billing
          </TabsTrigger>
          <TabsTrigger value="settings" className="data-[state=active]:bg-orange-600 data-[state=active]:text-white">
            <Settings className="w-4 h-4 mr-2" />
            Settings
          </TabsTrigger>
          <TabsTrigger value="activity" className="data-[state=active]:bg-orange-600 data-[state=active]:text-white">
            <Activity className="w-4 h-4 mr-2" />
            Activity
          </TabsTrigger>
        </TabsList>

        {/* Company Profile Tab */}
        <TabsContent value="company" className="space-y-6 mt-6">
          <Card className="bg-gray-800/50 border-gray-700">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="text-white">Company Profile</CardTitle>
                  <CardDescription className="text-gray-400">
                    Manage your company information and business details
                  </CardDescription>
                </div>
                {userCompanyContext.permissions?.billing_management && (
                  <Button
                    onClick={() => setIsEditingProfile(!isEditingProfile)}
                    variant={isEditingProfile ? "outline" : "default"}
                    className={isEditingProfile 
                      ? "border-gray-600 text-gray-300 hover:bg-gray-700" 
                      : "bg-orange-600 hover:bg-orange-700 text-white"
                    }
                  >
                    {isEditingProfile ? (
                      <><X className="w-4 h-4 mr-2" />Cancel</>
                    ) : (
                      <><Edit className="w-4 h-4 mr-2" />Edit Profile</>
                    )}
                  </Button>
                )}
              </div>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="text-center py-8">
                  <div className="w-8 h-8 border-4 border-orange-500 border-t-transparent rounded-full animate-spin mx-auto mb-2" />
                  <p className="text-gray-400">Loading company profile...</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <Label className="text-gray-300">Company Name</Label>
                    {isEditingProfile ? (
                      <Input
                        value={profileForm.company_name}
                        onChange={(e) => setProfileForm(prev => ({ ...prev, company_name: e.target.value }))}
                        className="bg-gray-700 border-gray-600 text-white mt-1"
                        placeholder="Enter company name"
                      />
                    ) : (
                      <p className="text-white mt-1">{companyProfile?.company_name || 'Not set'}</p>
                    )}
                  </div>
                  
                  <div>
                    <Label className="text-gray-300">Company Domain</Label>
                    {isEditingProfile ? (
                      <Input
                        value={profileForm.company_domain}
                        onChange={(e) => setProfileForm(prev => ({ ...prev, company_domain: e.target.value }))}
                        className="bg-gray-700 border-gray-600 text-white mt-1"
                        placeholder="example.com"
                      />
                    ) : (
                      <p className="text-white mt-1">{companyProfile?.company_domain || 'Not set'}</p>
                    )}
                  </div>
                  
                  <div>
                    <Label className="text-gray-300">Billing Email</Label>
                    {isEditingProfile ? (
                      <Input
                        type="email"
                        value={profileForm.billing_email}
                        onChange={(e) => setProfileForm(prev => ({ ...prev, billing_email: e.target.value }))}
                        className="bg-gray-700 border-gray-600 text-white mt-1"
                        placeholder="billing@example.com"
                      />
                    ) : (
                      <p className="text-white mt-1">{companyProfile?.billing_email || 'Not set'}</p>
                    )}
                  </div>
                  
                  <div>
                    <Label className="text-gray-300">Max Team Members</Label>
                    {isEditingProfile ? (
                      <Input
                        type="number"
                        min="1"
                        max="100"
                        value={profileForm.max_team_members}
                        onChange={(e) => setProfileForm(prev => ({ ...prev, max_team_members: parseInt(e.target.value) || 10 }))}
                        className="bg-gray-700 border-gray-600 text-white mt-1"
                      />
                    ) : (
                      <p className="text-white mt-1">{companyProfile?.max_team_members || 10}</p>
                    )}
                  </div>
                  
                  <div>
                    <Label className="text-gray-300">Subscription Tier</Label>
                    <p className="text-white mt-1">
                      <Badge className="bg-blue-500/20 text-blue-300 border-blue-500/30">
                        {companyProfile?.subscription_tier || 'basic'}
                      </Badge>
                    </p>
                  </div>
                  
                  <div>
                    <Label className="text-gray-300">Company Slug</Label>
                    <p className="text-gray-400 mt-1 font-mono text-sm">{companyProfile?.company_slug}</p>
                  </div>
                </div>
              )}
              
              {isEditingProfile && (
                <>
                  <Separator className="bg-gray-700 my-6" />
                  <div className="flex justify-end space-x-4">
                    <Button
                      onClick={handleCancelEdit}
                      variant="outline"
                      className="border-gray-600 text-gray-300 hover:bg-gray-700"
                    >
                      <X className="w-4 h-4 mr-2" />
                      Cancel
                    </Button>
                    <Button
                      onClick={handleSaveProfile}
                      disabled={saving || !profileForm.company_name.trim()}
                      className="bg-orange-600 hover:bg-orange-700 text-white"
                    >
                      {saving ? (
                        <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                      ) : (
                        <Save className="w-4 h-4 mr-2" />
                      )}
                      {saving ? 'Saving...' : 'Save Changes'}
                    </Button>
                  </div>
                </>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Billing Tab */}
        <TabsContent value="billing" className="space-y-6 mt-6">
          <Card className="bg-gray-800/50 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white flex items-center">
                <CreditCard className="w-5 h-5 mr-2 text-green-400" />
                Billing & Subscriptions
              </CardTitle>
              <CardDescription className="text-gray-400">
                Manage payment methods, view invoices, and track usage
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-center py-12">
                <CreditCard className="w-16 h-16 text-gray-600 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-white mb-2">Billing Management</h3>
                <p className="text-gray-400 mb-6 max-w-md mx-auto">
                  Full billing management features will be available here. For now, check the existing Billing tab.
                </p>
                <Button className="bg-green-600 hover:bg-green-700 text-white">
                  <Receipt className="w-4 h-4 mr-2" />
                  View Billing Tab
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Settings Tab */}
        <TabsContent value="settings" className="space-y-6 mt-6">
          <Card className="bg-gray-800/50 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white flex items-center">
                <Settings className="w-5 h-5 mr-2 text-blue-400" />
                Company Settings
              </CardTitle>
              <CardDescription className="text-gray-400">
                Configure advanced company features and integrations
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <h4 className="text-white font-medium">Security & Access</h4>
                    <div className="space-y-3">
                      <div className="flex items-center justify-between p-3 bg-gray-700/50 rounded-lg">
                        <div>
                          <p className="text-white text-sm font-medium">Single Sign-On (SSO)</p>
                          <p className="text-gray-400 text-xs">Enable SSO authentication</p>
                        </div>
                        <Badge className={companyProfile?.sso_enabled 
                          ? "bg-green-500/20 text-green-300 border-green-500/30" 
                          : "bg-gray-500/20 text-gray-400 border-gray-500/30"
                        }>
                          {companyProfile?.sso_enabled ? 'Enabled' : 'Disabled'}
                        </Badge>
                      </div>
                      
                      <div className="flex items-center justify-between p-3 bg-gray-700/50 rounded-lg">
                        <div>
                          <p className="text-white text-sm font-medium">Audit Logs</p>
                          <p className="text-gray-400 text-xs">Track user activity and changes</p>
                        </div>
                        <Badge className={companyProfile?.audit_logs_enabled 
                          ? "bg-green-500/20 text-green-300 border-green-500/30" 
                          : "bg-gray-500/20 text-gray-400 border-gray-500/30"
                        }>
                          {companyProfile?.audit_logs_enabled ? 'Enabled' : 'Disabled'}
                        </Badge>
                      </div>
                      
                      <div className="flex items-center justify-between p-3 bg-gray-700/50 rounded-lg">
                        <div>
                          <p className="text-white text-sm font-medium">API Access</p>
                          <p className="text-gray-400 text-xs">Enable API integration</p>
                        </div>
                        <Badge className={companyProfile?.api_access_enabled 
                          ? "bg-green-500/20 text-green-300 border-green-500/30" 
                          : "bg-gray-500/20 text-gray-400 border-gray-500/30"
                        }>
                          {companyProfile?.api_access_enabled ? 'Enabled' : 'Disabled'}
                        </Badge>
                      </div>
                    </div>
                  </div>
                  
                  <div className="space-y-4">
                    <h4 className="text-white font-medium">Account Status</h4>
                    <div className="space-y-3">
                      <div className="flex items-center justify-between p-3 bg-gray-700/50 rounded-lg">
                        <div>
                          <p className="text-white text-sm font-medium">Company Status</p>
                          <p className="text-gray-400 text-xs">Current account status</p>
                        </div>
                        <Badge className={companyProfile?.is_active 
                          ? "bg-green-500/20 text-green-300 border-green-500/30" 
                          : "bg-red-500/20 text-red-300 border-red-500/30"
                        }>
                          {companyProfile?.is_active ? 'Active' : 'Inactive'}
                        </Badge>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Activity Tab */}
        <TabsContent value="activity" className="space-y-6 mt-6">
          <Card className="bg-gray-800/50 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white flex items-center">
                <Activity className="w-5 h-5 mr-2 text-purple-400" />
                Company Activity
              </CardTitle>
              <CardDescription className="text-gray-400">
                View audit logs and team activity across your organization
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-center py-12">
                <Activity className="w-16 h-16 text-gray-600 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-white mb-2">Activity Logs</h3>
                <p className="text-gray-400 mb-6 max-w-md mx-auto">
                  Detailed audit logs and activity tracking will be available here.
                </p>
                <Button className="bg-purple-600 hover:bg-purple-700 text-white">
                  <FileText className="w-4 h-4 mr-2" />
                  View Full Logs
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
