import React, { useState, useEffect } from 'react';
import { Download, Upload, Database, Settings, RefreshCw, FileSpreadsheet, Import } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';
import brain from 'brain';
import { auth } from 'app/auth';
import type { AppApisClassificationClassificationTree as ClassificationTree } from '../brain/data-contracts';

const ToolsTab: React.FC = () => {
  const [trees, setTrees] = useState<ClassificationTree[]>([]);
  const [loading, setLoading] = useState(true);
  const [showExportDialog, setShowExportDialog] = useState(false);
  const [showImportDialog, setShowImportDialog] = useState(false);
  const [selectedTreeForExport, setSelectedTreeForExport] = useState('');
  const [selectedTreeForImport, setSelectedTreeForImport] = useState('');
  const [importFile, setImportFile] = useState<File | null>(null);
  const [exporting, setExporting] = useState(false);
  const [importing, setImporting] = useState(false);

  useEffect(() => {
    loadTrees();
  }, []);

  const loadTrees = async () => {
    try {
      setLoading(true);
      const treesResponse = await brain.list_classification_trees();
      if (treesResponse.ok) {
        const treesData = await treesResponse.json();
        setTrees(treesData);
      }
    } catch (error) {
      console.error('Error loading trees:', error);
      toast.error('Failed to load classification trees');
    } finally {
      setLoading(false);
    }
  };

  const handleExportNotes = async () => {
    try {
      setExporting(true);
      
      // Use brain client instead of direct fetch for proper handling
      const response = await brain.export_notes_to_excel({ treeId: 'global' });
      
      if (response.ok) {
        // Get the blob directly from the response
        const blob = await response.blob();
        
        // Ensure proper MIME type for Excel files
        const excelBlob = new Blob([blob], { 
          type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' 
        });
        
        // Create download link
        const url = window.URL.createObjectURL(excelBlob);
        const filename = `regulatory_notes_global_${new Date().toISOString().split('T')[0]}.xlsx`;
        
        const link = document.createElement('a');
        link.href = url;
        link.download = filename;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        window.URL.revokeObjectURL(url);
        
        toast.success('Global notes exported successfully');
        setShowExportDialog(false);
      } else {
        const errorText = await response.text();
        console.error('Export failed:', errorText);
        toast.error('Failed to export notes');
      }
    } catch (error) {
      console.error('Error exporting notes:', error);
      toast.error('Failed to export notes');
    } finally {
      setExporting(false);
    }
  };

  const handleImportNotes = async () => {
    if (!selectedTreeForImport || !importFile) {
      toast.error('Please select a tree and file to import');
      return;
    }

    try {
      setImporting(true);
      
      // Read file content as base64
      const fileContent = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => {
          const result = reader.result as string;
          // Remove data URL prefix to get just the base64 content
          const base64Content = result.split(',')[1];
          resolve(base64Content);
        };
        reader.onerror = reject;
        reader.readAsDataURL(importFile);
      });
      
      const response = await brain.import_notes_from_excel(
        { treeId: selectedTreeForImport },
        { file_content: fileContent }
      );
      
      if (response.ok) {
        const result = await response.json();
        toast.success(`Import completed! ${result.imported_count} notes imported, ${result.error_count} errors`);
        setShowImportDialog(false);
        setSelectedTreeForImport('');
        setImportFile(null);
      } else {
        const errorData = await response.json();
        toast.error(errorData.detail || 'Failed to import notes');
      }
    } catch (error) {
      console.error('Error importing notes:', error);
      toast.error('Failed to import notes');
    } finally {
      setImporting(false);
    }
  };

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (file.type === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' || 
          file.type === 'application/vnd.ms-excel' ||
          file.name.endsWith('.xlsx') || 
          file.name.endsWith('.xls')) {
        setImportFile(file);
      } else {
        toast.error('Please select a valid Excel file (.xlsx or .xls)');
        event.target.value = '';
      }
    }
  };

  const toolCategories = [
    {
      title: 'Data Export/Import',
      description: 'Import and export regulatory notes and classification data',
      icon: <Database className="w-6 h-6" />,
      color: 'green',
      tools: [
        {
          name: 'Export Notes to Excel',
          description: 'Export regulatory notes for a specific classification tree to Excel format',
          icon: <Download className="w-5 h-5" />,
          action: () => setShowExportDialog(true)
        },
        {
          name: 'Import Notes from Excel',
          description: 'Import regulatory notes from Excel file to a classification tree',
          icon: <Upload className="w-5 h-5" />,
          action: () => setShowImportDialog(true)
        }
      ]
    },
    {
      title: 'System Maintenance',
      description: 'System administration and maintenance tools',
      icon: <Settings className="w-6 h-6" />,
      color: 'blue',
      tools: [
        {
          name: 'Refresh Data Cache',
          description: 'Refresh cached classification data and reload trees',
          icon: <RefreshCw className="w-5 h-5" />,
          action: () => {
            loadTrees();
            toast.success('Data cache refreshed');
          }
        }
      ]
    }
  ];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h3 className="text-xl font-semibold text-green-400">Import/Export Tools</h3>
          <p className="text-gray-400 text-sm mt-1">Data management and system administration tools</p>
        </div>
      </div>

      {loading ? (
        <div className="text-center py-8">
          <p className="text-gray-400">Loading tools...</p>
        </div>
      ) : (
        <div className="space-y-8">
          {toolCategories.map((category, categoryIndex) => (
            <div key={categoryIndex} className="space-y-4">
              <div className="flex items-center gap-3">
                <div className={`p-2 rounded-lg bg-${category.color}-600/20 text-${category.color}-400`}>
                  {category.icon}
                </div>
                <div>
                  <h4 className="text-lg font-semibold text-white">{category.title}</h4>
                  <p className="text-gray-400 text-sm">{category.description}</p>
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {category.tools.map((tool, toolIndex) => (
                  <Card key={toolIndex} className="bg-gray-800/50 border-gray-700 hover:border-green-500/50 transition-colors cursor-pointer">
                    <CardHeader className="pb-3">
                      <CardTitle className="text-white text-lg flex items-center gap-2">
                        <div className="p-2 rounded-lg bg-green-600/20 text-green-400">
                          {tool.icon}
                        </div>
                        {tool.name}
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <p className="text-gray-400 text-sm">{tool.description}</p>
                      <Button 
                        onClick={tool.action}
                        className="w-full bg-green-600 hover:bg-green-700 text-white"
                      >
                        {tool.name === 'Export Notes to Excel' ? 'Export Global Notes' : 'Launch Tool'}
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          ))}
          
          {trees.length === 0 && (
            <Card className="bg-gray-800/50 border-gray-700">
              <CardContent className="p-8 text-center">
                <Settings className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-400">No classification trees found</p>
                <p className="text-gray-500 text-sm">Create classification trees to use import/export tools</p>
              </CardContent>
            </Card>
          )}
        </div>
      )}

      {/* Export Dialog */}
      <Dialog open={showExportDialog} onOpenChange={setShowExportDialog}>
        <DialogContent className="bg-gray-900 border-gray-700 text-white">
          <DialogHeader>
            <DialogTitle className="text-green-400 flex items-center gap-2">
              <Download className="w-5 h-5" />
              Export Global Notes to Excel
            </DialogTitle>
            <DialogDescription className="text-gray-400">
              Export all regulatory notes to Excel format. All notes in the system are Global Notes.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            <div className="bg-green-900/20 border border-green-600/30 rounded-lg p-4">
              <div className="flex items-center gap-2 text-green-400 mb-2">
                <FileSpreadsheet className="w-4 h-4" />
                <span className="font-medium">Export Information</span>
              </div>
              <ul className="text-sm text-gray-300 space-y-1">
                <li>• All regulatory notes will be exported (Global Notes)</li>
                <li>• File format: Excel (.xlsx)</li>
                <li>• Includes: Note Key, Title, Content, Created Date</li>
              </ul>
            </div>
          </div>
          
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => setShowExportDialog(false)}
              className="bg-gray-800 border-gray-600 text-white hover:bg-gray-700"
            >
              Cancel
            </Button>
            <Button 
              onClick={handleExportNotes}
              disabled={exporting}
              className="bg-green-600 hover:bg-green-700 text-white"
            >
              {exporting ? (
                <>
                  <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                  Exporting...
                </>
              ) : (
                <>
                  <Download className="w-4 h-4 mr-2" />
                  Export to Excel
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Import Dialog */}
      <Dialog open={showImportDialog} onOpenChange={setShowImportDialog}>
        <DialogContent className="bg-gray-900 border-gray-700 text-white">
          <DialogHeader>
            <DialogTitle className="text-green-400 flex items-center gap-2">
              <Import className="w-5 h-5" />
              Import Notes from Excel
            </DialogTitle>
            <DialogDescription className="text-gray-400">
              Upload an Excel file containing regulatory notes for a classification tree
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            <div className="space-y-2">
              <Label className="text-gray-300">Classification Tree</Label>
              <Select value={selectedTreeForImport} onValueChange={setSelectedTreeForImport}>
                <SelectTrigger className="bg-gray-800 border-gray-600 text-white">
                  <SelectValue placeholder="Select target tree" />
                </SelectTrigger>
                <SelectContent className="bg-gray-800 border-gray-600">
                  {trees.map(tree => (
                    <SelectItem key={tree.id} value={tree.id} className="text-white">
                      {tree.name} ({tree.jurisdiction})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label className="text-gray-300">Excel File</Label>
              <Input
                type="file"
                accept=".xlsx,.xls"
                onChange={handleFileChange}
                className="bg-gray-800 border-gray-600 text-white file:bg-gray-700 file:text-white file:border-0 file:mr-4 file:py-2 file:px-4 file:rounded-md"
              />
              {importFile && (
                <p className="text-sm text-green-400">Selected: {importFile.name}</p>
              )}
            </div>
            
            <div className="bg-blue-900/20 border border-blue-600/30 rounded-lg p-4">
              <div className="flex items-center gap-2 text-blue-400 mb-2">
                <FileSpreadsheet className="w-4 h-4" />
                <span className="font-medium">Import Requirements</span>
              </div>
              <ul className="text-sm text-gray-300 space-y-1">
                <li>• Excel file must contain columns: note_key, title, content</li>
                <li>• Note keys must be unique</li>
                <li>• File format: .xlsx or .xls</li>
                <li>• Existing notes with same key will be skipped</li>
              </ul>
            </div>
          </div>
          
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => {
                setShowImportDialog(false);
                setImportFile(null);
              }}
              className="bg-gray-800 border-gray-600 text-white hover:bg-gray-700"
            >
              Cancel
            </Button>
            <Button 
              onClick={handleImportNotes}
              disabled={importing || !selectedTreeForImport || !importFile}
              className="bg-green-600 hover:bg-green-700 text-white"
            >
              {importing ? (
                <>
                  <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                  Importing...
                </>
              ) : (
                <>
                  <Upload className="w-4 h-4 mr-2" />
                  Import from Excel
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default ToolsTab;
