import React from 'react';
import DocumentUploadDialog from 'components/DocumentUploadDialog';
import { toast } from 'sonner';

interface AdminDocumentUploadWrapperProps {
  showAddDocument: boolean;
  setShowAddDocument: (show: boolean) => void;
  onDocumentAdded: () => void;
}

export default function AdminDocumentUploadWrapper({
  showAddDocument,
  setShowAddDocument,
  onDocumentAdded
}: AdminDocumentUploadWrapperProps) {
  return (
    <DocumentUploadDialog
      open={showAddDocument}
      onClose={() => setShowAddDocument(false)}
      onSuccess={() => {
        setShowAddDocument(false);
        onDocumentAdded(); // Refresh the documents list
        toast.success('Document uploaded successfully!');
      }}
    />
  );
}
