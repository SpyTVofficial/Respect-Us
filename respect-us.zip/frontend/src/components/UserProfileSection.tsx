import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { User, Edit, Save, X } from 'lucide-react';
import { toast } from 'sonner';
import brain from 'brain';

interface UserProfileData {
  id?: number;
  user_id?: string;
  company_name: string;
  contact_person: string;
  email: string;
  phone: string;
  billing_address: string;
  city: string;
  postal_code: string;
  country: string;
  tax_id: string;
  vat_number: string;
  created_at?: string;
  updated_at?: string;
}

interface UserProfileSectionProps {
  user: any;
}

export default function UserProfileSection({ user }: UserProfileSectionProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [profileData, setProfileData] = useState<UserProfileData>({
    company_name: '',
    contact_person: '',
    email: '',
    phone: '',
    billing_address: '',
    city: '',
    postal_code: '',
    country: '',
    tax_id: '',
    vat_number: ''
  });
  const [originalData, setOriginalData] = useState<UserProfileData | null>(null);

  // Load user profile on component mount
  useEffect(() => {
    loadUserProfile();
  }, []);

  const loadUserProfile = async () => {
    try {
      const response = await brain.get_user_profile();
      if (response.ok) {
        const data = await response.json();
        setProfileData(data);
        setOriginalData(data);
      } else if (response.status === 404) {
        // Profile doesn't exist yet - start with empty form
        console.log('No profile found - using empty form');
      } else {
        console.error('Error loading profile:', response.status);
      }
    } catch (error) {
      console.error('Error loading user profile:', error);
    }
  };

  const handleSave = async () => {
    setIsLoading(true);
    try {
      const response = await brain.save_user_profile(profileData);
      if (response.ok) {
        const updatedData = await response.json();
        setProfileData(updatedData);
        setOriginalData(updatedData);
        setIsEditing(false);
        toast.success('Profile updated successfully!');
      } else {
        const errorData = await response.json();
        toast.error(errorData.detail || 'Failed to update profile');
      }
    } catch (error) {
      console.error('Error saving profile:', error);
      toast.error('Failed to update profile');
    } finally {
      setIsLoading(false);
    }
  };

  const handleCancel = () => {
    if (originalData) {
      setProfileData(originalData);
    }
    setIsEditing(false);
  };

  const handleDelete = async () => {
    if (!window.confirm('Are you sure you want to delete your profile? This action cannot be undone.')) {
      return;
    }

    setIsLoading(true);
    try {
      const response = await brain.delete_user_profile();
      if (response.ok) {
        // Reset to empty form
        const emptyData = {
          company_name: '',
          contact_person: '',
          email: '',
          phone: '',
          billing_address: '',
          city: '',
          postal_code: '',
          country: '',
          tax_id: '',
          vat_number: ''
        };
        setProfileData(emptyData);
        setOriginalData(null);
        setIsEditing(false);
        toast.success('Profile deleted successfully!');
      } else {
        const errorData = await response.json();
        toast.error(errorData.detail || 'Failed to delete profile');
      }
    } catch (error) {
      console.error('Error deleting profile:', error);
      toast.error('Failed to delete profile');
    } finally {
      setIsLoading(false);
    }
  };

  const updateField = (field: keyof UserProfileData, value: string) => {
    setProfileData(prev => ({ ...prev, [field]: value }));
  };

  const hasProfile = originalData && originalData.id;

  return (
    <Card className="bg-gray-900/50 border-gray-700 backdrop-blur-sm">
      <CardHeader>
        <CardTitle className="text-white flex items-center justify-between">
          <div className="flex items-center">
            <User className="w-5 h-5 mr-2 text-blue-400" />
            Business Profile
          </div>
          <div className="flex space-x-2">
            {!isEditing ? (
              <Button
                onClick={() => setIsEditing(true)}
                className="bg-blue-600 hover:bg-blue-700 text-white"
                size="sm"
              >
                <Edit className="w-4 h-4 mr-2" />
                {hasProfile ? 'Edit' : 'Create'}
              </Button>
            ) : (
              <>
                <Button
                  onClick={handleCancel}
                  variant="outline"
                  className="border-gray-600 text-gray-300 hover:bg-gray-800"
                  size="sm"
                  disabled={isLoading}
                >
                  <X className="w-4 h-4 mr-2" />
                  Cancel
                </Button>
                <Button
                  onClick={handleSave}
                  className="bg-green-600 hover:bg-green-700 text-white"
                  size="sm"
                  disabled={isLoading}
                >
                  <Save className="w-4 h-4 mr-2" />
                  {isLoading ? 'Saving...' : 'Save'}
                </Button>
              </>
            )}
          </div>
        </CardTitle>
        <CardDescription className="text-gray-400">
          {hasProfile
            ? 'Manage your business profile and billing information'
            : 'Create your business profile to access premium features'}
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Company Information */}
        <div className="space-y-4">
          <h3 className="text-lg font-semibold text-white">Company Information</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="company_name" className="text-sm font-medium text-gray-200">
                Company Name *
              </Label>
              <Input
                id="company_name"
                value={profileData.company_name}
                onChange={(e) => updateField('company_name', e.target.value)}
                disabled={!isEditing}
                placeholder="Your Company Ltd."
                className="bg-gray-800/50 border-gray-600 text-white placeholder-gray-400 focus:border-blue-500 disabled:opacity-60"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="contact_person" className="text-sm font-medium text-gray-200">
                Contact Person
              </Label>
              <Input
                id="contact_person"
                value={profileData.contact_person}
                onChange={(e) => updateField('contact_person', e.target.value)}
                disabled={!isEditing}
                placeholder="John Doe"
                className="bg-gray-800/50 border-gray-600 text-white placeholder-gray-400 focus:border-blue-500 disabled:opacity-60"
              />
            </div>
          </div>
        </div>

        {/* Contact Information */}
        <div className="space-y-4">
          <h3 className="text-lg font-semibold text-white">Contact Information</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="email" className="text-sm font-medium text-gray-200">
                Email *
              </Label>
              <Input
                id="email"
                type="email"
                value={profileData.email}
                onChange={(e) => updateField('email', e.target.value)}
                disabled={!isEditing}
                placeholder="contact@company.com"
                className="bg-gray-800/50 border-gray-600 text-white placeholder-gray-400 focus:border-blue-500 disabled:opacity-60"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="phone" className="text-sm font-medium text-gray-200">
                Phone
              </Label>
              <Input
                id="phone"
                value={profileData.phone}
                onChange={(e) => updateField('phone', e.target.value)}
                disabled={!isEditing}
                placeholder="+1 (555) 123-4567"
                className="bg-gray-800/50 border-gray-600 text-white placeholder-gray-400 focus:border-blue-500 disabled:opacity-60"
              />
            </div>
          </div>
        </div>

        {/* Billing Address */}
        <div className="space-y-4">
          <h3 className="text-lg font-semibold text-white">Billing Address</h3>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="billing_address" className="text-sm font-medium text-gray-200">
                Address
              </Label>
              <Input
                id="billing_address"
                value={profileData.billing_address}
                onChange={(e) => updateField('billing_address', e.target.value)}
                disabled={!isEditing}
                placeholder="123 Business Street"
                className="bg-gray-800/50 border-gray-600 text-white placeholder-gray-400 focus:border-blue-500 disabled:opacity-60"
              />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="city" className="text-sm font-medium text-gray-200">
                  City
                </Label>
                <Input
                  id="city"
                  value={profileData.city}
                  onChange={(e) => updateField('city', e.target.value)}
                  disabled={!isEditing}
                  placeholder="New York"
                  className="bg-gray-800/50 border-gray-600 text-white placeholder-gray-400 focus:border-blue-500 disabled:opacity-60"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="postal_code" className="text-sm font-medium text-gray-200">
                  Postal Code
                </Label>
                <Input
                  id="postal_code"
                  value={profileData.postal_code}
                  onChange={(e) => updateField('postal_code', e.target.value)}
                  disabled={!isEditing}
                  placeholder="10001"
                  className="bg-gray-800/50 border-gray-600 text-white placeholder-gray-400 focus:border-blue-500 disabled:opacity-60"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="country" className="text-sm font-medium text-gray-200">
                  Country
                </Label>
                <Input
                  id="country"
                  value={profileData.country}
                  onChange={(e) => updateField('country', e.target.value)}
                  disabled={!isEditing}
                  placeholder="United States"
                  className="bg-gray-800/50 border-gray-600 text-white placeholder-gray-400 focus:border-blue-500 disabled:opacity-60"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Tax Information */}
        <div className="space-y-4">
          <h3 className="text-lg font-semibold text-white">Tax Information</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="tax_id" className="text-sm font-medium text-gray-200">
                Tax ID
              </Label>
              <Input
                id="tax_id"
                value={profileData.tax_id}
                onChange={(e) => updateField('tax_id', e.target.value)}
                disabled={!isEditing}
                placeholder="123-45-6789"
                className="bg-gray-800/50 border-gray-600 text-white placeholder-gray-400 focus:border-blue-500 disabled:opacity-60"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="vat_number" className="text-sm font-medium text-gray-200">
                VAT Number
              </Label>
              <Input
                id="vat_number"
                value={profileData.vat_number}
                onChange={(e) => updateField('vat_number', e.target.value)}
                disabled={!isEditing}
                placeholder="DE123456789"
                className="bg-gray-800/50 border-gray-600 text-white placeholder-gray-400 focus:border-blue-500 disabled:opacity-60"
              />
            </div>
          </div>
        </div>

        {/* Profile Actions */}
        {hasProfile && !isEditing && (
          <div className="flex justify-end pt-4 border-t border-gray-700">
            <Button
              onClick={handleDelete}
              variant="outline"
              className="border-red-600 text-red-400 hover:bg-red-600 hover:text-white"
              disabled={isLoading}
            >
              {isLoading ? 'Deleting...' : 'Delete Profile'}
            </Button>
          </div>
        )}

        {/* Profile Metadata */}
        {hasProfile && profileData.created_at && (
          <div className="mt-6 pt-4 border-t border-gray-700">
            <div className="text-sm text-gray-400">
              <p>Profile created: {new Date(profileData.created_at).toLocaleDateString()}</p>
              {profileData.updated_at && (
                <p>Last updated: {new Date(profileData.updated_at).toLocaleDateString()}</p>
              )}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
