import React, { useState, useEffect, useRef } from 'react';
import { 
  MessageSquare, 
  Send, 
  Plus, 
  Hash, 
  Users, 
  Heart, 
  ThumbsUp, 
  Smile,
  X,
  Trash2
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import { toast } from 'sonner';
import { useUserGuardContext } from 'app/auth';
import { WS_API_URL } from 'app';
import brain from 'brain';
import type { 
  ChatMessage, 
  ChatThread, 
  CreateThreadRequest, 
  SendMessageRequest 
} from 'types';

interface Props {}

const CommunityChat: React.FC<Props> = () => {
  const { user } = useUserGuardContext();
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [threads, setThreads] = useState<ChatThread[]>([]);
  const [currentThread, setCurrentThread] = useState<string | null>(null);
  const [newMessage, setNewMessage] = useState('');
  const [showCreateThread, setShowCreateThread] = useState(false);
  const [newThreadTitle, setNewThreadTitle] = useState('');
  const [newThreadDescription, setNewThreadDescription] = useState('');
  const [loading, setLoading] = useState(false);
  const [ws, setWs] = useState<WebSocket | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const wsRef = useRef<WebSocket | null>(null);

  // Check if user is admin
  const isAdmin = () => {
    const adminEmails = [
      'admin@respectus.com',
      'patrick.goergen@respectus.com', 
      'support@respectus.com'
    ];
    return adminEmails.includes(user?.primaryEmail || '');
  };

  // Scroll to bottom when new messages arrive
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // Initialize WebSocket connection
  const connectWebSocket = async () => {
    try {
      // Import auth utilities
      const { auth } = await import('app');
      const token = await auth.getAuthToken();
      
      // Fix WebSocket URL construction
      const wsUrl = `${WS_API_URL.replace(/^http/, 'ws')}/community-chat/ws`;
      const protocols = ['databutton.app', `Authorization.Bearer.${token}`];
      
      const websocket = new WebSocket(wsUrl, protocols);
      
      websocket.onopen = () => {
        console.log('WebSocket connected to:', wsUrl);
        setWs(websocket);
        wsRef.current = websocket;
      };
      
      websocket.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          
          if (data.type === 'new_message') {
            setMessages(prev => {
              // Avoid duplicates
              const exists = prev.some(msg => msg.id === data.message.id);
              if (exists) return prev;
              return [...prev, data.message];
            });
          } else if (data.type === 'reaction_update') {
            setMessages(prev => prev.map(msg => 
              msg.id === data.message_id 
                ? { ...msg, reactions: data.reactions }
                : msg
            ));
          } else if (data.type === 'message_deleted') {
            setMessages(prev => prev.filter(msg => msg.id !== data.message_id));
          }
        } catch (error) {
          console.error('Error parsing WebSocket message:', error);
        }
      };
      
      websocket.onerror = (error) => {
        console.error('WebSocket error:', error);
        toast.error('Connection error. Please refresh the page.');
      };
      
      websocket.onclose = (event) => {
        console.log('WebSocket disconnected:', event.code, event.reason);
        setWs(null);
        wsRef.current = null;
        // Attempt to reconnect after 3 seconds
        setTimeout(connectWebSocket, 3000);
      };
      
    } catch (error) {
      console.error('Failed to connect WebSocket:', error);
      toast.error('Failed to connect to chat. Please refresh the page.');
    }
  };

  // Load initial data
  useEffect(() => {
    const loadInitialData = async () => {
      setLoading(true);
      try {
        // Load threads
        const threadsResponse = await brain.get_chat_threads();
        if (threadsResponse.ok) {
          const threadsData = await threadsResponse.json();
          setThreads(threadsData);
        }
        
        // Load general messages (no thread)
        const messagesResponse = await brain.get_chat_messages({ thread_id: null });
        if (messagesResponse.ok) {
          const messagesData = await messagesResponse.json();
          setMessages(messagesData);
        }
        
        // Connect WebSocket
        await connectWebSocket();
        
      } catch (error) {
        console.error('Error loading chat data:', error);
        toast.error('Failed to load chat data');
      } finally {
        setLoading(false);
      }
    };

    loadInitialData();

    // Cleanup on unmount
    return () => {
      if (wsRef.current) {
        wsRef.current.close();
      }
    };
  }, []);

  // Load messages for specific thread
  const loadThreadMessages = async (threadId: string | null) => {
    try {
      const response = await brain.get_chat_messages({ thread_id: threadId });
      if (response.ok) {
        const data = await response.json();
        setMessages(data);
        setCurrentThread(threadId);
      }
    } catch (error) {
      console.error('Error loading thread messages:', error);
      toast.error('Failed to load messages');
    }
  };

  // Send message
  const sendMessage = async () => {
    if (!newMessage.trim()) return;
    
    try {
      const messageData: SendMessageRequest = {
        content: newMessage,
        message_type: 'message',
        thread_id: currentThread
      };
      
      // Send via HTTP API
      const response = await brain.send_message(messageData);
      if (response.ok) {
        const messageResponse = await response.json();
        setMessages(prev => [...prev, messageResponse]);
        toast.success('Message sent');
      } else {
        throw new Error('Failed to send message');
      }
      
      setNewMessage('');
    } catch (error) {
      console.error('Error sending message:', error);
      toast.error('Failed to send message');
    }
  };

  // Create new thread
  const createThread = async () => {
    if (!newThreadTitle.trim()) {
      toast.error('Thread title is required');
      return;
    }
    
    try {
      const threadData: CreateThreadRequest = {
        title: newThreadTitle,
        description: newThreadDescription || undefined
      };
      
      const response = await brain.create_chat_thread(threadData);
      if (response.ok) {
        const newThread = await response.json();
        setThreads(prev => [newThread, ...prev]);
        setShowCreateThread(false);
        setNewThreadTitle('');
        setNewThreadDescription('');
        toast.success('Thread created successfully');
      } else {
        throw new Error('Failed to create thread');
      }
    } catch (error) {
      console.error('Error creating thread:', error);
      toast.error('Failed to create thread');
    }
  };

  // React to message
  const reactToMessage = async (messageId: string, reactionType: string) => {
    try {
      const response = await brain.react_to_message(
        { messageId },
        {
          reaction_type: reactionType
        }
      );
      
      if (response.ok) {
        toast.success('Reaction added');
        // Reload messages to get updated reactions
        await loadThreadMessages(currentThread);
      } else {
        throw new Error('Failed to add reaction');
      }
    } catch (error) {
      console.error('Error reacting to message:', error);
      toast.error('Failed to react to message');
    }
  };

  // Delete message (admin or message owner)
  const deleteMessage = async (messageId: string) => {
    try {
      const response = await brain.delete_message({ messageId });
      
      if (response.ok) {
        toast.success('Message deleted successfully');
        // Reload messages to reflect deletion
        loadThreadMessages(currentThread);
      } else {
        throw new Error('Failed to delete message');
      }
    } catch (error) {
      console.error('Error deleting message:', error);
      toast.error('Failed to delete message');
    }
  };

  const formatTime = (dateString: string) => {
    return new Date(dateString).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString();
  };

  return (
    <div className="bg-gradient-to-br from-green-900/20 to-emerald-800/10 backdrop-blur-sm border border-green-500/20 rounded-2xl p-8 h-[800px] flex">
      {/* Sidebar - Threads */}
      <div className="w-80 border-r border-green-500/20 pr-6 flex flex-col">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-green-500/20 rounded-xl">
              <MessageSquare className="w-8 h-8 text-green-400" />
            </div>
            <div>
              <h2 className="text-2xl font-bold text-white">Community Hub</h2>
              <p className="text-green-200/80 text-sm">Connect with compliance professionals</p>
            </div>
          </div>
        </div>
        
        <Button 
          onClick={() => setShowCreateThread(true)}
          className="mb-4 bg-green-600 hover:bg-green-700 text-white"
        >
          <Plus className="w-4 h-4 mr-2" />
          New Thread
        </Button>
        
        {/* General Chat */}
        <div className="mb-4">
          <Button
            variant={currentThread === null ? "default" : "ghost"}
            onClick={() => loadThreadMessages(null)}
            className="w-full justify-start text-left p-3 h-auto"
          >
            <Hash className="w-5 h-5 mr-3 text-green-400" />
            <div>
              <div className="font-semibold text-white">General Chat</div>
              <div className="text-xs text-gray-400">Open discussion</div>
            </div>
          </Button>
        </div>
        
        {/* Thread List */}
        <div className="flex-1 overflow-y-auto space-y-2">
          {threads.map((thread) => (
            <Button
              key={thread.id}
              variant={currentThread === thread.id ? "default" : "ghost"}
              onClick={() => loadThreadMessages(thread.id)}
              className="w-full justify-start text-left p-3 h-auto"
            >
              <MessageSquare className="w-5 h-5 mr-3 text-green-400" />
              <div className="flex-1">
                <div className="font-semibold text-white line-clamp-1">{thread.title}</div>
                <div className="text-xs text-gray-400 line-clamp-1">
                  {thread.message_count} messages
                  {thread.last_message_at && ` • ${formatDate(thread.last_message_at)}`}
                </div>
              </div>
            </Button>
          ))}
        </div>
        
        {/* Online Users */}
        <div className="mt-4 pt-4 border-t border-green-700/30">
          <div className="flex items-center gap-2 text-sm text-green-300/70">
            <Users className="w-4 h-4" />
            <span>Community Active</span>
            <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse ml-auto"></div>
          </div>
        </div>
      </div>
      
      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col pl-6">
        {/* Chat Header */}
        <div className="border-b border-green-500/20 pb-4 mb-4">
          <h3 className="text-xl font-bold text-white">
            {currentThread ? 
              threads.find(t => t.id === currentThread)?.title || 'Thread'
              : 'General Chat'
            }
          </h3>
          <p className="text-green-200/80 text-sm">
            {currentThread ? 
              threads.find(t => t.id === currentThread)?.description || 'Thread discussion'
              : 'Open discussion for all compliance topics'
            }
          </p>
        </div>
        
        {/* Messages Area */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.length === 0 ? (
            <div className="text-center text-gray-400 mt-8">
              <MessageSquare className="w-12 h-12 mx-auto mb-4 opacity-50" />
              <p>No messages yet. Start the conversation!</p>
            </div>
          ) : (
            messages.map((message) => (
              <div key={message.id} className="group flex items-start space-x-3">
                <div className="w-8 h-8 bg-green-600 rounded-full flex items-center justify-center text-white text-sm font-medium">
                  {message.username?.charAt(0).toUpperCase()}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center space-x-2 mb-1">
                    <span className="text-sm font-medium text-white">{message.username}</span>
                    <span className="text-xs text-gray-400">{formatTime(message.created_at)}</span>
                    {/* Delete button - show for message owner or admin */}
                    {(message.user_id === user.sub || isAdmin()) && (
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => deleteMessage(message.id)}
                        className="opacity-0 group-hover:opacity-100 transition-opacity h-6 w-6 p-0 text-red-400 hover:text-red-300 hover:bg-red-500/10"
                        title={isAdmin() ? "Delete message (Admin)" : "Delete your message"}
                      >
                        <Trash2 className="w-3 h-3" />
                      </Button>
                    )}
                  </div>
                  <p className="text-gray-300 text-sm break-words">{message.content}</p>
                  
                  {/* Reactions */}
                  <div className="flex items-center space-x-2 mt-2">
                    <div className="flex space-x-1">
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => reactToMessage(message.id, 'like')}
                        className="h-6 px-2 text-xs text-gray-400 hover:text-white hover:bg-green-500/20"
                      >
                        <ThumbsUp className="w-3 h-3 mr-1" />
                        {message.reactions?.like?.length || 0}
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => reactToMessage(message.id, 'heart')}
                        className="h-6 px-2 text-xs text-gray-400 hover:text-white hover:bg-red-500/20"
                      >
                        <Heart className="w-3 h-3 mr-1" />
                        {message.reactions?.heart?.length || 0}
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            ))
          )}
          <div ref={messagesEndRef} />
        </div>
        
        {/* Message Input */}
        <div className="flex gap-2">
          <Input
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && sendMessage()}
            placeholder="Type your message..."
            className="flex-1 bg-gray-800 border-green-500/20 text-white placeholder:text-gray-500"
          />
          <Button 
            onClick={sendMessage}
            disabled={!newMessage.trim()}
            className="bg-green-600 hover:bg-green-700"
          >
            <Send className="w-4 h-4" />
          </Button>
        </div>
      </div>
      
      {/* Create Thread Dialog */}
      <Dialog open={showCreateThread} onOpenChange={setShowCreateThread}>
        <DialogContent className="bg-gray-800 border-gray-700">
          <DialogHeader>
            <DialogTitle className="text-white">Create New Thread</DialogTitle>
            <DialogDescription className="text-gray-400">
              Start a new discussion topic for the community
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label className="text-sm font-medium text-gray-300 mb-2 block">Thread Title</Label>
              <Input
                value={newThreadTitle}
                onChange={(e) => setNewThreadTitle(e.target.value)}
                placeholder="What would you like to discuss?"
                className="bg-gray-700 border-gray-600 text-white"
              />
            </div>
            <div>
              <Label className="text-sm font-medium text-gray-300 mb-2 block">Description (Optional)</Label>
              <Textarea
                value={newThreadDescription}
                onChange={(e) => setNewThreadDescription(e.target.value)}
                placeholder="Provide more context about this discussion..."
                className="bg-gray-700 border-gray-600 text-white"
                rows={3}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowCreateThread(false)}>
              Cancel
            </Button>
            <Button 
              onClick={createThread}
              disabled={!newThreadTitle.trim()}
              className="bg-green-600 hover:bg-green-700"
            >
              Create Thread
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default CommunityChat;
