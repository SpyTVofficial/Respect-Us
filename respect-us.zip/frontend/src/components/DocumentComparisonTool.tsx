import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  GitCompare, 
  FileText, 
  BarChart3, 
  Download, 
  Loader2, 
  AlertCircle, 
  CheckCircle, 
  ExternalLink,
  Scale,
  Globe,
  Calendar,
  TrendingUp,
  Minus,
  Plus,
  Eye
} from 'lucide-react';
import { toast } from 'sonner';
import brain from 'brain';
import { DocumentResponse, ComparisonRequest, ComparisonResult, DocumentComparison } from '../brain/data-contracts';

interface Props {
  documents?: DocumentResponse[];
  onClose?: () => void;
  preselectedDocuments?: number[];
}

export const DocumentComparisonTool: React.FC<Props> = ({ 
  documents = [], 
  onClose,
  preselectedDocuments = []
}) => {
  const [open, setOpen] = useState(false);
  const [selectedDocuments, setSelectedDocuments] = useState<number[]>(preselectedDocuments);
  const [comparisonType, setComparisonType] = useState<string>('general');
  const [focusAreas, setFocusAreas] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);
  const [comparisonResult, setComparisonResult] = useState<ComparisonResult | null>(null);
  const [availableDocuments, setAvailableDocuments] = useState<DocumentResponse[]>(documents);
  const [suggestions, setSuggestions] = useState<any[]>([]);
  const [loadingSuggestions, setLoadingSuggestions] = useState(false);
  const [activeTab, setActiveTab] = useState('select');

  useEffect(() => {
    if (preselectedDocuments.length > 0) {
      setSelectedDocuments(preselectedDocuments);
      if (preselectedDocuments.length >= 2) {
        setActiveTab('configure');
      }
    }
  }, [preselectedDocuments]);

  useEffect(() => {
    if (documents.length > 0) {
      setAvailableDocuments(documents);
    } else {
      loadAvailableDocuments();
    }
  }, [documents]);

  const loadAvailableDocuments = async () => {
    try {
      const response = await brain.get_document_list({ limit: 50, offset: 0 });
      if (response.ok) {
        const data = await response.json();
        setAvailableDocuments(Array.isArray(data) ? data : data.documents || []);
      }
    } catch (error) {
      console.error('Failed to load documents:', error);
      toast.error('Failed to load documents');
    }
  };

  const loadSuggestions = async (documentId: number) => {
    try {
      setLoadingSuggestions(true);
      const response = await brain.get_comparison_suggestions({ document_id: documentId, limit: 5 });
      if (response.ok) {
        const data = await response.json();
        setSuggestions(data);
      }
    } catch (error) {
      console.error('Failed to load suggestions:', error);
      toast.error('Failed to load comparison suggestions');
    } finally {
      setLoadingSuggestions(false);
    }
  };

  const handleDocumentSelect = (documentId: number, checked: boolean) => {
    if (checked) {
      if (selectedDocuments.length >= 5) {
        toast.error('Maximum 5 documents can be compared at once');
        return;
      }
      setSelectedDocuments(prev => [...prev, documentId]);
      
      // Load suggestions if this is the first document
      if (selectedDocuments.length === 0) {
        loadSuggestions(documentId);
      }
    } else {
      setSelectedDocuments(prev => prev.filter(id => id !== documentId));
    }
  };

  const handleAddSuggestion = (suggestionId: number) => {
    if (selectedDocuments.length >= 5) {
      toast.error('Maximum 5 documents can be compared at once');
      return;
    }
    if (!selectedDocuments.includes(suggestionId)) {
      setSelectedDocuments(prev => [...prev, suggestionId]);
    }
  };

  const handleFocusAreaToggle = (area: string, checked: boolean) => {
    if (checked) {
      setFocusAreas(prev => [...prev, area]);
    } else {
      setFocusAreas(prev => prev.filter(a => a !== area));
    }
  };

  const performComparison = async () => {
    if (selectedDocuments.length < 2) {
      toast.error('Please select at least 2 documents to compare');
      return;
    }

    try {
      setLoading(true);
      const request: ComparisonRequest = {
        document_ids: selectedDocuments,
        comparison_type: comparisonType,
        focus_areas: focusAreas
      };

      const response = await brain.compare_documents(request);
      if (response.ok) {
        const result = await response.json();
        setComparisonResult(result);
        setActiveTab('results');
        toast.success('Document comparison completed successfully!');
      } else {
        throw new Error('Comparison failed');
      }
    } catch (error) {
      console.error('Comparison error:', error);
      toast.error('Failed to perform document comparison');
    } finally {
      setLoading(false);
    }
  };

  const exportComparison = async (format: string) => {
    if (!comparisonResult) return;
    
    try {
      // Implementation would depend on export API
      toast.info(`Export to ${format.toUpperCase()} requested`);
    } catch (error) {
      toast.error('Export failed');
    }
  };

  const getSelectedDocumentTitles = () => {
    return selectedDocuments.map(id => {
      const doc = availableDocuments.find(d => d.id === id);
      return doc ? doc.title : `Document ${id}`;
    });
  };

  const getSimilarityColor = (score: number) => {
    if (score >= 0.8) return 'text-green-600 dark:text-green-400';
    if (score >= 0.6) return 'text-yellow-600 dark:text-yellow-400';
    if (score >= 0.4) return 'text-orange-600 dark:text-orange-400';
    return 'text-red-600 dark:text-red-400';
  };

  const getSimilarityBadge = (score: number) => {
    if (score >= 0.8) return 'High Similarity';
    if (score >= 0.6) return 'Moderate Similarity';
    if (score >= 0.4) return 'Low Similarity';
    return 'Very Different';
  };

  const focusAreaOptions = [
    { value: 'definitions', label: 'Definitions' },
    { value: 'requirements', label: 'Requirements' },
    { value: 'penalties', label: 'Penalties' },
    { value: 'procedures', label: 'Procedures' },
    { value: 'exemptions', label: 'Exemptions' }
  ];

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <Button 
        onClick={() => setOpen(true)}
        className="flex items-center gap-2 bg-purple-600 hover:bg-purple-700 text-white"
      >
        <GitCompare className="h-4 w-4" />
        Compare Documents
      </Button>
      
      <DialogContent className="max-w-7xl max-h-[90vh] overflow-hidden">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <GitCompare className="h-5 w-5 text-purple-600" />
            Document Comparison Tool
          </DialogTitle>
          <DialogDescription>
            Compare regulations across jurisdictions and analyze differences
          </DialogDescription>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="h-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="select">Select Documents</TabsTrigger>
            <TabsTrigger value="configure" disabled={selectedDocuments.length < 2}>
              Configure Analysis
            </TabsTrigger>
            <TabsTrigger value="results" disabled={!comparisonResult}>
              View Results
            </TabsTrigger>
          </TabsList>

          <TabsContent value="select" className="space-y-4 h-[calc(100%-8rem)] overflow-auto">
            <div className="space-y-4">
              <div>
                <h3 className="text-lg font-semibold mb-2">Available Documents</h3>
                <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">
                  Select 2-5 documents to compare. Choose documents from different jurisdictions or versions for best analysis.
                </p>
              </div>

              {selectedDocuments.length > 0 && (
                <Card className="bg-purple-50 dark:bg-purple-900/20 border-purple-200 dark:border-purple-800">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm">Selected Documents ({selectedDocuments.length}/5)</CardTitle>
                  </CardHeader>
                  <CardContent className="pt-0">
                    <div className="space-y-2">
                      {getSelectedDocumentTitles().map((title, index) => (
                        <div key={index} className="flex items-center gap-2">
                          <CheckCircle className="h-4 w-4 text-green-600" />
                          <span className="text-sm">{title}</span>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}

              {suggestions.length > 0 && (
                <Card className="bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-800">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm flex items-center gap-2">
                      <TrendingUp className="h-4 w-4" />
                      Suggested Comparisons
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="pt-0">
                    <div className="space-y-2">
                      {suggestions.map((suggestion) => (
                        <div key={suggestion.id} className="flex items-center justify-between p-2 bg-white dark:bg-gray-800 rounded border">
                          <div className="flex-1">
                            <div className="font-medium text-sm">{suggestion.title}</div>
                            <div className="text-xs text-gray-600 dark:text-gray-400">
                              {suggestion.reason}
                            </div>
                          </div>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleAddSuggestion(suggestion.id)}
                            disabled={selectedDocuments.includes(suggestion.id)}
                          >
                            {selectedDocuments.includes(suggestion.id) ? 'Added' : 'Add'}
                          </Button>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}

              <div className="grid grid-cols-1 gap-4 max-h-96 overflow-auto">
                {availableDocuments.map((doc) => (
                  <Card key={doc.id} className="hover:shadow-md transition-shadow">
                    <CardContent className="p-4">
                      <div className="flex items-start gap-3">
                        <Checkbox
                          checked={selectedDocuments.includes(doc.id)}
                          onCheckedChange={(checked) => handleDocumentSelect(doc.id, checked as boolean)}
                        />
                        <div className="flex-1">
                          <h4 className="font-medium text-sm mb-1">{doc.title}</h4>
                          <p className="text-xs text-gray-600 dark:text-gray-400 mb-2 line-clamp-2">
                            {doc.description}
                          </p>
                          <div className="flex items-center gap-2 text-xs">
                            <Badge variant="outline">{doc.country_jurisdiction}</Badge>
                            <Badge variant="outline">{doc.regulation_type}</Badge>
                            {doc.publication_date && (
                              <span className="text-gray-500">
                                {new Date(doc.publication_date).getFullYear()}
                              </span>
                            )}
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </TabsContent>

          <TabsContent value="configure" className="space-y-4">
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-semibold mb-4">Comparison Configuration</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div>
                      <Label className="text-sm font-medium mb-2 block">Comparison Type</Label>
                      <Select value={comparisonType} onValueChange={setComparisonType}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="general">General Comparison</SelectItem>
                          <SelectItem value="jurisdiction">Cross-Jurisdictional</SelectItem>
                          <SelectItem value="version">Version Comparison</SelectItem>
                          <SelectItem value="regulation_type">Regulation Type</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label className="text-sm font-medium mb-3 block">Focus Areas (Optional)</Label>
                      <div className="space-y-2">
                        {focusAreaOptions.map((area) => (
                          <div key={area.value} className="flex items-center space-x-2">
                            <Checkbox
                              id={area.value}
                              checked={focusAreas.includes(area.value)}
                              onCheckedChange={(checked) => handleFocusAreaToggle(area.value, checked as boolean)}
                            />
                            <Label htmlFor={area.value} className="text-sm">{area.label}</Label>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div>
                      <Label className="text-sm font-medium mb-2 block">Selected Documents</Label>
                      <div className="space-y-2">
                        {getSelectedDocumentTitles().map((title, index) => (
                          <div key={index} className="p-2 bg-gray-50 dark:bg-gray-800 rounded text-sm">
                            {title}
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex justify-end gap-2">
                <Button
                  onClick={performComparison}
                  disabled={selectedDocuments.length < 2 || loading}
                  className="bg-purple-600 hover:bg-purple-700"
                >
                  {loading ? (
                    <>
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      Analyzing...
                    </>
                  ) : (
                    <>
                      <GitCompare className="h-4 w-4 mr-2" />
                      Start Comparison
                    </>
                  )}
                </Button>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="results" className="space-y-4 h-[calc(100%-8rem)] overflow-auto">
            {comparisonResult && (
              <div className="space-y-6">
                {/* Summary Section */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <BarChart3 className="h-5 w-5" />
                      Comparison Summary
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      <div className="text-center">
                        <div className="text-2xl font-bold text-purple-600">
                          {comparisonResult.summary.total_documents}
                        </div>
                        <div className="text-sm text-gray-600 dark:text-gray-400">Documents</div>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-blue-600">
                          {(comparisonResult.summary.average_similarity * 100).toFixed(1)}%
                        </div>
                        <div className="text-sm text-gray-600 dark:text-gray-400">Avg Similarity</div>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-orange-600">
                          {comparisonResult.summary.total_differences_found}
                        </div>
                        <div className="text-sm text-gray-600 dark:text-gray-400">Differences</div>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-green-600">
                          {comparisonResult.summary.jurisdictions_covered.length}
                        </div>
                        <div className="text-sm text-gray-600 dark:text-gray-400">Jurisdictions</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Pairwise Comparisons */}
                <Card>
                  <CardHeader>
                    <CardTitle>Detailed Comparisons</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {comparisonResult.comparisons.map((comparison, index) => (
                        <Card key={index} className="border-l-4 border-l-purple-500">
                          <CardHeader className="pb-3">
                            <div className="flex items-center justify-between">
                              <div className="space-y-1">
                                <div className="font-medium text-sm">
                                  {comparison.document1_title} vs {comparison.document2_title}
                                </div>
                                <div className="flex items-center gap-2">
                                  <Badge variant="outline" className="text-xs">
                                    {comparison.comparison_type}
                                  </Badge>
                                  <Badge 
                                    variant="outline" 
                                    className={`text-xs ${getSimilarityColor(comparison.similarity_score)}`}
                                  >
                                    {getSimilarityBadge(comparison.similarity_score)}
                                  </Badge>
                                  <span className="text-sm font-mono">
                                    {(comparison.similarity_score * 100).toFixed(1)}%
                                  </span>
                                </div>
                              </div>
                            </div>
                          </CardHeader>
                          <CardContent className="pt-0">
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                              <div>
                                <h5 className="font-medium text-sm mb-2">Key Differences ({comparison.differences.length})</h5>
                                <div className="space-y-1 max-h-32 overflow-auto">
                                  {comparison.differences.slice(0, 5).map((diff: any, idx: number) => (
                                    <div key={idx} className="text-xs p-2 bg-gray-50 dark:bg-gray-800 rounded">
                                      {diff.section || diff.field || 'Content difference'}
                                    </div>
                                  ))}
                                  {comparison.differences.length > 5 && (
                                    <div className="text-xs text-gray-500">
                                      +{comparison.differences.length - 5} more differences
                                    </div>
                                  )}
                                </div>
                              </div>
                              <div>
                                <h5 className="font-medium text-sm mb-2">Common Sections ({comparison.common_sections.length})</h5>
                                <div className="space-y-1 max-h-32 overflow-auto">
                                  {comparison.common_sections.slice(0, 3).map((section: string, idx: number) => (
                                    <div key={idx} className="text-xs p-2 bg-green-50 dark:bg-green-900/20 rounded">
                                      {section.substring(0, 100)}...
                                    </div>
                                  ))}
                                  {comparison.common_sections.length > 3 && (
                                    <div className="text-xs text-gray-500">
                                      +{comparison.common_sections.length - 3} more sections
                                    </div>
                                  )}
                                </div>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                {/* Export Options */}
                <Card>
                  <CardHeader>
                    <CardTitle>Export Results</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex gap-2">
                      <Button 
                        variant="outline" 
                        onClick={() => exportComparison('pdf')}
                        className="flex items-center gap-2"
                      >
                        <Download className="h-4 w-4" />
                        Export PDF
                      </Button>
                      <Button 
                        variant="outline" 
                        onClick={() => exportComparison('html')}
                        className="flex items-center gap-2"
                      >
                        <Download className="h-4 w-4" />
                        Export HTML
                      </Button>
                      <Button 
                        variant="outline" 
                        onClick={() => exportComparison('json')}
                        className="flex items-center gap-2"
                      >
                        <Download className="h-4 w-4" />
                        Export JSON
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}
          </TabsContent>
        </Tabs>

        <DialogFooter>
          <Button variant="outline" onClick={onClose || (() => setOpen(false))}>
            Close
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default DocumentComparisonTool;
