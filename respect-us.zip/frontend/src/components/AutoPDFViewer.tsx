import React, { useState, useEffect, startTransition } from 'react';
import { PDFLoader } from './PDFLoader';

interface Props {
  documentId: number;
  documentTitle: string;
  shouldAutoOpen: boolean;
  fileType?: string;
}

export const AutoPDFViewer: React.FC<Props> = ({ 
  documentId, 
  documentTitle, 
  shouldAutoOpen,
  fileType 
}) => {
  const [showPDF, setShowPDF] = useState(false);

  useEffect(() => {
    if (shouldAutoOpen && fileType === 'application/pdf') {
      startTransition(() => {
        setShowPDF(true);
      });
    }
  }, [shouldAutoOpen, fileType]);

  const handleClosePDF = () => {
    startTransition(() => {
      setShowPDF(false);
    });
  };

  if (!shouldAutoOpen || fileType !== 'application/pdf') {
    return null;
  }

  return (
    <React.Suspense fallback={null}>
      <PDFLoader
        documentId={documentId}
        documentTitle={documentTitle}
        isOpen={showPDF}
        onClose={handleClosePDF}
      />
    </React.Suspense>
  );
};
