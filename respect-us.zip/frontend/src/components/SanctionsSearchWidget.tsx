
import React, { useState, useCallback } from 'react';
import SearchWidget, { SearchResult, createSearchConfig } from 'components/SearchWidget';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { AlertTriangle, User, Building, Ship, Plane, ExternalLink, Calendar, MapPin } from 'lucide-react';
import { toast } from 'sonner';
import brain from 'brain';
import { SanctionEntity, SanctionSearchRequest } from 'brain/data-contracts';

interface SanctionsSearchWidgetProps {
  open: boolean;
  onClose: () => void;
  onSelectionConfirmed?: (entities: SanctionEntity[]) => void;
  initialQuery?: string;
  multiSelect?: boolean;
}

export default function SanctionsSearchWidget({
  open,
  onClose,
  onSelectionConfirmed,
  initialQuery = '',
  multiSelect = false
}: SanctionsSearchWidgetProps) {
  const [jurisdictions, setJurisdictions] = useState<string[]>([]);
  const [programs, setPrograms] = useState<string[]>([]);
  const [entityTypes, setEntityTypes] = useState<string[]>([]);
  const [riskLevels, setRiskLevels] = useState<string[]>([]);

  // Load filter options when component mounts
  React.useEffect(() => {
    const loadFilterOptions = async () => {
      try {
        const [jurisdictionsRes, programsRes, entityTypesRes, riskLevelsRes] = await Promise.all([
          brain.get_sanctions_jurisdictions(),
          brain.get_sanctions_programs(),
          brain.get_entity_types(),
          brain.get_risk_levels()
        ]);

        if (jurisdictionsRes.ok) {
          const data = await jurisdictionsRes.json();
          setJurisdictions(data);
        }
        if (programsRes.ok) {
          const data = await programsRes.json();
          setPrograms(data);
        }
        if (entityTypesRes.ok) {
          const data = await entityTypesRes.json();
          setEntityTypes(data);
        }
        if (riskLevelsRes.ok) {
          const data = await riskLevelsRes.json();
          setRiskLevels(data);
        }
      } catch (error) {
        console.error('Error loading filter options:', error);
      }
    };

    if (open) {
      loadFilterOptions();
    }
  }, [open]);

  const searchSanctions = useCallback(async (query: string, filters: Record<string, any> = {}): Promise<SearchResult[]> => {
    try {
      const searchRequest: SanctionSearchRequest = {
        query,
        entity_type: filters.entity_type || undefined,
        jurisdiction: filters.jurisdiction || undefined,
        sanctions_program: filters.sanctions_program || undefined,
        risk_level: filters.risk_level || undefined,
        limit: 50,
        exact_match: false
      };

      const response = await brain.search_sanctions(searchRequest);
      
      if (!response.ok) {
        throw new Error('Search failed');
      }

      const data = await response.json();
      
      // Convert SanctionEntity to SearchResult
      return data.entities.map((entity: SanctionEntity): SearchResult => ({
        id: entity.id,
        title: entity.name,
        description: entity.description || `${entity.entity_type} - ${entity.sanctions_program}`,
        details: {
          entity_type: entity.entity_type,
          jurisdiction: entity.jurisdiction,
          sanctions_program: entity.sanctions_program,
          risk_level: entity.risk_level,
          aliases: entity.aliases,
          date_added: entity.date_added,
          source_list: entity.source_list,
          ...entity.details
        },
        tags: [
          entity.entity_type,
          entity.jurisdiction,
          entity.risk_level,
          entity.source_list
        ],
        type: 'sanction_entity'
      }));
    } catch (error) {
      console.error('Sanctions search error:', error);
      toast.error('Failed to search sanctions lists');
      return [];
    }
  }, []);

  const handleSelectionConfirmed = (results: SearchResult[]) => {
    if (onSelectionConfirmed) {
      // Convert SearchResult back to SanctionEntity
      const entities: SanctionEntity[] = results.map(result => ({
        id: result.id,
        name: result.title,
        entity_type: result.details?.entity_type || 'unknown',
        aliases: result.details?.aliases || [],
        sanctions_program: result.details?.sanctions_program || '',
        jurisdiction: result.details?.jurisdiction || '',
        risk_level: result.details?.risk_level || 'unknown',
        description: result.description,
        date_added: result.details?.date_added || new Date().toISOString(),
        source_list: result.details?.source_list || '',
        details: result.details || {}
      }));
      
      onSelectionConfirmed(entities);
    }
  };

  const getEntityIcon = (entityType: string) => {
    switch (entityType) {
      case 'person': return <User className="h-4 w-4" />;
      case 'entity': return <Building className="h-4 w-4" />;
      case 'vessel': return <Ship className="h-4 w-4" />;
      case 'aircraft': return <Plane className="h-4 w-4" />;
      default: return <AlertTriangle className="h-4 w-4" />;
    }
  };

  const getRiskLevelColor = (riskLevel: string) => {
    switch (riskLevel) {
      case 'high': return 'bg-red-600 text-white';
      case 'medium': return 'bg-yellow-600 text-white';
      case 'low': return 'bg-green-600 text-white';
      default: return 'bg-gray-600 text-white';
    }
  };

  const SanctionResultTemplate = ({ result }: { result: SearchResult }) => {
    const entityType = result.details?.entity_type || 'unknown';
    const riskLevel = result.details?.risk_level || 'unknown';
    const jurisdiction = result.details?.jurisdiction || '';
    const aliases = result.details?.aliases || [];
    const dateAdded = result.details?.date_added;

    return (
      <Card className="cursor-pointer transition-all hover:shadow-md border border-gray-700 hover:border-gray-600 bg-gray-800">
        <CardContent className="p-4">
          <div className="flex items-start justify-between mb-3">
            <div className="flex items-center gap-2">
              {getEntityIcon(entityType)}
              <h4 className="font-semibold text-white">{result.title}</h4>
            </div>
            <Badge className={getRiskLevelColor(riskLevel)}>
              {riskLevel.toUpperCase()}
            </Badge>
          </div>

          {result.description && (
            <p className="text-sm text-gray-400 mb-3">{result.description}</p>
          )}

          {aliases.length > 0 && (
            <div className="mb-3">
              <p className="text-xs text-gray-500 mb-1">Known aliases:</p>
              <div className="flex flex-wrap gap-1">
                {aliases.slice(0, 3).map((alias: string, index: number) => (
                  <Badge key={index} variant="outline" className="text-xs border-gray-600 text-gray-300">
                    {alias}
                  </Badge>
                ))}
                {aliases.length > 3 && (
                  <Badge variant="outline" className="text-xs border-gray-600 text-gray-300">
                    +{aliases.length - 3} more
                  </Badge>
                )}
              </div>
            </div>
          )}

          <div className="grid grid-cols-2 gap-3 text-xs text-gray-400">
            <div className="flex items-center gap-1">
              <MapPin className="h-3 w-3" />
              <span>{jurisdiction}</span>
            </div>
            {dateAdded && (
              <div className="flex items-center gap-1">
                <Calendar className="h-3 w-3" />
                <span>{new Date(dateAdded).toLocaleDateString()}</span>
              </div>
            )}
          </div>

          <div className="flex flex-wrap gap-1 mt-3">
            <Badge variant="secondary" className="text-xs">
              {entityType}
            </Badge>
            <Badge variant="secondary" className="text-xs">
              {result.details?.source_list || 'Sanctions List'}
            </Badge>
          </div>
        </CardContent>
      </Card>
    );
  };

  const searchConfig = createSearchConfig({
    title: 'Search Sanctions Lists',
    description: 'Search for sanctioned persons, entities, vessels, and aircraft across multiple jurisdictions',
    placeholder: 'Enter name, entity, or identifier...',
    searchFunction: searchSanctions,
    multiSelect,
    repositoryLink: {
      label: 'View Full Database',
      url: '/knowledge-base?category=sanctions',
      description: 'Access complete sanctions database and documentation'
    },
    filters: [
      {
        label: 'Entity Type',
        key: 'entity_type',
        options: entityTypes.map(type => ({
          value: type,
          label: type.charAt(0).toUpperCase() + type.slice(1)
        }))
      },
      {
        label: 'Jurisdiction',
        key: 'jurisdiction',
        options: jurisdictions.map(jurisdiction => ({
          value: jurisdiction,
          label: jurisdiction
        }))
      },
      {
        label: 'Risk Level',
        key: 'risk_level',
        options: riskLevels.map(level => ({
          value: level,
          label: level.charAt(0).toUpperCase() + level.slice(1)
        }))
      }
    ],
    resultTemplate: SanctionResultTemplate
  });

  return (
    <SearchWidget
      config={searchConfig}
      open={open}
      onClose={onClose}
      onSelectionConfirmed={handleSelectionConfirmed}
      initialQuery={initialQuery}
      className="sanctions-search-widget"
    />
  );
}

// Export types for use in other components
export type { SanctionEntity } from 'types';
