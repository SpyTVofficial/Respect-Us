import React, { useState, useEffect } from 'react';
import {
  Card, CardContent, CardHeader, CardTitle, CardDescription
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle
} from '@/components/ui/dialog';
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuTrigger, DropdownMenuItem
} from '@/components/ui/dropdown-menu';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle
} from '@/components/ui/alert-dialog';
import {
  FileText, Plus, Edit, Trash2, ChevronDown, ChevronRight, MoreVertical,
  Upload, Download, Move, Copy, Search, Filter, BookOpen, Layers,
  Loader2, Link, Hash, ArrowUp, ArrowDown, Eye, TreePine
} from 'lucide-react';
import { toast } from 'sonner';
import brain from 'brain';
import {
  DocumentSectionsResponse, DocumentSection, CreateSectionRequest,
  UpdateSectionRequest, AppApisDocumentSectionsBulkImportRequest
} from '../brain/data-contracts';

interface Props {
  documentId: number;
  documentTitle?: string;
  onSectionUpdated?: () => void;
}

interface SectionFormData {
  section_number: string;
  section_title: string;
  section_content: string;
  parent_section_id: number | null;
  display_order: number;
}

interface ExpandedSections {
  [key: number]: boolean;
}

const DocumentSectionsManager: React.FC<Props> = ({ 
  documentId, 
  documentTitle = 'Document',
  onSectionUpdated 
}) => {
  const [sections, setSections] = useState<DocumentSection[]>([]);
  const [sectionsNotApplicable, setSectionsNotApplicable] = useState(false);
  const [loading, setLoading] = useState(true);
  const [expandedSections, setExpandedSections] = useState<ExpandedSections>({});
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedSections, setSelectedSections] = useState<Set<number>>(new Set());
  
  // Dialog states
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [showBulkImportDialog, setShowBulkImportDialog] = useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  
  // Form states
  const [formData, setFormData] = useState<SectionFormData>({
    section_number: '',
    section_title: '',
    section_content: '',
    parent_section_id: null,
    display_order: 0
  });
  const [editingSectionId, setEditingSectionId] = useState<number | null>(null);
  const [bulkImportText, setBulkImportText] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Load sections from API
  const loadSections = async () => {
    try {
      setLoading(true);
      const response = await brain.get_document_sections_admin({ documentId });
      const data = await response.json();
      setSections(data.sections || []);
      setSectionsNotApplicable(data.sections_not_applicable || false);
    } catch (error) {
      console.error('Error loading document sections:', error);
      toast.error('Failed to load document sections');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadSections();
  }, [documentId]);

  // Create hierarchical structure for sections
  const createHierarchy = (sections: DocumentSection[]): DocumentSection[] => {
    const sectionMap = new Map<number, DocumentSection & { children: DocumentSection[] }>();
    const rootSections: (DocumentSection & { children: DocumentSection[] })[] = [];

    // Initialize sections with children array
    sections.forEach(section => {
      sectionMap.set(section.id, { ...section, children: [] });
    });

    // Build hierarchy
    sections.forEach(section => {
      const sectionWithChildren = sectionMap.get(section.id)!;
      if (section.parent_section_id && sectionMap.has(section.parent_section_id)) {
        const parent = sectionMap.get(section.parent_section_id)!;
        parent.children.push(sectionWithChildren);
      } else {
        rootSections.push(sectionWithChildren);
      }
    });

    return rootSections;
  };

  // Filter sections based on search term
  const filteredSections = sections.filter(section =>
    section.section_title?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    section.section_number?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    section.section_content?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const hierarchicalSections = createHierarchy(searchTerm ? filteredSections : sections);

  // Toggle section expansion
  const toggleSection = (sectionId: number) => {
    setExpandedSections(prev => ({
      ...prev,
      [sectionId]: !prev[sectionId]
    }));
  };

  // Handle form submission for creating/editing sections
  const handleSubmitSection = async () => {
    try {
      setIsSubmitting(true);
      
      if (editingSectionId) {
        // Update existing section
        const updateRequest: UpdateSectionRequest = {
          section_number: formData.section_number || undefined,
          section_title: formData.section_title || undefined,
          section_content: formData.section_content || undefined,
          parent_section_id: formData.parent_section_id || undefined,
          display_order: formData.display_order || undefined
        };
        
        await brain.update_document_section({ sectionId: editingSectionId }, updateRequest);
        toast.success('Section updated successfully');
      } else {
        // Create new section
        const createRequest: CreateSectionRequest = {
          section_number: formData.section_number,
          section_title: formData.section_title,
          section_content: formData.section_content,
          parent_section_id: formData.parent_section_id,
          display_order: formData.display_order
        };
        
        await brain.create_document_section({ documentId }, createRequest);
        toast.success('Section created successfully');
      }
      
      // Reset form and reload
      resetForm();
      await loadSections();
      onSectionUpdated?.();
      
    } catch (error) {
      console.error('Error saving section:', error);
      toast.error('Failed to save section');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Handle bulk import
  const handleBulkImport = async () => {
    try {
      setIsSubmitting(true);
      
      // Parse the bulk import text into sections
      const lines = bulkImportText.split('\n').filter(line => line.trim());
      const importSections = [];
      
      for (let i = 0; i < lines.length; i++) {
        const line = lines[i].trim();
        if (line) {
          // Simple parsing - assume format: "1. Title: Content"
          const match = line.match(/^([\d\.]+)\s*([^:]+):?\s*(.*)$/);
          if (match) {
            importSections.push({
              section_number: match[1].trim(),
              section_title: match[2].trim(),
              section_content: match[3].trim() || match[2].trim(),
              display_order: i
            });
          } else {
            // Fallback: use line as title
            importSections.push({
              section_number: (i + 1).toString(),
              section_title: line,
              section_content: line,
              display_order: i
            });
          }
        }
      }
      
      const bulkRequest: AppApisDocumentSectionsBulkImportRequest = {
        document_id: documentId,
        sections: importSections,
        replace_existing: false
      };
      
      await brain.bulk_import_sections({ documentId }, bulkRequest);
      toast.success(`Imported ${importSections.length} sections successfully`);
      
      setBulkImportText('');
      setShowBulkImportDialog(false);
      await loadSections();
      onSectionUpdated?.();
      
    } catch (error) {
      console.error('Error importing sections:', error);
      toast.error('Failed to import sections');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Handle section deletion
  const handleDeleteSection = async (sectionId: number) => {
    try {
      await brain.delete_document_section({ sectionId });
      toast.success('Section deleted successfully');
      await loadSections();
      onSectionUpdated?.();
    } catch (error) {
      console.error('Error deleting section:', error);
      toast.error('Failed to delete section');
    }
  };

  // Reset form
  const resetForm = () => {
    setFormData({
      section_number: '',
      section_title: '',
      section_content: '',
      parent_section_id: null,
      display_order: 0
    });
    setEditingSectionId(null);
    setShowCreateDialog(false);
    setShowEditDialog(false);
  };

  // Start editing section
  const startEditSection = (section: DocumentSection) => {
    setFormData({
      section_number: section.section_number || '',
      section_title: section.section_title || '',
      section_content: section.section_content || '',
      parent_section_id: section.parent_section_id,
      display_order: section.display_order || 0
    });
    setEditingSectionId(section.id);
    setShowEditDialog(true);
  };

  // Render a single section with hierarchy
  const renderSection = (
    section: DocumentSection & { children?: DocumentSection[] }, 
    level: number = 0
  ) => {
    const hasChildren = section.children && section.children.length > 0;
    const isExpanded = expandedSections[section.id];
    const indent = level * 24;

    return (
      <div key={section.id} className="border border-gray-700 rounded-lg mb-2">
        <div 
          className="flex items-center justify-between p-4 hover:bg-gray-800/50 cursor-pointer"
          style={{ paddingLeft: `${16 + indent}px` }}
          onClick={() => hasChildren && toggleSection(section.id)}
        >
          <div className="flex items-center gap-3 flex-1">
            {hasChildren ? (
              isExpanded ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />
            ) : (
              <div className="w-4" />
            )}
            
            <div className="flex items-center gap-2">
              {section.section_number && (
                <Badge variant="outline" className="text-xs">
                  {section.section_number}
                </Badge>
              )}
              <TreePine className="h-4 w-4 text-blue-400" />
            </div>
            
            <div className="flex-1">
              <div className="font-medium text-white">
                {section.section_title || 'Untitled Section'}
              </div>
              {section.section_content && (
                <div className="text-sm text-gray-400 mt-1 line-clamp-2">
                  {section.section_content.substring(0, 120)}...
                </div>
              )}
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={(e) => {
                e.stopPropagation();
                startEditSection(section);
              }}
            >
              <Edit className="h-4 w-4" />
            </Button>
            
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="sm" onClick={(e) => e.stopPropagation()}>
                  <MoreVertical className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent>
                <DropdownMenuItem onClick={() => startEditSection(section)}>
                  <Edit className="h-4 w-4 mr-2" />
                  Edit Section
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => {
                  setEditingSectionId(section.id);
                  setShowDeleteDialog(true);
                }}>
                  <Trash2 className="h-4 w-4 mr-2" />
                  Delete Section
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
        
        {/* Render children if expanded */}
        {hasChildren && isExpanded && (
          <div className="border-t border-gray-700">
            {section.children!.map(child => renderSection(child, level + 1))}
          </div>
        )}
      </div>
    );
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <Loader2 className="h-8 w-8 animate-spin" />
        <span className="ml-2">Loading document sections...</span>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-white flex items-center gap-2">
            <Layers className="h-6 w-6" />
            Document Sections
          </h2>
          <p className="text-gray-400 mt-1">
            Manage hierarchical sections for {documentTitle}
          </p>
        </div>
        
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setShowBulkImportDialog(true)}
          >
            <Upload className="h-4 w-4 mr-2" />
            Bulk Import
          </Button>
          
          <Button onClick={() => setShowCreateDialog(true)}>
            <Plus className="h-4 w-4 mr-2" />
            Add Section
          </Button>
        </div>
      </div>

      {/* Search and filters */}
      <div className="flex items-center gap-4">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
          <Input
            placeholder="Search sections..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
        
        <Badge variant="secondary">
          {sections.length} sections
        </Badge>
      </div>

      {/* Sections list */}
      {sectionsNotApplicable ? (
        <Card>
          <CardContent className="p-6 text-center">
            <BookOpen className="h-12 w-12 mx-auto text-gray-400 mb-4" />
            <h3 className="text-lg font-semibold mb-2">Sections Not Applicable</h3>
            <p className="text-gray-400">
              This document has been marked as not having structured sections.
            </p>
          </CardContent>
        </Card>
      ) : sections.length === 0 ? (
        <Card>
          <CardContent className="p-6 text-center">
            <FileText className="h-12 w-12 mx-auto text-gray-400 mb-4" />
            <h3 className="text-lg font-semibold mb-2">No Sections Found</h3>
            <p className="text-gray-400 mb-4">
              This document doesn't have any sections yet. Add sections to create a structured view.
            </p>
            <Button onClick={() => setShowCreateDialog(true)}>
              <Plus className="h-4 w-4 mr-2" />
              Add First Section
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-2">
          {hierarchicalSections.map(section => renderSection(section))}
        </div>
      )}

      {/* Create Section Dialog */}
      <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Create New Section</DialogTitle>
            <DialogDescription>
              Add a new section to the document structure.
            </DialogDescription>
          </DialogHeader>
          
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="section_number">Section Number</Label>
                <Input
                  id="section_number"
                  value={formData.section_number}
                  onChange={(e) => setFormData(prev => ({ ...prev, section_number: e.target.value }))}
                  placeholder="e.g., 1.1, Article 5"
                />
              </div>
              <div>
                <Label htmlFor="display_order">Display Order</Label>
                <Input
                  id="display_order"
                  type="number"
                  value={formData.display_order}
                  onChange={(e) => setFormData(prev => ({ ...prev, display_order: parseInt(e.target.value) || 0 }))}
                  placeholder="0"
                />
              </div>
            </div>
            
            <div>
              <Label htmlFor="section_title">Section Title</Label>
              <Input
                id="section_title"
                value={formData.section_title}
                onChange={(e) => setFormData(prev => ({ ...prev, section_title: e.target.value }))}
                placeholder="Enter section title"
              />
            </div>
            
            <div>
              <Label htmlFor="section_content">Section Content</Label>
              <Textarea
                id="section_content"
                value={formData.section_content}
                onChange={(e) => setFormData(prev => ({ ...prev, section_content: e.target.value }))}
                placeholder="Enter section content"
                rows={6}
              />
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={resetForm}>
              Cancel
            </Button>
            <Button onClick={handleSubmitSection} disabled={isSubmitting}>
              {isSubmitting && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              Create Section
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Section Dialog */}
      <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Edit Section</DialogTitle>
            <DialogDescription>
              Modify the selected section.
            </DialogDescription>
          </DialogHeader>
          
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="edit_section_number">Section Number</Label>
                <Input
                  id="edit_section_number"
                  value={formData.section_number}
                  onChange={(e) => setFormData(prev => ({ ...prev, section_number: e.target.value }))}
                  placeholder="e.g., 1.1, Article 5"
                />
              </div>
              <div>
                <Label htmlFor="edit_display_order">Display Order</Label>
                <Input
                  id="edit_display_order"
                  type="number"
                  value={formData.display_order}
                  onChange={(e) => setFormData(prev => ({ ...prev, display_order: parseInt(e.target.value) || 0 }))}
                  placeholder="0"
                />
              </div>
            </div>
            
            <div>
              <Label htmlFor="edit_section_title">Section Title</Label>
              <Input
                id="edit_section_title"
                value={formData.section_title}
                onChange={(e) => setFormData(prev => ({ ...prev, section_title: e.target.value }))}
                placeholder="Enter section title"
              />
            </div>
            
            <div>
              <Label htmlFor="edit_section_content">Section Content</Label>
              <Textarea
                id="edit_section_content"
                value={formData.section_content}
                onChange={(e) => setFormData(prev => ({ ...prev, section_content: e.target.value }))}
                placeholder="Enter section content"
                rows={6}
              />
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={resetForm}>
              Cancel
            </Button>
            <Button onClick={handleSubmitSection} disabled={isSubmitting}>
              {isSubmitting && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              Update Section
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Bulk Import Dialog */}
      <Dialog open={showBulkImportDialog} onOpenChange={setShowBulkImportDialog}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Bulk Import Sections</DialogTitle>
            <DialogDescription>
              Import multiple sections at once. Use format: "1. Title: Content" or "Title" per line.
            </DialogDescription>
          </DialogHeader>
          
          <div className="py-4">
            <Label htmlFor="bulk_import">Section Data</Label>
            <Textarea
              id="bulk_import"
              value={bulkImportText}
              onChange={(e) => setBulkImportText(e.target.value)}
              placeholder={`1. Introduction: General overview\n2. Definitions: Key terms\n3. Scope: Application area`}
              rows={10}
              className="mt-2"
            />
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowBulkImportDialog(false)}>
              Cancel
            </Button>
            <Button onClick={handleBulkImport} disabled={isSubmitting || !bulkImportText.trim()}>
              {isSubmitting && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              Import Sections
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Section</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete this section? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => {
                if (editingSectionId) {
                  handleDeleteSection(editingSectionId);
                  setShowDeleteDialog(false);
                  setEditingSectionId(null);
                }
              }}
              className="bg-red-600 hover:bg-red-700"
            >
              Delete Section
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};

export default DocumentSectionsManager;
