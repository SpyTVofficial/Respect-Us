import { useState, useEffect } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Search, Calendar, Tag, TrendingUp } from 'lucide-react';
import brain from 'brain';
import { BlogPost } from 'types';

interface Props {
  onSearch: (query: string) => void;
  onCategoryFilter: (category: string | null) => void;
  onDateFilter: (date: string | null) => void;
  selectedCategory?: string | null;
  searchQuery?: string;
}

export default function BlogSidebar({ 
  onSearch, 
  onCategoryFilter, 
  onDateFilter, 
  selectedCategory,
  searchQuery = ''
}: Props) {
  const [categories, setCategories] = useState<string[]>([]);
  const [popularPosts, setPopularPosts] = useState<BlogPost[]>([]);
  const [recentDates, setRecentDates] = useState<string[]>([]);
  const [localSearchQuery, setLocalSearchQuery] = useState(searchQuery);

  useEffect(() => {
    loadSidebarData();
  }, []);

  useEffect(() => {
    setLocalSearchQuery(searchQuery);
  }, [searchQuery]);

  const loadSidebarData = async () => {
    try {
      // Load blog posts to extract categories and popular posts
      const response = await brain.search_blog_documents({
        publishing_status: 'published',
        limit: 100,
        offset: 0
      });
      const data = await response.json();
      const posts = data.documents || [];
      
      // Extract unique categories from article_type field
      const uniqueCategories = Array.from(new Set(
        posts.map((post: any) => post.article_type).filter(Boolean)
      )) as string[];
      setCategories(uniqueCategories);
      
      // Get popular posts (sorted by view_count if available)
      const popular = posts
        .sort((a: any, b: any) => (b.view_count || 0) - (a.view_count || 0))
        .slice(0, 5)
        .map((post: any) => ({
          id: post.id,
          title: post.title,
          slug: post.id.toString(),
          excerpt: post.excerpt || post.description || '',
          created_at: post.created_at,
          views: post.view_count || 0,
          categories: post.article_type ? [post.article_type] : []
        }));
      setPopularPosts(popular);
      
      // Extract recent dates (last 6 months)
      const dates = Array.from(new Set(
        posts.map((post: any) => {
          const date = new Date(post.created_at);
          return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
        })
      )).sort().reverse().slice(0, 6);
      setRecentDates(dates);
      
    } catch (error) {
      console.error('Error loading sidebar data:', error);
    }
  };

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSearch(localSearchQuery);
  };

  const formatMonthYear = (dateStr: string) => {
    const [year, month] = dateStr.split('-');
    const date = new Date(parseInt(year), parseInt(month) - 1);
    return date.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
  };

  return (
    <div className="space-y-6">
      {/* Search */}
      <Card className="bg-gray-900 border-gray-700">
        <CardHeader className="pb-3">
          <CardTitle className="text-white flex items-center gap-2">
            <Search className="h-5 w-5" />
            Search Blog
          </CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSearchSubmit} className="space-y-2">
            <Input
              placeholder="Search articles..."
              value={localSearchQuery}
              onChange={(e) => setLocalSearchQuery(e.target.value)}
              className="bg-gray-800 border-gray-600 text-white placeholder-gray-400"
            />
            <Button type="submit" size="sm" className="w-full">
              Search
            </Button>
          </form>
        </CardContent>
      </Card>

      {/* Categories */}
      <Card className="bg-gray-900 border-gray-700">
        <CardHeader className="pb-3">
          <CardTitle className="text-white flex items-center gap-2">
            <Tag className="h-5 w-5" />
            Categories
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          <Button
            variant={selectedCategory === null ? "default" : "ghost"}
            size="sm"
            onClick={() => onCategoryFilter(null)}
            className="w-full justify-start text-gray-300 hover:text-white"
          >
            All Categories
          </Button>
          {categories.map((category) => (
            <Button
              key={category}
              variant={selectedCategory === category ? "default" : "ghost"}
              size="sm"
              onClick={() => onCategoryFilter(category)}
              className="w-full justify-start text-gray-300 hover:text-white"
            >
              {category}
            </Button>
          ))}
        </CardContent>
      </Card>

      {/* Archive by Date */}
      <Card className="bg-gray-900 border-gray-700">
        <CardHeader className="pb-3">
          <CardTitle className="text-white flex items-center gap-2">
            <Calendar className="h-5 w-5" />
            Archive
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => onDateFilter(null)}
            className="w-full justify-start text-gray-300 hover:text-white"
          >
            All Time
          </Button>
          {recentDates.map((date) => (
            <Button
              key={date}
              variant="ghost"
              size="sm"
              onClick={() => onDateFilter(date)}
              className="w-full justify-start text-gray-300 hover:text-white"
            >
              {formatMonthYear(date)}
            </Button>
          ))}
        </CardContent>
      </Card>

      {/* Popular Posts */}
      {popularPosts.length > 0 && (
        <Card className="bg-gray-900 border-gray-700">
          <CardHeader className="pb-3">
            <CardTitle className="text-white flex items-center gap-2">
              <TrendingUp className="h-5 w-5" />
              Popular Posts
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {popularPosts.map((post) => (
              <div key={post.id} className="group">
                <h4 className="text-sm font-medium text-gray-300 group-hover:text-white transition-colors leading-tight">
                  {post.title}
                </h4>
                <div className="flex items-center gap-2 mt-1">
                  <span className="text-xs text-gray-500">
                    {new Date(post.created_at).toLocaleDateString()}
                  </span>
                  {post.views && (
                    <Badge variant="secondary" className="text-xs">
                      {post.views} views
                    </Badge>
                  )}
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      )}
    </div>
  );
}
