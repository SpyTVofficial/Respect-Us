import React from 'react';

interface Props {
  // Test component for sticky header validation
}

export function TestStickyTable({}: Props) {
  const testData = [
    { id: 1, country: 'United States', code: 'US', risk: 'Low' },
    { id: 2, country: 'China', code: 'CN', risk: 'High' },
    { id: 3, country: 'Russia', code: 'RU', risk: 'High' },
    { id: 4, country: 'Germany', code: 'DE', risk: 'Low' },
    { id: 5, country: 'Iran', code: 'IR', risk: 'Very High' },
    { id: 6, country: 'North Korea', code: 'KP', risk: 'Very High' },
    { id: 7, country: 'France', code: 'FR', risk: 'Low' },
    { id: 8, country: 'United Kingdom', code: 'GB', risk: 'Low' },
    { id: 9, country: 'Japan', code: 'JP', risk: 'Low' },
    { id: 10, country: 'South Korea', code: 'KR', risk: 'Low' },
    { id: 11, country: 'India', code: 'IN', risk: 'Medium' },
    { id: 12, country: 'Pakistan', code: 'PK', risk: 'High' },
    { id: 13, country: 'Israel', code: 'IL', risk: 'Medium' },
    { id: 14, country: 'Turkey', code: 'TR', risk: 'Medium' },
    { id: 15, country: 'Brazil', code: 'BR', risk: 'Low' },
  ];

  return (
    <div className="p-4">
      <h2 className="text-xl font-bold text-white mb-4">Sticky Header Test</h2>
      
      <div className="border border-gray-600 rounded-lg overflow-hidden">
        <div className="max-h-64 overflow-auto">
          <table className="w-full text-sm text-left">
            <thead>
              <tr>
                <th 
                  className="px-6 py-3 text-white bg-gray-800"
                  style={{ position: 'sticky', top: 0, zIndex: 10 }}
                >
                  Country
                </th>
                <th 
                  className="px-6 py-3 text-white bg-gray-800 text-center"
                  style={{ position: 'sticky', top: 0, zIndex: 10 }}
                >
                  Code
                </th>
                <th 
                  className="px-6 py-3 text-white bg-gray-800 text-center"
                  style={{ position: 'sticky', top: 0, zIndex: 10 }}
                >
                  Risk Level
                </th>
              </tr>
            </thead>
            <tbody>
              {testData.map((item) => (
                <tr key={item.id} className="border-b border-gray-700">
                  <td className="px-6 py-4 text-gray-200">{item.country}</td>
                  <td className="px-6 py-4 text-gray-200 text-center">{item.code}</td>
                  <td className="px-6 py-4 text-gray-200 text-center">{item.risk}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

export default TestStickyTable;
