import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { FileText, Save, Calendar, User, AlertCircle, Shield, Globe, ChevronDown, ChevronRight, Clock, Users, Plus, X } from 'lucide-react';
import { toast } from 'sonner';
import brain from 'brain';
import { DocumentResponse, BodyUpdateDocument, MetadataOption } from '../brain/data-contracts';
import { useUserGuardContext } from 'app/auth';
import { API_URL, auth } from 'app';
import ComboboxMultiSelect from './ComboboxMultiSelect';

export interface DocumentEditorProps {
  documentId: number;
  document: DocumentResponse | null;
  onDocumentUpdated: (document: DocumentResponse) => void;
  onClose: () => void;
}

interface EnhancedMetadataOptions {
  classification_levels: MetadataOption[];
  security_markings: MetadataOption[];
  document_types: MetadataOption[];
  compliance_frameworks: MetadataOption[];
  product_categories: MetadataOption[];
  review_schedules: MetadataOption[];
  geographic_scopes: MetadataOption[];
}

export default function DocumentEditor({ documentId, document: initialDocument, onDocumentUpdated, onClose }: DocumentEditorProps) {
  const { user } = useUserGuardContext();
  const [document, setDocument] = useState<DocumentResponse | null>(initialDocument);
  const [loading, setLoading] = useState(false);
  const [loadingOptions, setLoadingOptions] = useState(false);
  const [saving, setSaving] = useState(false);
  const [file, setFile] = useState<File | null>(null);
  
  // Enhanced metadata options
  const [enhancedOptions, setEnhancedOptions] = useState<EnhancedMetadataOptions | null>(null);
  
  // Legacy metadata options
  const [jurisdictions, setJurisdictions] = useState<MetadataOption[]>([]);
  const [regulationTypes, setRegulationTypes] = useState<MetadataOption[]>([]);
  const [subjects, setSubjects] = useState<MetadataOption[]>([]);
  
  // Collapsible sections state - matching EnhancedDocumentUpload exactly
  const [openSections, setOpenSections] = useState({
    basic: true,
    dates: false,
    categories: false,
    security: false,
    workflow: false,
    enhanced: false,
    alerts: false
  });
  
  // Enhanced document metadata state - matching EnhancedDocumentUpload exactly
  const [metadata, setMetadata] = useState({
    // Basic information
    title: '',
    description: '',
    issuing_authority: '',
    legal_status: 'in_force',
    version: '',
    source_url: '',
    
    // Date fields
    publication_date: '',
    effective_date: '',
    expiration_date: '',
    adoption_date: '',
    abrogation_date: '',
    next_review_date: '',
    
    // Array fields
    country_jurisdiction: [] as string[],
    regulation_type: [] as string[],
    subject: [] as string[],
    tags: [] as string[],
    
    // Enhanced metadata fields - matching EnhancedDocumentUpload exactly
    classification_level: '',
    security_markings: [] as string[],
    access_control_list: [] as string[],
    document_type: '',
    compliance_framework: '',
    product_category: '',
    retention_period_years: null as number | null,
    review_schedule: '',
    document_owner: '',
    sme_reviewers: [] as string[],
    training_required: false,
    version_major: 1,
    version_minor: 0,
    approval_chain: [] as string[],
    geographic_scope: [] as string[],
    
    // Alert generation fields
    generate_alert: '',
    alert_severity: 'medium',
    alert_jurisdictions: [] as string[],
    alert_expires_at: ''
  });
  
  // Separate state for tags input to avoid feedback loop
  const [tagsInput, setTagsInput] = useState('');
  
  // Toggle section visibility
  const toggleSection = (section: keyof typeof openSections) => {
    setOpenSections(prev => ({
      ...prev,
      [section]: !prev[section]
    }));
  };

  // Load document on mount
  useEffect(() => {
    if (documentId && !document) {
      loadDocument();
    }
  }, [documentId]);

  const loadDocument = async () => {
    try {
      setLoading(true);
      const response = await brain.get_document({ documentId });
      if (response.ok) {
        const documentData = await response.json();
        setDocument(documentData);
      }
    } catch (error) {
      console.error('Error loading document:', error);
      toast.error('Failed to load document');
    } finally {
      setLoading(false);
    }
  };

  // Load metadata options on mount
  useEffect(() => {
    loadMetadataOptions();
  }, []);

  const loadMetadataOptions = async () => {
    try {
      setLoadingOptions(true);
      
      // Load enhanced metadata options and legacy options in parallel
      const [enhancedRes, jurisdictionsRes, typesRes, subjectsRes] = await Promise.all([
        brain.get_enhanced_metadata_options(),
        brain.get_metadata_options({ category: 'jurisdiction' }),
        brain.get_metadata_options({ category: 'type' }),
        brain.get_metadata_options({ category: 'subject' })
      ]);
      
      if (enhancedRes.ok) {
        const enhancedData = await enhancedRes.json();
        setEnhancedOptions(enhancedData);
      }
      
      if (jurisdictionsRes.ok) {
        const jurisdictionsData = await jurisdictionsRes.json();
        setJurisdictions(jurisdictionsData);
      }
      
      if (typesRes.ok) {
        const typesData = await typesRes.json();
        setRegulationTypes(typesData);
      }
      
      if (subjectsRes.ok) {
        const subjectsData = await subjectsRes.json();
        setSubjects(subjectsData);
      }
    } catch (error) {
      console.error('Error loading metadata options:', error);
      toast.error('Failed to load metadata options');
    } finally {
      setLoadingOptions(false);
    }
  };

  // Load document data into form when document changes
  useEffect(() => {
    if (document) {
      const tagsArray = Array.isArray(document.tags) 
        ? document.tags 
        : (document.tags ? document.tags.split(',').map(s => s.trim()) : []);
        
      setMetadata({
        // Basic fields
        title: document.title || '',
        description: document.description || '',
        country_jurisdiction: Array.isArray(document.country_jurisdiction) 
          ? document.country_jurisdiction 
          : (document.country_jurisdiction ? document.country_jurisdiction.split(',').map(s => s.trim()) : []),
        regulation_type: Array.isArray(document.regulation_type) 
          ? document.regulation_type 
          : (document.regulation_type ? document.regulation_type.split(',').map(s => s.trim()) : []),
        subject: Array.isArray(document.subject) 
          ? document.subject 
          : (document.subject ? document.subject.split(',').map(s => s.trim()) : []),
        issuing_authority: document.issuing_authority || '',
        publication_date: document.publication_date || '',
        effective_date: document.effective_date || '',
        adoption_date: document.adoption_date || '',
        abrogation_date: document.abrogation_date || '',
        legal_status: document.legal_status || 'in_force',
        version: document.version || '',
        source_url: document.source_url || '',
        tags: tagsArray,
        
        // Enhanced metadata fields
        classification_level: document.classification_level || '',
        security_markings: Array.isArray(document.security_markings) ? document.security_markings : [],
        access_control_list: Array.isArray(document.access_control_list) ? document.access_control_list : [],
        document_type: document.document_type || '',
        compliance_framework: document.compliance_framework || '',
        product_category: document.product_category || '',
        retention_period_years: document.retention_period_years || null,
        review_schedule: document.review_schedule || '',
        next_review_date: document.next_review_date || '',
        expiration_date: document.expiration_date || '',
        document_owner: document.document_owner || '',
        sme_reviewers: Array.isArray(document.sme_reviewers) ? document.sme_reviewers : [],
        training_required: document.training_required || false,
        version_major: document.version_major || 1,
        version_minor: document.version_minor || 0,
        approval_chain: Array.isArray(document.approval_chain) ? document.approval_chain : [],
        geographic_scope: Array.isArray(document.geographic_scope) ? document.geographic_scope : []
      });
      
      // Initialize tags input field with comma-separated string
      setTagsInput(tagsArray.join(', '));
    }
  }, [document]);

  const handleSave = async () => {
    if (!document) return;
    
    setSaving(true);
    
    try {
      // Prepare the document update data from metadata state
      const updateData = {
        title: metadata.title?.trim() || '',
        description: metadata.description?.trim() || '',
        country_jurisdiction: metadata.country_jurisdiction || [],
        regulation_type: metadata.regulation_type || [],
        subject: metadata.subject || [],
        issuing_authority: metadata.issuing_authority || '',
        legal_status: metadata.legal_status || '',
        tags: Array.isArray(metadata.tags) && metadata.tags.length > 0 ? metadata.tags.join(', ') : '',
        version: metadata.version?.trim() || '',
        publication_date: metadata.publication_date || '',
        effective_date: metadata.effective_date || '',
        adoption_date: metadata.adoption_date || '',
        abrogation_date: metadata.abrogation_date || '',
        expiration_date: metadata.expiration_date || '',
        next_review_date: metadata.next_review_date || '',
        source_url: metadata.source_url?.trim() || '',
        
        // Enhanced metadata fields
        classification_level: metadata.classification_level?.trim() || '',
        security_markings: metadata.security_markings || [],
        access_control_list: metadata.access_control_list || [],
        document_type: metadata.document_type?.trim() || '',
        compliance_framework: metadata.compliance_framework?.trim() || '',
        product_category: metadata.product_category?.trim() || '',
        retention_period_years: metadata.retention_period_years || null,
        review_schedule: metadata.review_schedule?.trim() || '',
        document_owner: metadata.document_owner?.trim() || '',
        sme_reviewers: metadata.sme_reviewers || [],
        training_required: metadata.training_required || false,
        version_major: metadata.version_major || 1,
        version_minor: metadata.version_minor || 0,
        approval_chain: metadata.approval_chain || [],
        geographic_scope: metadata.geographic_scope || []
      };
      
      const metadataString = JSON.stringify(updateData);
      
      // Manually construct FormData
      const formData = new FormData();
      formData.append('metadata', metadataString);
      
      // Only append file if one is selected
      if (file) {
        formData.append('file', file);
      }
      
      // Get auth token for manual fetch call
      const token = await auth.getAuthToken();
      
      const response = await fetch(`${brain.baseUrl}/routes/knowledge-base/documents/${documentId}`, {
        method: 'PUT',
        headers: {
          'Authorization': `Bearer ${token}`
        },
        body: formData,
        credentials: 'include'
      });
      
      if (response.ok) {
        const responseData = await response.json();
        const updatedDocument = responseData.document || responseData;
        
        setDocument(updatedDocument);
        onDocumentUpdated(updatedDocument);
        toast.success('Document updated successfully');
        onClose();
      } else {
        const errorText = await response.text();
        let errorData;
        try {
          errorData = JSON.parse(errorText);
        } catch {
          errorData = { detail: 'Update failed', raw: errorText };
        }
        
        console.error('Update failed:', errorData);
        toast.error(errorData.detail || 'Failed to update document');
      }
    } catch (error) {
      console.error('Exception in handleSave:', error);
      toast.error('Error updating document');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <Card className="w-full max-w-4xl mx-auto bg-gray-800 border-gray-700">
        <CardContent className="p-8 text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500 mx-auto"></div>
          <p className="mt-4 text-gray-400">Loading document editor...</p>
        </CardContent>
      </Card>
    );
  }

  if (!document) {
    return (
      <Card className="w-full max-w-4xl mx-auto bg-gray-800 border-gray-700">
        <CardContent className="p-8 text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500 mx-auto"></div>
          <p className="mt-4 text-gray-400">Loading document...</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="w-full max-w-4xl mx-auto space-y-6">
      {/* Header */}
      <Card className="bg-gray-800 border-gray-700">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <FileText className="h-6 w-6 text-blue-400" />
              <CardTitle className="text-white">Edit Document</CardTitle>
            </div>
            <div className="flex items-center gap-2">
              <Button onClick={handleSave} disabled={saving} className="bg-blue-600 hover:bg-blue-700">
                <Save className="h-4 w-4 mr-1" />
                {saving ? 'Saving...' : 'Save Changes'}
              </Button>
              <Button variant="outline" onClick={onClose} className="border-gray-600 hover:bg-gray-700">
                Close
              </Button>
            </div>
          </div>
        </CardHeader>
      </Card>

      <div className="space-y-6">
        {/* Basic Information */}
        <Collapsible open={openSections.basic} onOpenChange={() => toggleSection('basic')}>
          <Card className="bg-gray-800 border-gray-700">
            <CollapsibleTrigger className="w-full">
              <CardHeader className="hover:bg-gray-700/50 transition-colors">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg text-white flex items-center gap-2">
                    <FileText className="h-5 w-5 text-blue-400" />
                    Basic Information
                  </CardTitle>
                  {openSections.basic ? <ChevronDown className="h-5 w-5" /> : <ChevronRight className="h-5 w-5" />}
                </div>
              </CardHeader>
            </CollapsibleTrigger>
            <CollapsibleContent>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label className="text-white font-medium">Title *</Label>
                    <Input
                      value={metadata.title}
                      onChange={(e) => setMetadata(prev => ({ ...prev, title: e.target.value }))}
                      placeholder="Document title"
                      className="bg-gray-700 border-gray-600 text-white"
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-white font-medium">Issuing Authority</Label>
                    <Input
                      value={metadata.issuing_authority}
                      onChange={(e) => setMetadata(prev => ({ ...prev, issuing_authority: e.target.value }))}
                      placeholder="e.g., BIS, OFAC, EU Commission"
                      className="bg-gray-700 border-gray-600 text-white"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label className="text-white font-medium">Description</Label>
                  <Textarea
                    value={metadata.description}
                    onChange={(e) => setMetadata(prev => ({ ...prev, description: e.target.value }))}
                    placeholder="Brief description of the document"
                    className="bg-gray-700 border-gray-600 text-white"
                    rows={3}
                  />
                </div>

                <div className="grid grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label className="text-white font-medium">Country/Jurisdiction *</Label>
                    <ComboboxMultiSelect
                      options={jurisdictions}
                      value={metadata.country_jurisdiction}
                      onChange={(values) => setMetadata(prev => ({ ...prev, country_jurisdiction: values }))}
                      placeholder="Select jurisdictions"
                      label=""
                      allowMultiple={true}
                      searchPlaceholder="Search jurisdictions..."
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-white font-medium">Type</Label>
                    <ComboboxMultiSelect
                      options={regulationTypes}
                      value={metadata.regulation_type}
                      onChange={(values) => setMetadata(prev => ({ ...prev, regulation_type: values }))}
                      placeholder="Select types"
                      label=""
                      allowMultiple={true}
                      searchPlaceholder="Search types..."
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-white font-medium">Subject</Label>
                    <ComboboxMultiSelect
                      options={subjects}
                      value={metadata.subject}
                      onChange={(values) => setMetadata(prev => ({ ...prev, subject: values }))}
                      placeholder="Select subjects"
                      label=""
                      allowMultiple={true}
                      searchPlaceholder="Search subjects..."
                    />
                  </div>
                </div>

                <div className="grid grid-cols-4 gap-4">
                  <div className="space-y-2">
                    <Label className="text-white font-medium">Publication Date</Label>
                    <Input
                      type="date"
                      value={metadata.publication_date}
                      onChange={(e) => setMetadata(prev => ({ ...prev, publication_date: e.target.value }))}
                      className="bg-gray-700 border-gray-600 text-white"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-white font-medium">Effective Date</Label>
                    <Input
                      type="date"
                      value={metadata.effective_date}
                      onChange={(e) => setMetadata(prev => ({ ...prev, effective_date: e.target.value }))}
                      className="bg-gray-700 border-gray-600 text-white"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-white font-medium">Adoption Date</Label>
                    <Input
                      type="date"
                      value={metadata.adoption_date}
                      onChange={(e) => setMetadata(prev => ({ ...prev, adoption_date: e.target.value }))}
                      className="bg-gray-700 border-gray-600 text-white"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-white font-medium">Abrogation Date</Label>
                    <Input
                      type="date"
                      value={metadata.abrogation_date}
                      onChange={(e) => setMetadata(prev => ({ ...prev, abrogation_date: e.target.value }))}
                      className="bg-gray-700 border-gray-600 text-white"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label className="text-white font-medium">Tags</Label>
                  <textarea
                    value={tagsInput}
                    onChange={(e) => setTagsInput(e.target.value)}
                    onBlur={() => {
                      // Parse tags when user finishes editing
                      const tags = tagsInput
                        .split(',')
                        .map(t => t.trim())
                        .filter(t => t.length > 0);
                      setMetadata(prev => ({ ...prev, tags }));
                    }}
                    className="bg-gray-700 border-gray-600 text-white min-h-[40px] resize-none p-2 rounded-md"
                    placeholder="Enter tags separated by commas (e.g., compliance, regulation, legal)"
                    rows={1}
                  />
                  {metadata.tags.length > 0 && (
                    <div className="flex flex-wrap gap-1 mt-2">
                      {metadata.tags.map((tag, index) => (
                        <Badge key={index} variant="secondary" className="bg-blue-600 text-white text-xs">
                          {tag}
                        </Badge>
                      ))}
                    </div>
                  )}
                </div>
              </CardContent>
            </CollapsibleContent>
          </Card>
        </Collapsible>

        {/* Security & Access Control */}
        <Collapsible open={openSections.security} onOpenChange={() => toggleSection('security')}>
          <Card className="bg-gray-800 border-gray-700">
            <CollapsibleTrigger className="w-full">
              <CardHeader className="hover:bg-gray-700/50 transition-colors">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg text-white flex items-center gap-2">
                    <Shield className="h-5 w-5 text-red-400" />
                    Security & Access Control
                  </CardTitle>
                  {openSections.security ? <ChevronDown className="h-5 w-5" /> : <ChevronRight className="h-5 w-5" />}
                </div>
              </CardHeader>
            </CollapsibleTrigger>
            <CollapsibleContent>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label className="text-white font-medium">Classification Level</Label>
                    <Select value={metadata.classification_level} onValueChange={(value) => setMetadata(prev => ({ ...prev, classification_level: value }))}>
                      <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                        <SelectValue placeholder="Select level" />
                      </SelectTrigger>
                      <SelectContent className="bg-gray-700 border-gray-600">
                        {enhancedOptions?.classification_levels.map((level) => (
                          <SelectItem key={level.value} value={level.value} className="text-white hover:bg-gray-600">
                            {level.display_name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label className="text-white font-medium">Training Required</Label>
                    <Select value={metadata.training_required ? 'true' : 'false'} onValueChange={(value) => setMetadata(prev => ({ ...prev, training_required: value === 'true' }))}>
                      <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="bg-gray-700 border-gray-600">
                        <SelectItem value="false" className="text-white hover:bg-gray-600">No</SelectItem>
                        <SelectItem value="true" className="text-white hover:bg-gray-600">Yes</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardContent>
            </CollapsibleContent>
          </Card>
        </Collapsible>

        {/* Compliance Information */}
        <Collapsible open={openSections.compliance} onOpenChange={() => toggleSection('compliance')}>
          <Card className="bg-gray-800 border-gray-700">
            <CollapsibleTrigger className="w-full">
              <CardHeader className="hover:bg-gray-700/50 transition-colors">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg text-white flex items-center gap-2">
                    <AlertCircle className="h-5 w-5 text-yellow-400" />
                    Compliance Information
                  </CardTitle>
                  {openSections.compliance ? <ChevronDown className="h-5 w-5" /> : <ChevronRight className="h-5 w-5" />}
                </div>
              </CardHeader>
            </CollapsibleTrigger>
            <CollapsibleContent>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label className="text-white font-medium">Document Type</Label>
                    <Select value={metadata.document_type} onValueChange={(value) => setMetadata(prev => ({ ...prev, document_type: value }))}>
                      <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                        <SelectValue placeholder="Select type" />
                      </SelectTrigger>
                      <SelectContent className="bg-gray-700 border-gray-600">
                        {enhancedOptions?.document_types.map((type) => (
                          <SelectItem key={type.value} value={type.value} className="text-white hover:bg-gray-600">
                            {type.display_name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label className="text-white font-medium">Compliance Framework</Label>
                    <Select value={metadata.compliance_framework} onValueChange={(value) => setMetadata(prev => ({ ...prev, compliance_framework: value }))}>
                      <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                        <SelectValue placeholder="Select framework" />
                      </SelectTrigger>
                      <SelectContent className="bg-gray-700 border-gray-600">
                        {enhancedOptions?.compliance_frameworks.map((framework) => (
                          <SelectItem key={framework.value} value={framework.value} className="text-white hover:bg-gray-600">
                            {framework.display_name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label className="text-white font-medium">Product Category</Label>
                    <Select value={metadata.product_category} onValueChange={(value) => setMetadata(prev => ({ ...prev, product_category: value }))}>
                      <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                        <SelectValue placeholder="Select category" />
                      </SelectTrigger>
                      <SelectContent className="bg-gray-700 border-gray-600">
                        {enhancedOptions?.product_categories.map((category) => (
                          <SelectItem key={category.value} value={category.value} className="text-white hover:bg-gray-600">
                            {category.display_name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardContent>
            </CollapsibleContent>
          </Card>
        </Collapsible>

        {/* Document Lifecycle */}
        <Collapsible open={openSections.lifecycle} onOpenChange={() => toggleSection('lifecycle')}>
          <Card className="bg-gray-800 border-gray-700">
            <CollapsibleTrigger className="w-full">
              <CardHeader className="hover:bg-gray-700/50 transition-colors">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg text-white flex items-center gap-2">
                    <Clock className="h-5 w-5 text-green-400" />
                    Document Lifecycle
                  </CardTitle>
                  {openSections.lifecycle ? <ChevronDown className="h-5 w-5" /> : <ChevronRight className="h-5 w-5" />}
                </div>
              </CardHeader>
            </CollapsibleTrigger>
            <CollapsibleContent>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label className="text-white font-medium">Review Schedule</Label>
                    <Select value={metadata.review_schedule} onValueChange={(value) => setMetadata(prev => ({ ...prev, review_schedule: value }))}>
                      <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                        <SelectValue placeholder="Select schedule" />
                      </SelectTrigger>
                      <SelectContent className="bg-gray-700 border-gray-600">
                        {enhancedOptions?.review_schedules.map((schedule) => (
                          <SelectItem key={schedule.value} value={schedule.value} className="text-white hover:bg-gray-600">
                            {schedule.display_name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label className="text-white font-medium">Retention Period (Years)</Label>
                    <Input
                      type="number"
                      value={metadata.retention_period_years || ''}
                      onChange={(e) => setMetadata(prev => ({ ...prev, retention_period_years: e.target.value ? parseInt(e.target.value) : null }))}
                      placeholder="Years to retain"
                      className="bg-gray-700 border-gray-600 text-white"
                    />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label className="text-white font-medium">Next Review Date</Label>
                    <Input
                      type="date"
                      value={metadata.next_review_date}
                      onChange={(e) => setMetadata(prev => ({ ...prev, next_review_date: e.target.value }))}
                      className="bg-gray-700 border-gray-600 text-white"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-white font-medium">Expiration Date</Label>
                    <Input
                      type="date"
                      value={metadata.expiration_date}
                      onChange={(e) => setMetadata(prev => ({ ...prev, expiration_date: e.target.value }))}
                      className="bg-gray-700 border-gray-600 text-white"
                    />
                  </div>
                </div>
              </CardContent>
            </CollapsibleContent>
          </Card>
        </Collapsible>

        {/* Ownership & Responsibilities */}
        <Collapsible open={openSections.ownership} onOpenChange={() => toggleSection('ownership')}>
          <Card className="bg-gray-800 border-gray-700">
            <CollapsibleTrigger className="w-full">
              <CardHeader className="hover:bg-gray-700/50 transition-colors">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg text-white flex items-center gap-2">
                    <Users className="h-5 w-5 text-purple-400" />
                    Ownership & Responsibilities
                  </CardTitle>
                  {openSections.ownership ? <ChevronDown className="h-5 w-5" /> : <ChevronRight className="h-5 w-5" />}
                </div>
              </CardHeader>
            </CollapsibleTrigger>
            <CollapsibleContent>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label className="text-white font-medium">Document Owner</Label>
                  <Input
                    value={metadata.document_owner}
                    onChange={(e) => setMetadata(prev => ({ ...prev, document_owner: e.target.value }))}
                    placeholder="Primary document owner"
                    className="bg-gray-700 border-gray-600 text-white"
                  />
                </div>
              </CardContent>
            </CollapsibleContent>
          </Card>
        </Collapsible>

        {/* Versioning & Change Control */}
        <Collapsible open={openSections.versioning} onOpenChange={() => toggleSection('versioning')}>
          <Card className="bg-gray-800 border-gray-700">
            <CollapsibleTrigger className="w-full">
              <CardHeader className="hover:bg-gray-700/50 transition-colors">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg text-white flex items-center gap-2">
                    <FileText className="h-5 w-5 text-orange-400" />
                    Versioning & Change Control
                  </CardTitle>
                  {openSections.versioning ? <ChevronDown className="h-5 w-5" /> : <ChevronRight className="h-5 w-5" />}
                </div>
              </CardHeader>
            </CollapsibleTrigger>
            <CollapsibleContent>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label className="text-white font-medium">Version</Label>
                    <Input
                      value={metadata.version}
                      onChange={(e) => setMetadata(prev => ({ ...prev, version: e.target.value }))}
                      placeholder="e.g., 1.0, 2023-Q1"
                      className="bg-gray-700 border-gray-600 text-white"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-white font-medium">Major Version</Label>
                    <Input
                      type="number"
                      value={metadata.version_major}
                      onChange={(e) => setMetadata(prev => ({ ...prev, version_major: parseInt(e.target.value) || 1 }))}
                      className="bg-gray-700 border-gray-600 text-white"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-white font-medium">Minor Version</Label>
                    <Input
                      type="number"
                      value={metadata.version_minor}
                      onChange={(e) => setMetadata(prev => ({ ...prev, version_minor: parseInt(e.target.value) || 0 }))}
                      className="bg-gray-700 border-gray-600 text-white"
                    />
                  </div>
                </div>
              </CardContent>
            </CollapsibleContent>
          </Card>
        </Collapsible>

        {/* Geographic Scope */}
        <Collapsible open={openSections.geography} onOpenChange={() => toggleSection('geography')}>
          <Card className="bg-gray-800 border-gray-700">
            <CollapsibleTrigger className="w-full">
              <CardHeader className="hover:bg-gray-700/50 transition-colors">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg text-white flex items-center gap-2">
                    <Globe className="h-5 w-5 text-cyan-400" />
                    Geographic Scope
                  </CardTitle>
                  {openSections.geography ? <ChevronDown className="h-5 w-5" /> : <ChevronRight className="h-5 w-5" />}
                </div>
              </CardHeader>
            </CollapsibleTrigger>
            <CollapsibleContent>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label className="text-white font-medium">Geographic Scope</Label>
                  <Select value={metadata.geographic_scope[0] || ''} onValueChange={(value) => setMetadata(prev => ({ ...prev, geographic_scope: value ? [value] : [] }))}>
                    <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                      <SelectValue placeholder="Select geographic scope" />
                    </SelectTrigger>
                    <SelectContent className="bg-gray-700 border-gray-600">
                      {enhancedOptions?.geographic_scopes.map((scope) => (
                        <SelectItem key={scope.value} value={scope.value} className="text-white hover:bg-gray-600">
                          {scope.display_name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </CollapsibleContent>
          </Card>
        </Collapsible>

        {/* Alert Generation */}
        <Collapsible open={openSections.alerts} onOpenChange={() => toggleSection('alerts')}>
          <Card className="bg-gray-800 border-gray-700">
            <CollapsibleTrigger className="w-full">
              <CardHeader className="hover:bg-gray-700/50 transition-colors">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg text-white flex items-center gap-2">
                    <AlertCircle className="h-5 w-5 text-amber-400" />
                    Alert Generation
                  </CardTitle>
                  {openSections.alerts ? <ChevronDown className="h-5 w-5" /> : <ChevronRight className="h-5 w-5" />}
                </div>
              </CardHeader>
            </CollapsibleTrigger>
            <CollapsibleContent>
              <CardContent className="space-y-4">
                <div className="p-4 bg-amber-600/10 border border-amber-600/30 rounded-lg">
                  <p className="text-amber-300 text-sm mb-3">
                    When this document is published, generate an alert for the selected module to notify users of relevant updates.
                  </p>
                  
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label className="text-white font-medium">Generate Alert For</Label>
                      <Select value={metadata.generate_alert} onValueChange={(value) => setMetadata(prev => ({ ...prev, generate_alert: value }))}>
                        <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                          <SelectValue placeholder="Select module (optional)" />
                        </SelectTrigger>
                        <SelectContent className="bg-gray-700 border-gray-600">
                          <SelectItem value="" className="text-white hover:bg-gray-600">None</SelectItem>
                          <SelectItem value="sanctions_embargoes" className="text-white hover:bg-gray-600">Sanctions & Embargoes</SelectItem>
                          <SelectItem value="product_classification" className="text-white hover:bg-gray-600">Product Classification</SelectItem>
                          <SelectItem value="customer_screening" className="text-white hover:bg-gray-600">Customer Screening</SelectItem>
                          <SelectItem value="end_use_checks" className="text-white hover:bg-gray-600">End-Use Checks</SelectItem>
                          <SelectItem value="risk_assessment" className="text-white hover:bg-gray-600">Risk Assessment</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    {metadata.generate_alert && (
                      <>
                        <div className="grid grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label className="text-white font-medium">Alert Severity</Label>
                            <Select value={metadata.alert_severity} onValueChange={(value) => setMetadata(prev => ({ ...prev, alert_severity: value }))}>
                              <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent className="bg-gray-700 border-gray-600">
                                <SelectItem value="low" className="text-white hover:bg-gray-600">
                                  <div className="flex items-center gap-2">
                                    <div className="w-2 h-2 rounded-full bg-green-400"></div>
                                    Low
                                  </div>
                                </SelectItem>
                                <SelectItem value="medium" className="text-white hover:bg-gray-600">
                                  <div className="flex items-center gap-2">
                                    <div className="w-2 h-2 rounded-full bg-yellow-400"></div>
                                    Medium
                                  </div>
                                </SelectItem>
                                <SelectItem value="high" className="text-white hover:bg-gray-600">
                                  <div className="flex items-center gap-2">
                                    <div className="w-2 h-2 rounded-full bg-orange-400"></div>
                                    High
                                  </div>
                                </SelectItem>
                                <SelectItem value="critical" className="text-white hover:bg-gray-600">
                                  <div className="flex items-center gap-2">
                                    <div className="w-2 h-2 rounded-full bg-red-400"></div>
                                    Critical
                                  </div>
                                </SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                          
                          <div className="space-y-2">
                            <Label className="text-white font-medium">Alert Expiration</Label>
                            <Input
                              type="date"
                              value={metadata.alert_expires_at}
                              onChange={(e) => setMetadata(prev => ({ ...prev, alert_expires_at: e.target.value }))}
                              className="bg-gray-700 border-gray-600 text-white"
                              placeholder="Optional expiration date"
                            />
                          </div>
                        </div>

                        <div className="space-y-2">
                          <Label className="text-white font-medium">Affected Jurisdictions (Optional)</Label>
                          <textarea
                            value={metadata.alert_jurisdictions.join(', ')}
                            onChange={(e) => {
                              const jurisdictions = e.target.value
                                .split(',')
                                .map(j => j.trim())
                                .filter(j => j.length > 0);
                              setMetadata(prev => ({ ...prev, alert_jurisdictions: jurisdictions }));
                            }}
                            className="bg-gray-700 border-gray-600 text-white min-h-[60px] resize-none p-2 rounded-md w-full"
                            placeholder="Enter jurisdictions separated by commas (e.g., US, EU, UK, CN)"
                            rows={2}
                          />
                          {metadata.alert_jurisdictions.length > 0 && (
                            <div className="flex flex-wrap gap-1 mt-2">
                              {metadata.alert_jurisdictions.map((jurisdiction, index) => (
                                <Badge key={index} variant="secondary" className="bg-amber-600 text-white text-xs">
                                  {jurisdiction}
                                </Badge>
                              ))}
                            </div>
                          )}
                        </div>
                      </>
                    )}
                  </div>
                </div>
              </CardContent>
            </CollapsibleContent>
          </Card>
        </Collapsible>
      </div>
    </div>
  );
}
