
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Users, 
  MessageSquare, 
  Bookmark, 
  Activity, 
  TrendingUp, 
  Eye, 
  Clock, 
  Award,
  BarChart3,
  Calendar
} from 'lucide-react';
import { useUserGuardContext } from 'app/auth';
import brain from 'brain';
import { CollaborationActivity } from 'types';
import { toast } from 'sonner';
import { formatDistanceToNow } from 'date-fns';
import { AnnotationPanel } from './AnnotationPanel';
import { BookmarkManager } from './BookmarkManager';
import { ActivityFeed } from './ActivityFeed';

interface Props {
  documentId?: number;
}

interface CollaborationStats {
  document_id?: number;
  total_annotations: number;
  active_users: number;
  pending_comments: number;
  resolved_comments: number;
  total_bookmarks: number;
  recent_activity_count: number;
  collaboration_score: number;
}

interface UserCollaborationSummary {
  user_id: string;
  total_annotations: number;
  total_bookmarks: number;
  documents_annotated: number;
  comments_posted: number;
  comments_resolved: number;
  activity_this_week: number;
  collaboration_level: string;
}

export function CollaborationDashboard({ documentId }: Props) {
  const { user } = useUserGuardContext();
  const [stats, setStats] = useState<CollaborationStats | null>(null);
  const [userSummary, setUserSummary] = useState<UserCollaborationSummary | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('overview');

  useEffect(() => {
    loadCollaborationData();
  }, [documentId]);

  const loadCollaborationData = async () => {
    try {
      setLoading(true);
      
      // Load user collaboration summary
      const userResponse = await brain.get_user_collaboration_summary();
      if (userResponse.ok) {
        const userData = await userResponse.json();
        setUserSummary(userData);
      }
      
      // Load document collaboration stats if documentId is provided
      if (documentId) {
        const docResponse = await brain.get_collaboration_stats({ documentId });
        if (docResponse.ok) {
          const docData = await docResponse.json();
          setStats(docData);
        }
      }
    } catch (error) {
      console.error('Error loading collaboration data:', error);
      toast.error('Failed to load collaboration data');
    } finally {
      setLoading(false);
    }
  };

  const getCollaborationLevelColor = (level: string) => {
    switch (level.toLowerCase()) {
      case 'expert': return 'bg-emerald-600';
      case 'intermediate': return 'bg-blue-600';
      case 'novice': return 'bg-yellow-600';
      default: return 'bg-gray-600';
    }
  };

  const getScoreColor = (score: number) => {
    if (score >= 80) return 'text-emerald-400';
    if (score >= 60) return 'text-blue-400';
    if (score >= 40) return 'text-yellow-400';
    return 'text-red-400';
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="text-gray-400">Loading collaboration dashboard...</div>
      </div>
    );
  }

  return (
    <div className="w-full space-y-6">
      {/* Header */}
      <div className="flex items-center gap-3">
        <Users className="h-6 w-6 text-blue-400" />
        <h2 className="text-2xl font-bold text-gray-100">Collaboration Dashboard</h2>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-4 bg-gray-800 border-gray-700">
          <TabsTrigger value="overview" className="data-[state=active]:bg-gray-700">Overview</TabsTrigger>
          <TabsTrigger value="annotations" className="data-[state=active]:bg-gray-700">Annotations</TabsTrigger>
          <TabsTrigger value="bookmarks" className="data-[state=active]:bg-gray-700">Bookmarks</TabsTrigger>
          <TabsTrigger value="activity" className="data-[state=active]:bg-gray-700">Activity</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          {/* User Summary Card */}
          {userSummary && (
            <Card className="bg-gradient-to-r from-blue-900/20 to-purple-900/20 border-gray-700">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-gray-100">
                  <Award className="h-5 w-5 text-yellow-400" />
                  Your Collaboration Profile
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-blue-400">{userSummary.total_annotations}</div>
                    <div className="text-sm text-gray-400">Total Annotations</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-green-400">{userSummary.total_bookmarks}</div>
                    <div className="text-sm text-gray-400">Bookmarks</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-purple-400">{userSummary.documents_annotated}</div>
                    <div className="text-sm text-gray-400">Documents Annotated</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-orange-400">{userSummary.activity_this_week}</div>
                    <div className="text-sm text-gray-400">This Week's Activity</div>
                  </div>
                </div>
                
                <div className="mt-4 flex items-center justify-center">
                  <Badge className={`${getCollaborationLevelColor(userSummary.collaboration_level)} text-white px-3 py-1`}>
                    {userSummary.collaboration_level} Collaborator
                  </Badge>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Document Stats (if documentId provided) */}
          {stats && documentId && (
            <Card className="bg-gray-800/50 border-gray-700">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-gray-100">
                  <BarChart3 className="h-5 w-5 text-blue-400" />
                  Document Collaboration Stats
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                  <div className="bg-gray-700/50 p-3 rounded">
                    <div className="flex items-center gap-2 mb-2">
                      <MessageSquare className="h-4 w-4 text-blue-400" />
                      <span className="text-sm text-gray-400">Annotations</span>
                    </div>
                    <div className="text-xl font-bold text-gray-100">{stats.total_annotations}</div>
                  </div>
                  
                  <div className="bg-gray-700/50 p-3 rounded">
                    <div className="flex items-center gap-2 mb-2">
                      <Users className="h-4 w-4 text-green-400" />
                      <span className="text-sm text-gray-400">Active Users</span>
                    </div>
                    <div className="text-xl font-bold text-gray-100">{stats.active_users}</div>
                  </div>
                  
                  <div className="bg-gray-700/50 p-3 rounded">
                    <div className="flex items-center gap-2 mb-2">
                      <Bookmark className="h-4 w-4 text-yellow-400" />
                      <span className="text-sm text-gray-400">Bookmarks</span>
                    </div>
                    <div className="text-xl font-bold text-gray-100">{stats.total_bookmarks}</div>
                  </div>
                  
                  <div className="bg-gray-700/50 p-3 rounded">
                    <div className="flex items-center gap-2 mb-2">
                      <Activity className="h-4 w-4 text-purple-400" />
                      <span className="text-sm text-gray-400">Recent Activity</span>
                    </div>
                    <div className="text-xl font-bold text-gray-100">{stats.recent_activity_count}</div>
                  </div>
                </div>
                
                <div className="flex items-center justify-between p-3 bg-gray-700/30 rounded">
                  <span className="text-gray-300">Collaboration Score</span>
                  <div className="flex items-center gap-2">
                    <div className={`text-2xl font-bold ${getScoreColor(stats.collaboration_score)}`}>
                      {stats.collaboration_score}/100
                    </div>
                    <TrendingUp className={`h-5 w-5 ${getScoreColor(stats.collaboration_score)}`} />
                  </div>
                </div>
                
                <div className="mt-4 grid grid-cols-2 gap-4">
                  <div className="text-center p-3 bg-green-600/10 rounded border border-green-600/20">
                    <div className="text-lg font-bold text-green-400">{stats.resolved_comments}</div>
                    <div className="text-xs text-gray-400">Resolved Comments</div>
                  </div>
                  <div className="text-center p-3 bg-yellow-600/10 rounded border border-yellow-600/20">
                    <div className="text-lg font-bold text-yellow-400">{stats.pending_comments}</div>
                    <div className="text-xs text-gray-400">Pending Comments</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Quick Actions */}
          <Card className="bg-gray-800/50 border-gray-700">
            <CardHeader>
              <CardTitle className="text-gray-100">Quick Actions</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <Button 
                  onClick={() => setActiveTab('annotations')} 
                  className="bg-blue-600 hover:bg-blue-700 justify-start"
                >
                  <MessageSquare className="h-4 w-4 mr-2" />
                  View Annotations
                </Button>
                <Button 
                  onClick={() => setActiveTab('bookmarks')} 
                  className="bg-green-600 hover:bg-green-700 justify-start"
                >
                  <Bookmark className="h-4 w-4 mr-2" />
                  Manage Bookmarks
                </Button>
                <Button 
                  onClick={() => setActiveTab('activity')} 
                  className="bg-purple-600 hover:bg-purple-700 justify-start"
                >
                  <Activity className="h-4 w-4 mr-2" />
                  View Activity
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="annotations">
          <AnnotationPanel 
            documentId={documentId || 1} 
            onAnnotationCreated={loadCollaborationData}
          />
        </TabsContent>

        <TabsContent value="bookmarks">
          <BookmarkManager 
            documentId={documentId}
            onBookmarkClick={(bookmark) => {
              // Handle bookmark navigation
              toast.info(`Navigate to document: ${bookmark.document_title}`);
            }}
          />
        </TabsContent>

        <TabsContent value="activity">
          <ActivityFeed documentId={documentId} />
        </TabsContent>
      </Tabs>
    </div>
  );
}
