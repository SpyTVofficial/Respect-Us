


import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import {
  FileText,
  BarChart3,
  Target,
  Globe,
  Users,
  Search,
  Shield,
  Mail,
  Phone,
  MapPin,
  ExternalLink,
  Package
} from 'lucide-react';

export default function Footer() {
  const navigate = useNavigate();

  const modules = [
    { name: 'Knowledge Base', path: '/knowledge-base', icon: <FileText className="w-4 h-4" /> },
    { name: 'Product Classification', path: '/product-classification', icon: <Package className="w-4 h-4" /> },
    { name: 'Risk Assessment', path: '/risk-assessment', icon: <BarChart3 className="w-4 h-4" /> },
    { name: 'Sanctions & Embargoes', path: '/sanctions-embargoes', icon: <Globe className="w-4 h-4" /> },
    { name: 'Customer Screening', path: '/customer-screening', icon: <Users className="w-4 h-4" /> },
    { name: 'End-Use Checks', path: '/EndUseChecks', icon: <Target className="w-4 h-4" /> },
    { name: 'License Determination', path: '#', icon: <Shield className="w-4 h-4" /> }
  ];

  const quickLinks = [
    { name: 'Dashboard', path: '/user-dashboard' },
    { name: 'Getting Started', path: '/user-dashboard?tab=getting-started' },
    { name: 'Documentation', path: '#' },
    { name: 'Support', path: 'mailto:contact@respectus.space' }
  ];

  const handleNavigation = (path: string) => {
    if (path.startsWith('mailto:')) {
      window.open(path, '_blank');
    } else if (path !== '#') {
      navigate(path);
    }
  };

  return (
    <footer className="bg-gray-900/95 border-t border-gray-700 mt-20">
      <div className="max-w-7xl mx-auto px-6 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Brand Section */}
          <div className="lg:col-span-1">
            <div className="flex items-center space-x-2 mb-4">
              <img 
                src="https://static.databutton.com/public/a180dafe-f6c8-4fb7-917a-f8d4b9bfe1b1/White_svg.svg" 
                alt="RespectUs Logo" 
                className="h-8 w-auto"
              />
              <span className="text-white font-bold text-xl">RespectUs</span>
            </div>
            <p className="text-gray-400 text-sm mb-6">
              Your comprehensive digital platform for export control compliance. 
              Streamline your compliance workflow with our suite of professional tools.
            </p>
            <div className="space-y-2">
              <div className="flex items-center space-x-2 text-gray-400 text-sm">
                <Mail className="w-4 h-4" />
                <span>contact@respectus.space</span>
              </div>
              <div className="flex items-center space-x-2 text-gray-400 text-sm">
                <Phone className="w-4 h-4" />
                <span>+352 2786 4123</span>
              </div>
              <div className="flex items-center space-x-2 text-gray-400 text-sm">
                <MapPin className="w-4 h-4" />
                <span>Global Compliance Solutions</span>
              </div>
            </div>
          </div>

          {/* Compliance Modules */}
          <div>
            <h3 className="text-white font-semibold mb-4">Compliance Modules</h3>
            <div className="space-y-2">
              {modules.map((module) => (
                <Button
                  key={module.name}
                  variant="ghost"
                  onClick={() => handleNavigation(module.path)}
                  className={`w-full justify-start text-gray-400 hover:text-white p-2 h-auto ${
                    module.path === '#' ? 'opacity-60 cursor-not-allowed' : 'hover:bg-gray-800'
                  }`}
                  disabled={module.path === '#'}
                >
                  <span className="mr-2">{module.icon}</span>
                  <span className="text-sm">{module.name}</span>
                  {module.path === '#' && (
                    <span className="ml-auto text-xs text-gray-500">Coming Soon</span>
                  )}
                </Button>
              ))}
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-white font-semibold mb-4">Quick Links</h3>
            <div className="space-y-2">
              {quickLinks.map((link) => (
                <Button
                  key={link.name}
                  variant="ghost"
                  onClick={() => handleNavigation(link.path)}
                  className="w-full justify-start text-gray-400 hover:text-white hover:bg-gray-800 p-2 h-auto"
                >
                  <span className="text-sm">{link.name}</span>
                  {link.path.startsWith('mailto:') && (
                    <ExternalLink className="w-3 h-3 ml-auto" />
                  )}
                </Button>
              ))}
            </div>
          </div>

          {/* Professional Services */}
          <div>
            <h3 className="text-white font-semibold mb-4">Professional Services</h3>
            <div className="space-y-3">
              <div className="text-gray-400 text-sm">
                <p className="mb-2">Expert compliance support and consulting services:</p>
                <ul className="space-y-1 text-xs">
                  <li>• Assessment Validation</li>
                  <li>• Compliance Consulting</li>
                  <li>• Training & Workshops</li>
                  <li>• Audit Services</li>
                </ul>
              </div>
              <Button
                variant="outline"
                onClick={() => window.open('mailto:contact@respectus.space?subject=Professional Services Inquiry', '_blank')}
                className="w-full border-blue-500/30 text-blue-400 hover:bg-blue-500/10 text-sm"
              >
                <Mail className="w-4 h-4 mr-2" />
                Contact Experts
              </Button>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-gray-700 mt-8 pt-6">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
            <div className="text-gray-400 text-sm">
              © 2025 RespectUs. All rights reserved. Digital platform for export control compliance.
            </div>
            <div className="flex items-center space-x-6 text-sm">
              <Button
                variant="ghost"
                onClick={() => handleNavigation('#')}
                className="text-gray-400 hover:text-white p-0 h-auto"
              >
                Privacy Policy
              </Button>
              <Button
                variant="ghost"
                onClick={() => handleNavigation('#')}
                className="text-gray-400 hover:text-white p-0 h-auto"
              >
                Terms of Service
              </Button>
              <Button
                variant="ghost"
                onClick={() => handleNavigation('#')}
                className="text-gray-400 hover:text-white p-0 h-auto"
              >
                Cookie Policy
              </Button>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
