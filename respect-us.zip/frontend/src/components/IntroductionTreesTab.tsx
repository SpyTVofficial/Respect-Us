import React, { useState, useEffect, useRef } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { ChevronDown, ChevronRight, Edit, Trash2, Plus, FileText, Target, Settings, Eye, EyeOff, MoreHorizontal, Edit3, Copy, Save, X, AlertTriangle, CheckCircle, XCircle, Download, Upload, TreePine, Workflow, FileUp, Hash, ArrowRight } from 'lucide-react';
import { toast } from 'sonner';
import brain from 'brain';
import TreeCard from 'components/TreeCard';
import type {
  TreeNode,
  NodeOption,
  ClassificationOutcome,
  AppApisClassificationClassificationTree as ClassificationTree,
  ClassificationNote
} from '../brain/data-contracts';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';

interface IntroductionTreesTabProps {
  onCreateTree: () => void;
  onEditTree?: (tree: ClassificationTree) => void;
  onCreateNode: (tree: ClassificationTree) => void;
  onEditNode?: (node: TreeNode) => void;
  onManageNodeOptions?: (node: TreeNode) => void;
  onRefresh?: (refreshFunction: () => void) => void;
}

const IntroductionTreesTab: React.FC<IntroductionTreesTabProps> = ({
  onCreateTree,
  onEditTree,
  onCreateNode,
  onEditNode,
  onManageNodeOptions,
  onRefresh
}) => {
  const [introductionTrees, setIntroductionTrees] = useState<ClassificationTree[]>([]);
  const [selectedTree, setSelectedTree] = useState<ClassificationTree | null>(null);
  const [treeNodes, setTreeNodes] = useState<TreeNode[]>([]);
  const [nodeOptions, setNodeOptions] = useState<{ [nodeId: string]: NodeOption[] }>({});
  const [loading, setLoading] = useState(true);
  
  // Add state for editing Introduction Trees
  const [showEditTreeDialog, setShowEditTreeDialog] = useState(false);
  const [editingTree, setEditingTree] = useState<ClassificationTree | null>(null);
  const [updatingTree, setUpdatingTree] = useState(false);
  const [editTreeData, setEditTreeData] = useState({
    name: '',
    description: '',
    jurisdiction: '',
    category: '',
    status: 'draft'
  });
  
  const [editingNode, setEditingNode] = useState<TreeNode | null>(null);
  const [editNodeForm, setEditNodeForm] = useState({
    node_key: '',
    title: '',
    description: '',
    question_text: '',
    question_type: 'multiple_choice',
    parent_node_id: null,
    display_order: 0,
    is_root: false,
    notes: '',
    routing_rule: '',
    // Multi-question assessment fields
    multi_questions: [] as Array<{key: string, text: string, regulatory_notes?: string[]}>,
    outcome_rules: [] as Array<{priority: number, logic: Record<string, any>, target: string, target_type: string, description?: string}>
  });
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [showEditNodeDialog, setShowEditNodeDialog] = useState(false);
  const [managingOptionsForNode, setManagingOptionsForNode] = useState<TreeNode | null>(null);
  const [showManageOptionsDialog, setShowManageOptionsDialog] = useState(false);
  const [newOptionData, setNewOptionData] = useState({
    option_text: '',
    option_value: '',
    routing_rule: '',
    display_order: 0,
    notes: ''
  });
  const [loadingOptions, setLoadingOptions] = useState(true);
  const [currentNodeOptions, setCurrentNodeOptions] = useState<NodeOption[]>([]);
  const [updatingNode, setUpdatingNode] = useState(false);
  
  // Use ref to always get current selected tree
  const selectedTreeRef = useRef<ClassificationTree | null>(null);
  
  // Update ref whenever selectedTree changes
  useEffect(() => {
    selectedTreeRef.current = selectedTree;
  }, [selectedTree]);

  const loadIntroductionTrees = async () => {
    try {
      setLoading(true);
      const response = await brain.list_introduction_trees();
      if (response.ok) {
        const trees = await response.json();
        setIntroductionTrees(trees);
      } else {
        toast.error('Failed to load introduction trees');
      }
    } catch (error) {
      console.error('Error loading introduction trees:', error);
      toast.error('Failed to load introduction trees');
    } finally {
      setLoading(false);
    }
  };

  const loadTreeData = async (treeId: string) => {
    try {
      // Load tree nodes
      const nodesResponse = await brain.list_introduction_tree_nodes({ treeId });
      if (nodesResponse.ok) {
        const nodes = await nodesResponse.json();
        setTreeNodes(nodes);
        
        // Load options for each node
        const optionsMap: { [nodeId: string]: NodeOption[] } = {};
        for (const node of nodes) {
          try {
            const optionsResponse = await brain.list_introduction_node_options({ nodeId: node.id });
            if (optionsResponse.ok) {
              const options = await optionsResponse.json();
              optionsMap[node.id] = options;
            }
          } catch (error) {
            console.error(`Error loading options for node ${node.id}:`, error);
          }
        }
        setNodeOptions(optionsMap);
      }
    } catch (error) {
      console.error('Error loading tree data:', error);
      toast.error('Failed to load tree data');
    }
  };

  const handleTreeSelect = (tree: ClassificationTree) => {
    setSelectedTree(tree);
    loadTreeData(tree.id);
  };

  const handleTreesReload = () => {
    loadIntroductionTrees();
  };

  const handleEditNode = (node: TreeNode, e: React.MouseEvent) => {
    e.stopPropagation();
    setEditingNode(node);
    setEditNodeForm({
      node_key: node.node_key,
      title: node.title,
      description: node.description || '',
      question_text: node.question_text || '',
      question_type: node.question_type || 'multiple_choice',
      parent_node_id: node.parent_node_id || null,
      display_order: node.display_order || 0,
      is_root: node.is_root || false,
      notes: node.notes || '',
      routing_rule: node.routing_rule || '',
      // Multi-question assessment fields
      multi_questions: node.multi_questions || [],
      outcome_rules: node.outcome_rules || []
    });
    setSelectedFile(null); // Reset file selection when opening dialog
    setShowEditNodeDialog(true);
  };

  const handleManageOptions = (node: TreeNode, e: React.MouseEvent) => {
    e.stopPropagation();
    setManagingOptionsForNode(node);
    setShowManageOptionsDialog(true);
  };

  const handleDuplicateNode = async (node: TreeNode, e: React.MouseEvent) => {
    e.stopPropagation();
    try {
      await brain.duplicate_introduction_tree_node({ nodeId: node.id });
      toast.success('Node duplicated successfully');
      if (selectedTree) {
        loadTreeData(selectedTree.id);
      }
    } catch (error) {
      console.error('Error duplicating node:', error);
      toast.error('Failed to duplicate node');
    }
  };

  const handleDeleteNode = async (node: TreeNode, e: React.MouseEvent) => {
    e.stopPropagation();
    if (window.confirm(`Are you sure you want to delete node "${node.title}"? This action cannot be undone.`)) {
      try {
        await brain.delete_introduction_tree_node({ nodeId: node.id });
        toast.success('Node deleted successfully');
        if (selectedTree) {
          loadTreeData(selectedTree.id);
        }
      } catch (error) {
        console.error('Error deleting node:', error);
        toast.error('Failed to delete node');
      }
    }
  };

  const renderNode = (node: TreeNode & { children: TreeNode[] }, depth = 0) => {
    const options = nodeOptions[node.id] || [];
    
    return (
      <div key={node.id} className={`ml-${depth * 4}`}>
        <div className="border border-gray-600 rounded-lg p-4 bg-gray-800/30 mb-2">
          <div className="flex justify-between items-start">
            <div className="flex-1">
              <h4 className="font-semibold text-white">{node.title}</h4>
              <p className="text-gray-400 text-sm mt-1">{node.description}</p>
              <div className="flex items-center gap-2 mt-2">
                <Badge variant="outline" className="text-xs">
                  <Hash className="w-3 h-3 mr-1" />
                  {node.node_key}
                </Badge>
                <Badge variant="outline" className="text-xs">
                  {node.question_type}
                </Badge>
                {node.routing_rule && (
                  <Badge variant="outline" className="text-xs text-blue-300 border-blue-500/50">
                    Routes to: {node.routing_rule}
                  </Badge>
                )}
              </div>
              {node.question_text && (
                <div className="mt-2 p-2 bg-gray-700/50 rounded text-sm text-gray-300">
                  <strong>Question:</strong> {node.question_text}
                </div>
              )}
            </div>
            <div className="flex gap-2 ml-4">
              <Button
                size="sm"
                variant="outline"
                onClick={(e) => handleEditNode(node, e)}
                className="text-yellow-400 border-yellow-500 hover:bg-yellow-500/20"
                title="Edit Node"
              >
                <Edit3 className="w-3 h-3 mr-1" />
                EDIT
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={(e) => handleManageOptions(node, e)}
                className="text-purple-400 border-purple-500 hover:bg-purple-500/20"
                title="Manage Options"
              >
                <Settings className="w-3 h-3 mr-1" />
                OPTIONS
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={(e) => handleDuplicateNode(node, e)}
                className="text-blue-400 border-blue-500 hover:bg-blue-500/20"
                title="Duplicate Node"
              >
                <Copy className="w-3 h-3" />
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={(e) => handleDeleteNode(node, e)}
                className="text-red-400 border-red-500 hover:bg-red-500/20"
                title="Delete Node"
              >
                <Trash2 className="w-3 h-3" />
              </Button>
            </div>
          </div>
          
          {options.length > 0 && (
            <div className="mt-3">
              <h5 className="text-sm font-medium text-gray-300 mb-2">Options:</h5>
              <div className="space-y-1">
                {options.map((option) => (
                  <div key={option.id} className="flex items-center justify-between p-2 bg-gray-700/30 rounded text-sm">
                    <div className="flex-1">
                      <span className="text-white">{option.option_text}</span>
                      {option.routing_rule && (
                        <div className="flex items-center gap-2 mt-1">
                          <Badge variant="outline" className="text-xs text-cyan-300 border-cyan-500/50 bg-cyan-500/10">
                            <ArrowRight className="w-3 h-3 mr-1" />
                            Routes to: {option.routing_rule}
                          </Badge>
                        </div>
                      )}
                    </div>
                    {option.leads_to_outcome && (
                      <Badge className="bg-green-500/20 text-green-300 border-green-500/30">
                        Outcome
                      </Badge>
                    )}
                    {option.next_node_id && (
                      <div className="flex items-center text-blue-300">
                        <ArrowRight className="w-3 h-3 mr-1" />
                        Next Node
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
        
        {node.children.map(child => renderNode(child, depth + 1))}
      </div>
    );
  };

  const buildTreeStructure = (nodes: TreeNode[]) => {
    const sortedNodes = [...nodes].sort((a, b) => a.node_key.localeCompare(b.node_key));
    const nodeMap = new Map<string, TreeNode & { children: TreeNode[] }>();
    const rootNodes: (TreeNode & { children: TreeNode[] })[] = [];

    // First pass: create all nodes with children arrays
    for (const node of sortedNodes) {
      nodeMap.set(node.id, { ...node, children: [] });
    }

    // Second pass: build the tree structure
    for (const node of sortedNodes) {
      const nodeWithChildren = nodeMap.get(node.id)!;
      
      if (node.parent_node_id && nodeMap.has(node.parent_node_id)) {
        const parent = nodeMap.get(node.parent_node_id)!;
        parent.children.push(nodeWithChildren);
      } else {
        rootNodes.push(nodeWithChildren);
      }
    }

    return rootNodes;
  };

  const loadNodeOptions = async (nodeId: string) => {
    try {
      setLoadingOptions(true);
      const response = await brain.list_introduction_node_options({ nodeId });
      if (response.ok) {
        const options = await response.json();
        setCurrentNodeOptions(options);
      } else {
        toast.error('Failed to load options');
      }
    } catch (error) {
      console.error('Error loading options:', error);
      toast.error('Failed to load options');
    } finally {
      setLoadingOptions(false);
    }
  };

  // Refresh function to reload current tree data
  const refreshCurrentTreeData = () => {
    if (selectedTree) {
      loadTreeData(selectedTree.id);
    }
  };

  // Expose refresh function to parent through callback
  useEffect(() => {
    if (onRefresh) {
      onRefresh(() => {
        // Use ref to get current selected tree
        const currentTree = selectedTreeRef.current;
        if (currentTree) {
          loadTreeData(currentTree.id);
        }
      });
    }
  }, [onRefresh]);

  useEffect(() => {
    loadIntroductionTrees();
  }, []);

  const handleEditNodeSubmit = async () => {
    if (!editingNode) return;
    
    try {
      setUpdatingNode(true);
      
      // TODO: Handle file upload if selectedFile exists
      // For now, we'll just show a message about the file
      if (selectedFile) {
        console.log('File selected for upload:', selectedFile.name);
        toast.info(`File "${selectedFile.name}" will be associated with this node`);
        // In a real implementation, you would upload the file to storage
        // and include the file URL or ID in the node update
      }
      
      await brain.update_introduction_tree_node(
        { nodeId: editingNode.id },
        {
          node_key: editNodeForm.node_key,
          title: editNodeForm.title,
          description: editNodeForm.description,
          question_text: editNodeForm.question_text,
          question_type: editNodeForm.question_type,
          parent_node_id: editNodeForm.parent_node_id,
          display_order: editNodeForm.display_order,
          is_root: editNodeForm.is_root,
          notes: editNodeForm.notes,
          routing_rule: editNodeForm.routing_rule,
          // Multi-question assessment fields
          multi_questions: editNodeForm.multi_questions,
          outcome_rules: editNodeForm.outcome_rules
        }
      );
      toast.success('Node updated successfully');
      if (selectedTree) {
        loadTreeData(selectedTree.id);
      }
      setShowEditNodeDialog(false);
      setSelectedFile(null); // Reset file selection when closing
    } catch (error) {
      console.error('Error updating node:', error);
      toast.error('Failed to update node');
    } finally {
      setUpdatingNode(false);
    }
  };

  // Add handler for editing Introduction Trees
  const handleEditTree = (tree: ClassificationTree) => {
    setEditingTree(tree);
    setEditTreeData({
      name: tree.name,
      description: tree.description || '',
      jurisdiction: tree.jurisdiction,
      category: tree.category,
      status: tree.status
    });
    setShowEditTreeDialog(true);
  };

  const handleCreateOption = async () => {
    if (!managingOptionsForNode || !newOptionData.option_text.trim() || !newOptionData.option_value.trim()) {
      toast.error('Please fill in required fields');
      return;
    }
    
    try {
      const response = await brain.create_introduction_node_option(
        { nodeId: managingOptionsForNode.id },
        {
          option_text: newOptionData.option_text,
          option_value: newOptionData.option_value,
          routing_rule: newOptionData.routing_rule || '',
          display_order: newOptionData.display_order,
          regulatory_notes: [],
          note: newOptionData.notes
        }
      );
      
      if (response.ok) {
        toast.success('Option created successfully');
        setNewOptionData({
          option_text: '',
          option_value: '',
          routing_rule: '',
          display_order: 0,
          notes: ''
        });
        // Reload options for this node
        if (managingOptionsForNode) {
          loadNodeOptions(managingOptionsForNode.id);
        }
      } else {
        toast.error('Failed to create option');
      }
    } catch (error) {
      console.error('Error creating option:', error);
      toast.error('Failed to create option');
    }
  };

  const [editingIntroOption, setEditingIntroOption] = useState<IntroductionNodeOption | null>(null);
  const [isEditIntroOptionDialogOpen, setIsEditIntroOptionDialogOpen] = useState(false);
  const [editIntroOptionForm, setEditIntroOptionForm] = useState({
    option_text: '',
    option_value: '',
    routing_rule: '',
    display_order: 0,
    regulatory_notes: [] as string[],
    note: ''
  });

  const handleEditIntroOption = (option: IntroductionNodeOption) => {
    setEditingIntroOption(option);
    setEditIntroOptionForm({
      option_text: option.option_text,
      option_value: option.option_value,
      routing_rule: option.routing_rule || '',
      display_order: option.display_order || 0,
      regulatory_notes: option.regulatory_notes || [],
      note: option.note || ''
    });
    setIsEditIntroOptionDialogOpen(true);
  };

  const handleUpdateIntroOption = async () => {
    if (!editingIntroOption || !editIntroOptionForm.option_text.trim() || !editIntroOptionForm.option_value.trim()) {
      toast.error('Please fill in both option text and value');
      return;
    }

    try {
      const response = await brain.update_introduction_node_option(
        { optionId: editingIntroOption.id },
        {
          option_text: editIntroOptionForm.option_text.trim(),
          option_value: editIntroOptionForm.option_value.trim(),
          routing_rule: editIntroOptionForm.routing_rule.trim() || null,
          display_order: editIntroOptionForm.display_order,
          regulatory_notes: editIntroOptionForm.regulatory_notes.length > 0 ? editIntroOptionForm.regulatory_notes : null,
          note: editIntroOptionForm.note.trim() || null
        }
      );
      
      if (response.ok) {
        toast.success(`Updated option "${editIntroOptionForm.option_text}"`);
        setIsEditIntroOptionDialogOpen(false);
        setEditingIntroOption(null);
        // Reload node options
        if (managingOptionsForNode) {
          loadNodeOptions(managingOptionsForNode.id);
        }
      } else {
        const errorData = await response.json().catch(() => null);
        toast.error(`Failed to update option: ${errorData?.detail || 'Unknown error'}`);
      }
    } catch (error) {
      console.error('Error updating Introduction Tree option:', error);
      toast.error('Failed to update option. Please try again.');
    }
  };

  return (
    <div className="space-y-6">
      <Card className="bg-gray-800/50 border-gray-700">
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle className="text-blue-400">Introduction Trees</CardTitle>
            <Button 
              onClick={onCreateTree}
              className="bg-blue-600 hover:bg-blue-700 text-white"
            >
              <Plus className="w-4 h-4 mr-2" />
              Create Introduction Tree
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {loading ? (
            <p className="text-gray-400">Loading introduction trees...</p>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {introductionTrees.map((tree) => (
                <TreeCard
                  key={tree.id}
                  tree={tree}
                  isSelected={selectedTree?.id === tree.id}
                  onTreeSelect={handleTreeSelect}
                  onCreateNode={onCreateNode}
                  onEditTree={handleEditTree}
                  onTreesReload={handleTreesReload}
                  variant="introduction"
                />
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {selectedTree && (
        <Card className="bg-gray-800/50 border-gray-700">
          <CardHeader>
            <CardTitle className="text-blue-400">Tree Structure: {selectedTree.name}</CardTitle>
          </CardHeader>
          <CardContent>
            {treeNodes.length === 0 ? (
              <p className="text-gray-400">No nodes found in this introduction tree.</p>
            ) : (
              <div className="space-y-2">
                {buildTreeStructure(treeNodes).map((node) => renderNode(node))}
              </div>
            )}
          </CardContent>
        </Card>
      )}
      
      {showEditNodeDialog && editingNode && (
        <Dialog open={showEditNodeDialog} onOpenChange={setShowEditNodeDialog}>
          <DialogContent className="bg-gray-900 border-gray-700 text-white max-w-4xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="text-blue-400">Edit Introduction Node</DialogTitle>
              <DialogDescription className="text-gray-400">
                Update the details of the selected introduction node
              </DialogDescription>
            </DialogHeader>
            
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-300">Node Key *</label>
                  <Input
                    value={editNodeForm.node_key}
                    onChange={(e) => setEditNodeForm({ ...editNodeForm, node_key: e.target.value })}
                    className="bg-gray-800 border-gray-600 text-white"
                    placeholder="e.g., START, Q1, Q2"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-300">Title *</label>
                  <Input
                    value={editNodeForm.title}
                    onChange={(e) => setEditNodeForm({ ...editNodeForm, title: e.target.value })}
                    className="bg-gray-800 border-gray-600 text-white"
                    placeholder="Node title"
                    required
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-300">Question Text</label>
                <Textarea
                  value={editNodeForm.question_text}
                  onChange={(e) => setEditNodeForm({ ...editNodeForm, question_text: e.target.value })}
                  className="bg-gray-800 border-gray-600 text-white"
                  placeholder="Enter the question to ask users"
                  rows={3}
                />
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-300">Description</label>
                <Textarea
                  value={editNodeForm.description}
                  onChange={(e) => setEditNodeForm({ ...editNodeForm, description: e.target.value })}
                  className="bg-gray-800 border-gray-600 text-white"
                  placeholder="Additional details about this node"
                  rows={2}
                />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-300">Question Type</label>
                  <Select value={editNodeForm.question_type} onValueChange={(value) => setEditNodeForm({ ...editNodeForm, question_type: value })}>
                    <SelectTrigger className="bg-gray-800 border-gray-600 text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-gray-800 border-gray-600">
                      <SelectItem value="multiple_choice" className="text-white">Multiple Choice</SelectItem>
                      <SelectItem value="yes_no" className="text-white">Yes/No</SelectItem>
                      <SelectItem value="text_input" className="text-white">Text Input</SelectItem>
                      <SelectItem value="number_input" className="text-white">Number Input</SelectItem>
                      <SelectItem value="file_upload" className="text-white">File Upload</SelectItem>
                      <SelectItem value="multi_question_assessment" className="text-white">Multi-Question Assessment</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-300">Parent Node</label>
                  <Select value={editNodeForm.parent_node_id ? editNodeForm.parent_node_id : 'none'} onValueChange={(value) => setEditNodeForm({ ...editNodeForm, parent_node_id: value === 'none' ? null : value })}>
                    <SelectTrigger className="bg-gray-800 border-gray-600 text-white">
                      <SelectValue placeholder="Select parent node" />
                    </SelectTrigger>
                    <SelectContent className="bg-gray-800 border-gray-600">
                      <SelectItem value="none" className="text-white">No Parent (Root)</SelectItem>
                      {treeNodes.filter(n => n.id !== editingNode?.id && n.id && n.id.trim() !== '').map(node => (
                        <SelectItem key={node.id} value={node.id} className="text-white">
                          {node.node_key} - {node.title}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div className="grid grid-cols-3 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-300">Display Order</label>
                  <Input
                    type="number"
                    value={editNodeForm.display_order}
                    onChange={(e) => setEditNodeForm({ ...editNodeForm, display_order: parseInt(e.target.value) || 0 })}
                    className="bg-gray-800 border-gray-600 text-white"
                    min="0"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-300">Root Node</label>
                  <div className="flex items-center space-x-2 mt-2">
                    <Checkbox
                      checked={editNodeForm.is_root}
                      onCheckedChange={(checked) => setEditNodeForm({ ...editNodeForm, is_root: checked as boolean })}
                      className="border-gray-600"
                    />
                    <span className="text-sm text-gray-400">Mark as root node</span>
                  </div>
                </div>
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-300">Administrative Notes</label>
                <Textarea
                  value={editNodeForm.notes}
                  onChange={(e) => setEditNodeForm({ ...editNodeForm, notes: e.target.value })}
                  className="bg-gray-800 border-gray-600 text-white"
                  placeholder="Internal notes for administrators"
                  rows={2}
                />
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-300">Routing Rule</label>
                
                {/* Instructions for routing rule usage */}
                <div className="bg-blue-900/30 border border-blue-700/50 rounded-lg p-3 mb-3">
                  <div className="flex items-start gap-2">
                    <span className="text-blue-400 text-sm">💡</span>
                    <div className="text-sm text-blue-300">
                      <p className="font-medium mb-1">When to use Routing Rule:</p>
                      <ul className="text-xs space-y-1 text-blue-200">
                        <li>• <strong>Text/Number Input nodes:</strong> Specify where users go after submitting their answer</li>
                        <li>• <strong>Multiple Choice nodes:</strong> Leave empty - routing is handled by individual options</li>
                        <li>• <strong>Format:</strong> Use a Classification Tree ID to direct users to that tree</li>
                      </ul>
                    </div>
                  </div>
                </div>
                
                <Input
                  value={editNodeForm.routing_rule}
                  onChange={(e) => setEditNodeForm({ ...editNodeForm, routing_rule: e.target.value })}
                  className="bg-gray-800 border-gray-600 text-white"
                  placeholder="Enter Classification Tree ID for routing (leave empty for multiple choice nodes)"
                />
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-300">Product Data Sheet</label>
                <div className="border-2 border-dashed border-gray-600 rounded-lg p-4 bg-gray-800/30">
                  <input
                    type="file"
                    id="file-upload"
                    className="hidden"
                    accept=".pdf,.doc,.docx,.xls,.xlsx,.txt,.jpg,.jpeg,.png"
                    onChange={(e) => {
                      const file = e.target.files?.[0] || null;
                      setSelectedFile(file);
                    }}
                  />
                  <label
                    htmlFor="file-upload"
                    className="flex flex-col items-center justify-center cursor-pointer hover:bg-gray-700/30 p-2 rounded transition-colors"
                  >
                    <FileUp className="w-8 h-8 text-gray-400 mb-2" />
                    <p className="text-sm text-gray-300 text-center">
                      {selectedFile ? (
                        <span className="text-blue-400 font-medium">{selectedFile.name}</span>
                      ) : (
                        <>
                          Click to upload or drag and drop<br />
                          <span className="text-gray-500 text-xs">PDF, DOC, XLS, images up to 10MB</span>
                        </>
                      )}
                    </p>
                  </label>
                  {selectedFile && (
                    <div className="mt-2 flex items-center justify-between p-2 bg-gray-700/50 rounded">
                      <span className="text-sm text-gray-300 truncate">{selectedFile.name}</span>
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        onClick={() => setSelectedFile(null)}
                        className="text-gray-400 hover:text-red-400"
                      >
                        <X className="w-4 h-4" />
                      </Button>
                    </div>
                  )}
                </div>
                <p className="text-xs text-gray-500">
                  Upload technical specifications, product sheets, or reference documents for this classification step
                </p>
              </div>
              
              {/* Multi-Question Assessment Configuration */}
              {editNodeForm.question_type === 'multi_question_assessment' && (
                <div className="space-y-4 border border-purple-500/30 rounded-lg p-4 bg-purple-900/10">
                  <h4 className="text-purple-400 font-semibold flex items-center gap-2">
                    <span>🔄</span> Multi-Question Assessment Configuration
                  </h4>
                  
                  {/* Questions Section */}
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <label className="text-sm font-medium text-gray-300">Assessment Questions</label>
                      <Button
                        type="button"
                        size="sm"
                        onClick={() => {
                          setEditNodeForm({
                            ...editNodeForm,
                            multi_questions: [...editNodeForm.multi_questions, { key: `q${editNodeForm.multi_questions.length + 1}`, text: '' }]
                          });
                        }}
                        className="bg-purple-600 hover:bg-purple-700 text-white"
                      >
                        + Add Question
                      </Button>
                    </div>
                    
                    {editNodeForm.multi_questions.map((question, index) => (
                      <div key={index} className="border border-gray-600 rounded p-3 bg-gray-800/30">
                        <div className="grid grid-cols-3 gap-3">
                          <div>
                            <label className="text-xs text-gray-400">Question Key</label>
                            <Input
                              value={question.key}
                              onChange={(e) => {
                                const updated = [...editNodeForm.multi_questions];
                                updated[index] = { ...updated[index], key: e.target.value };
                                setEditNodeForm({ ...editNodeForm, multi_questions: updated });
                              }}
                              className="bg-gray-800 border-gray-600 text-white text-sm"
                              placeholder="q1, q2, etc."
                            />
                          </div>
                          <div className="col-span-2">
                            <div className="flex items-center gap-2">
                              <div className="flex-1">
                                <label className="text-xs text-gray-400">Question Text</label>
                                <Input
                                  value={question.text}
                                  onChange={(e) => {
                                    const updated = [...editNodeForm.multi_questions];
                                    updated[index] = { ...updated[index], text: e.target.value };
                                    setEditNodeForm({ ...editNodeForm, multi_questions: updated });
                                  }}
                                  className="bg-gray-800 border-gray-600 text-white text-sm"
                                  placeholder="Enter your YES/NO question"
                                />
                              </div>
                              <Button
                                type="button"
                                size="sm"
                                variant="outline"
                                onClick={() => {
                                  const updated = editNodeForm.multi_questions.filter((_, i) => i !== index);
                                  setEditNodeForm({ ...editNodeForm, multi_questions: updated });
                                }}
                                className="text-red-400 border-red-500 hover:bg-red-500/20 mt-5"
                              >
                                Remove
                              </Button>
                            </div>
                          </div>
                        </div>
                        {/* Regulatory Notes Field */}
                        <div className="mt-3">
                          <label className="text-xs text-gray-400">Regulatory Notes (comma-separated note IDs)</label>
                          <Input
                            value={question.regulatory_notes ? question.regulatory_notes.join(', ') : ''}
                            onChange={(e) => {
                              const updated = [...editNodeForm.multi_questions];
                              const noteIds = e.target.value.split(',').map(id => id.trim()).filter(id => id.length > 0);
                              updated[index] = { ...updated[index], regulatory_notes: noteIds.length > 0 ? noteIds : undefined };
                              setEditNodeForm({ ...editNodeForm, multi_questions: updated });
                            }}
                            className="bg-gray-800 border-gray-600 text-white text-sm"
                            placeholder="note-en-0004, note-en-0005"
                          />
                        </div>
                      </div>
                    ))}
                    
                    {editNodeForm.multi_questions.length === 0 && (
                      <div className="text-center py-4 text-gray-500 text-sm">
                        No questions added yet. Click "Add Question" to start.
                      </div>
                    )}
                  </div>
                  
                  {/* Outcome Rules Section */}
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <label className="text-sm font-medium text-gray-300">Outcome Rules</label>
                      <Button
                        type="button"
                        size="sm"
                        onClick={() => {
                          setEditNodeForm({
                            ...editNodeForm,
                            outcome_rules: [...editNodeForm.outcome_rules, {
                              priority: editNodeForm.outcome_rules.length + 1,
                              logic: { yes_count: { min: 0 } },
                              target: '',
                              target_type: 'classification_tree',
                              description: ''
                            }]
                          });
                        }}
                        className="bg-green-600 hover:bg-green-700 text-white"
                      >
                        + Add Rule
                      </Button>
                    </div>
                    
                    {editNodeForm.outcome_rules.map((rule, index) => (
                      <div key={index} className="border border-gray-600 rounded p-3 bg-gray-800/30">
                        <div className="space-y-3">
                          <div className="grid grid-cols-4 gap-3">
                            <div>
                              <label className="text-xs text-gray-400">Priority</label>
                              <Input
                                type="number"
                                value={rule.priority}
                                onChange={(e) => {
                                  const updated = [...editNodeForm.outcome_rules];
                                  updated[index] = { ...updated[index], priority: parseInt(e.target.value) || 1 };
                                  setEditNodeForm({ ...editNodeForm, outcome_rules: updated });
                                }}
                                className="bg-gray-800 border-gray-600 text-white text-sm"
                                min="1"
                              />
                            </div>
                            <div>
                              <label className="text-xs text-gray-400">Target Type</label>
                              <Select
                                value={rule.target_type}
                                onValueChange={(value) => {
                                  const updated = [...editNodeForm.outcome_rules];
                                  updated[index] = { ...updated[index], target_type: value };
                                  setEditNodeForm({ ...editNodeForm, outcome_rules: updated });
                                }}
                              >
                                <SelectTrigger className="bg-gray-800 border-gray-600 text-white text-sm">
                                  <SelectValue />
                                </SelectTrigger>
                                <SelectContent className="bg-gray-800 border-gray-600">
                                  <SelectItem value="classification_tree">Classification Tree</SelectItem>
                                  <SelectItem value="outcome">Final Outcome</SelectItem>
                                  <SelectItem value="node">Next Node</SelectItem>
                                </SelectContent>
                              </Select>
                            </div>
                            <div>
                              <label className="text-xs text-gray-400">Target</label>
                              <Input
                                value={rule.target}
                                onChange={(e) => {
                                  const updated = [...editNodeForm.outcome_rules];
                                  updated[index] = { ...updated[index], target: e.target.value };
                                  setEditNodeForm({ ...editNodeForm, outcome_rules: updated });
                                }}
                                className="bg-gray-800 border-gray-600 text-white text-sm"
                                placeholder="Tree ID or Node Key"
                              />
                            </div>
                            <div className="flex items-end">
                              <Button
                                type="button"
                                size="sm"
                                variant="outline"
                                onClick={() => {
                                  const updated = editNodeForm.outcome_rules.filter((_, i) => i !== index);
                                  setEditNodeForm({ ...editNodeForm, outcome_rules: updated });
                                }}
                                className="text-red-400 border-red-500 hover:bg-red-500/20 w-full"
                              >
                                Remove
                              </Button>
                            </div>
                          </div>
                          
                          <div>
                            <label className="text-xs text-gray-400">Description (Optional)</label>
                            <Input
                              value={rule.description || ''}
                              onChange={(e) => {
                                const updated = [...editNodeForm.outcome_rules];
                                updated[index] = { ...updated[index], description: e.target.value };
                                setEditNodeForm({ ...editNodeForm, outcome_rules: updated });
                              }}
                              className="bg-gray-800 border-gray-600 text-white text-sm"
                              placeholder="Describe when this rule applies"
                            />
                          </div>
                          
                          <div>
                            <label className="text-xs text-gray-400">Logic Configuration</label>
                            <div className="grid grid-cols-2 gap-3 mt-1">
                              <div>
                                <label className="text-xs text-gray-500">Min YES answers</label>
                                <Input
                                  type="number"
                                  value={rule.logic?.yes_count?.min || 0}
                                  onChange={(e) => {
                                    const updated = [...editNodeForm.outcome_rules];
                                    const logic = updated[index].logic || {};
                                    logic.yes_count = { ...logic.yes_count, min: parseInt(e.target.value) || 0 };
                                    updated[index] = { ...updated[index], logic };
                                    setEditNodeForm({ ...editNodeForm, outcome_rules: updated });
                                  }}
                                  className="bg-gray-800 border-gray-600 text-white text-sm"
                                  min="0"
                                />
                              </div>
                              <div>
                                <label className="text-xs text-gray-500">Max YES answers (optional)</label>
                                <Input
                                  type="number"
                                  value={rule.logic?.yes_count?.max || ''}
                                  onChange={(e) => {
                                    const updated = [...editNodeForm.outcome_rules];
                                    const logic = updated[index].logic || {};
                                    const maxVal = e.target.value ? parseInt(e.target.value) : undefined;
                                    logic.yes_count = { ...logic.yes_count, max: maxVal };
                                    updated[index] = { ...updated[index], logic };
                                    setEditNodeForm({ ...editNodeForm, outcome_rules: updated });
                                  }}
                                  className="bg-gray-800 border-gray-600 text-white text-sm"
                                  min="0"
                                  placeholder="Leave empty for no max"
                                />
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                    
                    {editNodeForm.outcome_rules.length === 0 && (
                      <div className="text-center py-4 text-gray-500 text-sm">
                        No outcome rules added yet. Click "Add Rule" to start.
                      </div>
                    )}
                  </div>
                  
                  {/* Usage Instructions */}
                  <div className="bg-blue-900/20 border border-blue-700/30 rounded-lg p-3">
                    <div className="text-blue-300 text-sm">
                      <p className="font-medium mb-2">💡 How Multi-Question Assessment Works:</p>
                      <ul className="text-xs space-y-1 text-blue-200">
                        <li>• Users answer all questions with YES or NO</li>
                        <li>• System counts YES/NO responses and applies the first matching rule (by priority)</li>
                        <li>• Rules can specify minimum/maximum YES answers, NO answers, or percentages</li>
                        <li>• Example: "If 2+ YES answers, route to Tree ABC; If 0-1 YES, route to Tree XYZ"</li>
                      </ul>
                    </div>
                  </div>
                </div>
              )}
            </div>
            
            <DialogFooter>
              <Button
                variant="outline"
                onClick={() => {
                  setShowEditNodeDialog(false);
                  setSelectedFile(null); // Reset file selection when canceling
                }}
                className="text-gray-300 border-gray-600 hover:bg-gray-700"
              >
                Cancel
              </Button>
              <Button
                onClick={handleEditNodeSubmit}
                disabled={updatingNode || !editNodeForm.node_key || !editNodeForm.title}
                className="bg-blue-600 hover:bg-blue-700 text-white"
              >
                {updatingNode ? 'Saving...' : 'Save Changes'}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
      
      {showManageOptionsDialog && managingOptionsForNode && (
        <Dialog open={showManageOptionsDialog} onOpenChange={setShowManageOptionsDialog}>
          <DialogContent className="bg-gray-900 border-gray-700 text-white max-w-4xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="text-purple-400">Manage Introduction Node Options</DialogTitle>
              <DialogDescription className="text-gray-400">
                Configure options for node: {managingOptionsForNode?.node_key} - {managingOptionsForNode?.title}
              </DialogDescription>
            </DialogHeader>
            
            <div className="space-y-6">
              {/* Create New Option */}
              <div className="border border-gray-700 rounded-lg p-4 bg-gray-800/30">
                <h4 className="text-white font-semibold mb-3">Add New Option</h4>
                
                {/* Instructions */}
                <div className="mb-4 p-3 bg-blue-900/20 border border-blue-700/30 rounded-lg">
                  <p className="text-blue-300 text-sm mb-2 font-medium">💡 Instructions:</p>
                  <ul className="text-blue-200 text-xs space-y-1">
                    <li><strong>Option Text:</strong> The display text users will see (e.g., "Yes", "No", "Not Applicable")</li>
                    <li><strong>Option Value:</strong> The internal value for processing (e.g., "yes", "no", "na")</li>
                    <li><strong>Routing Rule:</strong> Where to go next - use a Classification Tree ID to direct users to that tree</li>
                  </ul>
                </div>
                
                <div className="grid grid-cols-2 gap-4 mb-4">
                  <div>
                    <Label className="text-gray-300">Option Text *</Label>
                    <Input
                      value={newOptionData.option_text}
                      onChange={(e) => setNewOptionData({ ...newOptionData, option_text: e.target.value })}
                      placeholder="e.g., Yes, No, Not Applicable"
                      className="bg-gray-800 border-gray-600 text-white"
                    />
                  </div>
                  <div>
                    <Label className="text-gray-300">Option Value *</Label>
                    <Input
                      value={newOptionData.option_value}
                      onChange={(e) => setNewOptionData({ ...newOptionData, option_value: e.target.value })}
                      placeholder="e.g., yes, no, na"
                      className="bg-gray-800 border-gray-600 text-white"
                    />
                  </div>
                  <div>
                    <Label className="text-gray-300">Routing Rule</Label>
                    <Input
                      value={newOptionData.routing_rule}
                      onChange={(e) => setNewOptionData({ ...newOptionData, routing_rule: e.target.value })}
                      placeholder="e.g., NEXT_NODE_KEY or CLASSIFICATION_TREE_ID"
                      className="bg-gray-800 border-gray-600 text-white"
                    />
                  </div>
                  <div>
                    <Label className="text-gray-300">Display Order</Label>
                    <Input
                      type="number"
                      value={newOptionData.display_order}
                      onChange={(e) => setNewOptionData({ ...newOptionData, display_order: parseInt(e.target.value) || 0 })}
                      className="bg-gray-800 border-gray-600 text-white"
                    />
                  </div>
                </div>
                <div>
                  <Label className="text-gray-300">Notes</Label>
                  <Textarea
                    value={newOptionData.notes}
                    onChange={(e) => setNewOptionData({ ...newOptionData, notes: e.target.value })}
                    placeholder="Optional notes about this option"
                    className="bg-gray-800 border-gray-600 text-white"
                    rows={3}
                  />
                </div>
                <Button
                  onClick={handleCreateOption}
                  className="bg-purple-600 hover:bg-purple-700 text-white mt-4"
                  disabled={!newOptionData.option_text.trim() || !newOptionData.option_value.trim()}
                >
                  Add Option
                </Button>
              </div>

              {/* Existing Options */}
              <div className="border border-gray-700 rounded-lg p-4 bg-gray-800/30">
                <h4 className="text-white font-semibold mb-3">Existing Options</h4>
                {loadingOptions ? (
                  <p className="text-gray-400">Loading options...</p>
                ) : currentNodeOptions.length === 0 ? (
                  <p className="text-gray-400">No options configured for this node.</p>
                ) : (
                  <div className="space-y-2">
                    {currentNodeOptions.map((option) => (
                      <div key={option.id} className="border border-gray-600 rounded p-3 bg-gray-800/50">
                        <div className="flex justify-between items-start">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-1">
                              <span className="font-medium text-white">{option.option_text}</span>
                              <Badge variant="outline" className="text-xs">{option.option_value}</Badge>
                            </div>
                            {option.routing_rule && (
                              <p className="text-sm text-blue-400">Routes to: {option.routing_rule}</p>
                            )}
                            {option.note && (
                              <p className="text-sm text-gray-400 mt-1">{option.note}</p>
                            )}
                          </div>
                          <div className="flex gap-1">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleEditIntroOption(option)}
                              className="border-gray-600 text-gray-300 hover:bg-gray-700"
                            >
                              <Edit3 className="w-3 h-3" />
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={async () => {
                                if (window.confirm(`Are you sure you want to delete option "${option.option_text}"?`)) {
                                  try {
                                    await brain.delete_introduction_node_option({ 
                                      nodeId: managingOptionsForNode.id, 
                                      optionId: option.id 
                                    });
                                    toast.success('Option deleted successfully');
                                    loadNodeOptions(managingOptionsForNode.id);
                                  } catch (error) {
                                    console.error('Error deleting option:', error);
                                    toast.error('Failed to delete option');
                                  }
                                }
                              }}
                              className="border-gray-600 text-red-400 hover:bg-red-900/20 hover:border-red-500"
                            >
                              <Trash2 className="w-3 h-3" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
            
            <DialogFooter>
              <Button
                variant="outline"
                onClick={() => setShowManageOptionsDialog(false)}
                className="text-gray-300 border-gray-600 hover:bg-gray-700"
              >
                Close
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
      
      {showEditTreeDialog && editingTree && (
        <Dialog open={showEditTreeDialog} onOpenChange={setShowEditTreeDialog}>
          <DialogContent className="bg-gray-900 border-gray-700 text-white max-w-4xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="text-blue-400">Edit Introduction Tree</DialogTitle>
              <DialogDescription className="text-gray-400">
                Update the details of the selected introduction tree
              </DialogDescription>
            </DialogHeader>
            
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-300">Name *</label>
                  <Input
                    value={editTreeData.name}
                    onChange={(e) => setEditTreeData({ ...editTreeData, name: e.target.value })}
                    className="bg-gray-800 border-gray-600 text-white"
                    placeholder="Tree name"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-300">Description</label>
                  <Textarea
                    value={editTreeData.description}
                    onChange={(e) => setEditTreeData({ ...editTreeData, description: e.target.value })}
                    className="bg-gray-800 border-gray-600 text-white"
                    placeholder="Tree description"
                    rows={2}
                  />
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-300">Jurisdiction</label>
                  <Input
                    value={editTreeData.jurisdiction}
                    onChange={(e) => setEditTreeData({ ...editTreeData, jurisdiction: e.target.value })}
                    className="bg-gray-800 border-gray-600 text-white"
                    placeholder="Tree jurisdiction"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-300">Category</label>
                  <Input
                    value={editTreeData.category}
                    onChange={(e) => setEditTreeData({ ...editTreeData, category: e.target.value })}
                    className="bg-gray-800 border-gray-600 text-white"
                    placeholder="Tree category"
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-300">Status</label>
                <Select value={editTreeData.status} onValueChange={(value) => setEditTreeData({ ...editTreeData, status: value })}>
                  <SelectTrigger className="bg-gray-800 border-gray-600 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-gray-800 border-gray-600">
                    <SelectItem value="draft" className="text-white">Draft</SelectItem>
                    <SelectItem value="published" className="text-white">Published</SelectItem>
                    <SelectItem value="archived" className="text-white">Archived</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <DialogFooter>
              <Button
                variant="outline"
                onClick={() => setShowEditTreeDialog(false)}
                className="text-gray-300 border-gray-600 hover:bg-gray-700"
              >
                Cancel
              </Button>
              <Button
                onClick={async () => {
                  if (!editingTree) return;
                  
                  try {
                    setUpdatingTree(true);
                    await brain.update_introduction_tree(
                      { treeId: editingTree.id },
                      {
                        name: editTreeData.name,
                        description: editTreeData.description,
                        jurisdiction: editTreeData.jurisdiction,
                        category: editTreeData.category,
                        status: editTreeData.status
                      }
                    );
                    toast.success('Tree updated successfully');
                    handleTreesReload(); // Reload trees list to show updated tree details
                    if (selectedTree) {
                      loadTreeData(selectedTree.id);
                    }
                    setShowEditTreeDialog(false);
                  } catch (error) {
                    console.error('Error updating tree:', error);
                    toast.error('Failed to update tree');
                  } finally {
                    setUpdatingTree(false);
                  }
                }}
                disabled={updatingTree || !editTreeData.name}
                className="bg-blue-600 hover:bg-blue-700 text-white"
              >
                {updatingTree ? 'Saving...' : 'Save Changes'}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
      
      {isEditIntroOptionDialogOpen && editingIntroOption && (
        <Dialog open={isEditIntroOptionDialogOpen} onOpenChange={setIsEditIntroOptionDialogOpen}>
          <DialogContent className="bg-gray-900 border-gray-700 text-white max-w-4xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="text-purple-400">Edit Introduction Tree Option</DialogTitle>
              <DialogDescription className="text-gray-400">
                Update the details of the selected introduction tree option
              </DialogDescription>
            </DialogHeader>
            
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-300">Option Text *</label>
                  <Input
                    value={editIntroOptionForm.option_text}
                    onChange={(e) => setEditIntroOptionForm({ ...editIntroOptionForm, option_text: e.target.value })}
                    className="bg-gray-800 border-gray-600 text-white"
                    placeholder="Option text"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-300">Option Value *</label>
                  <Input
                    value={editIntroOptionForm.option_value}
                    onChange={(e) => setEditIntroOptionForm({ ...editIntroOptionForm, option_value: e.target.value })}
                    className="bg-gray-800 border-gray-600 text-white"
                    placeholder="Option value"
                    required
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-300">Routing Rule</label>
                <Input
                  value={editIntroOptionForm.routing_rule}
                  onChange={(e) => setEditIntroOptionForm({ ...editIntroOptionForm, routing_rule: e.target.value })}
                  className="bg-gray-800 border-gray-600 text-white"
                  placeholder="Routing rule"
                />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-300">Display Order</label>
                  <Input
                    type="number"
                    value={editIntroOptionForm.display_order}
                    onChange={(e) => setEditIntroOptionForm({ ...editIntroOptionForm, display_order: parseInt(e.target.value) || 0 })}
                    className="bg-gray-800 border-gray-600 text-white"
                    placeholder="Display order"
                    min="0"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-300">Regulatory Notes</label>
                  <Textarea
                    value={editIntroOptionForm.regulatory_notes.join('\n')}
                    onChange={(e) => setEditIntroOptionForm({ 
                      ...editIntroOptionForm, 
                      regulatory_notes: e.target.value.split('\n').filter(note => note.trim() !== '') 
                    })}
                    className="bg-gray-800 border-gray-600 text-white"
                    placeholder="Enter regulatory notes (one per line)"
                    rows={3}
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-300">Note</label>
                <Textarea
                  value={editIntroOptionForm.note}
                  onChange={(e) => setEditIntroOptionForm({ ...editIntroOptionForm, note: e.target.value })}
                  className="bg-gray-800 border-gray-600 text-white"
                  placeholder="Option note"
                  rows={3}
                />
              </div>
            </div>
            
            <DialogFooter>
              <Button
                variant="outline"
                onClick={() => setIsEditIntroOptionDialogOpen(false)}
                className="text-gray-300 border-gray-600 hover:bg-gray-700"
              >
                Cancel
              </Button>
              <Button
                onClick={handleUpdateIntroOption}
                disabled={!editIntroOptionForm.option_text.trim() || !editIntroOptionForm.option_value.trim()}
                className="bg-purple-600 hover:bg-purple-700 text-white"
              >
                Save Changes
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
};

export default IntroductionTreesTab;
