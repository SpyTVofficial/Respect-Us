import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Plus,
  Edit,
  Trash2,
  Search,
  Tags,
  AlertCircle,
  CheckCircle,
  Settings,
  Eye,
  Copy,
  MoreHorizontal,
  Palette,
  Hash,
  Filter
} from 'lucide-react';
import { toast } from 'sonner';
import brain from 'brain';
import type {
  BadgeResponse,
  BadgeListResponse,
  CreateBadgeRequest,
  UpdateBadgeRequest
} from '../brain/data-contracts';

// Create a type alias to avoid naming conflict
type BadgeData = BadgeResponse;

export interface BadgeManagementProps {
  onRefresh?: () => void;
}

export default function BadgeManagement({ onRefresh }: BadgeManagementProps) {
  const [badges, setBadges] = useState<BadgeData[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  
  // Dialog states
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [showPreviewDialog, setShowPreviewDialog] = useState(false);
  const [selectedBadge, setSelectedBadge] = useState<BadgeData | null>(null);
  
  // Form data
  const [newBadge, setNewBadge] = useState({
    name: '',
    description: '',
    color: '#3b82f6',
    category: 'custom',
    is_active: true,
    sort_order: 0
  });
  
  const [editingBadge, setEditingBadge] = useState<BadgeData | null>(null);
  
  // Preset colors for quick selection
  const presetColors = [
    { name: 'Blue', value: '#3b82f6' },
    { name: 'Green', value: '#10b981' },
    { name: 'Yellow', value: '#f59e0b' },
    { name: 'Red', value: '#ef4444' },
    { name: 'Purple', value: '#8b5cf6' },
    { name: 'Indigo', value: '#6366f1' },
    { name: 'Pink', value: '#ec4899' },
    { name: 'Gray', value: '#6b7280' },
    { name: 'Orange', value: '#f97316' },
    { name: 'Teal', value: '#14b8a6' }
  ];

  useEffect(() => {
    loadBadges();
  }, []);

  const loadBadges = async () => {
    try {
      setLoading(true);
      const response = await brain.list_badges();
      if (response.ok) {
        const data: BadgeListResponse = await response.json();
        setBadges(data.badges || []);
      }
    } catch (error) {
      console.error('Error loading badges:', error);
      toast.error('Failed to load badge types');
    } finally {
      setLoading(false);
    }
  };

  const handleCreateBadge = async () => {
    if (!newBadge.name.trim()) {
      toast.error('Badge name is required');
      return;
    }

    try {
      const response = await brain.create_badge({
        name: newBadge.name,
        description: newBadge.description,
        color: newBadge.color,
        category: newBadge.category,
        is_active: true,
        sort_order: newBadge.sort_order
      });

      if (response.ok) {
        toast.success('Badge created successfully');
        await loadBadges();
        setShowCreateDialog(false);
        setNewBadge({
          name: '',
          description: '',
          color: '#3b82f6',
          category: 'custom',
          is_active: true,
          sort_order: 0
        });
        onRefresh?.();
      } else {
        const error = await response.json();
        toast.error((error as any)?.detail || (error as any)?.message || 'Failed to create badge');
      }
    } catch (error) {
      console.error('Error creating badge:', error);
      toast.error('Failed to create badge');
    }
  };

  const handleUpdateBadge = async () => {
    if (!editingBadge?.name?.trim()) {
      toast.error('Badge name is required');
      return;
    }

    try {
      const response = await brain.update_badge(
        { badgeId: editingBadge.id },
        {
          name: editingBadge.name,
          description: editingBadge.description,
          color: editingBadge.color,
          category: editingBadge.category,
          is_active: editingBadge.is_active,
          sort_order: editingBadge.sort_order
        }
      );

      if (response.ok) {
        toast.success('Badge updated successfully');
        await loadBadges();
        setShowEditDialog(false);
        setEditingBadge(null);
        onRefresh?.();
      } else {
        const error = await response.json();
        toast.error((error as any)?.detail || (error as any)?.message || 'Failed to update badge');
      }
    } catch (error) {
      console.error('Error updating badge:', error);
      toast.error('Failed to update badge');
    }
  };

  const handleDeleteBadge = async (badgeId: number) => {
    try {
      const response = await brain.delete_badge({ badgeId });
      
      if (response.ok) {
        toast.success('Badge type deleted successfully');
        setShowDeleteDialog(false);
        setSelectedBadge(null);
        loadBadges();
      } else {
        const error = await response.json();
        toast.error((error as any)?.detail || (error as any)?.message || 'Failed to delete badge type');
      }
    } catch (error) {
      console.error('Error deleting badge:', error);
      toast.error('Failed to delete badge type');
    }
  };

  const handleDuplicateBadge = (badge: BadgeData) => {
    setNewBadge({
      name: `${badge.name}_copy`,
      description: badge.description || '',
      color: badge.color,
      category: badge.category,
      is_active: true,
      sort_order: badge.sort_order
    });
    setShowCreateDialog(true);
  };

  const handleEditBadge = (badge: BadgeData) => {
    setEditingBadge({
      ...badge,
      name: badge.name,
      description: badge.description,
      color: badge.color,
      category: badge.category,
      is_active: badge.is_active,
      sort_order: badge.sort_order,
      id: badge.id,
      created_by: badge.created_by,
      created_at: badge.created_at,
      updated_at: badge.updated_at
    });
    setShowEditDialog(true);
  };

  const openEditDialog = (badge: BadgeData) => {
    setEditingBadge(badge);
    setShowEditDialog(true);
  };

  const openDeleteDialog = (badge: BadgeData) => {
    setSelectedBadge(badge);
    setShowDeleteDialog(true);
  };

  const openPreviewDialog = (badge: BadgeData) => {
    setSelectedBadge(badge);
    setShowPreviewDialog(true);
  };

  // Filter badges based on search and filters
  const filteredBadges = badges.filter(badge => {
    const matchesSearch = badge.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (badge.description && badge.description.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchesCategory = categoryFilter === 'all' || badge.category === categoryFilter;
    const matchesStatus = statusFilter === 'all' || 
      (statusFilter === 'active' && badge.is_active) ||
      (statusFilter === 'inactive' && !badge.is_active);
    
    return matchesSearch && matchesCategory && matchesStatus;
  });

  // Group badges by category
  const groupedBadges = filteredBadges.reduce((acc, badge) => {
    if (!acc[badge.category]) {
      acc[badge.category] = [];
    }
    acc[badge.category].push(badge);
    return acc;
  }, {} as Record<string, BadgeData[]>);

  // Simple contrast color calculation
  const getContrastColor = (hexColor: string) => {
    const r = parseInt(hexColor.slice(1, 3), 16);
    const g = parseInt(hexColor.slice(3, 5), 16);
    const b = parseInt(hexColor.slice(5, 7), 16);
    const brightness = (r * 299 + g * 587 + b * 114) / 1000;
    return brightness > 128 ? '#000000' : '#ffffff';
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-400">Loading badge types...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold flex items-center gap-2">
            <Tags className="h-6 w-6" />
            Badge Management
          </h2>
          <p className="text-gray-400 mt-1">
            Configure badge types for document classification and organization
          </p>
        </div>
        <Button onClick={() => setShowCreateDialog(true)} className="bg-blue-600 hover:bg-blue-700">
          <Plus className="h-4 w-4 mr-2" />
          Create Badge Type
        </Button>
      </div>

      {/* Filters and Search */}
      <Card className="bg-gray-800 border-gray-700">
        <CardContent className="p-4">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Search badge types..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 bg-gray-700 border-gray-600"
                />
              </div>
            </div>
            <Select value={categoryFilter} onValueChange={setCategoryFilter}>
              <SelectTrigger className="w-48 bg-gray-700 border-gray-600">
                <SelectValue placeholder="Filter by category" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Categories</SelectItem>
                <SelectItem value="priority">Priority</SelectItem>
                <SelectItem value="status">Status</SelectItem>
                <SelectItem value="type">Type</SelectItem>
                <SelectItem value="subject">Subject</SelectItem>
                <SelectItem value="custom">Custom</SelectItem>
              </SelectContent>
            </Select>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-48 bg-gray-700 border-gray-600">
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="active">Active</SelectItem>
                <SelectItem value="inactive">Inactive</SelectItem>
                <SelectItem value="system">System</SelectItem>
                <SelectItem value="custom">Custom</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Badge Categories */}
      <div className="space-y-6">
        {Object.entries(groupedBadges).map(([category, categoryBadges]) => (
          <Card key={category} className="bg-gray-800 border-gray-700">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 capitalize">
                <Hash className="h-5 w-5" />
                {category} Badges
                <Badge variant="outline" className="ml-2">
                  {categoryBadges.length}
                </Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {categoryBadges.map((badge) => (
                  <div
                    key={badge.id}
                    className="p-4 bg-gray-700 rounded-lg border border-gray-600 hover:border-gray-500 transition-all"
                  >
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <Badge
                            style={{
                              backgroundColor: badge.color,
                              color: '#ffffff'
                            }}
                          >
                            {badge.name}
                          </Badge>
                          {!badge.is_active && (
                            <Badge variant="outline" className="text-xs text-gray-400">
                              Inactive
                            </Badge>
                          )}
                        </div>
                        <div className="flex items-center space-x-2">
                          <div 
                            className="w-4 h-4 rounded" 
                            style={{ backgroundColor: badge.color }}
                          />
                          <span className="font-medium text-gray-900 dark:text-gray-100">
                            {badge.name}
                          </span>
                        </div>
                        {badge.description && (
                          <p className="text-xs text-gray-400 line-clamp-2">
                            {badge.description}
                          </p>
                        )}
                      </div>
                      <div className="flex gap-1">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => openPreviewDialog(badge)}
                          className="h-8 w-8 p-0 bg-gray-600 hover:bg-gray-500"
                        >
                          <Eye className="h-3 w-3" />
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleEditBadge(badge)}
                          className="h-8 w-8 p-0 bg-gray-600 hover:bg-gray-500"
                        >
                          <Edit className="h-3 w-3" />
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleDuplicateBadge(badge)}
                          className="h-8 w-8 p-0 bg-gray-600 hover:bg-gray-500"
                        >
                          <Copy className="h-3 w-3" />
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => openDeleteDialog(badge)}
                          className="h-8 w-8 p-0 bg-red-700 hover:bg-red-600 text-red-300"
                        >
                          <Trash2 className="h-3 w-3" />
                        </Button>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 text-xs text-gray-400">
                      <div 
                        className="w-3 h-3 rounded-full border border-gray-500"
                        style={{ backgroundColor: badge.color }}
                      ></div>
                      <span>{badge.color}</span>
                      <span>•</span>
                      <span>Order: {badge.sort_order}</span>
                    </div>
                    {badge.is_active ? (
                      <Badge className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200">
                        Active
                      </Badge>
                    ) : (
                      <Badge className="bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200">
                        Inactive
                      </Badge>
                    )}
                    {!badge.is_active && (
                      <div className="text-xs text-red-600 dark:text-red-400 mt-1">
                        Inactive
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredBadges.length === 0 && (
        <div className="text-center py-12">
          <Tags className="h-12 w-12 mx-auto mb-4 text-gray-400 opacity-50" />
          <p className="text-gray-400 mb-2">No badge types found</p>
          <p className="text-sm text-gray-500">Create your first badge type to get started</p>
        </div>
      )}

      {/* Create/Edit Dialog */}
      <Dialog open={showCreateDialog || showEditDialog} onOpenChange={(open) => {
        if (!open) {
          setShowCreateDialog(false);
          setShowEditDialog(false);
          setSelectedBadge(null);
          setNewBadge({
            name: '',
            description: '',
            color: '#3b82f6',
            category: 'custom',
            is_active: true,
            sort_order: 0
          });
        }
      }}>
        <DialogContent className="bg-slate-900 border-slate-700 text-white max-w-md">
          <DialogHeader>
            <DialogTitle className="text-white">
              {editingBadge ? 'Edit Badge' : 'Create New Badge'}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="name" className="text-slate-300">Name</Label>
              <Input
                id="name"
                value={editingBadge ? editingBadge.name : newBadge.name}
                onChange={(e) => {
                  if (editingBadge) {
                    setEditingBadge({ ...editingBadge, name: e.target.value });
                  } else {
                    setNewBadge({ ...newBadge, name: e.target.value });
                  }
                }}
                className="bg-slate-800 border-slate-600 text-white"
                placeholder="Badge name"
              />
            </div>
            <div>
              <Label htmlFor="description" className="text-slate-300">Description</Label>
              <Input
                id="description"
                value={editingBadge ? editingBadge.description || '' : newBadge.description}
                onChange={(e) => {
                  if (editingBadge) {
                    setEditingBadge({ ...editingBadge, description: e.target.value });
                  } else {
                    setNewBadge({ ...newBadge, description: e.target.value });
                  }
                }}
                className="bg-slate-800 border-slate-600 text-white"
                placeholder="Badge description"
              />
            </div>
            <div>
              <Label htmlFor="category" className="text-slate-300">Category</Label>
              <Select 
                value={editingBadge ? editingBadge.category : newBadge.category} 
                onValueChange={(value) => {
                  if (editingBadge) {
                    setEditingBadge({ ...editingBadge, category: value });
                  } else {
                    setNewBadge({ ...newBadge, category: value });
                  }
                }}
              >
                <SelectTrigger className="bg-slate-800 border-slate-600">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="priority">Priority</SelectItem>
                  <SelectItem value="status">Status</SelectItem>
                  <SelectItem value="type">Type</SelectItem>
                  <SelectItem value="subject">Subject</SelectItem>
                  <SelectItem value="custom">Custom</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="color" className="text-slate-300">Color</Label>
              <Input
                id="color"
                type="color"
                value={editingBadge ? editingBadge.color : newBadge.color}
                onChange={(e) => {
                  if (editingBadge) {
                    setEditingBadge({ ...editingBadge, color: e.target.value });
                  } else {
                    setNewBadge({ ...newBadge, color: e.target.value });
                  }
                }}
                className="bg-slate-800 border-slate-600"
              />
            </div>
            <div>
              <Label htmlFor="sort_order" className="text-slate-300">Sort Order</Label>
              <Input
                id="sort_order"
                type="number"
                value={editingBadge ? editingBadge.sort_order : newBadge.sort_order}
                onChange={(e) => {
                  const value = parseInt(e.target.value) || 0;
                  if (editingBadge) {
                    setEditingBadge({ ...editingBadge, sort_order: value });
                  } else {
                    setNewBadge({ ...newBadge, sort_order: value });
                  }
                }}
                className="bg-slate-800 border-slate-600"
              />
            </div>
            <div>
              <Label htmlFor="is_active" className="text-slate-300">Active</Label>
              <input
                type="checkbox"
                checked={editingBadge ? editingBadge.is_active : newBadge.is_active}
                onChange={(e) => {
                  if (editingBadge) {
                    setEditingBadge({ ...editingBadge, is_active: e.target.checked });
                  } else {
                    setNewBadge({ ...newBadge, is_active: e.target.checked });
                  }
                }}
                className="rounded"
              />
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                setShowCreateDialog(false);
                setShowEditDialog(false);
                setSelectedBadge(null);
                setNewBadge({
                  name: '',
                  description: '',
                  color: '#3b82f6',
                  category: 'custom',
                  is_active: true,
                  sort_order: 0
                });
              }}
            >
              Cancel
            </Button>
            <Button
              onClick={showCreateDialog ? handleCreateBadge : handleUpdateBadge}
              className="bg-blue-600 hover:bg-blue-700"
            >
              {showCreateDialog ? 'Create Badge' : 'Update Badge'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <Dialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <DialogContent className="bg-gray-800 border-gray-700">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <AlertCircle className="h-5 w-5 text-red-500" />
              Delete Badge Type
            </DialogTitle>
            <DialogDescription>
              Are you sure you want to delete the badge type "{selectedBadge?.name}"?
              This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDeleteDialog(false)}>
              Cancel
            </Button>
            <Button
              onClick={() => selectedBadge && handleDeleteBadge(selectedBadge.id)}
              className="bg-red-600 hover:bg-red-700"
            >
              Delete Badge
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Preview Dialog */}
      <Dialog open={showPreviewDialog} onOpenChange={setShowPreviewDialog}>
        <DialogContent className="bg-gray-800 border-gray-700">
          <DialogHeader>
            <DialogTitle>Badge Type Details</DialogTitle>
          </DialogHeader>
          {selectedBadge && (
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <Badge
                  style={{
                    backgroundColor: selectedBadge.color,
                    color: '#ffffff'
                  }}
                >
                  {selectedBadge.name}
                </Badge>
                {!selectedBadge.is_active && (
                  <Badge variant="outline" className="text-gray-400">Inactive</Badge>
                )}
              </div>
              
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="text-gray-400">Name:</span>
                  <p className="font-medium">{selectedBadge.name}</p>
                </div>
                <div>
                  <span className="text-gray-400">Category:</span>
                  <p className="font-medium capitalize">{selectedBadge.category}</p>
                </div>
                <div>
                  <span className="text-gray-400">Color:</span>
                  <div className="flex items-center gap-2">
                    <div 
                      className="w-4 h-4 rounded border border-gray-500"
                      style={{ backgroundColor: selectedBadge.color }}
                    ></div>
                    <span className="font-mono">{selectedBadge.color}</span>
                  </div>
                </div>
                <div>
                  <span className="text-gray-400">Sort Order:</span>
                  <p className="font-medium">{selectedBadge.sort_order}</p>
                </div>
              </div>
              
              {selectedBadge.description && (
                <div>
                  <span className="text-gray-400">Description:</span>
                  <p className="mt-1">{selectedBadge.description}</p>
                </div>
              )}
              
              {selectedBadge.created_at && (
                <div className="pt-4 border-t border-gray-600 text-xs text-gray-400">
                  Created: {new Date(selectedBadge.created_at).toLocaleString()}
                  {selectedBadge.updated_at && (
                    <span className="ml-4">
                      Updated: {new Date(selectedBadge.updated_at).toLocaleString()}
                    </span>
                  )}
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
