
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { CreditCard } from 'lucide-react';

interface CreditDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onConfirm: () => void;
}

export default function CreditDialog({ open, onOpenChange, onConfirm }: CreditDialogProps) {
  console.log('🎯 CreditDialog render - open:', open);
  console.log('🎯 CreditDialog props:', { open, onOpenChange: !!onOpenChange, onConfirm: !!onConfirm });
  
  if (open) {
    console.log('🎯 CreditDialog should be visible!');
  }
  
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-gray-800 border-gray-700 max-w-md">
        <DialogHeader>
          <DialogTitle className="text-white flex items-center gap-2">
            <CreditCard className="w-5 h-5" />
            Unlock Templates
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4">
          <div className="text-center">
            <p className="text-gray-400 mb-4">
              You need 4,000 credits to access the Risk Assessment templates.
            </p>
            
            <div className="bg-gray-900/40 rounded-lg p-4 mb-4">
              <div className="flex items-center justify-center gap-2 text-blue-400 mb-2">
                <CreditCard className="w-5 h-5" />
                <span className="font-semibold">4,000 Credits Required</span>
              </div>
              <p className="text-sm text-gray-500">
                Unlock all premium Risk Assessment templates
              </p>
            </div>
          </div>
          
          <div className="flex gap-3 pt-4">
            <Button
              variant="outline"
              onClick={() => onOpenChange(false)}
              className="flex-1 border-gray-600 text-gray-300"
            >
              Cancel
            </Button>
            
            <Button
              onClick={onConfirm}
              className="flex-1 bg-blue-600 hover:bg-blue-700"
            >
              Use 4,000 Credits
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
