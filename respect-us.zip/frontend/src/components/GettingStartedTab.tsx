
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  FileText, BarChart3, Target, Globe, Users, Search, Shield, CheckCircle, ArrowRight,
  Star, Award, Play, Receipt, CreditCard
} from 'lucide-react';
import { toast } from 'sonner';
import brain from 'brain';

interface ModuleAccessInfo {
  name: string;
  title: string;
  description?: string;
  user_has_access: boolean;
  status: string;
  price_eur?: number;
}

interface UserAccessStatus {
  modules: ModuleAccessInfo[];
  active_subscriptions: number;
}

interface OnboardingProgress {
  profile_completed: boolean;
  explored_knowledge_base: boolean;
  completed_tour: boolean;
  tried_risk_assessment: boolean;
  configured_workflow: boolean;
}

interface BusinessFormData {
  company_name: string;
  contact_person: string;
  email: string;
}

interface GettingStartedTabProps {
  userAccessStatus: UserAccessStatus | null;
  onboardingProgress: OnboardingProgress;
  setOnboardingProgress: React.Dispatch<React.SetStateAction<OnboardingProgress>>;
  showBusinessSignup: boolean;
  setShowBusinessSignup: React.Dispatch<React.SetStateAction<boolean>>;
  businessFormData: BusinessFormData;
  setBusinessFormData: React.Dispatch<React.SetStateAction<BusinessFormData>>;
  isSubmittingProfile: boolean;
  setActiveTab: (tab: string) => void;
  setShowGuidedTour: React.Dispatch<React.SetStateAction<boolean>>;
  handleModuleAccess: (module: ModuleAccessInfo) => void;
  user: any;
}

export default function GettingStartedTab({
  userAccessStatus,
  onboardingProgress,
  setOnboardingProgress,
  showBusinessSignup,
  setShowBusinessSignup,
  businessFormData,
  setBusinessFormData,
  isSubmittingProfile,
  setActiveTab,
  setShowGuidedTour,
  handleModuleAccess,
  user
}: GettingStartedTabProps) {
  const navigate = useNavigate();

  const calculateOnboardingCompletion = () => {
    const steps = Object.values(onboardingProgress);
    const completed = steps.filter(Boolean).length;
    return Math.round((completed / steps.length) * 100);
  };

  const updateOnboardingProgress = (updates: Partial<OnboardingProgress>) => {
    const newProgress = { ...onboardingProgress, ...updates };
    setOnboardingProgress(newProgress);
    localStorage.setItem(`onboarding_progress_${user.id}`, JSON.stringify(newProgress));
  };

  const startGuidedTour = () => {
    setShowGuidedTour(true);
  };

  const markKnowledgeBaseExplored = () => {
    updateOnboardingProgress({ explored_knowledge_base: true });
    navigate('/KnowledgeBase');
  };

  const handleBusinessSignup = async () => {
    if (!businessFormData.company_name.trim()) {
      toast.error('Company name is required');
      return;
    }

    try {
      const response = await brain.save_user_profile({
        company_name: businessFormData.company_name,
        contact_person: businessFormData.contact_person,
        email: businessFormData.email,
        phone: '',
        billing_address: '',
        city: '',
        postal_code: '',
        country: '',
        tax_id: '',
        vat_number: ''
      });

      if (response.ok) {
        toast.success('Profile completed successfully!');
        setShowBusinessSignup(false);
        updateOnboardingProgress({ profile_completed: true });
      } else {
        const errorData = await response.json();
        toast.error(errorData.detail || 'Failed to save profile');
      }
    } catch (error) {
      console.error('Error saving profile:', error);
      toast.error('Failed to save profile');
    }
  };

  return (
    <div className="space-y-6">
      {/* Welcome Banner */}
      <Card className="bg-gradient-to-br from-blue-900/30 to-purple-900/30 border-blue-500/30 backdrop-blur-sm">
        <CardContent className="p-8">
          <div className="text-center space-y-4">
            <div className="mx-auto w-16 h-16 bg-blue-600/20 rounded-full flex items-center justify-center">
              <Shield className="w-8 h-8 text-blue-400" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-white mb-2">
                Welcome to RespectUs
              </h1>
              <p className="text-blue-200 text-lg max-w-2xl mx-auto">
                Your comprehensive digital platform for export control compliance. 
                Get started with our 7 specialized modules designed for compliance professionals.
              </p>
            </div>
            <div className="flex items-center justify-center space-x-4">
              <Button 
                onClick={startGuidedTour}
                className="bg-blue-600 hover:bg-blue-700 text-white"
              >
                <Play className="w-4 h-4 mr-2" />
                Take Guided Tour
              </Button>
              <Button 
                onClick={() => setActiveTab('services')}
                variant="outline"
                className="border-blue-500/50 text-blue-300 hover:bg-blue-500/10"
              >
                Browse Modules
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Business Signup Card - Show if profile not completed */}
      {showBusinessSignup && (
        <Card className="bg-gradient-to-r from-green-900/30 to-blue-900/30 border-green-500/30 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="text-white flex items-center">
              <CreditCard className="w-5 h-5 mr-2 text-green-400" />
              Complete Your Business Profile
            </CardTitle>
            <CardDescription className="text-gray-300">
              Quick setup to personalize your RespectUs experience. Full business details will be collected when you purchase your first module.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="company_name" className="text-sm font-medium text-gray-200">
                  Company Name *
                </Label>
                <Input
                  id="company_name"
                  value={businessFormData.company_name}
                  onChange={(e) => setBusinessFormData(prev => ({ ...prev, company_name: e.target.value }))}
                  placeholder="Your Company Ltd."
                  className="bg-gray-800/50 border-gray-600 text-white placeholder-gray-400 focus:border-blue-500"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="contact_person" className="text-sm font-medium text-gray-200">
                  Contact Person
                </Label>
                <Input
                  id="contact_person"
                  value={businessFormData.contact_person}
                  onChange={(e) => setBusinessFormData(prev => ({ ...prev, contact_person: e.target.value }))}
                  placeholder="John Doe"
                  className="bg-gray-800/50 border-gray-600 text-white placeholder-gray-400 focus:border-blue-500"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="email" className="text-sm font-medium text-gray-200">
                  Email
                </Label>
                <Input
                  id="email"
                  type="email"
                  value={businessFormData.email}
                  onChange={(e) => setBusinessFormData(prev => ({ ...prev, email: e.target.value }))}
                  placeholder="contact@company.com"
                  className="bg-gray-800/50 border-gray-600 text-white placeholder-gray-400 focus:border-blue-500"
                />
              </div>
            </div>
            <div className="flex items-center justify-between pt-2">
              <p className="text-sm text-gray-400">
                Complete business details (address, billing) will be collected during your first module purchase.
              </p>
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  onClick={() => setShowBusinessSignup(false)}
                  className="border-gray-600 text-gray-300 hover:bg-gray-800"
                  disabled={isSubmittingProfile}
                >
                  Skip for now
                </Button>
                <Button
                  onClick={handleBusinessSignup}
                  disabled={isSubmittingProfile || !businessFormData.company_name.trim()}
                  className="bg-blue-600 hover:bg-blue-700 text-white"
                >
                  {isSubmittingProfile ? (
                    <div className="flex items-center gap-2">
                      <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                      Creating...
                    </div>
                  ) : (
                    'Complete Profile'
                  )}
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Success Metrics Teaser */}
      {calculateOnboardingCompletion() >= 75 && (
        <Card className="bg-gradient-to-r from-green-900/30 to-emerald-500/30 border-green-500/30 backdrop-blur-sm">
          <CardContent className="p-6">
            <div className="text-center space-y-3">
              <div className="mx-auto w-12 h-12 bg-green-600/20 rounded-full flex items-center justify-center">
                <Star className="w-6 h-6 text-green-400" />
              </div>
              <h3 className="text-xl font-bold text-white">
                Great Progress!
              </h3>
              <p className="text-green-300">
                You're almost ready to become a compliance expert. Complete your setup and start transforming your export control workflow.
              </p>
              <Button 
                onClick={() => updateOnboardingProgress({ configured_workflow: true })}
                className="bg-green-600 hover:bg-green-700 text-white"
              >
                Complete Setup
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Platform Overview */}
      <Card className="bg-gray-900/50 border-gray-700 backdrop-blur-sm">
        <CardHeader>
          <CardTitle className="text-white">Platform Overview</CardTitle>
          <CardDescription className="text-gray-400">
            Respectus provides 7 essential compliance modules to cover all aspects of export control
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {/* Knowledge Base - Free */}
            <div className="group cursor-pointer" onClick={() => navigate('/KnowledgeBase')}>
              <div className="p-4 rounded-lg bg-gradient-to-r from-blue-500 to-blue-700 bg-opacity-20 border border-blue-500/30 hover:bg-opacity-30 transition-all duration-200">
                <div className="flex items-center justify-between mb-2">
                  <FileText className="w-6 h-6 text-blue-400" />
                  <Badge className="bg-green-500/20 text-green-400 border-green-500/30 text-xs">FREE</Badge>
                </div>
                <h3 className="text-white font-semibold text-sm">Knowledge Base</h3>
                <p className="text-gray-400 text-xs mt-1">Regulatory documents & guidance</p>
              </div>
            </div>

            {/* Risk Assessment - Paid */}
            <div className="group cursor-pointer" onClick={() => handleModuleAccess({name: 'risk_assessment', title: 'Risk Assessment', user_has_access: userAccessStatus?.modules.find(m => m.name === 'risk_assessment')?.user_has_access || false, status: 'available', price_eur: 99})}>
              <div className="p-4 rounded-lg bg-gradient-to-r from-purple-500 to-purple-700 bg-opacity-20 border border-purple-500/30 hover:bg-opacity-30 transition-all duration-200">
                <div className="flex items-center justify-between mb-2">
                  <BarChart3 className="w-6 h-6 text-purple-400" />
                  <Badge className="bg-blue-500/20 text-blue-400 border-blue-500/30 text-xs">€99 + VAT if applicable</Badge>
                </div>
                <h3 className="text-white font-semibold text-sm">Risk Assessment</h3>
                <p className="text-gray-400 text-xs mt-1">Comprehensive compliance evaluation</p>
              </div>
            </div>

            {/* Other modules - Coming Soon */}
            <div className="p-4 rounded-lg bg-gradient-to-r from-green-500 to-green-700 bg-opacity-20 border border-green-500/30 opacity-60">
              <div className="flex items-center justify-between mb-2">
                <Target className="w-6 h-6 text-green-400" />
                <Badge className="bg-gray-500/20 text-gray-400 border-gray-500/30 text-xs">SOON</Badge>
              </div>
              <h3 className="text-white font-semibold text-sm">Product Classification</h3>
              <p className="text-gray-400 text-xs mt-1">Classify products for export control</p>
            </div>

            <div className="p-4 rounded-lg bg-gradient-to-r from-red-500 to-red-700 bg-opacity-20 border border-red-500/30 opacity-60">
              <div className="flex items-center justify-between mb-2">
                <Globe className="w-6 h-6 text-red-400" />
                <Badge className="bg-gray-500/20 text-gray-400 border-gray-500/30 text-xs">SOON</Badge>
              </div>
              <h3 className="text-white font-semibold text-sm">Sanctions & Embargoes</h3>
              <p className="text-gray-400 text-xs mt-1">Monitor sanctions compliance</p>
            </div>

            <div className="p-4 rounded-lg bg-gradient-to-r from-amber-500 to-amber-700 bg-opacity-20 border border-amber-500/30 opacity-60">
              <div className="flex items-center justify-between mb-2">
                <Users className="w-6 h-6 text-amber-400" />
                <Badge className="bg-gray-500/20 text-gray-400 border-gray-500/30 text-xs">SOON</Badge>
              </div>
              <h3 className="text-white font-semibold text-sm">Customer Screening</h3>
              <p className="text-gray-400 text-xs mt-1">Screen against watchlists</p>
            </div>

            <div className="p-4 rounded-lg bg-gradient-to-r from-cyan-500 to-cyan-700 bg-opacity-20 border border-cyan-500/30 opacity-60">
              <div className="flex items-center justify-between mb-2">
                <Search className="w-6 h-6 text-cyan-400" />
                <Badge className="bg-gray-500/20 text-gray-400 border-gray-500/30 text-xs">SOON</Badge>
              </div>
              <h3 className="text-white font-semibold text-sm">End-use Check</h3>
              <p className="text-gray-400 text-xs mt-1">Verify end-use compliance</p>
            </div>

            <div className="p-4 rounded-lg bg-gradient-to-r from-indigo-500 to-indigo-700 bg-opacity-20 border border-indigo-500/30 opacity-60">
              <div className="flex items-center justify-between mb-2">
                <Shield className="w-6 h-6 text-indigo-400" />
                <Badge className="bg-gray-500/20 text-gray-400 border-gray-500/30 text-xs">SOON</Badge>
              </div>
              <h3 className="text-white font-semibold text-sm">License Determination</h3>
              <p className="text-gray-400 text-xs mt-1">Determine licensing requirements</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Professional Services Navigation */}
      <Card className="bg-gray-900/50 border-gray-700 backdrop-blur-sm">
        <CardHeader>
          <CardTitle className="text-white flex items-center">
            <Users className="w-5 h-5 mr-2 text-blue-400" />
            Professional Services
          </CardTitle>
          <CardDescription className="text-gray-400">
            Expert compliance support and consulting services
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <div className="group cursor-pointer" onClick={() => window.open('mailto:services@respectus.com?subject=Expert Assessment Validation', '_blank')}>
              <div className="p-4 rounded-lg bg-gradient-to-r from-blue-500/10 to-purple-500/10 border border-blue-500/20 hover:border-blue-500/40 transition-all duration-200">
                <div className="flex items-center justify-between mb-2">
                  <FileText className="w-6 h-6 text-blue-400" />
                  <Badge className="bg-green-500/20 text-green-400 border-green-500/30 text-xs">Expert Review</Badge>
                </div>
                <h3 className="text-white font-semibold text-sm">Assessment Validation</h3>
                <p className="text-gray-400 text-xs mt-1">Professional review by compliance experts</p>
              </div>
            </div>

            <div className="group cursor-pointer" onClick={() => window.open('mailto:services@respectus.com?subject=Compliance Consulting Inquiry', '_blank')}>
              <div className="p-4 rounded-lg bg-gradient-to-r from-green-500/10 to-blue-500/10 border border-green-500/20 hover:border-green-500/40 transition-all duration-200">
                <div className="flex items-center justify-between mb-2">
                  <Users className="w-6 h-6 text-green-400" />
                  <Badge className="bg-blue-500/20 text-blue-400 border-blue-500/30 text-xs">Consulting</Badge>
                </div>
                <h3 className="text-white font-semibold text-sm">Expert Consulting</h3>
                <p className="text-gray-400 text-xs mt-1">Personalized compliance guidance</p>
              </div>
            </div>

            <div className="group cursor-pointer" onClick={() => window.open('mailto:services@respectus.com?subject=Compliance Audit Services', '_blank')}>
              <div className="p-4 rounded-lg bg-gradient-to-r from-purple-500/10 to-pink-500/10 border border-purple-500/20 hover:border-purple-500/40 transition-all duration-200">
                <div className="flex items-center justify-between mb-2">
                  <Search className="w-6 h-6 text-purple-400" />
                  <Badge className="bg-purple-500/20 text-purple-400 border-purple-500/30 text-xs">Audit</Badge>
                </div>
                <h3 className="text-white font-semibold text-sm">Compliance Audit</h3>
                <p className="text-gray-400 text-xs mt-1">Comprehensive compliance program review</p>
              </div>
            </div>

            <div className="group cursor-pointer" onClick={() => window.open('mailto:services@respectus.com?subject=Internal Compliance Program Development', '_blank')}>
              <div className="p-4 rounded-lg bg-gradient-to-r from-orange-500/10 to-red-500/10 border border-orange-500/20 hover:border-orange-500/40 transition-all duration-200">
                <div className="flex items-center justify-between mb-2">
                  <Shield className="w-6 h-6 text-orange-400" />
                  <Badge className="bg-orange-500/20 text-orange-400 border-orange-500/30 text-xs">Program Design</Badge>
                </div>
                <h3 className="text-white font-semibold text-sm">Internal Compliance Program</h3>
                <p className="text-gray-400 text-xs mt-1">Design and implement compliance frameworks</p>
              </div>
            </div>

            <div className="group cursor-pointer" onClick={() => window.open('mailto:services@respectus.com?subject=Product Classification Services', '_blank')}>
              <div className="p-4 rounded-lg bg-gradient-to-r from-cyan-500/10 to-teal-500/10 border border-cyan-500/20 hover:border-cyan-500/40 transition-all duration-200">
                <div className="flex items-center justify-between mb-2">
                  <Target className="w-6 h-6 text-cyan-400" />
                  <Badge className="bg-cyan-500/20 text-cyan-400 border-cyan-500/30 text-xs">Classification</Badge>
                </div>
                <h3 className="text-white font-semibold text-sm">Product Classification</h3>
                <p className="text-gray-400 text-xs mt-1">Expert product classification services</p>
              </div>
            </div>

            <div className="group cursor-pointer" onClick={() => window.open('mailto:services@respectus.com?subject=License Management Services', '_blank')}>
              <div className="p-4 rounded-lg bg-gradient-to-r from-indigo-500/10 to-purple-500/10 border border-indigo-500/20 hover:border-indigo-500/40 transition-all duration-200">
                <div className="flex items-center justify-between mb-2">
                  <Receipt className="w-6 h-6 text-indigo-400" />
                  <Badge className="bg-indigo-500/20 text-indigo-400 border-indigo-500/30 text-xs">License Mgmt</Badge>
                </div>
                <h3 className="text-white font-semibold text-sm">License Management</h3>
                <p className="text-gray-400 text-xs mt-1">End-to-end license application and management</p>
              </div>
            </div>

            <div className="group cursor-pointer" onClick={() => window.open('mailto:services@respectus.com?subject=External Compliance Officer Services', '_blank')}>
              <div className="p-4 rounded-lg bg-gradient-to-r from-emerald-500/10 to-green-500/10 border border-emerald-500/20 hover:border-emerald-500/40 transition-all duration-200">
                <div className="flex items-center justify-between mb-2">
                  <Award className="w-6 h-6 text-emerald-400" />
                  <Badge className="bg-emerald-500/20 text-emerald-400 border-emerald-500/30 text-xs">Outsourcing</Badge>
                </div>
                <h3 className="text-white font-semibold text-sm">External Compliance Officer</h3>
                <p className="text-gray-400 text-xs mt-1">Dedicated compliance officer services</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Progress Overview */}
      <Card className="bg-gray-900/50 border-gray-700 backdrop-blur-sm">
        <CardHeader>
          <CardTitle className="text-white flex items-center">
            <Award className="w-5 h-5 mr-2 text-purple-400" />
            Onboarding Progress
          </CardTitle>
          <CardDescription className="text-gray-400">
            {calculateOnboardingCompletion()}% complete • Keep going to unlock the full potential of RespectUs
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="w-full bg-gray-700 rounded-full h-2">
              <div 
                className="bg-gradient-to-r from-purple-600 to-blue-600 h-2 rounded-full transition-all duration-500"
                style={{ width: `${calculateOnboardingCompletion()}%` }}
              />
            </div>
            <div className="flex items-center justify-between text-sm">
              <span className="text-gray-400">Progress</span>
              <span className="text-purple-400 font-medium">{calculateOnboardingCompletion()}%</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Onboarding Checklist */}
      <Card className="bg-gray-900/50 border-gray-700 backdrop-blur-sm">
        <CardHeader>
          <CardTitle className="text-white">Get Started Checklist</CardTitle>
          <CardDescription className="text-gray-400">
            Complete these steps to make the most of RespectUs
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center space-x-3 p-3 rounded-lg bg-green-500/10 border border-green-500/20">
              <CheckCircle className="w-5 h-5 text-green-400" />
              <div className="flex-1">
                <p className="text-white font-medium">Create Your Account</p>
                <p className="text-gray-400 text-sm">Welcome! You've successfully created your account.</p>
              </div>
            </div>

            <div className="flex items-center space-x-3 p-3 rounded-lg bg-blue-500/10 border border-blue-500/20 cursor-pointer hover:bg-blue-500/15 transition-colors" onClick={markKnowledgeBaseExplored}>
              {onboardingProgress.explored_knowledge_base ? (
                <CheckCircle className="w-5 h-5 text-green-400" />
              ) : (
                <div className="w-5 h-5 rounded-full border-2 border-blue-400 flex items-center justify-center">
                  <div className="w-2 h-2 bg-blue-400 rounded-full"></div>
                </div>
              )}
              <div className="flex-1">
                <p className="text-white font-medium">Explore the Knowledge Base</p>
                <p className="text-gray-400 text-sm">Browse regulatory documents and compliance guidance (Free)</p>
              </div>
              <ArrowRight className="w-4 h-4 text-blue-400" />
            </div>

            <div className="flex items-center space-x-3 p-3 rounded-lg bg-gray-500/10 border border-gray-500/20 cursor-pointer hover:bg-gray-500/15 transition-colors" onClick={() => handleModuleAccess({name: 'risk_assessment', title: 'Risk Assessment', user_has_access: userAccessStatus?.modules.find(m => m.name === 'risk_assessment')?.user_has_access || false, status: 'available', price_eur: 99})}>
              {onboardingProgress.tried_risk_assessment ? (
                <CheckCircle className="w-5 h-5 text-green-400" />
              ) : (
                <div className="w-5 h-5 rounded-full border-2 border-gray-400"></div>
              )}
              <div className="flex-1">
                <p className="text-white font-medium">Try Risk Assessment</p>
                <p className="text-gray-400 text-sm">Complete your first compliance assessment</p>
              </div>
              <ArrowRight className="w-4 h-4 text-gray-400" />
            </div>

            <div className="flex items-center space-x-3 p-3 rounded-lg bg-gray-500/10 border border-gray-500/20 cursor-pointer hover:bg-gray-500/15 transition-colors" onClick={() => setActiveTab('services')}>
              {onboardingProgress.configured_workflow ? (
                <CheckCircle className="w-5 h-5 text-green-400" />
              ) : (
                <div className="w-5 h-5 rounded-full border-2 border-gray-400"></div>
              )}
              <div className="flex-1">
                <p className="text-white font-medium">Set Up Your Compliance Workflow</p>
                <p className="text-gray-400 text-sm">Configure modules based on your business needs</p>
              </div>
              <ArrowRight className="w-4 h-4 text-gray-400" />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <Card className="bg-gray-900/50 border-gray-700 backdrop-blur-sm">
        <CardHeader>
          <CardTitle className="text-white">Quick Actions</CardTitle>
          <CardDescription className="text-gray-400">
            Jump into key features to start your compliance journey
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Button 
              onClick={startGuidedTour}
              className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white h-auto p-4 flex flex-col items-start space-y-2"
            >
              <Play className="w-6 h-6" />
              <div className="text-left">
                <div className="font-semibold">Take Guided Tour</div>
                <div className="text-xs opacity-80">Learn the platform step-by-step</div>
              </div>
            </Button>

            <Button 
              onClick={markKnowledgeBaseExplored}
              className="bg-blue-600 hover:bg-blue-700 text-white h-auto p-4 flex flex-col items-start space-y-2"
            >
              <FileText className="w-6 h-6" />
              <div className="text-left">
                <div className="font-semibold">Browse Knowledge Base</div>
                <div className="text-xs opacity-80">Access free compliance resources</div>
              </div>
            </Button>

            <Button 
              onClick={() => handleModuleAccess({name: 'risk_assessment', title: 'Risk Assessment', user_has_access: userAccessStatus?.modules.find(m => m.name === 'risk_assessment')?.user_has_access || false, status: 'available', price_eur: 99})}
              className="bg-purple-600 hover:bg-purple-700 text-white h-auto p-4 flex flex-col items-start space-y-2"
            >
              <BarChart3 className="w-6 h-6" />
              <div className="text-left">
                <div className="font-semibold">Start Risk Assessment</div>
                <div className="text-xs opacity-80">Evaluate compliance risks</div>
              </div>
            </Button>

            <Button 
              onClick={() => setActiveTab('services')}
              className="bg-gray-600 hover:bg-gray-700 text-white h-auto p-4 flex flex-col items-start space-y-2"
            >
              <Shield className="w-6 h-6" />
              <div className="text-left">
                <div className="font-semibold">View All Modules</div>
                <div className="text-xs opacity-80">Explore all compliance tools</div>
              </div>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
