
import React, { useState, useCallback } from 'react';
import SearchWidget, { SearchResult, createSearchConfig } from 'components/SearchWidget';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Shield, Package, AlertTriangle, FileText, ExternalLink, Calendar, Tag, CheckCircle, XCircle } from 'lucide-react';
import { toast } from 'sonner';
import brain from 'brain';
import { ProductClassification, ProductSearchRequest } from 'brain/data-contracts';

interface ProductClassificationWidgetProps {
  open: boolean;
  onClose: () => void;
  onSelectionConfirmed?: (products: ProductClassification[]) => void;
  initialQuery?: string;
  multiSelect?: boolean;
}

export default function ProductClassificationWidget({
  open,
  onClose,
  onSelectionConfirmed,
  initialQuery = '',
  multiSelect = false
}: ProductClassificationWidgetProps) {
  const [controlRegimes, setControlRegimes] = useState<string[]>([]);
  const [categories, setCategories] = useState<string[]>([]);
  const [riskLevels, setRiskLevels] = useState<string[]>([]);

  // Load filter options when component mounts
  React.useEffect(() => {
    const loadFilterOptions = async () => {
      try {
        const [regimesRes, categoriesRes, riskLevelsRes] = await Promise.all([
          brain.get_control_regimes(),
          brain.get_product_categories(),
          brain.get_product_risk_levels()
        ]);

        if (regimesRes.ok) {
          const data = await regimesRes.json();
          setControlRegimes(data);
        }
        if (categoriesRes.ok) {
          const data = await categoriesRes.json();
          setCategories(data);
        }
        if (riskLevelsRes.ok) {
          const data = await riskLevelsRes.json();
          setRiskLevels(data);
        }
      } catch (error) {
        console.error('Error loading filter options:', error);
      }
    };

    if (open) {
      loadFilterOptions();
    }
  }, [open]);

  const searchProducts = useCallback(async (query: string, filters: Record<string, any> = {}): Promise<SearchResult[]> => {
    try {
      const searchRequest: ProductSearchRequest = {
        query,
        control_regime: filters.control_regime || undefined,
        category: filters.category || undefined,
        license_required: filters.license_required === 'true' ? true : filters.license_required === 'false' ? false : undefined,
        risk_level: filters.risk_level || undefined,
        include_unrestricted: filters.include_unrestricted !== 'false',
        limit: 50
      };

      const response = await brain.search_products(searchRequest);
      
      if (!response.ok) {
        throw new Error('Search failed');
      }

      const data = await response.json();
      
      // Convert ProductClassification to SearchResult
      return data.products.map((product: ProductClassification): SearchResult => ({
        id: product.id,
        title: product.product_name,
        description: product.description,
        details: {
          classification_code: product.classification_code,
          control_regime: product.control_regime,
          category: product.category,
          subcategory: product.subcategory,
          restrictions: product.restrictions,
          license_required: product.license_required,
          license_exceptions: product.license_exceptions,
          technical_notes: product.technical_notes,
          related_codes: product.related_codes,
          last_updated: product.last_updated,
          source_regulation: product.source_regulation,
          risk_level: product.risk_level,
          ...product.details
        },
        tags: [
          product.classification_code,
          product.control_regime,
          product.category,
          product.risk_level,
          ...(product.license_required ? ['License Required'] : ['No License'])
        ],
        type: 'product_classification'
      }));
    } catch (error) {
      console.error('Product classification search error:', error);
      toast.error('Failed to search product classifications');
      return [];
    }
  }, []);

  const handleSelectionConfirmed = (results: SearchResult[]) => {
    if (onSelectionConfirmed) {
      // Convert SearchResult back to ProductClassification
      const products: ProductClassification[] = results.map(result => ({
        id: result.id,
        product_name: result.title,
        classification_code: result.details?.classification_code || '',
        control_regime: result.details?.control_regime || '',
        category: result.details?.category || '',
        subcategory: result.details?.subcategory,
        description: result.description || '',
        restrictions: result.details?.restrictions || [],
        license_required: result.details?.license_required || false,
        license_exceptions: result.details?.license_exceptions || [],
        technical_notes: result.details?.technical_notes,
        related_codes: result.details?.related_codes || [],
        last_updated: result.details?.last_updated || new Date().toISOString(),
        source_regulation: result.details?.source_regulation || '',
        risk_level: result.details?.risk_level || 'unknown',
        details: result.details || {}
      }));
      
      onSelectionConfirmed(products);
    }
  };

  const getRiskLevelColor = (riskLevel: string) => {
    switch (riskLevel) {
      case 'high': return 'bg-red-600 text-white';
      case 'medium': return 'bg-yellow-600 text-white';
      case 'low': return 'bg-blue-600 text-white';
      case 'unrestricted': return 'bg-green-600 text-white';
      default: return 'bg-gray-600 text-white';
    }
  };

  const getControlRegimeIcon = (regime: string) => {
    switch (regime) {
      case 'EAR': return <Shield className="h-4 w-4" />;
      case 'ITAR': return <AlertTriangle className="h-4 w-4" />;
      default: return <FileText className="h-4 w-4" />;
    }
  };

  const ProductResultTemplate = ({ result }: { result: SearchResult }) => {
    const classificationCode = result.details?.classification_code || '';
    const controlRegime = result.details?.control_regime || '';
    const riskLevel = result.details?.risk_level || 'unknown';
    const licenseRequired = result.details?.license_required || false;
    const restrictions = result.details?.restrictions || [];
    const licenseExceptions = result.details?.license_exceptions || [];
    const category = result.details?.category || '';
    const subcategory = result.details?.subcategory;

    return (
      <Card className="cursor-pointer transition-all hover:shadow-md border border-gray-700 hover:border-gray-600 bg-gray-800">
        <CardHeader className="pb-2">
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-2">
              <Package className="h-5 w-5 text-blue-400" />
              <div>
                <CardTitle className="text-lg text-white">{result.title}</CardTitle>
                <div className="flex items-center gap-2 mt-1">
                  <Badge variant="outline" className="text-xs border-blue-600 text-blue-300">
                    {classificationCode}
                  </Badge>
                  <div className="flex items-center gap-1 text-xs text-gray-400">
                    {getControlRegimeIcon(controlRegime)}
                    <span>{controlRegime}</span>
                  </div>
                </div>
              </div>
            </div>
            <div className="flex flex-col gap-1 items-end">
              <Badge className={getRiskLevelColor(riskLevel)}>
                {riskLevel.toUpperCase()}
              </Badge>
              <div className="flex items-center gap-1 text-xs">
                {licenseRequired ? (
                  <>
                    <XCircle className="h-3 w-3 text-red-400" />
                    <span className="text-red-400">License Required</span>
                  </>
                ) : (
                  <>
                    <CheckCircle className="h-3 w-3 text-green-400" />
                    <span className="text-green-400">No License</span>
                  </>
                )}
              </div>
            </div>
          </div>
        </CardHeader>
        
        <CardContent className="pt-0">
          {result.description && (
            <p className="text-sm text-gray-400 mb-3">{result.description}</p>
          )}

          <div className="grid grid-cols-2 gap-3 text-xs text-gray-400 mb-3">
            <div>
              <span className="font-medium">Category:</span> {category}
              {subcategory && (
                <>
                  <br />
                  <span className="font-medium">Subcategory:</span> {subcategory}
                </>
              )}
            </div>
            {licenseExceptions.length > 0 && (
              <div>
                <span className="font-medium">License Exceptions:</span>
                <div className="flex flex-wrap gap-1 mt-1">
                  {licenseExceptions.slice(0, 3).map((exception: string, index: number) => (
                    <Badge key={index} variant="outline" className="text-xs border-gray-600 text-gray-300">
                      {exception}
                    </Badge>
                  ))}
                  {licenseExceptions.length > 3 && (
                    <Badge variant="outline" className="text-xs border-gray-600 text-gray-300">
                      +{licenseExceptions.length - 3}
                    </Badge>
                  )}
                </div>
              </div>
            )}
          </div>

          {restrictions.length > 0 && (
            <div className="mb-3">
              <div className="text-xs font-medium text-yellow-400 mb-1 flex items-center gap-1">
                <AlertTriangle className="h-3 w-3" />
                Key Restrictions:
              </div>
              <ul className="text-xs text-gray-400 space-y-1">
                {restrictions.slice(0, 2).map((restriction: string, index: number) => (
                  <li key={index} className="flex items-start gap-1">
                    <span className="text-yellow-400 mt-1">•</span>
                    <span>{restriction}</span>
                  </li>
                ))}
                {restrictions.length > 2 && (
                  <li className="text-gray-500 italic">... and {restrictions.length - 2} more</li>
                )}
              </ul>
            </div>
          )}

          <div className="flex flex-wrap gap-1">
            <Badge variant="secondary" className="text-xs">
              <Tag className="h-3 w-3 mr-1" />
              {category}
            </Badge>
            <Badge variant="secondary" className="text-xs">
              {controlRegime}
            </Badge>
            {result.details?.source_regulation && (
              <Badge variant="secondary" className="text-xs">
                {result.details.source_regulation.split(' - ')[0]}
              </Badge>
            )}
          </div>
        </CardContent>
      </Card>
    );
  };

  const searchConfig = createSearchConfig({
    title: 'Search Product Classifications',
    description: 'Search for dual-use items, restricted products, and export control classifications',
    placeholder: 'Enter product name, description, or classification code...',
    searchFunction: searchProducts,
    multiSelect,
    repositoryLink: {
      label: 'Browse Classification Guide',
      url: '/knowledge-base?category=product-classification',
      description: 'Access complete product classification database and guides'
    },
    filters: [
      {
        label: 'Control Regime',
        key: 'control_regime',
        options: controlRegimes.map(regime => ({
          value: regime,
          label: regime
        }))
      },
      {
        label: 'Category',
        key: 'category',
        options: categories.map(category => ({
          value: category,
          label: category
        }))
      },
      {
        label: 'License Required',
        key: 'license_required',
        options: [
          { value: 'true', label: 'Yes' },
          { value: 'false', label: 'No' }
        ]
      },
      {
        label: 'Risk Level',
        key: 'risk_level',
        options: riskLevels.map(level => ({
          value: level,
          label: level.charAt(0).toUpperCase() + level.slice(1)
        }))
      },
      {
        label: 'Include Unrestricted',
        key: 'include_unrestricted',
        options: [
          { value: 'true', label: 'Yes' },
          { value: 'false', label: 'No' }
        ]
      }
    ],
    resultTemplate: ProductResultTemplate
  });

  return (
    <SearchWidget
      config={searchConfig}
      open={open}
      onClose={onClose}
      onSelectionConfirmed={handleSelectionConfirmed}
      initialQuery={initialQuery}
      className="product-classification-widget"
    />
  );
}

// Export types for use in other components
export type { ProductClassification } from 'types';
