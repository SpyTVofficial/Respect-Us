import React, { useState } from 'react';
import { CreditConfirmationDialog } from './CreditConfirmationDialog';
import { 
  useCreditConfirmation, 
  handleApiCallWithCredits, 
  CreditConfirmationData 
} from 'utils/creditHandling';
import { toast } from 'sonner';

export interface DocumentAccessWrapperProps {
  children: React.ReactNode;
  onDocumentAccess?: (documentId: number, documentData: any) => void;
}

export const DocumentAccessWrapper: React.FC<DocumentAccessWrapperProps> = ({
  children,
  onDocumentAccess
}) => {
  const {
    isOpen,
    creditData,
    showCreditConfirmation,
    handleConfirm,
    handleCancel,
  } = useCreditConfirmation();
  
  const [isLoading, setIsLoading] = useState(false);
  
  const handleCreditConfirm = async () => {
    setIsLoading(true);
    try {
      await handleConfirm();
      toast.success('Document accessed successfully');
    } catch (error) {
      console.error('Failed to access document:', error);
      toast.error('Failed to access document');
    } finally {
      setIsLoading(false);
    }
  };
  
  return (
    <>
      {children}
      
      {creditData && (
        <CreditConfirmationDialog
          open={isOpen}
          onOpenChange={handleCancel}
          onConfirm={handleCreditConfirm}
          onCancel={handleCancel}
          documentTitle={creditData.documentTitle}
          requiredCredits={creditData.requiredCredits}
          currentBalance={creditData.currentBalance}
          isLoading={isLoading}
        />
      )}
    </>
  );
};

/**
 * Higher-order component for document access with credit handling
 */
export const withDocumentAccess = <P extends object>(
  Component: React.ComponentType<P>
) => {
  return React.forwardRef<any, P>((props, ref) => (
    <DocumentAccessWrapper>
      <Component {...props} ref={ref} />
    </DocumentAccessWrapper>
  ));
};
