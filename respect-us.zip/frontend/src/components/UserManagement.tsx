


import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Edit, Trash2, Plus } from 'lucide-react';
import { toast } from 'sonner';
import brain from 'brain';
import type { CustomerProfile } from 'types';

interface UserManagementProps {
  users: CustomerProfile[];
  onRefresh: () => void;
}

export const UserManagement: React.FC<UserManagementProps> = ({ users, onRefresh }) => {
  const [showAddUserDialog, setShowAddUserDialog] = useState(false);
  const [showEditUserDialog, setShowEditUserDialog] = useState(false);
  const [selectedUser, setSelectedUser] = useState<CustomerProfile | null>(null);
  const [loading, setLoading] = useState(false);

  const [newUserForm, setNewUserForm] = useState({
    email: '',
    contact_person: '',
    company_name: '',
    phone: '',
    country: '',
    billing_address: '',
    city: '',
    postal_code: '',
    tax_id: '',
    vat_number: ''
  });

  const [editUserForm, setEditUserForm] = useState({
    customer_id: '',
    email: '',
    contact_person: '',
    company_name: '',
    phone: '',
    country: '',
    billing_address: '',
    city: '',
    postal_code: '',
    tax_id: '',
    vat_number: ''
  });

  const handleEditUser = (user: CustomerProfile) => {
    setSelectedUser(user);
    setEditUserForm({
      customer_id: user.customer_id,
      email: user.email,
      contact_person: user.contact_person || '',
      company_name: user.company_name || '',
      phone: user.phone || '',
      country: user.country || '',
      billing_address: user.billing_address || '',
      city: user.city || '',
      postal_code: user.postal_code || '',
      tax_id: user.tax_id || '',
      vat_number: user.vat_number || ''
    });
    setShowEditUserDialog(true);
  };

  const handleCreateUser = async () => {
    if (!newUserForm.email || !newUserForm.contact_person) {
      toast.error('Email and Contact Person are required');
      return;
    }

    setLoading(true);
    try {
      const response = await brain.create_user({
        email: newUserForm.email,
        contact_person: newUserForm.contact_person,
        company_name: newUserForm.company_name || null,
        phone: newUserForm.phone || null,
        country: newUserForm.country || null,
        billing_address: newUserForm.billing_address || null,
        city: newUserForm.city || null,
        postal_code: newUserForm.postal_code || null,
        tax_id: newUserForm.tax_id || null,
        vat_number: newUserForm.vat_number || null
      });

      const result = await response.json();
      if (result.success) {
        toast.success('User created successfully');
        setShowAddUserDialog(false);
        setNewUserForm({
          email: '',
          contact_person: '',
          company_name: '',
          phone: '',
          country: '',
          billing_address: '',
          city: '',
          postal_code: '',
          tax_id: '',
          vat_number: ''
        });
        onRefresh();
      } else {
        toast.error(result.message || 'Failed to create user');
      }
    } catch (error) {
      console.error('Error creating user:', error);
      toast.error('Failed to create user');
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateUser = async () => {
    if (!editUserForm.email || !editUserForm.contact_person) {
      toast.error('Email and Contact Person are required');
      return;
    }

    setLoading(true);
    try {
      const response = await brain.update_user(
        { customerId: editUserForm.customer_id },
        {
          customer_id: editUserForm.customer_id,
          email: editUserForm.email,
          contact_person: editUserForm.contact_person,
          company_name: editUserForm.company_name || null,
          phone: editUserForm.phone || null,
          country: editUserForm.country || null,
          billing_address: editUserForm.billing_address || null,
          city: editUserForm.city || null,
          postal_code: editUserForm.postal_code || null,
          tax_id: editUserForm.tax_id || null,
          vat_number: editUserForm.vat_number || null
        }
      );

      const result = await response.json();
      if (result.success) {
        toast.success('User updated successfully');
        setShowEditUserDialog(false);
        onRefresh();
      } else {
        toast.error(result.message || 'Failed to update user');
      }
    } catch (error) {
      console.error('Error updating user:', error);
      toast.error('Failed to update user');
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteUser = async (customerId: string) => {
    if (!confirm('Are you sure you want to delete this user?')) {
      return;
    }

    setLoading(true);
    try {
      const response = await brain.delete_user({ customerId: customerId });
      const result = await response.json();
      
      if (result.success) {
        toast.success('User deleted successfully');
        onRefresh();
      } else {
        toast.error(result.message || 'Failed to delete user');
      }
    } catch (error) {
      console.error('Error deleting user:', error);
      toast.error('Failed to delete user');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle>User Management</CardTitle>
          <CardDescription>Manage customer accounts and information</CardDescription>
        </div>
        <Dialog open={showAddUserDialog} onOpenChange={setShowAddUserDialog}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Add User
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Add New User</DialogTitle>
              <DialogDescription>
                Create a new customer account
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="email">Email *</Label>
                  <Input
                    id="email"
                    value={newUserForm.email}
                    onChange={(e) => setNewUserForm({ ...newUserForm, email: e.target.value })}
                    placeholder="user@example.com"
                  />
                </div>
                <div>
                  <Label htmlFor="contact_person">Contact Person *</Label>
                  <Input
                    id="contact_person"
                    value={newUserForm.contact_person}
                    onChange={(e) => setNewUserForm({ ...newUserForm, contact_person: e.target.value })}
                    placeholder="John Doe"
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="company_name">Company Name</Label>
                  <Input
                    id="company_name"
                    value={newUserForm.company_name}
                    onChange={(e) => setNewUserForm({ ...newUserForm, company_name: e.target.value })}
                    placeholder="Company Inc."
                  />
                </div>
                <div>
                  <Label htmlFor="phone">Phone</Label>
                  <Input
                    id="phone"
                    value={newUserForm.phone}
                    onChange={(e) => setNewUserForm({ ...newUserForm, phone: e.target.value })}
                    placeholder="+1 234 567 8900"
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="country">Country</Label>
                  <Input
                    id="country"
                    value={newUserForm.country}
                    onChange={(e) => setNewUserForm({ ...newUserForm, country: e.target.value })}
                    placeholder="United States"
                  />
                </div>
                <div>
                  <Label htmlFor="city">City</Label>
                  <Input
                    id="city"
                    value={newUserForm.city}
                    onChange={(e) => setNewUserForm({ ...newUserForm, city: e.target.value })}
                    placeholder="New York"
                  />
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setShowAddUserDialog(false)}>
                Cancel
              </Button>
              <Button onClick={handleCreateUser} disabled={loading}>
                {loading ? 'Creating...' : 'Create User'}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </CardHeader>
      <CardContent>
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Email</TableHead>
                <TableHead>Contact Person</TableHead>
                <TableHead>Company</TableHead>
                <TableHead>Country</TableHead>
                <TableHead>Phone</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {users.map((user) => (
                <TableRow key={user.customer_id}>
                  <TableCell>{user.email}</TableCell>
                  <TableCell>{user.contact_person || '-'}</TableCell>
                  <TableCell>{user.company_name || '-'}</TableCell>
                  <TableCell>{user.country || '-'}</TableCell>
                  <TableCell>{user.phone || '-'}</TableCell>
                  <TableCell>
                    <div className="flex space-x-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleEditUser(user)}
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleDeleteUser(user.customer_id)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>

        {/* Edit User Dialog */}
        <Dialog open={showEditUserDialog} onOpenChange={setShowEditUserDialog}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Edit User</DialogTitle>
              <DialogDescription>
                Update customer information
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="edit_email">Email *</Label>
                  <Input
                    id="edit_email"
                    value={editUserForm.email}
                    onChange={(e) => setEditUserForm({ ...editUserForm, email: e.target.value })}
                    placeholder="user@example.com"
                  />
                </div>
                <div>
                  <Label htmlFor="edit_contact_person">Contact Person *</Label>
                  <Input
                    id="edit_contact_person"
                    value={editUserForm.contact_person}
                    onChange={(e) => setEditUserForm({ ...editUserForm, contact_person: e.target.value })}
                    placeholder="John Doe"
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="edit_company_name">Company Name</Label>
                  <Input
                    id="edit_company_name"
                    value={editUserForm.company_name}
                    onChange={(e) => setEditUserForm({ ...editUserForm, company_name: e.target.value })}
                    placeholder="Company Inc."
                  />
                </div>
                <div>
                  <Label htmlFor="edit_phone">Phone</Label>
                  <Input
                    id="edit_phone"
                    value={editUserForm.phone}
                    onChange={(e) => setEditUserForm({ ...editUserForm, phone: e.target.value })}
                    placeholder="+1 234 567 8900"
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="edit_country">Country</Label>
                  <Input
                    id="edit_country"
                    value={editUserForm.country}
                    onChange={(e) => setEditUserForm({ ...editUserForm, country: e.target.value })}
                    placeholder="United States"
                  />
                </div>
                <div>
                  <Label htmlFor="edit_city">City</Label>
                  <Input
                    id="edit_city"
                    value={editUserForm.city}
                    onChange={(e) => setEditUserForm({ ...editUserForm, city: e.target.value })}
                    placeholder="New York"
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="edit_billing_address">Billing Address</Label>
                  <Input
                    id="edit_billing_address"
                    value={editUserForm.billing_address}
                    onChange={(e) => setEditUserForm({ ...editUserForm, billing_address: e.target.value })}
                    placeholder="123 Main St"
                  />
                </div>
                <div>
                  <Label htmlFor="edit_postal_code">Postal Code</Label>
                  <Input
                    id="edit_postal_code"
                    value={editUserForm.postal_code}
                    onChange={(e) => setEditUserForm({ ...editUserForm, postal_code: e.target.value })}
                    placeholder="12345"
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="edit_tax_id">Tax ID</Label>
                  <Input
                    id="edit_tax_id"
                    value={editUserForm.tax_id}
                    onChange={(e) => setEditUserForm({ ...editUserForm, tax_id: e.target.value })}
                    placeholder="123-45-6789"
                  />
                </div>
                <div>
                  <Label htmlFor="edit_vat_number">VAT Number</Label>
                  <Input
                    id="edit_vat_number"
                    value={editUserForm.vat_number}
                    onChange={(e) => setEditUserForm({ ...editUserForm, vat_number: e.target.value })}
                    placeholder="GB123456789"
                  />
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setShowEditUserDialog(false)}>
                Cancel
              </Button>
              <Button onClick={handleUpdateUser} disabled={loading}>
                {loading ? 'Updating...' : 'Update User'}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </CardContent>
    </Card>
  );
};
