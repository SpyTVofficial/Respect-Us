import React from 'react';
import { Bell, Plus, Edit, Trash2, Send, Users, AlertTriangle, Info, Shield, Eye } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import brain from 'brain';
import { AdminNotification, AdminNotificationCreate } from 'types';
import { formatDistanceToNow } from 'date-fns';
import { toast } from 'sonner';

interface AdminNotificationManagerProps {
  className?: string;
}

const AdminNotificationManager: React.FC<AdminNotificationManagerProps> = ({ className }) => {
  const [notifications, setNotifications] = React.useState<AdminNotification[]>([]);
  const [loading, setLoading] = React.useState(false);
  const [createDialogOpen, setCreateDialogOpen] = React.useState(false);
  const [editingNotification, setEditingNotification] = React.useState<AdminNotification | null>(null);
  const [formData, setFormData] = React.useState<AdminNotificationCreate>({
    title: '',
    message: '',
    notification_type: 'announcement',
    priority: 'medium',
    target_audience: 'all_users',
    target_criteria: null,
    expires_at: null,
    metadata: null
  });

  const fetchNotifications = React.useCallback(async () => {
    try {
      setLoading(true);
      const response = await brain.get_admin_notifications({ active_only: false, limit: 50 });
      const data = await response.json();
      setNotifications(data || []);
    } catch (error) {
      console.error('Error fetching notifications:', error);
      toast.error('Failed to load notifications');
    } finally {
      setLoading(false);
    }
  }, []);

  React.useEffect(() => {
    fetchNotifications();
  }, [fetchNotifications]);

  const handleCreate = async () => {
    try {
      const response = await brain.create_admin_notification(formData);
      const result = await response.json();
      
      if (response.ok) {
        toast.success('Notification created successfully');
        setCreateDialogOpen(false);
        resetForm();
        fetchNotifications();
      } else {
        toast.error(result.detail || 'Failed to create notification');
      }
    } catch (error) {
      console.error('Error creating notification:', error);
      toast.error('Failed to create notification');
    }
  };

  const handleUpdate = async (notificationId: string) => {
    try {
      const response = await brain.update_admin_notification(
        { notification_id: notificationId },
        formData
      );
      const result = await response.json();
      
      if (response.ok) {
        toast.success('Notification updated successfully');
        setEditingNotification(null);
        resetForm();
        fetchNotifications();
      } else {
        toast.error(result.detail || 'Failed to update notification');
      }
    } catch (error) {
      console.error('Error updating notification:', error);
      toast.error('Failed to update notification');
    }
  };

  const handleDelete = async (notificationId: string) => {
    if (!confirm('Are you sure you want to deactivate this notification?')) return;
    
    try {
      const response = await brain.delete_admin_notification({ notification_id: notificationId });
      
      if (response.ok) {
        toast.success('Notification deactivated successfully');
        fetchNotifications();
      } else {
        toast.error('Failed to deactivate notification');
      }
    } catch (error) {
      console.error('Error deleting notification:', error);
      toast.error('Failed to deactivate notification');
    }
  };

  const resetForm = () => {
    setFormData({
      title: '',
      message: '',
      notification_type: 'announcement',
      priority: 'medium',
      target_audience: 'all_users',
      target_criteria: null,
      expires_at: null,
      metadata: null
    });
  };

  const startEdit = (notification: AdminNotification) => {
    setEditingNotification(notification);
    setFormData({
      title: notification.title,
      message: notification.message,
      notification_type: notification.notification_type,
      priority: notification.priority,
      target_audience: notification.target_audience,
      target_criteria: notification.target_criteria,
      expires_at: notification.expires_at ? new Date(notification.expires_at).toISOString().slice(0, 16) : null,
      metadata: notification.metadata
    });
  };

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'security_alert': return <Shield className="h-4 w-4 text-red-500" />;
      case 'feature_update': return <Info className="h-4 w-4 text-blue-500" />;
      case 'maintenance': return <AlertTriangle className="h-4 w-4 text-amber-500" />;
      case 'announcement': return <Bell className="h-4 w-4 text-green-500" />;
      default: return <Bell className="h-4 w-4 text-gray-500" />;
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'urgent': return 'bg-red-100 text-red-800 border-red-200';
      case 'high': return 'bg-orange-100 text-orange-800 border-orange-200';
      case 'medium': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'low': return 'bg-gray-100 text-gray-800 border-gray-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getStatusBadge = (notification: AdminNotification) => {
    if (!notification.is_active) {
      return <Badge variant="secondary">Inactive</Badge>;
    }
    if (notification.expires_at && new Date(notification.expires_at) < new Date()) {
      return <Badge variant="outline" className="text-gray-600">Expired</Badge>;
    }
    return <Badge variant="default" className="bg-green-600">Active</Badge>;
  };

  return (
    <div className={className}>
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Bell className="h-5 w-5" />
                Admin Notifications
              </CardTitle>
              <CardDescription>
                Create and manage system-wide notifications for users
              </CardDescription>
            </div>
            <Dialog open={createDialogOpen} onOpenChange={setCreateDialogOpen}>
              <DialogTrigger asChild>
                <Button onClick={resetForm}>
                  <Plus className="h-4 w-4 mr-2" />
                  Create Notification
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl">
                <DialogHeader>
                  <DialogTitle>
                    {editingNotification ? 'Edit Notification' : 'Create New Notification'}
                  </DialogTitle>
                </DialogHeader>
                
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="title">Title</Label>
                      <Input
                        id="title"
                        value={formData.title}
                        onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
                        placeholder="Notification title"
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="type">Type</Label>
                      <Select 
                        value={formData.notification_type} 
                        onValueChange={(value) => setFormData(prev => ({ ...prev, notification_type: value }))}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="announcement">Announcement</SelectItem>
                          <SelectItem value="maintenance">Maintenance</SelectItem>
                          <SelectItem value="feature_update">Feature Update</SelectItem>
                          <SelectItem value="security_alert">Security Alert</SelectItem>
                          <SelectItem value="general">General</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="priority">Priority</Label>
                      <Select 
                        value={formData.priority} 
                        onValueChange={(value) => setFormData(prev => ({ ...prev, priority: value }))}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="low">Low</SelectItem>
                          <SelectItem value="medium">Medium</SelectItem>
                          <SelectItem value="high">High</SelectItem>
                          <SelectItem value="urgent">Urgent</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="audience">Target Audience</Label>
                      <Select 
                        value={formData.target_audience} 
                        onValueChange={(value) => setFormData(prev => ({ ...prev, target_audience: value }))}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all_users">All Users</SelectItem>
                          <SelectItem value="specific_users">Specific Users</SelectItem>
                          <SelectItem value="by_role">By Role</SelectItem>
                          <SelectItem value="by_module">By Module</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="message">Message</Label>
                    <Textarea
                      id="message"
                      value={formData.message}
                      onChange={(e) => setFormData(prev => ({ ...prev, message: e.target.value }))}
                      placeholder="Notification message..."
                      rows={4}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="expires_at">Expiration Date (Optional)</Label>
                    <Input
                      id="expires_at"
                      type="datetime-local"
                      value={formData.expires_at || ''}
                      onChange={(e) => setFormData(prev => ({ ...prev, expires_at: e.target.value || null }))}
                    />
                  </div>
                  
                  <div className="flex justify-end gap-2 pt-4">
                    <Button 
                      variant="outline" 
                      onClick={() => {
                        setCreateDialogOpen(false);
                        setEditingNotification(null);
                        resetForm();
                      }}
                    >
                      Cancel
                    </Button>
                    <Button 
                      onClick={() => editingNotification ? handleUpdate(editingNotification.notification_id) : handleCreate()}
                      disabled={!formData.title || !formData.message}
                    >
                      <Send className="h-4 w-4 mr-2" />
                      {editingNotification ? 'Update' : 'Create'} Notification
                    </Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </CardHeader>
        
        <CardContent>
          {loading ? (
            <div className="text-center py-8 text-gray-500">
              Loading notifications...
            </div>
          ) : notifications.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              <Bell className="h-12 w-12 mx-auto mb-3 text-gray-300" />
              <p>No notifications created yet</p>
              <p className="text-sm text-gray-400 mt-1">
                Create your first notification to communicate with users
              </p>
            </div>
          ) : (
            <ScrollArea className="h-96">
              <div className="space-y-4">
                {notifications.map((notification) => (
                  <Card key={notification.notification_id} className="p-4">
                    <div className="flex items-start justify-between">
                      <div className="flex items-start gap-3 flex-1">
                        <div className="mt-1">
                          {getNotificationIcon(notification.notification_type)}
                        </div>
                        
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-1">
                            <h4 className="font-medium text-gray-900 truncate">
                              {notification.title}
                            </h4>
                            <Badge 
                              variant="outline" 
                              className={`text-xs ${getPriorityColor(notification.priority)}`}
                            >
                              {notification.priority.toUpperCase()}
                            </Badge>
                            {getStatusBadge(notification)}
                          </div>
                          
                          <p className="text-sm text-gray-600 mb-2 line-clamp-2">
                            {notification.message}
                          </p>
                          
                          <div className="flex items-center gap-4 text-xs text-gray-500">
                            <span className="flex items-center gap-1">
                              <Users className="h-3 w-3" />
                              {notification.target_audience.replace('_', ' ')}
                            </span>
                            <span>
                              {formatDistanceToNow(new Date(notification.created_at), { addSuffix: true })}
                            </span>
                            {notification.delivery_stats && (
                              <span className="flex items-center gap-1">
                                <Eye className="h-3 w-3" />
                                {notification.delivery_stats.read_count}/{notification.delivery_stats.total_users} read
                              </span>
                            )}
                          </div>
                          
                          {notification.expires_at && (
                            <p className="text-xs text-amber-600 mt-1">
                              Expires: {new Date(notification.expires_at).toLocaleDateString()}
                            </p>
                          )}
                        </div>
                      </div>
                      
                      <div className="flex items-center gap-1 ml-4">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => {
                            startEdit(notification);
                            setCreateDialogOpen(true);
                          }}
                          className="h-8 w-8 p-0"
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        
                        {notification.is_active && (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleDelete(notification.notification_id)}
                            className="h-8 w-8 p-0 text-red-600 hover:text-red-700 hover:bg-red-50"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        )}
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            </ScrollArea>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default AdminNotificationManager;
