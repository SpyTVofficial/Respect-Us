


import React, { useState, useEffect } from 'react';
import { toast } from 'sonner';
import brain from 'brain';
import { AppApisSavedArticlesCategoryResponse, AppApisSavedArticlesCategoryRequest } from 'types';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Badge } from '@/components/ui/badge';
import {
  Plus,
  FolderPlus,
  Edit3,
  Trash2,
  MoreHorizontal,
  Folder,
  Tag,
  Archive,
  BookOpen,
  Briefcase,
  Star,
  Heart,
  Target,
  Lightbulb,
  FileText,
  Shield,
  Globe,
  TrendingUp,
} from 'lucide-react';

interface Props {
  onCategoryChange?: () => void;
  selectedCategoryId?: number | null;
  onCategorySelect?: (categoryId: number | null) => void;
}

// Icon options for categories
const ICON_OPTIONS = [
  { value: 'folder', label: 'Folder', icon: Folder },
  { value: 'tag', label: 'Tag', icon: Tag },
  { value: 'archive', label: 'Archive', icon: Archive },
  { value: 'book-open', label: 'Book', icon: BookOpen },
  { value: 'briefcase', label: 'Business', icon: Briefcase },
  { value: 'star', label: 'Important', icon: Star },
  { value: 'heart', label: 'Favorites', icon: Heart },
  { value: 'target', label: 'Goals', icon: Target },
  { value: 'lightbulb', label: 'Ideas', icon: Lightbulb },
  { value: 'file-text', label: 'Documents', icon: FileText },
  { value: 'shield', label: 'Compliance', icon: Shield },
  { value: 'globe', label: 'Global', icon: Globe },
  { value: 'trending-up', label: 'Growth', icon: TrendingUp },
];

// Color options for categories
const COLOR_OPTIONS = [
  { value: '#6366f1', label: 'Indigo', color: '#6366f1' },
  { value: '#8b5cf6', label: 'Purple', color: '#8b5cf6' },
  { value: '#06b6d4', label: 'Cyan', color: '#06b6d4' },
  { value: '#10b981', label: 'Emerald', color: '#10b981' },
  { value: '#f59e0b', label: 'Amber', color: '#f59e0b' },
  { value: '#ef4444', label: 'Red', color: '#ef4444' },
  { value: '#ec4899', label: 'Pink', color: '#ec4899' },
  { value: '#84cc16', label: 'Lime', color: '#84cc16' },
  { value: '#f97316', label: 'Orange', color: '#f97316' },
  { value: '#64748b', label: 'Slate', color: '#64748b' },
];

const getIconComponent = (iconName: string) => {
  const iconOption = ICON_OPTIONS.find(opt => opt.value === iconName);
  return iconOption ? iconOption.icon : Folder;
};

export const CategoryManager: React.FC<Props> = ({ 
  onCategoryChange, 
  selectedCategoryId,
  onCategorySelect 
}) => {
  const [categories, setCategories] = useState<AppApisSavedArticlesCategoryResponse[]>([]);
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [editingCategory, setEditingCategory] = useState<AppApisSavedArticlesCategoryResponse | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  
  // Form state
  const [formData, setFormData] = useState<AppApisSavedArticlesCategoryRequest>({
    name: '',
    description: '',
    color: '#6366f1',
    icon: 'folder',
    display_order: 0,
  });

  // Load categories
  const loadCategories = async () => {
    try {
      setIsLoading(true);
      const response = await brain.get_article_categories();
      const data = await response.json();
      setCategories(data);
    } catch (error) {
      console.error('Error loading categories:', error);
      toast.error('Failed to load categories');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadCategories();
  }, []);

  const resetForm = () => {
    setFormData({
      name: '',
      description: '',
      color: '#6366f1',
      icon: 'folder',
      display_order: 0,
    });
  };

  const handleCreateCategory = async () => {
    if (!formData.name.trim()) {
      toast.error('Category name is required');
      return;
    }

    try {
      setIsLoading(true);
      await brain.create_article_category(formData);
      toast.success('Category created successfully');
      setIsCreateDialogOpen(false);
      resetForm();
      await loadCategories();
      onCategoryChange?.();
    } catch (error: any) {
      console.error('Error creating category:', error);
      if (error.message?.includes('already exists')) {
        toast.error('A category with this name already exists');
      } else {
        toast.error('Failed to create category');
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleEditCategory = async () => {
    if (!editingCategory || !formData.name.trim()) {
      toast.error('Category name is required');
      return;
    }

    try {
      setIsLoading(true);
      await brain.update_article_category(
        { categoryId: editingCategory.id },
        formData
      );
      toast.success('Category updated successfully');
      setIsEditDialogOpen(false);
      setEditingCategory(null);
      resetForm();
      await loadCategories();
      onCategoryChange?.();
    } catch (error: any) {
      console.error('Error updating category:', error);
      if (error.message?.includes('already exists')) {
        toast.error('A category with this name already exists');
      } else {
        toast.error('Failed to update category');
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleDeleteCategory = async (categoryId: number) => {
    if (!confirm('Are you sure you want to delete this category?')) {
      return;
    }

    try {
      setIsLoading(true);
      await brain.delete_article_category({ categoryId });
      toast.success('Category deleted successfully');
      await loadCategories();
      onCategoryChange?.();
      
      // If the deleted category was selected, clear the selection
      if (selectedCategoryId === categoryId) {
        onCategorySelect?.(null);
      }
    } catch (error) {
      console.error('Error deleting category:', error);
      toast.error('Failed to delete category');
    } finally {
      setIsLoading(false);
    }
  };

  const openEditDialog = (category: AppApisSavedArticlesCategoryResponse) => {
    setEditingCategory(category);
    setFormData({
      name: category.name,
      description: category.description || '',
      color: category.color,
      icon: category.icon,
      display_order: category.display_order,
    });
    setIsEditDialogOpen(true);
  };

  const renderCategoryForm = () => (
    <div className="space-y-4">
      <div>
        <Label htmlFor="name">Category Name</Label>
        <Input
          id="name"
          value={formData.name}
          onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
          placeholder="Enter category name"
          className="mt-1"
        />
      </div>
      
      <div>
        <Label htmlFor="description">Description (Optional)</Label>
        <Textarea
          id="description"
          value={formData.description}
          onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
          placeholder="Describe this category"
          className="mt-1"
          rows={3}
        />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label>Icon</Label>
          <Select value={formData.icon} onValueChange={(value) => setFormData(prev => ({ ...prev, icon: value }))}>
            <SelectTrigger className="mt-1">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {ICON_OPTIONS.map((option) => {
                const IconComponent = option.icon;
                return (
                  <SelectItem key={option.value} value={option.value}>
                    <div className="flex items-center gap-2">
                      <IconComponent className="w-4 h-4" />
                      {option.label}
                    </div>
                  </SelectItem>
                );
              })}
            </SelectContent>
          </Select>
        </div>

        <div>
          <Label>Color</Label>
          <Select value={formData.color} onValueChange={(value) => setFormData(prev => ({ ...prev, color: value }))}>
            <SelectTrigger className="mt-1">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {COLOR_OPTIONS.map((option) => (
                <SelectItem key={option.value} value={option.value}>
                  <div className="flex items-center gap-2">
                    <div 
                      className="w-4 h-4 rounded-full" 
                      style={{ backgroundColor: option.color }}
                    />
                    {option.label}
                  </div>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>
    </div>
  );

  return (
    <div className="space-y-4">
      {/* Header with Create Button */}
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold text-white">Article Categories</h3>
          <p className="text-sm text-gray-400">Organize your saved articles with custom categories</p>
        </div>
        <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
          <DialogTrigger asChild>
            <Button 
              size="sm" 
              className="bg-blue-600 hover:bg-blue-700 text-white"
              onClick={resetForm}
            >
              <Plus className="w-4 h-4 mr-2" />
              New Category
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-gray-900 border-gray-700">
            <DialogHeader>
              <DialogTitle className="text-white">Create New Category</DialogTitle>
              <DialogDescription className="text-gray-400">
                Create a custom category to organize your saved articles.
              </DialogDescription>
            </DialogHeader>
            {renderCategoryForm()}
            <DialogFooter>
              <Button
                variant="outline"
                onClick={() => setIsCreateDialogOpen(false)}
                disabled={isLoading}
              >
                Cancel
              </Button>
              <Button
                onClick={handleCreateCategory}
                disabled={isLoading}
                className="bg-blue-600 hover:bg-blue-700"
              >
                {isLoading ? 'Creating...' : 'Create Category'}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {/* Category Filter */}
      <div className="flex items-center gap-2 flex-wrap">
        <Button
          variant={selectedCategoryId === null ? "default" : "outline"}
          size="sm"
          onClick={() => onCategorySelect?.(null)}
          className={selectedCategoryId === null ? "bg-blue-600 hover:bg-blue-700" : ""}
        >
          All Articles
        </Button>
        {categories.map((category) => {
          const IconComponent = getIconComponent(category.icon);
          return (
            <Button
              key={category.id}
              variant={selectedCategoryId === category.id ? "default" : "outline"}
              size="sm"
              onClick={() => onCategorySelect?.(category.id)}
              className={selectedCategoryId === category.id ? "bg-blue-600 hover:bg-blue-700" : ""}
            >
              <IconComponent className="w-4 h-4 mr-2" style={{ color: category.color }} />
              {category.name}
              <Badge variant="secondary" className="ml-2 text-xs">
                {category.article_count}
              </Badge>
            </Button>
          );
        })}
      </div>

      {/* Categories Grid */}
      {categories.length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {categories.map((category) => {
            const IconComponent = getIconComponent(category.icon);
            return (
              <Card key={category.id} className="bg-gray-800/40 backdrop-blur-sm border border-gray-700 hover:border-gray-600 transition-all">
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div 
                        className="p-2 rounded-lg"
                        style={{ backgroundColor: `${category.color}20`, border: `1px solid ${category.color}40` }}
                      >
                        <IconComponent className="w-5 h-5" style={{ color: category.color }} />
                      </div>
                      <div>
                        <CardTitle className="text-sm font-semibold text-white">{category.name}</CardTitle>
                        <Badge variant="secondary" className="text-xs mt-1">
                          {category.article_count} {category.article_count === 1 ? 'article' : 'articles'}
                        </Badge>
                      </div>
                    </div>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                          <MoreHorizontal className="w-4 h-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end" className="bg-gray-800 border-gray-700">
                        <DropdownMenuItem onClick={() => openEditDialog(category)}>
                          <Edit3 className="w-4 h-4 mr-2" />
                          Edit
                        </DropdownMenuItem>
                        <DropdownMenuItem 
                          onClick={() => handleDeleteCategory(category.id)}
                          className="text-red-400 focus:text-red-300"
                        >
                          <Trash2 className="w-4 h-4 mr-2" />
                          Delete
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                </CardHeader>
                {category.description && (
                  <CardContent className="pt-0">
                    <p className="text-sm text-gray-400">{category.description}</p>
                  </CardContent>
                )}
              </Card>
            );
          })}
        </div>
      )}

      {/* Edit Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="bg-gray-900 border-gray-700">
          <DialogHeader>
            <DialogTitle className="text-white">Edit Category</DialogTitle>
            <DialogDescription className="text-gray-400">
              Update the category details.
            </DialogDescription>
          </DialogHeader>
          {renderCategoryForm()}
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                setIsEditDialogOpen(false);
                setEditingCategory(null);
                resetForm();
              }}
              disabled={isLoading}
            >
              Cancel
            </Button>
            <Button
              onClick={handleEditCategory}
              disabled={isLoading}
              className="bg-blue-600 hover:bg-blue-700"
            >
              {isLoading ? 'Updating...' : 'Update Category'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};
