import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
  Eye, 
  AlertTriangle, 
  CheckCircle, 
  XCircle, 
  User, 
  Calendar, 
  Globe, 
  Hash,
  FileText,
  Target
} from 'lucide-react';
import { ScreeningResult, ScreeningMatch } from '../brain/data-contracts';

export interface ScreeningDetailsProps {
  showScreeningDetails: boolean;
  setShowScreeningDetails: (show: boolean) => void;
  selectedScreening: ScreeningResult | null;
  onQualifyMatch: (matchIndex: number, qualification: string, notes: string) => void;
  loading: boolean;
}

const ScreeningDetails: React.FC<ScreeningDetailsProps> = ({
  showScreeningDetails,
  setShowScreeningDetails,
  selectedScreening,
  onQualifyMatch,
  loading
}) => {
  const [selectedMatch, setSelectedMatch] = React.useState<ScreeningMatch | null>(null);
  const [qualification, setQualification] = React.useState<string>('');
  const [qualificationNotes, setQualificationNotes] = React.useState<string>('');

  const getMatchTypeColor = (matchType: string) => {
    switch (matchType) {
      case 'exact': return 'bg-red-500/20 text-red-400 border-red-500/50';
      case 'fuzzy': return 'bg-orange-500/20 text-orange-400 border-orange-500/50';
      case 'alias': return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/50';
      default: return 'bg-gray-500/20 text-gray-400 border-gray-500/50';
    }
  };

  const getRiskColor = (riskLevel: string) => {
    switch (riskLevel) {
      case 'critical': return 'bg-red-500/20 text-red-400 border-red-500/50';
      case 'high': return 'bg-orange-500/20 text-orange-400 border-orange-500/50';
      case 'medium': return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/50';
      case 'low': return 'bg-green-500/20 text-green-400 border-green-500/50';
      default: return 'bg-gray-500/20 text-gray-400 border-gray-500/50';
    }
  };

  const handleQualifyMatch = () => {
    if (selectedMatch && qualification) {
      const matchIndex = selectedScreening?.matches?.findIndex(m => m.id === selectedMatch.id) ?? -1;
      if (matchIndex >= 0) {
        onQualifyMatch(matchIndex, qualification, qualificationNotes);
        setSelectedMatch(null);
        setQualification('');
        setQualificationNotes('');
      }
    }
  };

  return (
    <Dialog open={showScreeningDetails} onOpenChange={setShowScreeningDetails}>
      <DialogContent className="max-w-6xl bg-gray-900 border-gray-800 max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-white flex items-center gap-2">
            <Target className="h-5 w-5" />
            Screening Details & Match Qualification
          </DialogTitle>
        </DialogHeader>
        
        {selectedScreening && (
          <div className="space-y-6">
            {/* Screening Overview */}
            <Card className="bg-slate-800/30 border-slate-700/50">
              <CardHeader>
                <CardTitle className="text-white text-lg">Screening Overview</CardTitle>
              </CardHeader>
              <CardContent className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div>
                  <div className="text-gray-400 text-sm">Risk Level</div>
                  <Badge className={getRiskColor(selectedScreening.risk_level)}>
                    {selectedScreening.risk_level}
                  </Badge>
                </div>
                <div>
                  <div className="text-gray-400 text-sm">Total Matches</div>
                  <div className="text-white font-medium">{selectedScreening.total_matches}</div>
                </div>
                <div>
                  <div className="text-gray-400 text-sm">High Risk Matches</div>
                  <div className="text-red-400 font-medium">{selectedScreening.high_risk_matches}</div>
                </div>
                <div>
                  <div className="text-gray-400 text-sm">Screening Date</div>
                  <div className="text-white">
                    {new Date(selectedScreening.screening_date).toLocaleDateString()}
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Screening Matches */}
            <Card className="bg-slate-800/30 border-slate-700/50">
              <CardHeader>
                <CardTitle className="text-white text-lg flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5" />
                  Screening Matches ({selectedScreening.matches?.length || 0})
                </CardTitle>
              </CardHeader>
              <CardContent>
                {!selectedScreening.matches || selectedScreening.matches.length === 0 ? (
                  <div className="text-center py-8">
                    <CheckCircle className="h-12 w-12 text-green-400 mx-auto mb-4" />
                    <div className="text-gray-400">No matches found</div>
                    <div className="text-sm text-gray-500 mt-2">
                      This customer passed screening with no sanctions list matches
                    </div>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {selectedScreening.matches.map((match, index) => (
                      <Card key={match.id || index} className="bg-slate-700/30 border-slate-600/50">
                        <CardContent className="p-4">
                          <div className="flex items-start justify-between">
                            <div className="flex-1 space-y-3">
                              {/* Match Header */}
                              <div className="flex items-center gap-3">
                                <Badge className={getMatchTypeColor(match.match_type)}>
                                  {match.match_type} match
                                </Badge>
                                <Badge className={getRiskColor(match.risk_level)}>
                                  {match.risk_level} risk
                                </Badge>
                                <div className="text-sm text-gray-400">
                                  {(match.match_score * 100).toFixed(1)}% confidence
                                </div>
                              </div>

                              {/* Match Details */}
                              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div>
                                  <div className="text-gray-400 text-sm">Matched Field</div>
                                  <div className="text-white">{match.matched_field}</div>
                                </div>
                                <div>
                                  <div className="text-gray-400 text-sm">Matched Value</div>
                                  <div className="text-white font-mono bg-slate-800 px-2 py-1 rounded">
                                    {match.matched_value}
                                  </div>
                                </div>
                                {match.original_value && (
                                  <div>
                                    <div className="text-gray-400 text-sm">Original Value</div>
                                    <div className="text-white font-mono bg-slate-800 px-2 py-1 rounded">
                                      {match.original_value}
                                    </div>
                                  </div>
                                )}
                                <div>
                                  <div className="text-gray-400 text-sm">Watchlist Entry ID</div>
                                  <div className="text-white font-mono text-sm">{match.watchlist_entry_id}</div>
                                </div>
                              </div>

                              {/* Match Status */}
                              {match.is_false_positive ? (
                                <Badge className="bg-green-500/20 text-green-400 border-green-500/50">
                                  <CheckCircle className="h-3 w-3 mr-1" />
                                  Marked as False Positive
                                </Badge>
                              ) : (
                                <Badge className="bg-yellow-500/20 text-yellow-400 border-yellow-500/50">
                                  <AlertTriangle className="h-3 w-3 mr-1" />
                                  Requires Qualification
                                </Badge>
                              )}
                            </div>

                            {/* Qualification Actions */}
                            {!match.is_false_positive && (
                              <div className="ml-4">
                                <Button
                                  size="sm"
                                  onClick={() => {
                                    setSelectedMatch(match);
                                    setQualification('');
                                    setQualificationNotes('');
                                  }}
                                  className="bg-blue-500 hover:bg-blue-600 text-white"
                                >
                                  <Eye className="h-3 w-3 mr-1" />
                                  Qualify Match
                                </Button>
                              </div>
                            )}
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        )}

        {/* Match Qualification Modal */}
        <Dialog open={!!selectedMatch} onOpenChange={() => setSelectedMatch(null)}>
          <DialogContent className="max-w-2xl bg-gray-900 border-gray-800">
            <DialogHeader>
              <DialogTitle className="text-white">Qualify Screening Match</DialogTitle>
            </DialogHeader>
            
            {selectedMatch && (
              <div className="space-y-4">
                <div className="p-4 bg-slate-800/50 rounded-lg">
                  <div className="text-white font-medium mb-2">Match Details:</div>
                  <div className="text-sm text-gray-300">
                    <div><strong>Field:</strong> {selectedMatch.matched_field}</div>
                    <div><strong>Value:</strong> {selectedMatch.matched_value}</div>
                    <div><strong>Confidence:</strong> {(selectedMatch.match_score * 100).toFixed(1)}%</div>
                    <div><strong>Risk Level:</strong> {selectedMatch.risk_level}</div>
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-white text-sm font-medium">Qualification Decision</label>
                  <Select value={qualification} onValueChange={setQualification}>
                    <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                      <SelectValue placeholder="Select qualification" />
                    </SelectTrigger>
                    <SelectContent className="bg-slate-800 border-slate-700">
                      <SelectItem value="true_match">True Match - Confirmed Hit</SelectItem>
                      <SelectItem value="false_positive">False Positive - Not a Match</SelectItem>
                      <SelectItem value="pending">Pending - Requires Further Review</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <label className="text-white text-sm font-medium">Qualification Notes</label>
                  <Textarea
                    value={qualificationNotes}
                    onChange={(e) => setQualificationNotes(e.target.value)}
                    className="bg-slate-800 border-slate-700 text-white"
                    rows={3}
                    placeholder="Add notes explaining your qualification decision..."
                  />
                </div>

                <div className="flex justify-end gap-2 pt-4">
                  <Button
                    variant="outline"
                    onClick={() => setSelectedMatch(null)}
                    className="border-slate-600 text-gray-300 hover:bg-slate-800"
                  >
                    Cancel
                  </Button>
                  <Button
                    onClick={handleQualifyMatch}
                    disabled={!qualification || loading}
                    className="bg-blue-500 hover:bg-blue-600 text-white"
                  >
                    {loading ? 'Saving...' : 'Save Qualification'}
                  </Button>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>
      </DialogContent>
    </Dialog>
  );
};

export default ScreeningDetails;
