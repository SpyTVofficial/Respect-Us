import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { 
  AlertTriangle, 
  AlertCircle, 
  Clock, 
  TrendingUp, 
  Eye, 
  Download, 
  CheckCircle, 
  XCircle, 
  Loader2
} from 'lucide-react';
import { CustomerProfile, ScreeningResult, ScreeningAlert } from '../brain/data-contracts';

export interface ScreeningAlertsProps {
  alerts: ScreeningAlert[];
  screeningResults: ScreeningResult[];
  customers: CustomerProfile[];
  onShowScreeningDetails: (result: ScreeningResult) => void;
  isGeneratingPdf: boolean;
  onDownloadIndividualReport: (customerId: number, screeningId: number) => void;
}

const ScreeningAlerts: React.FC<ScreeningAlertsProps> = ({
  alerts,
  screeningResults,
  customers,
  onShowScreeningDetails,
  isGeneratingPdf,
  onDownloadIndividualReport
}) => {
  // Calculate alert statistics
  const alertStats = {
    total: alerts.length,
    critical: alerts.filter(a => a.priority === 'critical').length,
    high: alerts.filter(a => a.priority === 'high').length,
    open: alerts.filter(a => a.status === 'open').length
  };

  // Get screening results that require action (have matches)
  const resultsRequiringAction = screeningResults.filter(r => r.total_matches > 0);

  return (
    <div className="space-y-6">
      {/* Alert Statistics */}
      <div className="grid grid-cols-4 gap-4">
        <Card className="bg-slate-800/30 border-slate-700/50">
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-red-400" />
              <div>
                <div className="text-2xl font-bold text-white">{alertStats.critical}</div>
                <div className="text-sm text-gray-400">Critical</div>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-slate-800/30 border-slate-700/50">
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <AlertCircle className="h-5 w-5 text-orange-400" />
              <div>
                <div className="text-2xl font-bold text-white">{alertStats.high}</div>
                <div className="text-sm text-gray-400">High Priority</div>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-slate-800/30 border-slate-700/50">
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Clock className="h-5 w-5 text-yellow-400" />
              <div>
                <div className="text-2xl font-bold text-white">{alertStats.open}</div>
                <div className="text-sm text-gray-400">Open</div>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-slate-800/30 border-slate-700/50">
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-blue-400" />
              <div>
                <div className="text-2xl font-bold text-white">{resultsRequiringAction.length}</div>
                <div className="text-sm text-gray-400">Requires Review</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
      
      {/* Screening Results Requiring Action */}
      <Card className="bg-slate-800/30 border-slate-700/50">
        <CardHeader>
          <CardTitle className="text-white">Screening Results Requiring Action</CardTitle>
          <CardDescription className="text-gray-400">
            Review and qualify screening hits as match or no-match
          </CardDescription>
        </CardHeader>
        <CardContent>
          {resultsRequiringAction.length === 0 ? (
            <div className="text-center py-12">
              <CheckCircle className="h-12 w-12 text-green-400 mx-auto mb-4" />
              <div className="text-gray-400">No screening results require qualification</div>
              <div className="text-sm text-gray-500 mt-2">
                All screening hits have been reviewed and qualified
              </div>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow className="border-slate-700/50">
                  <TableHead className="text-gray-300">Customer</TableHead>
                  <TableHead className="text-gray-300">Screening Date</TableHead>
                  <TableHead className="text-gray-300">Total Matches</TableHead>
                  <TableHead className="text-gray-300">High Risk Matches</TableHead>
                  <TableHead className="text-gray-300">Status</TableHead>
                  <TableHead className="text-gray-300">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {resultsRequiringAction
                  .sort((a, b) => new Date(b.screening_date || 0).getTime() - new Date(a.screening_date || 0).getTime())
                  .map((result) => {
                    const customer = customers.find(c => c.id === result.customer_id);
                    const requiresReview = result.high_risk_matches > 0;
                    
                    return (
                      <TableRow key={result.id} className="border-slate-700/50 hover:bg-slate-700/30">
                        <TableCell>
                          <div>
                            <div className="text-white font-medium">
                              {customer?.customer_name || 'Unknown Customer'}
                            </div>
                            <div className="text-gray-400 text-sm">
                              {customer?.customer_type || 'Unknown'} • {customer?.country || 'Unknown Country'}
                            </div>
                          </div>
                        </TableCell>
                        <TableCell className="text-gray-300">
                          <div>
                            <div>{new Date(result.screening_date).toLocaleDateString()}</div>
                            <div className="text-xs text-gray-500">
                              {new Date(result.screening_date).toLocaleTimeString()}
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge className="bg-blue-500/20 text-blue-400 border-blue-500/50">
                            {result.total_matches} matches
                          </Badge>
                        </TableCell>
                        <TableCell>
                          {result.high_risk_matches > 0 ? (
                            <Badge className="bg-red-500/20 text-red-400 border-red-500/50">
                              <XCircle className="h-3 w-3 mr-1" />
                              {result.high_risk_matches} high risk
                            </Badge>
                          ) : (
                            <Badge className="bg-yellow-500/20 text-yellow-400 border-yellow-500/50">
                              <AlertCircle className="h-3 w-3 mr-1" />
                              Low risk only
                            </Badge>
                          )}
                        </TableCell>
                        <TableCell>
                          {requiresReview ? (
                            <Badge className="bg-orange-500/20 text-orange-400 border-orange-500/50">
                              <Clock className="h-3 w-3 mr-1" />
                              Requires Review
                            </Badge>
                          ) : (
                            <Badge className="bg-yellow-500/20 text-yellow-400 border-yellow-500/50">
                              <AlertCircle className="h-3 w-3 mr-1" />
                              Low Priority
                            </Badge>
                          )}
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Button
                              size="sm"
                              onClick={() => onShowScreeningDetails(result)}
                              className={requiresReview ? 
                                "bg-red-500 hover:bg-red-600 text-white h-8" :
                                "bg-yellow-500 hover:bg-yellow-600 text-white h-8"
                              }
                            >
                              <Eye className="h-3 w-3 mr-1" />
                              {requiresReview ? 'Review Now' : 'Review'}
                            </Button>
                            {customer && (
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => onDownloadIndividualReport(customer.id!, result.id!)}
                                disabled={isGeneratingPdf}
                                className="border-slate-600 text-gray-300 hover:bg-slate-700 h-8"
                              >
                                {isGeneratingPdf ? (
                                  <Loader2 className="h-3 w-3 mr-1 animate-spin" />
                                ) : (
                                  <Download className="h-3 w-3 mr-1" />
                                )}
                                PDF
                              </Button>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default ScreeningAlerts;
