import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Bookmark, BookmarkCheck, Search, Tag, Trash2, ExternalLink, Plus } from 'lucide-react';
import { useUserGuardContext } from 'app/auth';
import brain from 'brain';
import { UserBookmark, CreateBookmarkRequest } from 'types';
import { toast } from 'sonner';
import { formatDistanceToNow } from 'date-fns';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';

interface Props {
  documentId?: number;
  onBookmarkClick?: (bookmark: UserBookmark) => void;
}

export function BookmarkManager({ documentId, onBookmarkClick }: Props) {
  const { user } = useUserGuardContext();
  const [bookmarks, setBookmarks] = useState<UserBookmark[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [newBookmark, setNewBookmark] = useState({
    title: '',
    description: '',
    tags: [] as string[],
    tagInput: ''
  });
  const [creating, setCreating] = useState(false);

  useEffect(() => {
    loadBookmarks();
  }, []);

  const loadBookmarks = async () => {
    try {
      setLoading(true);
      const response = await brain.get_user_bookmarks();
      
      if (response.ok) {
        const data = await response.json();
        setBookmarks(data);
      }
    } catch (error) {
      console.error('Error loading bookmarks:', error);
      toast.error('Failed to load bookmarks');
    } finally {
      setLoading(false);
    }
  };

  const createBookmark = async () => {
    if (!documentId) {
      toast.error('Document ID is required to create bookmark');
      return;
    }

    if (!newBookmark.title.trim()) {
      toast.error('Please enter a bookmark title');
      return;
    }

    try {
      setCreating(true);
      const request: CreateBookmarkRequest = {
        document_id: documentId,
        title: newBookmark.title.trim(),
        description: newBookmark.description.trim() || undefined,
        tags: newBookmark.tags
      };

      const response = await brain.create_bookmark(request);
      
      if (response.ok) {
        toast.success('Bookmark created successfully');
        setNewBookmark({ title: '', description: '', tags: [], tagInput: '' });
        setShowCreateDialog(false);
        await loadBookmarks();
      } else {
        throw new Error('Failed to create bookmark');
      }
    } catch (error) {
      console.error('Error creating bookmark:', error);
      toast.error('Failed to create bookmark');
    } finally {
      setCreating(false);
    }
  };

  const deleteBookmark = async (bookmarkId: number) => {
    try {
      const response = await brain.delete_bookmark({ bookmark_id: bookmarkId });
      
      if (response.ok) {
        toast.success('Bookmark deleted');
        await loadBookmarks();
      }
    } catch (error) {
      console.error('Error deleting bookmark:', error);
      toast.error('Failed to delete bookmark');
    }
  };

  const addTag = () => {
    const tag = newBookmark.tagInput.trim().toLowerCase();
    if (tag && !newBookmark.tags.includes(tag)) {
      setNewBookmark(prev => ({
        ...prev,
        tags: [...prev.tags, tag],
        tagInput: ''
      }));
    }
  };

  const removeTag = (tagToRemove: string) => {
    setNewBookmark(prev => ({
      ...prev,
      tags: prev.tags.filter(tag => tag !== tagToRemove)
    }));
  };

  const handleTagInputKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      addTag();
    }
  };

  const filteredBookmarks = bookmarks.filter(bookmark => {
    if (!searchTerm) return true;
    
    const searchLower = searchTerm.toLowerCase();
    return (
      bookmark.title.toLowerCase().includes(searchLower) ||
      bookmark.description?.toLowerCase().includes(searchLower) ||
      bookmark.document_title?.toLowerCase().includes(searchLower) ||
      bookmark.tags.some(tag => tag.toLowerCase().includes(searchLower))
    );
  });

  return (
    <div className="w-full space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <BookmarkCheck className="h-5 w-5 text-blue-400" />
          <h3 className="text-lg font-semibold text-gray-100">My Bookmarks</h3>
          <Badge variant="outline" className="border-gray-600">
            {bookmarks.length}
          </Badge>
        </div>
        
        {documentId && (
          <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
            <DialogTrigger asChild>
              <Button className="bg-blue-600 hover:bg-blue-700">
                <Plus className="h-4 w-4 mr-2" />
                Add Bookmark
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-gray-800 border-gray-700 text-gray-100">
              <DialogHeader>
                <DialogTitle className="text-gray-100">Create New Bookmark</DialogTitle>
              </DialogHeader>
              
              <div className="space-y-4">
                <div>
                  <label className="text-sm font-medium text-gray-300 mb-2 block">
                    Bookmark Title *
                  </label>
                  <Input
                    placeholder="Enter bookmark title..."
                    value={newBookmark.title}
                    onChange={(e) => setNewBookmark(prev => ({ ...prev, title: e.target.value }))}
                    className="bg-gray-700 border-gray-600 text-gray-100"
                  />
                </div>

                <div>
                  <label className="text-sm font-medium text-gray-300 mb-2 block">
                    Description (Optional)
                  </label>
                  <Textarea
                    placeholder="Add a description..."
                    value={newBookmark.description}
                    onChange={(e) => setNewBookmark(prev => ({ ...prev, description: e.target.value }))}
                    className="bg-gray-700 border-gray-600 text-gray-100 min-h-[80px]"
                  />
                </div>

                <div>
                  <label className="text-sm font-medium text-gray-300 mb-2 block">
                    Tags
                  </label>
                  <div className="flex gap-2 mb-2">
                    <Input
                      placeholder="Add tag..."
                      value={newBookmark.tagInput}
                      onChange={(e) => setNewBookmark(prev => ({ ...prev, tagInput: e.target.value }))}
                      onKeyPress={handleTagInputKeyPress}
                      className="bg-gray-700 border-gray-600 text-gray-100"
                    />
                    <Button type="button" onClick={addTag} className="bg-gray-600 hover:bg-gray-700">
                      <Tag className="h-4 w-4" />
                    </Button>
                  </div>
                  
                  {newBookmark.tags.length > 0 && (
                    <div className="flex flex-wrap gap-2">
                      {newBookmark.tags.map((tag, index) => (
                        <Badge 
                          key={index} 
                          variant="secondary" 
                          className="bg-blue-600/20 text-blue-300 border-blue-500/30 cursor-pointer"
                          onClick={() => removeTag(tag)}
                        >
                          {tag}
                          <span className="ml-1 text-xs">×</span>
                        </Badge>
                      ))}
                    </div>
                  )}
                </div>

                <div className="flex gap-3 pt-4">
                  <Button 
                    onClick={createBookmark} 
                    disabled={creating || !newBookmark.title.trim()}
                    className="flex-1 bg-blue-600 hover:bg-blue-700"
                  >
                    {creating ? 'Creating...' : 'Create Bookmark'}
                  </Button>
                  <Button 
                    variant="outline" 
                    onClick={() => setShowCreateDialog(false)}
                    className="border-gray-600 text-gray-300 hover:bg-gray-700"
                  >
                    Cancel
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        )}
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
        <Input
          placeholder="Search bookmarks..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="pl-10 bg-gray-700 border-gray-600 text-gray-100 placeholder-gray-400"
        />
      </div>

      {/* Bookmarks List */}
      <div className="space-y-3">
        {loading ? (
          <div className="text-center py-8 text-gray-400">Loading bookmarks...</div>
        ) : filteredBookmarks.length === 0 ? (
          <div className="text-center py-8 text-gray-400">
            {searchTerm ? 'No bookmarks match your search.' : 'No bookmarks yet. Create your first one!'}
          </div>
        ) : (
          filteredBookmarks.map((bookmark) => (
            <Card 
              key={bookmark.id} 
              className="bg-gray-800/30 border-gray-700 hover:bg-gray-800/50 transition-colors cursor-pointer"
              onClick={() => onBookmarkClick?.(bookmark)}
            >
              <CardContent className="p-4">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <Bookmark className="h-4 w-4 text-blue-400" />
                      <h4 className="font-medium text-gray-100">{bookmark.title}</h4>
                    </div>
                    
                    {bookmark.description && (
                      <p className="text-sm text-gray-300 mb-2">{bookmark.description}</p>
                    )}
                    
                    <div className="flex items-center gap-2 text-xs text-gray-400 mb-2">
                      {bookmark.document_title && (
                        <>
                          <span>📄 {bookmark.document_title}</span>
                          {bookmark.document_jurisdiction && (
                            <>
                              <span>•</span>
                              <span>🌍 {bookmark.document_jurisdiction}</span>
                            </>
                          )}
                        </>
                      )}
                    </div>
                    
                    {bookmark.tags.length > 0 && (
                      <div className="flex flex-wrap gap-1 mb-2">
                        {bookmark.tags.map((tag, index) => (
                          <Badge 
                            key={index} 
                            variant="outline" 
                            className="text-xs border-gray-600 text-gray-400"
                          >
                            {tag}
                          </Badge>
                        ))}
                      </div>
                    )}
                    
                    <div className="text-xs text-gray-500">
                      Created {bookmark.created_at && formatDistanceToNow(new Date(bookmark.created_at), { addSuffix: true })}
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={(e) => {
                        e.stopPropagation();
                        // Navigate to document
                        if (onBookmarkClick) {
                          onBookmarkClick(bookmark);
                        }
                      }}
                      className="text-gray-400 hover:text-gray-200"
                    >
                      <ExternalLink className="h-3 w-3" />
                    </Button>
                    
                    {bookmark.user_id === user.sub && (
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={(e) => {
                          e.stopPropagation();
                          if (bookmark.id) deleteBookmark(bookmark.id);
                        }}
                        className="text-red-400 hover:text-red-300"
                      >
                        <Trash2 className="h-3 w-3" />
                      </Button>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
}
