import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Plus, GitBranch, Edit, Copy, Trash2, Play, Users, CheckCircle, Clock, Archive } from 'lucide-react';
import { toast } from 'sonner';
import brain from 'brain';
import type { ClassificationWorkflow, ClassificationWorkflowCreate, AppApisClassificationClassificationTree as ClassificationTree } from '../brain/data-contracts';

const WorkflowsTab: React.FC = () => {
  const [workflows, setWorkflows] = useState<ClassificationWorkflow[]>([]);
  const [classificationTrees, setClassificationTrees] = useState<ClassificationTree[]>([]);
  const [introductionTrees, setIntroductionTrees] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [selectedWorkflow, setSelectedWorkflow] = useState<ClassificationWorkflow | null>(null);
  const [formData, setFormData] = useState<{
    name: string;
    description?: string;
    status: string;
    pricing_tier?: string;
    introduction_tree_ids: string[];
    classification_tree_ids: string[];
    global_tree_orders: Record<string, { order: number; tree_type: string }>;
  }>({
    name: '',
    description: '',
    status: 'draft',
    introduction_tree_ids: [],
    classification_tree_ids: [],
    global_tree_orders: {}
  });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      setLoading(true);
      
      // Load workflows filtered by classification type
      const workflowsResponse = await brain.list_workflows({ workflow_type: 'classification' });
      if (workflowsResponse.ok) {
        const workflowsData = await workflowsResponse.json();
        console.log('📋 Classification workflows response:', workflowsData);
        // API returns direct array, not wrapped in {workflows: []}
        const workflowsArray = Array.isArray(workflowsData) ? workflowsData : [];
        console.log('📋 Classification workflows count:', workflowsArray.length);
        setWorkflows(workflowsArray);
      }
      
      // Load classification trees
      const treesResponse = await brain.list_classification_trees();
      if (treesResponse.ok) {
        const treesData = await treesResponse.json();
        setClassificationTrees(treesData || []);
      }
      
      // Load introduction trees
      const introTreesResponse = await brain.list_introduction_trees();
      if (introTreesResponse.ok) {
        const introTreesData = await introTreesResponse.json();
        setIntroductionTrees(introTreesData || []);
      }
    } catch (error) {
      console.error('Error loading data:', error);
      toast.error('Failed to load workflows');
    } finally {
      setLoading(false);
    }
  };

  const handleCreateWorkflow = async () => {
    console.log('🔄 handleCreateWorkflow started');
    console.log('📋 selectedWorkflow:', selectedWorkflow?.name);
    console.log('📝 formData:', formData);
    
    try {
      // Sort classification trees by their order before sending
      const orderedTreeIds = formData.classification_tree_ids
        .sort((a, b) => (formData.global_tree_orders[a]?.order || 1) - (formData.global_tree_orders[b]?.order || 1));

      // Sort introduction trees by their order
      const orderedIntroTreeIds = formData.introduction_tree_ids
        .sort((a, b) => (formData.global_tree_orders[a]?.order || 1) - (formData.global_tree_orders[b]?.order || 1));

      // Prepare tree orders for backend
      const treeOrders = Object.entries(formData.global_tree_orders).map(([treeId, orderData]) => ({
        tree_id: treeId,
        order: orderData.order,
        tree_type: orderData.tree_type
      }));

      const workflowData = {
        name: formData.name,
        description: formData.description,
        status: formData.status,
        pricing_tier: formData.pricing_tier,
        introduction_tree_ids: orderedIntroTreeIds,
        classification_tree_ids: orderedTreeIds,
        tree_orders: treeOrders
      };
      
      console.log('🚀 Sending API request with data:', workflowData);
      console.log('🎯 API call type:', selectedWorkflow ? 'UPDATE' : 'CREATE');
      
      if (selectedWorkflow) {
        console.log('🔧 Updating workflow with ID:', selectedWorkflow.id);
      }
      
      const response = selectedWorkflow 
        ? await brain.update_workflow({ workflowId: selectedWorkflow.id }, workflowData)
        : await brain.create_workflow(workflowData);
      
      console.log('📡 API response status:', response.status);
      console.log('✅ API response OK:', response.ok);
      
      if (response.ok) {
        console.log('🎉 Success! Closing dialog and refreshing data');
        toast.success(`Workflow ${selectedWorkflow ? 'updated' : 'created'} successfully`);
        setShowCreateDialog(false);
        resetForm();
        loadData();
      } else {
        console.log('❌ API request failed');
        const errorText = await response.text();
        console.log('📝 Error response:', errorText);
        toast.error(`Failed to ${selectedWorkflow ? 'update' : 'create'} workflow`);
      }
    } catch (error) {
      console.error(`💥 Error ${selectedWorkflow ? 'updating' : 'creating'} workflow:`, error);
      toast.error(`Failed to ${selectedWorkflow ? 'update' : 'create'} workflow`);
    }
  };

  const handleEditWorkflow = (workflow: ClassificationWorkflow) => {
    console.log('🔧 handleEditWorkflow called with workflow:', workflow.name);
    console.log('📋 Full workflow data:', workflow);
    
    setSelectedWorkflow(workflow);
    
    // Build global tree orders from existing data
    const treeOrders: Record<string, { order: number; tree_type: string }> = {};
    
    // Add introduction trees to orders
    workflow.introduction_trees?.forEach(tree => {
      treeOrders[tree.id] = { 
        order: tree.global_order || tree.sequence_order, 
        tree_type: 'introduction' 
      };
    });
    
    // Add classification trees to orders
    workflow.classification_trees?.forEach(tree => {
      treeOrders[tree.id] = { 
        order: tree.global_order || tree.sequence_order, 
        tree_type: 'classification' 
      };
    });
    
    const newFormData = {
      name: workflow.name,
      description: workflow.description || '',
      status: workflow.status,
      pricing_tier: workflow.pricing_tier || '',
      introduction_tree_ids: workflow.introduction_trees?.map(t => t.id) || [],
      classification_tree_ids: workflow.classification_trees?.map(t => t.id) || [],
      global_tree_orders: treeOrders
    };
    
    console.log('📝 Setting form data:', newFormData);
    console.log('🎯 Form data name field:', newFormData.name);
    console.log('🔄 Form data status field:', newFormData.status);
    
    setFormData(newFormData);
    
    console.log('🖥️ Opening edit dialog');
    setShowCreateDialog(true);
  };

  const handleDuplicateWorkflow = async (workflow: ClassificationWorkflow) => {
    try {
      const duplicateData = {
        name: `${workflow.name} (Copy)`,
        description: workflow.description,
        status: 'draft',
        pricing_tier: workflow.pricing_tier,
        introduction_tree_ids: workflow.introduction_trees?.map(t => t.id) || [],
        classification_tree_ids: workflow.classification_trees?.map(t => t.id) || [],
        global_tree_orders: {}
      };
      
      const response = await brain.create_workflow(duplicateData);
      if (response.ok) {
        toast.success('Workflow duplicated successfully');
        loadData();
      } else {
        toast.error('Failed to duplicate workflow');
      }
    } catch (error) {
      console.error('Error duplicating workflow:', error);
      toast.error('Failed to duplicate workflow');
    }
  };

  const handleDeleteWorkflow = async (workflowId: string, workflowName: string) => {
    if (!confirm(`Are you sure you want to delete the workflow "${workflowName}"?`)) {
      return;
    }
    
    try {
      const response = await brain.delete_workflow({ workflowId });
      if (response.ok) {
        toast.success(`Workflow "${workflowName}" deleted successfully`);
        loadData();
      } else {
        toast.error('Failed to delete workflow');
      }
    } catch (error) {
      console.error('Error deleting workflow:', error);
      toast.error('Failed to delete workflow');
    }
  };

  const resetForm = () => {
    setSelectedWorkflow(null);
    setFormData({
      name: '',
      description: '',
      status: 'draft',
      introduction_tree_ids: [],
      classification_tree_ids: [],
      global_tree_orders: {}
    });
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'published': return <CheckCircle className="w-4 h-4 text-green-400" />;
      case 'draft': return <Clock className="w-4 h-4 text-yellow-400" />;
      case 'archived': return <Archive className="w-4 h-4 text-gray-400" />;
      default: return <Clock className="w-4 h-4 text-gray-400" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'published': return 'bg-green-600';
      case 'draft': return 'bg-yellow-600';
      case 'archived': return 'bg-gray-600';
      default: return 'bg-gray-600';
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-gray-400">Loading workflows...</div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h3 className="text-xl font-semibold text-white">Classification Workflows</h3>
          <p className="text-gray-400 mt-1">Bundle Introduction Trees with Classification Trees into professional compliance workflows</p>
        </div>
        <Button
          onClick={() => {
            resetForm();
            setShowCreateDialog(true);
          }}
          className="bg-blue-600 hover:bg-blue-700 text-white"
        >
          <Plus className="w-4 h-4 mr-2" />
          Create Workflow
        </Button>
      </div>

      {/* Workflows Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {workflows.length === 0 ? (
          <Card className="bg-gray-800/50 border-gray-700 col-span-full">
            <CardContent className="p-8 text-center">
              <GitBranch className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-400 mb-4">No workflows created yet</p>
              <Button
                onClick={() => {
                  resetForm();
                  setShowCreateDialog(true);
                }}
                className="bg-blue-600 hover:bg-blue-700 text-white"
              >
                <Plus className="w-4 h-4 mr-2" />
                Create Your First Workflow
              </Button>
            </CardContent>
          </Card>
        ) : (
          workflows.map((workflow) => (
            <Card key={workflow.id} className="bg-gray-800/50 border-gray-700 hover:border-gray-600 transition-colors">
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <CardTitle className="text-lg text-white mb-2">{workflow.name}</CardTitle>
                    <div className="flex items-center gap-2 mb-2">
                      {getStatusIcon(workflow.status)}
                      <Badge className={`${getStatusColor(workflow.status)} text-white text-xs`}>
                        {workflow.status.charAt(0).toUpperCase() + workflow.status.slice(1)}
                      </Badge>
                      {workflow.pricing_tier && (
                        <Badge variant="outline" className="text-xs">
                          {workflow.pricing_tier}
                        </Badge>
                      )}
                    </div>
                  </div>
                  <div className="flex gap-1">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleEditWorkflow(workflow)}
                      className="border-gray-600 hover:bg-gray-700"
                    >
                      <Edit className="w-3 h-3" />
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleDuplicateWorkflow(workflow)}
                      className="border-gray-600 hover:bg-gray-700"
                    >
                      <Copy className="w-3 h-3" />
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleDeleteWorkflow(workflow.id, workflow.name)}
                      className="border-red-600 hover:bg-red-700 text-red-400"
                    >
                      <Trash2 className="w-3 h-3" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="pt-0">
                {workflow.description && (
                  <p className="text-gray-400 text-sm mb-4 line-clamp-2">{workflow.description}</p>
                )}
                
                <div className="space-y-3">
                  {workflow.introduction_trees && workflow.introduction_trees.length > 0 && (
                    <div className="flex items-center gap-2 text-sm">
                      <Play className="w-4 h-4 text-blue-400" />
                      <span className="text-gray-300">Introduction Trees:</span>
                      <span className="text-blue-400">
                        {workflow.introduction_trees.map(tree => tree.name).join(', ')}
                      </span>
                    </div>
                  )}
                  
                  <div className="flex items-center gap-2 text-sm">
                    <GitBranch className="w-4 h-4 text-amber-400" />
                    <span className="text-gray-300">Classification Trees:</span>
                    <span className="text-amber-400">{workflow.classification_trees?.length || 0}</span>
                  </div>
                  
                  {workflow.classification_trees && workflow.classification_trees.length > 0 && (
                    <div className="flex flex-wrap gap-1 mt-2">
                      {workflow.classification_trees.slice(0, 3).map((tree) => (
                        <Badge key={tree.id} variant="secondary" className="text-xs">
                          {tree.name}
                        </Badge>
                      ))}
                      {workflow.classification_trees.length > 3 && (
                        <Badge variant="secondary" className="text-xs">
                          +{workflow.classification_trees.length - 3} more
                        </Badge>
                      )}
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>

      {/* Create/Edit Workflow Dialog */}
      <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
        <DialogContent key={selectedWorkflow ? selectedWorkflow.id : 'create'} className="bg-gray-900 border-gray-700 text-white max-w-3xl">
          <DialogHeader>
            <DialogTitle className="text-blue-400">
              {selectedWorkflow ? 'Edit Workflow' : 'Create Classification Workflow'}
            </DialogTitle>
            <DialogDescription className="text-gray-400">
              {selectedWorkflow ? 'Update workflow details' : 'Create a new compliance workflow that bundles Introduction Trees with Classification Trees'}
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-6">
            <div>
              <Label className="text-gray-300">Workflow Name</Label>
              <Input
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="bg-gray-800 border-gray-600 text-white"
                placeholder="Enter workflow name"
              />
            </div>
            
            <div>
              <Label className="text-gray-300">Description</Label>
              <Textarea
                value={formData.description || ''}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                className="bg-gray-800 border-gray-600 text-white min-h-[100px]"
                placeholder="Describe this workflow and its purpose..."
              />
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="text-gray-300">Status</Label>
                <Select 
                  value={formData.status} 
                  onValueChange={(value) => setFormData({ ...formData, status: value })}
                >
                  <SelectTrigger className="bg-gray-800 border-gray-600 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-gray-800 border-gray-600">
                    <SelectItem value="draft">Draft</SelectItem>
                    <SelectItem value="published">Published</SelectItem>
                    <SelectItem value="archived">Archived</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <Label className="text-gray-300">Pricing Tier (Optional)</Label>
                <Input
                  value={formData.pricing_tier || ''}
                  onChange={(e) => setFormData({ ...formData, pricing_tier: e.target.value })}
                  className="bg-gray-800 border-gray-600 text-white"
                  placeholder="e.g., basic, premium, enterprise"
                />
              </div>
            </div>
            
            <div>
              <Label className="text-gray-300">Introduction Trees</Label>
              <div className="mt-2 space-y-3 max-h-40 overflow-y-auto border border-gray-600 rounded-md p-3 bg-gray-800">
                {introductionTrees
                  .map((tree) => (
                    <div key={tree.id} className="flex items-center justify-between space-x-3 p-2 rounded border border-gray-700">
                      <div className="flex items-center space-x-3">
                        <input
                          type="checkbox"
                          id={`intro-tree-${tree.id}`}
                          checked={formData.introduction_tree_ids?.includes(tree.id) || false}
                          onChange={(e) => {
                            const currentIds = formData.introduction_tree_ids || [];
                            const currentOrders = { ...formData.global_tree_orders };
                            if (e.target.checked) {
                              const newIds = [...currentIds, tree.id];
                              currentOrders[tree.id] = { order: newIds.length, tree_type: 'introduction' };
                              setFormData({ 
                                ...formData, 
                                introduction_tree_ids: newIds,
                                global_tree_orders: currentOrders
                              });
                            } else {
                              delete currentOrders[tree.id];
                              setFormData({ 
                                ...formData, 
                                introduction_tree_ids: currentIds.filter(id => id !== tree.id),
                                global_tree_orders: currentOrders
                              });
                            }
                          }}
                          className="rounded"
                        />
                        <label htmlFor={`intro-tree-${tree.id}`} className="text-sm text-gray-300 cursor-pointer">
                          {tree.name}
                        </label>
                      </div>
                      {formData.introduction_tree_ids?.includes(tree.id) && (
                        <div className="flex items-center space-x-2 flex-shrink-0">
                          <Label className="text-xs text-gray-400 whitespace-nowrap">Order:</Label>
                          <input
                            type="number"
                            min="1"
                            value={formData.global_tree_orders[tree.id]?.order || 1}
                            onChange={(e) => {
                              const newOrder = parseInt(e.target.value) || 1;
                              setFormData({
                                ...formData,
                                global_tree_orders: {
                                  ...formData.global_tree_orders,
                                  [tree.id]: { order: newOrder, tree_type: 'introduction' }
                                }
                              });
                            }}
                            className="w-16 px-2 py-1 text-xs bg-gray-700 border border-gray-600 rounded text-white focus:border-blue-500"
                          />
                        </div>
                      )}
                    </div>
                  ))
                }
                {introductionTrees.length === 0 && (
                  <p className="text-gray-400 text-sm text-center py-4">No introduction trees available</p>
                )}
              </div>
            </div>
            
            <div>
              <Label className="text-gray-300">Classification Trees</Label>
              <div className="mt-2 space-y-3 max-h-40 overflow-y-auto border border-gray-600 rounded-md p-3 bg-gray-800">
                {classificationTrees
                  .map((tree) => (
                    <div key={tree.id} className="flex items-center space-x-3">
                      <input
                        type="checkbox"
                        id={`tree-${tree.id}`}
                        checked={formData.classification_tree_ids?.includes(tree.id) || false}
                        onChange={(e) => {
                          const currentIds = formData.classification_tree_ids || [];
                          const currentOrders = { ...formData.global_tree_orders };
                          if (e.target.checked) {
                            const newIds = [...currentIds, tree.id];
                            currentOrders[tree.id] = { order: newIds.length, tree_type: 'classification' };
                            setFormData({ 
                              ...formData, 
                              classification_tree_ids: newIds,
                              global_tree_orders: currentOrders
                            });
                          } else {
                            delete currentOrders[tree.id];
                            setFormData({ 
                              ...formData, 
                              classification_tree_ids: currentIds.filter(id => id !== tree.id),
                              global_tree_orders: currentOrders
                            });
                          }
                        }}
                        className="rounded"
                      />
                      <label htmlFor={`tree-${tree.id}`} className="text-sm text-gray-300 cursor-pointer flex-1">
                        {tree.name}
                      </label>
                      {formData.classification_tree_ids?.includes(tree.id) && (
                        <div className="flex items-center space-x-2">
                          <Label className="text-xs text-gray-400">Order:</Label>
                          <input
                            type="number"
                            min="1"
                            value={formData.global_tree_orders[tree.id]?.order || 1}
                            onChange={(e) => {
                              const newOrder = parseInt(e.target.value) || 1;
                              setFormData({
                                ...formData,
                                global_tree_orders: {
                                  ...formData.global_tree_orders,
                                  [tree.id]: { order: newOrder, tree_type: 'classification' }
                                }
                              });
                            }}
                            className="w-16 px-2 py-1 text-xs bg-gray-700 border border-gray-600 rounded text-white"
                          />
                        </div>
                      )}
                    </div>
                  ))
                }
                {classificationTrees.length === 0 && (
                  <p className="text-gray-400 text-sm text-center py-4">No classification trees available</p>
                )}
              </div>
            </div>
          </div>
          
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                setShowCreateDialog(false);
                resetForm();
              }}
              className="text-gray-300 border-gray-600 hover:bg-gray-700"
            >
              Cancel
            </Button>
            <Button
              disabled={!formData.name.trim()}
              className="bg-blue-600 hover:bg-blue-700 text-white disabled:opacity-50"
              onMouseEnter={() => {
                console.log('💆 Button hover - formData.name:', formData.name);
                console.log('🚫 Button disabled state:', !formData.name.trim());
                console.log('📋 selectedWorkflow:', selectedWorkflow?.name);
                console.log('📝 Full formData:', formData);
                console.log('🔍 formData.name length:', formData.name?.length);
                console.log('🔍 formData.name after trim:', formData.name?.trim());
                console.log('🔍 Is name empty?', !formData.name?.trim());
              }}
              onClick={(e) => {
                console.log('💆 UPDATE WORKFLOW button clicked!');
                console.log('🔍 Button event:', e);
                console.log('📝 Form data at click:', formData);
                console.log('🚫 Button disabled?', !formData.name.trim());
                console.log('🔍 Name field value:', `"${formData.name}"`);
                if (!formData.name.trim()) {
                  console.log('⚠️ Button is disabled - name field empty');
                  e.preventDefault();
                  return false;
                }
                console.log('🚀 Calling handleCreateWorkflow...');
                handleCreateWorkflow();
              }}
            >
              <GitBranch className="w-4 h-4 mr-2" />
              {selectedWorkflow ? 'Update Workflow' : 'Create Workflow'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default WorkflowsTab;
