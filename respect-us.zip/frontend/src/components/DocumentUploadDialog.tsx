import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { Checkbox } from '@/components/ui/checkbox';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Check, ChevronsUpDown, X, ChevronDown, ChevronRight } from 'lucide-react';
import { cn } from 'utils/cn';
import brain from 'brain';
import { toast } from 'sonner';
import { useUserGuardContext } from 'app/auth';
import type { MetadataOptionResponse, DocumentMetadata, BodyUploadDocument } from '../brain/data-contracts';
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from '@/components/ui/command';
import ComboboxMultiSelect from './ComboboxMultiSelect';
import TagInput from './TagInput';

interface DocumentUploadDialogProps {
  open: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

export default function DocumentUploadDialog({ open, onClose, onSuccess }: DocumentUploadDialogProps) {
  const { user } = useUserGuardContext();
  const [file, setFile] = useState<File | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [loadingOptions, setLoadingOptions] = useState(false);
  const [uploadMode, setUploadMode] = useState<'file' | 'url'>('file');
  const [url, setUrl] = useState('');
  
  // Collapsible sections state
  const [showEnhancedSecurity, setShowEnhancedSecurity] = useState(true); // Default to open
  const [showComplianceFields, setShowComplianceFields] = useState(true); // Default to open
  const [showLifecycleFields, setShowLifecycleFields] = useState(true); // Default to open
  const [showOwnershipFields, setShowOwnershipFields] = useState(true); // Default to open
  const [showVersioningFields, setShowVersioningFields] = useState(false);
  const [showPricingFields, setShowPricingFields] = useState(false);
  
  // Dynamic metadata options
  const [jurisdictions, setJurisdictions] = useState<MetadataOptionResponse[]>([]);
  const [regulationTypes, setRegulationTypes] = useState<MetadataOptionResponse[]>([]);
  const [subjects, setSubjects] = useState<MetadataOptionResponse[]>([]);
  
  // Enhanced metadata options
  const [enhancedOptions, setEnhancedOptions] = useState<any>({});
  
  const [metadata, setMetadata] = useState<DocumentMetadata>({
    title: '',
    description: '',
    country_jurisdiction: [],
    regulation_type: [],
    subject: [],
    source_url: '',
    publication_date: '',
    effective_date: '',
    abrogation_date: '',
    legal_status: 'in_force',
    tags: '',
    issuing_authority: '',
    document_url: '',
    version: '1.0',
    badge: [],
    category_ids: [],
    create_sections: true,
    // Pricing fields
    is_premium: false,
    credit_cost: null,
    classification_level: 'Internal',
    security_markings: [],
    access_control_list: [],
    retention_period_months: null,
    document_type: '',
    compliance_framework: '',
    product_category: '',
    geographic_scope: [],
    expiration_date: '',
    approval_chain: [],
    version_major: 1,
    version_minor: 0,
    review_schedule: '',
    next_review_date: '',
    document_owner: '',
    sme_reviewers: [],
    training_required: false
  });

  // Document sections option
  const [shouldCreateSections, setShouldCreateSections] = useState(true);

  // Check if user is admin
  const isAdmin = user?.primaryEmail?.includes('admin') || user?.displayName?.toLowerCase().includes('admin');

  // Load metadata options from API
  const loadMetadataOptions = async () => {
    try {
      setLoadingOptions(true);
      
      // Load basic metadata options
      const [jurisdictionsRes, typesRes, subjectsRes, enhancedRes] = await Promise.all([
        brain.get_metadata_options({ category: 'jurisdiction', active_only: true }),
        brain.get_metadata_options({ category: 'type', active_only: true }),
        brain.get_metadata_options({ category: 'subject', active_only: true }),
        brain.get_enhanced_metadata_options()
      ]);
      
      if (jurisdictionsRes.ok) {
        const data = await jurisdictionsRes.json();
        setJurisdictions(Array.isArray(data) ? data : []);
      } else {
        console.error('Failed to load jurisdictions:', jurisdictionsRes.status);
        setJurisdictions([]);
      }
      
      if (typesRes.ok) {
        const data = await typesRes.json();
        setRegulationTypes(Array.isArray(data) ? data : []);
      } else {
        console.error('Failed to load regulation types:', typesRes.status);
        setRegulationTypes([]);
      }
      
      if (subjectsRes.ok) {
        const data = await subjectsRes.json();
        setSubjects(Array.isArray(data) ? data : []);
      } else {
        console.error('Failed to load subjects:', subjectsRes.status);
        setSubjects([]);
      }
      
      if (enhancedRes.ok) {
        const data = await enhancedRes.json();
        setEnhancedOptions(data || {});
      } else {
        console.error('Failed to load enhanced options:', enhancedRes.status);
        setEnhancedOptions({});
      }
      
    } catch (error) {
      console.error('Error loading metadata options:', error);
      // Ensure safe fallbacks on any error
      setJurisdictions([]);
      setRegulationTypes([]);
      setSubjects([]);
      setEnhancedOptions({});
      toast.error('Failed to load metadata options');
    } finally {
      setLoadingOptions(false);
    }
  };

  // Load metadata options when dialog opens
  useEffect(() => {
    if (open) {
      console.log('Dialog opened, loading metadata options...');
      console.log('Current state - jurisdictions:', jurisdictions.length, 'types:', regulationTypes.length, 'subjects:', subjects.length);
      loadMetadataOptions();
    }
  }, [open]);
  
  // Also load on mount to ensure data is available
  useEffect(() => {
    console.log('Component mounted, preloading metadata options...');
    loadMetadataOptions();
  }, []);

  // Auto-adjust sections preference based on regulation type
  useEffect(() => {
    const structuredTypes = ['Law', 'Regulation', 'Directive', 'Standard', 'Policy'];
    
    // Handle both string and array cases for regulation_type
    const regulationTypes = Array.isArray(metadata.regulation_type) 
      ? metadata.regulation_type 
      : metadata.regulation_type ? [metadata.regulation_type] : [];
    
    const shouldDefault = regulationTypes.some(type => 
      structuredTypes.includes(type)
    );
    
    setShouldCreateSections(shouldDefault);
  }, [metadata.regulation_type]);

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = event.target.files?.[0];
    if (selectedFile) {
      setFile(selectedFile);
      // Auto-populate title from filename if empty
      if (!metadata.title) {
        const nameWithoutExtension = selectedFile.name.replace(/\.[^/.]+$/, "");
        setMetadata(prev => ({ ...prev, title: nameWithoutExtension }));
      }
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validation based on upload mode
    if (uploadMode === 'file') {
      if (!file || !metadata.title.trim()) {
        toast.error('Please select a file and provide a title');
        return;
      }
    } else {
      if (!url.trim() || !metadata.title.trim()) {
        toast.error('Please enter a URL and provide a title');
        return;
      }
    }

    setIsUploading(true);

    try {
      // Create metadata object
      const metadataObject = {
        title: metadata.title,
        description: metadata.description,
        country_jurisdiction: metadata.country_jurisdiction,
        regulation_type: metadata.regulation_type,
        subject: metadata.subject,
        source_url: metadata.source_url,
        publication_date: metadata.publication_date,
        effective_date: metadata.effective_date,
        abrogation_date: metadata.abrogation_date,
        legal_status: metadata.legal_status,
        tags: metadata.tags,
        issuing_authority: metadata.issuing_authority,
        document_url: metadata.document_url,
        version: metadata.version,
        badge: metadata.badge,
        category_ids: metadata.category_ids,
        create_sections: shouldCreateSections,
        // Pricing fields
        is_premium: metadata.is_premium,
        credit_cost: metadata.credit_cost,
        classification_level: metadata.classification_level,
        security_markings: metadata.security_markings,
        access_control_list: metadata.access_control_list,
        retention_period_months: metadata.retention_period_months,
        document_type: metadata.document_type,
        compliance_framework: metadata.compliance_framework,
        product_category: metadata.product_category,
        geographic_scope: metadata.geographic_scope,
        expiration_date: metadata.expiration_date,
        approval_chain: metadata.approval_chain,
        version_major: metadata.version_major,
        version_minor: metadata.version_minor,
        review_schedule: metadata.review_schedule,
        next_review_date: metadata.next_review_date,
        document_owner: metadata.document_owner,
        sme_reviewers: metadata.sme_reviewers,
        training_required: metadata.training_required
      };
      
      let response;
      
      if (uploadMode === 'file') {
        // File upload mode - use correct BodyUploadDocument interface
        const uploadData: BodyUploadDocument = {
          file: file!,
          metadata: JSON.stringify(metadataObject)
        };
        response = await brain.upload_document(uploadData);
      } else {
        // URL upload mode
        const urlRequest = {
          url: url.trim(),
          metadata: {
            ...metadata,
            create_sections: shouldCreateSections,
          }
        };
        response = await brain.upload_url_document(urlRequest);
      }
      
      if (response.ok) {
        toast.success(`Document ${uploadMode === 'file' ? 'uploaded' : 'imported from URL'} successfully! Your document has been submitted for admin review and will be published to the Knowledge Base once approved.`);
        onSuccess();
        handleClose();
      } else {
        const errorData = await response.json().catch(() => ({ detail: `${uploadMode === 'file' ? 'Upload' : 'URL import'} failed` }));
        toast.error(errorData.detail || `Failed to ${uploadMode === 'file' ? 'upload' : 'import'} document. Please try again.`);
      }
      
    } catch (error) {
      console.error(`${uploadMode} error:`, error);
      toast.error(`Failed to ${uploadMode === 'file' ? 'upload' : 'import'} document. Please try again.`);
    } finally {
      setIsUploading(false);
    }
  };

  const handleClose = () => {
    setFile(null);
    setUrl('');
    setUploadMode('file');
    setMetadata({
      title: '',
      description: '',
      country_jurisdiction: [],
      regulation_type: [],
      subject: [],
      source_url: '',
      publication_date: '',
      effective_date: '',
      abrogation_date: '',
      legal_status: 'in_force',
      tags: '',
      issuing_authority: '',
      document_url: '',
      version: '1.0',
      badge: [],
      category_ids: [],
      create_sections: true,
      classification_level: 'Internal',
      security_markings: [],
      access_control_list: [],
      retention_period_months: null,
      document_type: '',
      compliance_framework: '',
      product_category: '',
      geographic_scope: [],
      expiration_date: '',
      approval_chain: [],
      version_major: 1,
      version_minor: 0,
      review_schedule: '',
      next_review_date: '',
      document_owner: '',
      sme_reviewers: [],
      training_required: false
    });
    setIsUploading(false); // Reset uploading state
    onClose();
  };

  // Metadata options with comprehensive safe defaults
  const metadataOptions = {
    country_jurisdiction: Array.isArray(jurisdictions) && jurisdictions.length > 0 ? jurisdictions : [],
    regulation_type: Array.isArray(regulationTypes) && regulationTypes.length > 0 ? regulationTypes : [],
    subject: Array.isArray(subjects) && subjects.length > 0 ? subjects : []
  };
  
  // Debug logging
  console.log('Current loadingOptions:', loadingOptions);
  console.log('Current metadataOptions:', metadataOptions);

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="bg-gray-900 border-gray-700 text-white max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold text-white">Upload Document</DialogTitle>
          <DialogDescription className="text-gray-400">
            Add a new regulatory document to the knowledge base
          </DialogDescription>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-6 mt-4">
          {/* Upload Mode Toggle */}
          <div className="space-y-3">
            <Label className="text-white font-medium">Upload Method</Label>
            <div className="flex space-x-4">
              <Button
                type="button"
                variant={uploadMode === 'file' ? 'default' : 'outline'}
                onClick={() => setUploadMode('file')}
                className={`px-6 py-2 ${uploadMode === 'file' 
                  ? 'bg-blue-600 hover:bg-blue-700 text-white' 
                  : 'bg-gray-800 border-gray-600 text-gray-300 hover:bg-gray-700'
                }`}
              >
                📄 Upload File
              </Button>
              <Button
                type="button"
                variant={uploadMode === 'url' ? 'default' : 'outline'}
                onClick={() => setUploadMode('url')}
                className={`px-6 py-2 ${uploadMode === 'url' 
                  ? 'bg-blue-600 hover:bg-blue-700 text-white' 
                  : 'bg-gray-800 border-gray-600 text-gray-300 hover:bg-gray-700'
                }`}
              >
                🌐 Import from URL
              </Button>
            </div>
          </div>

          {/* File Upload or URL Input */}
          {uploadMode === 'file' ? (
            <div className="space-y-2">
              <Label className="text-white font-medium">Document File *</Label>
              <Input
                type="file"
                accept=".pdf,.doc,.docx,.txt,.html,.rtf"
                onChange={handleFileSelect}
                className="bg-gray-800 border-gray-600 text-white file:bg-blue-600 file:text-white file:border-0 file:rounded file:mr-4 file:py-2 file:px-4"
              />
              {file && (
                <p className="text-sm text-gray-400">
                  Selected: {file.name} ({Math.round(file.size / 1024)} KB)
                </p>
              )}
            </div>
          ) : (
            <div className="space-y-2">
              <Label className="text-white font-medium">Document URL *</Label>
              <Input
                type="url"
                value={url}
                onChange={(e) => setUrl(e.target.value)}
                placeholder="https://example.com/document.html"
                className="bg-gray-800 border-gray-600 text-white"
                required={uploadMode === 'url'}
              />
              <p className="text-sm text-gray-400">
                Enter the URL of a webpage or document to import into the knowledge base
              </p>
            </div>
          )}

          {/* Basic Information */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label className="text-white font-medium">Title *</Label>
              <Input
                value={metadata.title}
                onChange={(e) => setMetadata(prev => ({ ...prev, title: e.target.value }))}
                placeholder="Document title"
                className="bg-gray-800 border-gray-600 text-white"
                required
              />
            </div>
            <div className="space-y-2">
              <Label className="text-white font-medium">Issuing Authority</Label>
              <Input
                value={metadata.issuing_authority}
                onChange={(e) => setMetadata(prev => ({ ...prev, issuing_authority: e.target.value }))}
                placeholder="e.g., BIS, OFAC, EU Commission"
                className="bg-gray-800 border-gray-600 text-white"
              />
            </div>
          </div>

          {/* Description */}
          <div className="space-y-2">
            <Label className="text-white font-medium">Description</Label>
            <Textarea
              value={metadata.description}
              onChange={(e) => setMetadata(prev => ({ ...prev, description: e.target.value }))}
              placeholder="Brief description of the document"
              className="bg-gray-800 border-gray-600 text-white"
              rows={3}
            />
          </div>

          {/* Jurisdiction and Regulation Type - Multi-Select ComboboxMultiSelect */}
          <div className="grid grid-cols-2 gap-4">
            <ComboboxMultiSelect
              options={loadingOptions ? [] : (metadataOptions.country_jurisdiction || [])}
              value={Array.isArray(metadata.country_jurisdiction) ? metadata.country_jurisdiction : 
                (metadata.country_jurisdiction ? [metadata.country_jurisdiction] : [])}
              onChange={(values) => {
                setMetadata(prev => ({
                  ...prev,
                  country_jurisdiction: values // Enable multi-selection for countries
                }));
              }}
              placeholder={loadingOptions ? "Loading..." : "Select jurisdictions"}
              label="Country/Jurisdiction *"
              allowMultiple={true}
              searchPlaceholder="Search jurisdictions..."
            />
            <ComboboxMultiSelect
              options={loadingOptions ? [] : (metadataOptions.regulation_type || [])}
              value={Array.isArray(metadata.regulation_type) ? metadata.regulation_type : 
                (metadata.regulation_type ? [metadata.regulation_type] : [])}
              onChange={(values) => {
                setMetadata(prev => ({
                  ...prev,
                  regulation_type: values // Enable multi-selection for types
                }));
              }}
              placeholder={loadingOptions ? "Loading..." : "Select types"}
              label="Type"
              allowMultiple={true}
              searchPlaceholder="Search regulation types..."
            />
          </div>

          {/* Subject and Version - Multi-Select ComboboxMultiSelect */}
          <div className="grid grid-cols-3 gap-4">
            <ComboboxMultiSelect
              options={loadingOptions ? [] : (metadataOptions.subject || [])}
              value={Array.isArray(metadata.subject) ? metadata.subject :
                (metadata.subject ? [metadata.subject] : [])}
              onChange={(values) => {
                console.log('Subject changed:', values);
                setMetadata(prev => ({
                  ...prev,
                  subject: values // Enable multi-selection for subjects
                }));
              }}
              placeholder={loadingOptions ? "Loading..." : "Select subjects"}
              label="Subject"
              allowMultiple={true}
              searchPlaceholder="Search subjects..."
            />
            <div className="space-y-2">
              <Label className="text-white font-medium">Version</Label>
              <Input
                value={metadata.version}
                onChange={(e) => setMetadata(prev => ({ ...prev, version: e.target.value }))}
                placeholder="e.g., 1.0, 2.1"
                className="bg-gray-800 border-gray-600 text-white"
              />
            </div>
            <div className="space-y-2">
              <Label className="text-white font-medium">Language</Label>
              <Input
                value={metadata.language}
                onChange={(e) => setMetadata(prev => ({ ...prev, language: e.target.value }))}
                placeholder="e.g., English, French"
                className="bg-gray-800 border-gray-600 text-white"
              />
            </div>
          </div>

          {/* Admin Source URL */}
          {isAdmin && (
            <div className="space-y-2">
              <Label className="text-white font-medium">Admin Source URL</Label>
              <Input
                value={metadata.source_url}
                onChange={(e) => setMetadata(prev => ({ ...prev, source_url: e.target.value }))}
                placeholder="Source URL for reference"
                className="bg-gray-800 border-gray-600 text-white"
              />
            </div>
          )}

          {/* Dates */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label className="text-white font-medium">Publication Date</Label>
              <Input
                type="date"
                value={metadata.publication_date}
                onChange={(e) => setMetadata(prev => ({ ...prev, publication_date: e.target.value }))}
                className="bg-gray-800 border-gray-600 text-white"
              />
            </div>
            <div className="space-y-2">
              <Label className="text-white font-medium">Effective Date</Label>
              <Input
                type="date"
                value={metadata.effective_date}
                onChange={(e) => setMetadata(prev => ({ ...prev, effective_date: e.target.value }))}
                className="bg-gray-800 border-gray-600 text-white"
              />
            </div>
            <div className="space-y-2">
              <Label className="text-white font-medium">Abrogation Date</Label>
              <Input
                type="date"
                value={metadata.abrogation_date}
                onChange={(e) => setMetadata(prev => ({ ...prev, abrogation_date: e.target.value }))}
                className="bg-gray-800 border-gray-600 text-white"
              />
            </div>
            <div className="space-y-2">
              <Label className="text-white font-medium">Adoption Date</Label>
              <Input
                type="date"
                value={metadata.adoption_date}
                onChange={(e) => setMetadata(prev => ({ ...prev, adoption_date: e.target.value }))}
                className="bg-gray-800 border-gray-600 text-white"
              />
            </div>
          </div>

          {/* Legal Status and Tags */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label className="text-white font-medium">Legal Status</Label>
              <Select value={metadata.legal_status} onValueChange={(value) => setMetadata(prev => ({ ...prev, legal_status: value }))}>
                <SelectTrigger className="bg-gray-800 border-gray-600 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-gray-800 border-gray-600">
                  <SelectItem value="in_force" className="text-white hover:bg-gray-700">In force</SelectItem>
                  <SelectItem value="proposed" className="text-white hover:bg-gray-700">Proposed</SelectItem>
                  <SelectItem value="voted" className="text-white hover:bg-gray-700">Voted</SelectItem>
                  <SelectItem value="abrogated" className="text-white hover:bg-gray-700">Abrogated</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <TagInput
              value={Array.isArray(metadata.tags) ? metadata.tags : 
                (metadata.tags ? metadata.tags.split(',').map(t => t.trim()).filter(Boolean) : [])}
              onChange={(tags) => {
                setMetadata(prev => ({
                  ...prev,
                  tags: tags // Store as array now
                }));
              }}
              label="Tags"
              placeholder="Add tags like dual-use, military, technology..."
            />
          </div>

          {/* Document Source URL */}
          <div className="space-y-2">
            <Label className="text-white font-medium">Document Source URL</Label>
            <Input
              value={metadata.document_url}
              onChange={(e) => setMetadata(prev => ({ ...prev, document_url: e.target.value }))}
              placeholder="URL to the original document source"
              className="bg-gray-800 border-gray-600 text-white"
            />
          </div>

          {/* Document sections option */}
          <div className="space-y-3">
            <div className="flex items-center space-x-2">
              <Checkbox 
                id="create-sections"
                checked={shouldCreateSections}
                onCheckedChange={(checked) => setShouldCreateSections(checked as boolean)}
              />
              <Label 
                htmlFor="create-sections" 
                className="text-white font-medium cursor-pointer"
              >
                Create structured sections for this document
              </Label>
            </div>
            <p className="text-gray-400 text-sm ml-6">
              Enable this for regulations, laws, and structured documents. 
              Disable for news articles, simple documents, or press releases.
            </p>
          </div>

          {/* Enhanced Security */}
          <Collapsible open={showEnhancedSecurity} onOpenChange={setShowEnhancedSecurity}>
            <CollapsibleTrigger className="flex items-center space-x-2">
              <Badge variant="secondary" className="text-white">
                {showEnhancedSecurity ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
              </Badge>
              <Label className="text-white font-medium">
                Enhanced Security & Access
              </Label>
            </CollapsibleTrigger>
            <CollapsibleContent className="space-y-4 mt-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label className="text-white font-medium">Classification Level</Label>
                  <Select value={metadata.classification_level} onValueChange={(value) => setMetadata(prev => ({ ...prev, classification_level: value }))}>
                    <SelectTrigger className="bg-gray-800 border-gray-600 text-white">
                      <SelectValue placeholder="Select level" />
                    </SelectTrigger>
                    <SelectContent className="bg-gray-800 border-gray-600">
                      {enhancedOptions.classification_levels?.map((level: any) => (
                        <SelectItem key={level.value} value={level.value} className="text-white hover:bg-gray-700">
                          {level.display_name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label className="text-white font-medium">Security Markings</Label>
                  <ComboboxMultiSelect
                    options={enhancedOptions.security_markings || []}
                    value={Array.isArray(metadata.security_markings) ? metadata.security_markings : 
                      (metadata.security_markings ? [metadata.security_markings] : [])}
                    onChange={(values) => {
                      setMetadata(prev => ({
                        ...prev,
                        security_markings: values // Enable multi-selection for security markings
                      }));
                    }}
                    placeholder="Select markings"
                    label="Security Markings"
                    allowMultiple={true}
                    searchPlaceholder="Search security markings..."
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label className="text-white font-medium">Access Control List</Label>
                  <TagInput
                    value={Array.isArray(metadata.access_control_list) ? metadata.access_control_list : 
                      (metadata.access_control_list ? 
                        (typeof metadata.access_control_list === 'string' ? 
                          metadata.access_control_list.split(', ').filter(s => s.trim()) : 
                          []) : [])}
                    onChange={(users) => {
                      setMetadata(prev => ({
                        ...prev,
                        access_control_list: users // Store as array of users
                      }));
                    }}
                    label="Access Control List"
                    placeholder="Add user emails or names..."
                  />
                </div>
                <div className="space-y-2">
                  <Label className="text-white font-medium">Retention Period (months)</Label>
                  <Input
                    type="number"
                    value={metadata.retention_period_months || ''}
                    onChange={(e) => setMetadata(prev => ({ ...prev, retention_period_months: e.target.value ? parseInt(e.target.value) : null }))}
                    placeholder="Number of months"
                    className="bg-gray-800 border-gray-600 text-white"
                  />
                </div>
              </div>
            </CollapsibleContent>
          </Collapsible>

          <Separator className="bg-gray-600" />

          {/* Compliance */}
          <Collapsible open={showComplianceFields} onOpenChange={setShowComplianceFields}>
            <CollapsibleTrigger className="flex items-center space-x-2">
              <Badge variant="secondary" className="text-white">
                {showComplianceFields ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
              </Badge>
              <Label className="text-white font-medium">
                Compliance & Product
              </Label>
            </CollapsibleTrigger>
            <CollapsibleContent className="space-y-4 mt-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label className="text-white font-medium">Document Type</Label>
                  <ComboboxMultiSelect
                    options={enhancedOptions.document_types || []}
                    value={Array.isArray(metadata.document_type) ? metadata.document_type : 
                      (metadata.document_type ? [metadata.document_type] : [])}
                    onChange={(values) => {
                      setMetadata(prev => ({
                        ...prev,
                        document_type: values
                      }));
                    }}
                    placeholder="Select types"
                    label="Document Type"
                    allowMultiple={true}
                    searchPlaceholder="Search document types..."
                  />
                </div>
                <div className="space-y-2">
                  <Label className="text-white font-medium">Compliance Framework</Label>
                  <ComboboxMultiSelect
                    options={enhancedOptions.compliance_frameworks || []}
                    value={Array.isArray(metadata.compliance_framework) ? metadata.compliance_framework : 
                      (metadata.compliance_framework ? [metadata.compliance_framework] : [])}
                    onChange={(values) => {
                      setMetadata(prev => ({
                        ...prev,
                        compliance_framework: values
                      }));
                    }}
                    placeholder="Select frameworks"
                    label="Compliance Framework"
                    allowMultiple={true}
                    searchPlaceholder="Search compliance frameworks..."
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <Label className="text-white font-medium">Product Category</Label>
                  <ComboboxMultiSelect
                    options={enhancedOptions.product_categories || []}
                    value={Array.isArray(metadata.product_category) ? metadata.product_category : 
                      (metadata.product_category ? [metadata.product_category] : [])}
                    onChange={(values) => {
                      setMetadata(prev => ({
                        ...prev,
                        product_category: values
                      }));
                    }}
                    placeholder="Select categories"
                    label="Product Category"
                    allowMultiple={true}
                    searchPlaceholder="Search product categories..."
                  />
                </div>
                <div className="space-y-2">
                  <Label className="text-white font-medium">Geographic Scope</Label>
                  <ComboboxMultiSelect
                    options={enhancedOptions.geographic_scopes || []}
                    value={Array.isArray(metadata.geographic_scope) ? metadata.geographic_scope : 
                      (metadata.geographic_scope ? [metadata.geographic_scope] : [])}
                    onChange={(values) => {
                      setMetadata(prev => ({
                        ...prev,
                        geographic_scope: values
                      }));
                    }}
                    placeholder="Select scope"
                    label="Geographic Scope"
                    allowMultiple={true}
                    searchPlaceholder="Search geographic scopes..."
                  />
                </div>
              </div>
            </CollapsibleContent>
          </Collapsible>

          <Separator className="bg-gray-600" />

          {/* Lifecycle */}
          <Collapsible open={showLifecycleFields} onOpenChange={setShowLifecycleFields}>
            <CollapsibleTrigger className="flex items-center space-x-2">
              <Badge variant="secondary" className="text-white">
                {showLifecycleFields ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
              </Badge>
              <Label className="text-white font-medium">
                Lifecycle & Versioning
              </Label>
            </CollapsibleTrigger>
            <CollapsibleContent className="space-y-4 mt-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label className="text-white font-medium">Version Major</Label>
                  <Input
                    type="number"
                    value={metadata.version_major}
                    onChange={(e) => setMetadata(prev => ({ ...prev, version_major: e.target.value ? parseInt(e.target.value) : 1 }))}
                    placeholder="Major version number"
                    className="bg-gray-800 border-gray-600 text-white"
                  />
                </div>
                <div className="space-y-2">
                  <Label className="text-white font-medium">Version Minor</Label>
                  <Input
                    type="number"
                    value={metadata.version_minor}
                    onChange={(e) => setMetadata(prev => ({ ...prev, version_minor: e.target.value ? parseInt(e.target.value) : 0 }))}
                    placeholder="Minor version number"
                    className="bg-gray-800 border-gray-600 text-white"
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label className="text-white font-medium">Review Schedule</Label>
                  <Select value={metadata.review_schedule} onValueChange={(value) => setMetadata(prev => ({ ...prev, review_schedule: value }))}>
                    <SelectTrigger className="bg-gray-800 border-gray-600 text-white">
                      <SelectValue placeholder="Select schedule" />
                    </SelectTrigger>
                    <SelectContent className="bg-gray-800 border-gray-600">
                      {enhancedOptions.review_schedules?.map((schedule: any) => (
                        <SelectItem key={schedule.value} value={schedule.value} className="text-white hover:bg-gray-700">
                          {schedule.display_name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label className="text-white font-medium">Next Review Date</Label>
                  <Input
                    type="date"
                    value={metadata.next_review_date}
                    onChange={(e) => setMetadata(prev => ({ ...prev, next_review_date: e.target.value }))}
                    className="bg-gray-800 border-gray-600 text-white"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label className="text-white font-medium">Expiration Date</Label>
                <Input
                  type="date"
                  value={metadata.expiration_date}
                  onChange={(e) => setMetadata(prev => ({ ...prev, expiration_date: e.target.value }))}
                  className="bg-gray-800 border-gray-600 text-white"
                />
              </div>
            </CollapsibleContent>
          </Collapsible>

          <Separator className="bg-gray-600" />

          {/* Ownership */}
          <Collapsible open={showOwnershipFields} onOpenChange={setShowOwnershipFields}>
            <CollapsibleTrigger className="flex items-center space-x-2">
              <Badge variant="secondary" className="text-white">
                {showOwnershipFields ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
              </Badge>
              <Label className="text-white font-medium">
                Ownership & Training
              </Label>
            </CollapsibleTrigger>
            <CollapsibleContent className="space-y-4 mt-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label className="text-white font-medium">Document Owner</Label>
                  <Input
                    value={metadata.document_owner}
                    onChange={(e) => setMetadata(prev => ({ ...prev, document_owner: e.target.value }))}
                    placeholder="Document owner name"
                    className="bg-gray-800 border-gray-600 text-white"
                  />
                </div>
                <div className="space-y-2">
                  <Label className="text-white font-medium">SME Reviewers</Label>
                  <Input
                    value={metadata.sme_reviewers.join(', ')}
                    onChange={(e) => setMetadata(prev => ({ ...prev, sme_reviewers: e.target.value.split(', ').filter(s => s.trim()) }))}
                    placeholder="Comma-separated list of SME reviewers"
                    className="bg-gray-800 border-gray-600 text-white"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <div className="flex items-center space-x-2">
                  <Checkbox 
                    id="training-required"
                    checked={metadata.training_required}
                    onCheckedChange={(checked) => setMetadata(prev => ({ ...prev, training_required: checked as boolean }))}
                  />
                  <Label 
                    htmlFor="training-required" 
                    className="text-white font-medium cursor-pointer"
                  >
                    Training Required
                  </Label>
                </div>
                <p className="text-gray-400 text-sm ml-6">
                  Check if this document requires special training to understand or implement.
                </p>
              </div>
            </CollapsibleContent>
          </Collapsible>

          <Separator className="bg-gray-600" />

          {/* Versioning */}
          <Collapsible open={showVersioningFields} onOpenChange={setShowVersioningFields}>
            <CollapsibleTrigger className="flex items-center space-x-2">
              <Badge variant="secondary" className="text-white">
                {showVersioningFields ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
              </Badge>
              <Label className="text-white font-medium">
                Versioning
              </Label>
            </CollapsibleTrigger>
            <CollapsibleContent className="space-y-4 mt-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label className="text-white font-medium">Version Major</Label>
                  <Input
                    type="number"
                    value={metadata.version_major}
                    onChange={(e) => setMetadata(prev => ({ ...prev, version_major: e.target.value ? parseInt(e.target.value) : 1 }))}
                    placeholder="Major version number"
                    className="bg-gray-800 border-gray-600 text-white"
                  />
                </div>
                <div className="space-y-2">
                  <Label className="text-white font-medium">Version Minor</Label>
                  <Input
                    type="number"
                    value={metadata.version_minor}
                    onChange={(e) => setMetadata(prev => ({ ...prev, version_minor: e.target.value ? parseInt(e.target.value) : 0 }))}
                    placeholder="Minor version number"
                    className="bg-gray-800 border-gray-600 text-white"
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label className="text-white font-medium">Review Schedule</Label>
                  <Select value={metadata.review_schedule} onValueChange={(value) => setMetadata(prev => ({ ...prev, review_schedule: value }))}>
                    <SelectTrigger className="bg-gray-800 border-gray-600 text-white">
                      <SelectValue placeholder="Select schedule" />
                    </SelectTrigger>
                    <SelectContent className="bg-gray-800 border-gray-600">
                      {enhancedOptions.review_schedules?.map((schedule: any) => (
                        <SelectItem key={schedule.value} value={schedule.value} className="text-white hover:bg-gray-700">
                          {schedule.display_name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label className="text-white font-medium">Next Review Date</Label>
                  <Input
                    type="date"
                    value={metadata.next_review_date}
                    onChange={(e) => setMetadata(prev => ({ ...prev, next_review_date: e.target.value }))}
                    className="bg-gray-800 border-gray-600 text-white"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label className="text-white font-medium">Expiration Date</Label>
                <Input
                  type="date"
                  value={metadata.expiration_date}
                  onChange={(e) => setMetadata(prev => ({ ...prev, expiration_date: e.target.value }))}
                  className="bg-gray-800 border-gray-600 text-white"
                />
              </div>
            </CollapsibleContent>
          </Collapsible>

          <Separator className="bg-gray-600" />

          {/* Pricing */}
          <Collapsible open={showPricingFields} onOpenChange={setShowPricingFields}>
            <CollapsibleTrigger className="flex items-center space-x-2">
              <Badge variant="secondary" className="text-white">
                {showPricingFields ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
              </Badge>
              <Label className="text-white font-medium">
                💰 Document Pricing
              </Label>
            </CollapsibleTrigger>
            <CollapsibleContent className="space-y-4 mt-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="is-premium"
                      checked={metadata.is_premium}
                      onCheckedChange={(checked) => setMetadata(prev => ({ ...prev, is_premium: checked as boolean }))}
                    />
                    <Label 
                      htmlFor="is-premium" 
                      className="text-white font-medium cursor-pointer"
                    >
                      Premium Document
                    </Label>
                  </div>
                  <p className="text-gray-400 text-sm ml-6">
                    Mark as premium if this document requires credits to access.
                  </p>
                </div>
                <div className="space-y-2">
                  <Label className="text-white font-medium">Credit Cost</Label>
                  <Input
                    type="number"
                    min="0"
                    value={metadata.credit_cost || ''}
                    onChange={(e) => setMetadata(prev => ({ ...prev, credit_cost: e.target.value ? parseInt(e.target.value) : null }))}
                    placeholder="Credits required to access"
                    className="bg-gray-800 border-gray-600 text-white"
                    disabled={!metadata.is_premium}
                  />
                  <p className="text-gray-400 text-sm">
                    {metadata.is_premium ? 'Number of credits users need to access this document' : 'Enable premium to set credit cost'}
                  </p>
                </div>
              </div>
              {metadata.is_premium && metadata.credit_cost && (
                <div className="bg-blue-900/30 border border-blue-600/50 rounded-lg p-4">
                  <div className="flex items-center space-x-2 text-blue-300">
                    <span className="text-sm font-medium">💡 Pricing Preview</span>
                  </div>
                  <p className="text-blue-200 text-sm mt-1">
                    Users will need <strong>{metadata.credit_cost} credits</strong> to access this document.
                  </p>
                </div>
              )}
            </CollapsibleContent>
          </Collapsible>

          <Separator className="bg-gray-600" />

          {/* Submit Buttons */}
          <div className="flex justify-end space-x-3 pt-4">
            <Button 
              type="submit" 
              disabled={
                (uploadMode === 'file' && (!file || !metadata.title.trim())) ||
                (uploadMode === 'url' && (!url.trim() || !metadata.title.trim())) ||
                isUploading
              } 
              className="bg-blue-600 hover:bg-blue-700 disabled:opacity-50"
            >
              {isUploading ? 'Processing...' : `${uploadMode === 'file' ? 'Upload' : 'Import'} Document`}
            </Button>
            <Button type="button" variant="outline" onClick={handleClose} disabled={isUploading}>
              Cancel
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
