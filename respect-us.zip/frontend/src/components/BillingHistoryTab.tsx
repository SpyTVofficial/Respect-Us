
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Receipt, Download, Filter, Search, Calendar, CreditCard, FileText, TrendingUp, DollarSign, AlertCircle, Eye, RefreshCw
} from 'lucide-react';
import { toast } from 'sonner';
import brain from 'brain';

interface Invoice {
  id: string;
  invoice_number: string;
  amount_total: number;
  amount_net?: number;
  amount_vat?: number;
  currency: string;
  status: string;
  invoice_date: string;
  due_date: string;
  description: string;
  pdf_url?: string;
  created_at: string;
  updated_at: string;
  company_name?: string;
}

interface BillingHistory {
  invoices: Invoice[];
  total_count: number;
  total_amount_paid: number;
  total_amount_pending: number;
  currency: string;
}

interface PaymentMethod {
  id: string;
  type: string;
  last_four?: string;
  brand?: string;
  is_default: boolean;
}

interface UsageAnalytics {
  total_usage: number;
  monthly_breakdown: Array<{
    month: string;
    usage: number;
    cost: number;
  }>;
  module_breakdown: Array<{
    module_name: string;
    usage_count: number;
    total_cost: number;
  }>;
}

interface UserCompanyContext {
  company_id: string | null;
  company_name: string | null;
  permissions: any;
}

interface BillingHistoryTabProps {
  userCompanyContext: UserCompanyContext | null;
}

export default function BillingHistoryTab({ userCompanyContext }: BillingHistoryTabProps) {
  const [billingHistory, setBillingHistory] = useState<BillingHistory | null>(null);
  const [paymentMethods, setPaymentMethods] = useState<PaymentMethod[]>([]);
  const [usageAnalytics, setUsageAnalytics] = useState<UsageAnalytics | null>(null);
  const [selectedInvoice, setSelectedInvoice] = useState<Invoice | null>(null);
  const [showInvoiceDialog, setShowInvoiceDialog] = useState(false);
  const [showPaymentMethodDialog, setShowPaymentMethodDialog] = useState(false);
  const [loading, setLoading] = useState(false);
  const [filters, setFilters] = useState({
    status: 'all',
    dateRange: 'all',
    searchTerm: ''
  });

  // Load billing data
  useEffect(() => {
    loadBillingData();
  }, [userCompanyContext?.company_id]);

  const loadBillingData = async () => {
    try {
      setLoading(true);
      const [historyResponse, methodsResponse, analyticsResponse] = await Promise.all([
        brain.get_invoice_history({
          company_id: userCompanyContext?.company_id ? parseInt(userCompanyContext.company_id) : undefined,
          status: filters.status !== 'all' ? filters.status : undefined,
          limit: 50,
          offset: 0
        }),
        brain.get_payment_methods({
          company_id: userCompanyContext?.company_id ? parseInt(userCompanyContext.company_id) : undefined
        }),
        brain.get_usage_analytics({
          company_id: userCompanyContext?.company_id ? parseInt(userCompanyContext.company_id) : undefined
        })
      ]);
      
      if (historyResponse.ok) {
        const historyData = await historyResponse.json();
        setBillingHistory(historyData);
      }
      
      if (methodsResponse.ok) {
        const methodsData = await methodsResponse.json();
        setPaymentMethods(methodsData.payment_methods || []);
      }
      
      if (analyticsResponse.ok) {
        const analyticsData = await analyticsResponse.json();
        setUsageAnalytics(analyticsData);
      }
    } catch (error) {
      console.error('Error loading billing data:', error);
      toast.error('Failed to load billing data');
    } finally {
      setLoading(false);
    }
  };

  const handleDownloadInvoice = async (invoiceId: string) => {
    try {
      const response = await brain.download_invoice({ invoice_id: parseInt(invoiceId) });
      if (response.ok) {
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `invoice-${invoiceId}.pdf`;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        document.body.removeChild(a);
        toast.success('Invoice downloaded successfully');
      } else {
        toast.error('Failed to download invoice');
      }
    } catch (error) {
      console.error('Error downloading invoice:', error);
      toast.error('Error downloading invoice');
    }
  };

  const getStatusBadgeColor = (status: string) => {
    switch (status) {
      case 'paid': return 'bg-green-500/20 text-green-300 border-green-500/30';
      case 'pending': return 'bg-yellow-500/20 text-yellow-300 border-yellow-500/30';
      case 'overdue': return 'bg-red-500/20 text-red-300 border-red-500/30';
      case 'cancelled': return 'bg-gray-500/20 text-gray-300 border-gray-500/30';
      default: return 'bg-gray-500/20 text-gray-300 border-gray-500/30';
    }
  };

  const formatCurrency = (amount: number, currency: string = 'EUR') => {
    return new Intl.NumberFormat('en-EU', {
      style: 'currency',
      currency: currency
    }).format(amount);
  };

  const formatPriceWithVATNotice = (amount: number, currency: string = 'EUR') => {
    return `${formatCurrency(amount, currency)} + VAT if applicable`;
  };

  const filteredInvoices = billingHistory?.invoices.filter(invoice => {
    const matchesStatus = filters.status === 'all' || invoice.status === filters.status;
    const matchesSearch = !filters.searchTerm || 
      invoice.invoice_number.toLowerCase().includes(filters.searchTerm.toLowerCase()) ||
      invoice.description.toLowerCase().includes(filters.searchTerm.toLowerCase());
    return matchesStatus && matchesSearch;
  }) || [];

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="text-center py-12">
          <RefreshCw className="w-8 h-8 text-gray-600 animate-spin mx-auto mb-4" />
          <p className="text-gray-400">Loading billing information...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Billing Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="bg-gray-800/50 border-gray-700">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">Total Paid</p>
                <p className="text-2xl font-bold text-green-400">
                  {formatCurrency(billingHistory?.total_amount_paid || 0, billingHistory?.currency)}
                </p>
              </div>
              <DollarSign className="w-8 h-8 text-green-400" />
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-gray-800/50 border-gray-700">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">Pending</p>
                <p className="text-2xl font-bold text-yellow-400">
                  {formatCurrency(billingHistory?.total_amount_pending || 0, billingHistory?.currency)}
                </p>
              </div>
              <AlertCircle className="w-8 h-8 text-yellow-400" />
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-gray-800/50 border-gray-700">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">Total Invoices</p>
                <p className="text-2xl font-bold text-white">
                  {billingHistory?.total_count || 0}
                </p>
              </div>
              <Receipt className="w-8 h-8 text-blue-400" />
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-gray-800/50 border-gray-700">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">Payment Methods</p>
                <p className="text-2xl font-bold text-white">
                  {paymentMethods.length}
                </p>
              </div>
              <CreditCard className="w-8 h-8 text-purple-400" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Usage Analytics */}
      {usageAnalytics && (
        <Card className="bg-gray-800/50 border-gray-700">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-blue-500/20 rounded-lg">
                  <TrendingUp className="w-5 h-5 text-blue-400" />
                </div>
                <div>
                  <CardTitle className="text-white">Usage Analytics</CardTitle>
                  <CardDescription className="text-gray-400">
                    Track your usage patterns and costs
                  </CardDescription>
                </div>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Module Breakdown */}
              <div className="space-y-4">
                <h4 className="text-sm font-medium text-gray-300 uppercase tracking-wide">Module Usage</h4>
                <div className="space-y-3">
                  {usageAnalytics.module_breakdown.map((module, index) => (
                    <div key={index} className="flex items-center justify-between p-3 bg-gray-700/50 rounded-lg">
                      <div>
                        <p className="text-white font-medium">{module.module_name}</p>
                        <p className="text-gray-400 text-sm">{module.usage_count} uses</p>
                      </div>
                      <div className="text-right">
                        <p className="text-white font-semibold">
                          {formatCurrency(module.total_cost)}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
              
              {/* Monthly Breakdown */}
              <div className="space-y-4">
                <h4 className="text-sm font-medium text-gray-300 uppercase tracking-wide">Monthly Breakdown</h4>
                <div className="space-y-3">
                  {usageAnalytics.monthly_breakdown.slice(-6).map((month, index) => (
                    <div key={index} className="flex items-center justify-between p-3 bg-gray-700/50 rounded-lg">
                      <div>
                        <p className="text-white font-medium">{month.month}</p>
                        <p className="text-gray-400 text-sm">{month.usage} uses</p>
                      </div>
                      <div className="text-right">
                        <p className="text-white font-semibold">
                          {formatCurrency(month.cost)}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Invoice History */}
      <Card className="bg-gray-800/50 border-gray-700">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-green-500/20 rounded-lg">
                <Receipt className="w-5 h-5 text-green-400" />
              </div>
              <div>
                <CardTitle className="text-white">Invoice History</CardTitle>
                <CardDescription className="text-gray-400">
                  Complete history of all billing transactions
                </CardDescription>
              </div>
            </div>
            <Button 
              onClick={() => setShowPaymentMethodDialog(true)}
              className="bg-purple-600 hover:bg-purple-700 text-white"
            >
              <CreditCard className="w-4 h-4 mr-2" />
              Manage Payment Methods
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {/* Filters */}
          <div className="flex flex-col sm:flex-row gap-4 mb-6">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  placeholder="Search invoices..."
                  value={filters.searchTerm}
                  onChange={(e) => setFilters(prev => ({ ...prev, searchTerm: e.target.value }))}
                  className="pl-10 bg-gray-700 border-gray-600 text-white"
                />
              </div>
            </div>
            <Select value={filters.status} onValueChange={(value) => setFilters(prev => ({ ...prev, status: value }))}>
              <SelectTrigger className="w-40 bg-gray-700 border-gray-600 text-white">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-gray-800 border-gray-700">
                <SelectItem value="all" className="text-gray-300">All Status</SelectItem>
                <SelectItem value="paid" className="text-gray-300">Paid</SelectItem>
                <SelectItem value="pending" className="text-gray-300">Pending</SelectItem>
                <SelectItem value="overdue" className="text-gray-300">Overdue</SelectItem>
                <SelectItem value="cancelled" className="text-gray-300">Cancelled</SelectItem>
              </SelectContent>
            </Select>
            <Button 
              onClick={loadBillingData}
              variant="outline"
              className="border-gray-600 text-gray-300 hover:bg-gray-700"
            >
              <RefreshCw className="w-4 h-4 mr-2" />
              Refresh
            </Button>
          </div>

          {/* Invoice Table */}
          {filteredInvoices.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow className="border-gray-700">
                  <TableHead className="text-gray-300">Invoice #</TableHead>
                  <TableHead className="text-gray-300">Description</TableHead>
                  <TableHead className="text-gray-300">Amount</TableHead>
                  <TableHead className="text-gray-300">Status</TableHead>
                  <TableHead className="text-gray-300">Date</TableHead>
                  <TableHead className="text-gray-300 w-[100px]">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredInvoices.map((invoice) => (
                  <TableRow key={invoice.id} className="border-gray-700">
                    <TableCell className="text-white font-medium">
                      {invoice.invoice_number}
                    </TableCell>
                    <TableCell className="text-gray-300">
                      {invoice.description}
                    </TableCell>
                    <TableCell className="text-white font-semibold">
                      {invoice.amount_net ? 
                        formatPriceWithVATNotice(invoice.amount_net, invoice.currency) :
                        formatCurrency(invoice.amount_total, invoice.currency)
                      }
                    </TableCell>
                    <TableCell>
                      <Badge className={getStatusBadgeColor(invoice.status)}>
                        {invoice.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-gray-400">
                      {new Date(invoice.invoice_date).toLocaleDateString()}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center space-x-2">
                        <Button
                          onClick={() => {
                            setSelectedInvoice(invoice);
                            setShowInvoiceDialog(true);
                          }}
                          variant="ghost"
                          size="sm"
                          className="h-8 w-8 p-0 text-gray-400 hover:text-white"
                        >
                          <Eye className="h-4 w-4" />
                        </Button>
                        {invoice.pdf_url && (
                          <Button
                            onClick={() => handleDownloadInvoice(invoice.id)}
                            variant="ghost"
                            size="sm"
                            className="h-8 w-8 p-0 text-gray-400 hover:text-white"
                          >
                            <Download className="h-4 w-4" />
                          </Button>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <div className="text-center py-12">
              <Receipt className="w-16 h-16 text-gray-600 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-white mb-2">No Invoices Found</h3>
              <p className="text-gray-400">
                {filters.status !== 'all' || filters.searchTerm ? 
                  'No invoices match your current filters.' : 
                  'No billing history available yet.'}
              </p>
              {(filters.status !== 'all' || filters.searchTerm) && (
                <Button 
                  onClick={() => setFilters({ status: 'all', dateRange: 'all', searchTerm: '' })}
                  variant="outline"
                  className="mt-4 border-gray-600 text-gray-300 hover:bg-gray-700"
                >
                  Clear Filters
                </Button>
              )}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Invoice Detail Dialog */}
      <Dialog open={showInvoiceDialog} onOpenChange={setShowInvoiceDialog}>
        <DialogContent className="bg-gray-800 border-gray-700 text-white max-w-2xl">
          <DialogHeader>
            <DialogTitle>Invoice Details</DialogTitle>
            <DialogDescription className="text-gray-400">
              Complete information for invoice {selectedInvoice?.invoice_number}
            </DialogDescription>
          </DialogHeader>
          {selectedInvoice && (
            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div>
                    <Label className="text-gray-300">Invoice Number</Label>
                    <p className="text-white font-semibold">{selectedInvoice.invoice_number}</p>
                  </div>
                  <div>
                    <Label className="text-gray-300">Amount (Net)</Label>
                    <p className="text-white font-semibold text-lg">
                      {selectedInvoice.amount_net ? 
                        formatPriceWithVATNotice(selectedInvoice.amount_net, selectedInvoice.currency) :
                        formatCurrency(selectedInvoice.amount_total, selectedInvoice.currency)
                      }
                    </p>
                  </div>
                  <div>
                    <Label className="text-gray-300">Status</Label>
                    <Badge className={getStatusBadgeColor(selectedInvoice.status)}>
                      {selectedInvoice.status}
                    </Badge>
                  </div>
                </div>
                <div className="space-y-4">
                  <div>
                    <Label className="text-gray-300">Invoice Date</Label>
                    <p className="text-white">{new Date(selectedInvoice.invoice_date).toLocaleDateString()}</p>
                  </div>
                  <div>
                    <Label className="text-gray-300">Due Date</Label>
                    <p className="text-white">{new Date(selectedInvoice.due_date).toLocaleDateString()}</p>
                  </div>
                  {selectedInvoice.amount_vat && selectedInvoice.amount_vat > 0 && (
                    <div>
                      <Label className="text-gray-300">VAT Amount</Label>
                      <p className="text-white font-semibold">
                        {formatCurrency(selectedInvoice.amount_vat, selectedInvoice.currency)}
                      </p>
                    </div>
                  )}
                  {(selectedInvoice.amount_net || selectedInvoice.amount_vat) && (
                    <div>
                      <Label className="text-gray-300">Total Amount</Label>
                      <p className="text-white font-semibold text-lg text-blue-400">
                        {formatCurrency(selectedInvoice.amount_total, selectedInvoice.currency)}
                      </p>
                    </div>
                  )}
                  {selectedInvoice.company_name && (
                    <div>
                      <Label className="text-gray-300">Company</Label>
                      <p className="text-white">{selectedInvoice.company_name}</p>
                    </div>
                  )}
                </div>
              </div>
              <div>
                <Label className="text-gray-300">Description</Label>
                <p className="text-white mt-2 p-3 bg-gray-700/50 rounded-lg">
                  {selectedInvoice.description}
                </p>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => setShowInvoiceDialog(false)}
              className="border-gray-600 text-gray-300 hover:bg-gray-700"
            >
              Close
            </Button>
            {selectedInvoice?.pdf_url && (
              <Button 
                onClick={() => handleDownloadInvoice(selectedInvoice.id)}
                className="bg-blue-600 hover:bg-blue-700 text-white"
              >
                <Download className="w-4 h-4 mr-2" />
                Download PDF
              </Button>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Payment Methods Dialog */}
      <Dialog open={showPaymentMethodDialog} onOpenChange={setShowPaymentMethodDialog}>
        <DialogContent className="bg-gray-800 border-gray-700 text-white">
          <DialogHeader>
            <DialogTitle>Payment Methods</DialogTitle>
            <DialogDescription className="text-gray-400">
              Manage your payment methods for billing
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            {paymentMethods.length > 0 ? (
              paymentMethods.map((method) => (
                <div key={method.id} className="flex items-center justify-between p-4 bg-gray-700/50 rounded-lg border border-gray-600">
                  <div className="flex items-center space-x-3">
                    <CreditCard className="w-5 h-5 text-blue-400" />
                    <div>
                      <p className="text-white font-medium">
                        {method.brand} ending in {method.last_four}
                      </p>
                      <p className="text-gray-400 text-sm">{method.type}</p>
                    </div>
                  </div>
                  {method.is_default && (
                    <Badge className="bg-green-500/20 text-green-400 border-green-500/30">
                      Default
                    </Badge>
                  )}
                </div>
              ))
            ) : (
              <div className="text-center py-8">
                <CreditCard className="w-12 h-12 text-gray-600 mx-auto mb-4" />
                <p className="text-gray-400">No payment methods configured</p>
              </div>
            )}
          </div>
          <DialogFooter>
            <Button 
              onClick={() => setShowPaymentMethodDialog(false)}
              className="bg-gray-600 hover:bg-gray-700 text-white"
            >
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
