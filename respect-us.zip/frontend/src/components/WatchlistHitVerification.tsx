
import React, { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { AlertTriangle, CheckCircle, XCircle, Eye, Calendar, MapPin, User, Building, Hash, Shield, FileText, Globe, Clock } from 'lucide-react';
import { toast } from 'sonner';

interface WatchlistEntry {
  id: number;
  list_name: string;
  entity_name: string;
  aliases: string[];
  entity_type: string;
  country: string | null;
  date_of_birth: string | null;
  identification_numbers: string[];
  sanctions_program: string;
  listing_date: string | null;
  last_updated: string;
  is_active: boolean;
  source_url: string | null;
  raw_data: any;
}

interface WatchlistSearchResult {
  watchlist_entry: WatchlistEntry;
  match_score: number;
  match_type: string;
  matched_field: string;
  risk_assessment: string;
}

export interface Props {
  result: WatchlistSearchResult;
  onVerificationComplete: () => void;
}

export const WatchlistHitVerification = ({ result, onVerificationComplete }: Props) => {
  const [isOpen, setIsOpen] = useState(false);
  const [decision, setDecision] = useState<string>('');
  const [reason, setReason] = useState('');
  const [notes, setNotes] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleVerification = async () => {
    if (!decision) {
      toast.error('Please select a verification decision');
      return;
    }

    setIsSubmitting(true);
    try {
      // For now, just store the verification locally and show success
      // In a real implementation, you would save this to a verification log
      const verification = {
        watchlist_entry_id: result.watchlist_entry.id,
        entity_name: result.watchlist_entry.entity_name,
        verification_decision: decision,
        verification_reason: reason || undefined,
        verification_notes: notes || undefined,
        verified_at: new Date().toISOString(),
        match_score: result.match_score,
        match_type: result.match_type
      };

      // Store in localStorage for demo purposes
      const existingVerifications = JSON.parse(localStorage.getItem('watchlist_verifications') || '[]');
      existingVerifications.push(verification);
      localStorage.setItem('watchlist_verifications', JSON.stringify(existingVerifications));
      
      toast.success(`Hit marked as ${decision === 'match' ? 'True Match' : 'False Positive'}`);
      setIsOpen(false);
      onVerificationComplete();
      
      // Reset form
      setDecision('');
      setReason('');
      setNotes('');
    } catch (error) {
      console.error('Hit verification failed:', error);
      toast.error('Failed to verify hit. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const getRiskBadgeColor = (riskLevel: string) => {
    switch (riskLevel.toLowerCase()) {
      case 'critical': return 'bg-red-600 text-white';
      case 'high': return 'bg-orange-500 text-white';
      case 'medium': return 'bg-yellow-500 text-black';
      case 'low': return 'bg-green-500 text-white';
      default: return 'bg-gray-500 text-white';
    }
  };

  const formatMatchScore = (score: number) => {
    return `${Math.round(score * 100)}%`;
  };

  const getMatchTypeDisplay = (type: string) => {
    switch (type.toLowerCase()) {
      case 'exact': return { label: 'Exact Match', color: 'bg-red-100 text-red-800' };
      case 'fuzzy': return { label: 'Fuzzy Match', color: 'bg-orange-100 text-orange-800' };
      case 'alias': return { label: 'Alias Match', color: 'bg-blue-100 text-blue-800' };
      case 'partial': return { label: 'Partial Match', color: 'bg-purple-100 text-purple-800' };
      default: return { label: type, color: 'bg-gray-100 text-gray-800' };
    }
  };

  const formatDate = (dateStr: string | null | undefined) => {
    if (!dateStr) return 'N/A';
    try {
      return new Date(dateStr).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
      });
    } catch {
      return dateStr;
    }
  };

  const matchTypeInfo = getMatchTypeDisplay(result.match_type);
  const entry = result.watchlist_entry;

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button 
          variant="outline" 
          size="sm" 
          className="h-8 px-2 text-xs bg-amber-50 border-amber-200 hover:bg-amber-100 text-amber-800"
        >
          <Eye className="h-3 w-3 mr-1" />
          Verify Hit
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-5xl max-h-[90vh] overflow-y-auto bg-gray-900 border-gray-700">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold text-white flex items-center gap-2">
            <AlertTriangle className="h-5 w-5 text-amber-500" />
            Watchlist Hit Verification
          </DialogTitle>
          <DialogDescription className="text-gray-300">
            Review this watchlist entry and determine if this is a relevant sanctions match for your investigation.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* Match Overview */}
          <Card className="bg-gray-800 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white flex items-center justify-between">
                <span>Match Overview</span>
                <div className="flex gap-2">
                  <Badge className={matchTypeInfo.color}>
                    {matchTypeInfo.label}
                  </Badge>
                </div>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-3 gap-4">
                <div>
                  <Label className="text-gray-300 text-xs">Match Score</Label>
                  <div className="text-2xl font-bold text-white">
                    {formatMatchScore(result.match_score)}
                  </div>
                </div>
                <div>
                  <Label className="text-gray-300 text-xs">Matched Field</Label>
                  <div className="text-lg font-medium text-white capitalize">
                    {result.matched_field.replace('_', ' ')}
                  </div>
                </div>
                <div>
                  <Label className="text-gray-300 text-xs">Watchlist</Label>
                  <div className="text-lg font-medium text-white">
                    {entry.list_name}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Comprehensive Sanctions Details */}
          <Card className="bg-gray-800 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Shield className="h-5 w-5" />
                Sanctions Entry Details
              </CardTitle>
              <CardDescription className="text-gray-300">
                Complete information from official sanctions databases
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Entity Identity Information */}
              <div>
                <h4 className="text-white font-semibold mb-3 flex items-center gap-2">
                  <User className="h-4 w-4" />
                  Entity Identity
                </h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label className="text-gray-300 text-xs">Listed Name</Label>
                    <div className="text-white font-medium">
                      {entry.entity_name}
                    </div>
                  </div>
                  
                  <div>
                    <Label className="text-gray-300 text-xs">Entity Type</Label>
                    <div className="text-white font-medium capitalize">
                      {entry.entity_type}
                    </div>
                  </div>

                  {entry.country && (
                    <div>
                      <Label className="text-gray-300 text-xs flex items-center gap-1">
                        <MapPin className="h-3 w-3" />
                        Country
                      </Label>
                      <div className="text-white font-medium">
                        {entry.country}
                      </div>
                    </div>
                  )}

                  {entry.date_of_birth && (
                    <div>
                      <Label className="text-gray-300 text-xs flex items-center gap-1">
                        <Calendar className="h-3 w-3" />
                        Date of Birth
                      </Label>
                      <div className="text-white font-medium">
                        {formatDate(entry.date_of_birth)}
                      </div>
                    </div>
                  )}
                </div>
              </div>

              <Separator className="bg-gray-600" />

              {/* Sanctions Program Information */}
              <div>
                <h4 className="text-white font-semibold mb-3 flex items-center gap-2">
                  <Globe className="h-4 w-4" />
                  Sanctions Program
                </h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label className="text-gray-300 text-xs">Sanctions Program</Label>
                    <div className="text-white font-medium">
                      {entry.sanctions_program}
                    </div>
                  </div>

                  <div>
                    <Label className="text-gray-300 text-xs">Source List</Label>
                    <div className="text-white font-medium">
                      {entry.list_name}
                    </div>
                  </div>

                  {entry.listing_date && (
                    <div>
                      <Label className="text-gray-300 text-xs flex items-center gap-1">
                        <Clock className="h-3 w-3" />
                        Listing Date
                      </Label>
                      <div className="text-white font-medium">
                        {formatDate(entry.listing_date)}
                      </div>
                    </div>
                  )}

                  <div>
                    <Label className="text-gray-300 text-xs flex items-center gap-1">
                      <Clock className="h-3 w-3" />
                      Last Updated
                    </Label>
                    <div className="text-white font-medium">
                      {formatDate(entry.last_updated)}
                    </div>
                  </div>
                </div>
              </div>

              <Separator className="bg-gray-600" />

              {/* Identification Information */}
              {entry.identification_numbers && entry.identification_numbers.length > 0 && (
                <>
                  <div>
                    <h4 className="text-white font-semibold mb-3 flex items-center gap-2">
                      <Hash className="h-4 w-4" />
                      Identification Numbers
                    </h4>
                    <div className="grid grid-cols-1 gap-2">
                      <div>
                        <Label className="text-gray-300 text-xs">ID Numbers</Label>
                        <div className="text-white font-medium">
                          {entry.identification_numbers.join(', ')}
                        </div>
                      </div>
                    </div>
                  </div>
                  <Separator className="bg-gray-600" />
                </>
              )}

              {/* Known Aliases */}
              {entry.aliases && entry.aliases.length > 0 && (
                <>
                  <div>
                    <h4 className="text-white font-semibold mb-3">Known Aliases & Alternative Names</h4>
                    <div className="flex flex-wrap gap-2">
                      {entry.aliases.map((alias: string, index: number) => (
                        <Badge key={index} variant="secondary" className="text-xs bg-blue-100 text-blue-800">
                          {alias}
                        </Badge>
                      ))}
                    </div>
                  </div>
                  <Separator className="bg-gray-600" />
                </>
              )}

              {/* Raw Data */}
              {entry.raw_data && (
                <div>
                  <h4 className="text-white font-semibold mb-3 flex items-center gap-2">
                    <FileText className="h-4 w-4" />
                    Additional Details
                  </h4>
                  <div className="bg-gray-700 p-3 rounded border text-xs">
                    <pre className="text-gray-300 whitespace-pre-wrap overflow-x-auto">
                      {JSON.stringify(entry.raw_data, null, 2)}
                    </pre>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Verification Decision */}
          <Card className="bg-gray-800 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white">Verification Decision</CardTitle>
              <CardDescription className="text-gray-300">
                Based on your review, is this entry relevant to your investigation?
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label className="text-gray-300 text-sm font-medium">Decision *</Label>
                <Select value={decision} onValueChange={setDecision}>
                  <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                    <SelectValue placeholder="Select verification decision" />
                  </SelectTrigger>
                  <SelectContent className="bg-gray-700 border-gray-600">
                    <SelectItem value="match" className="text-white hover:bg-gray-600">
                      <div className="flex items-center gap-2">
                        <CheckCircle className="h-4 w-4 text-red-500" />
                        Relevant Match - This entry is relevant to my investigation
                      </div>
                    </SelectItem>
                    <SelectItem value="no_match" className="text-white hover:bg-gray-600">
                      <div className="flex items-center gap-2">
                        <XCircle className="h-4 w-4 text-green-500" />
                        Not Relevant - This entry is not related to my investigation
                      </div>
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label className="text-gray-300 text-sm font-medium">Reason</Label>
                <Select value={reason} onValueChange={setReason}>
                  <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                    <SelectValue placeholder="Select reason (optional)" />
                  </SelectTrigger>
                  <SelectContent className="bg-gray-700 border-gray-600">
                    {decision === 'match' ? (
                      <>
                        <SelectItem value="exact_name_match" className="text-white hover:bg-gray-600">
                          Exact name match
                        </SelectItem>
                        <SelectItem value="alias_confirmed" className="text-white hover:bg-gray-600">
                          Alias confirmed
                        </SelectItem>
                        <SelectItem value="additional_identifiers" className="text-white hover:bg-gray-600">
                          Additional identifiers match
                        </SelectItem>
                        <SelectItem value="manual_verification" className="text-white hover:bg-gray-600">
                          Manual verification confirmed
                        </SelectItem>
                      </>
                    ) : (
                      <>
                        <SelectItem value="different_person" className="text-white hover:bg-gray-600">
                          Different person with similar name
                        </SelectItem>
                        <SelectItem value="spelling_variation" className="text-white hover:bg-gray-600">
                          Common spelling variation
                        </SelectItem>
                        <SelectItem value="different_jurisdiction" className="text-white hover:bg-gray-600">
                          Different jurisdiction/location
                        </SelectItem>
                        <SelectItem value="insufficient_information" className="text-white hover:bg-gray-600">
                          Insufficient information to confirm
                        </SelectItem>
                        <SelectItem value="not_related" className="text-white hover:bg-gray-600">
                          Not related to current investigation
                        </SelectItem>
                      </>
                    )}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label className="text-gray-300 text-sm font-medium">Additional Notes</Label>
                <Textarea
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Add any additional notes about this verification decision..."
                  className="bg-gray-700 border-gray-600 text-white placeholder-gray-400"
                  rows={3}
                />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Action Buttons */}
        <div className="flex justify-end gap-3 pt-4 border-t border-gray-700">
          <Button 
            variant="outline" 
            onClick={() => setIsOpen(false)}
            className="border-gray-600 text-gray-300 hover:bg-gray-700"
          >
            Cancel
          </Button>
          <Button 
            onClick={handleVerification}
            disabled={!decision || isSubmitting}
            className={`${decision === 'match' 
              ? 'bg-red-600 hover:bg-red-700' 
              : decision === 'no_match' 
              ? 'bg-green-600 hover:bg-green-700'
              : 'bg-blue-600 hover:bg-blue-700'
            } text-white`}
          >
            {isSubmitting ? 'Submitting...' : `Submit ${decision === 'match' ? 'Relevant Match' : decision === 'no_match' ? 'Not Relevant' : 'Decision'}`}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};
