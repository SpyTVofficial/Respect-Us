import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, PieChart, Pie, Cell } from 'recharts';
import { AlertTriangle, TrendingUp, TrendingDown, Minus, Bell, Settings, Eye, EyeOff } from 'lucide-react';
import brain from 'brain';
import { toast } from 'sonner';

interface UsageSummary {
  total_credits_consumed: number;
  total_actions_performed: number;
  most_used_component: string;
  most_used_action: string;
  daily_average: number;
  weekly_trend: string;
  current_balance: number;
  lifetime_consumed: number;
}

interface ComponentUsage {
  component_name: string;
  action_name: string;
  total_usage: number;
  total_cost: number;
  usage_count: number;
  avg_cost_per_action: number;
  last_used: string;
  percentage_of_total: number;
}

interface DailyUsagePoint {
  date: string;
  credits_consumed: number;
  actions_performed: number;
  components_used: string[];
}

interface SpendingAlert {
  id: number;
  user_id: string;
  alert_type: string;
  threshold_value: number;
  current_value: number;
  message: string;
  is_active: boolean;
  created_at: string;
  triggered_at?: string;
}

interface RealTimeMetrics {
  credits_consumed_today: number;
  actions_performed_today: number;
  active_sessions: number;
  peak_usage_hour: string;
  current_burn_rate: number;
  projected_daily_consumption: number;
}

interface AlertThreshold {
  alert_type: string;
  threshold_value: number;
  is_enabled: boolean;
}

export const UsageDashboard: React.FC = () => {
  const [summary, setSummary] = useState<UsageSummary | null>(null);
  const [componentUsage, setComponentUsage] = useState<ComponentUsage[]>([]);
  const [dailyChart, setDailyChart] = useState<DailyUsagePoint[]>([]);
  const [realTimeMetrics, setRealTimeMetrics] = useState<RealTimeMetrics | null>(null);
  const [alerts, setAlerts] = useState<SpendingAlert[]>([]);
  const [alertThresholds, setAlertThresholds] = useState<AlertThreshold[]>([
    { alert_type: 'low_balance', threshold_value: 100, is_enabled: true },
    { alert_type: 'daily_limit', threshold_value: 500, is_enabled: false }
  ]);
  const [loading, setLoading] = useState(true);
  const [showAlertSettings, setShowAlertSettings] = useState(false);
  const [selectedPeriod, setSelectedPeriod] = useState('30');

  useEffect(() => {
    loadDashboardData();
    // Set up real-time updates every 30 seconds
    const interval = setInterval(loadRealTimeData, 30000);
    return () => clearInterval(interval);
  }, [selectedPeriod]);

  const loadDashboardData = async () => {
    try {
      setLoading(true);
      const [summaryRes, componentsRes, chartRes, alertsRes, metricsRes] = await Promise.all([
        brain.get_user_usage_summary(),
        brain.get_component_usage_breakdown({ days: parseInt(selectedPeriod) }),
        brain.get_daily_usage_chart({ days: parseInt(selectedPeriod) }),
        brain.get_active_spending_alerts(),
        brain.get_real_time_metrics()
      ]);

      setSummary(await summaryRes.json());
      setComponentUsage(await componentsRes.json());
      setDailyChart(await chartRes.json());
      setAlerts(await alertsRes.json());
      setRealTimeMetrics(await metricsRes.json());
    } catch (error) {
      console.error('Error loading dashboard data:', error);
      toast.error('Failed to load usage dashboard');
    } finally {
      setLoading(false);
    }
  };

  const loadRealTimeData = async () => {
    try {
      const [metricsRes, alertsRes] = await Promise.all([
        brain.get_real_time_metrics(),
        brain.get_active_spending_alerts()
      ]);
      setRealTimeMetrics(await metricsRes.json());
      setAlerts(await alertsRes.json());
    } catch (error) {
      console.error('Error loading real-time data:', error);
    }
  };

  const configureAlerts = async () => {
    try {
      await brain.configure_spending_alerts(alertThresholds);
      toast.success('Alert settings saved successfully');
      setShowAlertSettings(false);
    } catch (error) {
      console.error('Error configuring alerts:', error);
      toast.error('Failed to save alert settings');
    }
  };

  const dismissAlert = async (alertId: number) => {
    try {
      await brain.dismiss_spending_alert({ alert_id: alertId });
      setAlerts(alerts.filter(alert => alert.id !== alertId));
      toast.success('Alert dismissed');
    } catch (error) {
      console.error('Error dismissing alert:', error);
      toast.error('Failed to dismiss alert');
    }
  };

  const checkAlerts = async () => {
    try {
      await brain.check_and_trigger_alerts();
      loadRealTimeData(); // Refresh alerts
      toast.success('Alerts checked');
    } catch (error) {
      console.error('Error checking alerts:', error);
    }
  };

  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case 'increasing': return <TrendingUp className="h-4 w-4 text-red-500" />;
      case 'decreasing': return <TrendingDown className="h-4 w-4 text-green-500" />;
      default: return <Minus className="h-4 w-4 text-gray-500" />;
    }
  };

  const getTrendColor = (trend: string) => {
    switch (trend) {
      case 'increasing': return 'text-red-600';
      case 'decreasing': return 'text-green-600';
      default: return 'text-gray-600';
    }
  };

  const getAlertTypeLabel = (type: string) => {
    switch (type) {
      case 'low_balance': return 'Low Balance';
      case 'daily_limit': return 'Daily Limit';
      case 'weekly_limit': return 'Weekly Limit';
      case 'high_usage': return 'High Usage';
      default: return type;
    }
  };

  const CHART_COLORS = ['#8884d8', '#82ca9d', '#ffc658', '#ff7300', '#8dd1e1'];

  if (loading && !summary) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading usage dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Active Alerts */}
      {alerts.length > 0 && (
        <div className="space-y-2">
          {alerts.map((alert) => (
            <Alert key={alert.id} className="border-orange-200 bg-orange-50">
              <AlertTriangle className="h-4 w-4 text-orange-600" />
              <AlertDescription className="flex justify-between items-center">
                <span className="text-orange-800">{alert.message}</span>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  onClick={() => dismissAlert(alert.id)}
                  className="text-orange-600 hover:text-orange-800"
                >
                  Dismiss
                </Button>
              </AlertDescription>
            </Alert>
          ))}
        </div>
      )}

      {/* Real-Time Metrics Row */}
      {realTimeMetrics && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Today's Usage</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-blue-600">
                {realTimeMetrics.credits_consumed_today}
              </div>
              <p className="text-xs text-gray-600">
                {realTimeMetrics.actions_performed_today} actions
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Burn Rate</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-purple-600">
                {realTimeMetrics.current_burn_rate.toFixed(1)}
              </div>
              <p className="text-xs text-gray-600">credits/hour</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Peak Hour</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600">
                {realTimeMetrics.peak_usage_hour}
              </div>
              <p className="text-xs text-gray-600">most active</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Projected Daily</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-orange-600">
                {realTimeMetrics.projected_daily_consumption}
              </div>
              <p className="text-xs text-gray-600">estimated credits</p>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Main Dashboard */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Usage Summary */}
        <Card className="lg:col-span-2">
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle>Usage Overview</CardTitle>
              <CardDescription>Your credit consumption summary</CardDescription>
            </div>
            <div className="flex items-center gap-2">
              <Button 
                variant="outline" 
                size="sm" 
                onClick={() => setShowAlertSettings(!showAlertSettings)}
              >
                <Bell className="h-4 w-4 mr-1" />
                Alerts
              </Button>
              <Button variant="outline" size="sm" onClick={checkAlerts}>
                <Eye className="h-4 w-4 mr-1" />
                Check
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            {summary && (
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-600">
                    {summary.current_balance.toLocaleString()}
                  </div>
                  <p className="text-sm text-gray-600">Current Balance</p>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-purple-600">
                    {summary.total_credits_consumed.toLocaleString()}
                  </div>
                  <p className="text-sm text-gray-600">Credits Used</p>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-green-600">
                    {summary.total_actions_performed.toLocaleString()}
                  </div>
                  <p className="text-sm text-gray-600">Actions</p>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-orange-600">
                    {summary.daily_average.toFixed(1)}
                  </div>
                  <p className="text-sm text-gray-600">Daily Avg</p>
                </div>
              </div>
            )}

            {summary && (
              <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div>
                    <p className="text-sm font-medium">Most Used Component</p>
                    <p className="text-lg font-semibold">{summary.most_used_component}</p>
                  </div>
                </div>
                <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div>
                    <p className="text-sm font-medium">Weekly Trend</p>
                    <div className="flex items-center gap-2">
                      {getTrendIcon(summary.weekly_trend)}
                      <span className={`font-semibold ${getTrendColor(summary.weekly_trend)}`}>
                        {summary.weekly_trend.charAt(0).toUpperCase() + summary.weekly_trend.slice(1)}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Alert Settings Panel */}
        {showAlertSettings && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Settings className="h-5 w-5" />
                Alert Settings
              </CardTitle>
              <CardDescription>Configure spending alerts</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {alertThresholds.map((threshold, index) => (
                <div key={threshold.alert_type} className="space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="text-sm font-medium">
                      {getAlertTypeLabel(threshold.alert_type)}
                    </label>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => {
                        const updated = [...alertThresholds];
                        updated[index].is_enabled = !updated[index].is_enabled;
                        setAlertThresholds(updated);
                      }}
                    >
                      {threshold.is_enabled ? 
                        <Eye className="h-4 w-4 text-green-600" /> : 
                        <EyeOff className="h-4 w-4 text-gray-400" />
                      }
                    </Button>
                  </div>
                  <input
                    type="number"
                    value={threshold.threshold_value}
                    onChange={(e) => {
                      const updated = [...alertThresholds];
                      updated[index].threshold_value = parseInt(e.target.value) || 0;
                      setAlertThresholds(updated);
                    }}
                    className="w-full px-3 py-2 border rounded-md"
                    placeholder="Threshold value"
                    disabled={!threshold.is_enabled}
                  />
                </div>
              ))}
              <Button onClick={configureAlerts} className="w-full">
                Save Alert Settings
              </Button>
            </CardContent>
          </Card>
        )}

        {/* Component Usage Breakdown */}
        {!showAlertSettings && (
          <Card>
            <CardHeader>
              <CardTitle>Component Usage</CardTitle>
              <CardDescription>Usage by module and action</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3 max-h-80 overflow-y-auto">
                {componentUsage.slice(0, 8).map((usage) => (
                  <div key={`${usage.component_name}-${usage.action_name}`} className="flex justify-between items-center p-2 bg-gray-50 rounded">
                    <div>
                      <p className="text-sm font-medium">{usage.component_name}</p>
                      <p className="text-xs text-gray-600">{usage.action_name}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-semibold">{usage.total_cost} credits</p>
                      <p className="text-xs text-gray-600">{usage.usage_count} uses</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Charts Section */}
      <Tabs value={selectedPeriod} onValueChange={setSelectedPeriod} className="w-full">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-semibold">Usage Analytics</h3>
          <TabsList>
            <TabsTrigger value="7">7 Days</TabsTrigger>
            <TabsTrigger value="30">30 Days</TabsTrigger>
            <TabsTrigger value="90">90 Days</TabsTrigger>
          </TabsList>
        </div>

        <TabsContent value={selectedPeriod} className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Daily Usage Chart */}
            <Card>
              <CardHeader>
                <CardTitle>Daily Credit Usage</CardTitle>
                <CardDescription>Credits consumed over time</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={dailyChart}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis 
                      dataKey="date" 
                      tick={{ fontSize: 12 }}
                      tickFormatter={(value) => new Date(value).toLocaleDateString()}
                    />
                    <YAxis tick={{ fontSize: 12 }} />
                    <Tooltip 
                      labelFormatter={(value) => new Date(value).toLocaleDateString()}
                      formatter={(value, name) => [value, name === 'credits_consumed' ? 'Credits' : 'Actions']}
                    />
                    <Line 
                      type="monotone" 
                      dataKey="credits_consumed" 
                      stroke="#8884d8" 
                      strokeWidth={2}
                      dot={{ r: 4 }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* Component Usage Pie Chart */}
            <Card>
              <CardHeader>
                <CardTitle>Usage by Component</CardTitle>
                <CardDescription>Distribution of credit consumption</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={componentUsage.slice(0, 5)}
                      cx="50%"
                      cy="50%"
                      outerRadius={80}
                      dataKey="total_cost"
                      nameKey="component_name"
                    >
                      {componentUsage.slice(0, 5).map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={CHART_COLORS[index % CHART_COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(value) => [`${value} credits`, 'Usage']} />
                  </PieChart>
                </ResponsiveContainer>
                <div className="mt-4 grid grid-cols-2 gap-2 text-xs">
                  {componentUsage.slice(0, 5).map((usage, index) => (
                    <div key={usage.component_name} className="flex items-center gap-2">
                      <div 
                        className="w-3 h-3 rounded" 
                        style={{ backgroundColor: CHART_COLORS[index % CHART_COLORS.length] }}
                      />
                      <span className="truncate">{usage.component_name}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default UsageDashboard;
