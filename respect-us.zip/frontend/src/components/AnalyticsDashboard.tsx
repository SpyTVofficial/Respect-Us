import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { 
  BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, 
  XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer,
  AreaChart, Area
} from 'recharts';
import { 
  TrendingUp, TrendingDown, Users, FileText, Search, Clock, 
  Globe, Target, Activity, AlertCircle, Database, Zap,
  BarChart3, Eye, Download, MessageSquare, Bookmark
} from 'lucide-react';
import brain from 'brain';
import {
  DocumentAnalyticsData,
  UserBehaviorAnalyticsData,
  SearchAnalyticsData,
  SystemMetricsData,
  ComplianceMetricsData,
  PerformanceMetricsData
} from 'types';
import { toast } from 'sonner';

interface Props {
  // Component props if needed
}

interface DashboardSummary {
  overview: {
    total_documents: number;
    total_views_today: number;
    active_users: number;
    pending_updates: number;
  };
  trending_documents: Array<{
    id: number;
    title: string;
    views: number;
    trend: string;
  }>;
  recent_activity: Array<{
    type: string;
    description: string;
    time: string;
  }>;
  compliance_alerts: Array<{
    level: string;
    message: string;
    count: number;
  }>;
  performance: {
    avg_response_time: string;
    uptime: string;
    cache_hit_rate: string;
    error_rate: string;
  };
}

const COLORS = ['#8B5CF6', '#06B6D4', '#10B981', '#F59E0B', '#EF4444', '#EC4899'];

export const AnalyticsDashboard: React.FC<Props> = () => {
  const [activeTab, setActiveTab] = useState('overview');
  const [timeRange, setTimeRange] = useState('30d');
  const [loading, setLoading] = useState(true);
  
  // Data state
  const [dashboardSummary, setDashboardSummary] = useState<DashboardSummary | null>(null);
  const [documentAnalytics, setDocumentAnalytics] = useState<DocumentAnalyticsData[]>([]);
  const [userBehavior, setUserBehavior] = useState<UserBehaviorAnalyticsData[]>([]);
  const [searchAnalytics, setSearchAnalytics] = useState<SearchAnalyticsData[]>([]);
  const [systemMetrics, setSystemMetrics] = useState<SystemMetricsData | null>(null);
  const [complianceMetrics, setComplianceMetrics] = useState<ComplianceMetricsData | null>(null);
  const [performanceMetrics, setPerformanceMetrics] = useState<PerformanceMetricsData | null>(null);

  const loadAnalyticsData = async () => {
    try {
      setLoading(true);
      
      // Load all analytics data in parallel
      const [summaryRes, documentsRes, systemRes, complianceRes, performanceRes, userRes, searchRes] = await Promise.all([
        brain.get_dashboard_summary(),
        brain.get_document_analytics({ time_range: timeRange, limit: 20 }),
        brain.get_system_metrics(),
        brain.get_compliance_metrics(),
        brain.get_performance_metrics(),
        brain.get_user_behavior_analytics({ time_range: timeRange, limit: 10 }),
        brain.get_search_analytics({ limit: 10 })
      ]);

      const [summary, documents, system, compliance, performance, users, search] = await Promise.all([
        summaryRes.json(),
        documentsRes.json(),
        systemRes.json(),
        complianceRes.json(),
        performanceRes.json(),
        userRes.json(),
        searchRes.json()
      ]);

      setDashboardSummary(summary);
      setDocumentAnalytics(documents);
      setSystemMetrics(system);
      setComplianceMetrics(compliance);
      setPerformanceMetrics(performance);
      setUserBehavior(users);
      setSearchAnalytics(search);
      
    } catch (error) {
      console.error('Error loading analytics data:', error);
      toast.error('Failed to load analytics data');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadAnalyticsData();
  }, [timeRange]);

  const formatNumber = (num: number): string => {
    if (num >= 1000000) return `${(num / 1000000).toFixed(1)}M`;
    if (num >= 1000) return `${(num / 1000).toFixed(1)}K`;
    return num.toString();
  };

  const getEngagementColor = (level: string): string => {
    switch (level) {
      case 'expert': return 'bg-purple-500';
      case 'high': return 'bg-blue-500';
      case 'medium': return 'bg-green-500';
      case 'low': return 'bg-yellow-500';
      default: return 'bg-gray-500';
    }
  };

  const getAlertColor = (level: string): string => {
    switch (level) {
      case 'high': return 'destructive';
      case 'medium': return 'secondary';
      case 'low': return 'outline';
      default: return 'outline';
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-2"></div>
          <p className="text-muted-foreground">Loading analytics...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header with Time Range Selector */}
      <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Knowledge Base Analytics</h2>
          <p className="text-muted-foreground">Comprehensive insights and regulatory intelligence</p>
        </div>
        <div className="flex items-center gap-4">
          <Select value={timeRange} onValueChange={setTimeRange}>
            <SelectTrigger className="w-40">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="7d">Last 7 days</SelectItem>
              <SelectItem value="30d">Last 30 days</SelectItem>
              <SelectItem value="90d">Last 90 days</SelectItem>
              <SelectItem value="1y">Last year</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline" onClick={loadAnalyticsData}>
            Refresh
          </Button>
        </div>
      </div>

      {/* Main Analytics Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-6 bg-gray-800/50">
          <TabsTrigger value="overview" className="data-[state=active]:bg-gray-700">
            <BarChart3 className="h-4 w-4 mr-2" />
            Overview
          </TabsTrigger>
          <TabsTrigger value="documents" className="data-[state=active]:bg-gray-700">
            <FileText className="h-4 w-4 mr-2" />
            Documents
          </TabsTrigger>
          <TabsTrigger value="users" className="data-[state=active]:bg-gray-700">
            <Users className="h-4 w-4 mr-2" />
            Users
          </TabsTrigger>
          <TabsTrigger value="search" className="data-[state=active]:bg-gray-700">
            <Search className="h-4 w-4 mr-2" />
            Search
          </TabsTrigger>
          <TabsTrigger value="compliance" className="data-[state=active]:bg-gray-700">
            <Target className="h-4 w-4 mr-2" />
            Compliance
          </TabsTrigger>
          <TabsTrigger value="performance" className="data-[state=active]:bg-gray-700">
            <Zap className="h-4 w-4 mr-2" />
            Performance
          </TabsTrigger>
        </TabsList>

        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-6">
          {/* Key Metrics Cards */}
          {dashboardSummary && (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card className="bg-gradient-to-br from-purple-500/10 to-purple-600/10 border-purple-500/20">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">Total Documents</p>
                      <p className="text-2xl font-bold text-purple-400">
                        {formatNumber(dashboardSummary.overview.total_documents)}
                      </p>
                    </div>
                    <div className="h-12 w-12 bg-purple-500/20 rounded-lg flex items-center justify-center">
                      <FileText className="h-6 w-6 text-purple-400" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-blue-500/10 to-blue-600/10 border-blue-500/20">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">Views Today</p>
                      <p className="text-2xl font-bold text-blue-400">
                        {formatNumber(dashboardSummary.overview.total_views_today)}
                      </p>
                    </div>
                    <div className="h-12 w-12 bg-blue-500/20 rounded-lg flex items-center justify-center">
                      <Eye className="h-6 w-6 text-blue-400" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-green-500/10 to-green-600/10 border-green-500/20">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">Active Users</p>
                      <p className="text-2xl font-bold text-green-400">
                        {formatNumber(dashboardSummary.overview.active_users)}
                      </p>
                    </div>
                    <div className="h-12 w-12 bg-green-500/20 rounded-lg flex items-center justify-center">
                      <Users className="h-6 w-6 text-green-400" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-orange-500/10 to-orange-600/10 border-orange-500/20">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">Pending Updates</p>
                      <p className="text-2xl font-bold text-orange-400">
                        {formatNumber(dashboardSummary.overview.pending_updates)}
                      </p>
                    </div>
                    <div className="h-12 w-12 bg-orange-500/20 rounded-lg flex items-center justify-center">
                      <Clock className="h-6 w-6 text-orange-400" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Trending Documents */}
            {dashboardSummary && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <TrendingUp className="h-5 w-5 text-green-500" />
                    Trending Documents
                  </CardTitle>
                  <CardDescription>Most viewed documents today</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {dashboardSummary.trending_documents.map((doc, index) => (
                    <div key={doc.id} className="flex items-center justify-between p-3 bg-gray-800/30 rounded-lg">
                      <div className="flex items-center gap-3">
                        <div className="text-sm font-medium text-purple-400">#{index + 1}</div>
                        <div>
                          <p className="font-medium text-sm">{doc.title}</p>
                          <p className="text-xs text-muted-foreground">{formatNumber(doc.views)} views</p>
                        </div>
                      </div>
                      <Badge variant="outline" className="text-green-400 border-green-400">
                        {doc.trend}
                      </Badge>
                    </div>
                  ))}
                </CardContent>
              </Card>
            )}

            {/* Recent Activity */}
            {dashboardSummary && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Activity className="h-5 w-5 text-blue-500" />
                    Recent Activity
                  </CardTitle>
                  <CardDescription>Latest system activities</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {dashboardSummary.recent_activity.map((activity, index) => (
                    <div key={index} className="flex items-start gap-3 p-3 bg-gray-800/30 rounded-lg">
                      <div className="h-2 w-2 bg-blue-500 rounded-full mt-2"></div>
                      <div className="flex-1">
                        <p className="text-sm">{activity.description}</p>
                        <p className="text-xs text-muted-foreground">{activity.time}</p>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>
            )}
          </div>

          {/* Performance Overview & Compliance Alerts */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Performance Metrics */}
            {dashboardSummary && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Zap className="h-5 w-5 text-yellow-500" />
                    System Performance
                  </CardTitle>
                  <CardDescription>Real-time system health metrics</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="text-center p-3 bg-gray-800/30 rounded-lg">
                      <p className="text-sm text-muted-foreground">Response Time</p>
                      <p className="text-lg font-semibold text-green-400">{dashboardSummary.performance.avg_response_time}</p>
                    </div>
                    <div className="text-center p-3 bg-gray-800/30 rounded-lg">
                      <p className="text-sm text-muted-foreground">Uptime</p>
                      <p className="text-lg font-semibold text-green-400">{dashboardSummary.performance.uptime}</p>
                    </div>
                    <div className="text-center p-3 bg-gray-800/30 rounded-lg">
                      <p className="text-sm text-muted-foreground">Cache Hit Rate</p>
                      <p className="text-lg font-semibold text-blue-400">{dashboardSummary.performance.cache_hit_rate}</p>
                    </div>
                    <div className="text-center p-3 bg-gray-800/30 rounded-lg">
                      <p className="text-sm text-muted-foreground">Error Rate</p>
                      <p className="text-lg font-semibold text-green-400">{dashboardSummary.performance.error_rate}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Compliance Alerts */}
            {dashboardSummary && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <AlertCircle className="h-5 w-5 text-orange-500" />
                    Compliance Alerts
                  </CardTitle>
                  <CardDescription>Important regulatory notifications</CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  {dashboardSummary.compliance_alerts.map((alert, index) => (
                    <div key={index} className="flex items-center justify-between p-3 bg-gray-800/30 rounded-lg">
                      <div className="flex items-center gap-3">
                        <AlertCircle className={`h-4 w-4 ${
                          alert.level === 'high' ? 'text-red-500' :
                          alert.level === 'medium' ? 'text-orange-500' : 'text-yellow-500'
                        }`} />
                        <span className="text-sm">{alert.message}</span>
                      </div>
                      <Badge variant={getAlertColor(alert.level) as any}>
                        {alert.count}
                      </Badge>
                    </div>
                  ))}
                </CardContent>
              </Card>
            )}
          </div>
        </TabsContent>

        {/* Documents Tab */}
        <TabsContent value="documents" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Document Views Chart */}
            <Card>
              <CardHeader>
                <CardTitle>Top Documents by Views</CardTitle>
                <CardDescription>Most viewed regulatory documents</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={documentAnalytics.slice(0, 10)}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                      <XAxis 
                        dataKey="title" 
                        tick={{ fontSize: 12 }}
                        angle={-45}
                        textAnchor="end"
                        height={100}
                        stroke="#9CA3AF"
                      />
                      <YAxis stroke="#9CA3AF" />
                      <Tooltip 
                        contentStyle={{ 
                          backgroundColor: '#1F2937', 
                          border: '1px solid #374151',
                          borderRadius: '8px'
                        }}
                      />
                      <Bar dataKey="total_views" fill="#8B5CF6" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            {/* Document Engagement Metrics */}
            <Card>
              <CardHeader>
                <CardTitle>Engagement Metrics</CardTitle>
                <CardDescription>User interaction patterns</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={documentAnalytics.slice(0, 10)}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                      <XAxis 
                        dataKey="title" 
                        tick={{ fontSize: 12 }}
                        angle={-45}
                        textAnchor="end"
                        height={100}
                        stroke="#9CA3AF"
                      />
                      <YAxis stroke="#9CA3AF" />
                      <Tooltip 
                        contentStyle={{ 
                          backgroundColor: '#1F2937', 
                          border: '1px solid #374151',
                          borderRadius: '8px'
                        }}
                      />
                      <Area 
                        type="monotone" 
                        dataKey="annotations_count" 
                        stackId="1" 
                        stroke="#06B6D4" 
                        fill="#06B6D4" 
                        fillOpacity={0.6}
                      />
                      <Area 
                        type="monotone" 
                        dataKey="bookmarks_count" 
                        stackId="1" 
                        stroke="#10B981" 
                        fill="#10B981" 
                        fillOpacity={0.6}
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Document Performance Table */}
          <Card>
            <CardHeader>
              <CardTitle>Document Performance Details</CardTitle>
              <CardDescription>Comprehensive analytics for all documents</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-gray-700">
                      <th className="text-left p-3">Document</th>
                      <th className="text-center p-3">Views</th>
                      <th className="text-center p-3">Unique Viewers</th>
                      <th className="text-center p-3">Avg. Time</th>
                      <th className="text-center p-3">Annotations</th>
                      <th className="text-center p-3">Bookmarks</th>
                      <th className="text-center p-3">Popularity</th>
                    </tr>
                  </thead>
                  <tbody>
                    {documentAnalytics.slice(0, 15).map((doc) => (
                      <tr key={doc.document_id} className="border-b border-gray-800 hover:bg-gray-800/30">
                        <td className="p-3">
                          <div>
                            <p className="font-medium">{doc.title}</p>
                            <p className="text-xs text-muted-foreground">{doc.jurisdiction}</p>
                          </div>
                        </td>
                        <td className="text-center p-3">{formatNumber(doc.total_views)}</td>
                        <td className="text-center p-3">{formatNumber(doc.unique_viewers)}</td>
                        <td className="text-center p-3">{doc.avg_time_spent.toFixed(1)}m</td>
                        <td className="text-center p-3">
                          <div className="flex items-center justify-center gap-1">
                            <MessageSquare className="h-3 w-3" />
                            {doc.annotations_count}
                          </div>
                        </td>
                        <td className="text-center p-3">
                          <div className="flex items-center justify-center gap-1">
                            <Bookmark className="h-3 w-3" />
                            {doc.bookmarks_count}
                          </div>
                        </td>
                        <td className="text-center p-3">
                          <div className="flex items-center justify-center">
                            <div className="w-16 bg-gray-700 rounded-full h-2">
                              <div 
                                className="bg-purple-500 h-2 rounded-full" 
                                style={{ width: `${doc.popularity_score}%` }}
                              ></div>
                            </div>
                            <span className="ml-2 text-xs">{doc.popularity_score}%</span>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Users Tab */}
        <TabsContent value="users" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* User Engagement Levels */}
            <Card>
              <CardHeader>
                <CardTitle>User Engagement Levels</CardTitle>
                <CardDescription>Distribution of user expertise and activity</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={[
                          { name: 'Expert', value: userBehavior.filter(u => u.engagement_level === 'expert').length },
                          { name: 'High', value: userBehavior.filter(u => u.engagement_level === 'high').length },
                          { name: 'Medium', value: userBehavior.filter(u => u.engagement_level === 'medium').length },
                          { name: 'Low', value: userBehavior.filter(u => u.engagement_level === 'low').length },
                        ]}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                      >
                        {COLORS.map((color, index) => (
                          <Cell key={`cell-${index}`} fill={color} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            {/* User Activity Metrics */}
            <Card>
              <CardHeader>
                <CardTitle>User Activity Overview</CardTitle>
                <CardDescription>Key user engagement metrics</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {userBehavior.slice(0, 6).map((user, index) => (
                  <div key={user.user_id} className="flex items-center justify-between p-3 bg-gray-800/30 rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className={`h-3 w-3 rounded-full ${getEngagementColor(user.engagement_level)}`}></div>
                      <div>
                        <p className="font-medium text-sm">User {index + 1}</p>
                        <p className="text-xs text-muted-foreground">{user.most_active_jurisdiction}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium">{user.total_sessions} sessions</p>
                      <p className="text-xs text-muted-foreground">{user.total_time_spent.toFixed(1)}h total</p>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>

          {/* User Behavior Details */}
          <Card>
            <CardHeader>
              <CardTitle>User Behavior Analysis</CardTitle>
              <CardDescription>Detailed user activity patterns</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-gray-700">
                      <th className="text-left p-3">User</th>
                      <th className="text-center p-3">Sessions</th>
                      <th className="text-center p-3">Time Spent</th>
                      <th className="text-center p-3">Documents</th>
                      <th className="text-center p-3">Annotations</th>
                      <th className="text-center p-3">Searches</th>
                      <th className="text-center p-3">Engagement</th>
                      <th className="text-center p-3">Active Jurisdiction</th>
                    </tr>
                  </thead>
                  <tbody>
                    {userBehavior.map((user, index) => (
                      <tr key={user.user_id} className="border-b border-gray-800 hover:bg-gray-800/30">
                        <td className="p-3 font-medium">User {index + 1}</td>
                        <td className="text-center p-3">{user.total_sessions}</td>
                        <td className="text-center p-3">{user.total_time_spent.toFixed(1)}h</td>
                        <td className="text-center p-3">{user.documents_viewed}</td>
                        <td className="text-center p-3">{user.annotations_created}</td>
                        <td className="text-center p-3">{user.searches_performed}</td>
                        <td className="text-center p-3">
                          <Badge variant="outline" className={`${getEngagementColor(user.engagement_level)} text-white`}>
                            {user.engagement_level}
                          </Badge>
                        </td>
                        <td className="text-center p-3 text-muted-foreground">{user.most_active_jurisdiction}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Search Tab */}
        <TabsContent value="search" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Popular Search Queries */}
            <Card>
              <CardHeader>
                <CardTitle>Popular Search Queries</CardTitle>
                <CardDescription>Most frequently searched terms</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={searchAnalytics}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                      <XAxis 
                        dataKey="query" 
                        tick={{ fontSize: 12 }}
                        angle={-45}
                        textAnchor="end"
                        height={100}
                        stroke="#9CA3AF"
                      />
                      <YAxis stroke="#9CA3AF" />
                      <Tooltip 
                        contentStyle={{ 
                          backgroundColor: '#1F2937', 
                          border: '1px solid #374151',
                          borderRadius: '8px'
                        }}
                      />
                      <Bar dataKey="frequency" fill="#06B6D4" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            {/* Search Success Rates */}
            <Card>
              <CardHeader>
                <CardTitle>Search Success Rates</CardTitle>
                <CardDescription>Query effectiveness and user satisfaction</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {searchAnalytics.map((search, index) => (
                    <div key={index} className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-sm font-medium">{search.query}</span>
                        <span className="text-sm text-muted-foreground">
                          {(search.success_rate * 100).toFixed(0)}% success
                        </span>
                      </div>
                      <Progress value={search.success_rate * 100} className="h-2" />
                      <div className="flex justify-between text-xs text-muted-foreground">
                        <span>{search.frequency} searches</span>
                        <span>{search.avg_results_count} avg results</span>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Search Analytics Table */}
          <Card>
            <CardHeader>
              <CardTitle>Search Analytics Details</CardTitle>
              <CardDescription>Comprehensive search performance metrics</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-gray-700">
                      <th className="text-left p-3">Query</th>
                      <th className="text-center p-3">Frequency</th>
                      <th className="text-center p-3">Success Rate</th>
                      <th className="text-center p-3">Avg Results</th>
                      <th className="text-center p-3">Jurisdictions</th>
                      <th className="text-center p-3">Categories</th>
                      <th className="text-center p-3">Last Searched</th>
                    </tr>
                  </thead>
                  <tbody>
                    {searchAnalytics.map((search, index) => (
                      <tr key={index} className="border-b border-gray-800 hover:bg-gray-800/30">
                        <td className="p-3 font-medium">{search.query}</td>
                        <td className="text-center p-3">{search.frequency}</td>
                        <td className="text-center p-3">
                          <span className={`px-2 py-1 rounded text-xs ${
                            search.success_rate > 0.8 ? 'bg-green-500/20 text-green-400' :
                            search.success_rate > 0.6 ? 'bg-yellow-500/20 text-yellow-400' :
                            'bg-red-500/20 text-red-400'
                          }`}>
                            {(search.success_rate * 100).toFixed(0)}%
                          </span>
                        </td>
                        <td className="text-center p-3">{search.avg_results_count}</td>
                        <td className="text-center p-3">
                          <div className="flex flex-wrap gap-1 justify-center">
                            {search.jurisdictions_searched.slice(0, 2).map((jurisdiction, idx) => (
                              <Badge key={idx} variant="outline" className="text-xs">
                                {jurisdiction}
                              </Badge>
                            ))}
                          </div>
                        </td>
                        <td className="text-center p-3">
                          <div className="flex flex-wrap gap-1 justify-center">
                            {search.categories_searched.slice(0, 2).map((category, idx) => (
                              <Badge key={idx} variant="outline" className="text-xs">
                                {category}
                              </Badge>
                            ))}
                          </div>
                        </td>
                        <td className="text-center p-3 text-muted-foreground">
                          {new Date(search.last_searched).toLocaleDateString()}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Compliance Tab */}
        <TabsContent value="compliance" className="space-y-6">
          {complianceMetrics && (
            <>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <Card className="bg-gradient-to-br from-blue-500/10 to-blue-600/10 border-blue-500/20">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-muted-foreground">Regulatory Updates</p>
                        <p className="text-2xl font-bold text-blue-400">{complianceMetrics.regulatory_updates_this_month}</p>
                        <p className="text-xs text-muted-foreground">This month</p>
                      </div>
                      <div className="h-12 w-12 bg-blue-500/20 rounded-lg flex items-center justify-center">
                        <FileText className="h-6 w-6 text-blue-400" />
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-gradient-to-br from-orange-500/10 to-orange-600/10 border-orange-500/20">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-muted-foreground">Active Alerts</p>
                        <p className="text-2xl font-bold text-orange-400">{complianceMetrics.compliance_alerts_active}</p>
                        <p className="text-xs text-muted-foreground">Requires attention</p>
                      </div>
                      <div className="h-12 w-12 bg-orange-500/20 rounded-lg flex items-center justify-center">
                        <AlertCircle className="h-6 w-6 text-orange-400" />
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-gradient-to-br from-green-500/10 to-green-600/10 border-green-500/20">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-muted-foreground">Risk Assessments</p>
                        <p className="text-2xl font-bold text-green-400">{complianceMetrics.risk_assessments_completed}</p>
                        <p className="text-xs text-muted-foreground">Completed</p>
                      </div>
                      <div className="h-12 w-12 bg-green-500/20 rounded-lg flex items-center justify-center">
                        <Target className="h-6 w-6 text-green-400" />
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-gradient-to-br from-purple-500/10 to-purple-600/10 border-purple-500/20">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-muted-foreground">Training Completion</p>
                        <p className="text-2xl font-bold text-purple-400">
                          {(complianceMetrics.user_training_completion * 100).toFixed(0)}%
                        </p>
                        <p className="text-xs text-muted-foreground">User training</p>
                      </div>
                      <div className="h-12 w-12 bg-purple-500/20 rounded-lg flex items-center justify-center">
                        <Users className="h-6 w-6 text-purple-400" />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Document Status Distribution */}
                <Card>
                  <CardHeader>
                    <CardTitle>Document Status Distribution</CardTitle>
                    <CardDescription>Current status of all regulatory documents</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="h-80">
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie
                            data={Object.entries(complianceMetrics.documents_by_status).map(([status, count]) => ({
                              name: status.replace('_', ' ').toUpperCase(),
                              value: count
                            }))}
                            cx="50%"
                            cy="50%"
                            labelLine={false}
                            label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                            outerRadius={80}
                            fill="#8884d8"
                            dataKey="value"
                          >
                            {COLORS.map((color, index) => (
                              <Cell key={`cell-${index}`} fill={color} />
                            ))}
                          </Pie>
                          <Tooltip />
                        </PieChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>

                {/* Compliance Metrics */}
                <Card>
                  <CardHeader>
                    <CardTitle>Compliance Health Score</CardTitle>
                    <CardDescription>Overall compliance system performance</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="space-y-4">
                      <div>
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-sm font-medium">Training Completion</span>
                          <span className="text-sm text-muted-foreground">
                            {(complianceMetrics.user_training_completion * 100).toFixed(0)}%
                          </span>
                        </div>
                        <Progress value={complianceMetrics.user_training_completion * 100} className="h-2" />
                      </div>

                      <div>
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-sm font-medium">Document Coverage</span>
                          <span className="text-sm text-muted-foreground">94%</span>
                        </div>
                        <Progress value={94} className="h-2" />
                      </div>

                      <div>
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-sm font-medium">Risk Assessment</span>
                          <span className="text-sm text-muted-foreground">89%</span>
                        </div>
                        <Progress value={89} className="h-2" />
                      </div>

                      <div className="pt-4 border-t border-gray-700">
                        <div className="text-center">
                          <p className="text-2xl font-bold text-green-400">91%</p>
                          <p className="text-sm text-muted-foreground">Overall Compliance Score</p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </>
          )}
        </TabsContent>

        {/* Performance Tab */}
        <TabsContent value="performance" className="space-y-6">
          {performanceMetrics && systemMetrics && (
            <>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <Card className="bg-gradient-to-br from-green-500/10 to-green-600/10 border-green-500/20">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-muted-foreground">Page Load Time</p>
                        <p className="text-2xl font-bold text-green-400">
                          {performanceMetrics.avg_page_load_time.toFixed(1)}s
                        </p>
                      </div>
                      <div className="h-12 w-12 bg-green-500/20 rounded-lg flex items-center justify-center">
                        <Clock className="h-6 w-6 text-green-400" />
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-gradient-to-br from-blue-500/10 to-blue-600/10 border-blue-500/20">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-muted-foreground">Search Response</p>
                        <p className="text-2xl font-bold text-blue-400">
                          {(performanceMetrics.search_response_time * 1000).toFixed(0)}ms
                        </p>
                      </div>
                      <div className="h-12 w-12 bg-blue-500/20 rounded-lg flex items-center justify-center">
                        <Search className="h-6 w-6 text-blue-400" />
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-gradient-to-br from-purple-500/10 to-purple-600/10 border-purple-500/20">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-muted-foreground">Cache Hit Rate</p>
                        <p className="text-2xl font-bold text-purple-400">
                          {(performanceMetrics.cache_hit_rate * 100).toFixed(0)}%
                        </p>
                      </div>
                      <div className="h-12 w-12 bg-purple-500/20 rounded-lg flex items-center justify-center">
                        <Database className="h-6 w-6 text-purple-400" />
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-gradient-to-br from-orange-500/10 to-orange-600/10 border-orange-500/20">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-muted-foreground">Active Users</p>
                        <p className="text-2xl font-bold text-orange-400">{performanceMetrics.concurrent_users}</p>
                      </div>
                      <div className="h-12 w-12 bg-orange-500/20 rounded-lg flex items-center justify-center">
                        <Users className="h-6 w-6 text-orange-400" />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* API Response Times */}
                <Card>
                  <CardHeader>
                    <CardTitle>API Response Times</CardTitle>
                    <CardDescription>Performance metrics for different endpoints</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="h-80">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={Object.entries(performanceMetrics.api_response_times).map(([endpoint, time]) => ({
                          endpoint,
                          time: time * 1000 // Convert to milliseconds
                        }))}>
                          <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                          <XAxis dataKey="endpoint" stroke="#9CA3AF" />
                          <YAxis stroke="#9CA3AF" />
                          <Tooltip 
                            contentStyle={{ 
                              backgroundColor: '#1F2937', 
                              border: '1px solid #374151',
                              borderRadius: '8px'
                            }}
                            formatter={(value) => [`${value}ms`, 'Response Time']}
                          />
                          <Bar dataKey="time" fill="#10B981" radius={[4, 4, 0, 0]} />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>

                {/* System Health Metrics */}
                <Card>
                  <CardHeader>
                    <CardTitle>System Health Overview</CardTitle>
                    <CardDescription>Real-time system performance indicators</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="text-center p-4 bg-gray-800/30 rounded-lg">
                        <p className="text-sm text-muted-foreground mb-1">Storage Used</p>
                        <p className="text-lg font-semibold text-blue-400">{systemMetrics.storage_used.toFixed(1)} GB</p>
                      </div>
                      <div className="text-center p-4 bg-gray-800/30 rounded-lg">
                        <p className="text-sm text-muted-foreground mb-1">Bandwidth</p>
                        <p className="text-lg font-semibold text-green-400">{systemMetrics.bandwidth_used.toFixed(1)} GB</p>
                      </div>
                      <div className="text-center p-4 bg-gray-800/30 rounded-lg">
                        <p className="text-sm text-muted-foreground mb-1">Error Rate</p>
                        <p className="text-lg font-semibold text-green-400">{(systemMetrics.error_rate * 100).toFixed(2)}%</p>
                      </div>
                      <div className="text-center p-4 bg-gray-800/30 rounded-lg">
                        <p className="text-sm text-muted-foreground mb-1">Peak Hour</p>
                        <p className="text-lg font-semibold text-purple-400">{performanceMetrics.peak_usage_hour}:00</p>
                      </div>
                    </div>

                    <div className="space-y-3">
                      <div>
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-sm font-medium">System Performance</span>
                          <span className="text-sm text-green-400">Excellent</span>
                        </div>
                        <Progress value={96} className="h-2" />
                      </div>
                      
                      <div>
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-sm font-medium">Resource Utilization</span>
                          <span className="text-sm text-blue-400">Optimal</span>
                        </div>
                        <Progress value={78} className="h-2" />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
};
