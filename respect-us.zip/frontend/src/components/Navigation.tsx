import React from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import {
  Search,
  Bell,
  Menu,
  X,
  ChevronDown,
  FileText,
  Package,
  BarChart3,
  Globe,
  Users,
  Target,
  Shield,
  Home,
  LayoutDashboard,
  CreditCard,
  HelpCircle,
  BookOpen
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger
} from '@/components/ui/dropdown-menu';
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger
} from '@/components/ui/sheet';
import { Separator } from '@/components/ui/separator';
import SupportRequestDialog from 'components/SupportRequestDialog';
import NotificationCenter from 'components/NotificationCenter';
import brain from 'brain';
import { stackClientApp } from 'app/auth';

interface NavigationProps {
  currentPage?: string;
}

// Module definitions with icons and status
const modules = [
  {
    name: 'Knowledge Base',
    path: '/knowledge-base',
    icon: FileText,
    status: 'ACTIVE' as const,
    key: 'knowledge-base'
  },
  {
    name: 'Product Classification',
    path: '/product-classification',
    icon: Package,
    status: 'ACTIVE' as const,
    key: 'product-classification'
  },
  {
    name: 'Risk Assessment',
    path: '/risk-assessment',
    icon: BarChart3,
    status: 'ACTIVE' as const,
    key: 'risk-assessment'
  },
  {
    name: 'Sanctions & Embargoes',
    path: '/sanctions-embargoes',
    icon: Globe,
    status: 'ACTIVE' as const,
    key: 'sanctions-embargoes'
  },
  {
    name: 'Customer Screening',
    path: '/customer-screening',
    icon: Users,
    status: 'ACTIVE' as const,
    key: 'customer-screening'
  },
  {
    name: 'End-Use Checks',
    path: '/end-use-checks',
    icon: Target,
    status: 'COMING SOON' as const,
    key: 'end-use-checks'
  },
  {
    name: 'License Determination',
    path: '/license-determination',
    icon: Shield,
    status: 'COMING SOON' as const,
    key: 'license-determination'
  }
];

const Navigation: React.FC<NavigationProps> = ({ currentPage }) => {
  const navigate = useNavigate();
  const location = useLocation();
  const [isSheetOpen, setIsSheetOpen] = React.useState(false);
  const [credits, setCredits] = React.useState<number | null>(null);
  const [supportDialogOpen, setSupportDialogOpen] = React.useState(false);
  const [notificationCenterOpen, setNotificationCenterOpen] = React.useState(false);
  const [unreadNotificationCount, setUnreadNotificationCount] = React.useState(0);

  // Fetch credits on component mount
  React.useEffect(() => {
    const fetchCredits = async () => {
      try {
        const response = await brain.get_credit_balance();
        const data = await response.json();
        setCredits(data.current_balance || 0);
      } catch (error) {
        console.error('Error fetching credits:', error);
        setCredits(0);
      }
    };

    fetchCredits();
  }, []);

  // Fetch unread notification count
  const fetchUnreadCount = React.useCallback(async () => {
    try {
      const response = await brain.get_unread_notification_count();
      const data = await response.json();
      setUnreadNotificationCount(data.unread_count || 0);
    } catch (error) {
      console.error('Error fetching notification count:', error);
    }
  }, []);

  React.useEffect(() => {
    fetchUnreadCount();
    
    // Poll for new notifications every 5 minutes
    const interval = setInterval(fetchUnreadCount, 300000);
    return () => clearInterval(interval);
  }, [fetchUnreadCount]);

  const handleNotificationCenterToggle = () => {
    setNotificationCenterOpen(!notificationCenterOpen);
  };

  const handleMarkAllRead = () => {
    setUnreadNotificationCount(0);
  };

  return (
    <nav className="bg-gray-900/95 backdrop-blur-sm border-b border-gray-700 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex items-center justify-between h-16">
          {/* Logo and Brand */}
          <div className="flex items-center space-x-4">
            <Button
              variant="ghost"
              onClick={() => navigate('/')}
              className="flex items-center space-x-2 text-white hover:text-blue-400 p-0"
            >
              <img 
                src="https://static.databutton.com/public/a180dafe-f6c8-4fb7-917a-f8d4b9bfe1b1/White_svg.svg" 
                alt="RespectUs Logo" 
                className="h-8 w-auto"
              />
              <span className="font-bold text-lg">RespectUs</span>
            </Button>
          </div>

          {/* Main Navigation */}
          <div className="hidden md:flex items-center space-x-1">
            <Button
              variant="ghost"
              onClick={() => navigate('/')}
              className={`text-white hover:text-blue-400 ${
                currentPage === 'home' ? 'text-blue-400 bg-blue-500/10' : ''
              }`}
            >
              <Home className="w-4 h-4 mr-2" />
              Home
            </Button>

            <Button
              variant="ghost"
              onClick={() => navigate('/user-dashboard')}
              className={`text-white hover:text-blue-400 ${
                currentPage === 'dashboard' ? 'text-blue-400 bg-blue-500/10' : ''
              }`}
            >
              <LayoutDashboard className="w-4 h-4 mr-2" />
              Dashboard
            </Button>

            <Button
              variant="ghost"
              onClick={() => navigate('/blog')}
              className={`text-white hover:text-blue-400 ${
                currentPage === 'blog' ? 'text-blue-400 bg-blue-500/10' : ''
              }`}
            >
              <BookOpen className="w-4 h-4 mr-2" />
              Blog
            </Button>

            {/* Modules Dropdown */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button
                  variant="ghost"
                  className="text-white hover:text-blue-400 flex items-center space-x-1"
                >
                  <span>Modules</span>
                  <ChevronDown className="w-4 h-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent 
                align="start" 
                className="w-64 bg-gray-800 border-gray-700 text-white"
              >
                {modules.map((module) => {
                  const Icon = module.icon;
                  const isCurrentPage = currentPage === module.key;
                  const isComingSoon = module.status === 'COMING SOON';
                  
                  return (
                    <DropdownMenuItem
                      key={module.key}
                      onClick={() => {
                        if (!isComingSoon) {
                          navigate(module.path);
                        }
                      }}
                      className={`flex items-center justify-between p-3 cursor-pointer hover:bg-gray-700 ${
                        isCurrentPage ? 'bg-blue-500/10 text-blue-400' : ''
                      } ${
                        isComingSoon ? 'opacity-60 cursor-not-allowed' : ''
                      }`}
                      disabled={isComingSoon}
                    >
                      <div className="flex items-center space-x-2">
                        <Icon className="w-4 h-4" />
                        <span>{module.name}</span>
                      </div>
                      <Badge 
                        variant={module.status === 'ACTIVE' ? 'default' : 'secondary'}
                        className={`text-xs ${
                          module.status === 'ACTIVE' 
                            ? 'bg-green-600 hover:bg-green-700 text-white' 
                            : 'bg-gray-600 hover:bg-gray-700 text-gray-300'
                        }`}
                      >
                        {module.status}
                      </Badge>
                    </DropdownMenuItem>
                  );
                })}
              </DropdownMenuContent>
            </DropdownMenu>
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden">
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="ghost" size="sm" className="text-white hover:text-blue-400">
                  <Menu className="w-5 h-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="bg-gray-900 border-gray-700 text-white">
                <SheetHeader>
                  <SheetTitle className="text-white flex items-center space-x-2">
                    <img 
                      src="https://static.databutton.com/public/a180dafe-f6c8-4fb7-917a-f8d4b9bfe1b1/Original_jpg.jpg" 
                      alt="RespectUs Logo" 
                      className="h-6 w-auto"
                    />
                    <span>RespectUs</span>
                  </SheetTitle>
                </SheetHeader>
                <div className="mt-6 space-y-4">
                  <Button
                    variant="ghost"
                    onClick={() => navigate('/')}
                    className="w-full justify-start text-white hover:text-blue-400"
                  >
                    <Home className="w-4 h-4 mr-2" />
                    Home
                  </Button>
                  
                  <Button
                    variant="ghost"
                    onClick={() => navigate('/user-dashboard')}
                    className="w-full justify-start text-white hover:text-blue-400"
                  >
                    <LayoutDashboard className="w-4 h-4 mr-2" />
                    Dashboard
                  </Button>

                  <Button
                    variant="ghost"
                    onClick={() => navigate('/blog')}
                    className="w-full justify-start text-white hover:text-blue-400"
                  >
                    <BookOpen className="w-4 h-4 mr-2" />
                    Blog
                  </Button>

                  <Separator className="my-4 bg-gray-700" />
                  
                  <div className="space-y-2">
                    <h3 className="text-sm font-medium text-gray-400 px-2">Modules</h3>
                    {modules.map((module) => {
                      const Icon = module.icon;
                      const isCurrentPage = currentPage === module.key;
                      const isComingSoon = module.status === 'COMING SOON';
                      
                      return (
                        <Button
                          key={module.key}
                          variant="ghost"
                          onClick={() => {
                            if (!isComingSoon) {
                              navigate(module.path);
                              setIsSheetOpen(false);
                            }
                          }}
                          className={`w-full justify-between text-white hover:text-blue-400 ${
                            isCurrentPage ? 'text-blue-400 bg-blue-500/10' : ''
                          } ${
                            isComingSoon ? 'opacity-60 cursor-not-allowed' : ''
                          }`}
                          disabled={isComingSoon}
                        >
                          <div className="flex items-center space-x-2">
                            <Icon className="w-4 h-4" />
                            <span>{module.name}</span>
                          </div>
                          <Badge 
                            variant={module.status === 'ACTIVE' ? 'default' : 'secondary'}
                            className={`text-xs ${
                              module.status === 'ACTIVE' 
                                ? 'bg-green-600 hover:bg-green-700 text-white' 
                                : 'bg-gray-600 hover:bg-gray-700 text-gray-300'
                            }`}
                          >
                            {module.status}
                          </Badge>
                        </Button>
                      );
                    })}
                  </div>
                </div>
              </SheetContent>
            </Sheet>
          </div>

          {/* Right side - Search, Notifications, Credits, User Menu */}
          <div className="flex items-center space-x-4">
            {/* Search */}
            <div className="relative hidden md:block">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                type="search"
                placeholder="Search documentation..."
                className="w-64 pl-10 bg-gray-800 border-gray-700 text-white placeholder-gray-400 focus:border-blue-500"
              />
            </div>

            {/* Notifications */}
            <Button
              variant="ghost"
              size="sm"
              className="relative text-gray-300 hover:text-white hover:bg-gray-800"
              onClick={handleNotificationCenterToggle}
            >
              <Bell className="h-5 w-5" />
              {unreadNotificationCount > 0 && (
                <Badge 
                  variant="destructive" 
                  className="absolute -top-1 -right-1 h-5 w-5 rounded-full p-0 flex items-center justify-center text-xs"
                >
                  {unreadNotificationCount > 99 ? '99+' : unreadNotificationCount}
                </Badge>
              )}
            </Button>

            {/* Credits Display */}
            <div className="flex items-center gap-2 text-sm text-gray-300">
              <CreditCard className="h-4 w-4" />
              <span>{credits !== null ? `${credits} credits` : 'Loading...'}</span>
            </div>

            {/* Buy Credits Button */}
            <Button
              size="sm"
              onClick={() => navigate('/buy-credits')}
              className="bg-blue-600 hover:bg-blue-700 text-white"
            >
              Buy Credits
            </Button>

            {/* Support Request Button */}
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setSupportDialogOpen(true)}
              className="text-gray-300 hover:text-white hover:bg-gray-800"
              title="Request Support"
            >
              <HelpCircle className="h-5 w-5" />
            </Button>

            {/* User Menu */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="sm" className="text-gray-300 hover:text-white hover:bg-gray-800">
                  Welcome, User
                  <ChevronDown className="ml-1 h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-48">
                <DropdownMenuItem
                  onClick={() => stackClientApp.signOut()}
                  className="text-red-600 cursor-pointer"
                >
                  Sign Out
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>

        {/* Support Request Dialog */}
        <SupportRequestDialog 
          isOpen={supportDialogOpen}
          onClose={() => setSupportDialogOpen(false)}
        />

        {/* Notification Center */}
        <NotificationCenter
          isOpen={notificationCenterOpen}
          onClose={() => setNotificationCenterOpen(false)}
          onMarkAllRead={handleMarkAllRead}
        />
      </div>
    </nav>
  );
};

export default Navigation;
