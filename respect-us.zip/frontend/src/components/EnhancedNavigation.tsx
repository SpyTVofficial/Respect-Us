
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useUser } from '@stackframe/react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  NavigationMenu,
  NavigationMenuContent,
  NavigationMenuItem,
  NavigationMenuLink,
  NavigationMenuList,
  NavigationMenuTrigger,
} from '@/components/ui/navigation-menu';
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from '@/components/ui/sheet';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import {
  Home,
  Menu,
  Bell,
  User,
  Settings,
  LogOut,
  HelpCircle,
  ChevronDown,
  Star,
  Clock,
  Zap
} from 'lucide-react';
import AdvancedNavigationSearch from 'components/AdvancedNavigationSearch';
import NavigationBreadcrumb from 'components/NavigationBreadcrumb';
import CreditBalanceDisplay from 'components/CreditBalanceDisplay';
import { useNavigationSession } from 'utils/useNavigationSession';
import { 
  NAVIGATION_MODULES, 
  getModulesByCategory, 
  getStatusBadgeConfig 
} from 'utils/navigationUtils';
import { stackClientApp } from 'app/auth';

interface EnhancedNavigationProps {
  currentPage?: string;
  showBreadcrumb?: boolean;
  variant?: 'full' | 'compact' | 'minimal';
}

export default function EnhancedNavigation({ 
  currentPage, 
  showBreadcrumb = true,
  variant = 'full'
}: EnhancedNavigationProps) {
  const navigate = useNavigate();
  const user = useUser();
  const { 
    currentModule, 
    breadcrumb, 
    recentModules, 
    favoriteModules, 
    toggleFavorite, 
    isFavorite 
  } = useNavigationSession();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [notificationCount] = useState(2); // TODO: Connect to real notifications
  
  const coreModules = getModulesByCategory('core');
  const assessmentModules = getModulesByCategory('assessment');
  const screeningModules = getModulesByCategory('screening');
  
  const handleModuleClick = (moduleId: string, path: string, status: string) => {
    if (status === 'coming_soon') return;
    
    if (!user && status !== 'free') {
      navigate('/auth/sign-in');
      return;
    }
    
    navigate(path);
    setIsMobileMenuOpen(false);
  };
  
  const handleFavoriteToggle = (moduleId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    toggleFavorite(moduleId);
  };
  
  const handleSignOut = async () => {
    try {
      await stackClientApp.signOut();
      navigate('/');
    } catch (error) {
      console.error('Sign out error:', error);
    }
  };

  const handleUserDashboard = () => {
    navigate('/user-dashboard');
  };

  const handleSettings = () => {
    navigate('/auth/account-settings');
  };

  const handleGettingStarted = () => {
    navigate('/user-dashboard?tab=getting-started');
  };

  const renderModuleItem = (module: typeof NAVIGATION_MODULES[0], inDropdown = false) => {
    const IconComponent = module.icon;
    const statusConfig = getStatusBadgeConfig(module.status);
    const isCurrentModule = currentModule?.id === module.id;
    const isFav = isFavorite(module.id);
    
    const content = (
      <div className="flex items-start space-x-3 w-full">
        <div className={`mt-1 ${module.color}`}>
          <IconComponent className="w-4 h-4" />
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center space-x-2">
            <span className="text-white font-medium text-sm truncate">
              {module.title}
            </span>
            <Badge className={`text-xs ${statusConfig.className}`}>
              {statusConfig.text}
            </Badge>
            {isFav && (
              <Star className="w-3 h-3 text-yellow-400 fill-current" />
            )}
          </div>
          <p className="text-gray-400 text-xs mt-1 line-clamp-2">
            {module.description}
          </p>
          {module.features && (
            <div className="flex flex-wrap gap-1 mt-2">
              {module.features.slice(0, 3).map((feature, idx) => (
                <Badge 
                  key={idx} 
                  variant="outline" 
                  className="text-xs border-gray-600 text-gray-400"
                >
                  {feature}
                </Badge>
              ))}
            </div>
          )}
        </div>
        <div className="flex flex-col items-end space-y-1">
          <Button
            variant="ghost"
            size="sm"
            onClick={(e) => handleFavoriteToggle(module.id, e)}
            className="h-6 w-6 p-0 text-gray-400 hover:text-yellow-400"
          >
            <Star className={`w-3 h-3 ${isFav ? 'fill-current text-yellow-400' : ''}`} />
          </Button>
          {module.status === 'premium' && module.pricing && (
            <Badge className="text-xs bg-purple-500/20 text-purple-400">
              €{module.pricing} + VAT if applicable
            </Badge>
          )}
        </div>
      </div>
    );
    
    if (inDropdown) {
      return (
        <NavigationMenuLink
          key={module.id}
          className={`block p-4 rounded-lg hover:bg-gray-800 transition-colors cursor-pointer ${
            module.status === 'coming_soon' ? 'opacity-60 cursor-not-allowed' : ''
          } ${isCurrentModule ? 'bg-gray-800/50 border border-gray-600' : ''}`}
          onClick={() => handleModuleClick(module.id, module.path, module.status)}
        >
          {content}
        </NavigationMenuLink>
      );
    }
    
    return (
      <Button
        key={module.id}
        variant="ghost"
        onClick={() => handleModuleClick(module.id, module.path, module.status)}
        disabled={module.status === 'coming_soon'}
        className={`w-full justify-start text-white hover:text-blue-400 h-auto p-3 ${
          isCurrentModule ? 'bg-blue-500/10 text-blue-400' : ''
        }`}
      >
        {content}
      </Button>
    );
  };
  
  if (variant === 'minimal') {
    return (
      <nav className="bg-gray-900/95 backdrop-blur-sm border-b border-gray-700 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6">
          <div className="flex items-center justify-between h-12">
            <Button
              variant="ghost"
              onClick={() => navigate('/')}
              className="flex items-center space-x-2 text-white hover:text-blue-400 p-0"
            >
              <img 
                src="https://static.databutton.com/public/a180dafe-f6c8-4fb7-917a-f8d4b9bfe1b1/Original_jpg.jpg" 
                alt="RespectUs Logo" 
                className="h-6 w-auto"
              />
              <span className="font-bold text-sm">RespectUs</span>
            </Button>
            
            {showBreadcrumb && breadcrumb.length > 0 && (
              <NavigationBreadcrumb 
                items={breadcrumb} 
                showHomeButton={false}
                showBackButton={true}
                className="flex-1 mx-4"
              />
            )}
            
            <AdvancedNavigationSearch className="w-48" />
          </div>
        </div>
      </nav>
    );
  }
  
  return (
    <nav className="bg-gray-900 border-b border-gray-800 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo and main navigation */}
          <div className="flex items-center space-x-8">
            <div 
              className="flex items-center space-x-2 cursor-pointer" 
              onClick={() => navigate('/')}
            >
              <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-sm">R</span>
              </div>
              <span className="text-white font-bold text-xl">RespectUs</span>
            </div>
            
            {variant === 'full' && (
              <div className="hidden lg:flex items-center space-x-6">
                {/* Navigation items here */}
              </div>
            )}
          </div>

          {/* Right side - Credits, User menu, etc. */}
          <div className="flex items-center space-x-4">
            {/* Credit Balance Display */}
            {user && (
              <CreditBalanceDisplay 
                variant="header" 
                showPurchaseButton={true}
                className="hidden sm:flex"
              />
            )}
            
            {/* Notifications */}
            {user && (
              <Button
                variant="ghost"
                size="sm"
                className="relative text-gray-300 hover:text-white hover:bg-gray-800"
              >
                <Bell className="w-4 h-4" />
                {notificationCount > 0 && (
                  <Badge className="absolute -top-1 -right-1 bg-red-500 text-white text-xs min-w-[1.25rem] h-5 flex items-center justify-center p-0">
                    {notificationCount}
                  </Badge>
                )}
              </Button>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
}
