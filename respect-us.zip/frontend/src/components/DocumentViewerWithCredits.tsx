import React, { useState, useEffect } from 'react';
import { useDocumentAccess } from 'utils/useDocumentAccess';
import { CreditConfirmationDialog } from './CreditConfirmationDialog';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Loader2, FileText, CreditCard } from 'lucide-react';
import { toast } from 'sonner';

export interface DocumentViewerWithCreditsProps {
  documentId: number;
  showSections?: boolean;
  onDocumentLoaded?: (document: any) => void;
  onSectionsLoaded?: (sections: any) => void;
}

export const DocumentViewerWithCredits: React.FC<DocumentViewerWithCreditsProps> = ({
  documentId,
  showSections = false,
  onDocumentLoaded,
  onSectionsLoaded
}) => {
  const [document, setDocument] = useState<any>(null);
  const [sections, setSections] = useState<any>(null);
  
  const {
    isLoading,
    creditConfirmation,
    accessDocument,
    accessDocumentSections,
    confirmCreditAccess,
    cancelCreditAccess,
  } = useDocumentAccess({
    showSuccessToast: true,
  });
  
  const loadDocument = async () => {
    const data = await accessDocument(documentId);
    if (data) {
      setDocument(data);
      if (onDocumentLoaded) {
        onDocumentLoaded(data);
      }
    }
  };
  
  const loadSections = async () => {
    const data = await accessDocumentSections(documentId);
    if (data) {
      setSections(data);
      if (onSectionsLoaded) {
        onSectionsLoaded(data);
      }
    }
  };
  
  useEffect(() => {
    loadDocument();
    if (showSections) {
      loadSections();
    }
  }, [documentId, showSections]);
  
  if (isLoading && !document) {
    return (
      <div className="flex items-center justify-center p-8">
        <Loader2 className="h-8 w-8 animate-spin" />
        <span className="ml-2">Loading document...</span>
      </div>
    );
  }
  
  if (!document && !creditConfirmation) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5" />
            Document Not Available
          </CardTitle>
          <CardDescription>
            This document could not be loaded.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Button onClick={loadDocument} disabled={isLoading}>
            {isLoading ? (
              <Loader2 className="h-4 w-4 animate-spin mr-2" />
            ) : (
              'Retry'
            )}
          </Button>
        </CardContent>
      </Card>
    );
  }
  
  return (
    <>
      {document && (
        <Card>
          <CardHeader>
            <div className="flex items-start justify-between">
              <div>
                <CardTitle className="flex items-center gap-2">
                  <FileText className="h-5 w-5" />
                  {document.title}
                </CardTitle>
                {document.description && (
                  <CardDescription className="mt-2">
                    {document.description}
                  </CardDescription>
                )}
              </div>
              
              <div className="flex gap-2">
                {document.is_premium && (
                  <Badge variant="secondary" className="flex items-center gap-1">
                    <CreditCard className="h-3 w-3" />
                    Premium
                  </Badge>
                )}
                {document.credit_cost > 0 && (
                  <Badge variant="outline">
                    {document.credit_cost} credits
                  </Badge>
                )}
              </div>
            </div>
          </CardHeader>
          
          <CardContent>
            {document.content_html && (
              <div 
                className="prose max-w-none dark:prose-invert" 
                dangerouslySetInnerHTML={{ __html: document.content_html }}
              />
            )}
            
            {document.content_text && !document.content_html && (
              <div className="whitespace-pre-wrap text-sm">
                {document.content_text}
              </div>
            )}
            
            {showSections && sections && (
              <div className="mt-6">
                <h3 className="text-lg font-semibold mb-4">Document Sections</h3>
                <div className="space-y-2">
                  {sections.sections?.map((section: any) => (
                    <div key={section.id} className="border rounded p-3">
                      <h4 className="font-medium">{section.section_title}</h4>
                      {section.section_content && (
                        <p className="text-sm text-muted-foreground mt-1">
                          {section.section_content.substring(0, 200)}...
                        </p>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      )}
      
      {creditConfirmation && (
        <CreditConfirmationDialog
          open={!!creditConfirmation}
          onOpenChange={cancelCreditAccess}
          onConfirm={confirmCreditAccess}
          onCancel={cancelCreditAccess}
          documentTitle={creditConfirmation.documentTitle}
          requiredCredits={creditConfirmation.requiredCredits}
          currentBalance={creditConfirmation.currentBalance}
          isLoading={isLoading}
        />
      )}
    </>
  );
};
