import React, { useState, useEffect } from "react";
import { toast } from "sonner";
import { API_URL } from "app";
import { 
  Plus,
  Search,
  Edit,
  Trash2,
  Eye,
  Upload,
  Download,
  Filter,
  AlertTriangle,
  Shield,
  Globe,
  Building,
  Users,
  Calendar,
  CheckCircle,
  XCircle,
  Clock,
  FileText,
  Settings,
  Loader2,
  Database
} from 'lucide-react';
import brain from 'brain';
import {
  SanctionsListResponse,
  SanctionsListCreate,
  SanctionsListUpdate,
  SanctionsListStats,
  SanctionsListEntryResponse,
  SanctionsListEntryCreate,
  BulkImportRequest
} from 'brain/data-contracts';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { auth } from 'app/auth';

interface SanctionsListManagementProps {
  onRefresh?: () => void;
}

export default function SanctionsListManagement({ onRefresh }: SanctionsListManagementProps) {
  const [activeTab, setActiveTab] = useState('overview');
  const [sanctionsLists, setSanctionsLists] = useState<SanctionsListResponse[]>([]);
  const [stats, setStats] = useState<SanctionsListStats | null>(null);
  const [selectedList, setSelectedList] = useState<SanctionsListResponse | null>(null);
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [showBulkImportDialog, setShowBulkImportDialog] = useState(false);
  const [showViewDialog, setShowViewDialog] = useState(false);
  const [showEntriesDialog, setShowEntriesDialog] = useState(false);
  const [showViewEntriesDialog, setShowViewEntriesDialog] = useState(false);
  const [watchlistEntries, setWatchlistEntries] = useState<any[]>([]);
  const [loadingEntries, setLoadingEntries] = useState(false);
  const [listEntries, setListEntries] = useState<SanctionsListEntryResponse[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [typeFilter, setTypeFilter] = useState('all');
  const [authorityFilter, setAuthorityFilter] = useState('all');
  const [activeFilter, setActiveFilter] = useState('all');
  
  // Pagination state for view entries dialog
  const [currentPage, setCurrentPage] = useState(1);
  const entriesPerPage = 50;
  
  // State variables for form data and dialogs
  const [formData, setFormData] = useState<SanctionsListCreate>({
    name: '',
    description: '',
    list_type: 'sanctions',
    source: '',
    source_url: '',
    authority: '',
    country_jurisdiction: '',
    is_active: true,
    is_official: false,
    update_frequency: 'manual',
    matching_algorithm: 'fuzzy',
    minimum_match_score: 0.80,
    last_list_update: '',
    notes: ''
  });
  
  // Bulk import states
  const [bulkImportData, setBulkImportData] = useState('');
  const [bulkImportMode, setBulkImportMode] = useState<'file' | 'text'>('file');
  const [bulkImportFile, setBulkImportFile] = useState<File | null>(null);
  const [replaceExisting, setReplaceExisting] = useState(false);
  
  // Dropdown options
  const [dropdownOptions, setDropdownOptions] = useState({
    list_types: [],
    entry_types: [],
    risk_levels: [],
    matching_algorithms: [],
    update_frequencies: []
  });
  
  const [xmlFile, setXmlFile] = useState<File | null>(null);
  const [isUploadingXml, setIsUploadingXml] = useState(false);
  
  const [csvFile, setCsvFile] = useState<File | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  
  const [importProgress, setImportProgress] = useState({ current: 0, total: 0, isActive: false });
  
  useEffect(() => {
    loadData();
    loadDropdownOptions();
  }, []);
  
  const loadData = async () => {
    try {
      setLoading(true);
      const [statsResponse, listsResponse] = await Promise.all([
        brain.get_sanctions_list_stats(),
        brain.list_sanctions_lists({ active_only: false, limit: 100, offset: 0 })
      ]);
      
      if (statsResponse.ok) {
        const statsData = await statsResponse.json();
        setStats(statsData);
      }
      
      if (listsResponse.ok) {
        const listsData = await listsResponse.json();
        setSanctionsLists(listsData);
      }
    } catch (error) {
      console.error('Error loading sanctions lists:', error);
      toast.error('Failed to load sanctions lists');
    } finally {
      setLoading(false);
    }
  };
  
  const loadDropdownOptions = async () => {
    try {
      const response = await brain.get_list_types();
      if (response.ok) {
        const options = await response.json();
        setDropdownOptions(options);
      }
    } catch (error) {
      console.error('Error loading dropdown options:', error);
    }
  };
  
  // Load entries for a specific sanctions list
  const loadListEntries = async (listId: string) => {
    try {
      setLoading(true);
      const response = await brain.get_sanctions_list_entries({ 
        listId: parseInt(listId),
        limit: 1000, // Increase limit to get all entries
        offset: 0
      });
      const data = await response.json();
      setListEntries(data || []);
      setCurrentPage(1); // Reset to first page when loading new data
    } catch (error) {
      console.error('Error loading list entries:', error);
      toast.error('Failed to load entries');
    } finally {
      setLoading(false);
    }
  };
  
  const loadWatchlistEntries = async (listName: string) => {
    try {
      setLoadingEntries(true);
      // Use brain client for authenticated API calls
      const response = await brain.search_watchlists({
        search_term: '',
        entity_type: 'all',
        country: '',
        include_inactive: false,
        limit: 100
      });
      
      if (response.ok) {
        const data = await response.json();
        // Extract watchlist_entry from each response object
        const entries = data.map((item: any) => item.watchlist_entry || item);
        // Filter entries by list name if needed
        const filteredEntries = listName ? entries.filter((entry: any) => entry.list_name === listName) : entries;
        setWatchlistEntries(filteredEntries);
      } else {
        const errorData = await response.json().catch(() => ({ detail: 'Failed to load entries' }));
        toast.error(errorData.detail || 'Failed to load watchlist entries');
      }
    } catch (error) {
      console.error('Error loading watchlist entries:', error);
      toast.error('Failed to load watchlist entries');
    } finally {
      setLoadingEntries(false);
    }
  };
  
  const handleCreate = async () => {
    try {
      const response = await brain.create_sanctions_list(formData);
      if (response.ok) {
        toast.success('Sanctions list created successfully');
        setShowCreateDialog(false);
        resetForm();
        loadData();
        onRefresh?.();
      } else {
        const error = await response.json();
        toast.error(error.detail || 'Failed to create sanctions list');
      }
    } catch (error) {
      console.error('Error creating sanctions list:', error);
      toast.error('Failed to create sanctions list');
    }
  };
  
  const handleUpdate = async () => {
    if (!selectedList) return;
    
    try {
      const updateData: SanctionsListUpdate = {
        ...formData
      };
      
      const response = await brain.update_sanctions_list(
        { listId: selectedList.id },
        updateData
      );
      
      if (response.ok) {
        toast.success('Sanctions list updated successfully');
        setShowEditDialog(false);
        resetForm();
        setSelectedList(null);
        loadData();
        onRefresh?.();
      } else {
        const error = await response.json();
        toast.error(error.detail || 'Failed to update sanctions list');
      }
    } catch (error) {
      console.error('Error updating sanctions list:', error);
      toast.error('Failed to update sanctions list');
    }
  };
  
  const handleDelete = async () => {
    if (!selectedList) return;
    
    try {
      const response = await brain.delete_sanctions_list({ listId: selectedList.id });
      if (response.ok) {
        toast.success('Sanctions list deleted successfully');
        setShowDeleteDialog(false);
        setSelectedList(null);
        loadData();
        onRefresh?.();
      } else {
        const error = await response.json();
        toast.error(error.detail || 'Failed to delete sanctions list');
      }
    } catch (error) {
      console.error('Error deleting sanctions list:', error);
      toast.error('Failed to delete sanctions list');
    }
  };
  
  const handleBulkImport = async () => {
    if (!selectedList || (!bulkImportData.trim() && !bulkImportFile)) {
      toast.error('Please select a list and provide data to import');
      return;
    }

    console.log('handleBulkImport started');
    console.log('selectedList:', selectedList);
    console.log('bulkImportMode:', bulkImportMode);
    console.log('bulkImportFile:', bulkImportFile);
    console.log('bulkImportData:', bulkImportData);

    setLoading(true);
    setImportProgress({ current: 0, total: 0, isActive: true });

    try {
      console.log('Starting import process...');
      
      let csvData = '';
      
      if (bulkImportMode === 'file' && bulkImportFile) {
        console.log('Reading file...');
        csvData = await new Promise<string>((resolve, reject) => {
          const reader = new FileReader();
          reader.onload = (e) => resolve(e.target?.result as string);
          reader.onerror = (e) => reject(e);
          reader.readAsText(bulkImportFile);
        });
        console.log('File read successfully, length:', csvData.length);
      } else {
        csvData = bulkImportData;
      }

      console.log('Parsing CSV data...');
      const lines = csvData.split('\n').filter(line => line.trim());
      console.log('Found', lines.length, 'lines');
      
      if (lines.length < 2) {
        toast.error('CSV must contain at least a header row and one data row');
        return;
      }

      // Detect delimiter
      const firstLine = lines[0];
      const commaCount = (firstLine.match(/,/g) || []).length;
      const semicolonCount = (firstLine.match(/;/g) || []).length;
      const delimiter = semicolonCount > commaCount ? ';' : ',';
      console.log('Detected delimiter:', delimiter);

      const headers = lines[0].split(delimiter).map(h => h.trim().replace(/"/g, ''));
      console.log('Headers:', headers);
      
      const entries = [];
      for (let i = 1; i < lines.length; i++) {
        const values = lines[i].split(delimiter).map(v => v.trim().replace(/"/g, ''));
        if (values.length !== headers.length) continue;
        
        const row: Record<string, any> = {};
        headers.forEach((header, index) => {
          row[header] = values[index] || '';
        });
        
        // Map EU format fields to standard format
        const entry = {
          primary_name: row['NameAlias_WholeName'] || row['primary_name'] || row['name'] || '',
          entry_type: (() => {
            const euType = row['Entity_SubjectType'] || row['entry_type'] || row['type'] || 'P';
            // Map EU format to backend expected values
            switch (euType.toUpperCase()) {
              case 'P': return 'individual';
              case 'E': return 'entity';
              case 'INDIVIDUAL': return 'individual';
              case 'ENTITY': return 'entity';
              case 'VESSEL': return 'vessel';
              case 'AIRCRAFT': return 'aircraft';
              case 'ADDRESS': return 'address';
              default: return 'individual';
            }
          })(),
          country: row['Address_CountryDescription'] || row['country'] || null,
          date_of_birth: (() => {
            const dateStr = row['BirthDate_BirthDate'] || row['date_of_birth'] || '';
            return dateStr.trim() ? dateStr : null;
          })(),
          place_of_birth: (() => {
            const placeStr = row['BirthDate_Place'] || row['BirthDate_City'] || row['place_of_birth'] || '';
            return placeStr.trim() ? placeStr : null;
          })(),
          aliases: row['aliases'] ? (Array.isArray(row['aliases']) ? row['aliases'] : [row['aliases']]) : [],
          nationality: (() => {
            const natStr = row['BirthDate_CountryDescription'] || row['nationality'] || '';
            return natStr.trim() ? natStr : null;
          })(),
          passport_numbers: row['passport_numbers'] ? (Array.isArray(row['passport_numbers']) ? row['passport_numbers'] : [row['passport_numbers']]) : [],
          id_numbers: row['Identification_Number'] ? [row['Identification_Number']] : (row['id_numbers'] ? (Array.isArray(row['id_numbers']) ? row['id_numbers'] : [row['id_numbers']]) : []),
          addresses: row['addresses'] ? (Array.isArray(row['addresses']) ? row['addresses'] : [row['addresses']]) : [],
          programs: row['Entity_Regulation_Programme'] ? [row['Entity_Regulation_Programme']] : (row['programs'] ? (Array.isArray(row['programs']) ? row['programs'] : [row['programs']]) : []),
          reasons: (() => {
            const reasonStr = row['Entity_DesignationDetails'] || row['reasons'] || '';
            return reasonStr.trim() ? reasonStr : null;
          })(),
          remarks: (() => {
            const remarkStr = row['Entity_Remark'] || row['remarks'] || '';
            return remarkStr.trim() ? remarkStr : null;
          })(),
          list_date: (() => {
            const listDateStr = row['Entity_DesignationDate'] || row['list_date'] || '';
            return listDateStr.trim() ? listDateStr : null;
          })(),
          modification_date: (() => {
            const modDateStr = row['modification_date'] || '';
            return modDateStr.trim() ? modDateStr : null;
          })(),
          is_active: row['is_active'] !== 'false' && row['is_active'] !== false,
          external_id: (() => {
            const extIdStr = row['Entity_LogicalId'] || row['Entity_EU_ReferenceNumber'] || row['external_id'] || '';
            return extIdStr.trim() ? extIdStr : null;
          })()
        };
        
        // Debug: Log the transformed entry for first few rows
        if (i <= 3) {
          console.log(`DEBUG Row ${i} transformation:`);
          console.log('Raw row data:', { 
            date_of_birth: row['BirthDate_BirthDate'], 
            entry_type: row['Entity_SubjectType'],
            primary_name: row['NameAlias_WholeName']
          });
          console.log('Transformed entry:', {
            date_of_birth: entry.date_of_birth,
            entry_type: entry.entry_type,
            primary_name: entry.primary_name
          });
        }
        
        if (entry.primary_name) {
          entries.push(entry);
        }
      }
      
      console.log('Parsed entries:', entries.length);
      
      if (entries.length === 0) {
        toast.error('No valid entries found in the CSV data');
        return;
      }

      // Split entries into batches of 1000
      const BATCH_SIZE = 1000;
      const batches = [];
      for (let i = 0; i < entries.length; i += BATCH_SIZE) {
        batches.push(entries.slice(i, i + BATCH_SIZE));
      }
      
      console.log(`Processing ${entries.length} entries in ${batches.length} batches of ${BATCH_SIZE}`);
      setImportProgress({ current: 0, total: batches.length, isActive: true });
      
      let totalImported = 0;
      let totalUpdated = 0;
      let totalSkipped = 0;
      let totalErrors: string[] = [];
      
      // Process batches sequentially
      for (let batchIndex = 0; batchIndex < batches.length; batchIndex++) {
        const batch = batches[batchIndex];
        console.log(`Processing batch ${batchIndex + 1}/${batches.length} with ${batch.length} entries`);
        console.log(`About to call brain.bulk_import_entries with listId: ${selectedList.id}`);
        console.log(`Sample entry from batch:`, batch[0]);
        
        setImportProgress({ current: batchIndex + 1, total: batches.length, isActive: true });
        
        try {
          console.log(`Making brain API call for batch ${batchIndex + 1}...`);
          
          const response = await brain.bulk_import_entries(
            { listId: selectedList.id },
            {
              entries: batch,
              replace_existing: batchIndex === 0 ? replaceExisting : false,
              sanctions_list_id: selectedList.id
            }
          );

          console.log('Response status:', response.status, 'ok:', response.ok);
          
          if (!response.ok) {
            const errorText = await response.text();
            console.error('HTTP error response:', errorText);
            throw new Error(`HTTP error! status: ${response.status}`);
          }

          const result = await response.json();
          console.log(`Batch ${batchIndex + 1} result:`, result);
          
          // Always track the imported/updated/skipped counts, regardless of success flag
          const imported = result.imported_count || 0;
          const updated = result.updated_count || 0;
          const skipped = result.skipped_count || 0;
          
          totalImported += imported;
          totalUpdated += updated;
          totalSkipped += skipped;
          
          console.log(`✅ Batch ${batchIndex + 1}: imported ${imported}, updated ${updated}, skipped ${skipped}`);
          console.log(`📊 Running totals: imported ${totalImported}, updated ${totalUpdated}, skipped ${totalSkipped}`);
          
          // Log validation errors but don't stop processing
          if (result.errors && result.errors.length > 0) {
            console.log(`⚠️ Batch ${batchIndex + 1} had ${result.errors.length} validation errors:`);
            console.log(`First 3 errors:`, result.errors.slice(0, 3));
            totalErrors.push(...result.errors.slice(0, 5)); // Keep first 5 errors per batch
          }
          
        } catch (error) {
          console.error('Error in batch', batchIndex + 1, ':', error);
          setImportProgress(prev => ({
            ...prev,
            errors: [...(prev.errors || []), `Batch ${batchIndex + 1}: ${error.message}`]
          }));
          break; // Stop processing on error
        }
      }
      
      setImportProgress({ current: 0, total: 0, isActive: false });
      
      if (totalErrors.length === 0) {
        toast.success(`Successfully imported ${totalImported} entries, updated ${totalUpdated}, skipped ${totalSkipped}`);
      } else if (totalImported > 0 || totalUpdated > 0) {
        toast.warning(`Partially completed: ${totalImported} imported, ${totalUpdated} updated, ${totalSkipped} skipped. ${totalErrors.length} errors occurred.`);
      } else {
        toast.error(`Import failed. ${totalErrors.length} errors occurred.`);
        console.error('Import errors:', totalErrors);
      }
      
      await loadData();
      setShowBulkImportDialog(false);
      setBulkImportData('');
      setBulkImportFile(null);
      
    } catch (error) {
      console.error('Import error:', error);
      toast.error('Failed to import entries: ' + (error instanceof Error ? error.message : 'Unknown error'));
    } finally {
      setLoading(false);
      setImportProgress({ current: 0, total: 0, isActive: false });
    }
  };
  
  const handleXmlUpload = async () => {
    if (!xmlFile) {
      toast.error("Please select an XML file");
      return;
    }

    setIsUploadingXml(true);
    try {
      // Add timeout to prevent hanging
      const timeoutPromise = new Promise((_, reject) => 
        setTimeout(() => reject(new Error('Upload timeout')), 60000)
      );
      
      // Use the brain client correctly with object format
      const uploadPromise = brain.import_xml_sanctions({ file: xmlFile });
      
      const response = await Promise.race([uploadPromise, timeoutPromise]);

      if (response.ok) {
        const result = await response.json();
        toast.success(`XML import completed: ${result.imported_count} entries imported, ${result.updated_count} updated`);
        if (result.errors && result.errors.length > 0) {
          console.warn('Import warnings:', result.errors);
          toast.warning(`Import completed with ${result.errors.length} warnings`);
        }
        setXmlFile(null);
        loadData(); // Reload the sanctions lists data
      } else {
        const errorData = await response.json();
        throw new Error(errorData.detail || "XML import failed");
      }
    } catch (error) {
      console.error('XML upload error:', error);
      if (error.message === 'Upload timeout') {
        toast.error("Upload timed out. Please try again with a smaller file.");
      } else {
        toast.error(`XML upload failed: ${error.message}`);
      }
    } finally {
      setIsUploadingXml(false);
    }
  };
  
  const handleCsvImport = async () => {
    if (!csvFile) {
      toast.error("Please select a CSV file");
      return;
    }

    setIsUploading(true);
    try {
      const formData = new FormData();
      formData.append("file", csvFile);

      const response = await fetch(`${API_URL}/sanctions-list-management/import-csv`, {
        method: "POST",
        body: formData,
        credentials: "include",
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.detail || "Upload failed");
      }

      const result = await response.json();
      toast.success(`Successfully imported ${result.imported_count} sanctions entries`);
      
      if (result.errors && result.errors.length > 0) {
        console.warn("Import errors:", result.errors);
        toast.warning(`Imported with ${result.errors.length} warnings - check console for details`);
      }

      // Reset form and reload data
      setCsvFile(null);
      loadData();
    } catch (error) {
      console.error("CSV upload error:", error);
      toast.error(error instanceof Error ? error.message : "Failed to upload CSV file");
    } finally {
      setIsUploading(false);
    }
  };
  
  const openCreateDialog = () => {
    resetForm();
    setShowCreateDialog(true);
  };
  
  const openEditDialog = (list: SanctionsListResponse) => {
    setSelectedList(list);
    setFormData({
      name: list.name,
      description: list.description || '',
      list_type: list.list_type,
      source: list.source || '',
      source_url: list.source_url || '',
      authority: list.authority || '',
      country_jurisdiction: list.country_jurisdiction || '',
      is_active: list.is_active,
      is_official: list.is_official,
      update_frequency: list.update_frequency,
      matching_algorithm: list.matching_algorithm,
      minimum_match_score: list.minimum_match_score,
      last_list_update: list.last_list_update || '',
      notes: list.notes || ''
    });
    setShowEditDialog(true);
  };
  
  const openDeleteDialog = (list: SanctionsListResponse) => {
    setSelectedList(list);
    setShowDeleteDialog(true);
  };
  
  const openViewDialog = (list: SanctionsListResponse) => {
    setSelectedList(list);
    setShowViewDialog(true);
  };
  
  const openEntriesDialog = (list: SanctionsListResponse) => {
    setSelectedList(list);
    loadListEntries(list.id);
    setShowEntriesDialog(true);
  };
  
  const openBulkImportDialog = (list: SanctionsListResponse) => {
    setSelectedList(list);
    setShowBulkImportDialog(true);
  };
  
  const openViewEntriesDialog = async (list: SanctionsListResponse) => {
    setSelectedList(list);
    setShowViewEntriesDialog(true);
    await loadListEntries(list.id);
  };
  
  // Calculate pagination data for view entries dialog
  const totalEntries = listEntries.length;
  const totalPages = Math.ceil(totalEntries / entriesPerPage);
  const startIndex = (currentPage - 1) * entriesPerPage;
  const endIndex = startIndex + entriesPerPage;
  const currentEntries = listEntries.slice(startIndex, endIndex);

  const handlePageChange = (page: number) => {
    setCurrentPage(page);
  };
  
  const resetForm = () => {
    setFormData({
      name: '',
      description: '',
      list_type: 'sanctions',
      source: '',
      source_url: '',
      authority: '',
      country_jurisdiction: '',
      is_active: true,
      is_official: false,
      update_frequency: 'manual',
      matching_algorithm: 'fuzzy',
      minimum_match_score: 0.80,
      last_list_update: '',
      notes: ''
    });
  };
  
  const filteredLists = sanctionsLists.filter(list => {
    const matchesSearch = list.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         (list.description && list.description.toLowerCase().includes(searchQuery.toLowerCase())) ||
                         (list.authority && list.authority.toLowerCase().includes(searchQuery.toLowerCase()));
    
    const matchesType = typeFilter === 'all' || list.list_type === typeFilter;
    const matchesAuthority = authorityFilter === 'all' || list.authority === authorityFilter;
    const matchesActive = activeFilter === 'all' || 
                         (activeFilter === 'active' && list.is_active) ||
                         (activeFilter === 'inactive' && !list.is_active);
    
    return matchesSearch && matchesType && matchesAuthority && matchesActive;
  });
  
  const getListTypeIcon = (type: string) => {
    switch (type) {
      case 'sanctions': return <Shield className="h-4 w-4" />;
      case 'watchlist': return <Eye className="h-4 w-4" />;
      case 'denied_persons': return <AlertTriangle className="h-4 w-4" />;
      case 'export_control': return <Database className="h-4 w-4" />;
      case 'terrorism': return <AlertTriangle className="h-4 w-4" />;
      case 'pep': return <Users className="h-4 w-4" />;
      default: return <FileText className="h-4 w-4" />;
    }
  };
  
  const getRiskLevelColor = (level: string) => {
    switch (level) {
      case 'low': return 'bg-green-500/20 text-green-300 border-green-500';
      case 'medium': return 'bg-yellow-500/20 text-yellow-300 border-yellow-500';
      case 'high': return 'bg-orange-500/20 text-orange-300 border-orange-500';
      case 'critical': return 'bg-red-500/20 text-red-300 border-red-500';
      default: return 'bg-gray-500/20 text-gray-300 border-gray-500';
    }
  };
  
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-white mb-1">Sanctions List Management</h2>
          <p className="text-gray-400">Manage sanctions lists and watchlists for customer screening</p>
        </div>
        <Button 
          onClick={openCreateDialog}
          className="bg-blue-600 hover:bg-blue-700 text-white"
        >
          <Plus className="h-4 w-4 mr-2" />
          Add Sanctions List
        </Button>
      </div>
      
      {/* Main Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="bg-gray-800 border-gray-700">
          <TabsTrigger value="overview" className="data-[state=active]:bg-gray-700 text-white">
            <Database className="h-4 w-4 mr-2" />
            Overview
          </TabsTrigger>
          <TabsTrigger value="lists" className="data-[state=active]:bg-gray-700 text-white">
            <Shield className="h-4 w-4 mr-2" />
            Sanctions Lists
          </TabsTrigger>
          <TabsTrigger value="configuration" className="data-[state=active]:bg-gray-700 text-white">
            <Settings className="h-4 w-4 mr-2" />
            Configuration
          </TabsTrigger>
        </TabsList>
        
        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-6">
          {stats && (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <Card className="bg-gradient-to-br from-blue-600/20 to-blue-800/20 border-blue-600/30">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-blue-200 text-sm">Total Lists</p>
                      <p className="text-2xl font-bold text-white">{stats.total_lists}</p>
                    </div>
                    <Database className="h-8 w-8 text-blue-400" />
                  </div>
                </CardContent>
              </Card>
              
              <Card className="bg-gradient-to-br from-green-600/20 to-green-800/20 border-green-600/30">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-green-200 text-sm">Active Lists</p>
                      <p className="text-2xl font-bold text-white">{stats.active_lists}</p>
                    </div>
                    <CheckCircle className="h-8 w-8 text-green-400" />
                  </div>
                </CardContent>
              </Card>
              
              <Card className="bg-gradient-to-br from-purple-600/20 to-purple-800/20 border-purple-600/30">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-purple-200 text-sm">Official Lists</p>
                      <p className="text-2xl font-bold text-white">{stats.official_lists}</p>
                    </div>
                    <Shield className="h-8 w-8 text-purple-400" />
                  </div>
                </CardContent>
              </Card>
              
              <Card className="bg-gradient-to-br from-amber-600/20 to-amber-800/20 border-amber-600/30">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-amber-200 text-sm">Total Entries</p>
                      <p className="text-2xl font-bold text-white">{stats.total_entries}</p>
                    </div>
                    <Users className="h-8 w-8 text-amber-400" />
                  </div>
                </CardContent>
              </Card>
            </div>
          )}
          
          {/* Distribution Charts */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Lists by Type */}
            <Card className="bg-gray-800/50 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white text-lg">Listsby Type</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {stats && stats.lists_by_type && Object.entries(stats.lists_by_type).map(([type, count]) => (
                    <div key={type} className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        {getListTypeIcon(type)}
                        <span className="text-gray-300 capitalize">{type.replace('_', ' ')}</span>
                      </div>
                      <Badge variant="outline" className="text-white">{count}</Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
            
            {/* Lists by Authority */}
            <Card className="bg-gray-800/50 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white text-lg">Listsby Authority</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {stats && stats.lists_by_authority && Object.entries(stats.lists_by_authority).map(([authority, count]) => (
                    <div key={authority} className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Globe className="h-4 w-4" />
                        <span className="text-gray-300">{authority}</span>
                      </div>
                      <Badge variant="outline" className="text-white">{count}</Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
            
            {/* Lists by Risk Level */}
            <Card className="bg-gray-800/50 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white text-lg">Listsby Risk Level</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {stats && stats.lists_by_risk_level && Object.entries(stats.lists_by_risk_level).map(([level, count]) => (
                    <div key={level} className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <AlertTriangle className="h-4 w-4" />
                        <span className="text-gray-300 capitalize">{level}</span>
                      </div>
                      <Badge className={getRiskLevelColor(level)}>{count}</Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        
        {/* Lists Tab */}
        <TabsContent value="lists" className="space-y-6">
          {/* Search and Filters */}
          <Card className="bg-gray-800/50 border-gray-700">
            <CardContent className="p-4">
              <div className="flex flex-col lg:flex-row gap-4">
                <div className="flex-1">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                    <Input
                      placeholder="Search lists by name, description, or authority..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="pl-10 bg-gray-700 border-gray-600 text-white"
                    />
                  </div>
                </div>
                
                <div className="flex gap-2">
                  <Select value={typeFilter} onValueChange={setTypeFilter}>
                    <SelectTrigger className="w-40 bg-gray-700 border-gray-600 text-white">
                      <SelectValue placeholder="Type" />
                    </SelectTrigger>
                    <SelectContent className="bg-gray-800 border-gray-600">
                      <SelectItem value="all">All Types</SelectItem>
                      {dropdownOptions.list_types.map((type: any) => (
                        <SelectItem key={type.value} value={type.value}>{type.label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  
                  <Select value={authorityFilter} onValueChange={setAuthorityFilter}>
                    <SelectTrigger className="w-40 bg-gray-700 border-gray-600 text-white">
                      <SelectValue placeholder="Authority" />
                    </SelectTrigger>
                    <SelectContent className="bg-gray-800 border-gray-600">
                      <SelectItem value="all">All Authorities</SelectItem>
                      {stats && stats.lists_by_authority && Object.keys(stats.lists_by_authority).map(authority => (
                        <SelectItem key={authority} value={authority}>{authority}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  
                  <Select value={activeFilter} onValueChange={setActiveFilter}>
                    <SelectTrigger className="w-32 bg-gray-700 border-gray-600 text-white">
                      <SelectValue placeholder="Status" />
                    </SelectTrigger>
                    <SelectContent className="bg-gray-800 border-gray-600">
                      <SelectItem value="all">All</SelectItem>
                      <SelectItem value="active">Active</SelectItem>
                      <SelectItem value="inactive">Inactive</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
          </Card>
          
          {/* Lists Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-4">
            {loading ? (
              Array.from({ length: 6 }).map((_, i) => (
                <Card key={i} className="bg-gray-800/50 border-gray-700 animate-pulse">
                  <CardContent className="p-4">
                    <div className="h-4 bg-gray-700 rounded mb-2"></div>
                    <div className="h-3 bg-gray-700 rounded mb-4"></div>
                    <div className="flex gap-2 mb-1">
                      <div className="h-6 w-16 bg-gray-700 rounded"></div>
                      <div className="h-6 w-20 bg-gray-700 rounded"></div>
                    </div>
                    <div className="flex justify-between items-center">
                      <div className="h-4 w-24 bg-gray-700 rounded"></div>
                      <div className="flex gap-1">
                        <div className="h-8 w-8 bg-gray-700 rounded"></div>
                        <div className="h-8 w-8 bg-gray-700 rounded"></div>
                        <div className="h-8 w-8 bg-gray-700 rounded"></div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            ) : filteredLists.length === 0 ? (
              <div className="col-span-full text-center py-12">
                <Database className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-400 text-lg mb-2">No sanctions lists found</p>
                <p className="text-gray-500 mb-4">Create your first sanctions list to get started</p>
                <Button onClick={openCreateDialog} className="bg-blue-600 hover:bg-blue-700">
                  <Plus className="h-4 w-4 mr-2" />
                  Add Sanctions List
                </Button>
              </div>
            ) : (
              filteredLists.map((list) => (
                <Card key={list.id} className="bg-gray-800/50 border-gray-700 hover:border-gray-600 transition-colors">
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex items-center gap-2">
                        {getListTypeIcon(list.list_type)}
                        <h3 className="font-semibold text-white truncate">{list.name}</h3>
                      </div>
                      <Badge 
                        className={list.is_active 
                          ? 'bg-green-500/20 text-green-300 border-green-500' 
                          : 'bg-gray-500/20 text-gray-300 border-gray-500'
                        }
                      >
                        {list.is_active ? 'Active' : 'Inactive'}
                      </Badge>
                    </div>
                    
                    {list.description && (
                      <p className="text-sm text-gray-400 mb-3 line-clamp-2">{list.description}</p>
                    )}
                    
                    <div className="flex flex-wrap gap-2 mb-4">
                      {list.authority && (
                        <Badge variant="outline" className="text-gray-300">
                          {list.authority}
                        </Badge>
                      )}
                    </div>
                    
                    <div className="flex items-center justify-between text-sm text-gray-400 mb-4">
                      <span>{list.total_entries} entries</span>
                      <span>Updated {new Date(list.updated_at).toLocaleDateString()}</span>
                    </div>
                    
                    {/* Last List Update Info */}
                    {list.last_list_update && (
                      <div className="flex items-center gap-2 text-sm text-amber-300 mb-3 bg-amber-500/10 rounded px-2 py-1">
                        <Clock className="h-3 w-3" />
                        <span>List Updated: {new Date(list.last_list_update).toLocaleDateString()}</span>
                      </div>
                    )}
                    
                    <div className="flex justify-between items-center">
                      <div className="flex gap-1">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => openViewDialog(list)}
                          className="text-gray-400 hover:text-white p-1 h-8 w-8"
                        >
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => openViewEntriesDialog(list)}
                          className="text-gray-400 hover:text-white p-1 h-8 w-8"
                        >
                          <Users className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => openEditDialog(list)}
                          className="text-gray-400 hover:text-white p-1 h-8 w-8"
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => openBulkImportDialog(list)}
                          className="text-gray-400 hover:text-white p-1 h-8 w-8"
                        >
                          <Upload className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => openDeleteDialog(list)}
                          className="text-gray-400 hover:text-red-400 p-1 h-8 w-8"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        </TabsContent>
        
        {/* Configuration Tab */}
        <TabsContent value="configuration" className="space-y-6">
          <Card className="bg-gray-800/50 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white">Global Screening Configuration</CardTitle>
              <CardDescription className="text-gray-400">
                Configure global settings for sanctions list screening
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label className="text-white font-medium">Default Matching Algorithm</Label>
                  <Select defaultValue="fuzzy">
                    <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-gray-800 border-gray-600">
                      {dropdownOptions.matching_algorithms.map((algo: any) => (
                        <SelectItem key={algo.value} value={algo.value}>{algo.label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <Label className="text-white font-medium">Default Match Threshold</Label>
                  <Input
                    type="number"
                    min="0"
                    max="1"
                    step="0.01"
                    defaultValue="0.80"
                    className="bg-gray-700 border-gray-600 text-white"
                  />
                </div>
              </div>
              
              <div className="space-y-4">
                <div className="flex items-center space-x-2">
                  <Checkbox id="auto-update" defaultChecked />
                  <Label htmlFor="auto-update" className="text-white">
                    Enable automatic list updates
                  </Label>
                </div>
                
                <div className="flex items-center space-x-2">
                  <Checkbox id="real-time-screening" defaultChecked />
                  <Label htmlFor="real-time-screening" className="text-white">
                    Enable real-time screening
                  </Label>
                </div>
                
                <div className="flex items-center space-x-2">
                  <Checkbox id="detailed-logging" />
                  <Label htmlFor="detailed-logging" className="text-white">
                    Enable detailed screening logs
                  </Label>
                </div>
              </div>
              
              <div className="flex justify-end pt-4">
                <Button className="bg-blue-600 hover:bg-blue-700">
                  Save Configuration
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
      
      {/* Create/Edit Dialog */}
      <Dialog open={showCreateDialog || showEditDialog} onOpenChange={(open) => {
        if (!open) {
          setShowCreateDialog(false);
          setShowEditDialog(false);
          resetForm();
          setSelectedList(null);
        }
      }}>
        <DialogContent className="bg-gray-900 border-gray-700 text-white max-w-2xl max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{showCreateDialog ? 'Create Sanctions List' : 'Edit Sanctions List'}</DialogTitle>
            <DialogDescription className="text-gray-400">
              {showCreateDialog ? 'Add a new sanctions list for screening.' : 'Update the sanctions list details.'}
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            {/* Basic Information */}
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="text-white font-medium">Name *</Label>
                <Input
                  value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                  placeholder="List name"
                  className="bg-gray-800 border-gray-600 text-white"
                />
              </div>
              <div>
                <Label className="text-white font-medium">List Type *</Label>
                <Select value={formData.list_type} onValueChange={(value) => setFormData({...formData, list_type: value})}>
                  <SelectTrigger className="bg-gray-800 border-gray-600 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-gray-800 border-gray-600">
                    {dropdownOptions.list_types.map((type: any) => (
                      <SelectItem key={type.value} value={type.value}>{type.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <div>
              <Label className="text-white font-medium">Description</Label>
              <Textarea
                value={formData.description}
                onChange={(e) => setFormData({...formData, description: e.target.value})}
                placeholder="Brief description of the list"
                className="bg-gray-800 border-gray-600 text-white"
                rows={3}
              />
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="text-white font-medium">Authority</Label>
                <Input
                  value={formData.authority}
                  onChange={(e) => setFormData({...formData, authority: e.target.value})}
                  placeholder="i.e., OFAC, EU, UN"
                  className="bg-gray-800 border-gray-600 text-white"
                />
              </div>
              <div>
                <Label className="text-white font-medium">Country/Jurisdiction</Label>
                <Input
                  value={formData.country_jurisdiction}
                  onChange={(e) => setFormData({...formData, country_jurisdiction: e.target.value})}
                  placeholder="i.e., United States, European Union"
                  className="bg-gray-800 border-gray-600 text-white"
                />
              </div>
            </div>
            
            <div className="grid grid-cols-1 gap-4">
              <div>
                <Label className="text-white font-medium">Source</Label>
                <Input
                  value={formData.source}
                  onChange={(e) => setFormData({...formData, source: e.target.value})}
                  placeholder="Source name"
                  className="bg-gray-800 border-gray-600 text-white"
                />
              </div>
              <div>
                <Label className="text-white font-medium">Source URL</Label>
                <Input
                  value={formData.source_url}
                  onChange={(e) => setFormData({...formData, source_url: e.target.value})}
                  placeholder="https://..."
                  className="bg-gray-800 border-gray-600 text-white"
                />
              </div>
            </div>
            
            <div className="grid grid-cols-3 gap-4">
              <div>
                <Label className="text-white font-medium">Matching Algorithm</Label>
                <Select value={formData.matching_algorithm} onValueChange={(value) => setFormData({...formData, matching_algorithm: value})}>
                  <SelectTrigger className="bg-gray-800 border-gray-600 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-gray-800 border-gray-600">
                    {dropdownOptions.matching_algorithms.map((algo: any) => (
                      <SelectItem key={algo.value} value={algo.value}>{algo.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-white font-medium">Update Frequency</Label>
                <Select value={formData.update_frequency} onValueChange={(value) => setFormData({...formData, update_frequency: value})}>
                  <SelectTrigger className="bg-gray-800 border-gray-600 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-gray-800 border-gray-600">
                    {dropdownOptions.update_frequencies.map((freq: any) => (
                      <SelectItem key={freq.value} value={freq.value}>{freq.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <div>
              <Label className="text-white font-medium">Minimum Match Score</Label>
              <Input
                type="number"
                min="0"
                max="1"
                step="0.01"
                value={formData.minimum_match_score}
                onChange={(e) => setFormData({...formData, minimum_match_score: parseFloat(e.target.value) || 0})}
                className="bg-gray-800 border-gray-600 text-white"
              />
            </div>
            
            <div>
              <Label className="text-white font-medium">Last List Update</Label>
              <Input
                type="date"
                value={formData.last_list_update}
                onChange={(e) => setFormData({...formData, last_list_update: e.target.value})}
                className="bg-gray-800 border-gray-600 text-white"
              />
            </div>
            
            <div className="space-y-4">
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="is_active" 
                  checked={formData.is_active}
                  onCheckedChange={(checked) => setFormData({...formData, is_active: checked as boolean})}
                />
                <Label htmlFor="is_active" className="text-white">
                  Active (enable for screening)
                </Label>
              </div>
              
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="is_official" 
                  checked={formData.is_official}
                  onCheckedChange={(checked) => setFormData({...formData, is_official: checked as boolean})}
                />
                <Label htmlFor="is_official" className="text-white">
                  Official government list
                </Label>
              </div>
            </div>
            
            <div>
              <Label className="text-white font-medium">Notes</Label>
              <Textarea
                value={formData.notes}
                onChange={(e) => setFormData({...formData, notes: e.target.value})}
                placeholder="Additional notes or comments"
                className="bg-gray-800 border-gray-600 text-white"
                rows={3}
              />
            </div>
          </div>
          
          <div className="flex justify-end space-x-3 pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={() => {
                console.log('Cancel button clicked');
                setShowCreateDialog(false);
                setShowEditDialog(false);
                resetForm();
                setSelectedList(null);
              }}
              className="border-gray-600 text-gray-300 hover:bg-gray-700 transition-all duration-200 hover:scale-105"
            >
              Cancel
            </Button>
            <Button
              type="button"
              onClick={showCreateDialog ? handleCreate : handleUpdate}
              className="bg-blue-600 hover:bg-blue-700 text-white transition-all duration-200 hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:scale-100"
            >
              {showCreateDialog ? 'Create' : 'Update'} List
            </Button>
          </div>
        </DialogContent>
      </Dialog>
      
      {/* View Dialog */}
      <Dialog open={showViewDialog} onOpenChange={setShowViewDialog}>
        <DialogContent className="bg-gray-900 border-gray-700 text-white max-w-2xl">
          <DialogHeader>
            <DialogTitle>Sanctions List Details</DialogTitle>
          </DialogHeader>
          {selectedList && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-gray-400">Name</Label>
                  <p className="text-white font-medium">{selectedList.name}</p>
                </div>
                <div>
                  <Label className="text-gray-400">Type</Label>
                  <div className="flex items-center gap-2">
                    {getListTypeIcon(selectedList.list_type)}
                    <p className="text-white capitalize">{selectedList.list_type.replace('_', ' ')}</p>
                  </div>
                </div>
              </div>
              
              {selectedList.description && (
                <div>
                  <Label className="text-gray-400">Description</Label>
                  <p className="text-white">{selectedList.description}</p>
                </div>
              )}
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-gray-400">Authority</Label>
                  <p className="text-white">{selectedList.authority || 'Not specified'}</p>
                </div>
                <div>
                  <Label className="text-gray-400">Country/Jurisdiction</Label>
                  <p className="text-white">{selectedList.country_jurisdiction || 'Not specified'}</p>
                </div>
              </div>
              
              <div className="grid grid-cols-3 gap-4">
                <div>
                  <Label className="text-gray-400">Risk Level</Label>
                  <Badge className={getRiskLevelColor(selectedList.risk_level)}>
                    {selectedList.risk_level.toUpperCase()}
                  </Badge>
                </div>
                <div>
                  <Label className="text-gray-400">Total Entries</Label>
                  <p className="text-white font-bold">{selectedList.total_entries}</p>
                </div>
                <div>
                  <Label className="text-gray-400">Status</Label>
                  <Badge className={selectedList.is_active 
                    ? 'bg-green-500/20 text-green-300 border-green-500' 
                    : 'bg-gray-500/20 text-gray-300 border-gray-500'}>
                    {selectedList.is_active ? 'Active' : 'Inactive'}
                  </Badge>
                </div>
              </div>
              
              {selectedList.source && (
                <div>
                  <Label className="text-gray-400">Source</Label>
                  <p className="text-white">{selectedList.source}</p>
                  {selectedList.source_url && (
                    <a 
                      href={selectedList.source_url} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="text-blue-400 hover:text-blue-300 text-sm"
                    >
                      View Source →
                    </a>
                  )}
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
      
      {/* Delete Confirmation Dialog */}
      <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <AlertDialogContent className="bg-gray-900 border-gray-700">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-white">Delete Sanctions List</AlertDialogTitle>
            <AlertDialogDescription className="text-gray-400">
              Are you sure you want to delete "{selectedList?.name}"? This action cannot be undone and will remove all entries in this list.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="border-gray-600 text-gray-300 hover:bg-gray-700">
              Cancel
            </AlertDialogCancel>
            <AlertDialogAction 
              onClick={handleDelete}
              className="bg-red-600 hover:bg-red-700 text-white"
            >
              Delete List
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
      
      {/* Bulk Import Dialog */}
      <Dialog open={showBulkImportDialog} onOpenChange={setShowBulkImportDialog}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="text-white">Bulk Import Entries</DialogTitle>
            <DialogDescription className="text-gray-400">
              Import multiple entries into {selectedList?.name}. You can upload a CSV file or paste CSV data.
            </DialogDescription>
          </DialogHeader>
          
          {importProgress.isActive && (
            <div className="mb-4 p-4 bg-blue-900/20 border border-blue-500/30 rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-blue-300">Processing batches...</span>
                <span className="text-sm text-blue-300">{importProgress.current}/{importProgress.total}</span>
              </div>
              <div className="w-full bg-gray-700 rounded-full h-2">
                <div 
                  className="bg-blue-500 h-2 rounded-full transition-all duration-300" 
                  style={{ width: `${(importProgress.current / importProgress.total) * 100}%` }}
                ></div>
              </div>
              <p className="text-xs text-gray-400 mt-1">
                Processing in batches of 1000 entries to ensure reliable import
              </p>
            </div>
          )}

          <div className="space-y-4">
            {/* Mode Selection Tabs */}
            <div className="flex space-x-1 bg-gray-800/50 rounded-lg p-1">
              <button
                type="button"
                onClick={() => {
                  console.log('Upload File button clicked');
                  setBulkImportMode('file');
                }}
                className={`flex-1 px-3 py-2 rounded-md text-sm font-medium transition-all duration-200 ${
                  bulkImportMode === 'file'
                    ? 'bg-blue-600 text-white shadow-sm transform scale-105'
                    : 'text-gray-400 hover:text-white hover:bg-gray-700 hover:scale-105'
                }`}
              >
                <Upload className="h-4 w-4 inline mr-2" />
                Upload File
              </button>
              <button
                type="button"
                onClick={() => {
                  console.log('Paste Text button clicked');
                  setBulkImportMode('text');
                }}
                className={`flex-1 px-3 py-2 rounded-md text-sm font-medium transition-all duration-200 ${
                  bulkImportMode === 'text'
                    ? 'bg-blue-600 text-white shadow-sm transform scale-105'
                    : 'text-gray-400 hover:text-white hover:bg-gray-700 hover:scale-105'
                }`}
              >
                <FileText className="h-4 w-4 inline mr-2" />
                Paste Text
              </button>
            </div>

            {/* File Upload Mode */}
            {bulkImportMode === 'file' && (
              <div className="space-y-3">
                <div>
                  <Label className="text-white font-medium">CSV File</Label>
                  <Input
                    type="file"
                    accept=".csv"
                    onChange={(e) => setBulkImportFile(e.target.files?.[0] || null)}
                    className="bg-gray-800 border-gray-600 text-white file:bg-gray-700 file:border-gray-600 file:text-white"
                  />
                  {bulkImportFile && (
                    <p className="text-sm text-gray-400 mt-1">
                      Selected: {bulkImportFile.name} ({Math.round(bulkImportFile.size / 1024)} KB)
                    </p>
                  )}
                </div>
              </div>
            )}

            {/* Text Paste Mode */}
            {bulkImportMode === 'text' && (
              <div>
                <Label className="text-white font-medium">CSV Data</Label>
                <Textarea
                  value={bulkImportData}
                  onChange={(e) => setBulkImportData(e.target.value)}
                  placeholder="primary_name,entry_type,aliases,nationality,programs\nJohn Doe,individual,Johnny;J.Doe,US,SDN Program\nExample Corp,entity,Example Company,US,Export Control"
                  className="bg-gray-800 border-gray-600 text-white font-mono"
                  rows={8}
                />
              </div>
            )}
            
            <div className="flex items-center space-x-2">
              <Checkbox 
                id="replace_existing" 
                checked={replaceExisting}
                onCheckedChange={(checked) => setReplaceExisting(checked as boolean)}
              />
              <Label htmlFor="replace_existing" className="text-white">
                Replace existing entries
              </Label>
            </div>
            
            <div className="bg-gray-800/50 rounded-lg p-4">
              <h4 className="text-white font-medium mb-2">CSV Format Guidelines:</h4>
              <ul className="text-sm text-gray-400 space-y-1">
                <li>• Required: primary_name, entry_type</li>
                <li>• Optional: aliases, nationality, programs, addresses, reasons</li>
                <li>• Separate multiple values with semicolons (;)</li>
                <li>• Entry types: individual, entity, vessel, aircraft, address</li>
              </ul>
            </div>
          </div>
          
          <div className="flex justify-end space-x-3 pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={() => {
                console.log('Cancel button clicked');
                setShowBulkImportDialog(false);
                setBulkImportData('');
                setBulkImportFile(null);
                setReplaceExisting(false);
              }}
              className="border-gray-600 text-gray-300 hover:bg-gray-700 transition-all duration-200 hover:scale-105"
            >
              Cancel
            </Button>
            <Button
              type="button"
              onClick={() => {
                console.log('Import Entries button clicked');
                handleBulkImport();
              }}
              disabled={bulkImportMode === 'file' ? !bulkImportFile : !bulkImportData.trim()}
              className="bg-blue-600 hover:bg-blue-700 text-white transition-all duration-200 hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:scale-100"
            >
              {loading ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Importing...
                </>
              ) : (
                'Import Entries'
              )}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
      
      {/* Entries Dialog */}
      <Dialog open={showEntriesDialog} onOpenChange={setShowEntriesDialog}>
        <DialogContent className="bg-gray-900 border-gray-700 text-white max-w-4xl max-h-[85vh]">
          <DialogHeader>
            <DialogTitle>List Entries - {selectedList?.name}</DialogTitle>
            <DialogDescription className="text-gray-400">
              View and manage entries in this sanctions list
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 max-h-[60vh] overflow-y-auto">
            {listEntries.length === 0 ? (
              <div className="text-center py-8">
                <Users className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-400">No entries found in this list</p>
              </div>
            ) : (
              <div className="space-y-3">
                {listEntries.map((entry) => (
                  <Card key={entry.id} className="bg-gray-800/50 border-gray-700">
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            {entry.entry_type === 'individual' && <Users className="h-4 w-4" />}
                            {entry.entry_type === 'entity' && <Building className="h-4 w-4" />}
                            {entry.entry_type === 'vessel' && <Ship className="h-4 w-4" />}
                            {entry.entry_type === 'aircraft' && <Plane className="h-4 w-4" />}
                            <h4 className="font-semibold text-white">{entry.primary_name}</h4>
                            <Badge variant="outline" className="text-xs capitalize">
                              {entry.entry_type}
                            </Badge>
                          </div>
                          
                          {entry.aliases.length > 0 && (
                            <p className="text-sm text-gray-400 mb-1">
                              <span className="font-medium">Aliases:</span> {entry.aliases.join(', ')}
                            </p>
                          )}
                          
                          {entry.nationality && (
                            <p className="text-sm text-gray-400 mb-1">
                              <span className="font-medium">Nationality:</span> {entry.nationality}
                            </p>
                          )}
                          
                          {entry.programs.length > 0 && (
                            <div className="flex flex-wrap gap-1 mt-2">
                              {entry.programs.map((program, index) => (
                                <Badge key={index} className="bg-red-500/20 text-red-300 text-xs">
                                  {program}
                                </Badge>
                              ))}
                            </div>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>
      
      {/* XML Upload Dialog */}
      <Dialog open={showEntriesDialog} onOpenChange={setShowEntriesDialog}>
        <DialogContent className="bg-gray-900 border-gray-700 text-white max-w-4xl max-h-[85vh]">
          <DialogHeader>
            <DialogTitle>XML Upload</DialogTitle>
            <DialogDescription className="text-gray-400">
              Upload an XML file to import sanctions entries.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 max-h-[60vh] overflow-y-auto">
            <div className="flex items-center justify-between">
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <Input
                    placeholder="Search lists by name, description, or authority..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10 bg-gray-700 border-gray-600 text-white"
                  />
                </div>
              </div>
              
              <div className="flex gap-2">
                <Select value={typeFilter} onValueChange={setTypeFilter}>
                  <SelectTrigger className="w-40 bg-gray-700 border-gray-600 text-white">
                    <SelectValue placeholder="Type" />
                  </SelectTrigger>
                  <SelectContent className="bg-gray-800 border-gray-600">
                    <SelectItem value="all">All Types</SelectItem>
                    {dropdownOptions.list_types.map((type: any) => (
                      <SelectItem key={type.value} value={type.value}>{type.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                
                <Select value={authorityFilter} onValueChange={setAuthorityFilter}>
                  <SelectTrigger className="w-40 bg-gray-700 border-gray-600 text-white">
                    <SelectValue placeholder="Authority" />
                  </SelectTrigger>
                  <SelectContent className="bg-gray-800 border-gray-600">
                    <SelectItem value="all">All Authorities</SelectItem>
                    {stats && stats.lists_by_authority && Object.keys(stats.lists_by_authority).map(authority => (
                      <SelectItem key={authority} value={authority}>{authority}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                
                <Select value={activeFilter} onValueChange={setActiveFilter}>
                  <SelectTrigger className="w-32 bg-gray-700 border-gray-600 text-white">
                    <SelectValue placeholder="Status" />
                  </SelectTrigger>
                  <SelectContent className="bg-gray-800 border-gray-600">
                    <SelectItem value="all">All</SelectItem>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="inactive">Inactive</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <div className="flex items-center justify-between">
              <div className="flex-1">
                <Label className="text-white font-medium">XML File</Label>
                <Input
                  type="file"
                  accept=".xml"
                  key={`xml-input-${Date.now()}`}
                  onChange={(e) => {
                    const file = e.target.files?.[0] || null;
                    console.log('🔍 XML onChange - file:', file?.name);
                    setXmlFile(file);
                  }}
                  className="bg-slate-700/50 border-slate-600 text-slate-200"
                />
              </div>
            </div>
            
            <div className="flex justify-end space-x-3 pt-4">
              <Button
                variant="outline"
                onClick={() => {
                  setShowEntriesDialog(false);
                  setXmlFile(null);
                }}
                className="border-gray-600 text-gray-300 hover:bg-gray-700"
              >
                Cancel
              </Button>
              <Button
                onClick={handleXmlUpload}
                disabled={!xmlFile}
                className="bg-blue-600 hover:bg-blue-700 text-white"
              >
                Upload XML
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
      
      {/* Bulk Import Section */}
      <Card className="bg-slate-800/50 border-slate-700/50">
        <CardHeader>
          <CardTitle className="text-blue-400 flex items-center gap-2">
            <Upload className="h-5 w-5" />
            Bulk Import
          </CardTitle>
          <CardDescription className="text-slate-400">
            Import sanctions lists from CSV files or UN Security Council XML
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* CSV Import */}
            <div className="space-y-3">
              <h4 className="text-sm font-medium text-slate-300">CSV Import</h4>
              <div className="flex items-center space-x-2">
                <Input
                  type="file"
                  accept=".csv"
                  onChange={(e) => setCsvFile(e.target.files?.[0] || null)}
                  className="bg-slate-700/50 border-slate-600 text-slate-200"
                />
                <Button
                  onClick={handleCsvImport}
                  disabled={!csvFile || isUploading}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  {isUploading ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    "Import CSV"
                  )}
                </Button>
              </div>
            </div>

            {/* XML Import */}
            <div className="space-y-3">
              <h4 className="text-sm font-medium text-slate-300">UN Security Council XML</h4>
              <div className="flex items-center space-x-2">
                <Input
                  type="file"
                  accept=".xml"
                  onChange={(e) => {
                    const file = e.target.files?.[0] || null;
                    console.log('🔍 XML onChange - file:', file?.name);
                    setXmlFile(file);
                  }}
                  className="bg-slate-700/50 border-slate-600 text-slate-200"
                />
                <Button
                  onClick={handleXmlUpload}
                  disabled={!xmlFile || isUploadingXml}
                  className="bg-green-600 hover:bg-green-700"
                >
                  {isUploadingXml ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    "Import XML"
                  )}
                </Button>
              </div>
              <p className="text-xs text-slate-500">
                Import UN Security Council consolidated sanctions list
              </p>
              {/* Debug info */}
              <div className="text-xs text-gray-500">
                Debug: xmlFile = {xmlFile ? xmlFile.name : 'null'}, isUploadingXml = {isUploadingXml.toString()}, disabled = {(!xmlFile || isUploadingXml).toString()}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
      
      {/* View Entries Dialog */}
      <Dialog open={showViewEntriesDialog} onOpenChange={(open) => {
        if (!open) {
          setShowViewEntriesDialog(false);
          setSelectedList(null);
          setListEntries([]);
        }
      }}>
        <DialogContent className="bg-gray-900 border-gray-700 text-white max-w-4xl max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>View Entries: {selectedList?.name}</DialogTitle>
            <DialogDescription className="text-gray-400">
              Imported entries from this sanctions list
            </DialogDescription>
          </DialogHeader>
          
          {loading ? (
            <div className="flex items-center justify-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-white"></div>
            </div>
          ) : totalEntries === 0 ? (
            <div className="text-center py-8">
              <Users className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-400">No entries found in this list</p>
            </div>
          ) : (
            <>
              {/* Pagination Info */}
              <div className="flex justify-between items-center py-2 border-b border-gray-700">
                <p className="text-sm text-gray-400">
                  Showing {startIndex + 1}-{Math.min(endIndex, totalEntries)} of {totalEntries} entries
                </p>
                <p className="text-sm text-gray-400">
                  Page {currentPage} of {totalPages}
                </p>
              </div>
              
              {/* Entries Table */}
              <div className="max-h-96 overflow-y-auto">
                <Table>
                  <TableHeader>
                    <TableRow className="border-gray-700">
                      <TableHead className="text-gray-300">Name</TableHead>
                      <TableHead className="text-gray-300">Type</TableHead>
                      <TableHead className="text-gray-300">Country</TableHead>
                      <TableHead className="text-gray-300">Date of Birth</TableHead>
                      <TableHead className="text-gray-300">Aliases</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {currentEntries.map((entry, index) => (
                      <TableRow key={index} className="border-gray-700">
                        <TableCell className="font-medium text-white">
                          {entry.primary_name}
                        </TableCell>
                        <TableCell className="text-gray-300">
                          <Badge className="bg-blue-500/20 text-blue-300 border-blue-500">
                            {entry.entry_type || 'Unknown'}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-gray-300">
                          {entry.countries && entry.countries.length > 0 ? entry.countries.join(', ') : '-'}
                        </TableCell>
                        <TableCell className="text-gray-300">
                          {entry.date_of_birth || '-'}
                        </TableCell>
                        <TableCell className="text-gray-300">
                          {entry.aliases && entry.aliases.length > 0 ? entry.aliases.slice(0, 2).join(', ') + (entry.aliases.length > 2 ? '...' : '') : '-'}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
              
              {/* Pagination Controls */}
              {totalPages > 1 && (
                <div className="flex justify-center items-center space-x-2 py-4 border-t border-gray-700">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handlePageChange(currentPage - 1)}
                    disabled={currentPage <= 1}
                    className="border-gray-600 text-gray-300 hover:bg-gray-700"
                  >
                    Previous
                  </Button>
                  
                  <div className="flex space-x-1">
                    {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                      const pageNum = Math.max(1, Math.min(totalPages - 4, currentPage - 2)) + i;
                      if (pageNum > totalPages) return null;
                      return (
                        <Button
                          key={pageNum}
                          variant={currentPage === pageNum ? "default" : "outline"}
                          size="sm"
                          onClick={() => handlePageChange(pageNum)}
                          className={currentPage === pageNum 
                            ? "bg-blue-600 hover:bg-blue-700" 
                            : "border-gray-600 text-gray-300 hover:bg-gray-700"
                          }
                        >
                          {pageNum}
                        </Button>
                      );
                    })}
                  </div>
                  
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handlePageChange(currentPage + 1)}
                    disabled={currentPage >= totalPages}
                    className="border-gray-600 text-gray-300 hover:bg-gray-700"
                  >
                    Next
                  </Button>
                </div>
              )}
            </>
          )}
          
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                setShowViewEntriesDialog(false);
                setSelectedList(null);
                setListEntries([]);
              }}
              className="border-gray-600 text-gray-300 hover:bg-gray-700"
            >
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
