import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { toast } from 'sonner';
import { Clock, Archive, RefreshCw, Trash2, AlertTriangle, CheckCircle } from 'lucide-react';
import brain from 'brain';
import { SavedClassificationResponse, ClassificationNotification } from '../brain/data-contracts';

interface Props {
  onLoadClassification?: (workflowData: any) => void;
}

export function SavedClassifications({ onLoadClassification }: Props) {
  const [classifications, setClassifications] = useState<SavedClassificationResponse[]>([]);
  const [notifications, setNotifications] = useState<ClassificationNotification[]>([]);
  const [loading, setLoading] = useState(false);
  const [showArchived, setShowArchived] = useState(false);

  const loadClassifications = async () => {
    try {
      setLoading(true);
      const response = await brain.list_classifications({ include_archived: showArchived });
      const data = await response.json();
      setClassifications(data);
    } catch (error) {
      console.error('Error loading classifications:', error);
      toast.error('Failed to load saved classifications');
    } finally {
      setLoading(false);
    }
  };

  const loadNotifications = async () => {
    try {
      const response = await brain.notifications();
      const data = await response.json();
      setNotifications(data);
    } catch (error) {
      console.error('Error loading notifications:', error);
    }
  };

  const handleLoadClassification = async (id: string) => {
    try {
      const response = await brain.load_classification({ classification_id: id });
      const data = await response.json();
      
      if (onLoadClassification) {
        onLoadClassification(data.workflow_data);
        toast.success(`Loaded classification: ${data.name}`);
      }
    } catch (error) {
      console.error('Error loading classification:', error);
      toast.error('Failed to load classification');
    }
  };

  const handleDeleteClassification = async (id: string, name: string) => {
    if (!confirm(`Are you sure you want to archive "${name}"? You can restore it later from the archived section.`)) {
      return;
    }

    try {
      await brain.delete_classification({ classification_id: id });
      toast.success('Classification archived successfully');
      loadClassifications();
    } catch (error) {
      console.error('Error archiving classification:', error);
      toast.error('Failed to archive classification');
    }
  };

  const handleRestoreClassification = async (id: string, name: string) => {
    try {
      const response = await brain.restore_classification({ classification_id: id });
      const data = await response.json();
      toast.success(`Restored "${name}" with 7-day extension`);
      loadClassifications();
    } catch (error) {
      console.error('Error restoring classification:', error);
      toast.error('Failed to restore classification');
    }
  };

  useEffect(() => {
    loadClassifications();
    loadNotifications();
  }, [showArchived]);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-600 text-white';
      case 'expiring_soon': return 'bg-yellow-600 text-white';
      case 'archived': return 'bg-gray-600 text-white';
      default: return 'bg-gray-600 text-white';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'active': return <CheckCircle className="h-4 w-4" />;
      case 'expiring_soon': return <AlertTriangle className="h-4 w-4" />;
      case 'archived': return <Archive className="h-4 w-4" />;
      default: return <Clock className="h-4 w-4" />;
    }
  };

  const formatTimeRemaining = (daysUntilExpiry: number) => {
    if (daysUntilExpiry <= 0) return 'Expired';
    if (daysUntilExpiry < 1) return 'Less than 1 day';
    return `${daysUntilExpiry} day${daysUntilExpiry === 1 ? '' : 's'}`;
  };

  return (
    <div className="space-y-6">
      {/* Notifications Section */}
      {notifications.length > 0 && (
        <Card className="bg-gray-900 border-gray-700">
          <CardHeader>
            <CardTitle className="text-yellow-400 flex items-center gap-2">
              <AlertTriangle className="h-5 w-5" />
              Classification Alerts
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {notifications.map((notification) => (
              <div
                key={notification.id}
                className="p-3 bg-yellow-900/20 border border-yellow-600/30 rounded-lg"
              >
                <p className="text-yellow-200">{notification.message}</p>
                <p className="text-xs text-yellow-400 mt-1">
                  Classification: {notification.classification_name}
                </p>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {/* Controls */}
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-semibold">Saved Classifications</h2>
        <div className="flex gap-2">
          <Button
            onClick={() => setShowArchived(!showArchived)}
            variant="outline"
            className="border-gray-600 hover:bg-gray-700"
          >
            <Archive className="h-4 w-4 mr-2" />
            {showArchived ? 'Hide Archived' : 'Show Archived'}
          </Button>
          <Button
            onClick={loadClassifications}
            variant="outline"
            className="border-gray-600 hover:bg-gray-700"
            disabled={loading}
          >
            <RefreshCw className={`h-4 w-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
            Refresh
          </Button>
        </div>
      </div>

      {/* Classifications List */}
      <div className="space-y-4">
        {loading ? (
          <Card className="bg-gray-900 border-gray-700">
            <CardContent className="p-6 text-center">
              <RefreshCw className="h-6 w-6 animate-spin mx-auto mb-2" />
              <p>Loading saved classifications...</p>
            </CardContent>
          </Card>
        ) : classifications.length === 0 ? (
          <Card className="bg-gray-900 border-gray-700">
            <CardContent className="p-6 text-center">
              <Archive className="h-12 w-12 text-gray-600 mx-auto mb-4" />
              <p className="text-gray-400">
                {showArchived ? 'No archived classifications found.' : 'No saved classifications found.'}
              </p>
              {!showArchived && (
                <p className="text-sm text-gray-500 mt-2">
                  Start a classification to see auto-saved progress here.
                </p>
              )}
            </CardContent>
          </Card>
        ) : (
          classifications.map((classification) => (
            <Card key={classification.id} className="bg-gray-900 border-gray-700">
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="flex items-center gap-2">
                      {classification.name}
                      <Badge className={getStatusColor(classification.status)}>
                        {getStatusIcon(classification.status)}
                        <span className="ml-1 capitalize">{classification.status.replace('_', ' ')}</span>
                      </Badge>
                      {classification.auto_save && (
                        <Badge variant="outline" className="border-blue-500 text-blue-400">
                          Auto-saved
                        </Badge>
                      )}
                    </CardTitle>
                    <CardDescription>
                      Item: {classification.item_name}
                      {classification.description && ` • ${classification.description}`}
                    </CardDescription>
                  </div>
                  <div className="text-right text-sm text-gray-400">
                    <p>Progress: {Math.round(classification.progress_percentage)}%</p>
                    <p>Updated: {new Date(classification.updated_at).toLocaleDateString()}</p>
                    {classification.status !== 'archived' && (
                      <p className="text-yellow-400">
                        Expires: {formatTimeRemaining(classification.days_until_expiry)}
                      </p>
                    )}
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="flex justify-between items-center">
                  <div className="text-sm text-gray-400">
                    <p>Current Step: {classification.current_step}</p>
                    {classification.item_description && (
                      <p className="mt-1">Description: {classification.item_description}</p>
                    )}
                  </div>
                  <div className="flex gap-2">
                    {classification.status === 'archived' ? (
                      <Button
                        onClick={() => handleRestoreClassification(classification.id, classification.name)}
                        className="bg-green-600 hover:bg-green-700"
                        size="sm"
                      >
                        <RefreshCw className="h-4 w-4 mr-2" />
                        Restore
                      </Button>
                    ) : (
                      <>
                        <Button
                          onClick={() => handleLoadClassification(classification.id)}
                          className="bg-blue-600 hover:bg-blue-700"
                          size="sm"
                        >
                          Load
                        </Button>
                        <Button
                          onClick={() => handleDeleteClassification(classification.id, classification.name)}
                          variant="outline"
                          className="border-red-500 text-red-400 hover:bg-red-900/20"
                          size="sm"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>

      {/* Help Text */}
      <Card className="bg-gray-900 border-gray-700">
        <CardContent className="p-4">
          <h4 className="font-semibold mb-2 text-blue-400">Extended Auto-Save Features</h4>
          <div className="text-sm text-gray-400 space-y-1">
            <p>• Classifications are now auto-saved for <strong>7 days</strong> (extended from 24 hours)</p>
            <p>• You'll receive notifications 1 day before automatic archival</p>
            <p>• Archived classifications can be restored with a new 7-day retention period</p>
            <p>• Manual saves extend the retention period automatically</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
