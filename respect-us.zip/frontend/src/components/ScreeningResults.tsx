import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { 
  Eye, 
  Search, 
  Download, 
  Settings, 
  AlertTriangle, 
  XCircle, 
  CheckCircle, 
  Clock, 
  Loader2,
  Filter,
  TrendingUp,
  Calendar
} from 'lucide-react';
import { CustomerProfile, ScreeningResult } from '../brain/data-contracts';

export interface ScreeningResultsProps {
  screeningResults: ScreeningResult[];
  customers: CustomerProfile[];
  screeningThreshold: number;
  setScreeningThreshold: (threshold: number) => void;
  enableVersionedScreening: boolean;
  setEnableVersionedScreening: (enabled: boolean) => void;
  screeningDate: string;
  setScreeningDate: (date: string) => void;
  forceRescreen: boolean;
  setForceRescreen: (force: boolean) => void;
  screeningNotes: string;
  setScreeningNotes: (notes: string) => void;
  onShowScreeningDetails: (result: ScreeningResult) => void;
  isGeneratingPdf: boolean;
  onDownloadIndividualReport: (customerId: number, screeningId: number) => void;
}

const ScreeningResults: React.FC<ScreeningResultsProps> = ({
  screeningResults,
  customers,
  screeningThreshold,
  setScreeningThreshold,
  enableVersionedScreening,
  setEnableVersionedScreening,
  screeningDate,
  setScreeningDate,
  forceRescreen,
  setForceRescreen,
  screeningNotes,
  setScreeningNotes,
  onShowScreeningDetails,
  isGeneratingPdf,
  onDownloadIndividualReport
}) => {
  const getRiskLevelColor = (riskLevel: string) => {
    switch (riskLevel) {
      case 'critical': return 'bg-red-500/20 text-red-400 border-red-500/50';
      case 'high': return 'bg-orange-500/20 text-orange-400 border-orange-500/50';
      case 'medium': return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/50';
      case 'low': return 'bg-green-500/20 text-green-400 border-green-500/50';
      default: return 'bg-gray-500/20 text-gray-400 border-gray-500/50';
    }
  };

  const getRiskIcon = (riskLevel: string) => {
    switch (riskLevel) {
      case 'critical': return <XCircle className="h-4 w-4" />;
      case 'high': return <AlertTriangle className="h-4 w-4" />;
      case 'medium': return <AlertTriangle className="h-4 w-4" />;
      case 'low': return <CheckCircle className="h-4 w-4" />;
      default: return <Clock className="h-4 w-4" />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Screening Configuration */}
      <Card className="bg-slate-800/30 border-slate-700/50">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Settings className="h-5 w-5" />
            Screening Configuration
          </CardTitle>
          <CardDescription className="text-gray-400">
            Configure screening parameters and thresholds
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Basic Settings */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label className="text-white">Screening Threshold: {screeningThreshold}%</Label>
              <Slider
                value={[screeningThreshold]}
                onValueChange={(value) => setScreeningThreshold(value[0])}
                max={100}
                min={50}
                step={5}
                className="w-full"
              />
              <div className="text-xs text-gray-400">
                Minimum match confidence required to flag as potential match
              </div>
            </div>
            
            <div className="space-y-4">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="versioned-screening"
                  checked={enableVersionedScreening}
                  onCheckedChange={setEnableVersionedScreening}
                  className="border-slate-600"
                />
                <Label htmlFor="versioned-screening" className="text-white">
                  Enable Versioned Screening
                </Label>
              </div>
              
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="force-rescreen"
                  checked={forceRescreen}
                  onCheckedChange={setForceRescreen}
                  className="border-slate-600"
                  disabled={!enableVersionedScreening}
                />
                <Label htmlFor="force-rescreen" className="text-white">
                  Force Re-screen
                </Label>
              </div>
            </div>
          </div>

          {/* Versioned Screening Options */}
          {enableVersionedScreening && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4 bg-slate-700/30 rounded-lg border border-slate-600/50">
              <div className="space-y-2">
                <Label className="text-white flex items-center gap-2">
                  <Calendar className="h-4 w-4" />
                  Screening Date (Optional)
                </Label>
                <Input
                  type="date"
                  value={screeningDate}
                  onChange={(e) => setScreeningDate(e.target.value)}
                  className="bg-slate-800 border-slate-700 text-white"
                  placeholder="Leave empty for current date"
                />
                <div className="text-xs text-gray-400">
                  Screen against sanctions lists active at this date
                </div>
              </div>
              
              <div className="space-y-2">
                <Label className="text-white">Screening Notes</Label>
                <Input
                  value={screeningNotes}
                  onChange={(e) => setScreeningNotes(e.target.value)}
                  className="bg-slate-800 border-slate-700 text-white"
                  placeholder="Optional notes for this screening"
                />
                <div className="text-xs text-gray-400">
                  Add context or reason for this screening
                </div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Screening Results */}
      <Card className="bg-slate-800/30 border-slate-700/50">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Search className="h-5 w-5" />
            Screening Results ({screeningResults.length})
          </CardTitle>
          <CardDescription className="text-gray-400">
            Recent customer screening results and risk assessments
          </CardDescription>
        </CardHeader>
        <CardContent>
          {screeningResults.length === 0 ? (
            <div className="text-center py-12">
              <Search className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <div className="text-gray-400 mb-2">No screening results found</div>
              <div className="text-sm text-gray-500">
                Start by screening customers to see results here
              </div>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow className="border-slate-700/50">
                  <TableHead className="text-gray-300">Customer</TableHead>
                  <TableHead className="text-gray-300">Screening Date</TableHead>
                  <TableHead className="text-gray-300">Risk Level</TableHead>
                  <TableHead className="text-gray-300">Total Matches</TableHead>
                  <TableHead className="text-gray-300">High Risk Matches</TableHead>
                  <TableHead className="text-gray-300">Status</TableHead>
                  <TableHead className="text-gray-300">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {screeningResults
                  .sort((a, b) => new Date(b.screening_date).getTime() - new Date(a.screening_date).getTime())
                  .map((result) => {
                    const customer = customers.find(c => c.id === result.customer_id);
                    
                    return (
                      <TableRow key={result.id} className="border-slate-700/50 hover:bg-slate-700/30">
                        <TableCell>
                          <div>
                            <div className="text-white font-medium">
                              {customer?.customer_name || 'Unknown Customer'}
                            </div>
                            <div className="text-gray-400 text-sm">
                              {customer?.customer_type || 'Unknown'} • {customer?.country || 'Unknown Country'}
                            </div>
                          </div>
                        </TableCell>
                        <TableCell className="text-gray-300">
                          <div>
                            <div>{new Date(result.screening_date).toLocaleDateString()}</div>
                            <div className="text-xs text-gray-500">
                              {new Date(result.screening_date).toLocaleTimeString()}
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge className={getRiskLevelColor(result.risk_level)}>
                            {getRiskIcon(result.risk_level)}
                            <span className="ml-1">{result.risk_level}</span>
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Badge className="bg-blue-500/20 text-blue-400 border-blue-500/50">
                            {result.total_matches} matches
                          </Badge>
                        </TableCell>
                        <TableCell>
                          {result.high_risk_matches > 0 ? (
                            <Badge className="bg-red-500/20 text-red-400 border-red-500/50">
                              <XCircle className="h-3 w-3 mr-1" />
                              {result.high_risk_matches} high risk
                            </Badge>
                          ) : (
                            <Badge className="bg-green-500/20 text-green-400 border-green-500/50">
                              <CheckCircle className="h-3 w-3 mr-1" />
                              No high risk
                            </Badge>
                          )}
                        </TableCell>
                        <TableCell>
                          <Badge 
                            variant="outline" 
                            className={`border-${result.status === 'completed' ? 'green' : 'yellow'}-500 text-${result.status === 'completed' ? 'green' : 'yellow'}-400`}
                          >
                            {result.status}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => onShowScreeningDetails(result)}
                              className="border-slate-600 text-gray-300 hover:bg-slate-700"
                            >
                              <Eye className="h-3 w-3 mr-1" />
                              Details
                            </Button>
                            {customer && (
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => onDownloadIndividualReport(customer.id!, result.id!)}
                                disabled={isGeneratingPdf}
                                className="border-slate-600 text-gray-300 hover:bg-slate-700"
                              >
                                {isGeneratingPdf ? (
                                  <Loader2 className="h-3 w-3 mr-1 animate-spin" />
                                ) : (
                                  <Download className="h-3 w-3 mr-1" />
                                )}
                                PDF
                              </Button>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default ScreeningResults;
