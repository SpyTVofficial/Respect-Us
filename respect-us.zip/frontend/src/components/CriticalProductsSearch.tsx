import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Skeleton } from '@/components/ui/skeleton';
import { 
  Search, 
  Filter, 
  X, 
  Database, 
  Scale, 
  AlertTriangle, 
  MapPin, 
  Info, 
  CheckCircle, 
  XCircle,
  Download,
  Upload,
  Eye,
  FileText,
  Globe
} from 'lucide-react';
import { toast } from 'sonner';
import brain from 'brain';
import CriticalProductsSectionContent from 'components/CriticalProductsSectionContent';
import ProductDetailModal from 'components/ProductDetailModal';
import type {
  CriticalProductSearchResult,
  SearchCriticalProductsRequest
} from '../brain/data-contracts';

interface Props {
  onProductSelect?: (product: CriticalProductSearchResult) => void;
}

const CriticalProductsSearch: React.FC<Props> = ({ onProductSelect }) => {
  const [activeTab, setActiveTab] = useState('trade-codes');
  const [searchResults, setSearchResults] = useState<CriticalProductSearchResult[]>([]);
  const [tradeCodesData, setTradeCodesData] = useState<any[]>([]);
  const [measuresData, setMeasuresData] = useState<any[]>([]);
  const [restrictionsData, setRestrictionsData] = useState<any[]>([]);
  const [jurisdictionsData, setJurisdictionsData] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [showAdvancedFilters, setShowAdvancedFilters] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [hsCode, setHsCode] = useState('');
  const [cnCode, setCnCode] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedJurisdiction, setSelectedJurisdiction] = useState('all');
  const [selectedMeasureType, setSelectedMeasureType] = useState('all');
  const [selectedRiskLevel, setSelectedRiskLevel] = useState('all');
  
  // Metadata
  const [categories, setCategories] = useState<string[]>([]);
  const [jurisdictions, setJurisdictions] = useState<string[]>([]);
  const [measureTypes, setMeasureTypes] = useState<string[]>([]);
  const [stats, setStats] = useState<any>(null);

  // Modal state
  const [selectedProduct, setSelectedProduct] = useState<CriticalProductSearchResult | null>(null);
  const [showProductDetail, setShowProductDetail] = useState(false);

  // Helper function to get jurisdiction descriptions
  const getJurisdictionDescription = (jurisdiction: string): string => {
    const descriptions: Record<string, string> = {
      'EU': 'European Union sanctions and export controls',
      'UK (HMT)': 'UK HM Treasury financial sanctions and export controls',
      'UN': 'United Nations Security Council sanctions',
      'US (OFAC)': 'US Office of Foreign Assets Control sanctions',
      'Australia -> Russia': 'Australian export controls targeting Russia',
      'Canada -> Russia': 'Canadian export controls targeting Russia',
      'Norway -> Russia': 'Norwegian export controls targeting Russia',
      'Switzerland -> Russia': 'Swiss export controls targeting Russia',
      'Japan -> Russia': 'Japanese export controls targeting Russia'
    };
    return descriptions[jurisdiction] || `${jurisdiction} regulatory measures`;
  };

  // Load metadata on component mount
  useEffect(() => {
    loadMetadata();
  }, []);

  const loadMetadata = async () => {
    try {
      const [categoriesRes, jurisdictionsRes, measureTypesRes, statsRes] = await Promise.all([
        brain.get_categories(),
        brain.get_jurisdictions(),
        brain.get_measure_types(),
        brain.get_critical_products_stats()
      ]);

      if (categoriesRes.ok) {
        const data = await categoriesRes.json();
        setCategories(data);
      }

      if (jurisdictionsRes.ok) {
        const data = await jurisdictionsRes.json();
        setJurisdictions(data);
      }

      if (measureTypesRes.ok) {
        const data = await measureTypesRes.json();
        setMeasureTypes(data);
      }

      if (statsRes.ok) {
        const data = await statsRes.json();
        setStats(data);
      }
    } catch (error) {
      console.error('Error loading metadata:', error);
    }
  };

  const handleSearch = async () => {
    if (!searchQuery && !hsCode && !cnCode && !selectedCategory && !selectedJurisdiction && !selectedMeasureType && !selectedRiskLevel) {
      toast.error('Please enter search criteria');
      return;
    }

    setLoading(true);
    try {
      const request: SearchCriticalProductsRequest = {
        query: searchQuery || undefined,
        hs_code: hsCode || undefined,
        cn_code: cnCode || undefined,
        category: selectedCategory || undefined,
        jurisdiction: selectedJurisdiction || undefined,
        measure_type: selectedMeasureType || undefined,
        risk_level: selectedRiskLevel || undefined,
        limit: 50
      };

      const response = await brain.search_critical_products(request);
      if (response.ok) {
        const data = await response.json();
        setSearchResults(data);
        toast.success(`Found ${data.length} products`);
      } else {
        toast.error('Search failed');
      }
    } catch (error) {
      console.error('Search error:', error);
      toast.error('Search failed');
    } finally {
      setLoading(false);
    }
  };

  const clearFilters = () => {
    setSearchQuery('');
    setHsCode('');
    setCnCode('');
    setSelectedCategory('all');
    setSelectedJurisdiction('all');
    setSelectedMeasureType('all');
    setSelectedRiskLevel('all');
    setSearchResults([]);
  };

  const handleProductClick = (product: CriticalProductSearchResult) => {
    setSelectedProduct(product);
    setShowProductDetail(true);
    if (onProductSelect) {
      onProductSelect(product);
    }
  };

  const getRiskLevelIcon = (riskLevel: string | null) => {
    switch (riskLevel) {
      case 'high':
        return <XCircle className="h-4 w-4 text-red-500" />;
      case 'medium':
        return <AlertTriangle className="h-4 w-4 text-yellow-500" />;
      case 'low':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      default:
        return <Info className="h-4 w-4 text-gray-400" />;
    }
  };

  const getRiskLevelColor = (riskLevel: string | null) => {
    switch (riskLevel) {
      case 'high':
        return 'bg-red-100 text-red-800 border-red-200';
      case 'medium':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'low':
        return 'bg-green-100 text-green-800 border-green-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const loadTabData = async (tab: string) => {
    setLoading(true);
    try {
      switch (tab) {
        case 'trade-codes':
          const tradeCodesResponse = await brain.list_trade_codes({ limit: 100 });
          if (tradeCodesResponse.ok) {
            const data = await tradeCodesResponse.json();
            setTradeCodesData(data);
          }
          break;
        case 'measures':
          const measuresResponse = await brain.list_restrictive_measures({ limit: 100 });
          if (measuresResponse.ok) {
            const data = await measuresResponse.json();
            setMeasuresData(data);
          }
          break;
        case 'restrictions':
          // Load products that have restrictions by searching with linked data
          const restrictionsSearchResponse = await brain.search_critical_products({ 
            limit: 100,
            // This should return products with their restrictions populated
          });
          if (restrictionsSearchResponse.ok) {
            const data = await restrictionsSearchResponse.json();
            // Filter to only show products that actually have restrictions
            const productsWithRestrictions = data.filter((item: any) => 
              item.restrictions && item.restrictions.length > 0
            );
            setRestrictionsData(productsWithRestrictions);
            console.log('Restrictions data loaded:', productsWithRestrictions.length, 'products with restrictions');
          }
          break;
        case 'jurisdictions':
          // Load both jurisdictions list and measures to group them
          const [jurisdictionsResponse, jurisdictionMeasuresResponse] = await Promise.all([
            brain.get_jurisdictions(),
            brain.list_restrictive_measures({ limit: 500 })
          ]);
          
          if (jurisdictionsResponse.ok && jurisdictionMeasuresResponse.ok) {
            const jurisdictionsDataRaw = await jurisdictionsResponse.json();
            const measuresData = await jurisdictionMeasuresResponse.json();
            
            // Group measures by jurisdiction
            const measuresByJurisdiction: Record<string, any[]> = {};
            measuresData.forEach((measure: any) => {
              if (measure.jurisdiction) {
                if (!measuresByJurisdiction[measure.jurisdiction]) {
                  measuresByJurisdiction[measure.jurisdiction] = [];
                }
                measuresByJurisdiction[measure.jurisdiction].push(measure);
              }
            });
            
            setJurisdictionsData(measuresByJurisdiction);
          }
          break;
      }
    } catch (error) {
      console.error('Error loading tab data:', error);
      toast.error('Failed to load data');
    } finally {
      setLoading(false);
    }
  };

  const handleTabChange = (value: string) => {
    setActiveTab(value);
    loadTabData(value);
  };

  useEffect(() => {
    loadTabData('trade-codes');
  }, []);

  return (
    <div className="space-y-6">
      {/* Header with Stats and Clear Button */}
      <div className="flex items-center justify-between">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 flex-1">
          {stats && (
            <>
              <Card>
                <CardContent className="p-4">
                  <div className="text-2xl font-bold text-blue-400">{stats.total_trade_codes || 0}</div>
                  <div className="text-sm text-gray-400">Trade Codes</div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4">
                  <div className="text-2xl font-bold text-purple-400">{stats.total_measures || 0}</div>
                  <div className="text-sm text-gray-400">Measures</div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4">
                  <div className="text-2xl font-bold text-yellow-400">{stats.total_restrictions || 0}</div>
                  <div className="text-sm text-gray-400">Restrictions</div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4">
                  <div className="text-2xl font-bold text-green-400">{stats.total_jurisdictions || 0}</div>
                  <div className="text-sm text-gray-400">Jurisdictions</div>
                </CardContent>
              </Card>
            </>
          )}
        </div>
      </div>

      {/* Navigation Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-4 mb-6">
          <TabsTrigger value="trade-codes" className="flex items-center gap-2">
            <Database className="h-4 w-4" />
            Trade Codes
            {stats?.trade_codes && (
              <Badge variant="secondary" className="ml-1 text-xs">
                {stats.trade_codes.toLocaleString()}
              </Badge>
            )}
          </TabsTrigger>
          <TabsTrigger value="measures" className="flex items-center gap-2">
            <Scale className="h-4 w-4" />
            Measures
            {stats?.measures && (
              <Badge variant="secondary" className="ml-1 text-xs">
                {stats.measures.toLocaleString()}
              </Badge>
            )}
          </TabsTrigger>
          <TabsTrigger value="restrictions" className="flex items-center gap-2">
            <AlertTriangle className="h-4 w-4" />
            Restrictions
            {stats?.restrictions && (
              <Badge variant="secondary" className="ml-1 text-xs">
                {stats.restrictions.toLocaleString()}
              </Badge>
            )}
          </TabsTrigger>
          <TabsTrigger value="jurisdictions" className="flex items-center gap-2">
            <MapPin className="h-4 w-4" />
            Jurisdictions
            {stats?.jurisdictions && (
              <Badge variant="secondary" className="ml-1 text-xs">
                {stats.jurisdictions.toLocaleString()}
              </Badge>
            )}
          </TabsTrigger>
        </TabsList>

        {/* Dedicated Search Interface */}
        <div className="bg-gradient-to-br from-gray-900 via-gray-800 to-black p-6 rounded-xl border border-gray-700 shadow-2xl mb-8">
          <div className="flex items-center gap-3 mb-6">
            <div className="p-2 bg-blue-600/20 rounded-lg border border-blue-500/30">
              <Search className="h-5 w-5 text-blue-400" />
            </div>
            <div>
              <h3 className="text-xl font-semibold text-white">Critical Products Search</h3>
              <p className="text-gray-400 text-sm">Search by HS/CN codes, keywords, or apply advanced filters</p>
            </div>
          </div>

          <div className="space-y-4">
            {/* Data Quality Attention Notice */}
            <Alert className="border-yellow-600 bg-yellow-900/20 text-yellow-200">
              <AlertTriangle className="h-4 w-4 text-yellow-400" />
              <AlertDescription>
                <strong>Data Quality Notice:</strong> The Critical Products database is currently in active development. 
                Product descriptions may be incomplete or generated automatically. Some regulatory measures 
                and restrictions data is still being imported and validated. Please verify critical compliance 
                information with primary regulatory sources.
              </AlertDescription>
            </Alert>

            {/* Primary Search Bar */}
            <div className="flex gap-3">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Search by product description, keywords, category..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
                  className="pl-10 bg-gray-800/50 border-gray-600 text-white placeholder-gray-400 h-12 text-base focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                />
              </div>
              <Button 
                onClick={handleSearch} 
                disabled={loading}
                className="px-8 h-12 bg-blue-600 hover:bg-blue-700 text-white font-medium shadow-lg"
              >
                {loading ? (
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    Searching...
                  </div>
                ) : (
                  <div className="flex items-center gap-2">
                    <Search className="h-4 w-4" />
                    Search
                  </div>
                )}
              </Button>
            </div>

            {/* Code Search Row */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div className="relative">
                <Input
                  placeholder="HS Code (e.g., 8542.31.00)"
                  value={hsCode}
                  onChange={(e) => setHsCode(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
                  className="bg-gray-800/50 border-gray-600 text-white placeholder-gray-400 focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                />
              </div>
              <div className="relative">
                <Input
                  placeholder="CN Code (e.g., 8542 31 00 90)"
                  value={cnCode}
                  onChange={(e) => setCnCode(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
                  className="bg-gray-800/50 border-gray-600 text-white placeholder-gray-400 focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                />
              </div>
            </div>

            {/* Filter Controls */}
            <div className="flex items-center justify-between pt-2">
              <div className="flex items-center gap-3">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setShowAdvancedFilters(!showAdvancedFilters)}
                  className="border-gray-600 text-gray-300 hover:text-white hover:border-gray-500 bg-gray-800/30"
                >
                  <Filter className="h-4 w-4 mr-2" />
                  Advanced Filters
                </Button>
                {(searchQuery || hsCode || cnCode || selectedCategory !== 'all' || selectedJurisdiction !== 'all' || selectedMeasureType !== 'all' || selectedRiskLevel !== 'all') && (
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={clearFilters}
                    className="text-gray-400 hover:text-white"
                  >
                    <X className="h-4 w-4 mr-1" />
                    Clear All
                  </Button>
                )}
              </div>
              
              {searchResults.length > 0 && (
                <div className="text-sm text-gray-400">
                  Found {searchResults.length} products
                </div>
              )}
            </div>

            {/* Advanced Filters Panel */}
            {showAdvancedFilters && (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 p-4 bg-black/20 rounded-lg border border-gray-700/50">
                <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                  <SelectTrigger className="bg-gray-800/50 border-gray-600 text-white">
                    <SelectValue placeholder="Product Category" />
                  </SelectTrigger>
                  <SelectContent className="bg-gray-800 border-gray-600">
                    <SelectItem value="all">All Categories</SelectItem>
                    {categories.map((category) => (
                      <SelectItem key={category} value={category} className="text-white">
                        {category}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                <Select value={selectedJurisdiction} onValueChange={setSelectedJurisdiction}>
                  <SelectTrigger className="bg-gray-800/50 border-gray-600 text-white">
                    <SelectValue placeholder="Jurisdiction" />
                  </SelectTrigger>
                  <SelectContent className="bg-gray-800 border-gray-600">
                    <SelectItem value="all">All Jurisdictions</SelectItem>
                    {jurisdictions.map((jurisdiction) => (
                      <SelectItem key={jurisdiction} value={jurisdiction} className="text-white">
                        {jurisdiction}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                <Select value={selectedMeasureType} onValueChange={setSelectedMeasureType}>
                  <SelectTrigger className="bg-gray-800/50 border-gray-600 text-white">
                    <SelectValue placeholder="Measure Type" />
                  </SelectTrigger>
                  <SelectContent className="bg-gray-800 border-gray-600">
                    <SelectItem value="all">All Measures</SelectItem>
                    {measureTypes.map((type) => (
                      <SelectItem key={type} value={type} className="text-white">
                        {type.replace('_', ' ').toUpperCase()}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                <Select value={selectedRiskLevel} onValueChange={setSelectedRiskLevel}>
                  <SelectTrigger className="bg-gray-800/50 border-gray-600 text-white">
                    <SelectValue placeholder="Risk Level" />
                  </SelectTrigger>
                  <SelectContent className="bg-gray-800 border-gray-600">
                    <SelectItem value="all">All Risk Levels</SelectItem>
                    <SelectItem value="high" className="text-white">High Risk</SelectItem>
                    <SelectItem value="medium" className="text-white">Medium Risk</SelectItem>
                    <SelectItem value="low" className="text-white">Low Risk</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            )}
          </div>
        </div>

        {/* Tab Content */}
        <TabsContent value="trade-codes" className="space-y-4">
          {/* Explanatory Section */}
          <CriticalProductsSectionContent 
            sectionType="trade-codes" 
            className="mb-6"
          />
          
          {loading ? (
            <div className="space-y-4">
              {[...Array(3)].map((_, i) => (
                <Card key={i}>
                  <CardContent className="p-4">
                    <Skeleton className="h-4 w-1/4 mb-2" />
                    <Skeleton className="h-6 w-3/4 mb-2" />
                    <Skeleton className="h-4 w-1/2" />
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <div className="grid gap-4">
              {tradeCodesData.map((code: any) => (
                <Card key={code.id} 
                      className="cursor-pointer hover:shadow-lg hover:scale-[1.01] transition-all duration-200 border-l-4 border-l-blue-500/30 hover:border-l-blue-500"
                      onClick={() => {
                        // Convert to CriticalProductSearchResult format for modal
                        const product = {
                          id: code.id,
                          hs_code: code.hs_code,
                          cn_code: code.cn_code,
                          description: code.description,
                          category: code.category,
                          subcategory: code.subcategory,
                          risk_level: code.risk_level,
                          restrictions: code.restrictions || []
                        };
                        handleProductClick(product);
                      }}>
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <Badge variant="outline" className="font-mono">
                            {code.hs_code}
                          </Badge>
                          {code.cn_code && (
                            <Badge variant="outline" className="font-mono text-xs">
                              CN: {code.cn_code}
                            </Badge>
                          )}
                          {code.restrictions && code.restrictions.length > 0 && (
                            <Badge className="bg-red-100 text-red-800 border-red-200 dark:bg-red-900/20 dark:text-red-400 dark:border-red-800">
                              {code.restrictions.length} restriction{code.restrictions.length !== 1 ? 's' : ''}
                            </Badge>
                          )}
                          {code.risk_level && (
                            <Badge className={getRiskLevelColor(code.risk_level)}>
                              {getRiskLevelIcon(code.risk_level)}
                              <span className="ml-1">{code.risk_level.toUpperCase()}</span>
                            </Badge>
                          )}
                        </div>
                        <h4 className="font-medium text-lg mb-2">{code.description}</h4>
                        {code.category && (
                          <div className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-400 mb-2">
                            <span><strong>Category:</strong> {code.category}</span>
                            {code.subcategory && <span>• {code.subcategory}</span>}
                          </div>
                        )}
                        {code.restrictions && code.restrictions.length > 0 && (
                          <div className="space-y-1">
                            <div className="text-sm font-medium text-red-700 dark:text-red-400 mb-1">
                              Active Restrictions:
                            </div>
                            {code.restrictions.slice(0, 2).map((restriction: any, index: number) => (
                              <div key={index} className="text-xs text-gray-600 dark:text-gray-400 bg-red-50 dark:bg-red-900/20 p-2 rounded">
                                <span className="font-mono">{restriction.regulation_reference}</span>
                                {restriction.measure_type && (
                                  <span className="ml-2 text-red-600 dark:text-red-400">
                                    ({restriction.measure_type.replace('_', ' ').toUpperCase()})
                                  </span>
                                )}
                              </div>
                            ))}
                            {code.restrictions.length > 2 && (
                              <div className="text-xs text-gray-500 dark:text-gray-400">
                                +{code.restrictions.length - 2} more restrictions...
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                      <div className="text-right text-sm text-gray-500 dark:text-gray-400">
                        <div className="flex items-center gap-1">
                          <Info className="h-4 w-4" />
                          Click for details
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
              {tradeCodesData.length === 0 && (
                <Card>
                  <CardContent className="p-8 text-center">
                    <Database className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                    <h3 className="text-lg font-medium mb-2">No trade codes found</h3>
                    <p className="text-gray-600 dark:text-gray-400">
                      Import data to see trade codes here
                    </p>
                  </CardContent>
                </Card>
              )}
            </div>
          )}
        </TabsContent>

        <TabsContent value="measures" className="space-y-6">
          {/* Explanatory Section - FIRST */}
          <CriticalProductsSectionContent 
            sectionType="measures" 
            className="mb-6"
          />
          
          {/* Search and Filters Section */}
          <Card className="bg-gray-900/50 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Scale className="h-5 w-5" />
                Regulatory Measures Database
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-300 mb-4">
                Search and filter regulatory measures by jurisdiction, type, and product category.
              </p>
              {/* Search functionality would go here */}
              <div className="text-center py-8 text-gray-400">
                <Scale className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <p>Measures search functionality will be implemented here</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="restrictions" className="space-y-6">
          {/* Explanatory Section - FIRST */}
          <CriticalProductsSectionContent 
            sectionType="restrictions" 
            className="mb-6"
          />
          
          {/* Search and Filters Section */}
          <Card className="bg-gray-900/50 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <AlertTriangle className="h-5 w-5" />
                Product Restrictions Database
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-300 mb-4">
                Search and analyze product restrictions by country, product type, and regulatory framework.
              </p>
              {/* Search functionality would go here */}
              <div className="text-center py-8 text-gray-400">
                <AlertTriangle className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <p>Restrictions search functionality will be implemented here</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="jurisdictions" className="space-y-6">
          {/* Explanatory Section - FIRST */}
          <CriticalProductsSectionContent 
            sectionType="jurisdictions" 
            className="mb-6"
          />
          
          {/* Search and Filters Section */}
          <Card className="bg-gray-900/50 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <MapPin className="h-5 w-5" />
                Regulatory Jurisdictions Overview
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-300 mb-4">
                Explore different regulatory jurisdictions and their export control frameworks.
              </p>
              {/* Search functionality would go here */}
              <div className="text-center py-8 text-gray-400">
                <MapPin className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <p>Jurisdictions overview functionality will be implemented here</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Search Results */}
      {searchResults.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Search Results ({searchResults.length})</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {searchResults.map((product) => (
                <Card key={product.id} 
                      className="cursor-pointer hover:shadow-lg hover:scale-[1.02] transition-all duration-200 border-l-4 border-l-blue-500 hover:border-l-blue-600"
                      onClick={() => handleProductClick(product)}>
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <Badge variant="outline" className="font-mono">
                            {product.hs_code}
                          </Badge>
                          {product.cn_code && (
                            <Badge variant="outline" className="font-mono text-xs">
                              CN: {product.cn_code}
                            </Badge>
                          )}
                          {product.risk_level && (
                            <Badge className={getRiskLevelColor(product.risk_level)}>
                              {getRiskLevelIcon(product.risk_level)}
                              <span className="ml-1">{product.risk_level.toUpperCase()}</span>
                            </Badge>
                          )}
                        </div>
                        
                        <h4 className="font-medium text-lg mb-2">{product.description}</h4>
                        
                        {product.category && (
                          <div className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-400">
                            <span>Category: {product.category}</span>
                            {product.subcategory && <span>• {product.subcategory}</span>}
                          </div>
                        )}
                      </div>
                      <div className="text-right text-sm text-gray-500 dark:text-gray-400">
                        <div className="flex items-center gap-1">
                          <Info className="h-4 w-4" />
                          Click for details
                        </div>
                      </div>
                    </div>

                    {/* Quick restrictions preview */}
                    {product.restrictions && product.restrictions.length > 0 ? (
                      <div className="space-y-2">
                        <h5 className="font-medium text-sm text-gray-700 dark:text-gray-300 mb-2 flex items-center gap-1">
                          <AlertTriangle className="h-4 w-4 text-red-500" />
                          {product.restrictions.length} Restriction{product.restrictions.length !== 1 ? 's' : ''} Found
                        </h5>
                        
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
                          {product.restrictions.slice(0, 3).map((restriction: any, index: number) => (
                            <div key={index} className="p-2 bg-red-50 dark:bg-red-900/20 rounded border border-red-200 dark:border-red-800">
                              <div className="flex items-center gap-1 mb-1">
                                <Badge variant="secondary" className="text-xs">
                                  {restriction.jurisdiction}
                                </Badge>
                              </div>
                              <div className="text-xs font-medium text-red-700 dark:text-red-400">
                                {restriction.measure_type.replace('_', ' ').toUpperCase()}
                              </div>
                            </div>
                          ))}
                        </div>
                        
                        {product.restrictions.length > 3 && (
                          <div className="text-sm text-gray-600 dark:text-gray-400">
                            +{product.restrictions.length - 3} more restrictions
                          </div>
                        )}
                      </div>
                    ) : (
                      <div className="flex items-center gap-2 text-sm text-green-600 dark:text-green-400">
                        <CheckCircle className="h-4 w-4" />
                        No specific restrictions found in database
                      </div>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {!loading && searchResults.length === 0 && (searchQuery || hsCode || cnCode || selectedCategory) && (
        <Card>
          <CardContent className="p-8 text-center">
            <Search className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium mb-2">No products found</h3>
            <p className="text-gray-600 dark:text-gray-400">
              Try adjusting your search criteria or using different keywords
            </p>
          </CardContent>
        </Card>
      )}
      
      {/* Product Detail Modal */}
      <ProductDetailModal 
        product={selectedProduct}
        isOpen={showProductDetail}
        onClose={() => setShowProductDetail(false)}
      />
    </div>
  );
};

export default CriticalProductsSearch;
