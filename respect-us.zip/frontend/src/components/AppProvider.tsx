import { StackProvider } from '@stackframe/react';
import { stackClientApp } from 'app/auth';
import { ThemeProvider } from '@/hooks/use-theme';
import { Toaster } from 'sonner';
import type { ReactNode } from "react";
import { useLocation } from "react-router-dom";

interface Props {
  children: ReactNode;
}

/**
 * A provider wrapping the whole app.
 *
 * You can add multiple providers here by nesting them,
 * and they will all be applied to the app.
 *
 * Note: ThemeProvider is already included in AppWrapper.tsx and does not need to be added here.
 */
export const AppProvider = ({ children }: Props) => {
  const location = useLocation();
  
  // Determine if we should show navigation
  const shouldShowNavigation = ![    '/auth/sign-in',
    '/auth/sign-up', 
    '/auth/forgot-password',
    '/auth/email-verification',
    '/auth/password-reset',
    '/onboarding'
  ].some(path => location.pathname.startsWith(path));
  
  if (!shouldShowNavigation) {
    return (
      <div className="min-h-screen bg-gray-900">
        {children}
        <Toaster 
          theme="dark" 
          position="bottom-right"
          toastOptions={{
            style: {
              background: 'rgb(17 24 39)',
              border: '1px solid rgb(55 65 81)',
              color: 'rgb(243 244 246)'
            }
          }}
        />
      </div>
    );
  }
  
  return (
    <div className="min-h-screen bg-gray-900">
      <main className="min-h-screen">
        {children}
      </main>
      <Toaster 
        theme="dark" 
        position="bottom-right"
        toastOptions={{
          style: {
            background: 'rgb(17 24 39)',
            border: '1px solid rgb(55 65 81)',
            color: 'rgb(243 244 246)'
          }
        }}
      />
    </div>
  );
};
