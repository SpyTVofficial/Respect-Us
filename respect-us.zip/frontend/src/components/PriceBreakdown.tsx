import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { Info } from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { VATBreakdown } from '../brain/data-contracts';

export interface Props {
  basePrice: number;
  currency: string;
  country: string;
  vatNumber?: string;
  vatBreakdown: VATBreakdown;
}

const PriceBreakdown = ({ 
  basePrice, 
  currency, 
  country, 
  vatNumber,
  vatBreakdown 
}: Props) => {
  const formatPrice = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: currency,
      minimumFractionDigits: 2
    }).format(amount);
  };

  const getVATDescription = () => {
    switch (vatBreakdown.vat_type) {
      case 'export':
        return 'Export outside EU - VAT exempt';
      case 'b2b_reverse_charge':
        return 'EU Business - Reverse charge applies';
      case 'b2c':
        return `EU Consumer - ${vatBreakdown.vat_rate}% VAT applied`;
      case 'domestic':
        return `Luxembourg customer - ${vatBreakdown.vat_rate}% VAT applied`;
      default:
        return 'VAT calculation applied';
    }
  };

  const getVATBadgeVariant = () => {
    switch (vatBreakdown.vat_type) {
      case 'export':
        return 'secondary';
      case 'b2b_reverse_charge':
        return 'outline';
      case 'b2c':
      case 'domestic':
        return 'default';
      default:
        return 'outline';
    }
  };

  return (
    <Card className="bg-gray-900/50 border-gray-700">
      <CardHeader className="pb-3">
        <CardTitle className="text-sm font-medium text-gray-200 flex items-center gap-2">
          <Info className="h-4 w-4" />
          Price Breakdown
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {/* Base Price */}
        <div className="flex justify-between items-center">
          <span className="text-sm text-gray-400">Base Price (Net)</span>
          <span className="text-sm font-medium text-white">
            {formatPrice(vatBreakdown.net_amount)}
          </span>
        </div>

        {/* VAT Information */}
        {vatBreakdown.vat_amount > 0 ? (
          <>
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-400">
                VAT ({vatBreakdown.vat_rate}%)
              </span>
              <span className="text-sm font-medium text-white">
                {formatPrice(vatBreakdown.vat_amount)}
              </span>
            </div>
            <Separator className="bg-gray-700" />
          </>
        ) : (
          <>
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-400">VAT</span>
              <Badge variant={getVATBadgeVariant() as any} className="text-xs">
                {vatBreakdown.vat_type === 'export' ? 'Exempt' : 'Reverse Charge'}
              </Badge>
            </div>
            <Separator className="bg-gray-700" />
          </>
        )}

        {/* Total */}
        <div className="flex justify-between items-center">
          <span className="text-base font-semibold text-white">
            Total Amount
          </span>
          <span className="text-lg font-bold text-green-400">
            {formatPrice(vatBreakdown.gross_amount)}
          </span>
        </div>

        {/* VAT Info Alert */}
        <Alert className="bg-blue-900/20 border-blue-700/50">
          <AlertDescription className="text-xs text-blue-200">
            {getVATDescription()}
            {vatNumber && (
              <div className="mt-1">
                <span className="font-medium">VAT Number:</span> {vatNumber}
              </div>
            )}
          </AlertDescription>
        </Alert>

        {/* Country Info */}
        <div className="text-xs text-gray-500">
          Billing Country: <span className="font-medium text-gray-400">{country}</span>
        </div>
      </CardContent>
    </Card>
  );
};

export default PriceBreakdown;
