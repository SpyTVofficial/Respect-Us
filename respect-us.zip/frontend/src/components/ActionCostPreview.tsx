
import React, { useState, useEffect } from 'react';
import { Coins, AlertTriangle, TrendingUp, Zap, CreditCard, Info, Clock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { useUser } from '@stackframe/react';
import { useCreditBalance } from 'utils/useCreditBalance';
import brain from 'brain';
import { toast } from 'sonner';

interface Props {
  componentName: string;
  actionName: string;
  actionLabel?: string;
  children?: React.ReactNode;
  onProceed?: () => void;
  disabled?: boolean;
  variant?: 'button' | 'card' | 'inline' | 'detailed';
  showFullPreview?: boolean;
  showPurchaseLink?: boolean;
  className?: string;
}

interface CostBreakdown {
  base_cost: number;
  tier_discount: number;
  geographic_multiplier: number;
  final_cost: number;
  tier_name?: string;
  next_tier_credits?: number;
  next_tier_discount?: number;
}

interface UsageEstimate {
  estimated_monthly_cost: number;
  similar_actions_this_month: number;
  average_cost_per_action: number;
}

export function ActionCostPreview({
  componentName,
  actionName,
  actionLabel,
  children,
  onProceed,
  disabled = false,
  variant = 'button',
  showFullPreview = false,
  showPurchaseLink = true,
  className = ''
}: Props) {
  const user = useUser();
  const { balance, refreshBalance } = useCreditBalance();
  const [cost, setCost] = useState<number | null>(null);
  const [costBreakdown, setCostBreakdown] = useState<CostBreakdown | null>(null);
  const [usageEstimate, setUsageEstimate] = useState<UsageEstimate | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [hasInsufficientCredits, setHasInsufficientCredits] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);

  useEffect(() => {
    if (user) {
      fetchCostInformation();
    }
  }, [user, componentName, actionName]);

  useEffect(() => {
    if (cost !== null && balance) {
      setHasInsufficientCredits(balance.current_balance < cost);
    }
  }, [cost, balance]);

  const fetchCostInformation = async () => {
    try {
      setIsLoading(true);
      
      // Fetch dynamic pricing
      const costResponse = await brain.check_dynamic_pricing({ 
        component: componentName, 
        action: actionName 
      });
      const costData = await costResponse.json();
      
      setCost(costData.final_cost);
      setCostBreakdown(costData.breakdown);
      
      // Fetch usage estimates
      try {
        const usageResponse = await brain.get_action_usage_estimate({ 
          component_name: componentName, 
          action_name: actionName 
        });
        const usageData = await usageResponse.json();
        setUsageEstimate(usageData);
      } catch (usageError) {
        console.log('Usage estimates not available:', usageError);
      }
      
    } catch (error) {
      console.error('Failed to fetch cost information:', error);
      toast.error('Failed to load pricing information');
    } finally {
      setIsLoading(false);
    }
  };

  const handleProceed = async () => {
    if (!onProceed) return;
    
    if (hasInsufficientCredits) {
      toast.error('Insufficient credits. Please purchase more credits to continue.');
      return;
    }
    
    setIsProcessing(true);
    try {
      await onProceed();
      refreshBalance(); // Refresh balance after action
    } catch (error) {
      console.error('Action failed:', error);
    } finally {
      setIsProcessing(false);
    }
  };

  const formatCredits = (credits: number) => {
    return credits.toLocaleString();
  };

  const getCostColor = () => {
    if (cost === null) return 'text-gray-400';
    if (hasInsufficientCredits) return 'text-red-400';
    if (cost === 0) return 'text-green-400';
    if (cost <= 10) return 'text-blue-400';
    if (cost <= 50) return 'text-yellow-400';
    return 'text-orange-400';
  };

  const getCostBadgeVariant = () => {
    if (cost === null || cost === 0) return 'secondary';
    if (hasInsufficientCredits) return 'destructive';
    if (cost <= 10) return 'default';
    return 'secondary';
  };

  // Detailed cost breakdown component
  const CostBreakdownCard = () => (
    <Card className="bg-gray-800 border-gray-700">
      <CardHeader className="pb-3">
        <CardTitle className="text-sm text-gray-300">Cost Breakdown</CardTitle>
      </CardHeader>
      <CardContent className="space-y-2">
        {costBreakdown && (
          <>
            <div className="flex justify-between text-sm">
              <span className="text-gray-400">Base Cost:</span>
              <span className="text-white">{formatCredits(costBreakdown.base_cost)} credits</span>
            </div>
            
            {costBreakdown.tier_discount > 0 && (
              <div className="flex justify-between text-sm">
                <span className="text-gray-400">Tier Discount ({costBreakdown.tier_name}):</span>
                <span className="text-green-400">-{formatCredits(costBreakdown.tier_discount)} credits</span>
              </div>
            )}
            
            {costBreakdown.geographic_multiplier !== 1 && (
              <div className="flex justify-between text-sm">
                <span className="text-gray-400">Regional Adjustment:</span>
                <span className={costBreakdown.geographic_multiplier > 1 ? 'text-orange-400' : 'text-green-400'}>
                  {costBreakdown.geographic_multiplier > 1 ? '+' : ''}
                  {formatCredits(Math.round((costBreakdown.geographic_multiplier - 1) * costBreakdown.base_cost))} credits
                </span>
              </div>
            )}
            
            <hr className="border-gray-600" />
            <div className="flex justify-between text-sm font-medium">
              <span className="text-gray-300">Final Cost:</span>
              <span className={getCostColor()}>{formatCredits(costBreakdown.final_cost)} credits</span>
            </div>
            
            {costBreakdown.next_tier_credits && (
              <div className="text-xs text-gray-500 mt-2">
                💡 Use {formatCredits(costBreakdown.next_tier_credits)} more credits this month to unlock {costBreakdown.next_tier_discount}% discount
              </div>
            )}
          </>
        )}
      </CardContent>
    </Card>
  );

  // Usage estimate component
  const UsageEstimateCard = () => (
    <Card className="bg-gray-800 border-gray-700">
      <CardHeader className="pb-3">
        <CardTitle className="text-sm text-gray-300">Usage Insights</CardTitle>
      </CardHeader>
      <CardContent className="space-y-2">
        {usageEstimate && (
          <>
            <div className="flex justify-between text-sm">
              <span className="text-gray-400">Similar actions this month:</span>
              <span className="text-white">{usageEstimate.similar_actions_this_month}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-gray-400">Average cost per action:</span>
              <span className="text-blue-400">{formatCredits(usageEstimate.average_cost_per_action)} credits</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-gray-400">Estimated monthly cost:</span>
              <span className="text-purple-400">{formatCredits(usageEstimate.estimated_monthly_cost)} credits</span>
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );

  if (isLoading) {
    return (
      <div className={`flex items-center space-x-2 ${className}`}>
        <div className="animate-pulse flex items-center space-x-2">
          <div className="w-4 h-4 bg-gray-600 rounded"></div>
          <div className="w-16 h-4 bg-gray-600 rounded"></div>
        </div>
      </div>
    );
  }

  // Inline variant - just show cost
  if (variant === 'inline') {
    return (
      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>
            <div className={`inline-flex items-center space-x-1 ${className}`}>
              <Coins className="w-3 h-3 text-gray-400" />
              <span className={`text-xs font-medium ${getCostColor()}`}>
                {cost !== null ? formatCredits(cost) : '...'} credits
              </span>
              {hasInsufficientCredits && <AlertTriangle className="w-3 h-3 text-red-400" />}
            </div>
          </TooltipTrigger>
          <TooltipContent>
            <p>Cost for {actionLabel || actionName}</p>
            {hasInsufficientCredits && <p className="text-red-400">Insufficient credits</p>}
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>
    );
  }

  // Card variant - comprehensive preview
  if (variant === 'card' || variant === 'detailed') {
    return (
      <Card className={`bg-gray-900 border-gray-800 ${className}`}>
        <CardHeader>
          <CardTitle className="text-white flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Coins className="w-5 h-5 text-purple-400" />
              <span>Action Cost Preview</span>
            </div>
            <Badge variant={getCostBadgeVariant()}>
              {cost !== null ? `${formatCredits(cost)} credits` : 'Loading...'}
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Current Balance */}
          {balance && (
            <div className="flex justify-between items-center p-3 bg-gray-800 rounded-lg">
              <span className="text-gray-400">Current Balance:</span>
              <span className="font-medium text-purple-400">
                {formatCredits(balance.current_balance)} credits
              </span>
            </div>
          )}

          {/* Insufficient Credits Warning */}
          {hasInsufficientCredits && (
            <Alert className="bg-red-900/20 border-red-500/30">
              <AlertTriangle className="w-4 h-4" />
              <AlertDescription className="text-red-300">
                <div className="flex items-center justify-between">
                  <span>Insufficient credits for this action.</span>
                  {showPurchaseLink && (
                    <Button size="sm" className="bg-red-600 hover:bg-red-700">
                      <CreditCard className="w-3 h-3 mr-1" />
                      Buy Credits
                    </Button>
                  )}
                </div>
              </AlertDescription>
            </Alert>
          )}

          {/* Cost breakdown for detailed variant */}
          {variant === 'detailed' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <CostBreakdownCard />
              {usageEstimate && <UsageEstimateCard />}
            </div>
          )}

          {/* Action button */}
          {children || onProceed ? (
            <div className="flex space-x-3">
              {children}
              {onProceed && (
                <Button 
                  onClick={handleProceed}
                  disabled={disabled || hasInsufficientCredits || isProcessing}
                  className="flex-1"
                >
                  {isProcessing ? (
                    <>
                      <div className="w-4 h-4 animate-spin rounded-full border-2 border-white border-t-transparent mr-2"></div>
                      Processing...
                    </>
                  ) : (
                    <>
                      <Zap className="w-4 h-4 mr-2" />
                      {actionLabel || `Execute ${actionName}`}
                    </>
                  )}
                </Button>
              )}
            </div>
          ) : null}

          {/* Balance after action */}
          {balance && cost !== null && !hasInsufficientCredits && (
            <div className="text-xs text-gray-500 flex items-center space-x-1">
              <Clock className="w-3 h-3" />
              <span>
                Balance after action: {formatCredits(balance.current_balance - cost)} credits
              </span>
            </div>
          )}
        </CardContent>
      </Card>
    );
  }

  // Button variant - default
  return (
    <div className={`space-y-2 ${className}`}>
      {/* Cost display */}
      <div className="flex items-center justify-between p-2 bg-gray-800 rounded-lg">
        <div className="flex items-center space-x-2">
          <Coins className="w-4 h-4 text-purple-400" />
          <span className="text-sm text-gray-400">Cost:</span>
          <span className={`text-sm font-medium ${getCostColor()}`}>
            {cost !== null ? formatCredits(cost) : 'Loading...'} credits
          </span>
        </div>
        
        {showFullPreview && (
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button variant="ghost" size="sm">
                  <Info className="w-3 h-3" />
                </Button>
              </TooltipTrigger>
              <TooltipContent side="left" className="max-w-sm">
                {costBreakdown && (
                  <div className="space-y-1 text-xs">
                    <div>Base: {formatCredits(costBreakdown.base_cost)} credits</div>
                    {costBreakdown.tier_discount > 0 && (
                      <div>Discount: -{formatCredits(costBreakdown.tier_discount)} credits</div>
                    )}
                    <div>Final: {formatCredits(costBreakdown.final_cost)} credits</div>
                  </div>
                )}
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        )}
      </div>

      {/* Insufficient credits warning */}
      {hasInsufficientCredits && (
        <Alert className="bg-red-900/20 border-red-500/30">
          <AlertTriangle className="w-4 h-4" />
          <AlertDescription className="text-red-300 text-sm">
            Insufficient credits. Current balance: {balance?.current_balance || 0}
          </AlertDescription>
        </Alert>
      )}

      {/* Action content */}
      <div className="space-y-2">
        {children}
        {onProceed && (
          <Button 
            onClick={handleProceed}
            disabled={disabled || hasInsufficientCredits || isProcessing}
            className="w-full"
          >
            {isProcessing ? (
              <>
                <div className="w-4 h-4 animate-spin rounded-full border-2 border-white border-t-transparent mr-2"></div>
                Processing...
              </>
            ) : (
              <>
                {actionLabel || `Execute ${actionName}`}
                {cost !== null && (
                  <span className="ml-2 text-xs opacity-75">
                    ({formatCredits(cost)} credits)
                  </span>
                )}
              </>
            )}
          </Button>
        )}
      </div>
    </div>
  );
}

export default ActionCostPreview;
