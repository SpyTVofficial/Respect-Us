



import React, { useState, useEffect } from 'react';
import { Users, Shield, AlertTriangle, Download, Upload, Search, Filter, Eye, Trash2, Edit, Plus, UserCheck, Clock, TrendingUp, Activity, BarChart3, FileText, CheckCircle, XCircle, AlertCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Separator } from '@/components/ui/separator';
import { toast } from 'sonner';
import brain from 'brain';
import {
  CustomerProfile,
  ScreeningResult,
  ScreeningAlert,
  BatchScreeningRequest,
  ScreeningExportRequest
} from 'brain/data-contracts';

interface CustomerScreeningAdminProps {
  onRefresh?: () => void;
}

interface CustomerStats {
  total_customers: number;
  screened_customers: number;
  high_risk_customers: number;
  pending_alerts: number;
  screening_rate: number;
  false_positive_rate: number;
}

function CustomerScreeningAdmin({ onRefresh }: CustomerScreeningAdminProps) {
  const [activeTab, setActiveTab] = useState('overview');
  const [customers, setCustomers] = useState<CustomerProfile[]>([]);
  const [alerts, setAlerts] = useState<ScreeningAlert[]>([]);
  const [stats, setStats] = useState<CustomerStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [riskFilter, setRiskFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  
  // Dialog states
  const [showCustomerDialog, setShowCustomerDialog] = useState(false);
  const [showBatchDialog, setShowBatchDialog] = useState(false);
  const [showExportDialog, setShowExportDialog] = useState(false);
  const [showViewDialog, setShowViewDialog] = useState(false);
  const [selectedCustomer, setSelectedCustomer] = useState<CustomerProfile | null>(null);
  const [selectedCustomers, setSelectedCustomers] = useState<number[]>([]);
  
  // Form states
  const [customerForm, setCustomerForm] = useState({
    customer_name: '',
    customer_type: 'individual',
    legal_name: '',
    aliases: [] as string[],
    birth_date: '',
    country: '',
    address: '',
    notes: ''
  });
  
  const [batchScreening, setBatchScreening] = useState({
    screen_all: false,
    customer_ids: [] as number[],
    force_rescreen: false
  });
  
  const [exportSettings, setExportSettings] = useState({
    format: 'json',
    include_history: true,
    include_matches: true,
    date_range: 'all'
  });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    await Promise.all([
      loadCustomers(),
      loadAlerts(),
      loadStats()
    ]);
  };

  const loadCustomers = async () => {
    try {
      setLoading(true);
      const response = await brain.list_customers({ limit: 100 });
      
      if (response.ok) {
        const data = await response.json();
        setCustomers(Array.isArray(data) ? data : []);
      } else {
        console.error('Failed to load customers:', response.status);
        setCustomers([]);
      }
    } catch (error) {
      console.error('Error loading customers:', error);
      setCustomers([]);
      toast.error('Failed to load customers');
    } finally {
      setLoading(false);
    }
  };

  const loadAlerts = async () => {
    try {
      const response = await brain.get_screening_alerts({ priority: 'all' });
      
      if (response.ok) {
        const data = await response.json();
        setAlerts(Array.isArray(data.alerts) ? data.alerts : []);
      } else {
        console.error('Failed to load alerts:', response.status);
        setAlerts([]);
      }
    } catch (error) {
      console.error('Error loading alerts:', error);
      setAlerts([]);
    }
  };

  const loadStats = async () => {
    try {
      // Calculate stats from available data
      const totalCustomers = customers.length;
      const screenedCustomers = customers.filter(c => c.last_screened).length;
      const highRiskCustomers = customers.filter(c => c.risk_score && c.risk_score >= 70).length;
      const pendingAlerts = alerts.filter(a => a.status === 'pending').length;
      
      setStats({
        total_customers: totalCustomers,
        screened_customers: screenedCustomers,
        high_risk_customers: highRiskCustomers,
        pending_alerts: pendingAlerts,
        screening_rate: totalCustomers > 0 ? (screenedCustomers / totalCustomers) * 100 : 0,
        false_positive_rate: 15.2 // Mock value
      });
    } catch (error) {
      console.error('Error calculating stats:', error);
    }
  };

  const handleCreateCustomer = async () => {
    try {
      const response = await brain.create_customer({
        ...customerForm,
        aliases: customerForm.aliases.filter(a => a.trim() !== '')
      });
      
      if (response.ok) {
        toast.success('Customer created successfully');
        setShowCustomerDialog(false);
        setCustomerForm({
          customer_name: '',
          customer_type: 'individual',
          legal_name: '',
          aliases: [],
          birth_date: '',
          country: '',
          address: '',
          notes: ''
        });
        await loadCustomers();
        onRefresh?.();
      } else {
        toast.error('Failed to create customer');
      }
    } catch (error) {
      console.error('Error creating customer:', error);
      toast.error('Failed to create customer');
    }
  };

  const handleDeleteCustomer = async (customerId: number) => {
    if (!confirm('Are you sure you want to delete this customer? This will remove all screening history.')) {
      return;
    }
    
    try {
      const response = await brain.delete_customer({ customerId });
      
      if (response.ok) {
        toast.success('Customer deleted successfully');
        await loadCustomers();
        onRefresh?.();
      } else {
        toast.error('Failed to delete customer');
      }
    } catch (error) {
      console.error('Error deleting customer:', error);
      toast.error('Failed to delete customer');
    }
  };

  const handleBatchScreening = async () => {
    try {
      const request: BatchScreeningRequest = {
        customer_ids: batchScreening.screen_all ? customers.map(c => c.id!).filter(Boolean) : batchScreening.customer_ids,
        force_rescreen: batchScreening.force_rescreen
      };
      
      const response = await brain.batch_screen_customers(request);
      
      if (response.ok) {
        toast.success('Batch screening initiated successfully');
        setShowBatchDialog(false);
        await loadCustomers();
        await loadAlerts();
      } else {
        toast.error('Failed to start batch screening');
      }
    } catch (error) {
      console.error('Error with batch screening:', error);
      toast.error('Failed to start batch screening');
    }
  };

  const handleExportResults = async () => {
    try {
      const request: ScreeningExportRequest = {
        format: exportSettings.format as 'json' | 'csv' | 'pdf',
        customer_ids: selectedCustomers.length > 0 ? selectedCustomers : undefined,
        include_history: exportSettings.include_history,
        include_match_details: exportSettings.include_matches
      };
      
      const response = await brain.export_screening_results(request);
      
      if (response.ok) {
        const data = await response.json();
        toast.success('Export completed successfully');
        setShowExportDialog(false);
        
        // Download the exported data
        if (data.download_url) {
          window.open(data.download_url, '_blank');
        }
      } else {
        toast.error('Failed to export results');
      }
    } catch (error) {
      console.error('Error exporting results:', error);
      toast.error('Failed to export results');
    }
  };

  const handleScreenCustomer = async (customerId: number) => {
    try {
      const response = await brain.screen_customer({ customerId });
      
      if (response.ok) {
        toast.success('Customer screening completed');
        await loadCustomers();
        await loadAlerts();
      } else {
        toast.error('Failed to screen customer');
      }
    } catch (error) {
      console.error('Error screening customer:', error);
      toast.error('Failed to screen customer');
    }
  };

  const filteredCustomers = customers.filter(customer => {
    const matchesSearch = customer.customer_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         customer.legal_name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         customer.country?.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesRisk = riskFilter === 'all' || 
                       (riskFilter === 'high' && customer.risk_score && customer.risk_score >= 70) ||
                       (riskFilter === 'medium' && customer.risk_score && customer.risk_score >= 40 && customer.risk_score < 70) ||
                       (riskFilter === 'low' && customer.risk_score && customer.risk_score < 40);
    
    const matchesStatus = statusFilter === 'all' ||
                         (statusFilter === 'screened' && customer.last_screened) ||
                         (statusFilter === 'unscreened' && !customer.last_screened);
    
    return matchesSearch && matchesRisk && matchesStatus;
  });

  const getRiskBadgeColor = (score?: number) => {
    if (!score) return 'bg-gray-500';
    if (score >= 70) return 'bg-red-500';
    if (score >= 40) return 'bg-yellow-500';
    return 'bg-green-500';
  };

  const getRiskLabel = (score?: number) => {
    if (!score) return 'Unknown';
    if (score >= 70) return 'High Risk';
    if (score >= 40) return 'Medium Risk';
    return 'Low Risk';
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-white">Customer Screening Management</h2>
          <p className="text-gray-400 mt-1">Manage customer profiles and screening operations</p>
        </div>
        <div className="flex gap-3">
          <Button 
            onClick={() => setShowBatchDialog(true)}
            className="bg-blue-600 hover:bg-blue-700"
          >
            <Upload className="w-4 h-4 mr-2" />
            Batch Screen
          </Button>
          <Button 
            onClick={() => setShowExportDialog(true)}
            className="bg-purple-600 hover:bg-purple-700"
          >
            <Download className="w-4 h-4 mr-2" />
            Export
          </Button>
          <Button 
            onClick={() => setShowCustomerDialog(true)}
            className="bg-green-600 hover:bg-green-700"
          >
            <Plus className="w-4 h-4 mr-2" />
            Add Customer
          </Button>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="bg-gray-800 border-gray-700">
          <TabsTrigger value="overview" className="data-[state=active]:bg-gray-700">
            <BarChart3 className="w-4 h-4 mr-2" />
            Overview
          </TabsTrigger>
          <TabsTrigger value="customers" className="data-[state=active]:bg-gray-700">
            <Users className="w-4 h-4 mr-2" />
            Customers
          </TabsTrigger>
          <TabsTrigger value="alerts" className="data-[state=active]:bg-gray-700">
            <AlertTriangle className="w-4 h-4 mr-2" />
            Alerts
          </TabsTrigger>
        </TabsList>

        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-6">
          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <Card className="bg-gray-800/50 border-gray-700">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-gray-300">Total Customers</CardTitle>
                <Users className="h-4 w-4 text-blue-400" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-white">{stats?.total_customers || 0}</div>
                <p className="text-xs text-gray-400 mt-1">Active customer profiles</p>
              </CardContent>
            </Card>

            <Card className="bg-gray-800/50 border-gray-700">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-gray-300">Screened</CardTitle>
                <Shield className="h-4 w-4 text-green-400" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-white">{stats?.screened_customers || 0}</div>
                <p className="text-xs text-gray-400 mt-1">{stats?.screening_rate.toFixed(1)}% screening rate</p>
              </CardContent>
            </Card>

            <Card className="bg-gray-800/50 border-gray-700">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-gray-300">High Risk</CardTitle>
                <AlertTriangle className="h-4 w-4 text-red-400" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-white">{stats?.high_risk_customers || 0}</div>
                <p className="text-xs text-gray-400 mt-1">Requiring attention</p>
              </CardContent>
            </Card>

            <Card className="bg-gray-800/50 border-gray-700">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-gray-300">Pending Alerts</CardTitle>
                <Clock className="h-4 w-4 text-yellow-400" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-white">{stats?.pending_alerts || 0}</div>
                <p className="text-xs text-gray-400 mt-1">Awaiting review</p>
              </CardContent>
            </Card>

            <Card className="bg-gray-800/50 border-gray-700">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-gray-300">Screening Rate</CardTitle>
                <TrendingUp className="h-4 w-4 text-blue-400" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-white">{stats?.screening_rate.toFixed(1)}%</div>
                <p className="text-xs text-gray-400 mt-1">Coverage percentage</p>
              </CardContent>
            </Card>

            <Card className="bg-gray-800/50 border-gray-700">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-gray-300">False Positive Rate</CardTitle>
                <Activity className="h-4 w-4 text-purple-400" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-white">{stats?.false_positive_rate}%</div>
                <p className="text-xs text-gray-400 mt-1">System accuracy</p>
              </CardContent>
            </Card>
          </div>

          {/* Recent Activity */}
          <Card className="bg-gray-800/50 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white">Recent Screening Activity</CardTitle>
              <CardDescription>Latest customer screening operations</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {customers.slice(0, 5).map((customer) => (
                  <div key={customer.id} className="flex items-center justify-between p-3 bg-gray-700/30 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                      <div>
                        <p className="text-white font-medium">{customer.customer_name}</p>
                        <p className="text-gray-400 text-sm">{customer.customer_type}</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-3">
                      <Badge className={`${getRiskBadgeColor(customer.risk_score)} text-white`}>
                        {getRiskLabel(customer.risk_score)}
                      </Badge>
                      <span className="text-gray-400 text-sm">
                        {customer.last_screened ? new Date(customer.last_screened).toLocaleDateString() : 'Not screened'}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Customers Tab */}
        <TabsContent value="customers" className="space-y-6">
          {/* Search and Filters */}
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  placeholder="Search customers..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 bg-gray-700 border-gray-600 text-white"
                />
              </div>
            </div>
            <Select value={riskFilter} onValueChange={setRiskFilter}>
              <SelectTrigger className="w-[180px] bg-gray-700 border-gray-600 text-white">
                <SelectValue placeholder="Risk Level" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Risk Levels</SelectItem>
                <SelectItem value="high">High Risk</SelectItem>
                <SelectItem value="medium">Medium Risk</SelectItem>
                <SelectItem value="low">Low Risk</SelectItem>
              </SelectContent>
            </Select>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-[180px] bg-gray-700 border-gray-600 text-white">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="screened">Screened</SelectItem>
                <SelectItem value="unscreened">Unscreened</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Customers Table */}
          <Card className="bg-gray-800/50 border-gray-700">
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-gray-700">
                      <th className="text-left p-4 text-gray-300 font-medium">
                        <input 
                          type="checkbox" 
                          className="rounded border-gray-600 bg-gray-700"
                          onChange={(e) => {
                            if (e.target.checked) {
                              setSelectedCustomers(filteredCustomers.map(c => c.id!).filter(Boolean));
                            } else {
                              setSelectedCustomers([]);
                            }
                          }}
                        />
                      </th>
                      <th className="text-left p-4 text-gray-300 font-medium">Customer</th>
                      <th className="text-left p-4 text-gray-300 font-medium">Type</th>
                      <th className="text-left p-4 text-gray-300 font-medium">Country</th>
                      <th className="text-left p-4 text-gray-300 font-medium">Risk Score</th>
                      <th className="text-left p-4 text-gray-300 font-medium">Last Screened</th>
                      <th className="text-left p-4 text-gray-300 font-medium">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {loading ? (
                      <tr>
                        <td colSpan={7} className="text-center p-8 text-gray-400">
                          Loading customers...
                        </td>
                      </tr>
                    ) : filteredCustomers.length === 0 ? (
                      <tr>
                        <td colSpan={7} className="text-center p-8 text-gray-400">
                          No customers found
                        </td>
                      </tr>
                    ) : (
                      filteredCustomers.map((customer) => (
                        <tr key={customer.id} className="border-b border-gray-700/50 hover:bg-gray-700/20">
                          <td className="p-4">
                            <input 
                              type="checkbox" 
                              className="rounded border-gray-600 bg-gray-700"
                              checked={selectedCustomers.includes(customer.id!)}
                              onChange={(e) => {
                                if (e.target.checked) {
                                  setSelectedCustomers([...selectedCustomers, customer.id!]);
                                } else {
                                  setSelectedCustomers(selectedCustomers.filter(id => id !== customer.id));
                                }
                              }}
                            />
                          </td>
                          <td className="p-4">
                            <div>
                              <p className="text-white font-medium">{customer.customer_name}</p>
                              {customer.legal_name && (
                                <p className="text-gray-400 text-sm">{customer.legal_name}</p>
                              )}
                            </div>
                          </td>
                          <td className="p-4">
                            <Badge variant="outline" className="border-gray-600 text-gray-300">
                              {customer.customer_type}
                            </Badge>
                          </td>
                          <td className="p-4 text-gray-300">{customer.country || 'N/A'}</td>
                          <td className="p-4">
                            <Badge className={`${getRiskBadgeColor(customer.risk_score)} text-white`}>
                              {customer.risk_score ? `${customer.risk_score}%` : 'N/A'}
                            </Badge>
                          </td>
                          <td className="p-4 text-gray-300">
                            {customer.last_screened ? 
                              new Date(customer.last_screened).toLocaleDateString() : 
                              'Never'
                            }
                          </td>
                          <td className="p-4">
                            <div className="flex items-center space-x-2">
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => {
                                  setSelectedCustomer(customer);
                                  setShowViewDialog(true);
                                }}
                                className="border-gray-600 text-gray-300 hover:bg-gray-700"
                              >
                                <Eye className="w-4 h-4" />
                              </Button>
                              <Button
                                size="sm"
                                onClick={() => handleScreenCustomer(customer.id!)}
                                className="bg-blue-600 hover:bg-blue-700"
                              >
                                <Shield className="w-4 h-4" />
                              </Button>
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => handleDeleteCustomer(customer.id!)}
                                className="border-red-600 text-red-400 hover:bg-red-600/20"
                              >
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </div>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Alerts Tab */}
        <TabsContent value="alerts" className="space-y-6">
          <Card className="bg-gray-800/50 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white">Screening Alerts</CardTitle>
              <CardDescription>High-priority matches requiring review</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {alerts.length === 0 ? (
                  <div className="text-center p-8 text-gray-400">
                    <AlertCircle className="w-12 h-12 mx-auto mb-4 text-gray-500" />
                    <p>No alerts at this time</p>
                  </div>
                ) : (
                  alerts.map((alert) => (
                    <div key={alert.id} className="flex items-center justify-between p-4 bg-gray-700/30 rounded-lg border border-gray-600">
                      <div className="flex items-center space-x-4">
                        <div className={`w-3 h-3 rounded-full ${alert.priority === 'high' ? 'bg-red-500' : alert.priority === 'medium' ? 'bg-yellow-500' : 'bg-blue-500'}`}></div>
                        <div>
                          <p className="text-white font-medium">{alert.customer_name}</p>
                          <p className="text-gray-400 text-sm">{alert.match_type} - {alert.list_name}</p>
                          <p className="text-gray-400 text-sm">Score: {alert.match_score}%</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-3">
                        <Badge className={`${alert.priority === 'high' ? 'bg-red-500' : alert.priority === 'medium' ? 'bg-yellow-500' : 'bg-blue-500'} text-white`}>
                          {alert.priority} priority
                        </Badge>
                        <span className="text-gray-400 text-sm">
                          {new Date(alert.created_at).toLocaleDateString()}
                        </span>
                        <Button size="sm" className="bg-blue-600 hover:bg-blue-700">
                          Review
                        </Button>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Create Customer Dialog */}
      <Dialog open={showCustomerDialog} onOpenChange={setShowCustomerDialog}>
        <DialogContent className="bg-gray-800 border-gray-600 text-white max-w-2xl">
          <DialogHeader>
            <DialogTitle>Add New Customer</DialogTitle>
            <DialogDescription>
              Create a new customer profile for screening
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label className="text-gray-300">Customer Name *</Label>
                <Input
                  value={customerForm.customer_name}
                  onChange={(e) => setCustomerForm({ ...customerForm, customer_name: e.target.value })}
                  className="bg-gray-700 border-gray-600 text-white"
                  placeholder="Enter customer name"
                />
              </div>
              <div>
                <Label className="text-gray-300">Customer Type</Label>
                <Select 
                  value={customerForm.customer_type} 
                  onValueChange={(value) => setCustomerForm({ ...customerForm, customer_type: value })}
                >
                  <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="individual">Individual</SelectItem>
                    <SelectItem value="entity">Entity</SelectItem>
                    <SelectItem value="vessel">Vessel</SelectItem>
                    <SelectItem value="airplane">Airplane</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label className="text-gray-300">Legal Name</Label>
                <Input
                  value={customerForm.legal_name}
                  onChange={(e) => setCustomerForm({ ...customerForm, legal_name: e.target.value })}
                  className="bg-gray-700 border-gray-600 text-white"
                  placeholder="Legal name (if different)"
                />
              </div>
              <div>
                <Label className="text-gray-300">Birth Date</Label>
                <Input
                  type="date"
                  value={customerForm.birth_date}
                  onChange={(e) => setCustomerForm({ ...customerForm, birth_date: e.target.value })}
                  className="bg-gray-700 border-gray-600 text-white"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label className="text-gray-300">Country</Label>
                <Input
                  value={customerForm.country}
                  onChange={(e) => setCustomerForm({ ...customerForm, country: e.target.value })}
                  className="bg-gray-700 border-gray-600 text-white"
                  placeholder="Country of residence/registration"
                />
              </div>
              <div>
                <Label className="text-gray-300">Aliases</Label>
                <Input
                  value={customerForm.aliases.join(', ')}
                  onChange={(e) => setCustomerForm({ ...customerForm, aliases: e.target.value.split(',').map(a => a.trim()) })}
                  className="bg-gray-700 border-gray-600 text-white"
                  placeholder="Alternative names (comma-separated)"
                />
              </div>
            </div>

            <div>
              <Label className="text-gray-300">Address</Label>
              <Textarea
                value={customerForm.address}
                onChange={(e) => setCustomerForm({ ...customerForm, address: e.target.value })}
                className="bg-gray-700 border-gray-600 text-white"
                placeholder="Customer address"
                rows={2}
              />
            </div>

            <div>
              <Label className="text-gray-300">Notes</Label>
              <Textarea
                value={customerForm.notes}
                onChange={(e) => setCustomerForm({ ...customerForm, notes: e.target.value })}
                className="bg-gray-700 border-gray-600 text-white"
                placeholder="Additional notes or comments"
                rows={3}
              />
            </div>

            <div className="flex justify-end space-x-3">
              <Button 
                variant="outline" 
                onClick={() => setShowCustomerDialog(false)}
                className="border-gray-600 text-gray-300 hover:bg-gray-700"
              >
                Cancel
              </Button>
              <Button 
                onClick={handleCreateCustomer}
                className="bg-green-600 hover:bg-green-700"
                disabled={!customerForm.customer_name.trim()}
              >
                Create Customer
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Batch Screening Dialog */}
      <Dialog open={showBatchDialog} onOpenChange={setShowBatchDialog}>
        <DialogContent className="bg-gray-800 border-gray-600 text-white">
          <DialogHeader>
            <DialogTitle>Batch Screening</DialogTitle>
            <DialogDescription>
              Screen multiple customers against watchlists
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <input
                type="checkbox"
                id="screen-all"
                checked={batchScreening.screen_all}
                onChange={(e) => setBatchScreening({ ...batchScreening, screen_all: e.target.checked })}
                className="rounded border-gray-600 bg-gray-700"
              />
              <Label htmlFor="screen-all" className="text-gray-300">Screen all customers</Label>
            </div>
            
            <div className="flex items-center space-x-2">
              <input
                type="checkbox"
                id="force-rescreen"
                checked={batchScreening.force_rescreen}
                onChange={(e) => setBatchScreening({ ...batchScreening, force_rescreen: e.target.checked })}
                className="rounded border-gray-600 bg-gray-700"
              />
              <Label htmlFor="force-rescreen" className="text-gray-300">Force re-screen (override recent screenings)</Label>
            </div>

            {!batchScreening.screen_all && (
              <div>
                <Label className="text-gray-300">Selected Customers</Label>
                <p className="text-gray-400 text-sm">{selectedCustomers.length} customers selected</p>
              </div>
            )}

            <div className="flex justify-end space-x-3">
              <Button 
                variant="outline" 
                onClick={() => setShowBatchDialog(false)}
                className="border-gray-600 text-gray-300 hover:bg-gray-700"
              >
                Cancel
              </Button>
              <Button 
                onClick={handleBatchScreening}
                className="bg-blue-600 hover:bg-blue-700"
              >
                Start Screening
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Export Dialog */}
      <Dialog open={showExportDialog} onOpenChange={setShowExportDialog}>
        <DialogContent className="bg-gray-800 border-gray-600 text-white">
          <DialogHeader>
            <DialogTitle>Export Screening Results</DialogTitle>
            <DialogDescription>
              Export customer screening data and results
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label className="text-gray-300">Export Format</Label>
              <Select 
                value={exportSettings.format} 
                onValueChange={(value) => setExportSettings({ ...exportSettings, format: value })}
              >
                <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="json">JSON</SelectItem>
                  <SelectItem value="csv">CSV</SelectItem>
                  <SelectItem value="pdf">PDF</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  id="include-history"
                  checked={exportSettings.include_history}
                  onChange={(e) => setExportSettings({ ...exportSettings, include_history: e.target.checked })}
                  className="rounded border-gray-600 bg-gray-700"
                />
                <Label htmlFor="include-history" className="text-gray-300">Include screening history</Label>
              </div>
              
              <div className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  id="include-matches"
                  checked={exportSettings.include_matches}
                  onChange={(e) => setExportSettings({ ...exportSettings, include_matches: e.target.checked })}
                  className="rounded border-gray-600 bg-gray-700"
                />
                <Label htmlFor="include-matches" className="text-gray-300">Include match details</Label>
              </div>
            </div>

            <div className="flex justify-end space-x-3">
              <Button 
                variant="outline" 
                onClick={() => setShowExportDialog(false)}
                className="border-gray-600 text-gray-300 hover:bg-gray-700"
              >
                Cancel
              </Button>
              <Button 
                onClick={handleExportResults}
                className="bg-purple-600 hover:bg-purple-700"
              >
                Export
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* View Customer Dialog */}
      <Dialog open={showViewDialog} onOpenChange={setShowViewDialog}>
        <DialogContent className="bg-gray-800 border-gray-600 text-white max-w-3xl">
          <DialogHeader>
            <DialogTitle>Customer Details</DialogTitle>
            <DialogDescription>
              View customer information and screening history
            </DialogDescription>
          </DialogHeader>
          {selectedCustomer && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div>
                    <Label className="text-gray-300">Customer Name</Label>
                    <p className="text-white font-medium">{selectedCustomer.customer_name}</p>
                  </div>
                  <div>
                    <Label className="text-gray-300">Type</Label>
                    <p className="text-white">{selectedCustomer.customer_type}</p>
                  </div>
                  <div>
                    <Label className="text-gray-300">Legal Name</Label>
                    <p className="text-white">{selectedCustomer.legal_name || 'N/A'}</p>
                  </div>
                  <div>
                    <Label className="text-gray-300">Country</Label>
                    <p className="text-white">{selectedCustomer.country || 'N/A'}</p>
                  </div>
                </div>
                <div className="space-y-4">
                  <div>
                    <Label className="text-gray-300">Risk Score</Label>
                    <div className="flex items-center space-x-2">
                      <Badge className={`${getRiskBadgeColor(selectedCustomer.risk_score)} text-white`}>
                        {selectedCustomer.risk_score ? `${selectedCustomer.risk_score}%` : 'N/A'}
                      </Badge>
                      <span className="text-gray-400">{getRiskLabel(selectedCustomer.risk_score)}</span>
                    </div>
                  </div>
                  <div>
                    <Label className="text-gray-300">Last Screened</Label>
                    <p className="text-white">
                      {selectedCustomer.last_screened ? 
                        new Date(selectedCustomer.last_screened).toLocaleString() : 
                        'Never screened'
                      }
                    </p>
                  </div>
                  <div>
                    <Label className="text-gray-300">Birth Date</Label>
                    <p className="text-white">{selectedCustomer.birth_date || 'N/A'}</p>
                  </div>
                </div>
              </div>
              
              {selectedCustomer.aliases && selectedCustomer.aliases.length > 0 && (
                <div>
                  <Label className="text-gray-300">Aliases</Label>
                  <div className="flex flex-wrap gap-2 mt-2">
                    {selectedCustomer.aliases.map((alias, index) => (
                      <Badge key={index} variant="outline" className="border-gray-600 text-gray-300">
                        {alias}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}
              
              {selectedCustomer.address && (
                <div>
                  <Label className="text-gray-300">Address</Label>
                  <p className="text-white">{selectedCustomer.address}</p>
                </div>
              )}
              
              {selectedCustomer.notes && (
                <div>
                  <Label className="text-gray-300">Notes</Label>
                  <p className="text-white">{selectedCustomer.notes}</p>
                </div>
              )}

              <div className="flex justify-end space-x-3">
                <Button 
                  variant="outline" 
                  onClick={() => setShowViewDialog(false)}
                  className="border-gray-600 text-gray-300 hover:bg-gray-700"
                >
                  Close
                </Button>
                <Button 
                  onClick={() => {
                    handleScreenCustomer(selectedCustomer.id!);
                    setShowViewDialog(false);
                  }}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  <Shield className="w-4 h-4 mr-2" />
                  Screen Customer
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

export default CustomerScreeningAdmin;
