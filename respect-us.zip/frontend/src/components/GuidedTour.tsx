
import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { X, ArrowRight, ArrowLeft, CheckCircle, Play } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface TourStep {
  id: string;
  title: string;
  description: string;
  target?: string;
  action?: () => void;
  actionText?: string;
  position?: 'top' | 'bottom' | 'left' | 'right';
}

interface GuidedTourProps {
  isOpen: boolean;
  onClose: () => void;
  onComplete: () => void;
}

const GuidedTour: React.FC<GuidedTourProps> = ({ isOpen, onClose, onComplete }) => {
  const navigate = useNavigate();
  const [currentStep, setCurrentStep] = useState(0);
  const [completedSteps, setCompletedSteps] = useState<string[]>([]);

  const tourSteps: TourStep[] = [
    {
      id: 'welcome',
      title: 'Welcome to RespectUs!',
      description: 'Let\'s take a quick tour to show you how RespectUs can transform your export control compliance workflow.',
    },
    {
      id: 'knowledge-base',
      title: 'Start with Knowledge Base (Free)',
      description: 'Access regulatory documents, compliance guidance, and stay updated with the latest export control regulations. This is completely free and a great way to get familiar with the platform.',
      action: () => navigate('/KnowledgeBase'),
      actionText: 'Explore Knowledge Base',
    },
    {
      id: 'risk-assessment',
      title: 'Risk Assessment Module',
      description: 'Our flagship compliance tool helps you evaluate export control risks systematically. Complete professional assessments with customizable templates.',
      actionText: 'Learn More',
    },
    {
      id: 'modules-overview',
      title: 'Complete Compliance Suite',
      description: 'RespectUs provides 7 essential modules covering all aspects of export control: Product Classification, Sanctions & Embargoes, Customer Screening, End-use Check, and License Determination.',
    },
    {
      id: 'dashboard',
      title: 'Your Control Center',
      description: 'This dashboard is your command center. Track your compliance activities, access modules, manage documents, and monitor your assessments all in one place.',
    },
    {
      id: 'get-started',
      title: 'Ready to Begin?',
      description: 'Start with the free Knowledge Base to explore compliance resources, then consider our Risk Assessment module when you\'re ready for comprehensive compliance evaluations.',
    },
  ];

  const currentTourStep = tourSteps[currentStep];

  const nextStep = () => {
    if (currentStep < tourSteps.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      handleComplete();
    }
  };

  const prevStep = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleStepAction = () => {
    if (currentTourStep.action) {
      currentTourStep.action();
      setCompletedSteps([...completedSteps, currentTourStep.id]);
    }
  };

  const handleComplete = () => {
    onComplete();
    onClose();
  };

  const skipTour = () => {
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <Card className="bg-gray-900 border-gray-700 max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <CardContent className="p-0">
          {/* Header */}
          <div className="p-6 border-b border-gray-700">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-purple-600 rounded-full flex items-center justify-center">
                  <Play className="w-4 h-4 text-white" />
                </div>
                <div>
                  <h2 className="text-xl font-bold text-white">Guided Tour</h2>
                  <p className="text-gray-400 text-sm">
                    Step {currentStep + 1} of {tourSteps.length}
                  </p>
                </div>
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={skipTour}
                className="text-gray-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </Button>
            </div>
          </div>

          {/* Progress Bar */}
          <div className="px-6 py-3 bg-gray-800/50">
            <div className="w-full bg-gray-700 rounded-full h-2">
              <div 
                className="bg-purple-600 h-2 rounded-full transition-all duration-300"
                style={{ width: `${((currentStep + 1) / tourSteps.length) * 100}%` }}
              />
            </div>
          </div>

          {/* Content */}
          <div className="p-6 space-y-6">
            <div className="text-center space-y-4">
              <h3 className="text-2xl font-bold text-white">
                {currentTourStep.title}
              </h3>
              <p className="text-gray-300 text-lg leading-relaxed">
                {currentTourStep.description}
              </p>
            </div>

            {/* Visual Element Based on Step */}
            {currentStep === 0 && (
              <div className="bg-gradient-to-r from-purple-600/20 to-blue-600/20 rounded-lg p-6 text-center">
                <div className="w-16 h-16 bg-purple-600 rounded-full mx-auto mb-4 flex items-center justify-center">
                  <CheckCircle className="w-8 h-8 text-white" />
                </div>
                <p className="text-purple-300 font-medium">Welcome aboard! Let's get you started.</p>
              </div>
            )}

            {currentStep === 1 && (
              <div className="bg-gradient-to-r from-blue-600/20 to-cyan-600/20 rounded-lg p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="text-white font-semibold">Knowledge Base</h4>
                    <p className="text-gray-300 text-sm">Regulatory documents & guidance</p>
                  </div>
                  <Badge className="bg-green-500/20 text-green-400 border-green-500/30">
                    FREE
                  </Badge>
                </div>
              </div>
            )}

            {currentStep === 2 && (
              <div className="bg-gradient-to-r from-purple-600/20 to-pink-600/20 rounded-lg p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="text-white font-semibold">Risk Assessment</h4>
                    <p className="text-gray-300 text-sm">Professional compliance evaluations</p>
                  </div>
                  <Badge className="bg-blue-500/20 text-blue-400 border-blue-500/30">
                    €99 + VAT if applicable
                  </Badge>
                </div>
              </div>
            )}

            {currentStep === 3 && (
              <div className="grid grid-cols-2 gap-3">
                {[
                  { name: 'Product Classification', color: 'green' },
                  { name: 'Sanctions & Embargoes', color: 'red' },
                  { name: 'Customer Screening', color: 'amber' },
                  { name: 'End-use Check', color: 'cyan' },
                ].map((module, idx) => (
                  <div key={idx} className={`bg-${module.color}-600/20 rounded-lg p-3 text-center`}>
                    <p className={`text-${module.color}-300 text-sm font-medium`}>{module.name}</p>
                    <Badge className="bg-gray-500/20 text-gray-400 border-gray-500/30 mt-1">
                      Coming Soon
                    </Badge>
                  </div>
                ))}
              </div>
            )}

            {/* Action Button */}
            {currentTourStep.action && currentTourStep.actionText && (
              <div className="text-center">
                <Button
                  onClick={handleStepAction}
                  className="bg-blue-600 hover:bg-blue-700 text-white"
                >
                  {currentTourStep.actionText}
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </div>
            )}
          </div>

          {/* Navigation */}
          <div className="p-6 border-t border-gray-700 flex items-center justify-between">
            <Button
              variant="outline"
              onClick={prevStep}
              disabled={currentStep === 0}
              className="border-gray-600 text-gray-300 hover:bg-gray-800"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Previous
            </Button>
            
            <div className="flex space-x-2">
              <Button
                variant="ghost"
                onClick={skipTour}
                className="text-gray-400 hover:text-white"
              >
                Skip Tour
              </Button>
              <Button
                onClick={nextStep}
                className="bg-purple-600 hover:bg-purple-700 text-white"
              >
                {currentStep === tourSteps.length - 1 ? 'Finish' : 'Next'}
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default GuidedTour;
