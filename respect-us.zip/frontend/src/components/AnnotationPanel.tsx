
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';
import { MessageSquare, Bookmark, Eye, EyeOff, Check, X, MoreVertical, Reply } from 'lucide-react';
import { useUserGuardContext } from 'app/auth';
import brain from 'brain';
import { DocumentAnnotation, CreateAnnotationRequest, UpdateAnnotationRequest } from 'types';
import { toast } from 'sonner';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { formatDistanceToNow } from 'date-fns';

interface Props {
  documentId: number;
  selectedText?: string;
  selectionData?: {
    start: number;
    end: number;
    text: string;
  };
  onAnnotationCreated?: () => void;
  onClose?: () => void;
}

const ANNOTATION_TYPES = [
  { value: 'highlight', label: 'Highlight', icon: '🟡' },
  { value: 'note', label: 'Note', icon: '📝' },
  { value: 'comment', label: 'Comment', icon: '💬' },
  { value: 'question', label: 'Question', icon: '❓' },
  { value: 'bookmark', label: 'Bookmark', icon: '🔖' }
];

const VISIBILITY_OPTIONS = [
  { value: 'private', label: 'Private', description: 'Only visible to you' },
  { value: 'team', label: 'Team', description: 'Visible to your team' },
  { value: 'public', label: 'Public', description: 'Visible to everyone' }
];

export function AnnotationPanel({ documentId, selectedText, selectionData, onAnnotationCreated, onClose }: Props) {
  const { user } = useUserGuardContext();
  const [annotations, setAnnotations] = useState<DocumentAnnotation[]>([]);
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState(false);
  const [newAnnotation, setNewAnnotation] = useState({
    type: 'highlight',
    content: '',
    visibility: 'private' as const
  });
  const [replyTo, setReplyTo] = useState<number | null>(null);
  const [replyContent, setReplyContent] = useState('');
  const [filter, setFilter] = useState({
    type: 'all',
    visibility: 'all'
  });

  useEffect(() => {
    loadAnnotations();
  }, [documentId, filter]);

  const loadAnnotations = async () => {
    try {
      setLoading(true);
      const response = await brain.get_document_annotations({
        document_id: documentId,
        annotation_type: filter.type === 'all' ? undefined : filter.type || undefined,
        visibility: filter.visibility === 'all' ? undefined : filter.visibility || undefined
      });
      
      if (response.ok) {
        const data = await response.json();
        setAnnotations(data);
      }
    } catch (error) {
      console.error('Error loading annotations:', error);
      toast.error('Failed to load annotations');
    } finally {
      setLoading(false);
    }
  };

  const createAnnotation = async () => {
    if (!newAnnotation.content.trim()) {
      toast.error('Please enter annotation content');
      return;
    }

    try {
      setCreating(true);
      const request: CreateAnnotationRequest = {
        document_id: documentId,
        annotation_type: newAnnotation.type,
        content: newAnnotation.content,
        visibility: newAnnotation.visibility,
        position_data: selectionData || {}
      };

      const response = await brain.create_annotation(request);
      
      if (response.ok) {
        toast.success('Annotation created successfully');
        setNewAnnotation({ type: 'highlight', content: '', visibility: 'private' });
        await loadAnnotations();
        onAnnotationCreated?.();
      } else {
        throw new Error('Failed to create annotation');
      }
    } catch (error) {
      console.error('Error creating annotation:', error);
      toast.error('Failed to create annotation');
    } finally {
      setCreating(false);
    }
  };

  const replyToAnnotation = async (parentId: number) => {
    if (!replyContent.trim()) {
      toast.error('Please enter reply content');
      return;
    }

    try {
      const request: CreateAnnotationRequest = {
        document_id: documentId,
        annotation_type: 'comment',
        content: replyContent,
        visibility: 'public',
        parent_id: parentId
      };

      const response = await brain.create_annotation(request);
      
      if (response.ok) {
        toast.success('Reply added successfully');
        setReplyContent('');
        setReplyTo(null);
        await loadAnnotations();
      }
    } catch (error) {
      console.error('Error replying to annotation:', error);
      toast.error('Failed to add reply');
    }
  };

  const resolveAnnotation = async (annotationId: number) => {
    try {
      const response = await brain.resolve_annotation({ annotation_id: annotationId });
      
      if (response.ok) {
        toast.success('Annotation resolved');
        await loadAnnotations();
      }
    } catch (error) {
      console.error('Error resolving annotation:', error);
      toast.error('Failed to resolve annotation');
    }
  };

  const deleteAnnotation = async (annotationId: number) => {
    try {
      const response = await brain.delete_annotation({ annotation_id: annotationId });
      
      if (response.ok) {
        toast.success('Annotation deleted');
        await loadAnnotations();
      }
    } catch (error) {
      console.error('Error deleting annotation:', error);
      toast.error('Failed to delete annotation');
    }
  };

  const getTypeIcon = (type: string) => {
    const typeConfig = ANNOTATION_TYPES.find(t => t.value === type);
    return typeConfig?.icon || '📄';
  };

  const getVisibilityIcon = (visibility: string) => {
    return visibility === 'private' ? <EyeOff className="h-3 w-3" /> : <Eye className="h-3 w-3" />;
  };

  return (
    <div className="w-full max-w-2xl space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold text-gray-100">Annotations & Comments</h3>
        {onClose && (
          <Button variant="ghost" size="sm" onClick={onClose}>
            <X className="h-4 w-4" />
          </Button>
        )}
      </div>

      {/* Create New Annotation */}
      <Card className="bg-gray-800/50 border-gray-700">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm text-gray-300">
            {selectedText ? `Annotate: "${selectedText.substring(0, 50)}..."` : 'Create New Annotation'}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <Select value={newAnnotation.type} onValueChange={(value) => setNewAnnotation(prev => ({ ...prev, type: value }))}>
              <SelectTrigger className="bg-gray-700 border-gray-600">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-gray-800 border-gray-600">
                {ANNOTATION_TYPES.map(type => (
                  <SelectItem key={type.value} value={type.value} className="text-gray-200">
                    {type.icon} {type.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={newAnnotation.visibility} onValueChange={(value: 'private' | 'team' | 'public') => setNewAnnotation(prev => ({ ...prev, visibility: value }))}>
              <SelectTrigger className="bg-gray-700 border-gray-600">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-gray-800 border-gray-600">
                {VISIBILITY_OPTIONS.map(option => (
                  <SelectItem key={option.value} value={option.value} className="text-gray-200">
                    {option.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <Textarea
            placeholder="Enter your annotation..."
            value={newAnnotation.content}
            onChange={(e) => setNewAnnotation(prev => ({ ...prev, content: e.target.value }))}
            className="bg-gray-700 border-gray-600 text-gray-100 placeholder-gray-400 min-h-[80px]"
          />

          <Button 
            onClick={createAnnotation} 
            disabled={creating || !newAnnotation.content.trim()}
            className="w-full bg-blue-600 hover:bg-blue-700"
          >
            {creating ? 'Creating...' : 'Create Annotation'}
          </Button>
        </CardContent>
      </Card>

      {/* Filter Controls */}
      <div className="flex gap-3">
        <Select value={filter.type} onValueChange={(value) => setFilter(prev => ({ ...prev, type: value }))}>
          <SelectTrigger className="bg-gray-700 border-gray-600 w-40">
            <SelectValue placeholder="Filter by type" />
          </SelectTrigger>
          <SelectContent className="bg-gray-800 border-gray-600">
            <SelectItem value="all" className="text-gray-200">All Types</SelectItem>
            {ANNOTATION_TYPES.map(type => (
              <SelectItem key={type.value} value={type.value} className="text-gray-200">
                {type.icon} {type.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Select value={filter.visibility} onValueChange={(value) => setFilter(prev => ({ ...prev, visibility: value }))}>
          <SelectTrigger className="bg-gray-700 border-gray-600 w-40">
            <SelectValue placeholder="Filter by visibility" />
          </SelectTrigger>
          <SelectContent className="bg-gray-800 border-gray-600">
            <SelectItem value="all" className="text-gray-200">All Visibility</SelectItem>
            {VISIBILITY_OPTIONS.map(option => (
              <SelectItem key={option.value} value={option.value} className="text-gray-200">
                {option.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Annotations List */}
      <div className="space-y-3">
        {loading ? (
          <div className="text-center py-8 text-gray-400">Loading annotations...</div>
        ) : annotations.length === 0 ? (
          <div className="text-center py-8 text-gray-400">
            No annotations found. Create the first one above!
          </div>
        ) : (
          annotations.map((annotation) => (
            <Card key={annotation.id} className="bg-gray-800/30 border-gray-700">
              <CardContent className="p-4">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <span className="text-lg">{getTypeIcon(annotation.annotation_type)}</span>
                    <span className="text-sm font-medium text-gray-200">{annotation.user_name}</span>
                    <Badge variant="outline" className="text-xs border-gray-600">
                      {annotation.annotation_type}
                    </Badge>
                    <div className="flex items-center gap-1 text-xs text-gray-400">
                      {getVisibilityIcon(annotation.visibility)}
                      <span>{annotation.visibility}</span>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-gray-400">
                      {annotation.created_at && formatDistanceToNow(new Date(annotation.created_at), { addSuffix: true })}
                    </span>
                    
                    {annotation.user_id === user.sub && (
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="sm" className="h-6 w-6 p-0">
                            <MoreVertical className="h-3 w-3" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent className="bg-gray-800 border-gray-600">
                          {!annotation.is_resolved && (
                            <DropdownMenuItem 
                              onClick={() => annotation.id && resolveAnnotation(annotation.id)}
                              className="text-green-400 hover:bg-gray-700"
                            >
                              <Check className="h-3 w-3 mr-2" />
                              Resolve
                            </DropdownMenuItem>
                          )}
                          <DropdownMenuItem 
                            onClick={() => annotation.id && deleteAnnotation(annotation.id)}
                            className="text-red-400 hover:bg-gray-700"
                          >
                            <X className="h-3 w-3 mr-2" />
                            Delete
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    )}
                  </div>
                </div>

                <div className="text-gray-100 mb-3">
                  {annotation.content}
                </div>

                {annotation.position_data?.text && (
                  <div className="bg-gray-700/50 p-2 rounded text-sm text-gray-300 mb-3">
                    <strong>Selected text:</strong> "{annotation.position_data.text}"
                  </div>
                )}

                {annotation.is_resolved && (
                  <Badge className="bg-green-600 text-white">
                    <Check className="h-3 w-3 mr-1" />
                    Resolved
                  </Badge>
                )}

                {/* Replies */}
                {annotation.replies && annotation.replies.length > 0 && (
                  <div className="mt-4 ml-4 space-y-2">
                    {annotation.replies.map((reply) => (
                      <div key={reply.id} className="bg-gray-700/30 p-3 rounded border-l-2 border-blue-500">
                        <div className="flex items-center gap-2 mb-2">
                          <span className="text-sm font-medium text-gray-200">{reply.user_name}</span>
                          <span className="text-xs text-gray-400">
                            {reply.created_at && formatDistanceToNow(new Date(reply.created_at), { addSuffix: true })}
                          </span>
                        </div>
                        <div className="text-gray-100 text-sm">{reply.content}</div>
                      </div>
                    ))}
                  </div>
                )}

                {/* Reply Form */}
                <div className="mt-3">
                  {replyTo === annotation.id ? (
                    <div className="space-y-2">
                      <Textarea
                        placeholder="Write a reply..."
                        value={replyContent}
                        onChange={(e) => setReplyContent(e.target.value)}
                        className="bg-gray-700 border-gray-600 text-gray-100 placeholder-gray-400 min-h-[60px]"
                      />
                      <div className="flex gap-2">
                        <Button 
                          size="sm" 
                          onClick={() => annotation.id && replyToAnnotation(annotation.id)}
                          className="bg-blue-600 hover:bg-blue-700"
                        >
                          Reply
                        </Button>
                        <Button 
                          size="sm" 
                          variant="outline" 
                          onClick={() => { setReplyTo(null); setReplyContent(''); }}
                          className="border-gray-600 text-gray-300 hover:bg-gray-700"
                        >
                          Cancel
                        </Button>
                      </div>
                    </div>
                  ) : (
                    <Button 
                      size="sm" 
                      variant="ghost" 
                      onClick={() => setReplyTo(annotation.id || null)}
                      className="text-gray-400 hover:text-gray-200 hover:bg-gray-700"
                    >
                      <Reply className="h-3 w-3 mr-1" />
                      Reply
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
}
