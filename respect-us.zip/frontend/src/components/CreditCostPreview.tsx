import React, { useState, useEffect } from 'react';
import { useUser } from '@stackframe/react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { 
  Coins, 
  AlertCircle, 
  CheckCircle, 
  Info,
  CreditCard,
  Zap
} from 'lucide-react';
import brain from 'brain';
import { toast } from 'sonner';

interface CreditCostPreviewProps {
  componentName: string;
  actionName: string;
  actionLabel?: string;
  actionDescription?: string;
  children: React.ReactElement;
  onConfirm?: () => void;
  showDialog?: boolean;
  disabled?: boolean;
  className?: string;
}

interface ActionPricing {
  is_priced: boolean;
  credit_cost: number;
  is_enabled: boolean;
}

interface CreditBalance {
  current_balance: number;
  lifetime_purchased: number;
  lifetime_consumed: number;
}

export default function CreditCostPreview({
  componentName,
  actionName,
  actionLabel = actionName,
  actionDescription,
  children,
  onConfirm,
  showDialog = true,
  disabled = false,
  className = ''
}: CreditCostPreviewProps) {
  const user = useUser();
  const [pricing, setPricing] = useState<ActionPricing | null>(null);
  const [balance, setBalance] = useState<CreditBalance | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [showConfirmDialog, setShowConfirmDialog] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Fetch pricing and balance info
  const fetchPricingInfo = async () => {
    if (!user) return;
    
    setIsLoading(true);
    setError(null);
    
    try {
      // Check action pricing
      const pricingResponse = await brain.check_action_pricing({
        component_name: componentName,
        action_name: actionName
      });
      const pricingData = await pricingResponse.json();
      setPricing(pricingData);
      
      // Get user balance if action is priced
      if (pricingData.is_priced && pricingData.is_enabled) {
        const balanceResponse = await brain.get_credit_balance();
        const balanceData = await balanceResponse.json();
        setBalance(balanceData);
      }
    } catch (err) {
      console.error('Failed to fetch pricing info:', err);
      setError('Failed to load pricing information');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (user) {
      fetchPricingInfo();
    }
  }, [user, componentName, actionName]);

  const handleClick = (e: React.MouseEvent) => {
    if (disabled) {
      e.preventDefault();
      return;
    }

    // If pricing is not loaded yet or action is free, proceed directly
    if (isLoading || !pricing || !pricing.is_priced || !pricing.is_enabled) {
      if (onConfirm) {
        onConfirm();
      }
      return;
    }

    // If action costs credits, show confirmation if enabled
    if (showDialog && pricing.credit_cost > 0) {
      e.preventDefault();
      setShowConfirmDialog(true);
    } else {
      if (onConfirm) {
        onConfirm();
      }
    }
  };

  const handleConfirm = () => {
    setShowConfirmDialog(false);
    if (onConfirm) {
      onConfirm();
    }
  };

  const canAfford = balance ? balance.current_balance >= (pricing?.credit_cost || 0) : true;
  const isLowBalance = balance ? balance.current_balance < 10 : false;
  const isCriticalBalance = balance ? balance.current_balance < 5 : false;

  // Enhanced child element with cost info
  const enhancedChild = React.cloneElement(children, {
    onClick: handleClick,
    disabled: disabled || (pricing?.is_priced && !canAfford),
    className: `${children.props.className || ''} ${className}`.trim()
  });

  const getCostBadge = () => {
    if (isLoading) {
      return (
        <Badge variant="outline" className="text-xs border-gray-500 text-gray-400">
          Loading...
        </Badge>
      );
    }

    if (!pricing || !pricing.is_enabled || !pricing.is_priced || pricing.credit_cost === 0) {
      return (
        <Badge variant="outline" className="text-xs border-green-500/30 bg-green-500/10 text-green-400">
          <CheckCircle className="w-3 h-3 mr-1" />
          Free
        </Badge>
      );
    }

    const costColor = canAfford 
      ? (isLowBalance ? 'text-yellow-400 border-yellow-500/30' : 'text-blue-400 border-blue-500/30')
      : 'text-red-400 border-red-500/30';

    return (
      <Badge variant="outline" className={`text-xs ${costColor}`}>
        <Coins className="w-3 h-3 mr-1" />
        {pricing.credit_cost} credits
      </Badge>
    );
  };

  // Tooltip content
  const tooltipContent = () => {
    if (isLoading) return "Loading pricing...";
    if (error) return `Error: ${error}`;
    if (!pricing || !pricing.is_enabled || !pricing.is_priced || pricing.credit_cost === 0) {
      return "This action is free";
    }
    if (!canAfford) {
      return `Insufficient credits. Need ${pricing.credit_cost}, have ${balance?.current_balance || 0}`;
    }
    return `This action costs ${pricing.credit_cost} credits. Balance: ${balance?.current_balance || 0}`;
  };

  const wrappedChild = (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <div className="relative inline-block">
            {enhancedChild}
            {/* Cost badge overlay */}
            <div className="absolute -top-2 -right-2 z-10">
              {getCostBadge()}
            </div>
          </div>
        </TooltipTrigger>
        <TooltipContent>
          <div className="space-y-1">
            <p>{tooltipContent()}</p>
            {actionDescription && (
              <p className="text-xs text-gray-400">{actionDescription}</p>
            )}
          </div>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );

  // Confirmation dialog
  const confirmationDialog = (
    <Dialog open={showConfirmDialog} onOpenChange={setShowConfirmDialog}>
      <DialogContent className="bg-gray-900 border-gray-700 text-white">
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-2">
            <Coins className="w-5 h-5 text-yellow-400" />
            <span>Confirm Action</span>
          </DialogTitle>
          <DialogDescription className="text-gray-300">
            {actionDescription || `You are about to perform: ${actionLabel}`}
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4">
          {/* Cost breakdown */}
          <div className="bg-gray-800/50 p-4 rounded-lg">
            <div className="flex items-center justify-between mb-3">
              <span className="text-sm font-medium">Action Cost</span>
              <div className="flex items-center space-x-2">
                <Coins className="w-4 h-4 text-yellow-400" />
                <span className="font-bold text-lg">{pricing?.credit_cost || 0}</span>
                <span className="text-sm text-gray-400">credits</span>
              </div>
            </div>
            
            <div className="flex items-center justify-between text-sm">
              <span className="text-gray-400">Current Balance</span>
              <span className={canAfford ? 'text-green-400' : 'text-red-400'}>
                {balance?.current_balance || 0} credits
              </span>
            </div>
            
            <div className="flex items-center justify-between text-sm border-t border-gray-700 pt-2 mt-2">
              <span className="text-gray-400">After Action</span>
              <span className={canAfford ? 'text-white' : 'text-red-400'}>
                {canAfford 
                  ? (balance?.current_balance || 0) - (pricing?.credit_cost || 0)
                  : 'Insufficient'
                } credits
              </span>
            </div>
          </div>

          {/* Warning for low balance */}
          {canAfford && isLowBalance && (
            <div className="flex items-start space-x-2 p-3 bg-yellow-500/10 border border-yellow-500/20 rounded-lg">
              <AlertCircle className="w-4 h-4 text-yellow-400 mt-0.5" />
              <div className="text-sm">
                <p className="text-yellow-400 font-medium">Low Balance Warning</p>
                <p className="text-gray-300">
                  {isCriticalBalance 
                    ? 'Critical balance! Consider purchasing more credits.'
                    : 'You have a low credit balance. Consider purchasing more credits soon.'
                  }
                </p>
              </div>
            </div>
          )}

          {/* Insufficient credits error */}
          {!canAfford && (
            <div className="flex items-start space-x-2 p-3 bg-red-500/10 border border-red-500/20 rounded-lg">
              <AlertCircle className="w-4 h-4 text-red-400 mt-0.5" />
              <div className="text-sm">
                <p className="text-red-400 font-medium">Insufficient Credits</p>
                <p className="text-gray-300">
                  You need {(pricing?.credit_cost || 0) - (balance?.current_balance || 0)} more credits to perform this action.
                </p>
              </div>
            </div>
          )}
        </div>

        <DialogFooter>
          <Button
            variant="outline"
            onClick={() => setShowConfirmDialog(false)}
            className="border-gray-600 text-gray-300 hover:bg-gray-800"
          >
            Cancel
          </Button>
          
          {!canAfford ? (
            <Button
              onClick={() => {
                setShowConfirmDialog(false);
                // Navigate to purchase credits
                window.location.href = '/user-dashboard?tab=credits';
              }}
              className="bg-blue-600 hover:bg-blue-700"
            >
              <CreditCard className="w-4 h-4 mr-2" />
              Purchase Credits
            </Button>
          ) : (
            <Button
              onClick={handleConfirm}
              className="bg-green-600 hover:bg-green-700"
            >
              <Zap className="w-4 h-4 mr-2" />
              Confirm ({pricing?.credit_cost || 0} credits)
            </Button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );

  return (
    <>
      {wrappedChild}
      {confirmationDialog}
    </>
  );
}
