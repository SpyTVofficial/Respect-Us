import React, { useState, useEffect, useMemo } from 'react';
import {
  ChevronDown,
  ChevronRight,
  FileText,
  BookOpen,
  List,
  Hash,
  ArrowRight,
  Search,
  Filter,
  Bookmark,
  ExternalLink,
  Key,
  Tag,
  MapPin,
  Book,
  FileSignature,
  SquareStack,
  Layers,
  Ruler,
  Users,
  Target,
  Lightbulb
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { toast } from 'sonner';
import brain from 'brain';

// Enhanced Section interface matching database structure
interface EnhancedSection {
  id: number;
  document_id: number;
  section_number: string | null;
  section_title: string | null;
  section_content: string | null;
  section_type: string | null;
  level: number | null;
  parent_section_id: number | null;
  display_order: number;
  cross_references: string[] | null;
  regulatory_references: string[] | null;
  definitions: string[] | null;
  keywords: string[] | null;
  created_at: string | null;
  children?: EnhancedSection[];
}

// Section type configurations
const SECTION_TYPE_CONFIG = {
  chapter: { icon: Book, color: 'text-purple-600', bg: 'bg-purple-50 dark:bg-purple-900/20', label: 'Chapter' },
  article: { icon: FileSignature, color: 'text-blue-600', bg: 'bg-blue-50 dark:bg-blue-900/20', label: 'Article' },
  section: { icon: SquareStack, color: 'text-green-600', bg: 'bg-green-50 dark:bg-green-900/20', label: 'Section' },
  subsection: { icon: Layers, color: 'text-amber-600', bg: 'bg-amber-50 dark:bg-amber-900/20', label: 'Subsection' },
  paragraph: { icon: Ruler, color: 'text-gray-600', bg: 'bg-gray-50 dark:bg-gray-900/20', label: 'Paragraph' },
  preamble: { icon: Users, color: 'text-indigo-600', bg: 'bg-indigo-50 dark:bg-indigo-900/20', label: 'Preamble' },
  definitions: { icon: Key, color: 'text-teal-600', bg: 'bg-teal-50 dark:bg-teal-900/20', label: 'Definitions' },
  annex: { icon: Target, color: 'text-red-600', bg: 'bg-red-50 dark:bg-red-900/20', label: 'Annex' },
  appendix: { icon: Lightbulb, color: 'text-orange-600', bg: 'bg-orange-50 dark:bg-orange-900/20', label: 'Appendix' },
  default: { icon: FileText, color: 'text-gray-600', bg: 'bg-gray-50 dark:bg-gray-900/20', label: 'Section' }
};

interface HierarchicalDocumentNavigationProps {
  documentId: number;
  documentTitle?: string;
  onSectionSelect?: (section: EnhancedSection) => void;
  selectedSectionId?: number;
  className?: string;
}

const HierarchicalDocumentNavigation: React.FC<HierarchicalDocumentNavigationProps> = ({
  documentId,
  documentTitle,
  onSectionSelect,
  selectedSectionId,
  className = ''
}) => {
  const [sections, setSections] = useState<EnhancedSection[]>([]);
  const [hierarchicalSections, setHierarchicalSections] = useState<EnhancedSection[]>([]);
  const [loading, setLoading] = useState(true);
  const [expandedSections, setExpandedSections] = useState<Set<number>>(new Set());
  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState<string>('all');
  const [activeTab, setActiveTab] = useState('tree');
  const [bookmarkedSections, setBookmarkedSections] = useState<Set<number>>(new Set());

  // Load document sections with enhanced data
  const loadSections = async () => {
    try {
      setLoading(true);
      const response = await brain.get_document_sections_admin(documentId);
      
      if (response.ok) {
        const data = await response.json();
        setSections(data.sections || []);
        
        // Auto-expand all top-level sections
        const topLevelIds = data.sections
          ?.filter((s: EnhancedSection) => !s.parent_section_id)
          .map((s: EnhancedSection) => s.id) || [];
        setExpandedSections(new Set(topLevelIds));
      } else {
        toast.error('Failed to load document sections');
      }
    } catch (error) {
      console.error('Error loading sections:', error);
      toast.error('Error loading document sections');
    } finally {
      setLoading(false);
    }
  };

  // Build hierarchical structure from flat sections
  const buildHierarchy = (flatSections: EnhancedSection[]): EnhancedSection[] => {
    const sectionMap = new Map<number, EnhancedSection>();
    const rootSections: EnhancedSection[] = [];

    // Create section map and initialize children arrays
    flatSections.forEach(section => {
      sectionMap.set(section.id, { ...section, children: [] });
    });

    // Build parent-child relationships
    flatSections.forEach(section => {
      const sectionWithChildren = sectionMap.get(section.id)!;
      
      if (section.parent_section_id) {
        const parent = sectionMap.get(section.parent_section_id);
        if (parent) {
          parent.children!.push(sectionWithChildren);
        } else {
          // Parent not found, treat as root
          rootSections.push(sectionWithChildren);
        }
      } else {
        rootSections.push(sectionWithChildren);
      }
    });

    // Sort sections by display_order at each level
    const sortSections = (sections: EnhancedSection[]) => {
      sections.sort((a, b) => a.display_order - b.display_order);
      sections.forEach(section => {
        if (section.children && section.children.length > 0) {
          sortSections(section.children);
        }
      });
    };

    sortSections(rootSections);
    return rootSections;
  };

  // Memoized hierarchical sections
  const filteredHierarchicalSections = useMemo(() => {
    const hierarchy = buildHierarchy(sections);
    
    // Apply search and filter
    const filterSections = (sections: EnhancedSection[]): EnhancedSection[] => {
      return sections.reduce((filtered: EnhancedSection[], section) => {
        let includeSection = true;
        
        // Filter by type
        if (filterType !== 'all' && section.section_type !== filterType) {
          includeSection = false;
        }
        
        // Filter by search query
        if (searchQuery && includeSection) {
          const searchLower = searchQuery.toLowerCase();
          const matchesTitle = section.section_title?.toLowerCase().includes(searchLower);
          const matchesContent = section.section_content?.toLowerCase().includes(searchLower);
          const matchesNumber = section.section_number?.toLowerCase().includes(searchLower);
          const matchesKeywords = section.keywords?.some(k => k.toLowerCase().includes(searchLower));
          
          includeSection = matchesTitle || matchesContent || matchesNumber || matchesKeywords;
        }
        
        // Recursively filter children
        const filteredChildren = section.children ? filterSections(section.children) : [];
        
        // Include section if it matches or has matching children
        if (includeSection || filteredChildren.length > 0) {
          filtered.push({
            ...section,
            children: filteredChildren
          });
        }
        
        return filtered;
      }, []);
    };
    
    return filterSections(hierarchy);
  }, [sections, searchQuery, filterType]);

  // Toggle section expansion
  const toggleExpansion = (sectionId: number) => {
    setExpandedSections(prev => {
      const newExpanded = new Set(prev);
      if (newExpanded.has(sectionId)) {
        newExpanded.delete(sectionId);
      } else {
        newExpanded.add(sectionId);
      }
      return newExpanded;
    });
  };

  // Toggle bookmark
  const toggleBookmark = (sectionId: number) => {
    setBookmarkedSections(prev => {
      const newBookmarks = new Set(prev);
      if (newBookmarks.has(sectionId)) {
        newBookmarks.delete(sectionId);
      } else {
        newBookmarks.add(sectionId);
      }
      return newBookmarks;
    });
  };

  // Handle section selection
  const handleSectionSelect = (section: EnhancedSection) => {
    onSectionSelect?.(section);
  };

  // Get section type configuration
  const getSectionConfig = (sectionType: string | null) => {
    return SECTION_TYPE_CONFIG[sectionType as keyof typeof SECTION_TYPE_CONFIG] || SECTION_TYPE_CONFIG.default;
  };

  // Render individual section in tree view
  const renderTreeSection = (section: EnhancedSection, depth = 0): React.ReactNode => {
    const config = getSectionConfig(section.section_type);
    const IconComponent = config.icon;
    const isExpanded = expandedSections.has(section.id);
    const isSelected = selectedSectionId === section.id;
    const isBookmarked = bookmarkedSections.has(section.id);
    const hasChildren = section.children && section.children.length > 0;
    const hasEnhancements = section.cross_references?.length || section.regulatory_references?.length || section.definitions?.length;
    
    return (
      <div key={section.id} className="select-none">
        <div
          className={`flex items-center gap-2 p-2 rounded-lg cursor-pointer transition-all duration-200 hover:bg-gray-100 dark:hover:bg-gray-800 ${
            isSelected ? 'bg-primary/10 border border-primary/20' : ''
          } ${depth > 0 ? `ml-${Math.min(depth * 4, 16)}` : ''}`}
          style={{ marginLeft: depth > 0 ? `${depth * 16}px` : '0' }}
          onClick={() => handleSectionSelect(section)}
        >
          {/* Expansion toggle */}
          <div className="flex-shrink-0 w-4">
            {hasChildren ? (
              <Button
                variant="ghost"
                size="sm"
                className="p-0 h-4 w-4 hover:bg-transparent"
                onClick={(e) => {
                  e.stopPropagation();
                  toggleExpansion(section.id);
                }}
              >
                {isExpanded ? (
                  <ChevronDown className="h-3 w-3" />
                ) : (
                  <ChevronRight className="h-3 w-3" />
                )}
              </Button>
            ) : (
              <div className="w-4" />
            )}
          </div>

          {/* Section icon */}
          <div className={`p-1 rounded ${config.bg}`}>
            <IconComponent className={`h-3 w-3 ${config.color}`} />
          </div>

          {/* Section number */}
          {section.section_number && (
            <Badge variant="outline" className="text-xs font-mono px-1">
              {section.section_number}
            </Badge>
          )}

          {/* Section title */}
          <span className={`text-sm font-medium flex-grow min-w-0 ${
            isSelected ? 'text-primary' : 'text-gray-900 dark:text-gray-100'
          }`}>
            {section.section_title || 'Untitled Section'}
          </span>

          {/* Enhancement indicators */}
          <div className="flex items-center gap-1">
            {section.cross_references && section.cross_references.length > 0 && (
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger>
                    <Badge variant="secondary" className="text-xs h-5 px-1">
                      <ExternalLink className="h-2 w-2 mr-1" />
                      {section.cross_references.length}
                    </Badge>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>{section.cross_references.length} cross-references</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            )}
            
            {section.definitions && section.definitions.length > 0 && (
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger>
                    <Badge variant="secondary" className="text-xs h-5 px-1">
                      <Key className="h-2 w-2 mr-1" />
                      {section.definitions.length}
                    </Badge>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>{section.definitions.length} definitions</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            )}
            
            {section.keywords && section.keywords.length > 0 && (
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger>
                    <Badge variant="secondary" className="text-xs h-5 px-1">
                      <Tag className="h-2 w-2 mr-1" />
                      {section.keywords.length}
                    </Badge>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>{section.keywords.length} keywords</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            )}

            {/* Bookmark toggle */}
            <Button
              variant="ghost"
              size="sm"
              className="p-0 h-4 w-4 hover:bg-transparent"
              onClick={(e) => {
                e.stopPropagation();
                toggleBookmark(section.id);
              }}
            >
              <Bookmark className={`h-3 w-3 ${
                isBookmarked ? 'fill-yellow-400 text-yellow-400' : 'text-gray-400'
              }`} />
            </Button>
          </div>
        </div>

        {/* Children sections */}
        {hasChildren && isExpanded && (
          <div className="mt-1">
            {section.children!.map(child => renderTreeSection(child, depth + 1))}
          </div>
        )}
      </div>
    );
  };

  // Render flat list view
  const renderListSection = (section: EnhancedSection): React.ReactNode => {
    const config = getSectionConfig(section.section_type);
    const IconComponent = config.icon;
    const isSelected = selectedSectionId === section.id;
    const isBookmarked = bookmarkedSections.has(section.id);
    
    return (
      <Card 
        key={section.id} 
        className={`cursor-pointer transition-all duration-200 hover:shadow-md ${
          isSelected ? 'border-primary shadow-md' : ''
        }`}
        onClick={() => handleSectionSelect(section)}
      >
        <CardContent className="p-4">
          <div className="flex items-start gap-3">
            {/* Section icon and type */}
            <div className={`p-2 rounded-lg ${config.bg}`}>
              <IconComponent className={`h-4 w-4 ${config.color}`} />
            </div>
            
            <div className="flex-grow min-w-0">
              {/* Header */}
              <div className="flex items-center gap-2 mb-2">
                {section.section_number && (
                  <Badge variant="outline" className="font-mono">
                    {section.section_number}
                  </Badge>
                )}
                <Badge variant="secondary">
                  {config.label}
                </Badge>
                {section.level && (
                  <Badge variant="outline" className="text-xs">
                    Level {section.level}
                  </Badge>
                )}
              </div>
              
              {/* Title */}
              <h4 className={`font-medium mb-2 ${
                isSelected ? 'text-primary' : 'text-gray-900 dark:text-gray-100'
              }`}>
                {section.section_title || 'Untitled Section'}
              </h4>
              
              {/* Content preview */}
              {section.section_content && (
                <p className="text-sm text-gray-600 dark:text-gray-400 line-clamp-2 mb-3">
                  {section.section_content.substring(0, 200)}...
                </p>
              )}
              
              {/* Enhancement details */}
              <div className="flex flex-wrap gap-2">
                {section.cross_references && section.cross_references.length > 0 && (
                  <Badge variant="outline" className="text-xs">
                    <ExternalLink className="h-3 w-3 mr-1" />
                    {section.cross_references.length} cross-refs
                  </Badge>
                )}
                
                {section.regulatory_references && section.regulatory_references.length > 0 && (
                  <Badge variant="outline" className="text-xs">
                    <MapPin className="h-3 w-3 mr-1" />
                    {section.regulatory_references.length} reg-refs
                  </Badge>
                )}
                
                {section.definitions && section.definitions.length > 0 && (
                  <Badge variant="outline" className="text-xs">
                    <Key className="h-3 w-3 mr-1" />
                    {section.definitions.length} definitions
                  </Badge>
                )}
                
                {section.keywords && section.keywords.length > 0 && (
                  <Badge variant="outline" className="text-xs">
                    <Tag className="h-3 w-3 mr-1" />
                    {section.keywords.length} keywords
                  </Badge>
                )}
              </div>
            </div>
            
            {/* Bookmark */}
            <Button
              variant="ghost"
              size="sm"
              className="p-1 h-6 w-6"
              onClick={(e) => {
                e.stopPropagation();
                toggleBookmark(section.id);
              }}
            >
              <Bookmark className={`h-3 w-3 ${
                isBookmarked ? 'fill-yellow-400 text-yellow-400' : 'text-gray-400'
              }`} />
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  };

  // Get unique section types for filter
  const uniqueSectionTypes = useMemo(() => {
    const types = new Set(sections.map(s => s.section_type).filter(Boolean));
    return Array.from(types);
  }, [sections]);

  // Load sections on mount
  useEffect(() => {
    if (documentId) {
      loadSections();
    }
  }, [documentId]);

  if (loading) {
    return (
      <Card className={className}>
        <CardContent className="p-6">
          <div className="flex items-center justify-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
            <span className="ml-2">Loading document structure...</span>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (sections.length === 0) {
    return (
      <Card className={className}>
        <CardContent className="p-6">
          <div className="text-center text-gray-500">
            <FileText className="h-12 w-12 mx-auto mb-4 text-gray-300" />
            <p>No sections found for this document.</p>
            <p className="text-sm mt-2">The document may not have been processed for section extraction yet.</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className={className}>
      <CardHeader className="pb-4">
        <CardTitle className="flex items-center gap-2">
          <BookOpen className="h-5 w-5" />
          Document Structure
          {documentTitle && (
            <span className="text-sm font-normal text-gray-500 ml-2 truncate">
              {documentTitle}
            </span>
          )}
        </CardTitle>
        
        {/* Search and Filter Controls */}
        <div className="flex flex-col gap-3 mt-4">
          <div className="flex gap-2">
            <div className="relative flex-grow">
              <Search className="absolute left-2 top-2.5 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Search sections..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-8"
              />
            </div>
            <Select value={filterType} onValueChange={setFilterType}>
              <SelectTrigger className="w-[180px]">
                <Filter className="h-4 w-4 mr-2" />
                <SelectValue placeholder="Filter by type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                {uniqueSectionTypes.map(type => {
                  const config = getSectionConfig(type);
                  return (
                    <SelectItem key={type} value={type}>
                      <div className="flex items-center gap-2">
                        <config.icon className="h-3 w-3" />
                        {config.label}
                      </div>
                    </SelectItem>
                  );
                })}
              </SelectContent>
            </Select>
          </div>
          
          {/* View mode tabs */}
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="tree" className="flex items-center gap-2">
                <List className="h-4 w-4" />
                Tree View
              </TabsTrigger>
              <TabsTrigger value="list" className="flex items-center gap-2">
                <SquareStack className="h-4 w-4" />
                List View
              </TabsTrigger>
            </TabsList>
          </Tabs>
        </div>
      </CardHeader>
      
      <CardContent>
        <div className="space-y-2">
          {/* Summary Stats */}
          <div className="flex flex-wrap gap-2 mb-4 p-3 bg-gray-50 dark:bg-gray-900 rounded-lg">
            <Badge variant="outline">
              {sections.length} total sections
            </Badge>
            <Badge variant="outline">
              {filteredHierarchicalSections.length} visible
            </Badge>
            {bookmarkedSections.size > 0 && (
              <Badge variant="outline" className="bg-yellow-50 text-yellow-700">
                <Bookmark className="h-3 w-3 mr-1" />
                {bookmarkedSections.size} bookmarked
              </Badge>
            )}
          </div>
          
          <Separator />
          
          {/* Content */}
          <ScrollArea className="h-[600px] w-full">
            <div className="space-y-2">
              {activeTab === 'tree' ? (
                // Tree View
                filteredHierarchicalSections.length > 0 ? (
                  filteredHierarchicalSections.map(section => renderTreeSection(section))
                ) : (
                  <div className="text-center text-gray-500 py-8">
                    <Search className="h-8 w-8 mx-auto mb-2 text-gray-300" />
                    <p>No sections match your search criteria.</p>
                  </div>
                )
              ) : (
                // List View
                filteredHierarchicalSections.length > 0 ? (
                  <div className="space-y-3">
                    {filteredHierarchicalSections.map(section => {
                      // Flatten hierarchy for list view
                      const flattenSections = (sections: EnhancedSection[]): EnhancedSection[] => {
                        let result: EnhancedSection[] = [];
                        sections.forEach(section => {
                          result.push(section);
                          if (section.children && section.children.length > 0) {
                            result = result.concat(flattenSections(section.children));
                          }
                        });
                        return result;
                      };
                      
                      return flattenSections([section]).map(flatSection => 
                        renderListSection(flatSection)
                      );
                    })}
                  </div>
                ) : (
                  <div className="text-center text-gray-500 py-8">
                    <Search className="h-8 w-8 mx-auto mb-2 text-gray-300" />
                    <p>No sections match your search criteria.</p>
                  </div>
                )
              )}
            </div>
          </ScrollArea>
        </div>
      </CardContent>
    </Card>
  );
};

export default HierarchicalDocumentNavigation;
