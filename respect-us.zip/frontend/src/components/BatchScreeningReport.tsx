import React from 'react';
import {
  Document,
  Page,
  Text,
  View,
  StyleSheet
} from '@react-pdf/renderer';
import { CustomerProfile, ScreeningResult } from 'brain/data-contracts';

// Define styles for the batch PDF report
const styles = StyleSheet.create({
  page: {
    flexDirection: 'column',
    backgroundColor: '#FFFFFF',
    padding: 40,
    fontFamily: 'Helvetica'
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 30,
    paddingBottom: 20,
    borderBottom: '2px solid #E5E7EB'
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#1F2937'
  },
  subtitle: {
    fontSize: 12,
    color: '#6B7280',
    marginTop: 4
  },
  section: {
    marginBottom: 20
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#374151',
    marginBottom: 10,
    paddingBottom: 5,
    borderBottom: '1px solid #E5E7EB'
  },
  summary: {
    backgroundColor: '#F9FAFB',
    padding: 15,
    borderRadius: 4,
    marginBottom: 20
  },
  summaryTitle: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#1F2937',
    marginBottom: 8
  },
  summaryGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap'
  },
  summaryItem: {
    width: '25%',
    marginBottom: 8
  },
  statLabel: {
    fontSize: 10,
    color: '#6B7280',
    fontWeight: 'bold'
  },
  statValue: {
    fontSize: 14,
    color: '#1F2937',
    fontWeight: 'bold',
    marginTop: 2
  },
  table: {
    display: 'flex',
    flexDirection: 'column',
    border: '1px solid #E5E7EB',
    borderRadius: 4
  },
  tableHeader: {
    flexDirection: 'row',
    backgroundColor: '#F9FAFB',
    borderBottom: '1px solid #E5E7EB',
    padding: 8
  },
  tableRow: {
    flexDirection: 'row',
    borderBottom: '1px solid #E5E7EB',
    padding: 8
  },
  tableCell: {
    fontSize: 9,
    color: '#374151',
    flex: 1,
    paddingRight: 8
  },
  tableCellHeader: {
    fontSize: 9,
    fontWeight: 'bold',
    color: '#1F2937',
    flex: 1,
    paddingRight: 8
  },
  riskBadge: {
    fontSize: 8,
    fontWeight: 'bold',
    textAlign: 'center'
  },
  riskCritical: {
    color: '#DC2626'
  },
  riskHigh: {
    color: '#D97706'
  },
  riskMedium: {
    color: '#CA8A04'
  },
  riskLow: {
    color: '#059669'
  },
  riskNone: {
    color: '#6B7280'
  },
  footer: {
    position: 'absolute',
    bottom: 30,
    left: 40,
    right: 40,
    fontSize: 8,
    color: '#6B7280',
    borderTop: '1px solid #E5E7EB',
    paddingTop: 10,
    textAlign: 'center'
  }
});

interface BatchScreeningData {
  customer: CustomerProfile;
  screening: ScreeningResult;
}

interface Props {
  batchNumber: string;
  screeningData: BatchScreeningData[];
  generatedBy: string;
  reportId: string;
}

export const BatchScreeningReport: React.FC<Props> = ({
  batchNumber,
  screeningData,
  generatedBy,
  reportId
}) => {
  const getRiskStyle = (riskLevel: string) => {
    switch (riskLevel?.toLowerCase()) {
      case 'critical': return [styles.riskBadge, styles.riskCritical];
      case 'high': return [styles.riskBadge, styles.riskHigh];
      case 'medium': return [styles.riskBadge, styles.riskMedium];
      case 'low': return [styles.riskBadge, styles.riskLow];
      default: return [styles.riskBadge, styles.riskNone];
    }
  };

  const formatDate = (date: string | Date | undefined) => {
    if (!date) return 'N/A';
    return new Date(date).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  // Calculate summary statistics
  const totalCustomers = screeningData.length;
  const highRiskCustomers = screeningData.filter(data => 
    data.screening.risk_level === 'critical' || data.screening.risk_level === 'high'
  ).length;
  const customersWithMatches = screeningData.filter(data => 
    data.screening.total_matches > 0
  ).length;
  const averageRiskScore = totalCustomers > 0 
    ? (screeningData.reduce((acc, data) => acc + data.screening.overall_risk_score, 0) / totalCustomers * 100).toFixed(1)
    : '0';

  return (
    <Document>
      <Page size="A4" style={styles.page}>
        {/* Header */}
        <View style={styles.header}>
          <View>
            <Text style={styles.title}>Batch Screening Report</Text>
            <Text style={styles.subtitle}>Respectus Compliance Platform</Text>
          </View>
          <View>
            <Text style={[styles.subtitle, { textAlign: 'right' }]}>Batch: {batchNumber}</Text>
            <Text style={[styles.subtitle, { textAlign: 'right' }]}>Report ID: {reportId}</Text>
            <Text style={[styles.subtitle, { textAlign: 'right' }]}>Generated: {formatDate(new Date())}</Text>
          </View>
        </View>

        {/* Batch Summary */}
        <View style={styles.summary}>
          <Text style={styles.summaryTitle}>Batch Summary</Text>
          <View style={styles.summaryGrid}>
            <View style={styles.summaryItem}>
              <Text style={styles.statLabel}>Total Customers</Text>
              <Text style={styles.statValue}>{totalCustomers}</Text>
            </View>
            <View style={styles.summaryItem}>
              <Text style={styles.statLabel}>High Risk</Text>
              <Text style={[styles.statValue, styles.riskHigh]}>{highRiskCustomers}</Text>
            </View>
            <View style={styles.summaryItem}>
              <Text style={styles.statLabel}>With Matches</Text>
              <Text style={styles.statValue}>{customersWithMatches}</Text>
            </View>
            <View style={styles.summaryItem}>
              <Text style={styles.statLabel}>Avg Risk Score</Text>
              <Text style={styles.statValue}>{averageRiskScore}%</Text>
            </View>
          </View>
        </View>

        {/* Screening Results Table */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Screening Results</Text>
          <View style={styles.table}>
            <View style={styles.tableHeader}>
              <Text style={styles.tableCellHeader}>Customer Name</Text>
              <Text style={styles.tableCellHeader}>Type</Text>
              <Text style={styles.tableCellHeader}>Country</Text>
              <Text style={styles.tableCellHeader}>Risk Level</Text>
              <Text style={styles.tableCellHeader}>Matches</Text>
              <Text style={styles.tableCellHeader}>Risk Score</Text>
              <Text style={styles.tableCellHeader}>Status</Text>
            </View>
            {screeningData.map((data, index) => (
              <View key={index} style={styles.tableRow}>
                <Text style={styles.tableCell}>{data.customer.customer_name}</Text>
                <Text style={styles.tableCell}>{data.customer.customer_type}</Text>
                <Text style={styles.tableCell}>{data.customer.country || 'N/A'}</Text>
                <Text style={getRiskStyle(data.screening.risk_level)}>
                  {data.screening.risk_level?.toUpperCase()}
                </Text>
                <Text style={styles.tableCell}>
                  {data.screening.total_matches} ({data.screening.high_risk_matches} high)
                </Text>
                <Text style={styles.tableCell}>
                  {(data.screening.overall_risk_score * 100).toFixed(1)}%
                </Text>
                <Text style={styles.tableCell}>
                  {data.screening.high_risk_matches > 0 ? 'REVIEW REQUIRED' : 
                   data.screening.total_matches > 0 ? 'VERIFY MATCHES' : 'CLEARED'}
                </Text>
              </View>
            ))}
          </View>
        </View>

        {/* Footer */}
        <Text style={styles.footer}>
          Batch screening report generated by Respectus Compliance Platform on {formatDate(new Date())}.
          This document contains confidential information and should be handled according to your organization's data security policies.
          Generated by: {generatedBy}
        </Text>
      </Page>
    </Document>
  );
};

export default BatchScreeningReport;
