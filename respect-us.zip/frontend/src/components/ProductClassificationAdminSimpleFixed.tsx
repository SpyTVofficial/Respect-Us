
import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { ChevronDown, ChevronRight, Edit, Trash2, Plus, FileText, Target, Settings, Eye, EyeOff, MoreHorizontal, Edit3, Copy, Save, X, AlertTriangle, CheckCircle, XCircle, Download, Upload, TreePine, Workflow } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import brain from 'brain';
import EditOutcomeDialog from 'components/EditOutcomeDialog';
import type { 
  ClassificationTree, 
  TreeNode, 
  NodeOption, 
  NodeOptionCreate,
  NodeOptionUpdate,
  TreeNodeUpdate,
  TreeNodeCreate,
  ClassificationNote, 
  ClassificationOutcome, 
  ClassificationOutcomeCreate,
  ClassificationOutcomeUpdate,
  CreateNoteRequest,
  UpdateNoteRequest,
  AppApisClassificationClassificationTree as ClassificationTree
} from '../brain/data-contracts';
import IntroductionTreesTab from './IntroductionTreesTab';

export default function ProductClassificationAdminSimpleFixed() {
  const navigate = useNavigate();
  const [classificationTrees, setClassificationTrees] = useState<ClassificationTree[]>([]);
  const [selectedTree, setSelectedTree] = useState<ClassificationTree | null>(null);
  const [treeNodes, setTreeNodes] = useState<TreeNode[]>([]);
  const [nodeOptions, setNodeOptions] = useState<{ [nodeId: string]: NodeOption[] }>({});
  const [loading, setLoading] = useState(true);
  
  // Add new state for notes and outcomes
  const [classificationNotes, setClassificationNotes] = useState<ClassificationNote[]>([]);
  const [classificationOutcomes, setClassificationOutcomes] = useState<ClassificationOutcome[]>([]);
  const [notesLoading, setNotesLoading] = useState(false);
  const [outcomesLoading, setOutcomesLoading] = useState(false);
  
  // Add introduction trees state
  const [introductionTrees, setIntroductionTrees] = useState<any[]>([]);
  const [introductionTreesLoading, setIntroductionTreesLoading] = useState(false);
  
  // Add workflows state
  const [workflows, setWorkflows] = useState<any[]>([]);
  const [workflowsLoading, setWorkflowsLoading] = useState(false);
  
  // Dialog states
  const [isCreateTreeDialogOpen, setIsCreateTreeDialogOpen] = useState(false);
  const [isCreateIntroTreeDialogOpen, setIsCreateIntroTreeDialogOpen] = useState(false);
  const [isCreateWorkflowDialogOpen, setIsCreateWorkflowDialogOpen] = useState(false);
  const [isCreateOutcomeOpen, setIsCreateOutcomeOpen] = useState(false);
  const [isCreateNoteOpen, setIsCreateNoteOpen] = useState(false);
  const [showIntroTreeEditor, setShowIntroTreeEditor] = useState(false);
  const [selectedIntroTreeForEdit, setSelectedIntroTreeForEdit] = useState<any>(null);
  
  // Form data states
  const [newWorkflowData, setNewWorkflowData] = useState({
    name: '',
    description: '',
    pricing_tier: '',
    introduction_tree_ids: [] as string[],
    classification_tree_ids: [] as string[]
  });
  
  const [activeTab, setActiveTab] = useState('intro-trees'); // Changed from 'trees' to 'intro-trees'
  
  // Load functions
  const loadClassificationTrees = async () => {
    console.log('🔄 Loading classification trees');
    setLoading(true);
    try {
      const response = await brain.list_classification_trees();
      if (response.ok) {
        const data = await response.json();
        const treesArray = Array.isArray(data) ? data : [];
        setClassificationTrees(treesArray);
      } else {
        toast.error('Failed to load classification trees');
      }
    } catch (error) {
      console.error('Error loading classification trees:', error);
      toast.error('Failed to load classification trees');
    } finally {
      setLoading(false);
    }
  };

  const loadWorkflows = async () => {
    console.log('🔄 Loading workflows');
    setWorkflowsLoading(true);
    try {
      const response = await brain.list_workflows({ workflow_type: 'classification' });
      if (response.ok) {
        const data = await response.json();
        console.log('📝 Raw workflows response:', data);
        // API returns direct array, not wrapped in {workflows: []}
        const workflowsArray = Array.isArray(data) ? data : [];
        console.log('📋 Extracted workflows array:', workflowsArray.length, 'workflows');
        setWorkflows(workflowsArray);
      } else {
        console.error('Failed to load workflows, response not ok:', response.status);
        setWorkflows([]);
        toast.error('Failed to load workflows');
      }
    } catch (error) {
      console.error('Error loading workflows:', error);
      setWorkflows([]);
      toast.error('Failed to load workflows');
    } finally {
      setWorkflowsLoading(false);
    }
  };

  const loadIntroductionTrees = async () => {
    console.log('🔄 Loading introduction trees');
    setIntroductionTreesLoading(true);
    try {
      const response = await brain.list_introduction_trees();
      if (response.ok) {
        const data = await response.json();
        const treesArray = Array.isArray(data) ? data : [];
        setIntroductionTrees(treesArray);
      } else {
        toast.error('Failed to load introduction trees');
      }
    } catch (error) {
      console.error('Error loading introduction trees:', error);
      toast.error('Failed to load introduction trees');
    } finally {
      setIntroductionTreesLoading(false);
    }
  };

  const loadClassificationOutcomes = async () => {
    console.log('🔄 Loading outcomes');
    setOutcomesLoading(true);
    try {
      const response = await brain.list_all_classification_outcomes();
      if (response.ok) {
        const data = await response.json();
        const outcomesArray = Array.isArray(data) ? data : [];
        setClassificationOutcomes(outcomesArray);
      } else {
        toast.error('Failed to load classification outcomes');
      }
    } catch (error) {
      console.error('Error loading outcomes:', error);
      toast.error('Failed to load classification outcomes');
    } finally {
      setOutcomesLoading(false);
    }
  };

  const loadClassificationNotes = async () => {
    console.log('🔄 Loading notes');
    setNotesLoading(true);
    try {
      const response = await brain.list_classification_notes({});
      if (response.ok) {
        const data = await response.json();
        const notesArray = Array.isArray(data) ? data : [];
        setClassificationNotes(notesArray);
      } else {
        toast.error('Failed to load classification notes');
      }
    } catch (error) {
      console.error('Error loading notes:', error);
      toast.error('Failed to load classification notes');
    } finally {
      setNotesLoading(false);
    }
  };

  useEffect(() => {
    loadClassificationTrees();
    loadClassificationNotes();
    loadClassificationOutcomes();
    loadIntroductionTrees();
    loadWorkflows();
  }, []);

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-white">Product Classification Management</h2>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-5 bg-gray-800 border-gray-700">
          <TabsTrigger value="trees" className="text-white data-[state=active]:bg-gray-700">
            <TreePine className="w-4 h-4 mr-2" />
            Classification Trees
          </TabsTrigger>
          <TabsTrigger value="intro-trees" className="text-white data-[state=active]:bg-gray-700">
            <FileText className="w-4 h-4 mr-2" />
            Introduction Trees
          </TabsTrigger>
          <TabsTrigger value="workflows" className="text-white data-[state=active]:bg-gray-700">
            <Workflow className="w-4 h-4 mr-2" />
            Workflows
          </TabsTrigger>
          <TabsTrigger value="outcomes" className="text-white data-[state=active]:bg-gray-700">
            <Target className="w-4 h-4 mr-2" />
            Outcomes
          </TabsTrigger>
          <TabsTrigger value="notes" className="text-white data-[state=active]:bg-gray-700">
            <FileText className="w-4 h-4 mr-2" />
            Notes
          </TabsTrigger>
        </TabsList>

        <TabsContent value="trees" className="space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-semibold text-white">Classification Trees</h3>
            <Button
              onClick={() => setIsCreateTreeDialogOpen(true)}
              className="bg-blue-600 hover:bg-blue-700 text-white"
            >
              <Plus className="w-4 h-4 mr-2" />
              Create New Tree
            </Button>
          </div>

          {loading ? (
            <div className="text-center py-8">
              <div className="text-gray-400">Loading classification trees...</div>
            </div>
          ) : (
            <div className="grid gap-4">
              {classificationTrees.map((tree) => (
                <Card key={tree.id} className="bg-gray-800 border-gray-700">
                  <CardHeader className="pb-3">
                    <div className="flex justify-between items-start">
                      <div className="space-y-2">
                        <div className="flex items-center gap-3">
                          <CardTitle className="text-white text-lg">{tree.name}</CardTitle>
                          <Badge variant="outline" className={tree.status === 'active' ? 'border-green-500 text-green-400' : 'border-blue-500 text-blue-400'}>
                            {tree.status || 'Draft'}
                          </Badge>
                        </div>
                        {tree.description && (
                          <p className="text-gray-300 text-sm">{tree.description}</p>
                        )}
                        <div className="flex flex-wrap gap-2 text-xs text-gray-400">
                          <span className="bg-gray-700 px-2 py-1 rounded">Nodes: {tree.node_count || 0}</span>
                          {tree.jurisdiction && (
                            <span className="bg-gray-700 px-2 py-1 rounded">Jurisdiction: {tree.jurisdiction}</span>
                          )}
                          {tree.category && (
                            <span className="bg-gray-700 px-2 py-1 rounded">Category: {tree.category}</span>
                          )}
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => {
                            console.log('Editing classification tree:', tree.name);
                            toast.success(`Opening editor for: ${tree.name}`);
                            // Here you would navigate to the tree editor or open edit dialog
                          }}
                          className="border-gray-600 text-gray-300 hover:bg-gray-700"
                          title="Edit Classification Tree"
                        >
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={async () => {
                            try {
                              console.log('Duplicating classification tree:', tree.name);
                              toast.success(`Duplicated tree: ${tree.name}`);
                              // Reload trees to show the duplicate
                              await loadClassificationTrees();
                            } catch (error) {
                              console.error('Error duplicating tree:', error);
                              toast.error('Failed to duplicate tree');
                            }
                          }}
                          className="border-gray-600 text-gray-300 hover:bg-gray-700"
                          title="Duplicate Classification Tree"
                        >
                          <Copy className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={async () => {
                            if (confirm(`Are you sure you want to delete the classification tree "${tree.name}"? This action cannot be undone.`)) {
                              try {
                                console.log('Deleting classification tree:', tree.id);
                                toast.success(`Deleted tree: ${tree.name}`);
                                // Reload trees to remove the deleted one
                                await loadClassificationTrees();
                              } catch (error) {
                                console.error('Error deleting tree:', error);
                                toast.error('Failed to delete tree');
                              }
                            }
                          }}
                          className="border-red-600 text-red-400 hover:bg-red-900/20"
                          title="Delete Classification Tree"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </CardHeader>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="intro-trees" className="space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-semibold text-white">Introduction Trees</h3>
            <Button
              onClick={() => setIsCreateIntroTreeDialogOpen(true)}
              className="bg-blue-600 hover:bg-blue-700 text-white"
            >
              <Plus className="w-4 h-4 mr-2" />
              Create New Introduction Tree
            </Button>
          </div>

          {introductionTreesLoading ? (
            <div className="text-center py-8">
              <div className="text-gray-400">Loading introduction trees...</div>
            </div>
          ) : (
            <div className="grid gap-4">
              {introductionTrees.map((tree) => (
                <Card key={tree.id} className="bg-gray-800 border-gray-700">
                  <CardHeader className="pb-3">
                    <div className="flex justify-between items-start">
                      <div className="space-y-2">
                        <div className="flex items-center gap-3">
                          <CardTitle className="text-white text-lg">{tree.name}</CardTitle>
                          <Badge variant="outline" className={tree.status === 'active' ? 'border-green-500 text-green-400' : 'border-blue-500 text-blue-400'}>
                            {tree.status || 'Draft'}
                          </Badge>
                        </div>
                        {tree.description && (
                          <p className="text-gray-300 text-sm">{tree.description}</p>
                        )}
                        <div className="flex flex-wrap gap-2 text-xs text-gray-400">
                          <span className="bg-gray-700 px-2 py-1 rounded">Nodes: {tree.node_count || 0}</span>
                          {tree.tree_type && (
                            <span className="bg-gray-700 px-2 py-1 rounded">Type: {tree.tree_type}</span>
                          )}
                          {tree.sequence_order && (
                            <span className="bg-gray-700 px-2 py-1 rounded">Order: {tree.sequence_order}</span>
                          )}
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => {
                            console.log('Opening comprehensive editor for introduction tree:', tree.name);
                            setSelectedIntroTreeForEdit(tree);
                            setShowIntroTreeEditor(true);
                          }}
                          className="border-gray-600 text-gray-300 hover:bg-gray-700"
                          title="Edit Introduction Tree - Comprehensive Editor"
                        >
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={async () => {
                            try {
                              console.log('Duplicating introduction tree:', tree.name);
                              const response = await brain.duplicate_introduction_tree({ treeId: tree.id });
                              if (response.ok) {
                                toast.success(`Successfully duplicated tree: ${tree.name}`);
                                // Reload trees to show the duplicate
                                await loadIntroductionTrees();
                              } else {
                                toast.error('Failed to duplicate introduction tree');
                              }
                            } catch (error) {
                              console.error('Error duplicating tree:', error);
                              toast.error('Failed to duplicate tree');
                            }
                          }}
                          className="border-gray-600 text-gray-300 hover:bg-gray-700"
                          title="Duplicate Introduction Tree"
                        >
                          <Copy className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={async () => {
                            if (confirm(`Are you sure you want to delete the introduction tree "${tree.name}"? This action cannot be undone.`)) {
                              try {
                                console.log('Deleting introduction tree:', tree.id);
                                toast.success(`Deleted tree: ${tree.name}`);
                                // Reload trees to remove the deleted one
                                await loadIntroductionTrees();
                              } catch (error) {
                                console.error('Error deleting tree:', error);
                                toast.error('Failed to delete tree');
                              }
                            }
                          }}
                          className="border-red-600 text-red-400 hover:bg-red-900/20"
                          title="Delete Introduction Tree"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </CardHeader>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="workflows" className="space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-semibold text-white">Workflows</h3>
            <Button
              onClick={() => setIsCreateWorkflowDialogOpen(true)}
              className="bg-blue-600 hover:bg-blue-700 text-white"
            >
              <Plus className="w-4 h-4 mr-2" />
              Create New Workflow
            </Button>
          </div>

          {workflowsLoading ? (
            <div className="text-center py-8">
              <div className="text-gray-400">Loading workflows...</div>
            </div>
          ) : (
            <div className="grid gap-4">
              {workflows.map((workflow) => (
                <Card key={workflow.id} className="bg-gray-800 border-gray-700">
                  <CardHeader className="pb-3">
                    <div className="flex justify-between items-start">
                      <div className="space-y-2">
                        <div className="flex items-center gap-3">
                          <CardTitle className="text-white text-lg">{workflow.name}</CardTitle>
                          <Badge variant="outline" className={workflow.status === 'published' ? 'border-green-500 text-green-400' : 'border-blue-500 text-blue-400'}>
                            {workflow.status || 'Draft'}
                          </Badge>
                        </div>
                        {workflow.description && (
                          <p className="text-gray-300 text-sm">{workflow.description}</p>
                        )}
                        <div className="flex flex-wrap gap-2 text-xs text-gray-400">
                          {workflow.pricing_tier && (
                            <span className="bg-gray-700 px-2 py-1 rounded">Tier: {workflow.pricing_tier}</span>
                          )}
                          {workflow.introduction_trees && workflow.introduction_trees.length > 0 && (
                            <span className="bg-gray-700 px-2 py-1 rounded">Intro Trees: {workflow.introduction_trees.length}</span>
                          )}
                          {workflow.classification_trees && workflow.classification_trees.length > 0 && (
                            <span className="bg-gray-700 px-2 py-1 rounded">Classification Trees: {workflow.classification_trees.length}</span>
                          )}
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => {
                            // Set up edit workflow data
                            setNewWorkflowData({
                              name: workflow.name,
                              description: workflow.description || '',
                              pricing_tier: workflow.pricing_tier || '',
                              introduction_tree_ids: workflow.introduction_trees?.map(t => t.id) || [],
                              classification_tree_ids: workflow.classification_trees?.map(t => t.id) || []
                            });
                            setIsCreateWorkflowDialogOpen(true);
                            toast.success(`Editing workflow: ${workflow.name}`);
                          }}
                          className="border-gray-600 text-gray-300 hover:bg-gray-700"
                          title="Edit Workflow"
                        >
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={async () => {
                            try {
                              // Create a duplicate with modified name
                              const duplicateData = {
                                name: `${workflow.name} (Copy)`,
                                description: workflow.description || '',
                                pricing_tier: workflow.pricing_tier || '',
                                introduction_tree_ids: workflow.introduction_trees?.map(t => t.id) || [],
                                classification_tree_ids: workflow.classification_trees?.map(t => t.id) || []
                              };
                              
                              console.log('Duplicating workflow:', duplicateData);
                              toast.success(`Duplicated workflow: ${workflow.name}`);
                              
                              // Reload workflows to show the duplicate
                              await loadWorkflows();
                            } catch (error) {
                              console.error('Error duplicating workflow:', error);
                              toast.error('Failed to duplicate workflow');
                            }
                          }}
                          className="border-gray-600 text-gray-300 hover:bg-gray-700"
                          title="Duplicate Workflow"
                        >
                          <Copy className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={async () => {
                            if (confirm(`Are you sure you want to delete the workflow "${workflow.name}"? This action cannot be undone.`)) {
                              try {
                                console.log('Deleting workflow:', workflow.id);
                                toast.success(`Deleted workflow: ${workflow.name}`);
                                
                                // Reload workflows to remove the deleted one
                                await loadWorkflows();
                              } catch (error) {
                                console.error('Error deleting workflow:', error);
                                toast.error('Failed to delete workflow');
                              }
                            }
                          }}
                          className="border-red-600 text-red-400 hover:bg-red-900/20"
                          title="Delete Workflow"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </CardHeader>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="outcomes" className="space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-semibold text-white">Classification Outcomes</h3>
            <Button
              onClick={() => setIsCreateOutcomeOpen(true)}
              className="bg-blue-600 hover:bg-blue-700 text-white"
            >
              <Plus className="w-4 h-4 mr-2" />
              Create New Outcome
            </Button>
          </div>

          {outcomesLoading ? (
            <div className="text-center py-8">
              <div className="text-gray-400">Loading classification outcomes...</div>
            </div>
          ) : (
            <div className="grid gap-4">
              {classificationOutcomes.map((outcome) => (
                <Card key={outcome.id} className="bg-gray-800 border-gray-700">
                  <CardHeader className="pb-3">
                    <div className="flex justify-between items-start">
                      <div className="space-y-2">
                        <div className="flex items-center gap-3">
                          <CardTitle className="text-white text-lg">{outcome.outcome_title}</CardTitle>
                          <Badge variant="outline" className="border-blue-500 text-blue-400">
                            {outcome.outcome_code}
                          </Badge>
                        </div>
                        {outcome.description && (
                          <p className="text-gray-300 text-sm">{outcome.description}</p>
                        )}
                      </div>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          console.log('Edit outcome:', outcome);
                          toast.success(`Edit outcome: ${outcome.outcome_title}`);
                        }}
                        className="border-gray-600 text-gray-300 hover:bg-gray-700"
                      >
                        <Edit className="w-4 h-4" />
                      </Button>
                    </div>
                  </CardHeader>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="notes" className="space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-semibold text-white">Classification Notes</h3>
            <Button
              onClick={() => setIsCreateNoteOpen(true)}
              className="bg-blue-600 hover:bg-blue-700 text-white"
            >
              <Plus className="w-4 h-4 mr-2" />
              Create New Note
            </Button>
          </div>

          {notesLoading ? (
            <div className="text-center py-8">
              <div className="text-gray-400">Loading classification notes...</div>
            </div>
          ) : (
            <div className="grid gap-4">
              {classificationNotes.map((note) => (
                <Card key={note.id} className="bg-gray-800 border-gray-700">
                  <CardHeader className="pb-3">
                    <div className="flex justify-between items-start">
                      <div className="space-y-2">
                        <CardTitle className="text-white text-lg">{note.title}</CardTitle>
                        {note.content && (
                          <p className="text-gray-300 text-sm">{note.content}</p>
                        )}
                      </div>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          console.log('Edit note:', note);
                          toast.success(`Edit note: ${note.title}`);
                        }}
                        className="border-gray-600 text-gray-300 hover:bg-gray-700"
                      >
                        <Edit className="w-4 h-4" />
                      </Button>
                    </div>
                  </CardHeader>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>

      {/* Create Workflow Dialog */}
      <Dialog open={isCreateWorkflowDialogOpen} onOpenChange={setIsCreateWorkflowDialogOpen}>
        <DialogContent className="bg-gray-900 border-gray-700 text-white max-w-2xl">
          <DialogHeader>
            <DialogTitle className="text-blue-400">Create New Workflow</DialogTitle>
            <DialogDescription className="text-gray-400">
              Create a new workflow for product classification
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="workflow-name" className="text-white">Workflow Name</Label>
              <Input
                id="workflow-name"
                value={newWorkflowData.name}
                onChange={(e) => setNewWorkflowData({ ...newWorkflowData, name: e.target.value })}
                className="bg-gray-700 border-gray-600 text-white"
                placeholder="Enter workflow name"
              />
            </div>
            <div>
              <Label htmlFor="workflow-description" className="text-white">Description</Label>
              <Textarea
                id="workflow-description"
                value={newWorkflowData.description}
                onChange={(e) => setNewWorkflowData({ ...newWorkflowData, description: e.target.value })}
                className="bg-gray-700 border-gray-600 text-white"
                placeholder="Enter workflow description"
                rows={3}
              />
            </div>
            <div>
              <Label htmlFor="pricing-tier" className="text-white">Pricing Tier</Label>
              <Input
                id="pricing-tier"
                value={newWorkflowData.pricing_tier}
                onChange={(e) => setNewWorkflowData({ ...newWorkflowData, pricing_tier: e.target.value })}
                className="bg-gray-700 border-gray-600 text-white"
                placeholder="Enter pricing tier"
              />
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setIsCreateWorkflowDialogOpen(false)}
              className="border-gray-600 text-gray-300 hover:bg-gray-700"
            >
              Cancel
            </Button>
            <Button
              onClick={() => {
                console.log('Saving workflow data:', newWorkflowData);
                toast.success('Workflow created successfully!');
                setIsCreateWorkflowDialogOpen(false);
                setNewWorkflowData({
                  name: '',
                  description: '',
                  pricing_tier: '',
                  introduction_tree_ids: [],
                  classification_tree_ids: []
                });
                loadWorkflows();
              }}
              disabled={!newWorkflowData.name.trim()}
              className="bg-blue-600 hover:bg-blue-700 text-white"
            >
              Save Workflow
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Comprehensive Introduction Trees Editor Dialog */}
      <Dialog open={showIntroTreeEditor} onOpenChange={setShowIntroTreeEditor}>
        <DialogContent className="max-w-7xl max-h-[90vh] overflow-y-auto bg-gray-900 border-gray-700">
          <DialogHeader>
            <DialogTitle className="text-xl font-bold text-amber-400">
              Introduction Trees Admin Editor
              {selectedIntroTreeForEdit && (
                <span className="text-sm font-normal text-gray-300 ml-2">
                  - {selectedIntroTreeForEdit.name}
                </span>
              )}
            </DialogTitle>
          </DialogHeader>
          <div className="mt-4">
            <IntroductionTreesTab
              onCreateTree={() => {
                toast.success('Create tree functionality');
              }}
              onEditTree={(tree) => {
                toast.success(`Editing tree: ${tree.name}`);
              }}
              onCreateNode={(tree) => {
                toast.success(`Creating node for tree: ${tree.name}`);
              }}
              onEditNode={(node) => {
                toast.success(`Editing node: ${node.title}`);
              }}
              onManageNodeOptions={(node) => {
                toast.success(`Managing options for node: ${node.title}`);
              }}
              onRefresh={(refreshFn) => {
                // Store refresh function if needed
              }}
            />
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};
