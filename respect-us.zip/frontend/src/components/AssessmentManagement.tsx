

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { 
  FileText, 
  Calendar, 
  Building, 
  User, 
  Trash2, 
  Eye, 
  Search, 
  Filter,
  Download,
  RefreshCw,
  TrendingUp,
  CheckCircle,
  Clock,
  AlertTriangle,
  Edit
} from 'lucide-react';
import { toast } from 'sonner';
import brain from 'brain';
import { UserAssessmentsResponse, UserAssessmentListItem } from '../brain/data-contracts';

interface AssessmentManagementProps {
  onRefresh?: () => void;
}

const AssessmentManagement: React.FC<AssessmentManagementProps> = ({ onRefresh }) => {
  const [assessments, setAssessments] = useState<UserAssessmentListItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [selectedAssessment, setSelectedAssessment] = useState<UserAssessmentListItem | null>(null);
  const [showViewDialog, setShowViewDialog] = useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [assessmentToDelete, setAssessmentToDelete] = useState<string | null>(null);
  const [totalCount, setTotalCount] = useState(0);

  useEffect(() => {
    loadAssessments();
  }, []);

  const loadAssessments = async () => {
    try {
      setLoading(true);
      const response = await brain.list_user_assessments();
      
      if (response.ok) {
        const data: UserAssessmentsResponse = await response.json();
        setAssessments(data.assessments || []);
        setTotalCount(data.total_count || 0);
      } else {
        const errorText = await response.text();
        console.error('Failed to load assessments:', errorText);
        toast.error('Failed to load assessments');
        setAssessments([]);
        setTotalCount(0);
      }
    } catch (error) {
      console.error('Error loading assessments:', error);
      toast.error('Error loading assessments');
      setAssessments([]);
      setTotalCount(0);
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteAssessment = async (assessmentId: string) => {
    try {
      const response = await brain.delete_assessment({ assessmentId });
      
      if (response.ok) {
        toast.success('Assessment deleted successfully');
        await loadAssessments();
        setShowDeleteDialog(false);
        setAssessmentToDelete(null);
        onRefresh?.();
      } else {
        const errorText = await response.text();
        console.error('Delete failed:', errorText);
        toast.error('Failed to delete assessment');
      }
    } catch (error) {
      console.error('Error deleting assessment:', error);
      toast.error('Error deleting assessment');
    }
  };

  const handleEditAssessment = async (assessment: UserAssessmentListItem) => {
    try {
      // Navigate to RiskAssessment page with assessment ID to load
      const editUrl = `/RiskAssessment?loadAssessmentId=${assessment.assessment_id}`;
      window.location.href = editUrl;
    } catch (error) {
      console.error('Error navigating to edit assessment:', error);
      toast.error('Error opening assessment for editing');
    }
  };

  const handleViewAssessment = (assessment: UserAssessmentListItem) => {
    setSelectedAssessment(assessment);
    setShowViewDialog(true);
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'completed':
        return <Badge className="bg-green-600 text-white"><CheckCircle className="w-3 h-3 mr-1" />Completed</Badge>;
      case 'in_progress':
        return <Badge className="bg-blue-600 text-white"><Clock className="w-3 h-3 mr-1" />In Progress</Badge>;
      case 'draft':
        return <Badge className="bg-yellow-600 text-white"><AlertTriangle className="w-3 h-3 mr-1" />Draft</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  const filteredAssessments = assessments.filter(assessment => {
    const matchesSearch = assessment.assessment_title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         assessment.company_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         assessment.template_title.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === 'all' || assessment.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const getStatusCounts = () => {
    const counts = {
      total: assessments.length,
      completed: assessments.filter(a => a.status === 'completed').length,
      in_progress: assessments.filter(a => a.status === 'in_progress').length,
      draft: assessments.filter(a => a.status === 'draft').length
    };
    return counts;
  };

  const statusCounts = getStatusCounts();

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="text-center">
          <RefreshCw className="w-8 h-8 animate-spin text-blue-400 mx-auto mb-4" />
          <p className="text-gray-400">Loading assessments...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-white">Assessment Management</h2>
          <p className="text-gray-400">Manage and review user risk assessments</p>
        </div>
        <div className="flex items-center space-x-3">
          <Button
            variant="outline"
            size="sm"
            onClick={loadAssessments}
            className="border-gray-600 text-gray-300 hover:bg-gray-700"
          >
            <RefreshCw className="w-4 h-4 mr-2" />
            Refresh
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-gradient-to-br from-blue-600/20 to-blue-800/20 border-blue-600/30">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-blue-200 text-sm">Total Assessments</p>
                <p className="text-2xl font-bold text-white">{statusCounts.total}</p>
              </div>
              <FileText className="h-8 w-8 text-blue-400" />
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-gradient-to-br from-green-600/20 to-green-800/20 border-green-600/30">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-green-200 text-sm">Completed</p>
                <p className="text-2xl font-bold text-white">{statusCounts.completed}</p>
              </div>
              <CheckCircle className="h-8 w-8 text-green-400" />
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-gradient-to-br from-blue-600/20 to-blue-800/20 border-blue-600/30">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-blue-200 text-sm">In Progress</p>
                <p className="text-2xl font-bold text-white">{statusCounts.in_progress}</p>
              </div>
              <Clock className="h-8 w-8 text-blue-400" />
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-gradient-to-br from-yellow-600/20 to-yellow-800/20 border-yellow-600/30">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-yellow-200 text-sm">Drafts</p>
                <p className="text-2xl font-bold text-white">{statusCounts.draft}</p>
              </div>
              <AlertTriangle className="h-8 w-8 text-yellow-400" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card className="bg-gray-800/30 border-gray-700">
        <CardContent className="p-4">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  placeholder="Search assessments..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-9 bg-gray-700/50 border-gray-600 text-white"
                />
              </div>
            </div>
            <div className="flex gap-3">
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-40 bg-gray-700/50 border-gray-600 text-white">
                  <Filter className="w-4 h-4 mr-2" />
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent className="bg-gray-800 border-gray-600">
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                  <SelectItem value="in_progress">In Progress</SelectItem>
                  <SelectItem value="draft">Draft</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Assessments Table */}
      <Card className="bg-gray-800/30 border-gray-700">
        <CardHeader>
          <CardTitle className="text-white">User Assessments</CardTitle>
          <CardDescription className="text-gray-400">
            {filteredAssessments.length} of {assessments.length} assessments
          </CardDescription>
        </CardHeader>
        <CardContent>
          {filteredAssessments.length === 0 ? (
            <div className="text-center py-8">
              <FileText className="w-12 h-12 text-gray-500 mx-auto mb-4" />
              <p className="text-gray-400">No assessments found</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="border-gray-700">
                    <TableHead className="text-gray-300">Assessment</TableHead>
                    <TableHead className="text-gray-300">Company</TableHead>
                    <TableHead className="text-gray-300">Template</TableHead>
                    <TableHead className="text-gray-300">Status</TableHead>
                    <TableHead className="text-gray-300">Progress</TableHead>
                    <TableHead className="text-gray-300">Created</TableHead>
                    <TableHead className="text-gray-300">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredAssessments.map((assessment) => (
                    <TableRow key={assessment.assessment_id} className="border-gray-700 hover:bg-gray-700/30">
                      <TableCell className="font-medium text-white">
                        {assessment.assessment_title}
                      </TableCell>
                      <TableCell className="text-gray-300">
                        <div className="flex items-center">
                          <Building className="w-4 h-4 mr-2 text-gray-400" />
                          {assessment.company_name}
                        </div>
                      </TableCell>
                      <TableCell className="text-gray-300">
                        {assessment.template_title}
                      </TableCell>
                      <TableCell>
                        {getStatusBadge(assessment.status)}
                      </TableCell>
                      <TableCell className="text-gray-300">
                        <div className="flex items-center space-x-2">
                          <div className="w-full bg-gray-700 rounded-full h-2">
                            <div 
                              className="bg-blue-600 h-2 rounded-full" 
                              style={{ width: `${assessment.completion_percentage}%` }}
                            />
                          </div>
                          <span className="text-sm">{Math.round(assessment.completion_percentage)}%</span>
                        </div>
                      </TableCell>
                      <TableCell className="text-gray-300">
                        <div className="flex items-center">
                          <Calendar className="w-4 h-4 mr-2 text-gray-400" />
                          {new Date(assessment.created_at).toLocaleDateString()}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center space-x-2">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleViewAssessment(assessment)}
                            className="text-blue-400 hover:text-blue-300 hover:bg-blue-600/20"
                          >
                            <Eye className="w-4 h-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleEditAssessment(assessment)}
                            className="text-green-400 hover:text-green-300 hover:bg-green-600/20"
                          >
                            <Edit className="w-4 h-4" />
                          </Button>
                          <AlertDialog>
                            <AlertDialogTrigger asChild>
                              <Button
                                variant="ghost"
                                size="sm"
                                className="text-red-400 hover:text-red-300 hover:bg-red-600/20"
                              >
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </AlertDialogTrigger>
                            <AlertDialogContent className="bg-gray-800 border-gray-700">
                              <AlertDialogHeader>
                                <AlertDialogTitle className="text-white">Delete Assessment</AlertDialogTitle>
                                <AlertDialogDescription className="text-gray-400">
                                  Are you sure you want to delete the assessment "{assessment.assessment_title}"? This action cannot be undone.
                                </AlertDialogDescription>
                              </AlertDialogHeader>
                              <AlertDialogFooter>
                                <AlertDialogCancel className="bg-gray-700 text-white border-gray-600 hover:bg-gray-600">
                                  Cancel
                                </AlertDialogCancel>
                                <AlertDialogAction
                                  onClick={() => handleDeleteAssessment(assessment.assessment_id)}
                                  className="bg-red-600 hover:bg-red-700 text-white"
                                >
                                  Delete
                                </AlertDialogAction>
                              </AlertDialogFooter>
                            </AlertDialogContent>
                          </AlertDialog>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* View Assessment Dialog */}
      <Dialog open={showViewDialog} onOpenChange={setShowViewDialog}>
        <DialogContent className="bg-gray-800 border-gray-700 max-w-2xl">
          <DialogHeader>
            <DialogTitle className="text-white">Assessment Details</DialogTitle>
            <DialogDescription className="text-gray-400">
              {selectedAssessment?.assessment_title}
            </DialogDescription>
          </DialogHeader>
          {selectedAssessment && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium text-gray-200">Company</label>
                  <p className="text-gray-300">{selectedAssessment.company_name}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-200">Template</label>
                  <p className="text-gray-300">{selectedAssessment.template_title}</p>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium text-gray-200">Status</label>
                  <div className="mt-1">{getStatusBadge(selectedAssessment.status)}</div>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-200">Completion</label>
                  <p className="text-gray-300">{Math.round(selectedAssessment.completion_percentage)}%</p>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium text-gray-200">Created</label>
                  <p className="text-gray-300">{new Date(selectedAssessment.created_at).toLocaleString()}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-200">Last Updated</label>
                  <p className="text-gray-300">{new Date(selectedAssessment.updated_at).toLocaleString()}</p>
                </div>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button
              onClick={() => setShowViewDialog(false)}
              className="bg-gray-600 hover:bg-gray-700 text-white"
            >
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default AssessmentManagement;
