
import React, { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Database, FileText, Wrench } from 'lucide-react';
import DocumentMetadataManagement from 'components/DocumentMetadataManagement';
import ContentManagement from 'components/ContentManagement';
import DocumentReferenceText from 'components/DocumentReferenceText';

interface Props {
  loading?: boolean;
}

export function SystemSettingsTab({ loading = false }: Props) {
  const [activeSubTab, setActiveSubTab] = useState('metadata');

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="bg-gray-800/30 backdrop-blur-sm border border-gray-700 rounded-lg p-6">
          <div className="animate-pulse">
            <div className="h-6 bg-gray-600 rounded w-1/4 mb-4"></div>
            <div className="h-4 bg-gray-600 rounded w-1/2 mb-6"></div>
            <div className="space-y-4">
              {[1, 2, 3].map((i) => (
                <div key={i} className="h-16 bg-gray-600 rounded"></div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-gray-800/30 backdrop-blur-sm border border-gray-700 rounded-lg">
      <div className="p-6 border-b border-gray-700">
        <h2 className="text-xl font-semibold text-white mb-2">System Settings</h2>
        <p className="text-gray-400">Configure system metadata and content management</p>
      </div>

      <Tabs value={activeSubTab} onValueChange={setActiveSubTab} className="p-6">
        <TabsList className="grid w-full grid-cols-2 bg-gray-800/50 backdrop-blur-sm">
          <TabsTrigger 
            value="metadata" 
            className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-500 data-[state=active]:to-blue-500 data-[state=active]:text-white"
          >
            <Database className="h-4 w-4 mr-2" />
            Metadata
          </TabsTrigger>
          <TabsTrigger 
            value="cms" 
            className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-500 data-[state=active]:to-blue-500 data-[state=active]:text-white"
          >
            <FileText className="h-4 w-4 mr-2" />
            CMS
          </TabsTrigger>
        </TabsList>

        {/* Metadata Tab */}
        <TabsContent value="metadata" className="space-y-6 mt-6">
          {/* Document Cross-Reference Demo */}
          <div className="bg-gray-900/30 backdrop-blur-sm border border-gray-600 rounded-lg p-6">
            <div className="mb-6">
              <h3 className="text-lg font-semibold text-white mb-2 flex items-center">
                <Wrench className="h-5 w-5 mr-2" />
                Document Cross-Reference Demo
              </h3>
              <p className="text-gray-400">Testing automatic document reference detection and linking</p>
            </div>
            <div className="space-y-4">
              <div className="bg-gray-900/50 border border-gray-600 rounded-lg p-4">
                <h4 className="text-md font-medium text-white mb-2">Example Text with Document References:</h4>
                <div className="text-gray-300 leading-relaxed">
                  <DocumentReferenceText>
                    This compliance analysis references H.R. 1316, the "Maintaining American Superiority by Improving Export Control Transparency Act" which was signed into law. The regulation requires comprehensive reporting on dual-use export licenses, particularly for entities in D:5 countries listed in the Entity List or Military End-User List (MEU). For additional context, see the Export Control Reform Act of 2018 and related CFR regulations.
                  </DocumentReferenceText>
                </div>
              </div>
              <div className="bg-gray-900/50 border border-gray-600 rounded-lg p-4">
                <h4 className="text-md font-medium text-white mb-2">How it works:</h4>
                <ul className="text-gray-400 text-sm space-y-1">
                  <li>• Automatically detects document references like "H.R. 1316" in text</li>
                  <li>• Searches knowledge base for matching documents</li>
                  <li>• Converts matches to clickable links</li>
                  <li>• Shows document titles and metadata on hover</li>
                </ul>
              </div>
            </div>
          </div>

          {/* Metadata Management */}
          <div className="bg-gray-900/30 backdrop-blur-sm border border-gray-600 rounded-lg p-6">
            <div className="mb-6">
              <h3 className="text-lg font-semibold text-white mb-2 flex items-center">
                <Database className="h-5 w-5 mr-2" />
                Document Metadata Management
              </h3>
              <p className="text-gray-400">Configure document metadata fields, categories, and taxonomies</p>
            </div>
            <DocumentMetadataManagement onRefresh={() => console.log('Metadata refreshed')} />
          </div>
        </TabsContent>

        {/* CMS Tab */}
        <TabsContent value="cms" className="space-y-6 mt-6">
          <div className="bg-gray-900/30 backdrop-blur-sm border border-gray-600 rounded-lg p-6">
            <div className="mb-6">
              <h3 className="text-lg font-semibold text-white mb-2 flex items-center">
                <FileText className="h-5 w-5 mr-2" />
                Content Management System
              </h3>
              <p className="text-gray-400">Manage system content, tooltips, help text, and module configurations</p>
            </div>
            <ContentManagement onRefresh={() => console.log('Content refreshed')} />
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}

export default SystemSettingsTab;
