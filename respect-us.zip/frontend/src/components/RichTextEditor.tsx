import React from 'react';
import { useEditor, EditorContent } from '@tiptap/react';
import StarterKit from '@tiptap/starter-kit';
import { Extension } from '@tiptap/core';
import Paragraph from '@tiptap/extension-paragraph';
import Heading from '@tiptap/extension-heading';
import Image from '@tiptap/extension-image';
import Link from '@tiptap/extension-link';
import Underline from '@tiptap/extension-underline';
import TextAlign from '@tiptap/extension-text-align';
import Highlight from '@tiptap/extension-highlight';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Bold,
  Italic,
  Underline as UnderlineIcon,
  AlignLeft,
  AlignCenter,
  AlignRight,
  Link as LinkIcon,
  Image as ImageIcon,
  List,
  ListOrdered,
  Quote,
  Palette,
  Type,
} from 'lucide-react';
import { toast } from 'sonner';

interface Props {
  content: string;
  onChange: (content: string) => void;
  placeholder?: string;
  className?: string;
}

const RichTextEditor: React.FC<Props> = ({ content, onChange, placeholder = "Start writing...", className = "" }) => {
  const [isLinkDialogOpen, setIsLinkDialogOpen] = React.useState(false);
  const [isImageDialogOpen, setIsImageDialogOpen] = React.useState(false);
  const [linkUrl, setLinkUrl] = React.useState('');
  const [linkText, setLinkText] = React.useState('');
  const [imageUrl, setImageUrl] = React.useState('');
  const [imageAlt, setImageAlt] = React.useState('');

  const editor = useEditor({
    extensions: [
      StarterKit.configure({
        // Disable default paragraph and heading to customize them
        paragraph: false,
        heading: false,
      }),
      // Add custom paragraph that allows empty paragraphs
      Paragraph.configure({
        HTMLAttributes: {
          class: 'my-paragraph',
        },
      }),
      // Add explicit heading extension with levels 1-6
      Heading.configure({
        levels: [1, 2, 3, 4, 5, 6],
      }),
      Image,
      Link.configure({
        openOnClick: false,
      }),
      Underline,
      TextAlign.configure({
        types: ['heading', 'paragraph'],
      }),
      Highlight,
    ],
    content: content || '<p></p>',
    onUpdate: ({ editor }) => {
      onChange(editor.getHTML());
    },
    editorProps: {
      attributes: {
        class: 'prose prose-invert max-w-none min-h-[200px] p-4 focus:outline-none bg-slate-900/50 text-slate-100',
      },
      handleKeyDown: (view, event) => {
        // Allow Enter to create new paragraphs even if current is empty
        if (event.key === 'Enter' && !event.shiftKey) {
          const { state, dispatch } = view;
          const { from, to } = state.selection;
          const tr = state.tr.split(from);
          dispatch(tr);
          return true;
        }
        return false;
      },
    },
    editable: true,
  });

  // Update editor content when content prop changes
  React.useEffect(() => {
    if (editor && content !== editor.getHTML()) {
      console.log('🔄 RichTextEditor: Updating content from prop:', content?.substring(0, 100) + '...');
      editor.commands.setContent(content || '<p></p>');
    }
  }, [editor, content]);

  const insertLink = () => {
    if (!editor || !linkUrl) return;
    
    if (linkUrl === '') {
      editor.chain().focus().extendMarkRange('link').unsetLink().run();
    } else {
      editor.chain().focus().extendMarkRange('link').setLink({ href: linkUrl }).run();
    }
    
    setIsLinkDialogOpen(false);
    setLinkUrl('');
  };

  const insertImageFromUrl = () => {
    if (!editor || !imageUrl) return;
    
    editor.chain().focus().setImage({ src: imageUrl }).run();
    setIsImageDialogOpen(false);
    setImageUrl('');
  };

  const handleAddImage = () => {
    toast.error('Image upload is not available. Please use the "Image URL" option instead.');
  };

  if (!editor) {
    return null;
  }

  return (
    <div className={`border border-slate-600 rounded-lg bg-slate-900/50 ${className}`}>
      {/* Toolbar */}
      <div className="border-b border-slate-600 p-2 flex flex-wrap gap-1 bg-slate-800/50">
        <Button
          type="button"
          variant="ghost"
          size="sm"
          onClick={() => editor.chain().focus().toggleBold().run()}
          className={`h-8 px-2 ${editor.isActive('bold') ? 'bg-slate-600' : 'hover:bg-slate-700'} text-slate-200`}
        >
          <Bold className="h-4 w-4" />
        </Button>
        <Button
          type="button"
          variant="ghost"
          size="sm"
          onClick={() => editor.chain().focus().toggleItalic().run()}
          className={`h-8 px-2 ${editor.isActive('italic') ? 'bg-slate-600' : 'hover:bg-slate-700'} text-slate-200`}
        >
          <Italic className="h-4 w-4" />
        </Button>
        <Button
          type="button"
          variant="ghost"
          size="sm"
          onClick={() => editor.chain().focus().toggleUnderline().run()}
          className={`h-8 px-2 ${editor.isActive('underline') ? 'bg-slate-600' : 'hover:bg-slate-700'} text-slate-200`}
        >
          <UnderlineIcon className="h-4 w-4" />
        </Button>
        <div className="w-px h-6 bg-slate-600 mx-1" />
        <Button
          type="button"
          variant="ghost"
          size="sm"
          onClick={() => editor.chain().focus().toggleHeading({ level: 1 }).run()}
          className={`h-8 px-2 ${editor.isActive('heading', { level: 1 }) ? 'bg-slate-600' : 'hover:bg-slate-700'} text-slate-200`}
        >
          <Type className="h-4 w-4" />
          <span className="ml-1 text-xs">H1</span>
        </Button>
        <Button
          type="button"
          variant="ghost"
          size="sm"
          onClick={() => editor.chain().focus().toggleHeading({ level: 2 }).run()}
          className={`h-8 px-2 ${editor.isActive('heading', { level: 2 }) ? 'bg-slate-600' : 'hover:bg-slate-700'} text-slate-200`}
        >
          <Type className="h-4 w-4" />
          <span className="ml-1 text-xs">H2</span>
        </Button>
        <Button
          type="button"
          variant="ghost"
          size="sm"
          onClick={() => editor.chain().focus().toggleHeading({ level: 3 }).run()}
          className={`h-8 px-2 ${editor.isActive('heading', { level: 3 }) ? 'bg-slate-600' : 'hover:bg-slate-700'} text-slate-200`}
        >
          <Type className="h-4 w-4" />
          <span className="ml-1 text-xs">H3</span>
        </Button>
        <div className="w-px h-6 bg-slate-600 mx-1" />
        <Button
          type="button"
          variant="ghost"
          size="sm"
          onClick={() => editor.chain().focus().setTextAlign('left').run()}
          className={`h-8 px-2 ${editor.isActive({ textAlign: 'left' }) ? 'bg-slate-600' : 'hover:bg-slate-700'} text-slate-200`}
        >
          <AlignLeft className="h-4 w-4" />
        </Button>
        <Button
          type="button"
          variant="ghost"
          size="sm"
          onClick={() => editor.chain().focus().setTextAlign('center').run()}
          className={`h-8 px-2 ${editor.isActive({ textAlign: 'center' }) ? 'bg-slate-600' : 'hover:bg-slate-700'} text-slate-200`}
        >
          <AlignCenter className="h-4 w-4" />
        </Button>
        <Button
          type="button"
          variant="ghost"
          size="sm"
          onClick={() => editor.chain().focus().setTextAlign('right').run()}
          className={`h-8 px-2 ${editor.isActive({ textAlign: 'right' }) ? 'bg-slate-600' : 'hover:bg-slate-700'} text-slate-200`}
        >
          <AlignRight className="h-4 w-4" />
        </Button>
        <div className="w-px h-6 bg-slate-600 mx-1" />
        <Button
          type="button"
          variant="ghost"
          size="sm"
          onClick={() => editor.chain().focus().toggleHighlight().run()}
          className={`h-8 px-2 ${editor.isActive('highlight') ? 'bg-slate-600' : 'hover:bg-slate-700'} text-slate-200`}
        >
          <Palette className="h-4 w-4" />
        </Button>
        <Dialog open={isLinkDialogOpen} onOpenChange={setIsLinkDialogOpen}>
          <DialogTrigger asChild>
            <Button
              type="button"
              variant="ghost"
              size="sm"
              className="h-8 px-2 hover:bg-slate-700 text-slate-200"
            >
              <LinkIcon className="h-4 w-4" />
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-slate-900 border-slate-700">
            <DialogHeader>
              <DialogTitle className="text-slate-100">Add External Link</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="linkText" className="text-slate-100">Link Text</Label>
                <Input
                  id="linkText"
                  value={linkText}
                  onChange={(e) => setLinkText(e.target.value)}
                  placeholder="Enter link text"
                  className="bg-slate-800 border-slate-600 text-slate-100 placeholder-slate-400"
                />
              </div>
              <div>
                <Label htmlFor="linkUrl" className="text-slate-100">URL</Label>
                <Input
                  id="linkUrl"
                  value={linkUrl}
                  onChange={(e) => setLinkUrl(e.target.value)}
                  placeholder="https://example.com"
                  className="bg-slate-800 border-slate-600 text-slate-100 placeholder-slate-400"
                />
              </div>
              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setIsLinkDialogOpen(false)} className="border-slate-600 text-slate-200">Cancel</Button>
                <Button onClick={insertLink} className="bg-blue-600 hover:bg-blue-700">Insert Link</Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
        <Dialog open={isImageDialogOpen} onOpenChange={setIsImageDialogOpen}>
          <DialogTrigger asChild>
            <Button
              type="button"
              variant="ghost"
              size="sm"
              onClick={handleAddImage}
              className="h-8 px-2 hover:bg-slate-700 text-slate-200"
            >
              <ImageIcon className="h-4 w-4" />
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-slate-900 border-slate-700">
            <DialogHeader>
              <DialogTitle className="text-slate-100">Add Image</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="imageUrl" className="text-slate-100">Image URL</Label>
                <Input
                  id="imageUrl"
                  value={imageUrl}
                  onChange={(e) => setImageUrl(e.target.value)}
                  placeholder="https://example.com/image.jpg"
                  className="bg-slate-800 border-slate-600 text-slate-100 placeholder-slate-400"
                />
              </div>
              <div>
                <Label htmlFor="imageAlt" className="text-slate-100">Alt Text (Optional)</Label>
                <Input
                  id="imageAlt"
                  value={imageAlt}
                  onChange={(e) => setImageAlt(e.target.value)}
                  placeholder="Describe the image"
                  className="bg-slate-800 border-slate-600 text-slate-100 placeholder-slate-400"
                />
              </div>
              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setIsImageDialogOpen(false)} className="border-slate-600 text-slate-200">Cancel</Button>
                <Button onClick={insertImageFromUrl} disabled={!imageUrl} className="bg-blue-600 hover:bg-blue-700">Insert Image</Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>
      
      {/* Editor Content */}
      <EditorContent editor={editor} />
    </div>
  );
};

export default RichTextEditor;
