import React, { useState, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';
import brain from 'brain';
import { Plus, X } from 'lucide-react';
import { API_URL } from 'app';

interface ImageUploadTestProps {
  onImageUploaded?: (url: string) => void;
}

export const ImageUploadTest: React.FC<ImageUploadTestProps> = ({ onImageUploaded }) => {
  const [uploadingImage, setUploadingImage] = useState(false);
  const [imageUrl, setImageUrl] = useState<string>('');
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [debugInfo, setDebugInfo] = useState<any>(null);

  const handleImageUpload = useCallback(async (file: File) => {
    if (!file) {
      console.log('❌ No file provided');
      return;
    }
    
    console.log('🚀 Starting image upload:', {
      name: file.name,
      size: file.size,
      type: file.type
    });
    
    setUploadingImage(true);
    setDebugInfo({ step: 'Starting upload...', file: { name: file.name, size: file.size, type: file.type } });
    
    try {
      console.log('📤 Calling brain.upload_image with file object:', file);
      setDebugInfo(prev => ({ ...prev, step: 'Calling API...' }));
      
      const uploadResponse = await brain.upload_image({ file });
      
      console.log('📨 Upload response received:', {
        status: uploadResponse.status,
        ok: uploadResponse.ok,
        statusText: uploadResponse.statusText
      });
      
      setDebugInfo(prev => ({ 
        ...prev, 
        step: 'Response received', 
        response: { 
          status: uploadResponse.status, 
          ok: uploadResponse.ok,
          statusText: uploadResponse.statusText
        } 
      }));
      
      if (!uploadResponse.ok) {
        const errorText = await uploadResponse.text();
        console.error('❌ Upload failed with response:', errorText);
        setDebugInfo(prev => ({ ...prev, step: 'Upload failed', error: errorText }));
        throw new Error(`Upload failed: ${errorText}`);
      }
      
      const uploadData = await uploadResponse.json();
      console.log('✅ Upload successful, response data:', uploadData);
      
      setDebugInfo(prev => ({ ...prev, step: 'Upload successful', data: uploadData }));
      
      const backendUrl = uploadData.image_url;
      
      if (!backendUrl) {
        console.error('❌ No image_url in response:', uploadData);
        setDebugInfo(prev => ({ ...prev, step: 'No image URL', data: uploadData }));
        throw new Error('No image URL returned from upload');
      }
      
      // Convert backend URL to full URL properly
      // Remove the leading /routes since API_URL already includes the routes path
      const cleanImageUrl = backendUrl.startsWith('/routes') ? backendUrl.substring('/routes'.length) : backendUrl;
      const fullImageUrl = backendUrl.startsWith('http') 
        ? backendUrl 
        : `${API_URL}${cleanImageUrl}`;
      
      console.log('🖼️ Setting image URL:', fullImageUrl);
      setDebugInfo(prev => ({ 
        ...prev, 
        step: 'Setting image URL', 
        urls: { 
          backend: backendUrl, 
          full: fullImageUrl 
        } 
      }));
      
      setImageUrl(fullImageUrl);
      setUploadedFile(file);
      onImageUploaded?.(fullImageUrl);
      
      toast.success('Image uploaded successfully!');
      
    } catch (error) {
      console.error('💥 Upload error:', error);
      setDebugInfo(prev => ({ 
        ...prev, 
        step: 'Error occurred', 
        error: error instanceof Error ? error.message : 'Unknown error' 
      }));
      toast.error(`Failed to upload image: ${error instanceof Error ? error.message : 'Unknown error'}`);
    } finally {
      setUploadingImage(false);
    }
  }, [onImageUploaded]);

  const handleFileSelect = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*';
    input.onchange = (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (file) {
        console.log('📁 File selected:', file);
        handleImageUpload(file);
      }
    };
    input.click();
  };

  const clearImage = () => {
    setImageUrl('');
    setUploadedFile(null);
    setDebugInfo(null);
  };

  return (
    <div className="p-6 bg-gray-800 rounded-lg space-y-4">
      <h3 className="text-lg font-semibold text-white">Image Upload Test</h3>
      
      {/* Upload Section */}
      <div className="border-2 border-dashed border-gray-600 rounded-lg p-6">
        {imageUrl ? (
          <div className="space-y-4">
            <div className="flex items-center justify-center">
              <img 
                src={imageUrl} 
                alt="Uploaded preview" 
                className="max-h-32 rounded-lg object-cover border border-gray-600"
                onLoad={() => console.log('🖼️ Image loaded successfully')}
                onError={(e) => {
                  console.error('❌ Image failed to load:', imageUrl);
                  console.error('Error event:', e);
                }}
              />
            </div>
            <div className="text-center">
              <p className="text-sm text-green-400">✅ Image displayed successfully!</p>
              <p className="text-xs text-gray-400 mt-1">{uploadedFile?.name} ({uploadedFile?.size} bytes)</p>
            </div>
            <div className="flex justify-center">
              <Button onClick={clearImage} variant="outline" size="sm">
                <X className="h-4 w-4 mr-1" />
                Clear Image
              </Button>
            </div>
          </div>
        ) : (
          <div className="text-center">
            <Button 
              onClick={handleFileSelect} 
              disabled={uploadingImage}
              variant="outline"
            >
              {uploadingImage ? (
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-blue-400 mr-2"></div>
              ) : (
                <Plus className="h-4 w-4 mr-2" />
              )}
              {uploadingImage ? 'Uploading...' : 'Select Image to Upload'}
            </Button>
            <p className="text-xs text-gray-500 mt-2">PNG, JPG, GIF up to 5MB</p>
          </div>
        )}
      </div>

      {/* Debug Info Section */}
      {debugInfo && (
        <div className="bg-gray-900 rounded p-4">
          <h4 className="text-sm font-semibold text-yellow-400 mb-2">Debug Information:</h4>
          <pre className="text-xs text-gray-300 whitespace-pre-wrap overflow-auto max-h-40">
            {JSON.stringify(debugInfo, null, 2)}
          </pre>
        </div>
      )}
    </div>
  );
};

export default ImageUploadTest;
