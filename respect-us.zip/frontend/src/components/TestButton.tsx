import React from 'react';
import { Button } from '@/components/ui/button';

const TestButton: React.FC = () => {
  const handleClick = () => {
    console.log('🧪 TEST BUTTON CLICKED - Event registration working!');
  };

  return (
    <div className="p-4 bg-slate-800 border border-slate-600 rounded">
      <h3 className="text-white mb-2">Test Button Component</h3>
      <Button onClick={handleClick} className="bg-red-600 hover:bg-red-700">
        Click to Test Event
      </Button>
    </div>
  );
};

export default TestButton;
