import React, { useState, useEffect } from 'react';
import { Badge } from '@/components/ui/badge';
import { Shield } from 'lucide-react';
import brain from 'brain';

export interface RegulatoryNoteButtonProps {
  noteKey: string;
  onClick?: (e: React.MouseEvent) => void;
}

export const RegulatoryNoteButton: React.FC<RegulatoryNoteButtonProps> = ({ noteKey, onClick }) => {
  const [noteData, setNoteData] = useState<{title: string; content: string} | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const fetchNoteData = async () => {
      if (!noteKey || noteKey.trim() === '') return;

      setLoading(true);
      try {
        const response = await brain.get_classification_note_by_key({ noteKey: noteKey.trim() });
        const result = await response.json();
        
        if (result && result.title) {
          setNoteData({
            title: result.title,
            content: result.content || ''
          });
        } else {
          console.warn(`No note data found for key: ${noteKey}`);
        }
      } catch (error) {
        console.error(`Failed to fetch note ${noteKey}:`, error);
      } finally {
        setLoading(false);
      }
    };

    fetchNoteData();
  }, [noteKey]);

  if (loading) {
    return (
      <Badge 
        variant="outline" 
        className="text-xs border-amber-500 text-amber-400 bg-amber-500/10 cursor-pointer hover:bg-amber-500/20 transition-colors"
        onClick={onClick}
      >
        <Shield className="h-3 w-3 mr-1" />
        Loading...
      </Badge>
    );
  }

  if (!noteData) {
    return (
      <Badge 
        variant="outline" 
        className="text-xs border-gray-500 text-gray-400 bg-gray-500/10 cursor-pointer hover:bg-gray-500/20 transition-colors"
        onClick={onClick}
        title={`Note not found: ${noteKey}`}
      >
        <Shield className="h-3 w-3 mr-1" />
        {noteKey}
      </Badge>
    );
  }

  return (
    <Badge 
      variant="outline" 
      className="text-xs border-amber-500 text-amber-400 bg-amber-500/10 cursor-pointer hover:bg-amber-500/20 transition-colors"
      onClick={onClick}
      title={noteData.content}
    >
      <Shield className="h-3 w-3 mr-1" />
      {noteData.title}
    </Badge>
  );
};
