import React, { useState, useEffect, startTransition } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Download, AlertCircle, Loader2, X, ExternalLink } from 'lucide-react';
import { auth } from 'app/auth';
import { API_URL, APP_BASE_PATH } from 'app';
import { useNavigate } from 'react-router-dom';
import brain from 'brain';

interface Props {
  documentId: number;
  documentTitle: string;
  isOpen: boolean;
  onClose: () => void;
}

// Browser detection helper
const detectBrowser = () => {
  const userAgent = navigator.userAgent.toLowerCase();
  if (userAgent.includes('chrome') && !userAgent.includes('edg')) {
    return 'chrome';
  } else if (userAgent.includes('firefox')) {
    return 'firefox';
  } else if (userAgent.includes('safari') && !userAgent.includes('chrome')) {
    return 'safari';
  }
  return 'other';
};

export const PDFLoader: React.FC<Props> = ({ documentId, documentTitle, isOpen, onClose }) => {
  const navigate = useNavigate();
  const [pdfBlobUrl, setPdfBlobUrl] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [browserType] = useState(detectBrowser());

  // Load PDF when dialog opens
  useEffect(() => {
    if (isOpen && !pdfBlobUrl && !loading) {
      startTransition(() => {
        loadPDF();
      });
    }
  }, [isOpen, pdfBlobUrl, loading]);

  // Cleanup blob URL when dialog closes
  useEffect(() => {
    if (!isOpen && pdfBlobUrl) {
      URL.revokeObjectURL(pdfBlobUrl);
      setPdfBlobUrl(null);
    }
  }, [isOpen, pdfBlobUrl]);

  const loadPDF = async () => {
    setLoading(true);
    setError(null);
    
    try {
      console.log('Loading PDF for document:', documentId);
      
      // Use fetch directly since brain method returns a stream iterator
      // Get auth token for the request
      const token = await auth.getAuthToken();
      
      const response = await fetch(`${brain.baseUrl}/routes/knowledge-base/file/${documentId}`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        credentials: 'include'
      });
      
      console.log('PDF response status:', response.status);
      
      // Check if response is ok
      if (!response.ok) {
        throw new Error(`Failed to load PDF: HTTP ${response.status}`);
      }
      
      // Get the blob from the response
      const blob = await response.blob();
      console.log('PDF blob size:', blob.size);
      
      if (blob.size === 0) {
        throw new Error('PDF file is empty');
      }
      
      const url = URL.createObjectURL(blob);
      setPdfBlobUrl(url);
      
      console.log('PDF loaded successfully');
    } catch (err) {
      console.error('Error loading PDF:', err);
      setError(err instanceof Error ? err.message : 'Failed to load PDF');
    } finally {
      setLoading(false);
    }
  };

  const handleDownload = () => {
    if (pdfBlobUrl) {
      const link = document.createElement('a');
      link.href = pdfBlobUrl;
      link.download = `${documentTitle}.pdf`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  };

  const openInNewTab = async () => {
    try {
      // Use fetch directly since brain method returns a stream iterator
      // Get auth token for the request
      const token = await auth.getAuthToken();
      
      const response = await fetch(`${brain.baseUrl}/routes/knowledge-base/file/${documentId}`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        credentials: 'include'
      });
      
      console.log('PDF response status for new tab:', response.status);
      
      if (!response.ok) {
        throw new Error(`Failed to load PDF: HTTP ${response.status}`);
      }
      
      const blob = await response.blob();
      
      if (blob.size === 0) {
        throw new Error('PDF file is empty');
      }
      
      const url = URL.createObjectURL(blob);
      
      console.log('Opening PDF in new tab for document:', documentId);
      
      // Open the PDF blob URL in a new tab
      window.open(url, '_blank');
      
      // Clean up the blob URL after a delay
      setTimeout(() => {
        URL.revokeObjectURL(url);
      }, 1000);
    } catch (error) {
      console.error('Error opening PDF in new tab:', error);
      setError('Failed to open PDF in new tab');
    }
  };

  const renderPDFViewer = () => {
    if (!pdfBlobUrl) return null;

    // Chrome-specific rendering with fallback
    if (browserType === 'chrome') {
      return (
        <div className="w-full h-[70vh] bg-gray-800 rounded border border-gray-700">
          <div className="flex flex-col h-full">
            {/* Chrome compatibility notice */}
            <div className="bg-yellow-900/20 border-yellow-600/30 border p-3 mb-4 rounded flex items-center gap-3">
              <AlertCircle className="w-5 h-5 text-yellow-400 flex-shrink-0" />
              <div className="text-yellow-200 text-sm">
                Chrome may block PDF display in embedded viewers. Use "Open in New Tab" for best experience.
              </div>
            </div>
            
            {/* Try Chrome's native PDF viewer with #view=FitH */}
            <iframe
              src={`${pdfBlobUrl}#view=FitH&toolbar=1&navpanes=1&scrollbar=1`}
              className="flex-1 w-full rounded"
              title={documentTitle}
              sandbox="allow-same-origin allow-scripts"
            />
          </div>
        </div>
      );
    }

    // Firefox and other browsers - standard iframe
    return (
      <div className="w-full h-[70vh] bg-gray-800 rounded border border-gray-700">
        <iframe
          src={pdfBlobUrl}
          className="w-full h-full rounded"
          title={documentTitle}
        />
      </div>
    );
  };

  if (!isOpen) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-gray-900 border-gray-700 max-w-6xl max-h-[90vh] p-0">
        <DialogHeader className="p-6 pb-0">
          <div className="flex items-center justify-between">
            <DialogTitle className="text-white">{documentTitle}</DialogTitle>
            <div className="flex items-center gap-2">
              {pdfBlobUrl && (
                <>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={openInNewTab}
                    className="border-gray-600 text-gray-300 hover:bg-gray-700"
                  >
                    <ExternalLink className="w-4 h-4 mr-2" />
                    Open in New Tab
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleDownload}
                    className="border-gray-600 text-gray-300 hover:bg-gray-700"
                  >
                    <Download className="w-4 h-4 mr-2" />
                    Download
                  </Button>
                </>
              )}
              <Button
                variant="ghost"
                size="sm"
                onClick={onClose}
                className="text-gray-400 hover:text-white hover:bg-gray-700"
              >
                <X className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </DialogHeader>
        
        <div className="flex-1 p-6 pt-4">
          {loading && (
            <div className="flex items-center justify-center h-96">
              <div className="flex flex-col items-center gap-4">
                <div className="w-8 h-8 border-2 border-blue-400 border-t-transparent rounded-full animate-spin"></div>
                <div className="text-gray-400">Loading PDF...</div>
              </div>
            </div>
          )}
          
          {error && (
            <div className="flex items-center justify-center h-96">
              <div className="flex flex-col items-center gap-4 text-center">
                <AlertCircle className="w-12 h-12 text-red-400" />
                <div className="text-red-400 font-medium">Failed to load PDF</div>
                <div className="text-gray-400 text-sm max-w-md">{error}</div>
                <Button
                  variant="outline"
                  onClick={loadPDF}
                  className="border-gray-600 text-gray-300 hover:bg-gray-700"
                >
                  Try Again
                </Button>
              </div>
            </div>
          )}
          
          {renderPDFViewer()}
        </div>
      </DialogContent>
    </Dialog>
  );
};
