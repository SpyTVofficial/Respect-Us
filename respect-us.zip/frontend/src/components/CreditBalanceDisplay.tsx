import React, { useState, useEffect } from 'react';
import { useUser } from '@stackframe/react';
import { Button } from '@/components/ui/button';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Badge } from '@/components/ui/badge';
import { 
  Coins, 
  Plus, 
  History, 
  TrendingUp, 
  RefreshCw,
  AlertCircle,
  Zap
} from 'lucide-react';
import brain from 'brain';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';

interface CreditBalance {
  user_id: string;
  current_balance: number;
  lifetime_purchased: number;
  lifetime_consumed: number;
}

interface CreditBalanceDisplayProps {
  className?: string;
  variant?: 'full' | 'compact' | 'minimal';
  showDropdown?: boolean;
}

export default function CreditBalanceDisplay({ 
  className = '', 
  variant = 'full',
  showDropdown = true 
}: CreditBalanceDisplayProps) {
  const user = useUser();
  const navigate = useNavigate();
  const [balance, setBalance] = useState<CreditBalance | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Fetch credit balance
  const fetchBalance = async () => {
    if (!user) return;
    
    setIsLoading(true);
    setError(null);
    
    try {
      const response = await brain.get_credit_balance();
      const data = await response.json();
      setBalance(data);
    } catch (err) {
      console.error('Failed to fetch credit balance:', err);
      setError('Failed to load balance');
      toast.error('Failed to load credit balance');
    } finally {
      setIsLoading(false);
    }
  };

  // Initial fetch and setup polling
  useEffect(() => {
    if (user) {
      fetchBalance();
      
      // Poll for balance updates every 30 seconds
      const interval = setInterval(fetchBalance, 30000);
      return () => clearInterval(interval);
    }
  }, [user]);

  // Listen for credit consumption events across the app
  useEffect(() => {
    const handleCreditUpdate = () => {
      fetchBalance();
    };

    // Add event listener for credit updates
    window.addEventListener('credit-consumed', handleCreditUpdate);
    window.addEventListener('credit-purchased', handleCreditUpdate);
    
    return () => {
      window.removeEventListener('credit-consumed', handleCreditUpdate);
      window.removeEventListener('credit-purchased', handleCreditUpdate);
    };
  }, []);

  const handleRefresh = () => {
    fetchBalance();
  };

  const handlePurchaseCredits = () => {
    navigate('/user-dashboard?tab=credits');
  };

  const handleViewHistory = () => {
    navigate('/user-dashboard?tab=credit-history');
  };

  const handleViewAnalytics = () => {
    navigate('/user-dashboard?tab=usage-analytics');
  };

  if (!user) return null;

  const currentBalance = balance?.current_balance ?? 0;
  const isLowBalance = currentBalance < 10;
  const isCriticalBalance = currentBalance < 5;

  // Determine balance color based on amount
  const getBalanceColor = () => {
    if (isCriticalBalance) return 'text-red-400';
    if (isLowBalance) return 'text-yellow-400';
    return 'text-green-400';
  };

  const formatBalance = (amount: number) => {
    if (amount >= 1000000) return `${(amount / 1000000).toFixed(1)}M`;
    if (amount >= 1000) return `${(amount / 1000).toFixed(1)}K`;
    return amount.toString();
  };

  if (variant === 'minimal') {
    return (
      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>
            <div className={`flex items-center space-x-1 ${className}`}>
              <Coins className="w-4 h-4 text-yellow-400" />
              <span className={`text-sm font-medium ${getBalanceColor()}`}>
                {formatBalance(currentBalance)}
              </span>
            </div>
          </TooltipTrigger>
          <TooltipContent>
            <p>Credit Balance: {currentBalance.toLocaleString()}</p>
            {isLowBalance && <p className="text-yellow-400">Low balance - consider purchasing more credits</p>}
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>
    );
  }

  if (variant === 'compact') {
    return (
      <Button
        variant="ghost"
        onClick={handlePurchaseCredits}
        className={`flex items-center space-x-2 text-gray-300 hover:text-white ${className}`}
      >
        <Coins className="w-4 h-4 text-yellow-400" />
        <span className={`font-medium ${getBalanceColor()}`}>
          {formatBalance(currentBalance)}
        </span>
        {isLowBalance && (
          <AlertCircle className="w-3 h-3 text-yellow-400" />
        )}
      </Button>
    );
  }

  // Full variant with dropdown
  if (!showDropdown) {
    return (
      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>
            <Button
              variant="ghost"
              onClick={handlePurchaseCredits}
              className={`flex items-center space-x-2 text-gray-300 hover:text-white ${className}`}
            >
              <div className="flex items-center space-x-2">
                <div className="flex items-center space-x-1">
                  <Coins className="w-4 h-4 text-yellow-400" />
                  <span className={`font-medium ${getBalanceColor()}`}>
                    {isLoading ? '...' : formatBalance(currentBalance)}
                  </span>
                </div>
                {isLowBalance && (
                  <AlertCircle className="w-3 h-3 text-yellow-400" />
                )}
              </div>
            </Button>
          </TooltipTrigger>
          <TooltipContent>
            <div className="space-y-1">
              <p>Credit Balance: {currentBalance.toLocaleString()}</p>
              {balance && (
                <>
                  <p className="text-xs text-gray-400">Lifetime Purchased: {balance.lifetime_purchased.toLocaleString()}</p>
                  <p className="text-xs text-gray-400">Lifetime Used: {balance.lifetime_consumed.toLocaleString()}</p>
                </>
              )}
              {isLowBalance && <p className="text-yellow-400 text-xs">Click to purchase more credits</p>}
            </div>
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>
    );
  }

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button
          variant="ghost"
          className={`flex items-center space-x-2 text-gray-300 hover:text-white ${className}`}
        >
          <div className="flex items-center space-x-2">
            <div className="flex items-center space-x-1">
              <Coins className="w-4 h-4 text-yellow-400" />
              <span className={`font-medium ${getBalanceColor()}`}>
                {isLoading ? '...' : formatBalance(currentBalance)}
              </span>
            </div>
            {isLowBalance && (
              <AlertCircle className="w-3 h-3 text-yellow-400" />
            )}
          </div>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="bg-gray-900/95 backdrop-blur-lg border-gray-700 text-white w-64">
        {/* Balance Overview */}
        <div className="px-3 py-2 border-b border-gray-700">
          <div className="flex items-center justify-between">
            <span className="text-sm text-gray-400">Credit Balance</span>
            <Button
              variant="ghost"
              size="sm"
              onClick={handleRefresh}
              className="h-6 w-6 p-0 text-gray-400 hover:text-white"
              disabled={isLoading}
            >
              <RefreshCw className={`w-3 h-3 ${isLoading ? 'animate-spin' : ''}`} />
            </Button>
          </div>
          <div className="flex items-center space-x-2 mt-1">
            <span className={`text-lg font-bold ${getBalanceColor()}`}>
              {currentBalance.toLocaleString()}
            </span>
            <Badge 
              variant="outline" 
              className={`text-xs ${
                isCriticalBalance 
                  ? 'border-red-500/30 bg-red-500/10 text-red-400'
                  : isLowBalance 
                    ? 'border-yellow-500/30 bg-yellow-500/10 text-yellow-400'
                    : 'border-green-500/30 bg-green-500/10 text-green-400'
              }`}
            >
              {isCriticalBalance ? 'Critical' : isLowBalance ? 'Low' : 'Good'}
            </Badge>
          </div>
          
          {balance && (
            <div className="grid grid-cols-2 gap-4 mt-2 text-xs text-gray-400">
              <div>
                <span className="block">Purchased</span>
                <span className="text-white font-medium">{balance.lifetime_purchased.toLocaleString()}</span>
              </div>
              <div>
                <span className="block">Used</span>
                <span className="text-white font-medium">{balance.lifetime_consumed.toLocaleString()}</span>
              </div>
            </div>
          )}
        </div>

        {/* Warning for low balance */}
        {isLowBalance && (
          <div className="px-3 py-2 bg-yellow-500/10 border border-yellow-500/20">
            <div className="flex items-center space-x-2">
              <AlertCircle className="w-4 h-4 text-yellow-400" />
              <span className="text-sm text-yellow-400">
                {isCriticalBalance ? 'Critical balance!' : 'Low balance'}
              </span>
            </div>
            <p className="text-xs text-gray-400 mt-1">
              Consider purchasing more credits to continue using premium features.
            </p>
          </div>
        )}

        {/* Actions */}
        <div className="py-1">
          <DropdownMenuItem onClick={handlePurchaseCredits} className="hover:bg-gray-800">
            <Plus className="w-4 h-4 mr-2" />
            Purchase Credits
          </DropdownMenuItem>
          <DropdownMenuItem onClick={handleViewHistory} className="hover:bg-gray-800">
            <History className="w-4 h-4 mr-2" />
            Transaction History
          </DropdownMenuItem>
          <DropdownMenuItem onClick={handleViewAnalytics} className="hover:bg-gray-800">
            <TrendingUp className="w-4 h-4 mr-2" />
            Usage Analytics
          </DropdownMenuItem>
        </div>

        {error && (
          <div className="px-3 py-2 border-t border-gray-700">
            <div className="flex items-center space-x-2">
              <AlertCircle className="w-4 h-4 text-red-400" />
              <span className="text-xs text-red-400">{error}</span>
            </div>
          </div>
        )}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
