import React, { useState, useEffect, useCallback, useRef } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Search, ExternalLink, FileText, CheckCircle2, AlertCircle, Clock, X } from 'lucide-react';
import { toast } from 'sonner';

// Base interfaces for search widget functionality
export interface SearchResult {
  id: string;
  title: string;
  description?: string;
  details?: Record<string, any>;
  tags?: string[];
  relevanceScore?: number;
  type?: string;
}

export interface SearchWidgetConfig {
  title: string;
  description: string;
  placeholder: string;
  searchFunction: (query: string, filters?: Record<string, any>) => Promise<SearchResult[]>;
  repositoryLink?: {
    label: string;
    url: string;
    description: string;
  };
  filters?: {
    label: string;
    key: string;
    options: { value: string; label: string }[];
  }[];
  resultTemplate?: (result: SearchResult) => React.ReactNode;
  onSelect?: (result: SearchResult) => void;
  multiSelect?: boolean;
}

interface SearchWidgetProps {
  config: SearchWidgetConfig;
  open: boolean;
  onClose: () => void;
  onSelectionConfirmed?: (results: SearchResult[]) => void;
  initialQuery?: string;
  className?: string;
}

export default function SearchWidget({
  config,
  open,
  onClose,
  onSelectionConfirmed,
  initialQuery = '',
  className = ''
}: SearchWidgetProps) {
  const [query, setQuery] = useState(initialQuery);
  const [results, setResults] = useState<SearchResult[]>([]);
  const [selectedResults, setSelectedResults] = useState<SearchResult[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [searchPerformed, setSearchPerformed] = useState(false);
  const [filters, setFilters] = useState<Record<string, string>>({});
  const [searchStartTime, setSearchStartTime] = useState<number>(0);
  const searchTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  // Debounced search function
  const performSearch = useCallback(async (searchQuery: string) => {
    if (!searchQuery.trim()) {
      setResults([]);
      setSearchPerformed(false);
      return;
    }

    setIsSearching(true);
    setSearchStartTime(Date.now());
    
    try {
      const searchResults = await config.searchFunction(searchQuery, filters);
      const searchTime = Date.now() - searchStartTime;
      
      setResults(searchResults);
      setSearchPerformed(true);
      
      // Log search performance (for analytics)
      console.log(`Search completed in ${searchTime}ms for query: "${searchQuery}"`);
      
      if (searchTime > 500) {
        console.warn(`Slow search detected: ${searchTime}ms`);
      }
    } catch (error) {
      console.error('Search error:', error);
      toast.error('Search failed. Please try again.');
      setResults([]);
    } finally {
      setIsSearching(false);
    }
  }, [config.searchFunction, filters, searchStartTime]);

  // Debounced search effect
  useEffect(() => {
    if (searchTimeoutRef.current) {
      clearTimeout(searchTimeoutRef.current);
    }

    searchTimeoutRef.current = setTimeout(() => {
      performSearch(query);
    }, 300); // 300ms debounce

    return () => {
      if (searchTimeoutRef.current) {
        clearTimeout(searchTimeoutRef.current);
      }
    };
  }, [query, performSearch]);

  // Initialize query from props
  useEffect(() => {
    setQuery(initialQuery);
  }, [initialQuery]);

  // Clear state when dialog closes
  useEffect(() => {
    if (!open) {
      setQuery('');
      setResults([]);
      setSelectedResults([]);
      setSearchPerformed(false);
      setFilters({});
    }
  }, [open]);

  const handleResultSelect = (result: SearchResult) => {
    if (config.multiSelect) {
      setSelectedResults(prev => {
        const isSelected = prev.some(r => r.id === result.id);
        if (isSelected) {
          return prev.filter(r => r.id !== result.id);
        } else {
          return [...prev, result];
        }
      });
    } else {
      setSelectedResults([result]);
      if (config.onSelect) {
        config.onSelect(result);
      }
    }
  };

  const handleConfirmSelection = () => {
    if (onSelectionConfirmed && selectedResults.length > 0) {
      onSelectionConfirmed(selectedResults);
    }
    onClose();
  };

  const handleRepositoryLink = () => {
    if (config.repositoryLink) {
      window.open(config.repositoryLink.url, '_blank');
      // Log repository access for audit trail
      console.log(`Repository accessed: ${config.repositoryLink.label}`);
    }
  };

  const DefaultResultTemplate = ({ result }: { result: SearchResult }) => (
    <Card 
      className={`cursor-pointer transition-all hover:shadow-md border border-gray-700 hover:border-gray-600 ${
        selectedResults.some(r => r.id === result.id) 
          ? 'bg-blue-900/20 border-blue-600' 
          : 'bg-gray-800'
      }`}
      onClick={() => handleResultSelect(result)}
    >
      <CardContent className="p-4">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <h4 className="font-medium text-white mb-1">{result.title}</h4>
            {result.description && (
              <p className="text-sm text-gray-400 mb-2">{result.description}</p>
            )}
            {result.tags && result.tags.length > 0 && (
              <div className="flex flex-wrap gap-1">
                {result.tags.map((tag, index) => (
                  <Badge key={index} variant="secondary" className="text-xs">
                    {tag}
                  </Badge>
                ))}
              </div>
            )}
          </div>
          {selectedResults.some(r => r.id === result.id) && (
            <CheckCircle2 className="h-5 w-5 text-blue-400 flex-shrink-0 ml-2" />
          )}
        </div>
      </CardContent>
    </Card>
  );

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className={`bg-gray-900 border-gray-700 text-white max-w-4xl max-h-[90vh] ${className}`}>
        <DialogHeader>
          <DialogTitle className="flex items-center gap-3 text-xl">
            <Search className="h-6 w-6 text-blue-400" />
            {config.title}
          </DialogTitle>
          <DialogDescription className="text-gray-400">
            {config.description}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          {/* Search Input */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            <Input
              placeholder={config.placeholder}
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              className="pl-10 bg-gray-800 border-gray-600 text-white placeholder-gray-400"
              autoFocus
            />
            {query && (
              <Button
                variant="ghost"
                size="sm"
                className="absolute right-2 top-1/2 transform -translate-y-1/2 h-6 w-6 p-0 text-gray-400 hover:text-white"
                onClick={() => setQuery('')}
              >
                <X className="h-4 w-4" />
              </Button>
            )}
          </div>

          {/* Filters */}
          {config.filters && config.filters.length > 0 && (
            <div className="flex flex-wrap gap-2">
              {config.filters.map((filter) => (
                <select
                  key={filter.key}
                  className="bg-gray-800 border border-gray-600 rounded px-2 py-1 text-sm text-white"
                  value={filters[filter.key] || ''}
                  onChange={(e) => setFilters(prev => ({ ...prev, [filter.key]: e.target.value }))}
                >
                  <option value="">{filter.label}: All</option>
                  {filter.options.map((option) => (
                    <option key={option.value} value={option.value}>
                      {option.label}
                    </option>
                  ))}
                </select>
              ))}
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              {isSearching && (
                <div className="flex items-center gap-2 text-sm text-gray-400">
                  <Clock className="h-4 w-4 animate-spin" />
                  Searching...
                </div>
              )}
              {searchPerformed && !isSearching && (
                <div className="text-sm text-gray-400">
                  {results.length} result{results.length !== 1 ? 's' : ''} found
                </div>
              )}
            </div>
            
            {config.repositoryLink && (
              <Button
                variant="outline"
                size="sm"
                onClick={handleRepositoryLink}
                className="border-gray-600 text-gray-300 hover:bg-gray-700"
              >
                <ExternalLink className="h-4 w-4 mr-2" />
                {config.repositoryLink.label}
              </Button>
            )}
          </div>

          <Separator className="bg-gray-700" />

          {/* Search Results */}
          <ScrollArea className="h-96">
            {searchPerformed && !isSearching ? (
              results.length > 0 ? (
                <div className="space-y-2">
                  {results.map((result) => (
                    <div key={result.id}>
                      {config.resultTemplate ? (
                        config.resultTemplate(result)
                      ) : (
                        <DefaultResultTemplate result={result} />
                      )}
                    </div>
                  ))}
                </div>
              ) : query.trim() ? (
                <div className="text-center py-8">
                  <AlertCircle className="h-12 w-12 text-gray-500 mx-auto mb-3" />
                  <p className="text-gray-400">No results found for "{query}"</p>
                  <p className="text-sm text-gray-500 mt-1">
                    Try different keywords or check the full database
                  </p>
                </div>
              ) : (
                <div className="text-center py-8">
                  <Search className="h-12 w-12 text-gray-500 mx-auto mb-3" />
                  <p className="text-gray-400">Enter a search term to get started</p>
                </div>
              )
            ) : query.trim() && isSearching ? (
              <div className="text-center py-8">
                <Clock className="h-12 w-12 text-gray-500 mx-auto mb-3 animate-spin" />
                <p className="text-gray-400">Searching...</p>
              </div>
            ) : (
              <div className="text-center py-8">
                <Search className="h-12 w-12 text-gray-500 mx-auto mb-3" />
                <p className="text-gray-400">Enter a search term to get started</p>
              </div>
            )}
          </ScrollArea>

          {/* Selection Actions */}
          {selectedResults.length > 0 && (
            <>
              <Separator className="bg-gray-700" />
              <div className="flex items-center justify-between">
                <div className="text-sm text-gray-400">
                  {selectedResults.length} item{selectedResults.length !== 1 ? 's' : ''} selected
                </div>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setSelectedResults([])}
                    className="border-gray-600 text-gray-300 hover:bg-gray-700"
                  >
                    Clear Selection
                  </Button>
                  <Button
                    size="sm"
                    onClick={handleConfirmSelection}
                    className="bg-blue-600 hover:bg-blue-700"
                  >
                    <CheckCircle2 className="h-4 w-4 mr-2" />
                    Confirm Selection
                  </Button>
                </div>
              </div>
            </>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}

// Helper function to create search widget configurations
export function createSearchConfig(config: Partial<SearchWidgetConfig> & { 
  title: string; 
  searchFunction: SearchWidgetConfig['searchFunction'] 
}): SearchWidgetConfig {
  return {
    description: 'Search and select items from the database',
    placeholder: 'Enter search terms...',
    ...config
  };
}
