import React, { useState, useEffect } from 'react';
import { toast } from 'sonner';
import brain from 'brain';
import { SavedArticleResponse } from 'types';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Bookmark,
  Search,
  Filter,
  Grid3X3,
  List,
  SortAsc,
  SortDesc,
} from 'lucide-react';
import { CategoryManager } from 'components/CategoryManager';
import { SavedArticleCard } from 'components/SavedArticleCard';
import { groupArticlesByCategory, sortCategoriesByDisplayOrder } from 'utils/categoryUtils';

interface Props {
  onNavigateToRepository?: () => void;
}

export const SavedArticlesView: React.FC<Props> = ({ onNavigateToRepository }) => {
  const [savedArticles, setSavedArticles] = useState<SavedArticleResponse[]>([]);
  const [filteredArticles, setFilteredArticles] = useState<SavedArticleResponse[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [selectedCategoryId, setSelectedCategoryId] = useState<number | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<'saved_at' | 'title'>('saved_at');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');
  const [viewMode, setViewMode] = useState<'grid' | 'list' | 'grouped'>('grid');
  const [showCategoryManager, setShowCategoryManager] = useState(false);

  // Load saved articles
  const loadSavedArticles = async (categoryId?: number | null) => {
    try {
      setIsLoading(true);
      const params = categoryId ? { category_id: categoryId } : {};
      const response = await brain.get_saved_articles(params);
      const data = await response.json();
      setSavedArticles(data);
      setFilteredArticles(data);
    } catch (error) {
      console.error('Error loading saved articles:', error);
      toast.error('Failed to load saved articles');
    } finally {
      setIsLoading(false);
    }
  };

  // Load articles on mount and when category filter changes
  useEffect(() => {
    loadSavedArticles(selectedCategoryId);
  }, [selectedCategoryId]);

  // Apply search and sort filters
  useEffect(() => {
    let filtered = [...savedArticles];

    // Apply search filter
    if (searchQuery.trim()) {
      filtered = filtered.filter(article => 
        article.document_title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (article.document_description && article.document_description.toLowerCase().includes(searchQuery.toLowerCase()))
      );
    }

    // Apply sorting
    filtered.sort((a, b) => {
      let comparison = 0;
      
      if (sortBy === 'saved_at') {
        comparison = new Date(a.saved_at).getTime() - new Date(b.saved_at).getTime();
      } else if (sortBy === 'title') {
        comparison = a.document_title.localeCompare(b.document_title);
      }
      
      return sortOrder === 'desc' ? -comparison : comparison;
    });

    setFilteredArticles(filtered);
  }, [savedArticles, searchQuery, sortBy, sortOrder]);

  const handleUnsaveArticle = async (articleId: number) => {
    const article = savedArticles.find(a => a.id === articleId);
    if (!article) return;

    try {
      await brain.unsave_article({ documentId: article.document_id });
      toast.success('Article removed from saved collection');
      loadSavedArticles(selectedCategoryId); // Reload the current view
    } catch (error) {
      console.error('Error unsaving article:', error);
      toast.error('Failed to remove article');
    }
  };

  const handleCategoryChange = () => {
    loadSavedArticles(selectedCategoryId); // Reload to get updated category assignments
  };

  const toggleSortOrder = () => {
    setSortOrder(prev => prev === 'asc' ? 'desc' : 'asc');
  };

  const renderArticleGrid = (articles: SavedArticleResponse[]) => (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {articles.map((article) => (
        <SavedArticleCard
          key={article.id}
          article={article}
          onUnsave={handleUnsaveArticle}
          onCategoriesUpdated={handleCategoryChange}
        />
      ))}
    </div>
  );

  const renderGroupedView = () => {
    const grouped = groupArticlesByCategory(filteredArticles);
    const categoryNames = Object.keys(grouped).sort();

    return (
      <div className="space-y-8">
        {categoryNames.map(categoryName => {
          const articles = grouped[categoryName];
          if (articles.length === 0) return null;

          return (
            <div key={categoryName} className="space-y-4">
              <div className="flex items-center gap-3">
                <h3 className="text-lg font-semibold text-white">{categoryName}</h3>
                <span className="text-sm text-gray-400">({articles.length})</span>
              </div>
              {renderArticleGrid(articles)}
            </div>
          );
        })}
      </div>
    );
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="text-center">
        <h2 className="text-3xl font-bold text-white mb-4 flex items-center justify-center gap-3">
          <Bookmark className="w-8 h-8 text-rose-400" />
          Saved Articles
        </h2>
        <p className="text-gray-400 mb-8 max-w-2xl mx-auto">
          Access your saved documents and articles for quick reference.
        </p>
      </div>

      {/* Category Management Toggle */}
      <div className="flex justify-between items-center">
        <Button
          variant="outline"
          onClick={() => setShowCategoryManager(!showCategoryManager)}
          className="bg-gray-800 border-gray-600 hover:bg-gray-700"
        >
          <Filter className="w-4 h-4 mr-2" />
          {showCategoryManager ? 'Hide' : 'Manage'} Categories
        </Button>
        
        <div className="text-sm text-gray-400">
          {filteredArticles.length} {filteredArticles.length === 1 ? 'article' : 'articles'}
          {selectedCategoryId && ' in selected category'}
        </div>
      </div>

      {/* Category Manager */}
      {showCategoryManager && (
        <div className="bg-gray-800/30 rounded-lg p-6 border border-gray-700">
          <CategoryManager
            onCategoryChange={handleCategoryChange}
            selectedCategoryId={selectedCategoryId}
            onCategorySelect={setSelectedCategoryId}
          />
        </div>
      )}

      {/* Search and Filters */}
      {savedArticles.length > 0 && (
        <div className="flex flex-col sm:flex-row gap-4 items-center">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <Input
              placeholder="Search articles..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 bg-gray-800 border-gray-600"
            />
          </div>
          
          <div className="flex items-center gap-2">
            <Select value={sortBy} onValueChange={(value: 'saved_at' | 'title') => setSortBy(value)}>
              <SelectTrigger className="w-32 bg-gray-800 border-gray-600">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-gray-800 border-gray-600">
                <SelectItem value="saved_at">Date Saved</SelectItem>
                <SelectItem value="title">Title</SelectItem>
              </SelectContent>
            </Select>
            
            <Button
              variant="outline"
              size="sm"
              onClick={toggleSortOrder}
              className="bg-gray-800 border-gray-600"
            >
              {sortOrder === 'asc' ? <SortAsc className="w-4 h-4" /> : <SortDesc className="w-4 h-4" />}
            </Button>
          </div>

          <div className="flex items-center gap-1 bg-gray-800 rounded-lg p-1">
            <Button
              variant={viewMode === 'grid' ? 'default' : 'ghost'}
              size="sm"
              onClick={() => setViewMode('grid')}
              className={viewMode === 'grid' ? 'bg-blue-600' : ''}
            >
              <Grid3X3 className="w-4 h-4" />
            </Button>
            <Button
              variant={viewMode === 'list' ? 'default' : 'ghost'}
              size="sm"
              onClick={() => setViewMode('list')}
              className={viewMode === 'list' ? 'bg-blue-600' : ''}
            >
              <List className="w-4 h-4" />
            </Button>
            <Button
              variant={viewMode === 'grouped' ? 'default' : 'ghost'}
              size="sm"
              onClick={() => setViewMode('grouped')}
              className={viewMode === 'grouped' ? 'bg-blue-600' : ''}
            >
              <Filter className="w-4 h-4" />
            </Button>
          </div>
        </div>
      )}

      {/* Loading State */}
      {isLoading && (
        <div className="text-center py-12">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-400 mx-auto"></div>
          <p className="text-gray-400 mt-4">Loading saved articles...</p>
        </div>
      )}

      {/* Empty State */}
      {!isLoading && savedArticles.length === 0 && (
        <div className="text-center py-12">
          <Bookmark className="w-16 h-16 text-gray-500 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-white mb-2">No Saved Articles</h3>
          <p className="text-gray-400 mb-6">
            {selectedCategoryId 
              ? 'No articles found in the selected category.' 
              : 'You haven\'t saved any articles yet. Browse the Document Repository and click the bookmark icon to save articles.'
            }
          </p>
          {!selectedCategoryId && onNavigateToRepository && (
            <Button 
              onClick={onNavigateToRepository}
              className="bg-blue-600 hover:bg-blue-700 text-white"
            >
              <Search className="w-4 h-4 mr-2" />
              Browse Documents
            </Button>
          )}
          {selectedCategoryId && (
            <Button 
              onClick={() => setSelectedCategoryId(null)}
              variant="outline"
              className="bg-gray-800 border-gray-600"
            >
              Show All Articles
            </Button>
          )}
        </div>
      )}

      {/* No Search Results */}
      {!isLoading && savedArticles.length > 0 && filteredArticles.length === 0 && searchQuery && (
        <div className="text-center py-12">
          <Search className="w-16 h-16 text-gray-500 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-white mb-2">No Results Found</h3>
          <p className="text-gray-400 mb-6">
            No articles match your search for "{searchQuery}"
          </p>
          <Button 
            onClick={() => setSearchQuery('')}
            variant="outline"
            className="bg-gray-800 border-gray-600"
          >
            Clear Search
          </Button>
        </div>
      )}

      {/* Articles Display */}
      {!isLoading && filteredArticles.length > 0 && (
        <div className="space-y-6">
          {viewMode === 'grouped' ? renderGroupedView() : renderArticleGrid(filteredArticles)}
        </div>
      )}
    </div>
  );
};
