

import React, { useState } from 'react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import {
  Search,
  Plus,
  Eye,
  Edit,
  Trash,
  Zap,
  Users,
  Filter,
  ChevronUp,
  ChevronDown,
  ChevronsUpDown,
  Shield,
  History,
  Trash2
} from 'lucide-react';
import { toast } from 'sonner';
import brain from 'brain';
import { CustomerProfile } from 'brain/data-contracts';

interface CustomerListProps {
  customers: CustomerProfile[];
  setCustomers: React.Dispatch<React.SetStateAction<CustomerProfile[]>>;
  searchQuery: string;
  setSearchQuery: React.Dispatch<React.SetStateAction<string>>;
  selectedCustomerIds: number[];
  setSelectedCustomerIds: React.Dispatch<React.SetStateAction<number[]>>;
  sortField: string;
  setSortField: React.Dispatch<React.SetStateAction<string>>;
  sortDirection: 'asc' | 'desc';
  setSortDirection: React.Dispatch<React.SetStateAction<'asc' | 'desc'>>;
  screeningThreshold: number;
  setScreeningThreshold: React.Dispatch<React.SetStateAction<number>>;
  onAddCustomer: () => void;
  onEditCustomer: (customer: CustomerProfile) => void;
  onViewHistory: (customer: CustomerProfile) => void;
  onScreenCustomer: (customerId: number) => void;
  onDeleteCustomer: (customerId: number) => void;
  batchScreening: (customerIds: number[]) => void;
  loading: boolean;
  isMobile?: boolean;
}

export default function CustomerList({
  customers,
  setCustomers,
  searchQuery,
  setSearchQuery,
  selectedCustomerIds,
  setSelectedCustomerIds,
  sortField,
  setSortField,
  sortDirection,
  setSortDirection,
  screeningThreshold,
  setScreeningThreshold,
  onAddCustomer,
  onEditCustomer,
  onViewHistory,
  onScreenCustomer,
  onDeleteCustomer,
  batchScreening,
  loading,
  isMobile = false
}: CustomerListProps) {
  const [riskFilter, setRiskFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [showFilters, setShowFilters] = useState(!isMobile); // Hide filters by default on mobile

  // Filter customers based on search and filters
  const filteredCustomers = customers.filter(customer => {
    const matchesSearch = !searchQuery || 
      customer.customer_name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      customer.email?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      customer.country?.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesRisk = riskFilter === 'all' || customer.risk_category === riskFilter;
    const matchesStatus = statusFilter === 'all' || customer.status === statusFilter;
    
    return matchesSearch && matchesRisk && matchesStatus;
  });

  // Sort customers
  const sortedCustomers = [...filteredCustomers].sort((a, b) => {
    if (!sortField) return 0;
    
    let aValue = a[sortField as keyof CustomerProfile] || '';
    let bValue = b[sortField as keyof CustomerProfile] || '';
    
    if (typeof aValue === 'string') aValue = aValue.toLowerCase();
    if (typeof bValue === 'string') bValue = bValue.toLowerCase();
    
    if (sortDirection === 'asc') {
      return aValue < bValue ? -1 : aValue > bValue ? 1 : 0;
    } else {
      return aValue > bValue ? -1 : aValue < bValue ? 1 : 0;
    }
  });

  const handleSort = (field: string) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  const getSortIcon = (field: string) => {
    if (sortField !== field) return <ChevronsUpDown className="w-4 h-4" />;
    return sortDirection === 'asc' ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />;
  };

  const handleSelectAll = (checked: boolean) => {
    if (checked) {
      setSelectedCustomerIds(sortedCustomers.map(c => c.id!).filter(Boolean));
    } else {
      setSelectedCustomerIds([]);
    }
  };

  const handleSelectCustomer = (customerId: number, checked: boolean) => {
    if (checked) {
      setSelectedCustomerIds(prev => [...prev, customerId]);
    } else {
      setSelectedCustomerIds(prev => prev.filter(id => id !== customerId));
    }
  };

  const getRiskBadgeColor = (risk: string) => {
    switch (risk?.toLowerCase()) {
      case 'high': return 'bg-red-500/20 text-red-400 border-red-500/30';
      case 'medium': return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30';
      case 'low': return 'bg-green-500/20 text-green-400 border-green-500/30';
      default: return 'bg-gray-500/20 text-gray-400 border-gray-500/30';
    }
  };

  const getStatusBadgeColor = (status: string) => {
    switch (status?.toLowerCase()) {
      case 'active': return 'bg-green-500/20 text-green-400 border-green-500/30';
      case 'pending': return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30';
      case 'suspended': return 'bg-red-500/20 text-red-400 border-red-500/30';
      case 'flagged': return 'bg-orange-500/20 text-orange-400 border-orange-500/30';
      default: return 'bg-gray-500/20 text-gray-400 border-gray-500/30';
    }
  };

  return (
    <Card className="bg-gray-900/50 border-gray-700 backdrop-blur-sm">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="text-white flex items-center">
              <Users className="w-5 h-5 mr-2 text-blue-400" />
              {isMobile ? 'Customers' : 'Customer Management'}
            </CardTitle>
            {!isMobile && (
              <CardDescription className="text-gray-400">
                Manage customer profiles and screening status
              </CardDescription>
            )}
          </div>
          <div className="flex items-center space-x-2">
            <Button
              onClick={onAddCustomer}
              className="bg-blue-600 hover:bg-blue-700 text-white touch-manipulation"
              size={isMobile ? "sm" : "default"}
            >
              <Plus className="w-4 h-4 mr-1" />
              {isMobile ? 'Add' : 'Add Customer'}
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Search and Mobile Filter Toggle */}
        <div className="space-y-3">
          <div className="relative">
            <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
            <Input
              placeholder="Search customers..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 bg-gray-800/50 border-gray-600 text-white placeholder-gray-400 touch-manipulation"
            />
          </div>
          
          {/* Mobile Filter Toggle */}
          {isMobile && (
            <Button
              variant="outline"
              onClick={() => setShowFilters(!showFilters)}
              className="w-full bg-gray-800/50 border-gray-600 text-gray-300 hover:bg-gray-700 touch-manipulation"
            >
              <Filter className="w-4 h-4 mr-2" />
              {showFilters ? 'Hide Filters' : 'Show Filters'}
            </Button>
          )}
        </div>

        {/* Filters - Responsive Layout */}
        {(showFilters || !isMobile) && (
          <div className={`flex gap-2 ${isMobile ? 'flex-col' : 'flex-row'}`}>
            <Select value={riskFilter} onValueChange={setRiskFilter}>
              <SelectTrigger className={`bg-gray-800/50 border-gray-600 text-white touch-manipulation ${isMobile ? 'w-full' : 'w-40'}`}>
                <Filter className="w-4 h-4 mr-2" />
                <SelectValue placeholder="Risk Level" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Risk Levels</SelectItem>
                <SelectItem value="low">Low Risk</SelectItem>
                <SelectItem value="standard">Standard Risk</SelectItem>
                <SelectItem value="high">High Risk</SelectItem>
              </SelectContent>
            </Select>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className={`bg-gray-800/50 border-gray-600 text-white touch-manipulation ${isMobile ? 'w-full' : 'w-40'}`}>
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Statuses</SelectItem>
                <SelectItem value="active">Active</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="suspended">Suspended</SelectItem>
                <SelectItem value="flagged">Flagged</SelectItem>
              </SelectContent>
            </Select>
          </div>
        )}

        {/* Batch Actions */}
        {selectedCustomerIds.length > 0 && (
          <div className={`bg-blue-600/20 border border-blue-500/30 rounded-lg p-3 ${isMobile ? 'text-sm' : ''}`}>
            <div className={`flex items-center justify-between ${isMobile ? 'flex-col gap-2' : ''}`}>
              <span className="text-blue-300">
                {selectedCustomerIds.length} customer{selectedCustomerIds.length !== 1 ? 's' : ''} selected
              </span>
              <div className={`flex gap-2 ${isMobile ? 'w-full' : ''}`}>
                <Button
                  onClick={() => batchScreening(selectedCustomerIds)}
                  size={isMobile ? "sm" : "default"}
                  className={`bg-blue-600 hover:bg-blue-700 text-white touch-manipulation ${isMobile ? 'flex-1' : ''}`}
                >
                  <Shield className="w-4 h-4 mr-1" />
                  Screen
                </Button>
                <Button
                  onClick={() => setSelectedCustomerIds([])}
                  variant="outline"
                  size={isMobile ? "sm" : "default"}
                  className={`border-gray-600 text-gray-300 hover:bg-gray-700 touch-manipulation ${isMobile ? 'flex-1' : ''}`}
                >
                  Clear
                </Button>
              </div>
            </div>
          </div>
        )}

        {/* Customer List - Mobile Card View vs Desktop Table */}
        {loading ? (
          <div className="flex items-center justify-center py-8">
            <div className="text-gray-400">Loading customers...</div>
          </div>
        ) : sortedCustomers.length === 0 ? (
          <div className="text-center py-8">
            <Users className="w-12 h-12 mx-auto text-gray-600 mb-4" />
            <h3 className="text-lg font-medium text-gray-400 mb-2">No customers found</h3>
            <p className="text-gray-500 mb-4">Get started by adding your first customer</p>
            <Button onClick={onAddCustomer} className="bg-blue-600 hover:bg-blue-700 text-white touch-manipulation">
              <Plus className="w-4 h-4 mr-2" />
              Add Customer
            </Button>
          </div>
        ) : isMobile ? (
          // Mobile Card View
          <div className="space-y-3">
            {sortedCustomers.map((customer) => (
              <Card key={customer.id} className="bg-gray-800/30 border-gray-700">
                <CardContent className="p-4">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-start space-x-3 flex-1">
                      <input
                        type="checkbox"
                        checked={selectedCustomerIds.includes(customer.id!)}
                        onChange={(e) => handleSelectCustomer(customer.id!, e.target.checked)}
                        className="mt-1 touch-manipulation"
                      />
                      <div className="flex-1 min-w-0">
                        <h4 className="font-medium text-white truncate">{customer.customer_name}</h4>
                        <p className="text-sm text-gray-400 truncate">{customer.email}</p>
                        <div className="flex items-center gap-2 mt-2">
                          <Badge className={`text-xs ${getRiskBadgeColor(customer.risk_category || 'standard')}`}>
                            {customer.risk_category || 'Standard'}
                          </Badge>
                          <Badge className={`text-xs ${getStatusBadgeColor(customer.status || 'active')}`}>
                            {customer.status || 'Active'}
                          </Badge>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="text-xs text-gray-500 mb-3">
                    <div>{customer.country}</div>
                    <div>Created: {customer.created_at ? new Date(customer.created_at).toLocaleDateString() : 'N/A'}</div>
                  </div>
                  
                  <div className="flex gap-1 overflow-x-auto">
                    <Button
                      onClick={() => onScreenCustomer(customer.id!)}
                      size="sm"
                      className="bg-blue-600 hover:bg-blue-700 text-white touch-manipulation min-w-0 flex-shrink-0"
                    >
                      <Shield className="w-3 h-3" />
                    </Button>
                    <Button
                      onClick={() => onEditCustomer(customer)}
                      variant="outline"
                      size="sm"
                      className="border-gray-600 text-gray-300 hover:bg-gray-700 touch-manipulation min-w-0 flex-shrink-0"
                    >
                      <Edit className="w-3 h-3" />
                    </Button>
                    <Button
                      onClick={() => onViewHistory(customer)}
                      variant="outline"
                      size="sm"
                      className="border-gray-600 text-gray-300 hover:bg-gray-700 touch-manipulation min-w-0 flex-shrink-0"
                    >
                      <History className="w-3 h-3" />
                    </Button>
                    <Button
                      onClick={() => onDeleteCustomer(customer.id!)}
                      variant="outline"
                      size="sm"
                      className="border-red-600 text-red-400 hover:bg-red-600/20 touch-manipulation min-w-0 flex-shrink-0"
                    >
                      <Trash2 className="w-3 h-3" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          // Desktop Table View
          <div className="border border-gray-700 rounded-lg overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow className="bg-gray-800/50 border-gray-700">
                  <TableHead className="w-12">
                    <Checkbox
                      checked={selectedCustomerIds.length === sortedCustomers.length && sortedCustomers.length > 0}
                      onCheckedChange={handleSelectAll}
                      className="border-gray-500"
                    />
                  </TableHead>
                  <TableHead className="text-gray-300">
                    <Button
                      variant="ghost"
                      onClick={() => handleSort('customer_name')}
                      className="h-auto p-0 font-medium text-gray-300 hover:text-white"
                    >
                      Name {getSortIcon('customer_name')}
                    </Button>
                  </TableHead>
                  <TableHead className="text-gray-300">Type</TableHead>
                  <TableHead className="text-gray-300">
                    <Button
                      variant="ghost"
                      onClick={() => handleSort('country')}
                      className="h-auto p-0 font-medium text-gray-300 hover:text-white"
                    >
                      Country {getSortIcon('country')}
                    </Button>
                  </TableHead>
                  <TableHead className="text-gray-300">Risk Level</TableHead>
                  <TableHead className="text-gray-300">Status</TableHead>
                  <TableHead className="text-gray-300">
                    <Button
                      variant="ghost"
                      onClick={() => handleSort('last_screened')}
                      className="h-auto p-0 font-medium text-gray-300 hover:text-white"
                    >
                      Last Screened {getSortIcon('last_screened')}
                    </Button>
                  </TableHead>
                  <TableHead className="text-gray-300 text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {sortedCustomers.map((customer) => (
                  <TableRow key={customer.id} className="border-gray-700 hover:bg-gray-800/30">
                    <TableCell>
                      <Checkbox
                        checked={selectedCustomerIds.includes(customer.id!)}
                        onCheckedChange={(checked) => handleSelectCustomer(customer.id!, checked as boolean)}
                        className="border-gray-500"
                      />
                    </TableCell>
                    <TableCell className="font-medium text-white">
                      <div>
                        <div>{customer.customer_name}</div>
                        {customer.email && (
                          <div className="text-xs text-gray-400">{customer.email}</div>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge className="bg-gray-500/20 text-gray-300 border-gray-500/30">
                        {customer.customer_type || 'Individual'}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-gray-300">
                      {customer.country || 'N/A'}
                    </TableCell>
                    <TableCell>
                      <Badge className={getRiskBadgeColor(customer.risk_category || 'standard')}>
                        {(customer.risk_category || 'standard').charAt(0).toUpperCase() + (customer.risk_category || 'standard').slice(1)}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Badge className={getStatusBadgeColor(customer.status || 'active')}>
                        {(customer.status || 'active').charAt(0).toUpperCase() + (customer.status || 'active').slice(1)}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-gray-300">
                      {customer.last_screened ? new Date(customer.last_screened).toLocaleDateString() : 'Never'}
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end space-x-1">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => onScreenCustomer(customer.id!)}
                          className="h-8 w-8 p-0 text-blue-400 hover:text-blue-300 hover:bg-blue-500/20"
                          title="Screen Customer"
                        >
                          <Zap className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => onViewHistory(customer)}
                          className="h-8 w-8 p-0 text-green-400 hover:text-green-300 hover:bg-green-500/20"
                          title="View History"
                        >
                          <Eye className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => onEditCustomer(customer)}
                          className="h-8 w-8 p-0 text-yellow-400 hover:text-yellow-300 hover:bg-yellow-500/20"
                          title="Edit Customer"
                        >
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => onDeleteCustomer(customer.id!)}
                          className="h-8 w-8 p-0 text-red-400 hover:text-red-300 hover:bg-red-500/20"
                          title="Delete Customer"
                        >
                          <Trash className="w-4 h-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
