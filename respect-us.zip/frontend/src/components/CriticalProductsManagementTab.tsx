

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Skeleton } from '@/components/ui/skeleton';
import { 
  Upload, 
  Download, 
  Database, 
  Plus, 
  Edit, 
  Trash2, 
  AlertTriangle, 
  CheckCircle, 
  FileText, 
  Search,
  Filter,
  BarChart3,
  RefreshCw,
  Settings
} from 'lucide-react';
import { toast } from 'sonner';
import brain from 'brain';
import type { CriticalProductSearchResult } from 'types';

export interface Props {
  loading?: boolean;
}

interface ImportStats {
  total_records: number;
  successful_imports: number;
  failed_imports: number;
  duplicate_records: number;
  validation_errors: string[];
}

interface DatabaseStats {
  total_products: number;
  total_restrictions: number;
  total_jurisdictions: number;
  total_categories: number;
  last_updated: string;
}

export function CriticalProductsManagementTab({ loading = false }: Props) {
  const [activeSubTab, setActiveSubTab] = useState('overview');
  const [products, setProducts] = useState<CriticalProductSearchResult[]>([]);
  const [importFile, setImportFile] = useState<File | null>(null);
  const [importing, setImporting] = useState(false);
  const [importStats, setImportStats] = useState<ImportStats | null>(null);
  const [dbStats, setDbStats] = useState<DatabaseStats | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedProduct, setSelectedProduct] = useState<CriticalProductSearchResult | null>(null);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [dataLoading, setDataLoading] = useState(true);
  
  // New product form data
  const [newProductData, setNewProductData] = useState({
    hs_code: '',
    cn_code: '',
    description: '',
    category: '',
    subcategory: '',
    risk_level: 'medium',
    restrictions: [] as any[]
  });

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    try {
      setDataLoading(true);
      
      // Load database statistics
      const statsResponse = await brain.get_critical_products_stats();
      if (statsResponse.ok) {
        const stats = await statsResponse.json();
        setDbStats({
          total_products: stats.total_trade_codes || 0,
          total_restrictions: stats.total_restrictions || 0,
          total_jurisdictions: stats.total_jurisdictions || 0,
          total_categories: stats.total_categories || 0,
          last_updated: new Date().toISOString()
        });
      }
      
      // Load recent products
      await loadProducts();
    } catch (error) {
      console.error('Error loading dashboard data:', error);
      toast.error('Failed to load dashboard data');
    } finally {
      setDataLoading(false);
    }
  };

  const loadProducts = async (query = '') => {
    try {
      const response = await brain.search_critical_products({
        query: query || undefined,
        limit: 20,
        offset: 0
      });
      
      if (response.ok) {
        const results = await response.json();
        setProducts(results);
      }
    } catch (error) {
      console.error('Error loading products:', error);
    }
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setImportFile(file);
    }
  };

  const handleImport = async () => {
    console.log('🔥 handleImport function called');
    console.log('📄 importFile state:', importFile);
    
    if (!importFile) {
      console.log('❌ No import file selected');
      toast.error('Please select a file to import');
      return;
    }

    console.log('✅ File validation passed, starting import...');
    
    try {
      console.log('⏳ Setting importing state to true');
      setImporting(true);
      
      console.log('🌐 Calling brain.import_critical_products with file:', importFile.name);
      // Use the brain client instead of fetch
      const response = await brain.import_critical_products({ file: importFile });
      
      console.log('📡 Received response:', response);
      console.log('📊 Response status:', response.status);
      console.log('✅ Response ok:', response.ok);
      
      if (response.ok) {
        const result = await response.json();
        console.log('📈 Import result:', result);
        toast.success(`Successfully imported ${result.imported_count || 0} critical products`);
        setImportFile(null);
        loadProducts(); // Refresh the products list
      } else {
        console.log('❌ Response not ok, parsing error...');
        const errorData = await response.json().catch(() => null);
        console.log('🚨 Error data:', errorData);
        toast.error(`Import failed: ${errorData?.detail || 'Unknown error'}`);
      }
    } catch (error) {
      console.error('💥 Import error:', error);
      console.error('📋 Error details:', {
        name: error.name,
        message: error.message,
        stack: error.stack
      });
      toast.error('Failed to import file. Please check the format and try again.');
    } finally {
      console.log('🏁 Setting importing state to false');
      setImporting(false);
    }
  };

  const handleAddProduct = async () => {
    try {
      const response = await brain.create_critical_product(newProductData);
      
      if (response.ok) {
        toast.success('Product added successfully');
        setShowAddDialog(false);
        setNewProductData({
          hs_code: '',
          cn_code: '',
          description: '',
          category: '',
          subcategory: '',
          risk_level: 'medium',
          restrictions: []
        });
        await loadProducts();
      }
    } catch (error) {
      console.error('Error adding product:', error);
      toast.error('Failed to add product');
    }
  };

  const handleDeleteProduct = async (productId: string) => {
    try {
      const response = await brain.delete_critical_product({ productId });
      
      if (response.ok) {
        toast.success('Product deleted successfully');
        await loadProducts();
      }
    } catch (error) {
      console.error('Error deleting product:', error);
      toast.error('Failed to delete product');
    }
  };

  const exportProducts = async () => {
    try {
      const response = await brain.export_critical_products();
      
      if (response.ok) {
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `critical-products-${new Date().toISOString().split('T')[0]}.xlsx`;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        document.body.removeChild(a);
        toast.success('Export completed successfully');
      }
    } catch (error) {
      console.error('Export error:', error);
      toast.error('Failed to export products');
    }
  };

  if (loading || dataLoading) {
    return (
      <div className="space-y-6">
        <div className="bg-gray-800/30 backdrop-blur-sm border border-gray-700 rounded-lg p-6">
          <div className="animate-pulse">
            <div className="h-6 bg-gray-600 rounded w-1/4 mb-4"></div>
            <div className="h-4 bg-gray-600 rounded w-1/2 mb-6"></div>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              {[1, 2, 3, 4].map((i) => (
                <div key={i} className="h-24 bg-gray-600 rounded"></div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-white mb-2">Critical Products Management</h2>
          <p className="text-gray-400">Import, manage, and maintain the critical products database</p>
        </div>
        <div className="flex gap-2">
          <Button onClick={exportProducts} variant="outline" className="border-gray-600 text-gray-300 hover:bg-gray-700">
            <Download className="h-4 w-4 mr-2" />
            Export Data
          </Button>
          <Button onClick={() => setShowAddDialog(true)} className="bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600">
            <Plus className="h-4 w-4 mr-2" />
            Add Product
          </Button>
        </div>
      </div>

      {/* Statistics Cards */}
      {dbStats && (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="bg-gray-800/50 border-gray-700">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-2xl font-bold text-blue-400">{dbStats.total_products}</div>
                  <div className="text-sm text-gray-400">Total Products</div>
                </div>
                <Database className="h-8 w-8 text-blue-400" />
              </div>
            </CardContent>
          </Card>
          <Card className="bg-gray-800/50 border-gray-700">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-2xl font-bold text-purple-400">{dbStats.total_restrictions}</div>
                  <div className="text-sm text-gray-400">Restrictions</div>
                </div>
                <AlertTriangle className="h-8 w-8 text-purple-400" />
              </div>
            </CardContent>
          </Card>
          <Card className="bg-gray-800/50 border-gray-700">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-2xl font-bold text-green-400">{dbStats.total_jurisdictions}</div>
                  <div className="text-sm text-gray-400">Jurisdictions</div>
                </div>
                <CheckCircle className="h-8 w-8 text-green-400" />
              </div>
            </CardContent>
          </Card>
          <Card className="bg-gray-800/50 border-gray-700">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-2xl font-bold text-yellow-400">{dbStats.total_categories}</div>
                  <div className="text-sm text-gray-400">Categories</div>
                </div>
                <BarChart3 className="h-8 w-8 text-yellow-400" />
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Sub-tabs */}
      <Tabs value={activeSubTab} onValueChange={setActiveSubTab}>
        <TabsList className="bg-gray-800/50 backdrop-blur-sm">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="import">Import Data</TabsTrigger>
          <TabsTrigger value="manage">Manage Products</TabsTrigger>
          <TabsTrigger value="settings">Settings</TabsTrigger>
        </TabsList>

        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-6">
          <div className="grid gap-6">
            {/* Recent Import Stats */}
            {importStats && (
              <Card className="bg-gray-800/30 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <FileText className="h-5 w-5 text-green-400" />
                    Last Import Results
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="text-center">
                      <div className="text-2xl font-bold text-green-400">{importStats.successful_imports}</div>
                      <div className="text-sm text-gray-400">Successful</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-red-400">{importStats.failed_imports}</div>
                      <div className="text-sm text-gray-400">Failed</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-yellow-400">{importStats.duplicate_records}</div>
                      <div className="text-sm text-gray-400">Duplicates</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-blue-400">{importStats.total_records}</div>
                      <div className="text-sm text-gray-400">Total Records</div>
                    </div>
                  </div>
                  
                  {importStats.validation_errors.length > 0 && (
                    <div className="mt-4">
                      <h4 className="font-medium text-red-400 mb-2">Validation Errors:</h4>
                      <ul className="text-sm text-gray-300 space-y-1">
                        {importStats.validation_errors.slice(0, 5).map((error, index) => (
                          <li key={index}>• {error}</li>
                        ))}
                        {importStats.validation_errors.length > 5 && (
                          <li>• ... and {importStats.validation_errors.length - 5} more errors</li>
                        )}
                      </ul>
                    </div>
                  )}
                </CardContent>
              </Card>
            )}

            {/* Quick Actions */}
            <Card className="bg-gray-800/30 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white">Quick Actions</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Button 
                    onClick={() => setActiveSubTab('import')} 
                    className="h-auto p-4 bg-gradient-to-r from-blue-500/20 to-purple-500/20 border border-blue-500/30 hover:from-blue-500/30 hover:to-purple-500/30"
                  >
                    <div className="flex flex-col items-center gap-2">
                      <Upload className="h-6 w-6 text-blue-400" />
                      <span>Import Products</span>
                    </div>
                  </Button>
                  <Button 
                    onClick={() => setActiveSubTab('manage')} 
                    className="h-auto p-4 bg-gradient-to-r from-green-500/20 to-blue-500/20 border border-green-500/30 hover:from-green-500/30 hover:to-blue-500/30"
                  >
                    <div className="flex flex-col items-center gap-2">
                      <Search className="h-6 w-6 text-green-400" />
                      <span>Manage Products</span>
                    </div>
                  </Button>
                  <Button 
                    onClick={exportProducts} 
                    className="h-auto p-4 bg-gradient-to-r from-purple-500/20 to-pink-500/20 border border-purple-500/30 hover:from-purple-500/30 hover:to-pink-500/30"
                  >
                    <div className="flex flex-col items-center gap-2">
                      <Download className="h-6 w-6 text-purple-400" />
                      <span>Export Data</span>
                    </div>
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Import Data Tab */}
        <TabsContent value="import" className="space-y-6">
          <Card className="bg-gray-800/30 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Upload className="h-5 w-5 text-blue-400" />
                Import Critical Products Data
              </CardTitle>
              <CardDescription className="text-gray-300">
                Upload Excel or CSV files containing critical products data. Supported formats: HS codes, CN codes, descriptions, restrictions.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="border-2 border-dashed border-gray-600 rounded-lg p-8 text-center">
                <Upload className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <div className="space-y-2">
                  <Label htmlFor="file-upload" className="text-lg font-medium text-white cursor-pointer">
                    Choose file to upload
                  </Label>
                  <Input
                    id="file-upload"
                    type="file"
                    accept=".xlsx,.xls,.csv"
                    onChange={handleFileUpload}
                    className="hidden"
                  />
                  <p className="text-sm text-gray-400">
                    Supports Excel (.xlsx, .xls) and CSV (.csv) files
                  </p>
                </div>
              </div>
              
              {importFile && (
                <Alert>
                  <FileText className="h-4 w-4" />
                  <AlertDescription>
                    Selected file: <span className="font-medium">{importFile.name}</span> ({(importFile.size / 1024 / 1024).toFixed(2)} MB)
                  </AlertDescription>
                </Alert>
              )}
              
              <div className="flex gap-2">
                <Button 
                  onClick={handleImport} 
                  disabled={!importFile || importing}
                  className="bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600"
                >
                  {importing ? (
                    <>
                      <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                      Importing...
                    </>
                  ) : (
                    <>
                      <Upload className="h-4 w-4 mr-2" />
                      Import Data
                    </>
                  )}
                </Button>
                <Button 
                  variant="outline" 
                  onClick={() => setImportFile(null)}
                  className="border-gray-600 text-gray-300 hover:bg-gray-700"
                >
                  Clear
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Import Template */}
          <Card className="bg-gray-800/30 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white">Import Template</CardTitle>
              <CardDescription className="text-gray-300">
                Download a template to ensure your data is in the correct format.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button variant="outline" className="border-gray-600 text-gray-300 hover:bg-gray-700">
                <Download className="h-4 w-4 mr-2" />
                Download Template
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Manage Products Tab */}
        <TabsContent value="manage" className="space-y-6">
          <Card className="bg-gray-800/30 border-gray-700">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-white flex items-center gap-2">
                  <Search className="h-5 w-5 text-green-400" />
                  Product Management
                </CardTitle>
                <Button onClick={() => loadProducts(searchQuery)} variant="outline" size="sm">
                  <RefreshCw className="h-4 w-4 mr-2" />
                  Refresh
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex gap-2">
                <Input
                  placeholder="Search by HS code, description, or category..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && loadProducts(searchQuery)}
                  className="flex-1"
                />
                <Button onClick={() => loadProducts(searchQuery)}>
                  <Search className="h-4 w-4" />
                </Button>
              </div>
              
              <div className="space-y-3">
                {products.length > 0 ? (
                  products.map((product) => (
                    <div key={product.id} className="flex items-center justify-between p-4 bg-gray-700/30 rounded-lg border border-gray-600">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <Badge variant="outline" className="font-mono text-xs">
                            {product.hs_code}
                          </Badge>
                          {product.risk_level && (
                            <Badge className={`text-xs ${
                              product.risk_level === 'high' ? 'bg-red-500/20 text-red-400 border-red-500/50' :
                              product.risk_level === 'medium' ? 'bg-yellow-500/20 text-yellow-400 border-yellow-500/50' :
                              'bg-green-500/20 text-green-400 border-green-500/50'
                            }`}>
                              {product.risk_level.toUpperCase()}
                            </Badge>
                          )}
                        </div>
                        <div className="text-white font-medium mb-1">{product.description}</div>
                        <div className="text-sm text-gray-400">
                          Category: {product.category}
                          {product.subcategory && ` • ${product.subcategory}`}
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Button size="sm" variant="outline" onClick={() => {
                          setSelectedProduct(product);
                          setShowEditDialog(true);
                        }}>
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button 
                          size="sm" 
                          variant="outline" 
                          onClick={() => handleDeleteProduct(product.id)}
                          className="border-red-500/50 text-red-400 hover:bg-red-500/10"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="text-center py-8 text-gray-400">
                    No products found. Try adjusting your search criteria.
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Settings Tab */}
        <TabsContent value="settings" className="space-y-6">
          <Card className="bg-gray-800/30 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Settings className="h-5 w-5 text-purple-400" />
                Database Settings
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Alert>
                <AlertTriangle className="h-4 w-4" />
                <AlertDescription>
                  Database maintenance and configuration options will be available in future updates.
                </AlertDescription>
              </Alert>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Add Product Dialog */}
      <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
        <DialogContent className="bg-gray-800 border-gray-700">
          <DialogHeader>
            <DialogTitle className="text-white">Add New Critical Product</DialogTitle>
            <DialogDescription className="text-gray-300">
              Enter the details for the new critical product.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="text-white">HS Code</Label>
                <Input
                  value={newProductData.hs_code}
                  onChange={(e) => setNewProductData({...newProductData, hs_code: e.target.value})}
                  placeholder="e.g., 8542.31.00"
                />
              </div>
              <div>
                <Label className="text-white">CN Code</Label>
                <Input
                  value={newProductData.cn_code}
                  onChange={(e) => setNewProductData({...newProductData, cn_code: e.target.value})}
                  placeholder="e.g., 8542 31 00 90"
                />
              </div>
            </div>
            
            <div>
              <Label className="text-white">Description</Label>
              <Textarea
                value={newProductData.description}
                onChange={(e) => setNewProductData({...newProductData, description: e.target.value})}
                placeholder="Product description..."
              />
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="text-white">Category</Label>
                <Input
                  value={newProductData.category}
                  onChange={(e) => setNewProductData({...newProductData, category: e.target.value})}
                  placeholder="e.g., Electronics"
                />
              </div>
              <div>
                <Label className="text-white">Risk Level</Label>
                <Select 
                  value={newProductData.risk_level} 
                  onValueChange={(value) => setNewProductData({...newProductData, risk_level: value})}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="low">Low Risk</SelectItem>
                    <SelectItem value="medium">Medium Risk</SelectItem>
                    <SelectItem value="high">High Risk</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setShowAddDialog(false)}>
                Cancel
              </Button>
              <Button onClick={handleAddProduct} className="bg-gradient-to-r from-purple-500 to-blue-500">
                Add Product
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

export default CriticalProductsManagementTab;
