
import React, { useState, useEffect } from 'react';
import { Search, Filter, X, Plus, ChevronDown, ChevronRight, BookOpen, FileText, Calendar, Building2, Tag, Sparkles } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import brain from 'brain';
import { useUserGuardContext } from 'app/auth';

interface SearchFilter {
  field: string;
  value: string | string[];
  operator: string;
  label?: string;
}

interface SearchTerm {
  term: string;
  operator: string;
  field?: string;
}

interface SearchResult {
  id: number;
  title: string;
  content_snippet: string;
  relevance_score: number;
  document_type?: string;
  issuing_authority?: string;
  publication_date?: string;
  tags?: string[];
}

interface SectionResult {
  section_id: number;
  document_id: number;
  document_title: string;
  section_number: string;
  section_title: string;
  section_type?: string;
  level?: number;
  section_snippet: string;
  document_type?: string;
}

interface AdvancedSearchProps {
  onDocumentSelect?: (documentId: number) => void;
  className?: string;
}

const AdvancedSearch: React.FC<AdvancedSearchProps> = ({ onDocumentSelect, className }) => {
  const { user } = useUserGuardContext();
  const [query, setQuery] = useState('');
  const [filters, setFilters] = useState<SearchFilter[]>([]);
  const [searchSections, setSearchSections] = useState(false);
  const [sortBy, setSortBy] = useState('relevance');
  const [results, setResults] = useState<SearchResult[]>([]);
  const [sectionResults, setSectionResults] = useState<SectionResult[]>([]);
  const [totalCount, setTotalCount] = useState(0);
  const [loading, setLoading] = useState(false);
  const [showFilters, setShowFilters] = useState(false);
  const [searchTerms, setSearchTerms] = useState<SearchTerm[]>([]);
  const [suggestions, setSuggestions] = useState<any>({});
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [currentPage, setCurrentPage] = useState(0);
  const [hasMore, setHasMore] = useState(false);

  // Search suggestions
  const fetchSuggestions = async (searchQuery: string) => {
    if (searchQuery.length < 2) {
      setSuggestions({});
      setShowSuggestions(false);
      return;
    }

    try {
      const response = await brain.get_search_suggestions({ query: searchQuery });
      const data = await response.json();
      setSuggestions(data);
      setShowSuggestions(true);
    } catch (error) {
      console.error('Error fetching suggestions:', error);
    }
  };

  // Debounced search suggestions
  useEffect(() => {
    const timer = setTimeout(() => {
      if (query) {
        fetchSuggestions(query);
      }
    }, 300);

    return () => clearTimeout(timer);
  }, [query]);

  // Perform search
  const performSearch = async (offset: number = 0) => {
    if (!query.trim() && filters.length === 0) {
      setResults([]);
      setSectionResults([]);
      setTotalCount(0);
      return;
    }

    setLoading(true);
    try {
      const searchRequest = {
        query,
        filters: filters.map(f => ({
          field: f.field,
          value: f.value,
          operator: f.operator
        })),
        search_sections: searchSections,
        sort_by: sortBy,
        limit: 20,
        offset
      };

      const response = await brain.advanced_search_documents(searchRequest);
      const data = await response.json();

      if (offset === 0) {
        setResults(data.documents || []);
        setSectionResults(data.sections || []);
      } else {
        setResults(prev => [...prev, ...(data.documents || [])]);
        setSectionResults(prev => [...prev, ...(data.sections || [])]);
      }

      setTotalCount(data.total_count || 0);
      setHasMore(data.has_more || false);
      setSearchTerms(data.search_terms || []);
      setCurrentPage(Math.floor(offset / 20));
      setShowSuggestions(false);

    } catch (error) {
      console.error('Search error:', error);
    } finally {
      setLoading(false);
    }
  };

  // Add filter
  const addFilter = (field: string, value: string | string[], operator: string = '=', label?: string) => {
    const newFilter: SearchFilter = { field, value, operator, label };
    setFilters([...filters, newFilter]);
  };

  // Remove filter
  const removeFilter = (index: number) => {
    setFilters(filters.filter((_, i) => i !== index));
  };

  // Load more results
  const loadMore = () => {
    performSearch((currentPage + 1) * 20);
  };

  // Handle search
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setCurrentPage(0);
    performSearch(0);
  };

  // Quick filter options
  const quickFilters = [
    { field: 'document_type', value: 'regulation', operator: '=', label: 'Regulations' },
    { field: 'document_type', value: 'directive', operator: '=', label: 'Directives' },
    { field: 'document_type', value: 'decision', operator: '=', label: 'Decisions' },
    { field: 'tags', value: 'eu', operator: '=', label: 'EU Documents' },
    { field: 'tags', value: 'sanctions', operator: '=', label: 'Sanctions' },
    { field: 'tags', value: 'export-control', operator: '=', label: 'Export Control' }
  ];

  return (
    <div className={`w-full max-w-6xl mx-auto space-y-6 ${className}`}>
      {/* Search Header */}
      <Card>
        <CardHeader>
          <div className="flex items-center gap-2">
            <Sparkles className="h-5 w-5 text-blue-400" />
            <CardTitle>Advanced Knowledge Base Search</CardTitle>
          </div>
          <CardDescription>
            Search with Boolean operators (AND, OR, NOT), phrase matching with quotes, and wildcard searches with *
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Main Search */}
          <form onSubmit={handleSearch} className="space-y-4">
            <div className="relative">
              <div className="flex gap-2">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    value={query}
                    onChange={(e) => setQuery(e.target.value)}
                    placeholder='Try: "export control" AND sanctions OR embargoes NOT iran*'
                    className="pl-10 pr-4"
                  />
                  
                  {/* Search Suggestions */}
                  {showSuggestions && Object.keys(suggestions).length > 0 && (
                    <div className="absolute top-full left-0 right-0 z-10 mt-1 bg-background border rounded-md shadow-lg max-h-60 overflow-y-auto">
                      {suggestions.terms?.length > 0 && (
                        <div className="p-2">
                          <div className="text-xs font-medium text-muted-foreground mb-1">Terms</div>
                          {suggestions.terms.map((term: string, idx: number) => (
                            <button
                              key={idx}
                              type="button"
                              onClick={() => {
                                setQuery(query + ' ' + term);
                                setShowSuggestions(false);
                              }}
                              className="block w-full text-left px-2 py-1 text-sm hover:bg-muted rounded"
                            >
                              {term}
                            </button>
                          ))}
                        </div>
                      )}
                      
                      {suggestions.tags?.length > 0 && (
                        <div className="p-2 border-t">
                          <div className="text-xs font-medium text-muted-foreground mb-1">Tags</div>
                          {suggestions.tags.map((tag: string, idx: number) => (
                            <button
                              key={idx}
                              type="button"
                              onClick={() => addFilter('tags', tag, '=', `Tag: ${tag}`)}
                              className="block w-full text-left px-2 py-1 text-sm hover:bg-muted rounded"
                            >
                              <Tag className="inline h-3 w-3 mr-1" />
                              {tag}
                            </button>
                          ))}
                        </div>
                      )}
                    </div>
                  )}
                </div>
                
                <Button type="button" variant="outline" onClick={() => setShowFilters(!showFilters)}>
                  <Filter className="h-4 w-4 mr-2" />
                  Filters {filters.length > 0 && `(${filters.length})`}
                </Button>
                
                <Button type="submit" disabled={loading}>
                  {loading ? 'Searching...' : 'Search'}
                </Button>
              </div>
            </div>

            {/* Search Options */}
            <div className="flex items-center gap-4 text-sm">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="search-sections"
                  checked={searchSections}
                  onCheckedChange={setSearchSections}
                />
                <Label htmlFor="search-sections">Search within document sections</Label>
              </div>
              
              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger className="w-40">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="relevance">Relevance</SelectItem>
                  <SelectItem value="date">Date</SelectItem>
                  <SelectItem value="title">Title</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </form>

          {/* Quick Filters */}
          {!showFilters && (
            <div className="flex flex-wrap gap-2">
              <span className="text-sm text-muted-foreground">Quick filters:</span>
              {quickFilters.map((filter, idx) => (
                <Button
                  key={idx}
                  variant="outline"
                  size="sm"
                  onClick={() => addFilter(filter.field, filter.value, filter.operator, filter.label)}
                >
                  <Plus className="h-3 w-3 mr-1" />
                  {filter.label}
                </Button>
              ))}
            </div>
          )}

          {/* Advanced Filters */}
          <Collapsible open={showFilters} onOpenChange={setShowFilters}>
            <CollapsibleContent className="space-y-4">
              <Separator />
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <Label className="text-sm font-medium">Document Type</Label>
                  <Select onValueChange={(value) => addFilter('document_type', value, '=', `Type: ${value}`)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="regulation">Regulation</SelectItem>
                      <SelectItem value="directive">Directive</SelectItem>
                      <SelectItem value="decision">Decision</SelectItem>
                      <SelectItem value="recommendation">Recommendation</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <Label className="text-sm font-medium">Issuing Authority</Label>
                  <Select onValueChange={(value) => addFilter('issuing_authority', value, '=', `Authority: ${value}`)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select authority" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="EU Council">EU Council</SelectItem>
                      <SelectItem value="European Commission">European Commission</SelectItem>
                      <SelectItem value="European Parliament">European Parliament</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <Label className="text-sm font-medium">Legal Status</Label>
                  <Select onValueChange={(value) => addFilter('legal_status', value, '=', `Status: ${value}`)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="in-force">In Force</SelectItem>
                      <SelectItem value="draft">Draft</SelectItem>
                      <SelectItem value="repealed">Repealed</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CollapsibleContent>
          </Collapsible>

          {/* Active Filters */}
          {filters.length > 0 && (
            <div className="space-y-2">
              <div className="text-sm font-medium">Active Filters:</div>
              <div className="flex flex-wrap gap-2">
                {filters.map((filter, idx) => (
                  <Badge key={idx} variant="secondary" className="flex items-center gap-1">
                    {filter.label || `${filter.field}: ${filter.value}`}
                    <button
                      onClick={() => removeFilter(idx)}
                      className="ml-1 hover:bg-muted rounded-full p-0.5"
                    >
                      <X className="h-3 w-3" />
                    </button>
                  </Badge>
                ))}
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setFilters([])}
                  className="h-6 px-2 text-xs"
                >
                  Clear all
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Search Results */}
      {(results.length > 0 || sectionResults.length > 0) && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span>Search Results ({totalCount})</span>
              {searchTerms.length > 0 && (
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <span>Terms:</span>
                  {searchTerms.map((term, idx) => (
                    <Badge key={idx} variant="outline">
                      {term.operator} {term.term}
                    </Badge>
                  ))}
                </div>
              )}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="documents" className="w-full">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="documents" className="flex items-center gap-2">
                  <FileText className="h-4 w-4" />
                  Documents ({results.length})
                </TabsTrigger>
                <TabsTrigger value="sections" className="flex items-center gap-2">
                  <BookOpen className="h-4 w-4" />
                  Sections ({sectionResults.length})
                </TabsTrigger>
              </TabsList>
              
              <TabsContent value="documents" className="space-y-4">
                {results.map((result) => (
                  <Card key={result.id} className="hover:shadow-md transition-shadow cursor-pointer"
                        onClick={() => onDocumentSelect?.(result.id)}>
                    <CardContent className="pt-4">
                      <div className="space-y-2">
                        <div className="flex items-start justify-between">
                          <h3 className="font-medium text-lg leading-tight">{result.title}</h3>
                          <div className="flex items-center gap-2 text-xs text-muted-foreground ml-4">
                            {result.relevance_score && (
                              <Badge variant="outline">Score: {result.relevance_score.toFixed(2)}</Badge>
                            )}
                            {result.document_type && (
                              <Badge variant="secondary">{result.document_type}</Badge>
                            )}
                          </div>
                        </div>
                        
                        {result.content_snippet && (
                          <p className="text-sm text-muted-foreground line-clamp-3">
                            {result.content_snippet}
                          </p>
                        )}
                        
                        <div className="flex items-center gap-4 text-xs text-muted-foreground">
                          {result.issuing_authority && (
                            <div className="flex items-center gap-1">
                              <Building2 className="h-3 w-3" />
                              {result.issuing_authority}
                            </div>
                          )}
                          {result.publication_date && (
                            <div className="flex items-center gap-1">
                              <Calendar className="h-3 w-3" />
                              {new Date(result.publication_date).toLocaleDateString()}
                            </div>
                          )}
                          {result.tags && result.tags.length > 0 && (
                            <div className="flex items-center gap-1">
                              <Tag className="h-3 w-3" />
                              {result.tags.slice(0, 3).join(', ')}
                              {result.tags.length > 3 && '...'}
                            </div>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </TabsContent>
              
              <TabsContent value="sections" className="space-y-4">
                {sectionResults.map((section) => (
                  <Card key={`${section.document_id}-${section.section_id}`} 
                        className="hover:shadow-md transition-shadow cursor-pointer"
                        onClick={() => onDocumentSelect?.(section.document_id)}>
                    <CardContent className="pt-4">
                      <div className="space-y-2">
                        <div className="flex items-start justify-between">
                          <div className="space-y-1">
                            <h3 className="font-medium">{section.section_title}</h3>
                            <p className="text-sm text-muted-foreground">{section.document_title}</p>
                          </div>
                          <div className="flex items-center gap-2 text-xs text-muted-foreground ml-4">
                            {section.section_type && (
                              <Badge variant="outline">{section.section_type}</Badge>
                            )}
                            {section.section_number && (
                              <Badge variant="secondary">§ {section.section_number}</Badge>
                            )}
                          </div>
                        </div>
                        
                        {section.section_snippet && (
                          <p className="text-sm text-muted-foreground line-clamp-3">
                            {section.section_snippet}
                          </p>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </TabsContent>
            </Tabs>
            
            {/* Load More */}
            {hasMore && (
              <div className="text-center pt-4">
                <Button onClick={loadMore} disabled={loading} variant="outline">
                  {loading ? 'Loading...' : 'Load More'}
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Search Help */}
      {query === '' && results.length === 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Search className="h-5 w-5" />
              Search Help
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
              <div>
                <h4 className="font-medium mb-2">Boolean Operators</h4>
                <ul className="space-y-1 text-muted-foreground">
                  <li><code>export AND control</code> - Both terms must be present</li>
                  <li><code>sanctions OR embargoes</code> - Either term can be present</li>
                  <li><code>regulation NOT iran</code> - First term without second</li>
                </ul>
              </div>
              
              <div>
                <h4 className="font-medium mb-2">Special Searches</h4>
                <ul className="space-y-1 text-muted-foreground">
                  <li><code>"exact phrase"</code> - Search for exact phrase</li>
                  <li><code>export*</code> - Wildcard search (export, exports, etc.)</li>
                  <li><code>title:sanctions</code> - Search only in document titles</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export { AdvancedSearch };
