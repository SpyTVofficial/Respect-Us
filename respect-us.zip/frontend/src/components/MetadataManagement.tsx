import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import {
  Plus,
  Edit,
  Trash2,
  Globe,
  Tag,
  FileType,
  BookOpen,
  Target,
  Search,
  Filter,
  Download,
  Upload,
  ArrowUpDown,
  Save,
  X,
  GripVertical,
  Copy
} from 'lucide-react';
import { toast } from 'sonner';
import brain from 'brain';
import type {
  MetadataOptionResponse,
  MetadataOptionRequest,
  MetadataOptionUpdate,
  ClassificationNote,
  ClassificationOutcome,
  ClassificationOutcomeCreate,
  CreateNoteRequest
} from '../brain/data-contracts';

interface MetadataManagementProps {
  onRefresh?: () => void;
}

type CategoryType = 'jurisdiction' | 'type' | 'subject' | 'notes' | 'outcomes';

export default function MetadataManagement({ onRefresh }: MetadataManagementProps) {
  const [activeCategory, setActiveCategory] = useState<CategoryType>('jurisdiction');
  const [loading, setLoading] = useState(true);

  // Document metadata states
  const [jurisdictions, setJurisdictions] = useState<MetadataOptionResponse[]>([]);
  const [types, setTypes] = useState<MetadataOptionResponse[]>([]);
  const [subjects, setSubjects] = useState<MetadataOptionResponse[]>([]);

  // Classification notes states
  const [classificationNotes, setClassificationNotes] = useState<ClassificationNote[]>([]);
  const [showCreateNoteDialog, setShowCreateNoteDialog] = useState(false);
  const [showEditNoteDialog, setShowEditNoteDialog] = useState(false);
  const [selectedNote, setSelectedNote] = useState<ClassificationNote | null>(null);
  const [newNoteData, setNewNoteData] = useState({
    note_key: '',
    title: '',
    content: '',
    tree_id: null as string | null,
    module_type: 'product_classification'
  });

  // Classification outcomes states
  const [classificationOutcomes, setClassificationOutcomes] = useState<ClassificationOutcome[]>([]);
  const [showCreateOutcomeDialog, setShowCreateOutcomeDialog] = useState(false);
  const [showEditOutcomeDialog, setShowEditOutcomeDialog] = useState(false);
  const [selectedOutcome, setSelectedOutcome] = useState<ClassificationOutcome | null>(null);
  const [newOutcomeData, setNewOutcomeData] = useState({
    tree_id: null as string | null,
    outcome_code: '',
    outcome_title: '',
    description: '',
    regulatory_basis: '',
    outcome_text: '',
    license_required: false,
    prohibition_applies: false,
    additional_requirements: ''
  });

  // Dialog states for document metadata
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [selectedOption, setSelectedOption] = useState<MetadataOptionResponse | null>(null);

  // Form data for document metadata
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    is_active: true
  });

  // Search and filter states
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');

  useEffect(() => {
    loadData();
  }, [activeCategory]);

  const loadData = async () => {
    setLoading(true);
    try {
      switch (activeCategory) {
        case 'jurisdiction':
        case 'type':
        case 'subject':
          await loadDocumentMetadata();
          break;
        case 'notes':
          await loadClassificationNotes();
          break;
        case 'outcomes':
          await loadClassificationOutcomes();
          break;
      }
    } catch (error) {
      console.error('Error loading data:', error);
      toast.error('Failed to load data');
    } finally {
      setLoading(false);
    }
  };

  const loadDocumentMetadata = async () => {
    try {
      const [jurisdictionsRes, typesRes, subjectsRes] = await Promise.all([
        brain.get_metadata_options({ category: 'jurisdiction' }),
        brain.get_metadata_options({ category: 'type' }),
        brain.get_metadata_options({ category: 'subject' })
      ]);

      if (jurisdictionsRes.ok) {
        const data = await jurisdictionsRes.json();
        setJurisdictions(Array.isArray(data) ? data : []);
      }

      if (typesRes.ok) {
        const data = await typesRes.json();
        setTypes(Array.isArray(data) ? data : []);
      }

      if (subjectsRes.ok) {
        const data = await subjectsRes.json();
        setSubjects(Array.isArray(data) ? data : []);
      }
    } catch (error) {
      console.error('Error loading document metadata:', error);
    }
  };

  const loadClassificationNotes = async () => {
    try {
      const response = await brain.list_classification_notes({});
      if (response.ok) {
        const data = await response.json();
        setClassificationNotes(Array.isArray(data) ? data : []);
      }
    } catch (error) {
      console.error('Error loading classification notes:', error);
    }
  };

  const loadClassificationOutcomes = async () => {
    try {
      const response = await brain.list_all_classification_outcomes();
      if (response.ok) {
        const data = await response.json();
        setClassificationOutcomes(Array.isArray(data) ? data : []);
      }
    } catch (error) {
      console.error('Error loading classification outcomes:', error);
    }
  };

  // Document metadata handlers
  const handleCreateOption = async () => {
    try {
      const response = await brain.create_metadata_option({
        category: activeCategory,
        ...formData
      });

      if (response.ok) {
        toast.success(`${getCategoryLabel(activeCategory)} created successfully`);
        setShowCreateDialog(false);
        resetForm();
        await loadDocumentMetadata();
        onRefresh?.();
      } else {
        toast.error(`Failed to create ${getCategoryLabel(activeCategory).toLowerCase()}`);
      }
    } catch (error) {
      console.error('Error creating option:', error);
      toast.error('Failed to create option');
    }
  };

  const handleUpdateOption = async () => {
    if (!selectedOption) return;

    try {
      const response = await brain.update_metadata_option(
        { optionId: selectedOption.id },
        formData
      );

      if (response.ok) {
        toast.success(`${getCategoryLabel(activeCategory)} updated successfully`);
        setShowEditDialog(false);
        resetForm();
        await loadDocumentMetadata();
        onRefresh?.();
      } else {
        toast.error(`Failed to update ${getCategoryLabel(activeCategory).toLowerCase()}`);
      }
    } catch (error) {
      console.error('Error updating option:', error);
      toast.error('Failed to update option');
    }
  };

  const handleDeleteOption = async (optionId: number) => {
    try {
      const response = await brain.delete_metadata_option({ optionId });

      if (response.ok) {
        toast.success(`${getCategoryLabel(activeCategory)} deleted successfully`);
        await loadDocumentMetadata();
        onRefresh?.();
      } else {
        toast.error(`Failed to delete ${getCategoryLabel(activeCategory).toLowerCase()}`);
      }
    } catch (error) {
      console.error('Error deleting option:', error);
      toast.error('Failed to delete option');
    }
  };

  // Classification notes handlers
  const handleCreateNote = async () => {
    try {
      const response = await brain.create_classification_note(newNoteData as CreateNoteRequest);

      if (response.ok) {
        toast.success('Classification note created successfully');
        setShowCreateNoteDialog(false);
        resetNoteForm();
        await loadClassificationNotes();
      } else {
        toast.error('Failed to create classification note');
      }
    } catch (error) {
      console.error('Error creating note:', error);
      toast.error('Failed to create note');
    }
  };

  const handleUpdateNote = async () => {
    if (!selectedNote?.id) return;

    try {
      const response = await brain.update_classification_note(
        { noteId: selectedNote.id },
        newNoteData
      );

      if (response.ok) {
        toast.success('Classification note updated successfully');
        setShowEditNoteDialog(false);
        resetNoteForm();
        await loadClassificationNotes();
      } else {
        toast.error('Failed to update classification note');
      }
    } catch (error) {
      console.error('Error updating note:', error);
      toast.error('Failed to update note');
    }
  };

  const handleDeleteNote = async (noteId: number) => {
    try {
      const response = await brain.delete_classification_note({ noteId });

      if (response.ok) {
        toast.success('Classification note deleted successfully');
        await loadClassificationNotes();
      } else {
        toast.error('Failed to delete classification note');
      }
    } catch (error) {
      console.error('Error deleting note:', error);
      toast.error('Failed to delete note');
    }
  };

  // Classification outcomes handlers
  const handleCreateOutcome = async () => {
    try {
      const response = await brain.create_classification_outcome(newOutcomeData);

      if (response.ok) {
        toast.success('Classification outcome created successfully');
        setShowCreateOutcomeDialog(false);
        resetOutcomeForm();
        await loadClassificationOutcomes();
      } else {
        toast.error('Failed to create classification outcome');
      }
    } catch (error) {
      console.error('Error creating outcome:', error);
      toast.error('Failed to create outcome');
    }
  };

  const handleUpdateOutcome = async () => {
    if (!selectedOutcome?.id) return;

    try {
      const response = await brain.update_classification_outcome(
        { outcomeId: selectedOutcome.id },
        newOutcomeData
      );

      if (response.ok) {
        toast.success('Classification outcome updated successfully');
        setShowEditOutcomeDialog(false);
        resetOutcomeForm();
        await loadClassificationOutcomes();
      } else {
        toast.error('Failed to update classification outcome');
      }
    } catch (error) {
      console.error('Error updating outcome:', error);
      toast.error('Failed to update outcome');
    }
  };

  const handleDeleteOutcome = async (outcomeId: string) => {
    try {
      const response = await brain.delete_classification_outcome({ outcomeId });

      if (response.ok) {
        toast.success('Classification outcome deleted successfully');
        await loadClassificationOutcomes();
      } else {
        toast.error('Failed to delete classification outcome');
      }
    } catch (error) {
      console.error('Error deleting outcome:', error);
      toast.error('Failed to delete outcome');
    }
  };

  // Duplicate handlers
  const handleDuplicateOption = async (item: MetadataOptionResponse) => {
    try {
      const duplicateData = {
        category: activeCategory,
        value: `${item.value}_copy`,
        display_name: `${item.display_name} (Copy)`,
        display_order: item.display_order + 1,
        is_active: true
      };
      
      const response = await brain.create_metadata_option(duplicateData);
      
      if (response.ok) {
        toast.success(`${getCategoryLabel(activeCategory)} duplicated successfully`);
        await loadDocumentMetadata();
        onRefresh?.();
      } else {
        toast.error(`Failed to duplicate ${getCategoryLabel(activeCategory).toLowerCase()}`);
      }
    } catch (error) {
      console.error('Error duplicating option:', error);
      toast.error('Failed to duplicate option');
    }
  };

  const handleDuplicateNote = async (note: ClassificationNote) => {
    try {
      const duplicateData = {
        note_key: `${note.note_key}_copy`,
        title: `${note.title} (Copy)`,
        content: note.content,
        tree_id: note.tree_id,
        module_type: note.module_type || 'product_classification'
      };
      
      const response = await brain.create_classification_note(duplicateData);
      
      if (response.ok) {
        toast.success('Classification note duplicated successfully');
        await loadClassificationNotes();
      } else {
        const errorData = await response.json().catch(() => null);
        toast.error(errorData?.detail || 'Failed to duplicate note');
      }
    } catch (error) {
      console.error('Error duplicating note:', error);
      toast.error('Failed to duplicate note');
    }
  };

  const handleDuplicateOutcome = async (outcome: ClassificationOutcome) => {
    try {
      // Ensure outcome_code doesn't exceed 100 chars when adding '_copy'
      const baseCopyCode = `${outcome.outcome_code}_copy`;
      const finalCopyCode = baseCopyCode.length > 100 
        ? `${outcome.outcome_code.substring(0, 95)}_copy` 
        : baseCopyCode;

      const duplicateData: ClassificationOutcomeCreate = {
        outcome_code: finalCopyCode,
        outcome_title: `${outcome.outcome_title} (Copy)`,
        description: outcome.description,
        regulatory_basis: outcome.regulatory_basis,
        outcome_text: outcome.outcome_text || '',
        guidance_notes: outcome.guidance_notes,
        is_controlled: outcome.is_controlled || false
      };
      
      let response;
      if (outcome.tree_id) {
        // If outcome has a tree_id, create it under that tree
        response = await brain.create_classification_outcome(
          { treeId: outcome.tree_id },
          duplicateData
        );
      } else {
        // If it's a tree-independent outcome, create as tree-independent
        response = await brain.create_tree_independent_outcome(duplicateData);
      }
      
      if (response.ok) {
        toast.success('Classification outcome duplicated successfully');
        await loadClassificationOutcomes();
      } else {
        const errorData = await response.json().catch(() => null);
        toast.error(errorData?.detail || 'Failed to duplicate outcome');
      }
    } catch (error) {
      console.error('Error duplicating outcome:', error);
      toast.error('Failed to duplicate outcome');
    }
  };

  const handleDuplicate = async (item: any) => {
    if (activeCategory === 'notes') {
      await handleDuplicateNote(item);
    } else if (activeCategory === 'outcomes') {
      await handleDuplicateOutcome(item);
    } else {
      await handleDuplicateOption(item);
    }
  };

  // Utility functions
  const resetForm = () => {
    setFormData({
      name: '',
      description: '',
      is_active: true
    });
    setSelectedOption(null);
  };

  const resetNoteForm = () => {
    setNewNoteData({
      note_key: '',
      title: '',
      content: '',
      tree_id: null,
      module_type: 'product_classification'
    });
    setSelectedNote(null);
  };

  const resetOutcomeForm = () => {
    setNewOutcomeData({
      tree_id: null,
      outcome_code: '',
      outcome_title: '',
      description: '',
      regulatory_basis: '',
      outcome_text: '',
      license_required: false,
      prohibition_applies: false,
      additional_requirements: ''
    });
    setSelectedOutcome(null);
  };

  const getCategoryLabel = (category: CategoryType): string => {
    switch (category) {
      case 'jurisdiction': return 'Jurisdiction';
      case 'type': return 'Type';
      case 'subject': return 'Subject';
      case 'notes': return 'Classification Notes';
      case 'outcomes': return 'Classification Outcomes';
      default: return category;
    }
  };

  const getCategoryIcon = (category: CategoryType) => {
    switch (category) {
      case 'jurisdiction': return <Globe className="h-4 w-4" />;
      case 'type': return <FileType className="h-4 w-4" />;
      case 'subject': return <Tag className="h-4 w-4" />;
      case 'notes': return <BookOpen className="h-4 w-4" />;
      case 'outcomes': return <Target className="h-4 w-4" />;
      default: return <Tag className="h-4 w-4" />;
    }
  };

  const getCurrentData = () => {
    switch (activeCategory) {
      case 'jurisdiction': return jurisdictions;
      case 'type': return types;
      case 'subject': return subjects;
      case 'notes': return classificationNotes;
      case 'outcomes': return classificationOutcomes;
      default: return [];
    }
  };

  const openCreateDialog = () => {
    resetForm();
    resetNoteForm();
    resetOutcomeForm();
    
    if (activeCategory === 'notes') {
      setShowCreateNoteDialog(true);
    } else if (activeCategory === 'outcomes') {
      setShowCreateOutcomeDialog(true);
    } else {
      setShowCreateDialog(true);
    }
  };

  const openEditDialog = (item: any) => {
    if (activeCategory === 'notes') {
      setSelectedNote(item);
      setNewNoteData({
        note_key: item.note_key || '',
        title: item.title || '',
        content: item.content || '',
        tree_id: item.tree_id || null,
        module_type: item.module_type || 'product_classification'
      });
      setShowEditNoteDialog(true);
    } else if (activeCategory === 'outcomes') {
      setSelectedOutcome(item);
      setNewOutcomeData({
        tree_id: item.tree_id || null,
        outcome_code: item.outcome_code || '',
        outcome_title: item.outcome_title || '',
        description: item.description || '',
        regulatory_basis: item.regulatory_basis || '',
        outcome_text: item.outcome_text || '',
        license_required: item.license_required || false,
        prohibition_applies: item.prohibition_applies || false,
        additional_requirements: item.additional_requirements || ''
      });
      setShowEditOutcomeDialog(true);
    } else {
      setSelectedOption(item);
      setFormData({
        name: item.display_name || '',
        description: item.description || '',
        is_active: item.is_active !== undefined ? item.is_active : true
      });
      setShowEditDialog(true);
    }
  };

  const handleDelete = async (item: any) => {
    if (activeCategory === 'notes') {
      await handleDeleteNote(item.id);
    } else if (activeCategory === 'outcomes') {
      await handleDeleteOutcome(item.id);
    } else {
      await handleDeleteOption(item.id);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-amber-400 mb-2">Unified Metadata Management</h2>
          <p className="text-gray-400">Manage all metadata types in one centralized location</p>
        </div>
        <Button 
          onClick={openCreateDialog}
          className="bg-amber-600 hover:bg-amber-700 text-white"
        >
          <Plus className="h-4 w-4 mr-2" />
          Create New {getCategoryLabel(activeCategory)}
        </Button>
      </div>

      {/* Category Tabs */}
      <Tabs value={activeCategory} onValueChange={(value) => setActiveCategory(value as CategoryType)}>
        <TabsList className="bg-gray-800 border-gray-700 grid grid-cols-5">
          <TabsTrigger value="jurisdiction" className="data-[state=active]:bg-amber-600">
            <Globe className="h-4 w-4 mr-2" />
            Jurisdictions ({jurisdictions.length})
          </TabsTrigger>
          <TabsTrigger value="type" className="data-[state=active]:bg-amber-600">
            <FileType className="h-4 w-4 mr-2" />
            Types ({types.length})
          </TabsTrigger>
          <TabsTrigger value="subject" className="data-[state=active]:bg-amber-600">
            <Tag className="h-4 w-4 mr-2" />
            Subjects ({subjects.length})
          </TabsTrigger>
          <TabsTrigger value="notes" className="data-[state=active]:bg-amber-600">
            <BookOpen className="h-4 w-4 mr-2" />
            Notes ({classificationNotes.length})
          </TabsTrigger>
          <TabsTrigger value="outcomes" className="data-[state=active]:bg-amber-600">
            <Target className="h-4 w-4 mr-2" />
            Outcomes ({classificationOutcomes.length})
          </TabsTrigger>
        </TabsList>

        {/* Content for each tab */}
        <TabsContent value={activeCategory} className="space-y-4">
          <Card className="bg-gray-800 border-gray-700">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2 text-amber-400">
                    {getCategoryIcon(activeCategory)}
                    {getCategoryLabel(activeCategory)} Management
                  </CardTitle>
                  <CardDescription className="text-gray-400">
                    Manage {getCategoryLabel(activeCategory).toLowerCase()} options for the platform
                  </CardDescription>
                </div>
                <div className="flex items-center gap-2">
                  <Input
                    placeholder="Search..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-64 bg-gray-700 border-gray-600 text-white"
                  />
                  <Button variant="outline" size="sm" className="border-gray-600">
                    <Search className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="flex items-center justify-center py-8">
                  <div className="text-gray-400">Loading {getCategoryLabel(activeCategory).toLowerCase()}...</div>
                </div>
              ) : (
                <div className="space-y-4">
                  {getCurrentData().length === 0 ? (
                    <div className="text-center py-8 text-gray-400">
                      No {getCategoryLabel(activeCategory).toLowerCase()} found
                    </div>
                  ) : (
                    <Table>
                      <TableHeader>
                        <TableRow className="border-gray-700">
                          {activeCategory === 'notes' ? (
                            <>
                              <TableHead className="text-gray-300">Note Key</TableHead>
                              <TableHead className="text-gray-300">Title</TableHead>
                              <TableHead className="text-gray-300">Content Preview</TableHead>
                              <TableHead className="text-gray-300">Module</TableHead>
                              <TableHead className="text-gray-300">Actions</TableHead>
                            </>
                          ) : activeCategory === 'outcomes' ? (
                            <>
                              <TableHead className="text-gray-300">Outcome Code</TableHead>
                              <TableHead className="text-gray-300">Title</TableHead>
                              <TableHead className="text-gray-300">Description</TableHead>
                              <TableHead className="text-gray-300">License Required</TableHead>
                              <TableHead className="text-gray-300">Actions</TableHead>
                            </>
                          ) : (
                            <>
                              <TableHead className="text-gray-300">Name</TableHead>
                              <TableHead className="text-gray-300">Description</TableHead>
                              <TableHead className="text-gray-300">Status</TableHead>
                              <TableHead className="text-gray-300">Actions</TableHead>
                            </>
                          )}
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {getCurrentData().map((item: any) => (
                          <TableRow key={item.id} className="border-gray-700">
                            {activeCategory === 'notes' ? (
                              <>
                                <TableCell className="text-white font-mono">{item.note_key}</TableCell>
                                <TableCell className="text-white">{item.title}</TableCell>
                                <TableCell className="text-gray-300 max-w-xs truncate">
                                  {item.content?.substring(0, 100)}...
                                </TableCell>
                                <TableCell>
                                  <Badge variant="outline" className="border-amber-600 text-amber-400">
                                    {item.module_type}
                                  </Badge>
                                </TableCell>
                                <TableCell>
                                  <div className="flex items-center gap-2">
                                    <Button
                                      variant="ghost"
                                      size="sm"
                                      onClick={() => openEditDialog(item)}
                                      className="text-blue-400 hover:text-blue-300"
                                    >
                                      <Edit className="h-4 w-4" />
                                    </Button>
                                    <AlertDialog>
                                      <AlertDialogTrigger asChild>
                                        <Button
                                          variant="ghost"
                                          size="sm"
                                          className="text-red-400 hover:text-red-300"
                                        >
                                          <Trash2 className="h-4 w-4" />
                                        </Button>
                                      </AlertDialogTrigger>
                                      <AlertDialogContent className="bg-gray-800 border-gray-600">
                                        <AlertDialogHeader>
                                          <AlertDialogTitle className="text-white">Delete Note</AlertDialogTitle>
                                          <AlertDialogDescription className="text-gray-400">
                                            Are you sure you want to delete this classification note? This action cannot be undone.
                                          </AlertDialogDescription>
                                        </AlertDialogHeader>
                                        <AlertDialogFooter>
                                          <AlertDialogCancel className="bg-gray-700 border-gray-600 text-white hover:bg-gray-600">
                                            Cancel
                                          </AlertDialogCancel>
                                          <AlertDialogAction
                                            onClick={() => handleDelete(item)}
                                            className="bg-red-600 hover:bg-red-700 text-white"
                                          >
                                            Delete
                                          </AlertDialogAction>
                                        </AlertDialogFooter>
                                      </AlertDialogContent>
                                    </AlertDialog>
                                    <Button
                                      variant="ghost"
                                      size="sm"
                                      onClick={() => handleDuplicate(item)}
                                      className="text-green-400 hover:text-green-300"
                                    >
                                      <Copy className="h-4 w-4" />
                                    </Button>
                                  </div>
                                </TableCell>
                              </>
                            ) : activeCategory === 'outcomes' ? (
                              <>
                                <TableCell className="text-white font-mono">{item.outcome_code}</TableCell>
                                <TableCell className="text-white">{item.outcome_title}</TableCell>
                                <TableCell className="text-gray-300 max-w-xs truncate">
                                  {item.description?.substring(0, 100)}...
                                </TableCell>
                                <TableCell>
                                  <Badge 
                                    variant={item.license_required ? "destructive" : "secondary"}
                                    className={item.license_required ? "bg-red-600" : "bg-green-600"}
                                  >
                                    {item.license_required ? 'Required' : 'Not Required'}
                                  </Badge>
                                </TableCell>
                                <TableCell>
                                  <div className="flex items-center gap-2">
                                    <Button
                                      variant="ghost"
                                      size="sm"
                                      onClick={() => openEditDialog(item)}
                                      className="text-blue-400 hover:text-blue-300"
                                    >
                                      <Edit className="h-4 w-4" />
                                    </Button>
                                    <AlertDialog>
                                      <AlertDialogTrigger asChild>
                                        <Button
                                          variant="ghost"
                                          size="sm"
                                          className="text-red-400 hover:text-red-300"
                                        >
                                          <Trash2 className="h-4 w-4" />
                                        </Button>
                                      </AlertDialogTrigger>
                                      <AlertDialogContent className="bg-gray-800 border-gray-600">
                                        <AlertDialogHeader>
                                          <AlertDialogTitle className="text-white">Delete Outcome</AlertDialogTitle>
                                          <AlertDialogDescription className="text-gray-400">
                                            Are you sure you want to delete this classification outcome? This action cannot be undone.
                                          </AlertDialogDescription>
                                        </AlertDialogHeader>
                                        <AlertDialogFooter>
                                          <AlertDialogCancel className="bg-gray-700 border-gray-600 text-white hover:bg-gray-600">
                                            Cancel
                                          </AlertDialogCancel>
                                          <AlertDialogAction
                                            onClick={() => handleDelete(item)}
                                            className="bg-red-600 hover:bg-red-700 text-white"
                                          >
                                            Delete
                                          </AlertDialogAction>
                                        </AlertDialogFooter>
                                      </AlertDialogContent>
                                    </AlertDialog>
                                    <Button
                                      variant="ghost"
                                      size="sm"
                                      onClick={() => handleDuplicate(item)}
                                      className="text-green-400 hover:text-green-300"
                                    >
                                      <Copy className="h-4 w-4" />
                                    </Button>
                                  </div>
                                </TableCell>
                              </>
                            ) : (
                              <>
                                <TableCell className="text-white">{item.display_name}</TableCell>
                                <TableCell className="text-gray-300">{item.description || 'No description'}</TableCell>
                                <TableCell>
                                  <Badge 
                                    variant={item.is_active ? "default" : "secondary"}
                                    className={item.is_active ? "bg-green-600" : "bg-gray-600"}
                                  >
                                    {item.is_active ? 'Active' : 'Inactive'}
                                  </Badge>
                                </TableCell>
                                <TableCell>
                                  <div className="flex items-center gap-2">
                                    <Button
                                      variant="ghost"
                                      size="sm"
                                      onClick={() => openEditDialog(item)}
                                      className="text-blue-400 hover:text-blue-300"
                                    >
                                      <Edit className="h-4 w-4" />
                                    </Button>
                                    <AlertDialog>
                                      <AlertDialogTrigger asChild>
                                        <Button
                                          variant="ghost"
                                          size="sm"
                                          className="text-red-400 hover:text-red-300"
                                        >
                                          <Trash2 className="h-4 w-4" />
                                        </Button>
                                      </AlertDialogTrigger>
                                      <AlertDialogContent className="bg-gray-800 border-gray-600">
                                        <AlertDialogHeader>
                                          <AlertDialogTitle className="text-white">Delete {getCategoryLabel(activeCategory)}</AlertDialogTitle>
                                          <AlertDialogDescription className="text-gray-400">
                                            Are you sure you want to delete this {getCategoryLabel(activeCategory).toLowerCase()}? This action cannot be undone.
                                          </AlertDialogDescription>
                                        </AlertDialogHeader>
                                        <AlertDialogFooter>
                                          <AlertDialogCancel className="bg-gray-700 border-gray-600 text-white hover:bg-gray-600">
                                            Cancel
                                          </AlertDialogCancel>
                                          <AlertDialogAction
                                            onClick={() => handleDelete(item)}
                                            className="bg-red-600 hover:bg-red-700 text-white"
                                          >
                                            Delete
                                          </AlertDialogAction>
                                        </AlertDialogFooter>
                                      </AlertDialogContent>
                                    </AlertDialog>
                                    <Button
                                      variant="ghost"
                                      size="sm"
                                      onClick={() => handleDuplicate(item)}
                                      className="text-green-400 hover:text-green-300"
                                    >
                                      <Copy className="h-4 w-4" />
                                    </Button>
                                  </div>
                                </TableCell>
                              </>
                            )}
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Create Document Metadata Dialog */}
      <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
        <DialogContent className="bg-gray-800 border-gray-600 text-white max-w-md">
          <DialogHeader>
            <DialogTitle>Create New {getCategoryLabel(activeCategory)}</DialogTitle>
            <DialogDescription className="text-gray-400">
              Add a new {getCategoryLabel(activeCategory).toLowerCase()} option
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="name" className="text-white">Name</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="bg-gray-700 border-gray-600 text-white"
                placeholder="Enter name"
              />
            </div>
            <div>
              <Label htmlFor="description" className="text-white">Description</Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                className="bg-gray-700 border-gray-600 text-white"
                placeholder="Enter description (optional)"
                rows={3}
              />
            </div>
            <div className="flex items-center space-x-2">
              <Switch
                id="is_active"
                checked={formData.is_active}
                onCheckedChange={(checked) => setFormData({ ...formData, is_active: checked })}
              />
              <Label htmlFor="is_active" className="text-white">Active</Label>
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setShowCreateDialog(false)}
              className="border-gray-600 text-gray-300 hover:bg-gray-700"
            >
              Cancel
            </Button>
            <Button
              onClick={handleCreateOption}
              className="bg-amber-600 hover:bg-amber-700 text-white"
            >
              Create {getCategoryLabel(activeCategory)}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Document Metadata Dialog */}
      <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
        <DialogContent className="bg-gray-800 border-gray-600 text-white max-w-md">
          <DialogHeader>
            <DialogTitle>Edit {getCategoryLabel(activeCategory)}</DialogTitle>
            <DialogDescription className="text-gray-400">
              Update the {getCategoryLabel(activeCategory).toLowerCase()} information
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="edit-name" className="text-white">Name</Label>
              <Input
                id="edit-name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="bg-gray-700 border-gray-600 text-white"
                placeholder="Enter name"
              />
            </div>
            <div>
              <Label htmlFor="edit-description" className="text-white">Description</Label>
              <Textarea
                id="edit-description"
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                className="bg-gray-700 border-gray-600 text-white"
                placeholder="Enter description (optional)"
                rows={3}
              />
            </div>
            <div className="flex items-center space-x-2">
              <Switch
                id="edit-is_active"
                checked={formData.is_active}
                onCheckedChange={(checked) => setFormData({ ...formData, is_active: checked })}
              />
              <Label htmlFor="edit-is_active" className="text-white">Active</Label>
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setShowEditDialog(false)}
              className="border-gray-600 text-gray-300 hover:bg-gray-700"
            >
              Cancel
            </Button>
            <Button
              onClick={handleUpdateOption}
              className="bg-amber-600 hover:bg-amber-700 text-white"
            >
              Update {getCategoryLabel(activeCategory)}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Create Classification Note Dialog */}
      <Dialog open={showCreateNoteDialog} onOpenChange={setShowCreateNoteDialog}>
        <DialogContent className="bg-gray-800 border-gray-600 text-white max-w-2xl">
          <DialogHeader>
            <DialogTitle>Create Classification Note</DialogTitle>
            <DialogDescription className="text-gray-400">
              Add a new regulatory note for product classification
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="note-key" className="text-white">Note Key</Label>
              <Input
                id="note-key"
                value={newNoteData.note_key}
                onChange={(e) => setNewNoteData({ ...newNoteData, note_key: e.target.value })}
                className="bg-gray-700 border-gray-600 text-white"
                placeholder="Enter unique note key"
              />
            </div>
            <div>
              <Label htmlFor="note-title" className="text-white">Title</Label>
              <Input
                id="note-title"
                value={newNoteData.title}
                onChange={(e) => setNewNoteData({ ...newNoteData, title: e.target.value })}
                className="bg-gray-700 border-gray-600 text-white"
                placeholder="Enter note title"
              />
            </div>
            <div>
              <Label htmlFor="note-content" className="text-white">Content</Label>
              <Textarea
                id="note-content"
                value={newNoteData.content}
                onChange={(e) => setNewNoteData({ ...newNoteData, content: e.target.value })}
                className="bg-gray-700 border-gray-600 text-white"
                placeholder="Enter note content"
                rows={6}
              />
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setShowCreateNoteDialog(false)}
              className="border-gray-600 text-gray-300 hover:bg-gray-700"
            >
              Cancel
            </Button>
            <Button
              onClick={handleCreateNote}
              className="bg-amber-600 hover:bg-amber-700 text-white"
            >
              Create Note
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Classification Note Dialog */}
      <Dialog open={showEditNoteDialog} onOpenChange={setShowEditNoteDialog}>
        <DialogContent className="bg-gray-800 border-gray-600 text-white max-w-2xl">
          <DialogHeader>
            <DialogTitle>Edit Classification Note</DialogTitle>
            <DialogDescription className="text-gray-400">
              Update the classification note information
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="edit-note-key" className="text-white">Note Key</Label>
              <Input
                id="edit-note-key"
                value={newNoteData.note_key}
                onChange={(e) => setNewNoteData({ ...newNoteData, note_key: e.target.value })}
                className="bg-gray-700 border-gray-600 text-white"
                placeholder="Enter unique note key"
              />
            </div>
            <div>
              <Label htmlFor="edit-note-title" className="text-white">Title</Label>
              <Input
                id="edit-note-title"
                value={newNoteData.title}
                onChange={(e) => setNewNoteData({ ...newNoteData, title: e.target.value })}
                className="bg-gray-700 border-gray-600 text-white"
                placeholder="Enter note title"
              />
            </div>
            <div>
              <Label htmlFor="edit-note-content" className="text-white">Content</Label>
              <Textarea
                id="edit-note-content"
                value={newNoteData.content}
                onChange={(e) => setNewNoteData({ ...newNoteData, content: e.target.value })}
                className="bg-gray-700 border-gray-600 text-white"
                placeholder="Enter note content"
                rows={6}
              />
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setShowEditNoteDialog(false)}
              className="border-gray-600 text-gray-300 hover:bg-gray-700"
            >
              Cancel
            </Button>
            <Button
              onClick={handleUpdateNote}
              className="bg-amber-600 hover:bg-amber-700 text-white"
            >
              Update Note
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Create Classification Outcome Dialog */}
      <Dialog open={showCreateOutcomeDialog} onOpenChange={setShowCreateOutcomeDialog}>
        <DialogContent className="bg-gray-800 border-gray-600 text-white max-w-3xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Create Classification Outcome</DialogTitle>
            <DialogDescription className="text-gray-400">
              Add a new classification outcome for product classification
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="outcome-code" className="text-white">Outcome Code</Label>
                <Input
                  id="outcome-code"
                  value={newOutcomeData.outcome_code}
                  onChange={(e) => setNewOutcomeData({ ...newOutcomeData, outcome_code: e.target.value })}
                  className="bg-gray-700 border-gray-600 text-white"
                  placeholder="Enter outcome code"
                />
              </div>
              <div>
                <Label htmlFor="outcome-title" className="text-white">Outcome Title</Label>
                <Input
                  id="outcome-title"
                  value={newOutcomeData.outcome_title}
                  onChange={(e) => setNewOutcomeData({ ...newOutcomeData, outcome_title: e.target.value })}
                  className="bg-gray-700 border-gray-600 text-white"
                  placeholder="Enter outcome title"
                />
              </div>
            </div>
            <div>
              <Label htmlFor="outcome-description" className="text-white">Description</Label>
              <Textarea
                id="outcome-description"
                value={newOutcomeData.description}
                onChange={(e) => setNewOutcomeData({ ...newOutcomeData, description: e.target.value })}
                className="bg-gray-700 border-gray-600 text-white"
                placeholder="Enter outcome description"
                rows={3}
              />
            </div>
            <div>
              <Label htmlFor="regulatory-basis" className="text-white">Regulatory Basis</Label>
              <Textarea
                id="regulatory-basis"
                value={newOutcomeData.regulatory_basis}
                onChange={(e) => setNewOutcomeData({ ...newOutcomeData, regulatory_basis: e.target.value })}
                className="bg-gray-700 border-gray-600 text-white"
                placeholder="Enter regulatory basis"
                rows={2}
              />
            </div>
            <div>
              <Label htmlFor="outcome-text" className="text-white">Outcome Text</Label>
              <Textarea
                id="outcome-text"
                value={newOutcomeData.outcome_text}
                onChange={(e) => setNewOutcomeData({ ...newOutcomeData, outcome_text: e.target.value })}
                className="bg-gray-700 border-gray-600 text-white"
                placeholder="Enter detailed outcome text"
                rows={4}
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="flex items-center space-x-2">
                <Switch
                  id="license-required"
                  checked={newOutcomeData.license_required}
                  onCheckedChange={(checked) => setNewOutcomeData({ ...newOutcomeData, license_required: checked })}
                />
                <Label htmlFor="license-required" className="text-white">License Required</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Switch
                  id="prohibition-applies"
                  checked={newOutcomeData.prohibition_applies}
                  onCheckedChange={(checked) => setNewOutcomeData({ ...newOutcomeData, prohibition_applies: checked })}
                />
                <Label htmlFor="prohibition-applies" className="text-white">Prohibition Applies</Label>
              </div>
            </div>
            <div>
              <Label htmlFor="additional-requirements" className="text-white">Additional Requirements</Label>
              <Textarea
                id="additional-requirements"
                value={newOutcomeData.additional_requirements}
                onChange={(e) => setNewOutcomeData({ ...newOutcomeData, additional_requirements: e.target.value })}
                className="bg-gray-700 border-gray-600 text-white"
                placeholder="Enter any additional requirements"
                rows={2}
              />
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setShowCreateOutcomeDialog(false)}
              className="border-gray-600 text-gray-300 hover:bg-gray-700"
            >
              Cancel
            </Button>
            <Button
              onClick={handleCreateOutcome}
              className="bg-amber-600 hover:bg-amber-700 text-white"
            >
              Create Outcome
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Classification Outcome Dialog */}
      <Dialog open={showEditOutcomeDialog} onOpenChange={setShowEditOutcomeDialog}>
        <DialogContent className="bg-gray-800 border-gray-600 text-white max-w-3xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Edit Classification Outcome</DialogTitle>
            <DialogDescription className="text-gray-400">
              Update the classification outcome information
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="edit-outcome-code" className="text-white">Outcome Code</Label>
                <Input
                  id="edit-outcome-code"
                  value={newOutcomeData.outcome_code}
                  onChange={(e) => setNewOutcomeData({ ...newOutcomeData, outcome_code: e.target.value })}
                  className="bg-gray-700 border-gray-600 text-white"
                  placeholder="Enter outcome code"
                />
              </div>
              <div>
                <Label htmlFor="edit-outcome-title" className="text-white">Outcome Title</Label>
                <Input
                  id="edit-outcome-title"
                  value={newOutcomeData.outcome_title}
                  onChange={(e) => setNewOutcomeData({ ...newOutcomeData, outcome_title: e.target.value })}
                  className="bg-gray-700 border-gray-600 text-white"
                  placeholder="Enter outcome title"
                />
              </div>
            </div>
            <div>
              <Label htmlFor="edit-outcome-description" className="text-white">Description</Label>
              <Textarea
                id="edit-outcome-description"
                value={newOutcomeData.description}
                onChange={(e) => setNewOutcomeData({ ...newOutcomeData, description: e.target.value })}
                className="bg-gray-700 border-gray-600 text-white"
                placeholder="Enter outcome description"
                rows={3}
              />
            </div>
            <div>
              <Label htmlFor="edit-regulatory-basis" className="text-white">Regulatory Basis</Label>
              <Textarea
                id="edit-regulatory-basis"
                value={newOutcomeData.regulatory_basis}
                onChange={(e) => setNewOutcomeData({ ...newOutcomeData, regulatory_basis: e.target.value })}
                className="bg-gray-700 border-gray-600 text-white"
                placeholder="Enter regulatory basis"
                rows={2}
              />
            </div>
            <div>
              <Label htmlFor="edit-outcome-text" className="text-white">Outcome Text</Label>
              <Textarea
                id="edit-outcome-text"
                value={newOutcomeData.outcome_text}
                onChange={(e) => setNewOutcomeData({ ...newOutcomeData, outcome_text: e.target.value })}
                className="bg-gray-700 border-gray-600 text-white"
                placeholder="Enter detailed outcome text"
                rows={4}
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="flex items-center space-x-2">
                <Switch
                  id="edit-license-required"
                  checked={newOutcomeData.license_required}
                  onCheckedChange={(checked) => setNewOutcomeData({ ...newOutcomeData, license_required: checked })}
                />
                <Label htmlFor="edit-license-required" className="text-white">License Required</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Switch
                  id="edit-prohibition-applies"
                  checked={newOutcomeData.prohibition_applies}
                  onCheckedChange={(checked) => setNewOutcomeData({ ...newOutcomeData, prohibition_applies: checked })}
                />
                <Label htmlFor="edit-prohibition-applies" className="text-white">Prohibition Applies</Label>
              </div>
            </div>
            <div>
              <Label htmlFor="edit-additional-requirements" className="text-white">Additional Requirements</Label>
              <Textarea
                id="edit-additional-requirements"
                value={newOutcomeData.additional_requirements}
                onChange={(e) => setNewOutcomeData({ ...newOutcomeData, additional_requirements: e.target.value })}
                className="bg-gray-700 border-gray-600 text-white"
                placeholder="Enter any additional requirements"
                rows={2}
              />
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setShowEditOutcomeDialog(false)}
              className="border-gray-600 text-gray-300 hover:bg-gray-700"
            >
              Cancel
            </Button>
            <Button
              onClick={handleUpdateOutcome}
              className="bg-amber-600 hover:bg-amber-700 text-white"
            >
              Update Outcome
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
