import React, { useState, useEffect } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Switch } from '@/components/ui/switch';
import { Checkbox } from '@/components/ui/checkbox';
import { Progress } from '@/components/ui/progress';
import {
  Rss,
  Globe,
  Activity,
  Clock,
  AlertTriangle,
  CheckCircle,
  XCircle,
  Play,
  Pause,
  Settings,
  Plus,
  Trash2,
  RefreshCw,
  Bell,
  Calendar,
  TrendingUp,
  Database,
  Server,
  Shield,
  Zap,
  Target,
  Filter,
  Download,
  Upload,
  Eye,
  ExternalLink,
  Search,
  MoreVertical,
  Edit,
  MonitorSpeaker,
  Gauge,
  Timer,
  Network,
  Cpu,
  HardDrive,
  Wifi,
  AlertCircle,
  BarChart3,
  LineChart
} from 'lucide-react';
import { toast } from 'sonner';
import brain from 'brain';

interface RegulatoryFeed {
  id: number;
  name: string;
  jurisdiction: string;
  feed_type: 'rss' | 'api' | 'scraper' | 'manual';
  url: string; // Fixed: changed from source_url to url
  update_frequency: 'hourly' | 'daily' | 'weekly' | 'monthly';
  status: 'active' | 'paused' | 'error' | 'disabled';
  last_checked?: string;
  last_update_found?: string;
  error_count: number;
  configuration: Record<string, any>;
  created_at?: string;
  updated_at?: string;
}

interface FeedUpdate {
  id: number;
  feed_id: number;
  title: string;
  description: string;
  source_url: string;
  publication_date: string;
  jurisdiction: string;
  category: string;
  confidence: number;
  status: 'new' | 'processed' | 'ignored';
  created_at: string;
}

interface FeedAlert {
  id: number;
  feed_id: number;
  alert_type: 'new_document' | 'feed_error' | 'threshold_exceeded';
  message: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  created_at: string;
  is_read: boolean;
}

interface FeedHealthMetrics {
  health_score: number;
  uptime_percentage: number;
  success_rate: number;
  avg_response_time: number;
  last_successful_check: string;
  error_count_24h: number;
  status: 'healthy' | 'warning' | 'error' | 'critical';
}

interface SchedulingConfig {
  enabled: boolean;
  frequency: 'hourly' | 'daily' | 'weekly' | 'monthly';
  cron_expression?: string;
  timezone: string;
  retry_attempts: number;
  retry_delay: number;
  error_threshold: number;
}

interface NotificationConfig {
  email_enabled: boolean;
  webhook_enabled: boolean;
  dashboard_enabled: boolean;
  notification_types: string[];
  recipients: string[];
  webhook_url?: string;
}

interface SystemStatus {
  total_feeds: number;
  active_feeds: number;
  feeds_with_errors: number;
  last_global_update: string;
  system_health: 'healthy' | 'degraded' | 'down';
  processing_queue_size: number;
}

interface Props {
  onDocumentAdded?: (documentId: number) => void;
}

const RegulatoryFeedsInterface: React.FC<Props> = ({ onDocumentAdded }) => {
  const [activeTab, setActiveTab] = useState('feeds');
  const [feeds, setFeeds] = useState<RegulatoryFeed[]>([]);
  const [feedUpdates, setFeedUpdates] = useState<FeedUpdate[]>([]);
  const [feedAlerts, setFeedAlerts] = useState<FeedAlert[]>([]);
  const [selectedFeed, setSelectedFeed] = useState<number | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [showCreateFeed, setShowCreateFeed] = useState(false);
  const [showFeedConfig, setShowFeedConfig] = useState(false);
  const [showHealthDashboard, setShowHealthDashboard] = useState(false);
  const [showSchedulingConfig, setShowSchedulingConfig] = useState(false);
  const [showNotificationConfig, setShowNotificationConfig] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [jurisdictionFilter, setJurisdictionFilter] = useState<string>('all');
  
  // New state for automation features
  const [feedHealthMetrics, setFeedHealthMetrics] = useState<{ [feedId: number]: FeedHealthMetrics }>({});
  const [systemStatus, setSystemStatus] = useState<SystemStatus | null>(null);
  const [processingFeeds, setProcessingFeeds] = useState<Set<number>>(new Set());
  const [schedulingConfigs, setSchedulingConfigs] = useState<{ [feedId: number]: SchedulingConfig }>({});
  const [notificationConfigs, setNotificationConfigs] = useState<{ [feedId: number]: NotificationConfig }>({});
  const [bulkProcessing, setBulkProcessing] = useState(false);
  const [realTimeUpdates, setRealTimeUpdates] = useState(true);

  // Form states
  const [newFeed, setNewFeed] = useState({
    name: '',
    jurisdiction: '',
    feed_type: 'rss' as const,
    url: '', // Fixed: changed from source_url to url
    update_frequency: 'daily' as const,
    configuration: {
      keywords: [],
      exclude_keywords: [],
      auto_import: true,
      notification_enabled: true,
      confidence_threshold: 0.8
    }
  });

  const [schedulingForm, setSchedulingForm] = useState<SchedulingConfig>({
    enabled: true,
    frequency: 'daily',
    timezone: 'UTC',
    retry_attempts: 3,
    retry_delay: 300,
    error_threshold: 5
  });

  const [notificationForm, setNotificationForm] = useState<NotificationConfig>({
    email_enabled: true,
    webhook_enabled: false,
    dashboard_enabled: true,
    notification_types: ['new_document', 'feed_error'],
    recipients: [],
    webhook_url: ''
  });

  useEffect(() => {
    loadFeeds();
    loadSystemStatus();
    if (realTimeUpdates) {
      const interval = setInterval(() => {
        loadFeeds();
        loadSystemStatus();
        loadHealthMetrics();
      }, 30000); // Update every 30 seconds
      return () => clearInterval(interval);
    }
  }, [realTimeUpdates]);

  const loadFeeds = async () => {
    try {
      setIsLoading(true);
      const response = await brain.list_regulatory_feeds();
      const feedData = await response.json();
      setFeeds(feedData.feeds || []);
      setFeedUpdates(feedData.recent_updates || []);
      setFeedAlerts(feedData.alerts || []);
      
      // Load health metrics for all feeds
      for (const feed of feedData.feeds || []) {
        loadFeedHealthMetrics(feed.id);
      }
    } catch (error) {
      console.error('Error loading feeds:', error);
      toast.error('Failed to load regulatory feeds');
    } finally {
      setIsLoading(false);
    }
  };

  const loadSystemStatus = async () => {
    try {
      const response = await brain.get_system_status();
      const statusData = await response.json();
      setSystemStatus(statusData);
    } catch (error) {
      console.error('Error loading system status:', error);
    }
  };

  const loadFeedHealthMetrics = async (feedId: number) => {
    try {
      const response = await brain.get_feed_health_metrics({ feedId });
      const healthData = await response.json();
      setFeedHealthMetrics(prev => ({
        ...prev,
        [feedId]: healthData
      }));
    } catch (error) {
      console.error(`Error loading health metrics for feed ${feedId}:`, error);
    }
  };

  const loadHealthMetrics = async () => {
    for (const feed of feeds) {
      loadFeedHealthMetrics(feed.id);
    }
  };

  const processEnhancedFeed = async (feedId: number) => {
    try {
      setProcessingFeeds(prev => new Set(prev).add(feedId));
      toast.info('Starting enhanced feed processing...');
      
      const response = await brain.process_feed_enhanced({ feedId });
      const result = await response.json();
      
      if (result.success) {
        toast.success(`Feed processed successfully: ${result.documents_imported} documents imported`);
        loadFeeds(); // Refresh data
        if (onDocumentAdded && result.documents_imported > 0) {
          onDocumentAdded(feedId);
        }
      } else {
        toast.error(`Feed processing failed: ${result.error}`);
      }
    } catch (error) {
      console.error('Error processing feed:', error);
      toast.error('Failed to process feed');
    } finally {
      setProcessingFeeds(prev => {
        const next = new Set(prev);
        next.delete(feedId);
        return next;
      });
    }
  };

  const bulkProcessFeeds = async () => {
    try {
      setBulkProcessing(true);
      const activeFeedIds = feeds.filter(f => f.status === 'active').map(f => f.id);
      
      if (activeFeedIds.length === 0) {
        toast.warning('No active feeds to process');
        return;
      }

      toast.info(`Processing ${activeFeedIds.length} feeds...`);
      
      const response = await brain.bulk_process_feeds({
        feed_ids: activeFeedIds,
        parallel_workers: 3,
        error_threshold: 0.3,
        timeout_seconds: 300
      });
      
      const result = await response.json();
      
      toast.success(`Bulk processing completed: ${result.successful_feeds} succeeded, ${result.failed_feeds} failed`);
      loadFeeds();
      
    } catch (error) {
      console.error('Error in bulk processing:', error);
      toast.error('Bulk processing failed');
    } finally {
      setBulkProcessing(false);
    }
  };

  const performHealthCheck = async (feedId: number) => {
    try {
      toast.info('Performing health check...');
      const response = await brain.perform_feed_health_check({ feedId });
      const result = await response.json();
      
      if (result.is_healthy) {
        toast.success('Feed health check passed');
      } else {
        toast.warning(`Health check issues: ${result.issues.join(', ')}`);
      }
      
      loadFeedHealthMetrics(feedId);
    } catch (error) {
      console.error('Error performing health check:', error);
      toast.error('Health check failed');
    }
  };

  const configureScheduling = async (feedId: number) => {
    try {
      const response = await brain.configure_feed_scheduling({ feedId }, schedulingForm);
      const result = await response.json();
      
      if (result.success) {
        toast.success('Scheduling configured successfully');
        setSchedulingConfigs(prev => ({ ...prev, [feedId]: schedulingForm }));
        setShowSchedulingConfig(false);
      }
    } catch (error) {
      console.error('Error configuring scheduling:', error);
      toast.error('Failed to configure scheduling');
    }
  };

  const configureNotifications = async (feedId: number) => {
    try {
      const response = await brain.configure_feed_alerts({ feedId }, {
        alert_types: notificationForm.notification_types,
        email_enabled: notificationForm.email_enabled,
        webhook_enabled: notificationForm.webhook_enabled,
        webhook_url: notificationForm.webhook_url,
        recipients: notificationForm.recipients,
        severity_threshold: 'medium'
      });
      
      const result = await response.json();
      
      if (result.success) {
        toast.success('Notification settings configured');
        setNotificationConfigs(prev => ({ ...prev, [feedId]: notificationForm }));
        setShowNotificationConfig(false);
      }
    } catch (error) {
      console.error('Error configuring notifications:', error);
      toast.error('Failed to configure notifications');
    }
  };

  const createFeed = async () => {
    try {
      const response = await brain.create_regulatory_feed({
        name: newFeed.name,
        jurisdiction: newFeed.jurisdiction,
        feed_type: newFeed.feed_type,
        url: newFeed.url, // Fixed: changed from source_url to url
        update_frequency: newFeed.update_frequency,
        configuration: newFeed.configuration,
        status: 'active'
      });
      
      const result = await response.json();
      toast.success('Regulatory feed created successfully');
      loadFeeds();
      setShowCreateFeed(false);
      setNewFeed({
        name: '',
        jurisdiction: '',
        feed_type: 'rss',
        url: '', // Fixed: changed from source_url to url
        update_frequency: 'daily',
        configuration: {
          keywords: [],
          exclude_keywords: [],
          auto_import: true,
          notification_enabled: true,
          confidence_threshold: 0.8
        }
      });
    } catch (error) {
      console.error('Error creating feed:', error);
      toast.error('Failed to create feed');
    }
  };

  const checkFeedForUpdates = async (feedId: number) => {
    try {
      setIsLoading(true);
      const response = await brain.check_feed_for_updates({ feedId });
      if (response.ok) {
        const data = await response.json();
        toast.success(`Feed check completed: ${data.updates_found} updates found`);
        loadFeeds();
        if (selectedFeed === feedId) {
          loadFeedUpdates(feedId);
        }
      }
    } catch (error) {
      console.error('Error checking feed:', error);
      toast.error('Failed to check feed for updates');
    } finally {
      setIsLoading(false);
    }
  };

  const toggleFeedStatus = async (feedId: number, currentStatus: string) => {
    try {
      const newStatus = currentStatus === 'active' ? 'paused' : 'active';
      // In real implementation, would call update feed API
      toast.success(`Feed ${newStatus === 'active' ? 'activated' : 'paused'}`);
      loadFeeds();
    } catch (error) {
      console.error('Error toggling feed status:', error);
      toast.error('Failed to update feed status');
    }
  };

  const processUpdate = async (updateId: number, action: 'approve' | 'ignore') => {
    try {
      // In real implementation, would call process update API
      const update = feedUpdates.find(u => u.id === updateId);
      if (update && action === 'approve') {
        // Simulate adding document to knowledge base
        onDocumentAdded?.(updateId);
        toast.success('Update imported to Knowledge Base');
      } else {
        toast.success('Update marked as ignored');
      }
      
      // Update local state
      setFeedUpdates(prev => 
        prev.map(u => u.id === updateId ? 
          { ...u, status: action === 'approve' ? 'processed' : 'ignored' } : u
        )
      );
    } catch (error) {
      console.error('Error processing update:', error);
      toast.error('Failed to process update');
    }
  };

  const resetNewFeedForm = () => {
    setNewFeed({
      name: '',
      jurisdiction: '',
      feed_type: 'rss',
      url: '', // Fixed: changed from source_url to url
      update_frequency: 'daily',
      configuration: {
        keywords: [],
        exclude_keywords: [],
        auto_import: true,
        notification_enabled: true,
        confidence_threshold: 0.8
      }
    });
  };

  const getFeedTypeIcon = (type: string) => {
    switch (type) {
      case 'rss': return <Rss className="w-4 h-4" />;
      case 'api': return <Database className="w-4 h-4" />;
      case 'scraper': return <Globe className="w-4 h-4" />;
      default: return <Server className="w-4 h-4" />;
    }
  };

  const getStatusBadge = (status: string) => {
    const statusConfig = {
      active: { color: 'bg-green-500', icon: <CheckCircle className="w-3 h-3" /> },
      paused: { color: 'bg-yellow-500', icon: <Pause className="w-3 h-3" /> },
      error: { color: 'bg-red-500', icon: <XCircle className="w-3 h-3" /> },
      disabled: { color: 'bg-gray-500', icon: <XCircle className="w-3 h-3" /> }
    };
    
    const config = statusConfig[status as keyof typeof statusConfig] || statusConfig.disabled;
    
    return (
      <Badge className={`${config.color} text-white flex items-center gap-1`}>
        {config.icon}
        {status}
      </Badge>
    );
  };

  const getSeverityBadge = (severity: string) => {
    const severityConfig = {
      low: 'bg-blue-500',
      medium: 'bg-yellow-500',
      high: 'bg-orange-500',
      critical: 'bg-red-500'
    };
    
    return (
      <Badge className={`${severityConfig[severity as keyof typeof severityConfig]} text-white`}>
        {severity}
      </Badge>
    );
  };

  const filteredFeeds = feeds.filter(feed => {
    const matchesSearch = feed.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         feed.jurisdiction.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || feed.status === statusFilter;
    const matchesJurisdiction = jurisdictionFilter === 'all' || feed.jurisdiction === jurisdictionFilter;
    
    return matchesSearch && matchesStatus && matchesJurisdiction;
  });

  const uniqueJurisdictions = Array.from(new Set(feeds.map(f => f.jurisdiction)));
  const unreadAlerts = feedAlerts.filter(alert => !alert.is_read);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-white flex items-center gap-2">
          <MonitorSpeaker className="h-6 w-6" />
          Regulatory Feeds Monitor
        </h2>
        <div className="flex items-center gap-2">
          <Switch
            checked={realTimeUpdates}
            onCheckedChange={setRealTimeUpdates}
          />
          <Label className="text-white">Real-time Updates</Label>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="feeds">Feeds</TabsTrigger>
          <TabsTrigger value="updates">Updates</TabsTrigger>
          <TabsTrigger value="alerts">Alerts</TabsTrigger>
        </TabsList>

        <TabsContent value="feeds" className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Input
                placeholder="Search feeds..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-64"
              />
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-40">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="paused">Paused</SelectItem>
                  <SelectItem value="error">Error</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <Button onClick={() => setShowCreateFeed(true)}>
              <Plus className="h-4 w-4 mr-2" />
              Add Feed
            </Button>
          </div>

          <div className="space-y-4">
            {feeds.map((feed) => (
              <Card key={feed.id} className="border border-gray-200 hover:shadow-md transition-shadow">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <Rss className="h-5 w-5 text-blue-600" />
                        <h3 className="font-semibold">{feed.name}</h3>
                        <Badge variant={feed.status === 'active' ? 'default' : 'secondary'}>
                          {feed.status}
                        </Badge>
                      </div>
                      <div className="text-sm text-gray-600">
                        {feed.jurisdiction} • {feed.feed_type.toUpperCase()} • {feed.update_frequency}
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Button
                        size="sm"
                        onClick={() => processEnhancedFeed(feed.id)}
                        disabled={processingFeeds.has(feed.id)}
                      >
                        {processingFeeds.has(feed.id) ? (
                          <RefreshCw className="h-4 w-4 animate-spin" />
                        ) : (
                          <Play className="h-4 w-4" />
                        )}
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="updates" className="space-y-4">
          <div className="text-center py-8">
            <Activity className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-700 mb-2">No updates found</h3>
            <p className="text-gray-500">Feed updates will appear here when available.</p>
          </div>
        </TabsContent>

        <TabsContent value="alerts" className="space-y-4">
          <div className="text-center py-8">
            <Bell className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-700 mb-2">No alerts</h3>
            <p className="text-gray-500">System alerts will appear here when triggered.</p>
          </div>
        </TabsContent>
      </Tabs>

      {/* Create Feed Dialog */}
      <Dialog open={showCreateFeed} onOpenChange={setShowCreateFeed}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Create New Regulatory Feed</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="name">Feed Name</Label>
                <Input
                  id="name"
                  value={newFeed.name}
                  onChange={(e) => setNewFeed(prev => ({ ...prev, name: e.target.value }))}
                  placeholder="EU Export Control Updates"
                />
              </div>
              <div>
                <Label htmlFor="jurisdiction">Jurisdiction</Label>
                <Input
                  id="jurisdiction"
                  value={newFeed.jurisdiction}
                  onChange={(e) => setNewFeed(prev => ({ ...prev, jurisdiction: e.target.value }))}
                  placeholder="EU"
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="feedType">Feed Type</Label>
                <Select value={newFeed.feed_type} onValueChange={(value: 'rss' | 'api' | 'scraper' | 'manual') => 
                  setNewFeed(prev => ({ ...prev, feed_type: value }))
                }>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="rss">RSS Feed</SelectItem>
                    <SelectItem value="api">API</SelectItem>
                    <SelectItem value="scraper">Web Scraper</SelectItem>
                    <SelectItem value="manual">Manual</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="frequency">Update Frequency</Label>
                <Select value={newFeed.update_frequency} onValueChange={(value: 'hourly' | 'daily' | 'weekly' | 'monthly') => 
                  setNewFeed(prev => ({ ...prev, update_frequency: value }))
                }>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="hourly">Hourly</SelectItem>
                    <SelectItem value="daily">Daily</SelectItem>
                    <SelectItem value="weekly">Weekly</SelectItem>
                    <SelectItem value="monthly">Monthly</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div>
              <Label htmlFor="url">Source URL</Label>
              <Input
                id="url"
                value={newFeed.url}
                onChange={(e) => setNewFeed(prev => ({ ...prev, url: e.target.value }))}
                placeholder="https://example.com/rss.xml"
              />
            </div>
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setShowCreateFeed(false)}>
                Cancel
              </Button>
              <Button onClick={createFeed}>
                Create Feed
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default RegulatoryFeedsInterface;
