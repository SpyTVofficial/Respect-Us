
import React, { useState } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { CreditCard, Receipt, Shield, Clock, CheckCircle, ArrowLeft } from 'lucide-react';
import { toast } from 'sonner';
import brain from 'brain';
import CustomerOnboardingForm, { CustomerDetails } from './CustomerOnboardingForm';
import PriceBreakdown from './PriceBreakdown';
import { VATBreakdown } from '../brain/data-contracts';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  moduleName: string;
  moduleTitle: string;
  price: number;
  onPaymentSuccess?: () => void;
}

type PaymentStep = 'method' | 'customer_details' | 'payment' | 'invoice';

const PaymentDialog = ({
  isOpen,
  onClose,
  moduleName,
  moduleTitle,
  price,
  onPaymentSuccess
}: Props) => {
  const [currentStep, setCurrentStep] = useState<PaymentStep>('method');
  const [selectedMethod, setSelectedMethod] = useState<'card' | 'invoice' | null>(null);
  const [customerDetails, setCustomerDetails] = useState<CustomerDetails | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [vatBreakdown, setVatBreakdown] = useState<VATBreakdown | null>(null);
  const [priceDisplay, setPriceDisplay] = useState<string>('');

  // Function to update VAT preview when customer details change
  const updateVATPreview = async (details: Partial<CustomerDetails>) => {
    if (!details.country) return;
    
    try {
      const response = await brain.get_vat_preview({
        module_name: moduleName,
        customer_country: details.country,
        vat_number: details.vat_number || undefined
      });
      
      if (response.ok) {
        const data = await response.json();
        setVatBreakdown(data.vat_breakdown);
        setPriceDisplay(data.price_display);
      }
    } catch (error) {
      console.error('Error fetching VAT preview:', error);
      // Set fallback breakdown
      setVatBreakdown({
        net_amount: price,
        vat_amount: 0,
        gross_amount: price,
        vat_rate: 0,
        vat_type: 'export',
        country_code: null
      });
      setPriceDisplay(`€${price.toFixed(2)}`);
    }
  };
  
  const handleMethodSelection = (method: 'card' | 'invoice') => {
    setSelectedMethod(method);
    setCurrentStep('customer_details');
  };

  const handleCustomerDetailsSubmit = async (details: CustomerDetails) => {
    setCustomerDetails(details);
    setIsLoading(true);

    try {
      if (selectedMethod === 'card') {
        // Create payment intent with customer details
        const response = await brain.create_payment_intent({
          module_name: moduleName,
          template_id: 1,
          price_amount: price,
          currency: 'EUR',
          customer_details: details
        });

        if (response.ok) {
          const data = await response.json();
          toast.success(`Payment of ${data.vat_breakdown ? `€${data.vat_breakdown.gross_amount.toFixed(2)}` : `€${data.amount.toFixed(2)}`} processed successfully!`);
          onPaymentSuccess?.();
          onClose();
        } else {
          toast.error('Payment processing failed. Please try again.');
        }
      } else if (selectedMethod === 'invoice') {
        // Submit invoice request
        const response = await brain.request_invoice({
          module_name: moduleName,
          template_id: 1,
          customer_details: details,
          special_notes: 'Invoice request for Risk Assessment module access'
        });

        if (response.ok) {
          const data = await response.json();
          toast.success('Invoice request submitted successfully! We will contact you shortly.');
          onPaymentSuccess?.();
          onClose();
        } else {
          toast.error('Invoice request failed. Please try again.');
        }
      }
    } catch (error) {
      console.error('Payment error:', error);
      toast.error('An error occurred. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleBack = () => {
    if (currentStep === 'customer_details') {
      setCurrentStep('method');
      setSelectedMethod(null);
    }
  };

  const resetDialog = () => {
    setCurrentStep('method');
    setSelectedMethod(null);
    setCustomerDetails(null);
    setIsLoading(false);
    setVatBreakdown(null);
    setPriceDisplay('');
  };

  const handleClose = () => {
    resetDialog();
    onClose();
  };

  const renderPaymentMethodStep = () => (
    <div className="space-y-6">
      <div className="text-center space-y-4">
        <div className="inline-flex items-center justify-center w-16 h-16 bg-blue-600/20 rounded-full">
          <Shield className="h-8 w-8 text-blue-400" />
        </div>
        <div>
          <h3 className="text-2xl font-bold text-white">{moduleTitle}</h3>
          <p className="text-gray-400 mt-2">
            Get unlimited access to one risk assessment template
          </p>
        </div>
        <div className="flex items-center justify-center gap-2">
          <span className="text-3xl font-bold text-white">€{price}</span>
          <Badge variant="secondary" className="bg-green-600/20 text-green-400">
            One-time payment
          </Badge>
        </div>
      </div>

      <div className="space-y-4">
        <h4 className="text-lg font-semibold text-white mb-4">Choose Payment Method</h4>
        
        {/* Credit Card Option */}
        <Card 
          className="bg-gray-800/50 border-gray-600 hover:border-blue-500 cursor-pointer transition-colors"
          onClick={() => handleMethodSelection('card')}
        >
          <CardHeader className="pb-3">
            <CardTitle className="text-white flex items-center gap-3">
              <CreditCard className="h-5 w-5 text-blue-400" />
              Credit Card
              <Badge variant="secondary" className="bg-blue-600/20 text-blue-400 ml-auto">
                Instant Access
              </Badge>
            </CardTitle>
            <CardDescription className="text-gray-400">
              Pay securely with your credit card via Stripe. Get immediate access to the module.
            </CardDescription>
          </CardHeader>
        </Card>

        {/* Invoice Option */}
        <Card 
          className="bg-gray-800/50 border-gray-600 hover:border-blue-500 cursor-pointer transition-colors"
          onClick={() => handleMethodSelection('invoice')}
        >
          <CardHeader className="pb-3">
            <CardTitle className="text-white flex items-center gap-3">
              <Receipt className="h-5 w-5 text-green-400" />
              Invoice / Bank Transfer
              <Badge variant="secondary" className="bg-green-600/20 text-green-400 ml-auto">
                <Clock className="h-3 w-3 mr-1" />
                2-3 Days
              </Badge>
            </CardTitle>
            <CardDescription className="text-gray-400">
              Request an invoice for bank transfer. Access granted after payment verification.
            </CardDescription>
          </CardHeader>
        </Card>
      </div>

      <div className="bg-gray-800/30 rounded-lg p-4 space-y-2">
        <div className="flex items-center gap-2 text-sm text-gray-300">
          <CheckCircle className="h-4 w-4 text-green-400" />
          Unlimited access to one selected template
        </div>
        <div className="flex items-center gap-2 text-sm text-gray-300">
          <CheckCircle className="h-4 w-4 text-green-400" />
          Professional compliance documentation
        </div>
        <div className="flex items-center gap-2 text-sm text-gray-300">
          <CheckCircle className="h-4 w-4 text-green-400" />
          Expert-designed risk assessment framework
        </div>
        <div className="flex items-center gap-2 text-sm text-gray-300">
          <CheckCircle className="h-4 w-4 text-green-400" />
          Email support and guidance
        </div>
      </div>
    </div>
  );

  const renderCustomerDetailsStep = () => (
    <div className="space-y-4">
      <div className="flex items-center gap-2 mb-4">
        <Button
          variant="ghost"
          size="sm"
          onClick={handleBack}
          className="text-gray-400 hover:text-white p-2"
        >
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <div>
          <h3 className="text-lg font-semibold text-white">
            {selectedMethod === 'card' ? 'Complete Payment' : 'Request Invoice'}
          </h3>
          <p className="text-sm text-gray-400">
            {selectedMethod === 'card' 
              ? 'Provide your details to complete the secure payment'
              : 'Provide your details to request an invoice for bank transfer'
            }
          </p>
        </div>
      </div>

      <CustomerOnboardingForm
        onSubmit={handleCustomerDetailsSubmit}
        onCancel={handleBack}
        isLoading={isLoading}
        title={selectedMethod === 'card' ? 'Payment Details' : 'Invoice Request'}
        description={selectedMethod === 'card' 
          ? 'Complete your purchase with secure payment processing'
          : 'We will send you an invoice for bank transfer payment'
        }
        onDetailsChange={updateVATPreview}
      />
      
      {/* VAT Breakdown */}
      {vatBreakdown && (
        <div className="mt-6">
          <PriceBreakdown
            basePrice={price}
            currency="EUR"
            country={customerDetails?.country || ''}
            vatNumber={customerDetails?.vat_number}
            vatBreakdown={vatBreakdown}
          />
        </div>
      )}
    </div>
  );

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto bg-gray-900/95 backdrop-blur-sm border-gray-700">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold text-white">
            {currentStep === 'method' ? 'Access Premium Module' : 'Complete Purchase'}
          </DialogTitle>
          <DialogDescription className="text-gray-400">
            {currentStep === 'method' 
              ? 'Choose your preferred payment method to unlock the Risk Assessment module'
              : 'Please provide your information to complete the transaction'
            }
          </DialogDescription>
        </DialogHeader>

        {currentStep === 'method' && renderPaymentMethodStep()}
        {currentStep === 'customer_details' && renderCustomerDetailsStep()}
      </DialogContent>
    </Dialog>
  );
};

export default PaymentDialog;
