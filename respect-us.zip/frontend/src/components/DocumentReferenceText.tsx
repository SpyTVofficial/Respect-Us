import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import brain from 'brain';
import { Button } from '@/components/ui/button';
import { ExternalLink, AlertCircle } from 'lucide-react';
import { toast } from 'sonner';

interface DocumentReference {
  reference_id: string;
  document_id: number | null;
  title: string | null;
  description: string | null;
  url: string | null;
  status: 'found' | 'not_found' | 'error';
  error_message: string | null;
}

interface Props {
  children: string;
  className?: string;
}

/**
 * Component that automatically converts document references (DOC-123, KB-456) in text to clickable links
 */
export default function DocumentReferenceText({ children, className = '' }: Props) {
  const [processedText, setProcessedText] = useState<React.ReactNode>(children);
  const [references, setReferences] = useState<DocumentReference[]>([]);
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const processReferences = async () => {
      try {
        setLoading(true);
        
        // Extract references from text
        const extractResponse = await brain.extract_references_from_text_endpoint({ text: children });
        if (!extractResponse.ok) {
          console.error('Failed to extract references');
          setProcessedText(children);
          return;
        }
        
        const extractData = await extractResponse.json();
        const foundReferences = extractData.references;
        
        if (!foundReferences || foundReferences.length === 0) {
          setProcessedText(children);
          return;
        }
        
        // Resolve the references to get document info
        const resolveResponse = await brain.resolve_references(foundReferences);
        if (!resolveResponse.ok) {
          console.error('Failed to resolve references');
          setProcessedText(children);
          return;
        }
        
        const resolveData = await resolveResponse.json();
        setReferences(resolveData.resolved);
        
        // Process the text to replace references with clickable links
        let processedContent = children;
        const referenceParts: React.ReactNode[] = [];
        let lastIndex = 0;
        
        // Sort references by their position in the text
        const sortedRefs = [...resolveData.resolved].sort((a, b) => {
          const indexA = children.indexOf(a.reference_id);
          const indexB = children.indexOf(b.reference_id);
          return indexA - indexB;
        });
        
        sortedRefs.forEach((ref: DocumentReference, index) => {
          const refIndex = children.indexOf(ref.reference_id, lastIndex);
          if (refIndex === -1) return;
          
          // Add text before this reference
          if (refIndex > lastIndex) {
            referenceParts.push(children.substring(lastIndex, refIndex));
          }
          
          // Add the reference as a clickable component
          if (ref.status === 'found' && ref.document_id) {
            referenceParts.push(
              <Button
                key={`ref-${index}-${ref.reference_id}`}
                variant="link"
                className="p-0 h-auto text-blue-600 hover:text-blue-800 underline font-normal"
                onClick={() => {
                  navigate(`/document-reader?documentId=${ref.document_id}`);
                }}
                title={ref.title || ref.description || 'Open document'}
              >
                {ref.reference_id}
                <ExternalLink className="ml-1 h-3 w-3" />
              </Button>
            );
          } else {
            // Show as non-clickable with error indicator
            referenceParts.push(
              <span
                key={`ref-${index}-${ref.reference_id}`}
                className="inline-flex items-center text-gray-500"
                title={ref.error_message || 'Document not found'}
              >
                {ref.reference_id}
                <AlertCircle className="ml-1 h-3 w-3 text-yellow-500" />
              </span>
            );
          }
          
          lastIndex = refIndex + ref.reference_id.length;
        });
        
        // Add any remaining text
        if (lastIndex < children.length) {
          referenceParts.push(children.substring(lastIndex));
        }
        
        setProcessedText(referenceParts.length > 0 ? referenceParts : children);
        
      } catch (error) {
        console.error('Error processing document references:', error);
        setProcessedText(children);
      } finally {
        setLoading(false);
      }
    };
    
    if (children && children.trim()) {
      processReferences();
    } else {
      setProcessedText(children);
    }
  }, [children, navigate]);
  
  if (loading) {
    return (
      <div className={`${className} animate-pulse`}>
        {children}
      </div>
    );
  }
  
  return (
    <div className={className}>
      {processedText}
    </div>
  );
}

// Helper component for displaying reference statistics
export function DocumentReferenceStats({ references }: { references: DocumentReference[] }) {
  const foundCount = references.filter(ref => ref.status === 'found').length;
  const notFoundCount = references.filter(ref => ref.status === 'not_found').length;
  const errorCount = references.filter(ref => ref.status === 'error').length;
  
  if (references.length === 0) return null;
  
  return (
    <div className="text-sm text-gray-500 mt-2">
      Document references: {foundCount} found, {notFoundCount} not found
      {errorCount > 0 && `, ${errorCount} errors`}
    </div>
  );
}
