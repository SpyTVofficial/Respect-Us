
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Coins, CreditCard, History, ShoppingCart } from 'lucide-react';
import { toast } from 'sonner';
import brain from 'brain';
import { CreditBalance, PaymentIntentResponse, CreditTransaction, CreditPackage } from '../brain/data-contracts';
import { useUserGuardContext } from 'app/auth';

interface Props {
  showTransactions?: boolean;
  className?: string;
}

export const CreditBalanceWidget: React.FC<Props> = ({ showTransactions = true, className = "" }) => {
  const { user } = useUserGuardContext();
  const [balance, setBalance] = useState<CreditBalance | null>(null);
  const [transactions, setTransactions] = useState<CreditTransaction[]>([]);
  const [packages, setPackages] = useState<CreditPackage[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [showPurchaseDialog, setShowPurchaseDialog] = useState(false);
  const [showTransactionHistory, setShowTransactionHistory] = useState(false);
  const [selectedPackage, setSelectedPackage] = useState<CreditPackage | null>(null);
  const [isProcessingPurchase, setIsProcessingPurchase] = useState(false);

  useEffect(() => {
    loadCreditData();
  }, []);

  const loadCreditData = async () => {
    try {
      setIsLoading(true);
      const [balanceResponse, packagesResponse] = await Promise.all([
        brain.get_credit_balance(),
        brain.get_credit_packages()
      ]);

      if (balanceResponse.ok) {
        const balanceData = await balanceResponse.json();
        setBalance(balanceData);
      }

      if (packagesResponse.ok) {
        const packagesData = await packagesResponse.json();
        setPackages(packagesData);
      }
    } catch (error) {
      console.error('Error loading credit data:', error);
      toast.error('Failed to load credit information');
    } finally {
      setIsLoading(false);
    }
  };

  const loadTransactionHistory = async () => {
    try {
      const response = await brain.get_credit_transactions({ limit: 20 });
      if (response.ok) {
        const data = await response.json();
        setTransactions(data);
      }
    } catch (error) {
      console.error('Error loading transactions:', error);
      toast.error('Failed to load transaction history');
    }
  };

  const handlePurchaseCredits = async (pkg: CreditPackage) => {
    try {
      setIsProcessingPurchase(true);
      
      // Create payment intent for the selected package
      const response = await brain.create_payment_intent({
        module_name: "credit_purchase",
        price_amount: pkg.price_cents / 100,
        currency: "EUR",
        customer_details: {
          company_name: "Default Company",
          contact_person: user.displayName || "User",
          email: user.primaryEmail || "",
          billing_address: "Default Address",
          city: "Default City",
          postal_code: "00000",
          country: "DE"
        }
      });

      if (response.ok) {
        const data = await response.json();
        // Redirect to payment URL - using client_secret as the URL to redirect to
        if (data.client_secret) {
          window.location.href = data.client_secret;
        } else {
          toast.error('No payment URL received');
        }
      } else {
        toast.error('Failed to initiate purchase');
      }
    } catch (error) {
      console.error('Error purchasing credits:', error);
      toast.error('Failed to purchase credits');
    } finally {
      setIsProcessingPurchase(false);
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getTransactionTypeColor = (type: string) => {
    switch (type) {
      case 'purchase':
        return 'bg-green-500';
      case 'consume':
        return 'bg-red-500';
      case 'refund':
        return 'bg-blue-500';
      case 'admin_adjustment':
        return 'bg-yellow-500';
      default:
        return 'bg-gray-500';
    }
  };

  if (isLoading) {
    return (
      <Card className={`${className} animate-pulse`}>
        <CardContent className="p-6">
          <div className="flex items-center space-x-4">
            <div className="w-12 h-12 bg-gray-700 rounded-full"></div>
            <div className="space-y-2">
              <div className="w-24 h-4 bg-gray-700 rounded"></div>
              <div className="w-32 h-6 bg-gray-700 rounded"></div>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <>
      <Card className={`${className} border-gray-700 bg-gray-800/50 backdrop-blur-sm`}>
        <CardContent className="p-4">
          <div className="flex items-center justify-between gap-4">
            {/* Left side - Balance display */}
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <Coins className="h-5 w-5 text-yellow-500" />
                <div>
                  <p className="text-lg font-bold text-yellow-500">
                    {balance?.current_balance?.toLocaleString() || '0'}
                  </p>
                  <p className="text-xs text-gray-400">Credits</p>
                </div>
              </div>
              
              {/* Statistics - horizontal layout */}
              {balance && (
                <div className="flex items-center gap-6 pl-4 border-l border-gray-700">
                  <div className="text-center">
                    <p className="text-sm font-semibold text-green-500">
                      {balance.lifetime_purchased.toLocaleString()}
                    </p>
                    <p className="text-xs text-gray-400">Purchased</p>
                  </div>
                  <div className="text-center">
                    <p className="text-sm font-semibold text-red-500">
                      {balance.lifetime_consumed.toLocaleString()}
                    </p>
                    <p className="text-xs text-gray-400">Used</p>
                  </div>
                </div>
              )}
            </div>
            
            {/* Right side - Actions */}
            <div className="flex items-center gap-2">
              {showTransactions && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    loadTransactionHistory();
                    setShowTransactionHistory(true);
                  }}
                >
                  <History className="h-4 w-4 mr-1" />
                  History
                </Button>
              )}
              <Button
                onClick={() => setShowPurchaseDialog(true)}
                size="sm"
                className="bg-blue-600 hover:bg-blue-700"
              >
                <ShoppingCart className="h-4 w-4 mr-1" />
                Buy Credits
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Purchase Credits Dialog */}
      <Dialog open={showPurchaseDialog} onOpenChange={setShowPurchaseDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center">
              <CreditCard className="h-5 w-5 mr-2" />
              Purchase Credits
            </DialogTitle>
            <DialogDescription>
              Choose a credit package to add to your account
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            {packages.map((pkg) => (
              <div
                key={pkg.id}
                className={`p-4 border rounded-lg cursor-pointer transition-colors ${
                  selectedPackage?.id === pkg.id
                    ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20'
                    : 'border-gray-300 hover:border-gray-400'
                }`}
                onClick={() => setSelectedPackage(pkg)}
              >
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-semibold">{pkg.name}</h3>
                    <p className="text-sm text-gray-600 dark:text-gray-400">
                      {pkg.credits.toLocaleString()} credits
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-lg">
                      €{(pkg.price_cents / 100).toFixed(2)} + VAT if applicable
                    </p>
                    {pkg.discount_percentage > 0 && (
                      <Badge variant="default" className="text-xs">
                        {pkg.discount_percentage}% off
                      </Badge>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setShowPurchaseDialog(false)}
            >
              Cancel
            </Button>
            <Button
              onClick={() => selectedPackage && handlePurchaseCredits(selectedPackage)}
              disabled={!selectedPackage || isProcessingPurchase}
              className="bg-blue-600 hover:bg-blue-700"
            >
              {isProcessingPurchase ? 'Processing...' : 'Purchase Credits'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Transaction History Dialog */}
      <Dialog open={showTransactionHistory} onOpenChange={setShowTransactionHistory}>
        <DialogContent className="sm:max-w-4xl">
          <DialogHeader>
            <DialogTitle className="flex items-center">
              <History className="h-5 w-5 mr-2" />
              Credit Transaction History
            </DialogTitle>
            <DialogDescription>
              Your complete credit transaction history
            </DialogDescription>
          </DialogHeader>
          
          <div className="max-h-96 overflow-y-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Date</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Description</TableHead>
                  <TableHead className="text-right">Amount</TableHead>
                  <TableHead className="text-right">Balance</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {transactions.map((transaction) => (
                  <TableRow key={transaction.id}>
                    <TableCell className="text-sm">
                      {formatDate(transaction.created_at.toString())}
                    </TableCell>
                    <TableCell>
                      <Badge
                        variant="outline"
                        className={`${getTransactionTypeColor(transaction.transaction_type)} text-white`}
                      >
                        {transaction.transaction_type}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-sm">
                      {transaction.description || `${transaction.component_name} - ${transaction.action_name}`}
                    </TableCell>
                    <TableCell className={`text-right font-medium ${
                      transaction.amount > 0 ? 'text-green-500' : 'text-red-500'
                    }`}>
                      {transaction.amount > 0 ? '+' : ''}{transaction.amount}
                    </TableCell>
                    <TableCell className="text-right">
                      {transaction.balance_after.toLocaleString()}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setShowTransactionHistory(false)}
            >
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
};
