import React from 'react';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Trash2 } from 'lucide-react';
import DocumentEditor from 'components/DocumentEditor';
import { DocumentResponse, AppApisCategoriesCategoryResponse as CategoryResponse } from '../brain/data-contracts';

interface DocumentManagementDialogsProps {
  // Edit Dialog
  showDocumentDialog: boolean;
  setShowDocumentDialog: (show: boolean) => void;
  selectedDocument: DocumentResponse | null;
  
  // Delete Dialog
  showDeleteDialog: boolean;
  setShowDeleteDialog: (show: boolean) => void;
  documentToDelete: number | null;
  setDocumentToDelete: (id: number | null) => void;
  
  // Handlers
  handleDeleteDocument: (id: number) => Promise<void>;
  loadData: () => void;
}

const DocumentManagementDialogs: React.FC<DocumentManagementDialogsProps> = ({
  showDocumentDialog,
  setShowDocumentDialog,
  selectedDocument,
  showDeleteDialog,
  setShowDeleteDialog,
  documentToDelete,
  setDocumentToDelete,
  handleDeleteDocument,
  loadData
}) => {
  const handleDocumentSave = (updatedDocument: DocumentResponse) => {
    // Close dialog and refresh data
    setShowDocumentDialog(false);
    loadData();
  };

  return (
    <>
      {/* Document Edit Dialog */}
      <Dialog open={showDocumentDialog} onOpenChange={setShowDocumentDialog}>
        <DialogContent className="bg-gray-800 border-gray-700 max-w-4xl max-h-[80vh] overflow-y-auto">
          {selectedDocument ? (
            <DocumentEditor
              documentId={selectedDocument.id}
              document={selectedDocument}
              onDocumentUpdated={handleDocumentSave}
              onClose={() => setShowDocumentDialog(false)}
            />
          ) : (
            <div className="p-4 text-white">
              <p>🔍 Debug: No selectedDocument provided</p>
              <p>showDocumentDialog: {showDocumentDialog.toString()}</p>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Document Delete Dialog */}
      <Dialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <DialogContent className="bg-gray-800 border-gray-700">
          <DialogHeader>
            <DialogTitle className="text-red-400">Confirm Deletion</DialogTitle>
            <DialogDescription className="text-gray-400">
              Are you sure you want to delete this document? This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                setShowDeleteDialog(false);
                setDocumentToDelete(null);
              }}
              className="text-gray-300 border-gray-600 hover:bg-gray-700"
            >
              Cancel
            </Button>
            <Button
              onClick={async () => {
                if (documentToDelete) {
                  await handleDeleteDocument(documentToDelete);
                  setShowDeleteDialog(false);
                  setDocumentToDelete(null);
                }
              }}
              className="bg-red-600 hover:bg-red-700 text-white"
            >
              <Trash2 className="w-4 h-4 mr-2" />
              Delete Document
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default DocumentManagementDialogs;
