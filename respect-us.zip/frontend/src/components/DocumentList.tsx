import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { FileText, Eye, BarChart3, Calendar } from 'lucide-react';
import { DocumentResponse } from 'types';

export interface Props {
  documents: DocumentResponse[];
  onDocumentClick: (document: DocumentResponse) => void;
  onDocumentStructureClick: (document: DocumentResponse) => void;
}

export const DocumentList: React.FC<Props> = ({ 
  documents, 
  onDocumentClick, 
  onDocumentStructureClick 
}) => {
  return (
    <div className="space-y-4">
      {documents.map((document) => (
        <Card 
          key={document.id} 
          className="bg-gray-800/30 border-gray-700 hover:bg-gray-800/50 transition-colors"
        >
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-3 mb-2">
                  <FileText className="h-5 w-5 text-blue-400 flex-shrink-0" />
                  <h3 className="text-lg font-semibold text-white truncate">
                    {document.title}
                  </h3>
                </div>
                
                {document.description && (
                  <p className="text-gray-300 mb-3 line-clamp-2">
                    {document.description}
                  </p>
                )}
                
                <div className="flex flex-wrap gap-2 mb-3">
                  {document.file_type && (
                    <Badge variant="secondary" className="bg-blue-900/30 text-blue-300">
                      {document.file_type.toUpperCase()}
                    </Badge>
                  )}
                  {document.file_size && (
                    <Badge variant="outline" className="border-gray-600 text-gray-300">
                      {(document.file_size / 1024 / 1024).toFixed(1)} MB
                    </Badge>
                  )}
                  {document.created_at && (
                    <Badge variant="outline" className="border-gray-600 text-gray-300">
                      <Calendar className="h-3 w-3 mr-1" />
                      {new Date(document.created_at).toLocaleDateString()}
                    </Badge>
                  )}
                </div>
              </div>
              
              <div className="flex gap-2 ml-4 flex-shrink-0">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => onDocumentClick(document)}
                  className="border-gray-600 hover:bg-gray-700"
                >
                  <Eye className="h-4 w-4 mr-2" />
                  View
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => onDocumentStructureClick(document)}
                  className="border-gray-600 hover:bg-gray-700"
                >
                  <BarChart3 className="h-4 w-4 mr-2" />
                  Structure
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
};
