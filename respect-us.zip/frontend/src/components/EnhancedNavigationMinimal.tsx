import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useUser } from '@stackframe/react';
import { Badge } from '@/components/ui/badge';
import { BookOpen, Shield, Scale } from 'lucide-react';

interface EnhancedNavigationProps {
  currentPage?: string;
  showBreadcrumb?: boolean;
  variant?: 'full' | 'compact' | 'minimal';
}

export default function EnhancedNavigationMinimal({
  currentPage,
  showBreadcrumb = true,
  variant = 'full'
}: EnhancedNavigationProps) {
  const navigate = useNavigate();
  const user = useUser();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  // Simple module definitions to test
  const coreModules = [
    {
      id: 'knowledge_base',
      title: 'Knowledge Base',
      description: 'Access regulatory documentation',
      icon: BookOpen,
      path: '/knowledge-base',
      status: 'free' as const,
      color: 'text-blue-400'
    },
    {
      id: 'product_classification',
      title: 'Product Classification',
      description: 'Classify products for export control',
      icon: Shield,
      path: '/product-classification',
      status: 'premium' as const,
      color: 'text-green-400'
    }
  ];

  const handleModuleClick = (moduleId: string, path: string, status: string) => {
    if (status === 'coming_soon') return;

    if (!user && status !== 'free') {
      navigate('/auth/sign-in');
      return;
    }

    navigate(path);
    setIsMobileMenuOpen(false);
  };

  return (
    <nav className="bg-gray-900/95 backdrop-blur-sm border-b border-gray-800 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex items-center space-x-4">
            <button
              onClick={() => navigate('/')}
              className="flex items-center space-x-2 text-white hover:text-blue-400 transition-colors"
            >
              <Scale className="w-6 h-6" />
              <span className="font-bold text-lg hidden sm:block">RespectUs</span>
            </button>
          </div>

          {/* Navigation Items */}
          <div className="hidden md:flex items-center space-x-6">
            {coreModules.map((module) => (
              <button
                key={module.id}
                onClick={() => handleModuleClick(module.id, module.path, module.status)}
                className="text-gray-300 hover:text-white px-3 py-2 rounded-md text-sm font-medium transition-colors"
              >
                {module.title}
              </button>
            ))}
          </div>

          {/* User Menu */}
          <div className="flex items-center space-x-4">
            {user ? (
              <div className="text-sm text-gray-300">
                Welcome, {user.displayName || 'User'}
              </div>
            ) : (
              <button
                onClick={() => navigate('/auth/sign-in')}
                className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md text-sm font-medium transition-colors"
              >
                Sign In
              </button>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
}
