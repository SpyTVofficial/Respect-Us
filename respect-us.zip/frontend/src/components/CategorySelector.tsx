


import React, { useState, useEffect } from 'react';
import { toast } from 'sonner';
import brain from 'brain';
import { AppApisSavedArticlesCategoryResponse } from 'types';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { 
  Folder, 
  FileText, 
  Star, 
  Shield, 
  AlertTriangle, 
  BookOpen,
  X,
  Settings
} from 'lucide-react';
import { CategoryManagementDialog } from 'components/CategoryManagementDialog';

interface Props {
  selectedCategoryIds: number[];
  onCategoryChange: (categoryIds: number[]) => void;
  multiSelect?: boolean;
  placeholder?: string;
  className?: string;
}

const ICON_MAP: Record<string, React.ComponentType<any>> = {
  'folder': Folder,
  'file-text': FileText,
  'star': Star,
  'shield': Shield,
  'alert-triangle': AlertTriangle,
  'book-open': BookOpen,
};

const getIconComponent = (iconName: string) => {
  return ICON_MAP[iconName] || Folder;
};

export const CategorySelector: React.FC<Props> = ({
  selectedCategoryIds,
  onCategoryChange,
  multiSelect = true,
  placeholder = "Select categories...",
  className = ""
}) => {
  const [categories, setCategories] = useState<AppApisSavedArticlesCategoryResponse[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [showManagementDialog, setShowManagementDialog] = useState(false);

  // Load categories
  const loadCategories = async () => {
    try {
      setIsLoading(true);
      const response = await brain.get_article_categories();
      const data = await response.json();
      setCategories(data);
    } catch (error) {
      console.error('Error loading categories:', error);
      toast.error('Failed to load categories');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadCategories();
  }, []);

  const handleCategoryToggle = (categoryId: number) => {
    if (multiSelect) {
      const newSelection = selectedCategoryIds.includes(categoryId)
        ? selectedCategoryIds.filter(id => id !== categoryId)
        : [...selectedCategoryIds, categoryId];
      onCategoryChange(newSelection);
    } else {
      onCategoryChange(selectedCategoryIds.includes(categoryId) ? [] : [categoryId]);
    }
  };

  const getSelectedCategoryNames = () => {
    return categories
      .filter(cat => selectedCategoryIds.includes(cat.id))
      .map(cat => cat.name)
      .join(', ');
  };

  if (categories.length === 0) {
    return (
      <div className={`space-y-3 ${className}`}>
        <div className="flex items-center justify-between">
          <Label className="text-sm font-medium text-white">Categories (Optional)</Label>
          <Button 
            variant="ghost" 
            size="sm"
            onClick={() => setShowManagementDialog(true)}
            className="text-blue-400 hover:text-blue-300 hover:bg-blue-400/10 p-1 h-auto"
          >
            <Settings className="w-4 h-4" />
          </Button>
        </div>
        <div className="text-sm text-gray-400 p-3 border border-gray-700 rounded-lg">
          <p className="mb-2">No categories yet. Articles will be saved as "Uncategorized".</p>
          <Button 
            variant="outline" 
            size="sm" 
            onClick={() => setShowManagementDialog(true)}
            className="text-blue-400 border-blue-400 hover:bg-blue-400/10"
          >
            Create Categories
          </Button>
        </div>
        
        <CategoryManagementDialog
          isOpen={showManagementDialog}
          onClose={() => setShowManagementDialog(false)}
          onCategoryCreated={loadCategories}
        />
      </div>
    );
  }

  if (multiSelect) {
    return (
      <div className={`space-y-3 ${className}`}>
        <div className="flex items-center justify-between">
          <Label className="text-sm font-medium text-white">
            Categories {selectedCategoryIds.length > 0 && `(${selectedCategoryIds.length} selected)`}
          </Label>
          <Button 
            variant="ghost" 
            size="sm"
            onClick={() => setShowManagementDialog(true)}
            className="text-blue-400 hover:text-blue-300 hover:bg-blue-400/10 p-1 h-auto"
          >
            <Settings className="w-4 h-4" />
          </Button>
        </div>
        <div className="space-y-2 max-h-40 overflow-y-auto">
          {categories.map((category) => {
            const IconComponent = getIconComponent(category.icon);
            const isSelected = selectedCategoryIds.includes(category.id);
            
            return (
              <div 
                key={category.id}
                className="flex items-center space-x-3 p-2 rounded-lg hover:bg-gray-800/50 transition-colors cursor-pointer"
                onClick={() => handleCategoryToggle(category.id)}
              >
                <Checkbox
                  checked={isSelected}
                  onCheckedChange={() => handleCategoryToggle(category.id)}
                  className="data-[state=checked]:bg-blue-600 data-[state=checked]:border-blue-600"
                />
                <div className="flex items-center gap-2 flex-1">
                  <div 
                    className="p-1 rounded"
                    style={{ backgroundColor: `${category.color}20` }}
                  >
                    <IconComponent className="w-4 h-4" style={{ color: category.color }} />
                  </div>
                  <span className="text-sm text-white">{category.name}</span>
                  <Badge variant="secondary" className="text-xs">
                    {category.article_count}
                  </Badge>
                </div>
              </div>
            );
          })}
        </div>
        {selectedCategoryIds.length > 0 && (
          <div className="flex flex-wrap gap-1 mt-2">
            {categories
              .filter(cat => selectedCategoryIds.includes(cat.id))
              .map(cat => {
                const IconComponent = getIconComponent(cat.icon);
                return (
                  <Badge 
                    key={cat.id} 
                    variant="secondary" 
                    className="flex items-center gap-1 bg-gray-800 text-white border border-gray-600"
                  >
                    <IconComponent className="w-3 h-3" style={{ color: cat.color }} />
                    {cat.name}
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleCategoryToggle(cat.id);
                      }}
                      className="ml-1 hover:bg-gray-700 rounded"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </Badge>
                );
              })}
          </div>
        )}
        
        <CategoryManagementDialog
          isOpen={showManagementDialog}
          onClose={() => setShowManagementDialog(false)}
          onCategoryCreated={loadCategories}
        />
      </div>
    );
  }

  // Single select mode
  return (
    <div className={`space-y-2 ${className}`}>
      <div className="flex items-center justify-between">
        <Label className="text-sm font-medium text-white">Category</Label>
        <Button 
          variant="ghost" 
          size="sm"
          onClick={() => setShowManagementDialog(true)}
          className="text-blue-400 hover:text-blue-300 hover:bg-blue-400/10 p-1 h-auto"
        >
          <Settings className="w-4 h-4" />
        </Button>
      </div>
      <Select
        value={selectedCategoryIds[0]?.toString() || ""}
        onValueChange={(value) => {
          if (value) {
            onCategoryChange([parseInt(value)]);
          } else {
            onCategoryChange([]);
          }
        }}
      >
        <SelectTrigger className="bg-gray-800 border-gray-700 text-white">
          <SelectValue placeholder={placeholder} />
        </SelectTrigger>
        <SelectContent className="bg-gray-800 border-gray-700">
          <SelectItem value="" className="text-gray-400">
            No category
          </SelectItem>
          {categories.map((category) => {
            const IconComponent = getIconComponent(category.icon);
            return (
              <SelectItem 
                key={category.id} 
                value={category.id.toString()}
                className="text-white hover:bg-gray-700"
              >
                <div className="flex items-center gap-2">
                  <div 
                    className="p-1 rounded"
                    style={{ backgroundColor: `${category.color}20` }}
                  >
                    <IconComponent className="w-3 h-3" style={{ color: category.color }} />
                  </div>
                  {category.name}
                  <Badge variant="secondary" className="text-xs ml-auto">
                    {category.article_count}
                  </Badge>
                </div>
              </SelectItem>
            );
          })}
        </SelectContent>
      </Select>
      
      <CategoryManagementDialog
        isOpen={showManagementDialog}
        onClose={() => setShowManagementDialog(false)}
        onCategoryCreated={loadCategories}
      />
    </div>
  );
};
