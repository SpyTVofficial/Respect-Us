import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, PieChart, Pie, Cell } from 'recharts';
import { Users, CreditCard, TrendingUp, Activity, DollarSign, Target } from 'lucide-react';
import brain from 'brain';
import { toast } from 'sonner';

interface AdminUsageAnalytics {
  total_users: number;
  active_users_last_30_days: number;
  total_credits_consumed_all_time: number;
  total_credits_consumed_last_30_days: number;
  average_credits_per_user: number;
  top_components_by_usage: ComponentUsage[];
  revenue_analytics: {
    total_credits_purchased: number;
    total_revenue: number;
    average_purchase_size: number;
  };
  user_engagement_metrics: {
    daily_active_users: number;
    retention_rate: number;
    churn_rate: number;
  };
}

interface ComponentUsage {
  component_name: string;
  action_name: string;
  total_usage: number;
  total_cost: number;
  usage_count: number;
  avg_cost_per_action: number;
  last_used: string;
  percentage_of_total: number;
}

interface RealTimeDashboard {
  real_time_metrics: {
    active_users_today: number;
    credits_consumed_today: number;
    total_actions_today: number;
    actions_this_hour: number;
    transactions_last_hour: number;
  };
  system_health: {
    status: string;
    transaction_rate: number;
    error_rate: number;
    response_time: string;
  };
  timestamp: string;
}

const AdminAnalyticsDashboard: React.FC = () => {
  const [analytics, setAnalytics] = useState<AdminUsageAnalytics | null>(null);
  const [realTimeData, setRealTimeData] = useState<RealTimeDashboard | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('overview');

  useEffect(() => {
    loadAnalyticsData();
    // Update real-time data every 30 seconds
    const interval = setInterval(loadRealTimeData, 30000);
    return () => clearInterval(interval);
  }, []);

  const loadAnalyticsData = async () => {
    try {
      setLoading(true);
      const [analyticsRes, realTimeRes] = await Promise.all([
        brain.get_admin_usage_analytics(),
        brain.get_admin_real_time_dashboard()
      ]);

      setAnalytics(await analyticsRes.json());
      setRealTimeData(await realTimeRes.json());
    } catch (error) {
      console.error('Error loading admin analytics:', error);
      toast.error('Failed to load analytics data');
    } finally {
      setLoading(false);
    }
  };

  const loadRealTimeData = async () => {
    try {
      const response = await brain.get_admin_real_time_dashboard();
      setRealTimeData(await response.json());
    } catch (error) {
      console.error('Error loading real-time data:', error);
    }
  };

  const CHART_COLORS = ['#8884d8', '#82ca9d', '#ffc658', '#ff7300', '#8dd1e1', '#d084d0'];

  if (loading && !analytics) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading admin analytics...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Admin Analytics</h1>
          <p className="text-gray-600">System-wide usage analytics and performance metrics</p>
        </div>
        <div className="flex items-center space-x-2">
          <Badge variant="outline" className="text-xs">
            Last updated: {realTimeData ? new Date(realTimeData.timestamp).toLocaleTimeString() : 'N/A'}
          </Badge>
          <Button onClick={loadAnalyticsData} size="sm" variant="outline">
            Refresh
          </Button>
        </div>
      </div>

      {/* Real-Time Metrics */}
      {realTimeData && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center">
                <Users className="h-4 w-4 mr-2 text-blue-600" />
                Active Today
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-blue-600">
                {realTimeData.real_time_metrics.active_users_today}
              </div>
              <p className="text-xs text-gray-600">users</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center">
                <CreditCard className="h-4 w-4 mr-2 text-purple-600" />
                Credits Today
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-purple-600">
                {realTimeData.real_time_metrics.credits_consumed_today.toLocaleString()}
              </div>
              <p className="text-xs text-gray-600">consumed</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center">
                <Activity className="h-4 w-4 mr-2 text-green-600" />
                Actions Today
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600">
                {realTimeData.real_time_metrics.total_actions_today.toLocaleString()}
              </div>
              <p className="text-xs text-gray-600">performed</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center">
                <TrendingUp className="h-4 w-4 mr-2 text-orange-600" />
                This Hour
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-orange-600">
                {realTimeData.real_time_metrics.actions_this_hour}
              </div>
              <p className="text-xs text-gray-600">actions</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center">
                <Target className="h-4 w-4 mr-2 text-red-600" />
                System Health
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-lg font-bold text-green-600">
                {realTimeData.system_health.status.toUpperCase()}
              </div>
              <p className="text-xs text-gray-600">{realTimeData.system_health.response_time}</p>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Main Analytics */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="usage">Usage Analysis</TabsTrigger>
          <TabsTrigger value="revenue">Revenue</TabsTrigger>
          <TabsTrigger value="optimization">Optimization</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          {analytics && (
            <>
              {/* Overview Stats */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium">Total Users</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{analytics.total_users.toLocaleString()}</div>
                    <p className="text-xs text-gray-600">registered users</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium">Active Users (30d)</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold text-green-600">
                      {analytics.active_users_last_30_days.toLocaleString()}
                    </div>
                    <p className="text-xs text-gray-600">
                      {((analytics.active_users_last_30_days / Math.max(analytics.total_users, 1)) * 100).toFixed(1)}% of total
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium">Credits Consumed (All Time)</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold text-purple-600">
                      {analytics.total_credits_consumed_all_time.toLocaleString()}
                    </div>
                    <p className="text-xs text-gray-600">total credits</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium">Avg Credits/User</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold text-blue-600">
                      {analytics.average_credits_per_user.toFixed(0)}
                    </div>
                    <p className="text-xs text-gray-600">per user lifetime</p>
                  </CardContent>
                </Card>
              </div>

              {/* Usage Distribution */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Top Components by Usage</CardTitle>
                    <CardDescription>Most popular features</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={300}>
                      <BarChart data={analytics.top_components_by_usage.slice(0, 8)}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis 
                          dataKey="component_name" 
                          tick={{ fontSize: 10 }}
                          angle={-45}
                          textAnchor="end"
                          height={60}
                        />
                        <YAxis tick={{ fontSize: 12 }} />
                        <Tooltip 
                          formatter={(value, name) => [
                            `${value} credits`, 
                            name === 'total_cost' ? 'Total Cost' : name
                          ]}
                        />
                        <Bar dataKey="total_cost" fill="#8884d8" />
                      </BarChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Usage Distribution</CardTitle>
                    <CardDescription>Credit consumption by component</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={300}>
                      <PieChart>
                        <Pie
                          data={analytics.top_components_by_usage.slice(0, 6)}
                          cx="50%"
                          cy="50%"
                          outerRadius={80}
                          dataKey="total_cost"
                          nameKey="component_name"
                        >
                          {analytics.top_components_by_usage.slice(0, 6).map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={CHART_COLORS[index % CHART_COLORS.length]} />
                          ))}
                        </Pie>
                        <Tooltip formatter={(value) => [`${value} credits`, 'Usage']} />
                      </PieChart>
                    </ResponsiveContainer>
                    <div className="mt-4 grid grid-cols-2 gap-2 text-xs">
                      {analytics.top_components_by_usage.slice(0, 6).map((usage, index) => (
                        <div key={usage.component_name} className="flex items-center gap-2">
                          <div 
                            className="w-3 h-3 rounded" 
                            style={{ backgroundColor: CHART_COLORS[index % CHART_COLORS.length] }}
                          />
                          <span className="truncate">{usage.component_name}</span>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </>
          )}
        </TabsContent>

        <TabsContent value="usage" className="space-y-6">
          {analytics && (
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Detailed Component Usage</CardTitle>
                  <CardDescription>Complete breakdown of feature usage</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="border-b">
                          <th className="text-left p-2">Component</th>
                          <th className="text-left p-2">Action</th>
                          <th className="text-right p-2">Usage Count</th>
                          <th className="text-right p-2">Total Credits</th>
                          <th className="text-right p-2">Avg Cost</th>
                          <th className="text-left p-2">Last Used</th>
                        </tr>
                      </thead>
                      <tbody>
                        {analytics.top_components_by_usage.map((usage, index) => (
                          <tr key={`${usage.component_name}-${usage.action_name}`} className="border-b hover:bg-gray-50">
                            <td className="p-2 font-medium">{usage.component_name}</td>
                            <td className="p-2 text-gray-600">{usage.action_name}</td>
                            <td className="p-2 text-right">{usage.usage_count.toLocaleString()}</td>
                            <td className="p-2 text-right font-semibold">{usage.total_cost.toLocaleString()}</td>
                            <td className="p-2 text-right">{usage.avg_cost_per_action.toFixed(2)}</td>
                            <td className="p-2">{new Date(usage.last_used).toLocaleDateString()}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}
        </TabsContent>

        <TabsContent value="revenue" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium flex items-center">
                  <DollarSign className="h-4 w-4 mr-2 text-green-600" />
                  Total Revenue
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-green-600">
                  ${analytics?.revenue_analytics.total_revenue?.toLocaleString() ?? 'N/A'}
                </div>
                <p className="text-xs text-gray-600">all time</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Credits Sold</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-blue-600">
                  {analytics?.revenue_analytics.total_credits_purchased?.toLocaleString() ?? 'N/A'}
                </div>
                <p className="text-xs text-gray-600">total credits</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Avg Purchase</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-purple-600">
                  ${analytics?.revenue_analytics.average_purchase_size?.toLocaleString() ?? 'N/A'}
                </div>
                <p className="text-xs text-gray-600">per transaction</p>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="optimization" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Pricing Optimization Insights</CardTitle>
                <CardDescription>Usage patterns to inform pricing strategy</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="bg-blue-50 p-4 rounded-lg">
                  <h4 className="font-semibold text-blue-900">High-Value Features</h4>
                  <p className="text-sm text-blue-800 mt-1">
                    Features with high usage and low cost efficiency may benefit from price increases
                  </p>
                  <div className="mt-2 space-y-1">
                    {analytics?.top_components_by_usage.slice(0, 3).map((usage) => (
                      <div key={usage.component_name} className="text-sm">
                        <span className="font-medium">{usage.component_name}</span>
                        <span className="text-blue-600 ml-2">
                          {usage.avg_cost_per_action.toFixed(2)} credits/action
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="bg-green-50 p-4 rounded-lg">
                  <h4 className="font-semibold text-green-900">Growth Opportunities</h4>
                  <p className="text-sm text-green-800 mt-1">
                    Low-usage features may benefit from promotional pricing or bundling
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>User Engagement</CardTitle>
                <CardDescription>Metrics for user retention and growth</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center p-3 bg-gray-50 rounded">
                    <div className="text-lg font-bold">
                      {((analytics?.active_users_last_30_days ?? 0) / Math.max(analytics?.total_users ?? 1, 1) * 100).toFixed(1)}%
                    </div>
                    <p className="text-xs text-gray-600">Activation Rate</p>
                  </div>
                  <div className="text-center p-3 bg-gray-50 rounded">
                    <div className="text-lg font-bold">
                      {analytics?.average_credits_per_user.toFixed(0) ?? 'N/A'}
                    </div>
                    <p className="text-xs text-gray-600">LTV (Credits)</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default AdminAnalyticsDashboard;
