import React, { useState, useEffect, useMemo } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { CheckCircle, XCircle } from 'lucide-react';
import { toast } from 'sonner';
import brain from 'brain';
import { MultiQuestionAssessmentRequest } from 'brain/data-contracts';
import { RegulatoryNoteButton } from 'components/RegulatoryNoteButton';

interface MultiQuestionItem {
  key: string;
  question: string;
  description?: string;
  order: number;
  regulatory_notes?: string[];
}

interface ClassificationNode {
  id: string;
  node_key: string;
  title: string;
  description?: string;
  question_text?: string;
  question_type: string;
  multi_questions?: MultiQuestionItem[];
  outcome_rules?: any[];
}

interface Props {
  node: ClassificationNode;
  treeId: string;
  onComplete: (responses: Record<string, boolean>, routingData: MultiQuestionAssessmentResponse) => void;
  treeType?: 'introduction' | 'classification'; // Add tree type to distinguish
}

export function MultiQuestionAssessment({ node, treeId, onComplete, treeType = 'classification' }: Props) {
  const [responses, setResponses] = useState<Record<string, boolean>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [allQuestionsAnswered, setAllQuestionsAnswered] = useState(false);

  // Parse multi_questions - it might be a JSON string or already an array
  const questions = useMemo(() => {
    try {
      let rawQuestions = node.multi_questions;
      
      // If it's a string, parse it
      if (typeof rawQuestions === 'string') {
        rawQuestions = JSON.parse(rawQuestions);
      }
      
      // If it's not an array, return empty array
      if (!Array.isArray(rawQuestions)) {
        return [];
      }
      
      // Map the data structure to match our interface
      return rawQuestions.map((q: any) => {
        console.log('Parsing question:', q);
        console.log('Regulatory notes for question:', q.regulatory_notes);
        return {
          key: q.key,
          question: q.text || q.question, // Handle both 'text' and 'question' fields
          description: q.description,
          order: q.order,
          regulatory_notes: q.regulatory_notes
        };
      }).sort((a, b) => (a.order || 0) - (b.order || 0)); // Sort by order
    } catch (error) {
      console.error('Error parsing multi_questions:', error);
      return [];
    }
  }, [node.multi_questions]);

  // Check if all questions have been answered
  useEffect(() => {
    const answeredCount = Object.keys(responses).length;
    const totalQuestions = questions.length;
    setAllQuestionsAnswered(answeredCount === totalQuestions && totalQuestions > 0);
  }, [responses, questions]);

  const handleResponseChange = (questionKey: string, response: boolean) => {
    setResponses(prev => ({
      ...prev,
      [questionKey]: response
    }));
  };

  const handleSubmit = async () => {
    if (!allQuestionsAnswered) {
      toast.error('Please answer all questions before continuing.');
      return;
    }

    setIsSubmitting(true);
    try {
      console.log('Submitting assessment:', { treeId, nodeKey: node.node_key, responses });
      
      const request: MultiQuestionAssessmentRequest = {
        responses
      };

      const response = treeType === 'classification' 
        ? await brain.process_classification_multi_question_assessment(
            { treeId: treeId, nodeKey: node.node_key }, 
            request
          )
        : await brain.process_introduction_multi_question_assessment(
            { treeId: treeId, nodeKey: node.node_key }, 
            request
          );
      const result = await response.json();
      
      console.log('Assessment result:', result);
      
      // Call the completion handler with responses and routing data
      onComplete(responses, result);
      
    } catch (error) {
      console.error('Error processing multi-question assessment:', error);
      toast.error('Failed to process assessment. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  if (questions.length === 0) {
    return (
      <Card className="bg-gray-800 border-gray-700">
        <CardContent className="py-6">
          <div className="text-center text-gray-400">
            <p>No questions configured for this assessment.</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Questions */}
      <div className="space-y-4">
        {questions.map((question, index) => {
          const hasResponse = question.key in responses;
          const response = responses[question.key];
          
          return (
            <Card key={question.key} className="bg-gray-800 border-gray-700">
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <CardTitle className="text-lg font-medium text-gray-100">
                      {index + 1}. {question.question}
                    </CardTitle>
                    {question.description && (
                      <p className="text-sm text-gray-400 mt-1">{question.description}</p>
                    )}
                    {/* Regulatory Notes */}
                    {console.log('Rendering question:', question)}
                    {console.log('Question regulatory_notes:', question.regulatory_notes)}
                    {question.regulatory_notes && question.regulatory_notes.length > 0 && (
                      <div className="flex flex-wrap gap-1 mt-2">
                        {console.log('About to render regulatory note buttons:', question.regulatory_notes)}
                        {question.regulatory_notes.map((noteKey, noteIndex) => {
                          console.log('Rendering note button for:', noteKey);
                          return (
                            <RegulatoryNoteButton
                              key={noteIndex}
                              noteKey={noteKey}
                              onClick={(e) => e.stopPropagation()}
                            />
                          );
                        })}
                      </div>
                    )}
                  </div>
                  {hasResponse && (
                    <Badge 
                      variant="outline" 
                      className={`ml-3 flex-shrink-0 ${
                        response 
                          ? 'border-green-500 text-green-400 bg-green-500/10' 
                          : 'border-red-500 text-red-400 bg-red-500/10'
                      }`}
                    >
                      {response ? (
                        <>
                          <CheckCircle className="h-3 w-3 mr-1" />
                          YES
                        </>
                      ) : (
                        <>
                          <XCircle className="h-3 w-3 mr-1" />
                          NO
                        </>
                      )}
                    </Badge>
                  )}
                </div>
              </CardHeader>
              <CardContent className="pt-0">
                <div className="flex gap-3">
                  <Button
                    variant={hasResponse && response ? "default" : "outline"}
                    size="sm"
                    onClick={() => handleResponseChange(question.key, true)}
                    disabled={isSubmitting}
                    className={`flex-1 ${
                      hasResponse && response
                        ? 'bg-green-600 hover:bg-green-700 border-green-500 text-white'
                        : 'border-gray-600 text-gray-300 hover:border-green-500 hover:text-green-400'
                    }`}
                  >
                    <CheckCircle className="h-4 w-4 mr-2" />
                    YES
                  </Button>
                  <Button
                    variant={hasResponse && !response ? "default" : "outline"}
                    size="sm"
                    onClick={() => handleResponseChange(question.key, false)}
                    disabled={isSubmitting}
                    className={`flex-1 ${
                      hasResponse && !response
                        ? 'bg-red-600 hover:bg-red-700 border-red-500 text-white'
                        : 'border-gray-600 text-gray-300 hover:border-red-500 hover:text-red-400'
                    }`}
                  >
                    <XCircle className="h-4 w-4 mr-2" />
                    NO
                  </Button>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Progress Summary */}
      <Card className="bg-gray-800 border-gray-700">
        <CardContent className="py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Badge variant="outline" className="border-gray-500 text-gray-400">
                {Object.keys(responses).length} / {questions.length} answered
              </Badge>
              {allQuestionsAnswered && (
                <Badge className="bg-green-500/20 text-green-400 border-green-500">
                  <CheckCircle className="h-3 w-3 mr-1" />
                  Complete
                </Badge>
              )}
            </div>
            <Button
              onClick={handleSubmit}
              disabled={!allQuestionsAnswered || isSubmitting}
              className="min-w-[120px]"
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Processing...
                </>
              ) : (
                'Continue'
              )}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

export default MultiQuestionAssessment;
