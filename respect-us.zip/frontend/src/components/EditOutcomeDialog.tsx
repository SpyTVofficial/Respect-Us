import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Edit } from 'lucide-react';
import { ClassificationOutcome } from '../brain/data-contracts';

interface EditOutcomeDialogProps {
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
  editingOutcome: ClassificationOutcome | null;
  setEditingOutcome: (outcome: ClassificationOutcome | null) => void;
  onSave: () => void;
}

export const EditOutcomeDialog: React.FC<EditOutcomeDialogProps> = ({
  isOpen,
  onOpenChange,
  editingOutcome,
  setEditingOutcome,
  onSave
}) => {
  // Debug logging to understand button state
  const isButtonDisabled = !editingOutcome || !editingOutcome.outcome_code?.trim() || !editingOutcome.outcome_title?.trim();
  
  console.log('🔍 EditOutcomeDialog render:', {
    isOpen,
    editingOutcome: editingOutcome ? {
      id: editingOutcome.id,
      outcome_code: editingOutcome.outcome_code,
      outcome_title: editingOutcome.outcome_title,
      outcome_code_length: editingOutcome.outcome_code?.length,
      outcome_title_length: editingOutcome.outcome_title?.length
    } : null,
    isButtonDisabled,
    reasons: {
      noEditingOutcome: !editingOutcome,
      emptyOutcomeCode: !editingOutcome?.outcome_code?.trim(),
      emptyOutcomeTitle: !editingOutcome?.outcome_title?.trim()
    }
  });
  
  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="bg-gray-900 border-gray-700 text-white max-w-2xl">
        <DialogHeader>
          <DialogTitle className="text-amber-400">Edit Classification Outcome</DialogTitle>
          <DialogDescription className="text-gray-400">
            Modify outcome properties and classification details
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label className="text-gray-300">Outcome Code</Label>
              <Input
                value={editingOutcome?.outcome_code || ''}
                onChange={(e) => {
                  console.log('📝 Outcome code changed:', e.target.value);
                  setEditingOutcome(prev => prev ? {...prev, outcome_code: e.target.value} : null);
                }}
                className="bg-gray-800 border-gray-600 text-white"
                placeholder="e.g., EU-ML 22.a, 3A001"
              />
            </div>
            <div>
              <Label className="text-gray-300">Outcome Title</Label>
              <Input
                value={editingOutcome?.outcome_title || ''}
                onChange={(e) => {
                  console.log('📝 Outcome title changed:', e.target.value);
                  setEditingOutcome(prev => prev ? {...prev, outcome_title: e.target.value} : null);
                }}
                className="bg-gray-800 border-gray-600 text-white"
                placeholder="e.g., Military List - Spacecraft Systems"
              />
            </div>
          </div>
          <div>
            <Label className="text-gray-300">Outcome Description</Label>
            <Textarea
              value={editingOutcome?.description || ''}
              onChange={(e) => setEditingOutcome(prev => prev ? {...prev, description: e.target.value} : null)}
              className="bg-gray-800 border-gray-600 text-white"
              placeholder="Detailed description of this classification outcome"
              rows={3}
            />
          </div>
          <div>
            <Label className="text-gray-300">Regulatory Basis</Label>
            <Textarea
              value={editingOutcome?.regulatory_basis || ''}
              onChange={(e) => setEditingOutcome(prev => prev ? {...prev, regulatory_basis: e.target.value} : null)}
              className="bg-gray-800 border-gray-600 text-white"
              placeholder="Legal/regulatory basis for this classification (optional)"
              rows={2}
            />
          </div>
          <div>
            <Label className="text-gray-300">Outcome Text</Label>
            <Textarea
              value={editingOutcome?.outcome_text || ''}
              onChange={(e) => setEditingOutcome(prev => prev ? {...prev, outcome_text: e.target.value} : null)}
              className="bg-gray-800 border-gray-600 text-white"
              placeholder="e.g., This item is classified as dual-use technology requiring export authorization"
              rows={3}
            />
          </div>
          <div className="space-y-3">
            <Label className="text-gray-300">Badge Options:</Label>
            
            {/* Controlled Badge Checkbox */}
            <div className="flex items-center space-x-2">
              <input
                type="checkbox"
                id="controlled-checkbox"
                checked={editingOutcome?.is_controlled === true}
                onChange={(e) => {
                  console.log('🏷️ Controlled badge changed:', e.target.checked);
                  setEditingOutcome(prev => prev ? {
                    ...prev, 
                    is_controlled: e.target.checked ? true : null
                  } : null);
                }}
                className="w-4 h-4 rounded border-gray-600 bg-gray-800 text-amber-600 focus:ring-amber-600"
              />
              <Label htmlFor="controlled-checkbox" className="text-gray-300 cursor-pointer">
                Show "CONTROLLED" badge
              </Label>
            </div>
            
            {/* Not Controlled Badge Checkbox */}
            <div className="flex items-center space-x-2">
              <input
                type="checkbox"
                id="not-controlled-checkbox"
                checked={editingOutcome?.is_controlled === false}
                onChange={(e) => {
                  console.log('🏷️ Not Controlled badge changed:', e.target.checked);
                  setEditingOutcome(prev => prev ? {
                    ...prev, 
                    is_controlled: e.target.checked ? false : null
                  } : null);
                }}
                className="w-4 h-4 rounded border-gray-600 bg-gray-800 text-amber-600 focus:ring-amber-600"
              />
              <Label htmlFor="not-controlled-checkbox" className="text-gray-300 cursor-pointer">
                Show "NOT CONTROLLED" badge
              </Label>
            </div>
          </div>
          
          {/* Badge Preview - Only show if one of the options is selected */}
          {editingOutcome?.is_controlled !== null && editingOutcome?.is_controlled !== undefined && (
            <div className="mt-2">
              <Label className="text-gray-300 mb-2 block">Badge Preview:</Label>
              <div className="flex justify-center">
                {editingOutcome.is_controlled ? (
                  <Badge className="bg-red-600 hover:bg-red-700 text-white px-3 py-1">
                    CONTROLLED
                  </Badge>
                ) : (
                  <Badge className="bg-green-600 hover:bg-green-700 text-white px-3 py-1">
                    NOT CONTROLLED. PLEASE CHECK CATCH-ALL PROVISIONS
                  </Badge>
                )}
              </div>
            </div>
          )}
          <div>
            <Label className="text-gray-300">Guidance Notes</Label>
            <Textarea
              value={editingOutcome?.guidance_notes || ''}
              onChange={(e) => setEditingOutcome(prev => prev ? {...prev, guidance_notes: e.target.value} : null)}
              className="bg-gray-800 border-gray-600 text-white"
              placeholder="Additional guidance or notes for this outcome (optional)"
              rows={2}
            />
          </div>
          <div className="flex justify-end space-x-2 pt-4">
            <Button
              variant="outline"
              onClick={() => {
                onOpenChange(false);
                setEditingOutcome(null);
              }}
              className="border-gray-600 text-gray-400 hover:bg-gray-800"
            >
              Cancel
            </Button>
            <Button 
              onClick={() => {
                console.log('💾 Save Changes button clicked!');
                console.log('📊 Current editing outcome:', editingOutcome);
                onSave();
              }}
              disabled={isButtonDisabled}
              className="bg-amber-600 hover:bg-amber-700 text-white disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Edit className="w-4 h-4 mr-2" />
              Save Changes
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default EditOutcomeDialog;
