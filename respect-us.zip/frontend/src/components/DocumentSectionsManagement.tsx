
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Trash2, Edit, Plus, Upload, Download, GripVertical, FileIcon, Info } from 'lucide-react';
import { toast } from 'sonner';
import brain from 'brain';
import {
  DndContext,
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  DragEndEvent,
} from '@dnd-kit/core';
import {
  arrayMove,
  SortableContext,
  sortableKeyboardCoordinates,
  verticalListSortingStrategy,
} from '@dnd-kit/sortable';
import {
  useSortable,
} from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import {
  AppApisDocumentSectionsDocumentSection as DocumentSection,
  CreateSectionRequest,
  UpdateSectionRequest
} from '../brain/data-contracts';

interface Document {
  id: number;
  title: string;
  country_jurisdiction: string;
  regulation_type: string;
  section_count: number;
}

interface SortableSectionProps {
  section: DocumentSection;
  onEdit: (section: DocumentSection) => void;
  onDelete: (id: number) => void;
}

function SortableSection({ section, onEdit, onDelete }: SortableSectionProps) {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
  } = useSortable({ id: section.id! });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
  };

  return (
    <div
      ref={setNodeRef}
      style={style}
      className="bg-white rounded-lg border p-4 mb-2 shadow-sm"
    >
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3 flex-1">
          <div
            {...attributes}
            {...listeners}
            className="cursor-grab hover:cursor-grabbing p-1 hover:bg-gray-100 rounded"
          >
            <GripVertical className="h-4 w-4 text-gray-400" />
          </div>
          <div className="flex-1">
            <div className="flex items-center space-x-2 mb-1">
              <Badge variant="outline" className="text-xs">
                {section.section_number || 'No Number'}
              </Badge>
              <h4 className="font-medium text-sm">
                {section.section_title || 'Untitled Section'}
              </h4>
            </div>
            <p className="text-xs text-gray-600 truncate max-w-md">
              {section.section_content ? 
                section.section_content.substring(0, 100) + (section.section_content.length > 100 ? '...' : '')
                : 'No content'
              }
            </p>
          </div>
        </div>
        <div className="flex items-center space-x-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => onEdit(section)}
            className="h-8 w-8 p-0"
          >
            <Edit className="h-4 w-4" />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => onDelete(section.id!)}
            className="h-8 w-8 p-0 text-red-600 hover:text-red-700"
          >
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}

export default function DocumentSectionsManagement() {
  const [documents, setDocuments] = useState<Document[]>([]);
  const [selectedDocument, setSelectedDocument] = useState<Document | null>(null);
  const [sections, setSections] = useState<DocumentSection[]>([]);
  const [sectionsNotApplicable, setSectionsNotApplicable] = useState<boolean>(false);
  const [loading, setLoading] = useState(false);
  const [editingSection, setEditingSection] = useState<DocumentSection | null>(null);
  const [showSectionDialog, setShowSectionDialog] = useState(false);
  const [showBulkImport, setShowBulkImport] = useState(false);
  const [bulkImportText, setBulkImportText] = useState('');
  const [replaceExisting, setReplaceExisting] = useState(false);

  const sensors = useSensors(
    useSensor(PointerSensor),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    })
  );

  // Load documents on component mount
  useEffect(() => {
    loadDocuments();
  }, []);

  const loadDocuments = async () => {
    try {
      setLoading(true);
      const response = await brain.list_admin_documents();
      const data = await response.json();
      setDocuments(data || []);
    } catch (error) {
      console.error('Error loading documents:', error);
      toast.error('Failed to load documents');
    } finally {
      setLoading(false);
    }
  };

  const loadSections = async (documentId: number) => {
    try {
      setLoading(true);
      const response = await brain.get_document_sections_admin({ documentId });
      const data = await response.json();
      setSections(data.sections || []);
      setSectionsNotApplicable(data.sections_not_applicable || false);
    } catch (error) {
      console.error('Error loading sections:', error);
      toast.error('Failed to load document sections');
    } finally {
      setLoading(false);
    }
  };

  const handleDocumentSelect = (document: Document) => {
    setSelectedDocument(document);
    loadSections(document.id);
  };

  const handleCreateSection = async (sectionData: Partial<DocumentSection>) => {
    if (!selectedDocument) return;

    try {
      const response = await brain.create_document_section(
        { documentId: selectedDocument.id },
        {
          document_id: selectedDocument.id,
          section_number: sectionData.section_number || '',
          section_title: sectionData.section_title || '',
          section_content: sectionData.section_content || '',
          parent_section_id: sectionData.parent_section_id || null,
          display_order: sectionData.display_order || sections.length
        }
      );
      
      if (response.ok) {
        toast.success('Section created successfully');
        loadSections(selectedDocument.id);
        setShowSectionDialog(false);
        setEditingSection(null);
      }
    } catch (error) {
      console.error('Error creating section:', error);
      toast.error('Failed to create section');
    }
  };

  const handleUpdateSection = async (sectionData: Partial<DocumentSection>) => {
    if (!editingSection) return;

    try {
      const response = await brain.update_document_section(
        { sectionId: editingSection.id! },
        {
          section_number: sectionData.section_number,
          section_title: sectionData.section_title,
          section_content: sectionData.section_content,
          parent_section_id: sectionData.parent_section_id,
          display_order: sectionData.display_order
        }
      );
      
      if (response.ok) {
        toast.success('Section updated successfully');
        loadSections(selectedDocument!.id);
        setShowSectionDialog(false);
        setEditingSection(null);
      }
    } catch (error) {
      console.error('Error updating section:', error);
      toast.error('Failed to update section');
    }
  };

  const handleDeleteSection = async (sectionId: number) => {
    if (!confirm('Are you sure you want to delete this section?')) return;

    try {
      const response = await brain.delete_document_section({ sectionId });
      
      if (response.ok) {
        toast.success('Section deleted successfully');
        loadSections(selectedDocument!.id);
      }
    } catch (error) {
      console.error('Error deleting section:', error);
      toast.error('Failed to delete section');
    }
  };

  const handleDragEnd = async (event: DragEndEvent) => {
    const { active, over } = event;

    if (active.id !== over?.id) {
      const oldIndex = sections.findIndex((section) => section.id === active.id);
      const newIndex = sections.findIndex((section) => section.id === over?.id);

      const reorderedSections = arrayMove(sections, oldIndex, newIndex);
      setSections(reorderedSections);

      // Update display order in backend
      try {
        const sectionOrders = reorderedSections.map((section, index) => ({
          id: section.id,
          display_order: index
        }));

        await brain.reorder_document_sections(
          { documentId: selectedDocument!.id },
          { section_orders: sectionOrders }
        );
        
        toast.success('Section order updated');
      } catch (error) {
        console.error('Error reordering sections:', error);
        toast.error('Failed to update section order');
        // Revert the change
        loadSections(selectedDocument!.id);
      }
    }
  };

  const handleBulkImport = async () => {
    if (!selectedDocument || !bulkImportText.trim()) return;

    try {
      // Parse the bulk import text into sections
      const lines = bulkImportText.split('\n');
      const parsedSections: any[] = [];
      
      let currentSection: any = null;
      
      for (const line of lines) {
        const trimmedLine = line.trim();
        if (!trimmedLine) continue;
        
        // Check if line looks like a section header (e.g., "1. Introduction" or "Section 1: Introduction")
        const sectionMatch = trimmedLine.match(/^(\d+\.?|Section\s+\d+:?)\s*(.*)$/i);
        
        if (sectionMatch) {
          // Save previous section if exists
          if (currentSection) {
            parsedSections.push(currentSection);
          }
          
          // Start new section
          currentSection = {
            section_number: sectionMatch[1].replace(/[:\.]+$/, ''),
            section_title: sectionMatch[2] || `Section ${sectionMatch[1]}`,
            section_content: '',
            display_order: parsedSections.length
          };
        } else if (currentSection) {
          // Add content to current section
          currentSection.section_content += (currentSection.section_content ? '\n' : '') + trimmedLine;
        } else {
          // No section header found, create a default section
          currentSection = {
            section_number: '1',
            section_title: 'Imported Content',
            section_content: trimmedLine,
            display_order: 0
          };
        }
      }
      
      // Add final section
      if (currentSection) {
        parsedSections.push(currentSection);
      }
      
      if (parsedSections.length === 0) {
        toast.error('No sections could be parsed from the text');
        return;
      }

      const response = await brain.bulk_import_sections(
        { documentId: selectedDocument.id },
        {
          document_id: selectedDocument.id,
          sections: parsedSections,
          replace_existing: replaceExisting
        }
      );
      
      if (response.ok) {
        toast.success(`Successfully imported ${parsedSections.length} sections`);
        loadSections(selectedDocument.id);
        setShowBulkImport(false);
        setBulkImportText('');
        setReplaceExisting(false);
      }
    } catch (error) {
      console.error('Error importing sections:', error);
      toast.error('Failed to import sections');
    }
  };

  const handleExportSections = async () => {
    if (!selectedDocument || sections.length === 0) return;

    try {
      const response = await brain.export_sections({ documentId: selectedDocument.id });
      const data = await response.json();
      
      // Create downloadable text file
      const exportText = data.sections.map((section: any) => 
        `${section.section_number}. ${section.section_title}\n${section.section_content}\n\n`
      ).join('');
      
      const blob = new Blob([exportText], { type: 'text/plain' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${selectedDocument.title.replace(/[^a-zA-Z0-9]/g, '_')}_sections.txt`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      
      toast.success('Sections exported successfully');
    } catch (error) {
      console.error('Error exporting sections:', error);
      toast.error('Failed to export sections');
    }
  };

  const handleSectionsNotApplicableChange = async (checked: boolean) => {
    if (!selectedDocument) return;

    try {
      const response = await brain.update_sections_not_applicable(
        { documentId: selectedDocument.id },
        { sections_not_applicable: checked }
      );
      
      if (response.ok) {
        setSectionsNotApplicable(checked);
        toast.success(checked ? 'Sections marked as not applicable' : 'Sections marked as applicable');
      }
    } catch (error) {
      console.error('Error updating sections not applicable:', error);
      toast.error('Failed to update sections not applicable status');
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Document Sections Management</h2>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Documents List */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <FileIcon className="h-5 w-5" />
              <span>Documents</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-96">
              {loading && !selectedDocument ? (
                <div className="text-center py-8 text-gray-500">Loading documents...</div>
              ) : documents.length === 0 ? (
                <div className="text-center py-8 text-gray-500">No documents found</div>
              ) : (
                <div className="space-y-2">
                  {documents.map((doc) => (
                    <div
                      key={doc.id}
                      className={`p-3 rounded-lg border cursor-pointer transition-colors ${
                        selectedDocument?.id === doc.id
                          ? 'bg-blue-50 border-blue-200'
                          : 'hover:bg-gray-50'
                      }`}
                      onClick={() => handleDocumentSelect(doc)}
                    >
                      <h4 className="font-medium text-sm mb-1">{doc.title}</h4>
                      <div className="flex items-center justify-between text-xs text-gray-500">
                        <span>{doc.country_jurisdiction}</span>
                        <Badge variant="secondary" className="text-xs">
                          {doc.section_count} sections
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </ScrollArea>
          </CardContent>
        </Card>

        {/* Sections Management */}
        <div className="lg:col-span-2">
          {selectedDocument ? (
            <Card>
              <CardHeader>
                <div className="flex justify-between items-center">
                  <CardTitle>Sections for "{selectedDocument.title}"</CardTitle>
                  <div className="flex items-center space-x-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setShowBulkImport(true)}
                      disabled={sectionsNotApplicable}
                    >
                      <Upload className="h-4 w-4 mr-2" />
                      Bulk Import
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={handleExportSections}
                      disabled={sections.length === 0 || sectionsNotApplicable}
                    >
                      <Download className="h-4 w-4 mr-2" />
                      Export
                    </Button>
                    <Button
                      size="sm"
                      onClick={() => {
                        setEditingSection(null);
                        setShowSectionDialog(true);
                      }}
                      disabled={sectionsNotApplicable}
                    >
                      <Plus className="h-4 w-4 mr-2" />
                      Add Section
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                {/* Sections Not Applicable Checkbox */}
                <div className="mb-6 p-4 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg border-2 border-blue-200">
                  <div className="flex items-start space-x-4">
                    <div className="flex items-center space-x-3">
                      <Checkbox
                        id="sections_not_applicable"
                        checked={sectionsNotApplicable}
                        onCheckedChange={handleSectionsNotApplicableChange}
                        className="h-5 w-5 data-[state=checked]:bg-blue-600 data-[state=checked]:border-blue-600"
                      />
                      <div className="flex-1">
                        <Label htmlFor="sections_not_applicable" className="text-base font-semibold cursor-pointer text-gray-900">
                          Sections do not apply to this document
                        </Label>
                        <p className="text-sm text-gray-700 mt-1 leading-relaxed">
                          Check this box if this document does not contain sections that need to be managed separately.
                          When enabled, section creation and management will be disabled.
                        </p>
                      </div>
                    </div>
                    <div className="flex-shrink-0">
                      <div className={`w-3 h-3 rounded-full ${
                        sectionsNotApplicable ? 'bg-green-500' : 'bg-gray-300'
                      }`} />
                    </div>
                  </div>
                </div>

                {sectionsNotApplicable ? (
                  <Alert>
                    <Info className="h-4 w-4" />
                    <AlertDescription>
                      This document is marked as "sections not applicable". Section management is disabled.
                      Uncheck the box above to enable section management.
                    </AlertDescription>
                  </Alert>
                ) : loading ? (
                  <div className="text-center py-8 text-gray-500">Loading sections...</div>
                ) : sections.length === 0 ? (
                  <Alert>
                    <AlertDescription>
                      This document has no sections yet. Add sections manually or use bulk import to get started.
                    </AlertDescription>
                  </Alert>
                ) : (
                  <DndContext
                    sensors={sensors}
                    collisionDetection={closestCenter}
                    onDragEnd={handleDragEnd}
                  >
                    <SortableContext items={sections.map(s => s.id!)} strategy={verticalListSortingStrategy}>
                      <div className="space-y-2">
                        {sections.map((section) => (
                          <SortableSection
                            key={section.id}
                            section={section}
                            onEdit={(section) => {
                              setEditingSection(section);
                              setShowSectionDialog(true);
                            }}
                            onDelete={handleDeleteSection}
                          />
                        ))}
                      </div>
                    </SortableContext>
                  </DndContext>
                )}
              </CardContent>
            </Card>
          ) : (
            <Card>
              <CardContent className="py-12">
                <div className="text-center text-gray-500">
                  <FileIcon className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p>Select a document to manage its sections</p>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>

      {/* Section Creation/Edit Dialog */}
      <SectionDialog
        open={showSectionDialog}
        onOpenChange={setShowSectionDialog}
        section={editingSection}
        onSave={editingSection ? handleUpdateSection : handleCreateSection}
      />

      {/* Bulk Import Dialog */}
      <BulkImportDialog
        open={showBulkImport}
        onOpenChange={setShowBulkImport}
        text={bulkImportText}
        onTextChange={setBulkImportText}
        replaceExisting={replaceExisting}
        onReplaceChange={setReplaceExisting}
        onImport={handleBulkImport}
      />
    </div>
  );
}

// Section Dialog Component
interface SectionDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  section: DocumentSection | null;
  onSave: (section: Partial<DocumentSection>) => void;
}

function SectionDialog({ open, onOpenChange, section, onSave }: SectionDialogProps) {
  const [formData, setFormData] = useState<Partial<DocumentSection>>({});

  useEffect(() => {
    if (section) {
      setFormData(section);
    } else {
      setFormData({
        section_number: '',
        section_title: '',
        section_content: '',
        parent_section_id: undefined,
        display_order: 0
      });
    }
  }, [section]);

  const handleSubmit = () => {
    if (!formData.section_title?.trim()) {
      toast.error('Section title is required');
      return;
    }
    onSave(formData);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>
            {section ? 'Edit Section' : 'Create New Section'}
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="section_number">Section Number</Label>
              <Input
                id="section_number"
                value={formData.section_number || ''}
                onChange={(e) => setFormData({ ...formData, section_number: e.target.value })}
                placeholder="e.g., 1, 1.1, A"
              />
            </div>
            <div>
              <Label htmlFor="display_order">Display Order</Label>
              <Input
                id="display_order"
                type="number"
                value={formData.display_order || 0}
                onChange={(e) => setFormData({ ...formData, display_order: parseInt(e.target.value) || 0 })}
              />
            </div>
          </div>
          <div>
            <Label htmlFor="section_title">Section Title *</Label>
            <Input
              id="section_title"
              value={formData.section_title || ''}
              onChange={(e) => setFormData({ ...formData, section_title: e.target.value })}
              placeholder="Enter section title"
            />
          </div>
          <div>
            <Label htmlFor="section_content">Section Content</Label>
            <Textarea
              id="section_content"
              value={formData.section_content || ''}
              onChange={(e) => setFormData({ ...formData, section_content: e.target.value })}
              placeholder="Enter section content"
              rows={8}
            />
          </div>
          <div className="flex justify-end space-x-2 pt-4">
            <Button variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button onClick={handleSubmit}>
              {section ? 'Update' : 'Create'} Section
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

// Bulk Import Dialog Component
interface BulkImportDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  text: string;
  onTextChange: (text: string) => void;
  replaceExisting: boolean;
  onReplaceChange: (replace: boolean) => void;
  onImport: () => void;
}

function BulkImportDialog({
  open,
  onOpenChange,
  text,
  onTextChange,
  replaceExisting,
  onReplaceChange,
  onImport
}: BulkImportDialogProps) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Bulk Import Sections</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <Alert>
            <AlertDescription>
              Paste your document content below. The system will automatically detect section headers
              (e.g., "1. Introduction", "Section 2: Overview") and split the content into sections.
            </AlertDescription>
          </Alert>
          <div>
            <Label htmlFor="bulk_content">Document Content</Label>
            <Textarea
              id="bulk_content"
              value={text}
              onChange={(e) => onTextChange(e.target.value)}
              placeholder="Paste your document content here...\n\n1. Introduction\nThis is the introduction content...\n\n2. Main Content\nThis is the main content...\n\n3. Conclusion\nThis is the conclusion..."
              rows={12}
            />
          </div>
          <div className="flex items-center space-x-2">
            <input
              type="checkbox"
              id="replace_existing"
              checked={replaceExisting}
              onChange={(e) => onReplaceChange(e.target.checked)}
              className="rounded"
            />
            <Label htmlFor="replace_existing" className="text-sm">
              Replace all existing sections (warning: this will delete current sections)
            </Label>
          </div>
          <div className="flex justify-end space-x-2 pt-4">
            <Button variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button onClick={onImport} disabled={!text.trim()}>
              Import Sections
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
