import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { 
  Search, 
  Users, 
  AlertTriangle, 
  CheckCircle2, 
  Calendar,
  Mail,
  Phone,
  MapPin,
  Building2,
  Globe,
  Edit3,
  Trash2,
  Plus,
  Eye,
  FileText,
  TrendingUp,
  TrendingDown,
  Minus,
  DollarSign,
  Package,
  CreditCard,
  Clock,
  AlertCircle,
  Shield,
  Star,
  Filter,
  Download,
  Upload,
  MoreHorizontal,
  RefreshCw,
  FolderOpen,
  Bell,
  User,
  Activity,
  BarChart3,
  UserPlus,
  UserCheck,
  ArrowLeft,
  Check,
  X,
  Edit,
  Info,
  CheckCircle,
  Settings,
  FileCheck
} from 'lucide-react';
import { toast } from 'sonner';
import brain from 'brain';
import { CustomerProfile } from 'brain/data-contracts';

interface CustomerProfilesProps {
  customers: CustomerProfile[];
  loading: boolean;
  onRefresh: () => void;
}

interface ProfileFormData {
  customer_name: string;
  customer_type: string;
  legal_name: string;
  aliases: string[];
  address: string;
  city: string;
  country: string;
  postal_code: string;
  date_of_birth: string;
  incorporation_date: string;
  registration_number: string;
  tax_id: string;
  phone: string;
  email: string;
  website: string;
  business_type: string;
  risk_category: string;
  notes: string;
}

interface CustomerTransaction {
  id?: number;
  customer_id: number;
  transaction_date: string;
  transaction_type: string;
  amount: number;
  currency: string;
  description: string;
  status: string;
  reference_number?: string;
  compliance_status?: string;
  risk_score?: number;
  notes?: string;
}

interface CustomerProduct {
  id?: number;
  customer_id: number;
  product_name: string;
  product_category: string;
  eccn_classification?: string;
  hs_code?: string;
  technology_level?: string;
  end_use?: string;
  quantity?: number;
  unit_value?: number;
  currency?: string;
  compliance_notes?: string;
  risk_assessment?: string;
  created_at?: string;
}

const CustomerProfiles: React.FC<CustomerProfilesProps> = ({
  customers,
  loading,
  onRefresh
}) => {
  // Local state for UI management
  const [selectedCustomer, setSelectedCustomer] = useState<CustomerProfile | null>(null);
  const [showAddCustomer, setShowAddCustomer] = useState(false);
  const [showEditCustomer, setShowEditCustomer] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [customerToDelete, setCustomerToDelete] = useState<CustomerProfile | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState('profiles');
  const [activeProfileTab, setActiveProfileTab] = useState('overview');
  
  // Add missing filter state variables
  const [filterType, setFilterType] = useState('all');
  const [filterRisk, setFilterRisk] = useState('all');
  const [showProfileDialog, setShowProfileDialog] = useState(false);
  
  // Add edit mode state variables
  const [isEditMode, setIsEditMode] = useState(false);
  const [editedCustomer, setEditedCustomer] = useState<CustomerProfile | null>(null);
  const [showAddTransaction, setShowAddTransaction] = useState(false);
  const [showAddProduct, setShowAddProduct] = useState(false);
  
  // Phase 2 state variables
  const [customerTransactions, setCustomerTransactions] = useState<any[]>([]);
  const [customerProducts, setCustomerProducts] = useState<any[]>([]);
  const [transactionLoading, setTransactionLoading] = useState(false);
  const [productLoading, setProductLoading] = useState(false);
  const [advancedSearchQuery, setAdvancedSearchQuery] = useState('');
  const [searchFilters, setSearchFilters] = useState({
    customer_type: 'all',
    risk_category: 'all',
    country: '',
    has_transactions: false,
    has_products: false,
    date_range: { start: '', end: '' }
  });
  const [filteredCustomers, setFilteredCustomers] = useState<CustomerProfile[]>([]);
  
  // Format date helper function
  const formatDate = (dateString: string | undefined) => {
    if (!dateString) return 'Not specified';
    try {
      return new Date(dateString).toLocaleDateString();
    } catch {
      return 'Invalid date';
    }
  };

  // Add profile function
  const handleAddProfile = () => {
    setShowAddCustomer(true);
  };

  // Load customer transactions
  const loadCustomerTransactions = async (customerId: string) => {
    if (!customerId) return;
    
    setTransactionLoading(true);
    try {
      const response = await brain.get_customer_transactions({ customer_id: customerId });
      const data = await response.json();
      setCustomerTransactions(data.transactions || []);
    } catch (error) {
      console.error('Error loading transactions:', error);
      toast.error('Failed to load transaction history');
    } finally {
      setTransactionLoading(false);
    }
  };

  // Load customer products
  const loadCustomerProducts = async (customerId: string) => {
    if (!customerId) return;
    
    setProductLoading(true);
    try {
      const response = await brain.get_customer_products({ customer_id: customerId });
      const data = await response.json();
      setCustomerProducts(data.products || []);
    } catch (error) {
      console.error('Error loading products:', error);
      toast.error('Failed to load product portfolio');
    } finally {
      setProductLoading(false);
    }
  };

  // Add transaction function
  const handleAddTransaction = () => {
    console.log('Add Transaction clicked for customer:', selectedCustomer?.customer_name);
    // Here you could open a modal or navigate to add transaction page
    alert(`Add Transaction functionality for ${selectedCustomer?.customer_name} - This would open a transaction form`);
  };

  // Add product function
  const handleAddProduct = () => {
    console.log('Add Product clicked for customer:', selectedCustomer?.customer_name);
    // Here you could open a modal or navigate to add product page
    alert(`Add Product functionality for ${selectedCustomer?.customer_name} - This would open a product form`);
  };

  // Effect to load transaction and product data when customer is selected
  useEffect(() => {
    if (selectedCustomer?.id) {
      loadCustomerTransactions(selectedCustomer.id);
      loadCustomerProducts(selectedCustomer.id);
    }
  }, [selectedCustomer?.id]);

  // Effect to filter customers based on advanced search
  useEffect(() => {
    const filtered = customers.filter(customer => {
      // Basic search
      const matchesBasicSearch = !advancedSearchQuery || 
        customer.customer_name.toLowerCase().includes(advancedSearchQuery.toLowerCase()) ||
        customer.legal_name?.toLowerCase().includes(advancedSearchQuery.toLowerCase()) ||
        customer.email?.toLowerCase().includes(advancedSearchQuery.toLowerCase()) ||
        customer.country?.toLowerCase().includes(advancedSearchQuery.toLowerCase());
      
      // Filter criteria
      const matchesType = searchFilters.customer_type === 'all' || customer.customer_type === searchFilters.customer_type;
      const matchesRisk = searchFilters.risk_category === 'all' || customer.risk_category === searchFilters.risk_category;
      const matchesCountry = !searchFilters.country || customer.country?.toLowerCase().includes(searchFilters.country.toLowerCase());
      
      // Transaction/Product filters (simplified for now)
      const matchesTransactions = !searchFilters.has_transactions || true; // Would need actual transaction data
      const matchesProducts = !searchFilters.has_products || true; // Would need actual product data
      
      // Date range filter
      let matchesDateRange = true;
      if (searchFilters.date_range.start || searchFilters.date_range.end) {
        const customerDate = customer.created_at ? new Date(customer.created_at) : null;
        if (customerDate) {
          if (searchFilters.date_range.start) {
            const startDate = new Date(searchFilters.date_range.start);
            matchesDateRange = matchesDateRange && customerDate >= startDate;
          }
          if (searchFilters.date_range.end) {
            const endDate = new Date(searchFilters.date_range.end);
            matchesDateRange = matchesDateRange && customerDate <= endDate;
          }
        }
      }
      
      return matchesBasicSearch && matchesType && matchesRisk && matchesCountry && 
             matchesTransactions && matchesProducts && matchesDateRange;
    });
    
    setFilteredCustomers(filtered);
  }, [customers, advancedSearchQuery, searchFilters]);

  // Utility functions
  const getRiskLevelColor = (riskLevel: string) => {
    switch (riskLevel) {
      case 'critical': return 'bg-red-500/20 text-red-400 border-red-500/50';
      case 'high': return 'bg-orange-500/20 text-orange-400 border-orange-500/50';
      case 'standard': return 'bg-blue-500/20 text-blue-400 border-blue-500/50';
      case 'low': return 'bg-green-500/20 text-green-400 border-green-500/50';
      default: return 'bg-gray-500/20 text-gray-400 border-gray-500/50';
    }
  };

  const getCustomerTypeIcon = (type: string) => {
    switch (type) {
      case 'individual': return <User className="h-4 w-4" />;
      case 'entity':
      case 'company':
      case 'organization': return <Building2 className="h-4 w-4" />;
      default: return <User className="h-4 w-4" />;
    }
  };

  const handleViewProfile = (customer: CustomerProfile) => {
    console.log('🔍 View button clicked for customer:', customer.customer_name);
    console.log('📊 Setting selectedCustomer to:', customer);
    console.log('🎯 Current selectedCustomer before update:', selectedCustomer);
    setSelectedCustomer(customer);
    setActiveProfileTab('overview');
    console.log('✅ handleViewProfile completed');
  };

  // Add handleEditProfile function
  const handleEditProfile = (customer: CustomerProfile) => {
    setIsEditMode(true);
    setEditedCustomer({ ...customer });
  };

  // Handle save profile changes
  const handleSaveProfile = async () => {
    if (!editedCustomer) return;
    
    try {
      console.log('Saving customer profile...', editedCustomer);
      
      // Update the selected customer with edited data
      setSelectedCustomer(editedCustomer);
      
      // Exit edit mode
      setIsEditMode(false);
      setEditedCustomer(null);
      
      // Refresh the customer list to ensure consistency
      onRefresh();
      
      // Show success message
      console.log('Customer profile saved successfully!');
      
      // You could add a toast notification here when the API is implemented:
      // toast.success('Customer profile updated successfully!');
      
    } catch (error) {
      console.error('Error saving customer profile:', error);
      // toast.error('Failed to save customer profile');
    }
  };

  // Handle cancel edit
  const handleCancelEdit = () => {
    setIsEditMode(false);
    setEditedCustomer(null);
  };

  // Handle field changes in edit mode
  const handleFieldChange = (field: string, value: any) => {
    if (!editedCustomer) return;
    setEditedCustomer({
      ...editedCustomer,
      [field]: value
    });
  };

  // Filter customers for main table (basic search)
  const mainFilteredCustomers = customers.filter(customer => {
    const matchesSearch = customer.customer_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         customer.legal_name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         customer.country?.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesSearch;
  });

  // Customer analytics data
  const customerAnalytics = {
    total: customers.length,
    byType: {
      individual: customers.filter(c => c.customer_type === 'individual').length,
      entity: customers.filter(c => c.customer_type === 'entity').length,
      company: customers.filter(c => c.customer_type === 'company').length,
      organization: customers.filter(c => c.customer_type === 'organization').length
    },
    byRisk: {
      low: customers.filter(c => c.risk_category === 'low').length,
      standard: customers.filter(c => c.risk_category === 'standard').length,
      high: customers.filter(c => c.risk_category === 'high').length,
      critical: customers.filter(c => c.risk_category === 'critical').length
    }
  };

  return (
    <div className="space-y-6">
      {selectedCustomer ? (
        // Individual Customer Profile View
        <div className="space-y-4">
          {/* Header with back button and customer info */}
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Button
                variant="ghost"
                onClick={() => setSelectedCustomer(null)}
                className="text-slate-300 hover:text-white hover:bg-slate-700/50"
              >
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Customer List
              </Button>
              <div>
                <h2 className="text-2xl font-bold text-white">{selectedCustomer.customer_name}</h2>
                <p className="text-slate-400">{selectedCustomer.email}</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <Badge className={getRiskLevelColor(selectedCustomer.risk_category || 'standard')}>
                {selectedCustomer.risk_category || 'standard'}
              </Badge>
              
              {/* Conditional Edit Mode UI */}
              {isEditMode ? (
                <div className="flex items-center space-x-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={handleSaveProfile}
                    className="text-green-400 hover:text-green-300 hover:bg-green-500/20"
                  >
                    <Check className="h-4 w-4 mr-2" />
                    Save
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={handleCancelEdit}
                    className="text-red-400 hover:text-red-300 hover:bg-red-500/20"
                  >
                    <X className="h-4 w-4 mr-2" />
                    Cancel
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setShowAddTransaction(true)}
                    className="text-blue-400 hover:text-blue-300 hover:bg-blue-500/20"
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    Add Transaction
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setShowAddProduct(true)}
                    className="text-purple-400 hover:text-purple-300 hover:bg-purple-500/20"
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    Add Product
                  </Button>
                </div>
              ) : (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => selectedCustomer && handleEditProfile(selectedCustomer)}
                  className="text-green-400 hover:text-green-300 hover:bg-green-500/20"
                  disabled={!selectedCustomer}
                >
                  <Edit className="h-4 w-4 mr-2" />
                  Edit
                </Button>
              )}
            </div>
          </div>

          {/* Enhanced Customer Profile Tabs */}
          <Card className="bg-slate-900/30 border-slate-700/50">
            <CardContent className="p-6">
              <Tabs value={activeProfileTab} onValueChange={setActiveProfileTab} className="w-full">
                <TabsList className="grid grid-cols-9 mb-6 bg-slate-800/50">

                  <TabsTrigger value="overview" className="text-slate-300 data-[state=active]:text-white data-[state=active]:bg-slate-700">

                    <User className="h-4 w-4 mr-2" />
                    Overview
                  </TabsTrigger>
                  <TabsTrigger value="transactions" className="text-slate-300 data-[state=active]:text-white data-[state=active]:bg-slate-700">
                    <CreditCard className="h-4 w-4 mr-2" />
                    Transactions
                  </TabsTrigger>
                  <TabsTrigger value="products" className="text-slate-300 data-[state=active]:text-white data-[state=active]:bg-slate-700">
                    <Package className="h-4 w-4 mr-2" />
                    Products
                  </TabsTrigger>
                  <TabsTrigger value="search" className="text-slate-300 data-[state=active]:text-white data-[state=active]:bg-slate-700">
                    <Search className="h-4 w-4 mr-2" />
                    Search
                  </TabsTrigger>
                  <TabsTrigger value="reports" className="text-slate-300 data-[state=active]:text-white data-[state=active]:bg-slate-700">
                    <FileText className="h-4 w-4 mr-2" />
                    Reports
                  </TabsTrigger>
                  <TabsTrigger value="analytics" className="text-slate-300 data-[state=active]:text-white data-[state=active]:bg-slate-700">
                    <TrendingUp className="h-4 w-4 mr-2" />
                    Analytics
                  </TabsTrigger>
                  <TabsTrigger value="documents" className="text-slate-300 data-[state=active]:text-white data-[state=active]:bg-slate-700">
                    <FolderOpen className="h-4 w-4 mr-2" />
                    Documents
                  </TabsTrigger>
                  <TabsTrigger value="monitoring" className="text-slate-300 data-[state=active]:text-white data-[state=active]:bg-slate-700">
                    <Bell className="h-4 w-4 mr-2" />
                    Monitoring
                  </TabsTrigger>
                  <TabsTrigger value="timeline" className="text-slate-300 data-[state=active]:text-white data-[state=active]:bg-slate-700">
                    <Clock className="h-4 w-4 mr-2" />
                    Timeline
                  </TabsTrigger>
                </TabsList>

                {/* Overview Tab */}
                <TabsContent value="overview" className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    {/* Customer Details Card */}
                    <Card className="bg-slate-800/30 border-slate-700/50">
                      <CardHeader>
                        <CardTitle className="text-white flex items-center">
                          <User className="h-5 w-5 mr-2" />
                          Customer Details
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-3">
                        <div>
                          <p className="text-sm text-slate-400">Customer Name</p>
                          {isEditMode ? (
                            <input
                              type="text"
                              value={editedCustomer?.customer_name || ''}
                              onChange={(e) => handleFieldChange('customer_name', e.target.value)}
                              className="w-full px-3 py-2 bg-slate-700/50 border border-slate-600 rounded-md text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                            />
                          ) : (
                            <p className="text-white">{selectedCustomer.customer_name}</p>
                          )}
                        </div>
                        <div>
                          <p className="text-sm text-slate-400">Type</p>
                          {isEditMode ? (
                            <select
                              value={editedCustomer?.customer_type || 'individual'}
                              onChange={(e) => handleFieldChange('customer_type', e.target.value)}
                              className="w-full px-3 py-2 bg-slate-700/50 border border-slate-600 rounded-md text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                            >
                              <option value="individual">Individual</option>
                              <option value="entity">Entity</option>
                              <option value="company">Company</option>
                              <option value="organization">Organization</option>
                            </select>
                          ) : (
                            <p className="text-white capitalize">{selectedCustomer.customer_type}</p>
                          )}
                        </div>
                        <div>
                          <p className="text-sm text-slate-400">Legal Name</p>
                          {isEditMode ? (
                            <input
                              type="text"
                              value={editedCustomer?.legal_name || ''}
                              onChange={(e) => handleFieldChange('legal_name', e.target.value)}
                              className="w-full px-3 py-2 bg-slate-700/50 border border-slate-600 rounded-md text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                              placeholder="Enter legal name"
                            />
                          ) : (
                            <p className="text-white">{selectedCustomer.legal_name || 'Not provided'}</p>
                          )}
                        </div>
                        <div>
                          <p className="text-sm text-slate-400">Email</p>
                          {isEditMode ? (
                            <input
                              type="email"
                              value={editedCustomer?.email || ''}
                              onChange={(e) => handleFieldChange('email', e.target.value)}
                              className="w-full px-3 py-2 bg-slate-700/50 border border-slate-600 rounded-md text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                              placeholder="Enter email address"
                            />
                          ) : (
                            <p className="text-white">{selectedCustomer.email || 'Not provided'}</p>
                          )}
                        </div>
                        <div>
                          <p className="text-sm text-slate-400">Country</p>
                          {isEditMode ? (
                            <input
                              type="text"
                              value={editedCustomer?.country || ''}
                              onChange={(e) => handleFieldChange('country', e.target.value)}
                              className="w-full px-3 py-2 bg-slate-700/50 border border-slate-600 rounded-md text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                              placeholder="Enter country"
                            />
                          ) : (
                            <p className="text-white">{selectedCustomer.country || 'Not provided'}</p>
                          )}
                        </div>
                        <div>
                          <p className="text-sm text-slate-400">Phone</p>
                          {isEditMode ? (
                            <input
                              type="tel"
                              value={editedCustomer?.phone || ''}
                              onChange={(e) => handleFieldChange('phone', e.target.value)}
                              className="w-full px-3 py-2 bg-slate-700/50 border border-slate-600 rounded-md text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                              placeholder="Enter phone number"
                            />
                          ) : (
                            <p className="text-white">{selectedCustomer.phone || 'Not provided'}</p>
                          )}
                        </div>
                      </CardContent>
                    </Card>

                    {/* Risk Assessment Card */}
                    <Card className="bg-slate-800/30 border-slate-700/50">
                      <CardHeader>
                        <CardTitle className="text-white flex items-center">
                          <Shield className="h-5 w-5 mr-2" />
                          Risk Assessment
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-3">
                        <div>
                          <p className="text-sm text-slate-400">Risk Category</p>
                          {isEditMode ? (
                            <select
                              value={editedCustomer?.risk_category || 'standard'}
                              onChange={(e) => handleFieldChange('risk_category', e.target.value)}
                              className="w-full px-3 py-2 bg-slate-700/50 border border-slate-600 rounded-md text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                            >
                              <option value="low">Low</option>
                              <option value="standard">Standard</option>
                              <option value="high">High</option>
                              <option value="critical">Critical</option>
                            </select>
                          ) : (
                            <Badge className={getRiskLevelColor(selectedCustomer.risk_category || 'standard')}>
                              {selectedCustomer.risk_category || 'standard'}
                            </Badge>
                          )}
                        </div>
                        <div>
                          <p className="text-sm text-slate-400">Last Screening</p>
                          <p className="text-white">{selectedCustomer.last_screening_date ? formatDate(selectedCustomer.last_screening_date) : 'Never'}</p>
                        </div>
                        <div>
                          <p className="text-sm text-slate-400">Screening Score</p>
                          <p className="text-white">{selectedCustomer.screening_score || 'N/A'}</p>
                        </div>
                      </CardContent>
                    </Card>

                    {/* Activity Summary Card */}
                    <Card className="bg-slate-800/30 border-slate-700/50">
                      <CardHeader>
                        <CardTitle className="text-white flex items-center">
                          <Activity className="h-5 w-5 mr-2" />
                          Activity Summary
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-3">
                        <div>
                          <p className="text-sm text-slate-400">Total Transactions</p>
                          <p className="text-white">{customerTransactions?.length || 0}</p>
                        </div>
                        <div>
                          <p className="text-sm text-slate-400">Total Products</p>
                          <p className="text-white">{customerProducts?.length || 0}</p>
                        </div>
                        <div>
                          <p className="text-sm text-slate-400">Member Since</p>
                          <p className="text-white">{formatDate(selectedCustomer.created_at)}</p>
                        </div>
                      </CardContent>
                    </Card>
                  </div>

                  {/* Notes Section */}
                  {(selectedCustomer.notes || isEditMode) && (
                    <Card className="bg-slate-800/30 border-slate-700/50">
                      <CardHeader>
                        <CardTitle className="text-white flex items-center">
                          <FileText className="h-5 w-5 mr-2" />
                          Notes
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        {isEditMode ? (
                          <textarea
                            value={editedCustomer?.notes || ''}
                            onChange={(e) => handleFieldChange('notes', e.target.value)}
                            className="w-full px-3 py-2 bg-slate-700/50 border border-slate-600 rounded-md text-white focus:outline-none focus:ring-2 focus:ring-blue-500 min-h-[100px] resize-vertical"
                            placeholder="Enter notes about this customer..."
                          />
                        ) : (
                          <p className="text-slate-300">{selectedCustomer.notes}</p>
                        )}
                      </CardContent>
                    </Card>
                  )}
                </TabsContent>

                {/* Placeholder tabs - will show the enhanced content from previous implementation */}
                <TabsContent value="transactions" className="space-y-6">
                  <div className="text-center py-12 text-slate-400">
                    <CreditCard className="h-12 w-12 mx-auto mb-4 text-slate-500" />
                    <h3 className="text-lg font-medium text-white mb-2">Customer Transactions</h3>
                    <p>Transaction history for {selectedCustomer.customer_name} will be displayed here.</p>
                  </div>
                </TabsContent>

                <TabsContent value="products" className="space-y-6">
                  <div className="text-center py-12 text-slate-400">
                    <Package className="h-12 w-12 mx-auto mb-4 text-slate-500" />
                    <h3 className="text-lg font-medium text-white mb-2">Customer Products</h3>
                    <p>Product records for {selectedCustomer.customer_name} will be displayed here.</p>
                  </div>
                </TabsContent>

                <TabsContent value="search" className="space-y-6">
                  <div className="text-center py-12 text-slate-400">
                    <Search className="h-12 w-12 mx-auto mb-4 text-slate-500" />
                    <h3 className="text-lg font-medium text-white mb-2">Advanced Search</h3>
                    <p>Search capabilities for {selectedCustomer.customer_name} will be displayed here.</p>
                  </div>
                </TabsContent>

                <TabsContent value="reports" className="space-y-6">
                  <div className="text-center py-12 text-slate-400">
                    <FileText className="h-12 w-12 mx-auto mb-4 text-slate-500" />
                    <h3 className="text-lg font-medium text-white mb-2">Customer Reports</h3>
                    <p>Reports and analytics for {selectedCustomer.customer_name} will be displayed here.</p>
                  </div>
                </TabsContent>

                <TabsContent value="analytics" className="space-y-6">
                  {/* Advanced Analytics Dashboard */}
                  <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    {/* Real-time Risk Scoring */}
                    <Card className="bg-slate-800/30 border-slate-700/50">
                      <CardHeader>
                        <CardTitle className="text-white flex items-center">
                          <TrendingUp className="h-5 w-5 mr-2 text-blue-400" />
                          Risk Score Trends
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <div className="flex items-center justify-between">
                          <span className="text-slate-300">Current Risk Score</span>
                          <Badge className={getRiskLevelColor(selectedCustomer.risk_category || 'standard')}>
                            {selectedCustomer.risk_category === 'critical' ? '85' : 
                             selectedCustomer.risk_category === 'high' ? '72' :
                             selectedCustomer.risk_category === 'standard' ? '45' : '23'}/100
                          </Badge>
                        </div>
                        <div className="space-y-2">
                          <div className="flex justify-between text-sm">
                            <span className="text-slate-400">30-day trend</span>
                            <span className="text-green-400">-5.2%</span>
                          </div>
                          <div className="w-full bg-slate-700 rounded-full h-2">
                            <div className="bg-gradient-to-r from-green-500 to-blue-500 h-2 rounded-full" 
                                 style={{width: `${selectedCustomer.risk_category === 'critical' ? '85' : 
                                                 selectedCustomer.risk_category === 'high' ? '72' :
                                                 selectedCustomer.risk_category === 'standard' ? '45' : '23'}%`}}></div>
                          </div>
                        </div>
                        <div className="grid grid-cols-2 gap-4 pt-4">
                          <div className="text-center">
                            <p className="text-2xl font-bold text-blue-400">12</p>
                            <p className="text-xs text-slate-400">Risk Factors</p>
                          </div>
                          <div className="text-center">
                            <p className="text-2xl font-bold text-green-400">98.7%</p>
                            <p className="text-xs text-slate-400">Confidence</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>

                    {/* Activity Patterns */}
                    <Card className="bg-slate-800/30 border-slate-700/50">
                      <CardHeader>
                        <CardTitle className="text-white flex items-center">
                          <Activity className="h-5 w-5 mr-2 text-purple-400" />
                          Activity Patterns
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <div className="space-y-3">
                          <div className="flex items-center justify-between">
                            <span className="text-slate-300 text-sm">Transaction Frequency</span>
                            <span className="text-purple-400 font-medium">High</span>
                          </div>
                          <div className="flex items-center justify-between">
                            <span className="text-slate-300 text-sm">Geographic Spread</span>
                            <span className="text-amber-400 font-medium">Medium</span>
                          </div>
                          <div className="flex items-center justify-between">
                            <span className="text-slate-300 text-sm">Compliance Score</span>
                            <span className="text-green-400 font-medium">Excellent</span>
                          </div>
                        </div>
                        <div className="pt-4 border-t border-slate-700">
                          <h4 className="text-white font-medium mb-2">Behavioral Analysis</h4>
                          <div className="space-y-2 text-sm">
                            <div className="flex justify-between">
                              <span className="text-slate-400">Consistency</span>
                              <span className="text-green-400">94%</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-slate-400">Predictability</span>
                              <span className="text-blue-400">87%</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-slate-400">Anomaly Detection</span>
                              <span className="text-amber-400">2 alerts</span>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>

                    {/* Predictive Insights */}
                    <Card className="bg-slate-800/30 border-slate-700/50">
                      <CardHeader>
                        <CardTitle className="text-white flex items-center">
                          <BarChart3 className="h-5 w-5 mr-2 text-cyan-400" />
                          Predictive Insights
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <div className="space-y-3">
                          <div className="bg-slate-700/50 rounded-lg p-3">
                            <div className="flex items-center justify-between mb-2">
                              <span className="text-slate-300 text-sm">Risk Trajectory</span>
                              <Badge variant="outline" className="text-green-400 border-green-500/50">Stable</Badge>
                            </div>
                            <p className="text-xs text-slate-400">Risk likely to remain stable over next 90 days</p>
                          </div>
                          <div className="bg-slate-700/50 rounded-lg p-3">
                            <div className="flex items-center justify-between mb-2">
                              <span className="text-slate-300 text-sm">Compliance Forecast</span>
                              <Badge variant="outline" className="text-blue-400 border-blue-500/50">High</Badge>
                            </div>
                            <p className="text-xs text-slate-400">98% probability of continued compliance</p>
                          </div>
                          <div className="bg-slate-700/50 rounded-lg p-3">
                            <div className="flex items-center justify-between mb-2">
                              <span className="text-slate-300 text-sm">Anomaly Likelihood</span>
                              <Badge variant="outline" className="text-amber-400 border-amber-500/50">Low</Badge>
                            </div>
                            <p className="text-xs text-slate-400">5% chance of unusual activity next month</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </div>

                  {/* Interactive Charts Section */}
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    {/* Transaction Volume Chart */}
                    <Card className="bg-slate-800/30 border-slate-700/50">
                      <CardHeader>
                        <CardTitle className="text-white flex items-center">
                          <BarChart3 className="h-5 w-5 mr-2 text-blue-400" />
                          Transaction Volume (Last 12 Months)
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="h-64 flex items-end justify-between space-x-2">
                          {[42, 65, 38, 89, 72, 45, 67, 58, 91, 76, 83, 69].map((value, index) => (
                            <div key={index} className="flex flex-col items-center">
                              <div 
                                className="bg-gradient-to-t from-blue-500 to-cyan-400 rounded-t"
                                style={{height: `${value * 2.5}px`, width: '20px'}}
                              ></div>
                              <span className="text-xs text-slate-400 mt-2">
                                {['J', 'F', 'M', 'A', 'M', 'J', 'J', 'A', 'S', 'O', 'N', 'D'][index]}
                              </span>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>

                    {/* Risk Assessment Timeline */}
                    <Card className="bg-slate-800/30 border-slate-700/50">
                      <CardHeader>
                        <CardTitle className="text-white flex items-center">
                          <TrendingUp className="h-5 w-5 mr-2 text-purple-400" />
                          Risk Assessment Timeline
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-4">
                          {[
                            { date: '2024-08-29', risk: 'Standard', score: 45, change: '+2' },
                            { date: '2024-08-15', risk: 'Standard', score: 43, change: '-1' },
                            { date: '2024-08-01', risk: 'Standard', score: 44, change: '+5' },
                            { date: '2024-07-15', risk: 'Low', score: 39, change: '-3' },
                            { date: '2024-07-01', risk: 'Low', score: 42, change: '0' }
                          ].map((entry, index) => (
                            <div key={index} className="flex items-center justify-between py-2 border-b border-slate-700/50 last:border-b-0">
                              <div className="flex items-center space-x-3">
                                <div className="w-2 h-2 rounded-full bg-blue-400"></div>
                                <div>
                                  <p className="text-white text-sm">{entry.date}</p>
                                  <p className="text-slate-400 text-xs">{entry.risk} Risk</p>
                                </div>
                              </div>
                              <div className="flex items-center space-x-2">
                                <span className="text-white font-medium">{entry.score}</span>
                                <Badge variant="outline" className={
                                  entry.change.startsWith('+') ? 'text-green-400 border-green-500/50' :
                                  entry.change.startsWith('-') ? 'text-red-400 border-red-500/50' :
                                  'text-slate-400 border-slate-500/50'
                                }>
                                  {entry.change}
                                </Badge>
                              </div>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  </div>

                  {/* Customer Insights Summary */}
                  <Card className="bg-slate-800/30 border-slate-700/50">
                    <CardHeader>
                      <CardTitle className="text-white flex items-center">
                        <Users className="h-5 w-5 mr-2 text-emerald-400" />
                        Customer Intelligence Summary
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                        <div className="space-y-3">
                          <h4 className="text-white font-medium">Key Strengths</h4>
                          <ul className="space-y-1 text-sm">
                            <li className="flex items-center text-green-400">
                              <CheckCircle className="h-3 w-3 mr-2" />
                              Consistent compliance history
                            </li>
                            <li className="flex items-center text-green-400">
                              <CheckCircle className="h-3 w-3 mr-2" />
                              Transparent business practices
                            </li>
                            <li className="flex items-center text-green-400">
                              <CheckCircle className="h-3 w-3 mr-2" />
                              Regular transaction patterns
                            </li>
                          </ul>
                        </div>
                        <div className="space-y-3">
                          <h4 className="text-white font-medium">Areas of Interest</h4>
                          <ul className="space-y-1 text-sm">
                            <li className="flex items-center text-amber-400">
                              <AlertCircle className="h-3 w-3 mr-1" />
                              Geographic expansion
                            </li>
                            <li className="flex items-center text-amber-400">
                              <AlertCircle className="h-3 w-3 mr-2" />
                              New product lines
                            </li>
                            <li className="flex items-center text-amber-400">
                              <AlertCircle className="h-3 w-3 mr-2" />
                              Increased transaction volume
                            </li>
                          </ul>
                        </div>
                        <div className="space-y-3">
                          <h4 className="text-white font-medium">Recommendations</h4>
                          <ul className="space-y-1 text-sm">
                            <li className="flex items-center text-blue-400">
                              <Info className="h-3 w-3 mr-2" />
                              Continue standard monitoring
                            </li>
                            <li className="flex items-center text-blue-400">
                              <Info className="h-3 w-3 mr-2" />
                              Quarterly review schedule
                            </li>
                            <li className="flex items-center text-blue-400">
                              <Info className="h-3 w-3 mr-2" />
                              Enhanced due diligence for new markets
                            </li>
                          </ul>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>

                {/* Document Management Dashboard */}
                <TabsContent value="documents" className="space-y-6">
                  <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
                    {/* Upload New Document */}
                    <Card className="bg-slate-800/30 border-slate-700/50">
                      <CardHeader>
                        <CardTitle className="text-white flex items-center">
                          <Upload className="h-5 w-5 mr-2 text-green-400" />
                          Upload Document
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <div className="border-2 border-dashed border-slate-600 rounded-lg p-6 text-center hover:border-slate-500 transition-colors cursor-pointer">
                          <Upload className="h-8 w-8 mx-auto mb-2 text-slate-400" />
                          <p className="text-slate-300 text-sm mb-1">Drop files here or click to browse</p>
                          <p className="text-slate-500 text-xs">Supports PDF, DOC, DOCX, XLS, XLSX</p>
                        </div>
                        <Select value={undefined} onValueChange={(value) => console.log('Document category:', value)}>
                          <SelectTrigger className="bg-slate-700/50 border-slate-600">
                            <SelectValue placeholder="Document Category" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="kyc">KYC Documentation</SelectItem>
                            <SelectItem value="due_diligence">Due Diligence</SelectItem>
                            <SelectItem value="compliance">Compliance Records</SelectItem>
                            <SelectItem value="contracts">Contracts & Agreements</SelectItem>
                            <SelectItem value="financial">Financial Statements</SelectItem>
                            <SelectItem value="certificates">Certificates & Licenses</SelectItem>
                          </SelectContent>
                        </Select>
                        <Button className="w-full bg-green-600 hover:bg-green-700">
                          <Upload className="h-4 w-4 mr-2" />
                          Upload Document
                        </Button>
                      </CardContent>
                    </Card>

                    {/* Document Statistics */}
                    <Card className="bg-slate-800/30 border-slate-700/50">
                      <CardHeader>
                        <CardTitle className="text-white flex items-center">
                          <BarChart3 className="h-5 w-5 mr-2 text-blue-400" />
                          Document Overview
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <div className="grid grid-cols-2 gap-4">
                          <div className="text-center">
                            <p className="text-2xl font-bold text-blue-400">24</p>
                            <p className="text-xs text-slate-400">Total Documents</p>
                          </div>
                          <div className="text-center">
                            <p className="text-2xl font-bold text-green-400">18</p>
                            <p className="text-xs text-slate-400">Approved</p>
                          </div>
                        </div>
                        <div className="space-y-2">
                          <div className="flex justify-between text-sm">
                            <span className="text-slate-400">KYC Documents</span>
                            <span className="text-white">8</span>
                          </div>
                          <div className="flex justify-between text-sm">
                            <span className="text-slate-400">Due Diligence</span>
                            <span className="text-white">6</span>
                          </div>
                          <div className="flex justify-between text-sm">
                            <span className="text-slate-400">Compliance</span>
                            <span className="text-white">5</span>
                          </div>
                          <div className="flex justify-between text-sm">
                            <span className="text-slate-400">Financial</span>
                            <span className="text-white">3</span>
                          </div>
                          <div className="flex justify-between text-sm">
                            <span className="text-slate-400">Certificates</span>
                            <span className="text-white">2</span>
                          </div>
                        </div>
                      </CardContent>
                    </Card>

                    {/* Workflow Status */}
                    <Card className="bg-slate-800/30 border-slate-700/50">
                      <CardHeader>
                        <CardTitle className="text-white flex items-center">
                          <Settings className="h-5 w-5 mr-2 text-purple-400" />
                          Workflow Status
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <div className="space-y-3">
                          <div className="flex items-center justify-between">
                            <span className="text-slate-300 text-sm">Pending Review</span>
                            <Badge variant="outline" className="text-amber-400 border-amber-500/50">3</Badge>
                          </div>
                          <div className="flex items-center justify-between">
                            <span className="text-slate-300 text-sm">Under Review</span>
                            <Badge variant="outline" className="text-blue-400 border-blue-500/50">2</Badge>
                          </div>
                          <div className="flex items-center justify-between">
                            <span className="text-slate-300 text-sm">Approved</span>
                            <Badge variant="outline" className="text-green-400 border-green-500/50">18</Badge>
                          </div>
                          <div className="flex items-center justify-between">
                            <span className="text-slate-300 text-sm">Rejected</span>
                            <Badge variant="outline" className="text-red-400 border-red-500/50">1</Badge>
                          </div>
                        </div>
                        <div className="pt-4 border-t border-slate-700">
                          <div className="flex items-center justify-between mb-2">
                            <span className="text-slate-300 text-sm">Next Review</span>
                            <span className="text-blue-400 text-sm">2 days</span>
                          </div>
                          <div className="flex items-center justify-between">
                            <span className="text-slate-300 text-sm">Expiring Soon</span>
                            <span className="text-amber-400 text-sm">1 doc</span>
                          </div>
                        </div>
                      </CardContent>
                    </Card>

                    {/* Quick Actions */}
                    <Card className="bg-slate-800/30 border-slate-700/50">
                      <CardHeader>
                        <CardTitle className="text-white flex items-center">
                          <Star className="h-5 w-5 mr-2 text-amber-400" />
                          Quick Actions
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-3">
                        <Button variant="outline" className="w-full justify-start border-slate-600 text-white hover:bg-slate-700">
                          <Download className="h-4 w-4 mr-2" />
                          Download All Documents
                        </Button>
                        <Button variant="outline" className="w-full justify-start border-slate-600 text-white hover:bg-slate-700">
                          <Mail className="h-4 w-4 mr-2" />
                          Request Missing Documents
                        </Button>
                        <Button variant="outline" className="w-full justify-start border-slate-600 text-white hover:bg-slate-700">
                          <RefreshCw className="h-4 w-4 mr-2" />
                          Schedule Review
                        </Button>
                        <Button variant="outline" className="w-full justify-start border-slate-600 text-white hover:bg-slate-700">
                          <Shield className="h-4 w-4 mr-2" />
                          Compliance Check
                        </Button>
                      </CardContent>
                    </Card>
                  </div>

                  {/* Document List */}
                  <Card className="bg-slate-800/30 border-slate-700/50">
                    <CardHeader>
                      <div className="flex justify-between items-center">
                        <CardTitle className="text-white flex items-center">
                          <FolderOpen className="h-5 w-5 mr-2 text-cyan-400" />
                          Document Repository
                        </CardTitle>
                        <div className="flex space-x-2">
                          <Select value={undefined} onValueChange={(value) => console.log('Filter category:', value)}>
                            <SelectTrigger className="w-40 bg-slate-700/50 border-slate-600">
                              <SelectValue placeholder="Filter by category" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="all">All Categories</SelectItem>
                              <SelectItem value="kyc">KYC Documentation</SelectItem>
                              <SelectItem value="due_diligence">Due Diligence</SelectItem>
                              <SelectItem value="compliance">Compliance Records</SelectItem>
                              <SelectItem value="financial">Financial Statements</SelectItem>
                            </SelectContent>
                          </Select>
                          <Button variant="outline" size="sm" className="border-slate-600 text-white hover:bg-slate-700">
                            <Filter className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        {[
                          {
                            name: 'Certificate_of_Incorporation.pdf',
                            category: 'KYC Documentation',
                            uploadDate: '2024-08-25',
                            status: 'approved',
                            version: '1.2',
                            size: '2.4 MB',
                            expiryDate: '2025-08-25'
                          },
                          {
                            name: 'Financial_Statements_2024.xlsx',
                            category: 'Financial Statements',
                            uploadDate: '2024-08-20',
                            status: 'under_review',
                            version: '1.0',
                            size: '1.8 MB',
                            expiryDate: null
                          },
                          {
                            name: 'Due_Diligence_Report.docx',
                            category: 'Due Diligence',
                            uploadDate: '2024-08-15',
                            status: 'pending_review',
                            version: '3.1',
                            size: '4.2 MB',
                            expiryDate: '2024-12-15'
                          },
                          {
                            name: 'Compliance_Audit_2024.pdf',
                            category: 'Compliance Records',
                            uploadDate: '2024-08-10',
                            status: 'approved',
                            version: '1.0',
                            size: '3.7 MB',
                            expiryDate: '2025-08-10'
                          },
                          {
                            name: 'Business_License.pdf',
                            category: 'Certificates & Licenses',
                            uploadDate: '2024-08-05',
                            status: 'expired',
                            version: '2.0',
                            size: '1.1 MB',
                            expiryDate: '2024-08-01'
                          }
                        ].map((doc, index) => (
                          <div key={index} className="bg-slate-700/30 rounded-lg p-4 border border-slate-600/50">
                            <div className="flex items-start justify-between">
                              <div className="flex items-start space-x-3">
                                <div className="flex-shrink-0 mt-1">
                                  <FileText className="h-5 w-5 text-blue-400" />
                                </div>
                                <div className="flex-1">
                                  <div className="flex items-center space-x-2 mb-1">
                                    <h4 className="text-white font-medium">{doc.name}</h4>
                                    <Badge variant="outline" className="text-xs text-slate-400 border-slate-500/50">
                                      v{doc.version}
                                    </Badge>
                                  </div>
                                  <div className="flex items-center space-x-4 text-sm text-slate-400">
                                    <span>{doc.category}</span>
                                    <span>•</span>
                                    <span>{doc.size}</span>
                                    <span>•</span>
                                    <span>Uploaded {doc.uploadDate}</span>
                                    {doc.expiryDate && (
                                      <>
                                        <span>•</span>
                                        <span className={doc.status === 'expired' ? 'text-red-400' : 'text-slate-400'}>
                                          Expires {doc.expiryDate}
                                        </span>
                                      </>
                                    )}
                                  </div>
                                </div>
                              </div>
                              <div className="flex items-center space-x-2">
                                <Badge 
                                  variant="outline" 
                                  className={
                                    doc.status === 'approved' ? 'text-green-400 border-green-500/50' :
                                    doc.status === 'under_review' ? 'text-blue-400 border-blue-500/50' :
                                    doc.status === 'pending_review' ? 'text-amber-400 border-amber-500/50' :
                                    doc.status === 'expired' ? 'text-red-400 border-red-500/50' :
                                    'text-slate-400 border-slate-500/50'
                                  }
                                >
                                  {doc.status.replace('_', ' ')}
                                </Badge>
                                <Button variant="ghost" size="sm" className="text-slate-400 hover:text-white hover:bg-slate-600">
                                  <Eye className="h-4 w-4" />
                                </Button>
                                <Button variant="ghost" size="sm" className="text-slate-400 hover:text-white hover:bg-slate-600">
                                  <Download className="h-4 w-4" />
                                </Button>
                                <Button variant="ghost" size="sm" className="text-slate-400 hover:text-white hover:bg-slate-600">
                                  <Edit className="h-4 w-4" />
                                </Button>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>

                  {/* Document Audit Trail */}
                  <Card className="bg-slate-800/30 border-slate-700/50">
                    <CardHeader>
                      <CardTitle className="text-white flex items-center">
                        <Clock className="h-5 w-5 mr-2 text-orange-400" />
                        Document Audit Trail
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        {[
                          {
                            action: 'Document Approved',
                            document: 'Certificate_of_Incorporation.pdf',
                            user: 'Compliance Team',
                            timestamp: '2024-08-25 14:30',
                            type: 'approval'
                          },
                          {
                            action: 'Document Uploaded',
                            document: 'Financial_Statements_2024.xlsx',
                            user: selectedCustomer.customer_name,
                            timestamp: '2024-08-20 09:15',
                            type: 'upload'
                          },
                          {
                            action: 'Review Requested',
                            document: 'Due_Diligence_Report.docx',
                            user: 'Risk Assessment Team',
                            timestamp: '2024-08-15 16:45',
                            type: 'review'
                          },
                          {
                            action: 'Document Approved',
                            document: 'Compliance_Audit_2024.pdf',
                            user: 'Senior Compliance Officer',
                            timestamp: '2024-08-10 11:20',
                            type: 'approval'
                          },
                          {
                            action: 'Document Expired',
                            document: 'Business_License.pdf',
                            user: 'System',
                            timestamp: '2024-08-01 00:00',
                            type: 'expiry'
                          }
                        ].map((entry, index) => (
                          <div key={index} className="flex items-start space-x-3 pb-4 border-b border-slate-700/50 last:border-b-0 last:pb-0">
                            <div className="flex-shrink-0 mt-1">
                              <div className={
                                `w-2 h-2 rounded-full ${
                                  entry.type === 'approval' ? 'bg-green-400' :
                                  entry.type === 'upload' ? 'bg-blue-400' :
                                  entry.type === 'review' ? 'bg-amber-400' :
                                  entry.type === 'expiry' ? 'bg-red-400' : 'bg-slate-400'
                                }`
                              }></div>
                            </div>
                            <div className="flex-1">
                              <div className="flex items-center justify-between">
                                <div>
                                  <p className="text-white text-sm font-medium">{entry.action}</p>
                                  <p className="text-slate-400 text-xs">{entry.document}</p>
                                </div>
                                <div className="text-right">
                                  <p className="text-slate-400 text-xs">{entry.user}</p>
                                  <p className="text-slate-500 text-xs">{entry.timestamp}</p>
                                </div>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>

                {/* Monitoring & Automation Dashboard */}
                <TabsContent value="monitoring" className="space-y-6">
                  {/* Monitoring & Automation Dashboard */}
                  <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    {/* Monitoring Status */}
                    <Card className="bg-slate-800/30 border-slate-700/50">
                      <CardHeader>
                        <CardTitle className="text-white flex items-center">
                          <Shield className="h-5 w-5 mr-2 text-green-400" />
                          Monitoring Status
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <div className="flex items-center justify-between">
                          <span className="text-slate-300">Active Monitoring</span>
                          <Badge className="bg-green-500/20 text-green-400 border-green-500/50">
                            <CheckCircle className="h-3 w-3 mr-1" />
                            Active
                          </Badge>
                        </div>
                        <div className="space-y-3">
                          <div className="flex justify-between">
                            <span className="text-slate-400 text-sm">Real-time Screening</span>
                            <span className="text-green-400 text-sm">Enabled</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-slate-400 text-sm">Risk Threshold</span>
                            <span className="text-blue-400 text-sm">Medium</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-slate-400 text-sm">Alert Priority</span>
                            <span className="text-amber-400 text-sm">High</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-slate-400 text-sm">Last Check</span>
                            <span className="text-slate-300 text-sm">2 min ago</span>
                          </div>
                        </div>
                        <div className="pt-4 border-t border-slate-700">
                          <div className="grid grid-cols-2 gap-4">
                            <div className="text-center">
                              <p className="text-lg font-bold text-blue-400">24/7</p>
                              <p className="text-xs text-slate-400">Monitoring</p>
                            </div>
                            <div className="text-center">
                              <p className="text-lg font-bold text-green-400">99.9%</p>
                              <p className="text-xs text-slate-400">Uptime</p>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>

                    {/* Alert Configuration */}
                    <Card className="bg-slate-800/30 border-slate-700/50">
                      <CardHeader>
                        <CardTitle className="text-white flex items-center">
                          <Bell className="h-5 w-5 mr-2 text-amber-400" />
                          Alert System
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <div className="space-y-3">
                          <div className="flex items-center justify-between">
                            <span className="text-slate-300 text-sm">Email Alerts</span>
                            <Badge variant="outline" className="text-green-400 border-green-500/50">Enabled</Badge>
                          </div>
                          <div className="flex items-center justify-between">
                            <span className="text-slate-300 text-sm">SMS Notifications</span>
                            <Badge variant="outline" className="text-blue-400 border-blue-500/50">Enabled</Badge>
                          </div>
                          <div className="flex items-center justify-between">
                            <span className="text-slate-300 text-sm">Dashboard Alerts</span>
                            <Badge variant="outline" className="text-green-400 border-green-500/50">Enabled</Badge>
                          </div>
                          <div className="flex items-center justify-between">
                            <span className="text-slate-300 text-sm">Webhook Integration</span>
                            <Badge variant="outline" className="text-slate-400 border-slate-500/50">Disabled</Badge>
                          </div>
                        </div>
                        <div className="pt-4 border-t border-slate-700">
                          <h4 className="text-white font-medium mb-2">Alert Thresholds</h4>
                          <div className="space-y-2 text-sm">
                            <div className="flex justify-between">
                              <span className="text-slate-400">Risk Score Change</span>
                              <span className="text-amber-400">≥15 points</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-slate-400">Sanctions Match</span>
                              <span className="text-red-400">Immediate</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-slate-400">Unusual Activity</span>
                              <span className="text-blue-400">≥3 anomalies</span>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>

                    {/* Automation Settings */}
                    <Card className="bg-slate-800/30 border-slate-700/50">
                      <CardHeader>
                        <CardTitle className="text-white flex items-center">
                          <Settings className="h-5 w-5 mr-2 text-purple-400" />
                          Automation Rules
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <div className="space-y-3">
                          <div className="bg-slate-700/50 rounded-lg p-3">
                            <div className="flex items-center justify-between mb-2">
                              <span className="text-slate-300 text-sm">Daily Screening</span>
                              <Badge variant="outline" className="text-green-400 border-green-500/50">Active</Badge>
                            </div>
                            <p className="text-xs text-slate-400">Automated daily sanctions and PEP screening at 06:00 UTC</p>
                          </div>
                          <div className="bg-slate-700/50 rounded-lg p-3">
                            <div className="flex items-center justify-between mb-2">
                              <span className="text-slate-300 text-sm">Risk Re-assessment</span>
                              <Badge variant="outline" className="text-blue-400 border-blue-500/50">Weekly</Badge>
                            </div>
                            <p className="text-xs text-slate-400">Automatic risk score recalculation every Monday</p>
                          </div>
                          <div className="bg-slate-700/50 rounded-lg p-3">
                            <div className="flex items-center justify-between mb-2">
                              <span className="text-slate-300 text-sm">Document Expiry</span>
                              <Badge variant="outline" className="text-amber-400 border-amber-500/50">30 days</Badge>
                            </div>
                            <p className="text-xs text-slate-400">Alert 30 days before document expiration</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </div>

                  {/* Screening Schedule Configuration */}
                  <Card className="bg-slate-800/30 border-slate-700/50">
                    <CardHeader>
                      <div className="flex justify-between items-center">
                        <CardTitle className="text-white flex items-center">
                          <Calendar className="h-5 w-5 mr-2 text-cyan-400" />
                          Automated Screening Schedule
                        </CardTitle>
                        <Button className="bg-blue-600 hover:bg-blue-700">
                          <Plus className="h-4 w-4 mr-2" />
                          Add Schedule
                        </Button>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                        {/* Current Schedules */}
                        <div className="space-y-4">
                          <h4 className="text-white font-medium">Active Schedules</h4>
                          {[
                            {
                              name: 'Daily Sanctions Screening',
                              frequency: 'Daily at 06:00 UTC',
                              status: 'active',
                              lastRun: '2024-08-29 06:00',
                              nextRun: '2024-08-30 06:00',
                              type: 'sanctions'
                            },
                            {
                              name: 'Weekly Risk Assessment',
                              frequency: 'Every Monday at 09:00 UTC',
                              status: 'active',
                              lastRun: '2024-08-26 09:00',
                              nextRun: '2024-09-02 09:00',
                              type: 'risk'
                            },
                            {
                              name: 'Monthly Compliance Review',
                              frequency: 'First Monday of each month',
                              status: 'active',
                              lastRun: '2024-08-05 10:00',
                              nextRun: '2024-09-02 10:00',
                              type: 'compliance'
                            },
                            {
                              name: 'Quarterly Deep Screening',
                              frequency: 'Every 3 months',
                              status: 'scheduled',
                              lastRun: '2024-08-01 08:00',
                              nextRun: '2024-11-01 08:00',
                              type: 'comprehensive'
                            }
                          ].map((schedule, index) => (
                            <div key={index} className="bg-slate-700/30 rounded-lg p-4 border border-slate-600/50">
                              <div className="flex items-start justify-between">
                                <div className="flex-1">
                                  <div className="flex items-center space-x-2 mb-2">
                                    <h5 className="text-white font-medium">{schedule.name}</h5>
                                    <Badge 
                                      variant="outline" 
                                      className={
                                        schedule.status === 'active' ? 'text-green-400 border-green-500/50' :
                                        schedule.status === 'scheduled' ? 'text-blue-400 border-blue-500/50' :
                                        'text-slate-400 border-slate-500/50'
                                      }
                                    >
                                      {schedule.status}
                                    </Badge>
                                  </div>
                                  <p className="text-slate-400 text-sm mb-2">{schedule.frequency}</p>
                                  <div className="grid grid-cols-2 gap-4 text-xs">
                                    <div>
                                      <span className="text-slate-500">Last Run:</span>
                                      <p className="text-slate-300">{schedule.lastRun}</p>
                                    </div>
                                    <div>
                                      <span className="text-slate-500">Next Run:</span>
                                      <p className="text-slate-300">{schedule.nextRun}</p>
                                    </div>
                                  </div>
                                </div>
                                <div className="flex space-x-2">
                                  <Button variant="ghost" size="sm" className="text-slate-400 hover:text-white hover:bg-slate-600">
                                    <Edit className="h-4 w-4" />
                                  </Button>
                                  <Button variant="ghost" size="sm" className="text-slate-400 hover:text-white hover:bg-slate-600">
                                    <Settings className="h-4 w-4" />
                                  </Button>
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>

                        {/* Schedule Configuration */}
                        <div className="space-y-4">
                          <h4 className="text-white font-medium">Quick Configuration</h4>
                          <div className="bg-slate-700/30 rounded-lg p-4 border border-slate-600/50 space-y-4">
                            <div>
                              <label className="text-slate-300 text-sm block mb-2">Screening Type</label>
                              <Select value={undefined} onValueChange={(value) => console.log('Screening type:', value)}>
                                <SelectTrigger className="bg-slate-700/50 border-slate-600">
                                  <SelectValue placeholder="Select screening type" />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="sanctions">Sanctions & PEP Screening</SelectItem>
                                  <SelectItem value="risk">Risk Assessment</SelectItem>
                                  <SelectItem value="compliance">Compliance Check</SelectItem>
                                  <SelectItem value="comprehensive">Comprehensive Review</SelectItem>
                                </SelectContent>
                              </Select>
                            </div>
                            <div>
                              <label className="text-slate-300 text-sm block mb-2">Frequency</label>
                              <Select value={undefined} onValueChange={(value) => console.log('Frequency:', value)}>
                                <SelectTrigger className="bg-slate-700/50 border-slate-600">
                                  <SelectValue placeholder="Select frequency" />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="daily">Daily</SelectItem>
                                  <SelectItem value="weekly">Weekly</SelectItem>
                                  <SelectItem value="monthly">Monthly</SelectItem>
                                  <SelectItem value="quarterly">Quarterly</SelectItem>
                                  <SelectItem value="custom">Custom</SelectItem>
                                </SelectContent>
                              </Select>
                            </div>
                            <div>
                              <label className="text-slate-300 text-sm block mb-2">Time (UTC)</label>
                              <Input 
                                type="time" 
                                className="bg-slate-700/50 border-slate-600 text-white"
                                defaultValue="09:00"
                              />
                            </div>
                            <div className="flex items-center space-x-2">
                              <input type="checkbox" id="immediate" className="rounded border-slate-600" />
                              <label htmlFor="immediate" className="text-slate-300 text-sm">Run immediately after creation</label>
                            </div>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  {/* Recent Activity & Alerts */}
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    {/* Recent Monitoring Activity */}
                    <Card className="bg-slate-800/30 border-slate-700/50">
                      <CardHeader>
                        <CardTitle className="text-white flex items-center">
                          <Activity className="h-5 w-5 mr-2 text-green-400" />
                          Recent Monitoring Activity
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-4">
                          {[
                            {
                              type: 'screening',
                              message: 'Daily sanctions screening completed',
                              timestamp: '2024-08-29 06:05',
                              status: 'success',
                              details: 'No matches found'
                            },
                            {
                              type: 'alert',
                              message: 'Risk score threshold exceeded',
                              timestamp: '2024-08-28 14:22',
                              status: 'warning',
                              details: 'Score increased by 18 points'
                            },
                            {
                              type: 'system',
                              message: 'Automated compliance check initiated',
                              timestamp: '2024-08-28 10:00',
                              status: 'info',
                              details: 'Weekly scheduled check'
                            },
                            {
                              type: 'screening',
                              message: 'PEP screening completed',
                              timestamp: '2024-08-27 18:30',
                              status: 'success',
                              details: 'No new matches'
                            },
                            {
                              type: 'alert',
                              message: 'Document expiry notification sent',
                              timestamp: '2024-08-27 09:15',
                              status: 'info',
                              details: 'Business license expires in 30 days'
                            }
                          ].map((activity, index) => (
                            <div key={index} className="flex items-start space-x-3 pb-3 border-b border-slate-700/50 last:border-b-0 last:pb-0">
                              <div className="flex-shrink-0 mt-1">
                                <div className={
                                  `w-2 h-2 rounded-full ${
                                    activity.status === 'success' ? 'bg-green-400' :
                                    activity.status === 'warning' ? 'bg-amber-400' :
                                    activity.status === 'error' ? 'bg-red-400' :
                                    'bg-blue-400'
                                  }`
                                }></div>
                              </div>
                              <div className="flex-1">
                                <p className="text-white text-sm font-medium">{activity.message}</p>
                                <p className="text-slate-400 text-xs mb-1">{activity.details}</p>
                                <p className="text-slate-500 text-xs">{activity.timestamp}</p>
                              </div>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>

                    {/* Active Alerts */}
                    <Card className="bg-slate-800/30 border-slate-700/50">
                      <CardHeader>
                        <CardTitle className="text-white flex items-center">
                          <AlertTriangle className="h-5 w-5 mr-2 text-amber-400" />
                          Active Alerts
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-4">
                          {[
                            {
                              priority: 'high',
                              title: 'Risk Score Increase',
                              description: 'Customer risk score increased significantly',
                              timestamp: '2024-08-28 14:22',
                              action: 'Review Required'
                            },
                            {
                              priority: 'medium',
                              title: 'Document Expiry Warning',
                              description: 'Business license expires in 30 days',
                              timestamp: '2024-08-27 09:15',
                              action: 'Request Renewal'
                            },
                            {
                              priority: 'low',
                              title: 'Screening Schedule Updated',
                              description: 'Daily screening schedule modified',
                              timestamp: '2024-08-26 16:45',
                              action: 'Acknowledged'
                            }
                          ].map((alert, index) => (
                            <div key={index} className="bg-slate-700/30 rounded-lg p-3 border border-slate-600/50">
                              <div className="flex items-start justify-between mb-2">
                                <div className="flex items-center space-x-2">
                                  <Badge 
                                    variant="outline" 
                                    className={
                                      alert.priority === 'high' ? 'text-red-400 border-red-500/50' :
                                      alert.priority === 'medium' ? 'text-amber-400 border-amber-500/50' :
                                      'text-blue-400 border-blue-500/50'
                                    }
                                  >
                                    {alert.priority} priority
                                  </Badge>
                                  <span className="text-slate-500 text-xs">{alert.timestamp}</span>
                                </div>
                                <Button variant="ghost" size="sm" className="text-slate-400 hover:text-white hover:bg-slate-600">
                                  <X className="h-3 w-3" />
                                </Button>
                              </div>
                              <h5 className="text-white font-medium mb-1">{alert.title}</h5>
                              <p className="text-slate-400 text-sm mb-2">{alert.description}</p>
                              <div className="flex justify-between items-center">
                                <span className="text-blue-400 text-xs">{alert.action}</span>
                                <Button variant="outline" size="sm" className="border-slate-600 text-white hover:bg-slate-700">
                                  Take Action
                                </Button>
                              </div>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </TabsContent>

                {/* Timeline & Activity Feed */}
                <TabsContent value="timeline" className="space-y-6">
                  {/* Timeline Header */}
                  <Card className="bg-slate-800/30 border-slate-700/50">
                    <CardHeader>
                      <div className="flex justify-between items-center">
                        <CardTitle className="text-white flex items-center">
                          <Clock className="h-5 w-5 mr-2 text-cyan-400" />
                          Customer Timeline & Activity Feed
                        </CardTitle>
                        <div className="flex space-x-2">
                          <Select>
                            <SelectTrigger className="w-40 bg-slate-700/50 border-slate-600">
                              <SelectValue placeholder="Filter by type" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="all">All Activities</SelectItem>
                              <SelectItem value="transactions">Transactions</SelectItem>
                              <SelectItem value="screenings">Screenings</SelectItem>
                              <SelectItem value="documents">Documents</SelectItem>
                              <SelectItem value="risk">Risk Changes</SelectItem>
                              <SelectItem value="compliance">Compliance</SelectItem>
                              <SelectItem value="system">System Events</SelectItem>
                            </SelectContent>
                          </Select>
                          <Select>
                            <SelectTrigger className="w-32 bg-slate-700/50 border-slate-600">
                              <SelectValue placeholder="Time range" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="7d">Last 7 days</SelectItem>
                              <SelectItem value="30d">Last 30 days</SelectItem>
                              <SelectItem value="90d">Last 90 days</SelectItem>
                              <SelectItem value="1y">Last year</SelectItem>
                              <SelectItem value="all">All time</SelectItem>
                            </SelectContent>
                          </Select>
                          <Button variant="outline" size="sm" className="border-slate-600 text-white hover:bg-slate-700">
                            <Download className="h-4 w-4 mr-2" />
                            Export
                          </Button>
                        </div>
                      </div>
                    </CardHeader>
                  </Card>

                  {/* Timeline Stats */}
                  <div className="grid grid-cols-1 lg:grid-cols-6 gap-4">
                    <Card className="bg-slate-800/30 border-slate-700/50">
                      <CardContent className="p-4 text-center">
                        <p className="text-2xl font-bold text-blue-400">156</p>
                        <p className="text-xs text-slate-400">Total Events</p>
                      </CardContent>
                    </Card>
                    <Card className="bg-slate-800/30 border-slate-700/50">
                      <CardContent className="p-4 text-center">
                        <p className="text-2xl font-bold text-green-400">42</p>
                        <p className="text-xs text-slate-400">Transactions</p>
                      </CardContent>
                    </Card>
                    <Card className="bg-slate-800/30 border-slate-700/50">
                      <CardContent className="p-4 text-center">
                        <p className="text-2xl font-bold text-purple-400">28</p>
                        <p className="text-xs text-slate-400">Screenings</p>
                      </CardContent>
                    </Card>
                    <Card className="bg-slate-800/30 border-slate-700/50">
                      <CardContent className="p-4 text-center">
                        <p className="text-2xl font-bold text-amber-400">18</p>
                        <p className="text-xs text-slate-400">Documents</p>
                      </CardContent>
                    </Card>
                    <Card className="bg-slate-800/30 border-slate-700/50">
                      <CardContent className="p-4 text-center">
                        <p className="text-2xl font-bold text-red-400">12</p>
                        <p className="text-xs text-slate-400">Risk Changes</p>
                      </CardContent>
                    </Card>
                    <Card className="bg-slate-800/30 border-slate-700/50">
                      <CardContent className="p-4 text-center">
                        <p className="text-2xl font-bold text-cyan-400">56</p>
                        <p className="text-xs text-slate-400">System Events</p>
                      </CardContent>
                    </Card>
                  </div>

                  {/* Main Timeline */}
                  <Card className="bg-slate-800/30 border-slate-700/50">
                    <CardContent className="p-6">
                      <div className="relative">
                        {/* Timeline Line */}
                        <div className="absolute left-8 top-0 bottom-0 w-0.5 bg-slate-600"></div>
                        
                        {/* Timeline Events */}
                        <div className="space-y-8">
                          {[
                            {
                              timestamp: '2024-08-29 08:00:00',
                              type: 'system',
                              category: 'Automated Screening',
                              title: 'Daily Sanctions Screening Completed',
                              description: 'Automated daily screening against global sanctions lists completed successfully.',
                              details: {
                                status: 'No matches found',
                                lists_checked: ['OFAC SDN', 'EU Consolidated', 'UN Security Council'],
                                execution_time: '2.3 seconds'
                              },
                              importance: 'low',
                              icon: Shield,
                              iconColor: 'text-green-400'
                            },
                            {
                              timestamp: '2024-08-28 14:22:15',
                              type: 'risk',
                              category: 'Risk Assessment',
                              title: 'Risk Score Increased - Critical Alert',
                              description: 'Customer risk score increased from 45 to 68 due to geographic expansion into high-risk jurisdictions.',
                              details: {
                                previous_score: 45,
                                new_score: 68,
                                change_reason: 'Geographic expansion',
                                risk_factors: ['High-risk jurisdiction', 'Complex ownership structure'],
                                reviewed_by: 'Risk Assessment Team'
                              },
                              importance: 'high',
                              icon: AlertTriangle,
                              iconColor: 'text-red-400'
                            },
                            {
                              timestamp: '2024-08-28 11:45:30',
                              type: 'transaction',
                              category: 'Financial Transaction',
                              title: 'Large Transaction Processed',
                              description: 'High-value transaction of $2,500,000 processed for dual-use technology equipment.',
                              details: {
                                amount: '$2,500,000',
                                currency: 'USD',
                                product: 'Advanced manufacturing equipment',
                                destination: 'Germany',
                                license_required: 'Yes',
                                license_number: 'EXP-2024-DE-1847'
                              },
                              importance: 'high',
                              icon: DollarSign,
                              iconColor: 'text-green-400'
                            },
                            {
                              timestamp: '2024-08-27 16:30:45',
                              type: 'document',
                              category: 'Document Management',
                              title: 'KYC Documentation Updated',
                              description: 'Customer submitted updated certificate of incorporation and beneficial ownership information.',
                              details: {
                                documents_uploaded: ['Certificate_of_Incorporation_v2.pdf', 'Beneficial_Ownership_Statement.pdf'],
                                review_status: 'Pending compliance review',
                                uploaded_by: selectedCustomer.customer_name,
                                file_sizes: ['2.4 MB', '1.8 MB']
                              },
                              importance: 'medium',
                              icon: FileText,
                              iconColor: 'text-blue-400'
                            },
                            {
                              timestamp: '2024-08-27 09:15:20',
                              type: 'compliance',
                              category: 'Compliance Action',
                              title: 'Enhanced Due Diligence Initiated',
                              description: 'Enhanced Due Diligence process initiated following risk score increase and transaction pattern analysis.',
                              details: {
                                trigger: 'Risk score threshold exceeded',
                                assigned_to: 'Senior Compliance Officer',
                                expected_completion: '2024-09-10',
                                checklist_items: ['Source of funds verification', 'Business purpose analysis', 'Ultimate beneficial owner verification']
                              },
                              importance: 'high',
                              icon: UserCheck,
                              iconColor: 'text-purple-400'
                            },
                            {
                              timestamp: '2024-08-26 13:20:10',
                              type: 'screening',
                              category: 'PEP Screening',
                              title: 'Politically Exposed Person Screening',
                              description: 'Comprehensive PEP screening completed as part of enhanced due diligence process.',
                              details: {
                                screening_result: 'No direct PEP matches',
                                associated_persons: '2 business associates flagged',
                                databases_checked: ['World-Check', 'Dow Jones', 'LexisNexis'],
                                review_required: 'Yes - associate connections'
                              },
                              importance: 'medium',
                              icon: Search,
                              iconColor: 'text-amber-400'
                            },
                            {
                              timestamp: '2024-08-25 10:30:00',
                              type: 'transaction',
                              category: 'Financial Transaction',
                              title: 'Export License Application Submitted',
                              description: 'Export license application submitted for controlled technology transfer to European subsidiary.',
                              details: {
                                license_type: 'Dual-use technology export',
                                destination_country: 'Germany',
                                eccn_code: '3A001.b.2',
                                application_number: 'EXP-2024-DE-1847',
                                estimated_value: '$2,500,000'
                              },
                              importance: 'high',
                              icon: FileCheck,
                              iconColor: 'text-cyan-400'
                            },
                            {
                              timestamp: '2024-08-24 15:45:30',
                              type: 'system',
                              category: 'System Event',
                              title: 'Customer Profile Created',
                              description: 'Initial customer profile established following comprehensive onboarding and due diligence process.',
                              details: {
                                onboarding_completed_by: 'Customer Relations Team',
                                initial_risk_score: 32,
                                documents_collected: ['Certificate of incorporation', 'Business license', 'Bank reference letter'],
                                compliance_review: 'Completed',
                                approval_status: 'Approved for business relationship'
                              },
                              importance: 'medium',
                              icon: UserPlus,
                              iconColor: 'text-green-400'
                            }
                          ].map((event, index) => (
                            <div key={index} className="relative flex items-start space-x-4">
                              {/* Timeline Node */}
                              <div className={
                                `relative z-10 flex items-center justify-center w-8 h-8 rounded-full border-2 ${
                                  event.importance === 'high' ? 'bg-red-500/20 border-red-500' :
                                  event.importance === 'medium' ? 'bg-amber-500/20 border-amber-500' :
                                  'bg-slate-500/20 border-slate-500'
                                }`
                              }>
                                <event.icon className={`h-4 w-4 ${event.iconColor}`} />
                              </div>
                              
                              {/* Event Content */}
                              <div className="flex-1 bg-slate-700/30 rounded-lg p-4 border border-slate-600/50">
                                <div className="flex items-start justify-between mb-2">
                                  <div className="flex-1">
                                    <div className="flex items-center space-x-2 mb-1">
                                      <h4 className="text-white font-medium">{event.title}</h4>
                                      <Badge 
                                        variant="outline" 
                                        className={
                                          event.type === 'transaction' ? 'text-green-400 border-green-500/50' :
                                          event.type === 'screening' ? 'text-purple-400 border-purple-500/50' :
                                          event.type === 'document' ? 'text-blue-400 border-blue-500/50' :
                                          event.type === 'risk' ? 'text-red-400 border-red-500/50' :
                                          event.type === 'compliance' ? 'text-amber-400 border-amber-500/50' :
                                          'text-slate-400 border-slate-500/50'
                                        }
                                      >
                                        {event.category}
                                      </Badge>
                                      {event.importance === 'high' && (
                                        <Badge className="bg-red-500/20 text-red-400 border-red-500/50">
                                          Critical
                                        </Badge>
                                      )}
                                    </div>
                                    <p className="text-slate-300 text-sm mb-2">{event.description}</p>
                                    <p className="text-slate-500 text-xs">{event.timestamp}</p>
                                  </div>
                                  <Button variant="ghost" size="sm" className="text-slate-400 hover:text-white hover:bg-slate-600">
                                    <MoreHorizontal className="h-4 w-4" />
                                  </Button>
                                </div>
                                
                                {/* Event Details */}
                                <div className="mt-3 pt-3 border-t border-slate-600/50">
                                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-3 text-sm">
                                    {Object.entries(event.details).map(([key, value]) => (
                                      <div key={key} className="flex justify-between">
                                        <span className="text-slate-400 capitalize">{key.replace('_', ' ')}:</span>
                                        <span className="text-slate-200 font-medium">
                                          {Array.isArray(value) ? value.join(', ') : String(value)}
                                        </span>
                                      </div>
                                    ))}
                                  </div>
                                </div>
                                
                                {/* Action Buttons */}
                                <div className="flex space-x-2 mt-3">
                                  <Button variant="outline" size="sm" className="border-slate-600 text-white hover:bg-slate-700">
                                    <Eye className="h-3 w-3 mr-1" />
                                    View Details
                                  </Button>
                                  {event.type === 'document' && (
                                    <Button variant="outline" size="sm" className="border-slate-600 text-white hover:bg-slate-700">
                                      <Download className="h-3 w-3 mr-1" />
                                      Download
                                    </Button>
                                  )}
                                  {event.type === 'risk' && (
                                    <Button variant="outline" size="sm" className="border-slate-600 text-white hover:bg-slate-700">
                                      <AlertTriangle className="h-3 w-3 mr-1" />
                                      Review
                                    </Button>
                                  )}
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                        
                        {/* Load More */}
                        <div className="text-center mt-8">
                          <Button variant="outline" className="border-slate-600 text-white hover:bg-slate-700">
                            <RefreshCw className="h-4 w-4 mr-2" />
                            Load More Events
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </div>
      ) : (
        // Main Customer Profiles Table View  
        <>
          {/* Header Section */}
          <Card className="bg-slate-900/30 border-slate-700/50">
            <CardHeader>
              <div className="flex justify-between items-center">
                <div>
                  <CardTitle className="text-white">Customer Profile Management</CardTitle>
                  <CardDescription className="text-slate-400">
                    Comprehensive customer screening and profile management
                  </CardDescription>
                </div>
                <div className="flex space-x-3">
                  <Button onClick={() => setShowAddCustomer(true)} className="bg-blue-600 hover:bg-blue-700">
                    <Plus className="h-4 w-4 mr-2" />
                    Add Customer
                  </Button>
                  <Button onClick={onRefresh} variant="outline" className="border-slate-600 text-white hover:bg-slate-700">
                    <RefreshCw className="h-4 w-4 mr-2" />
                    Refresh
                  </Button>
                </div>
              </div>
            </CardHeader>
          </Card>

          {/* Customer Analytics Overview */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card className="bg-slate-900/30 border-slate-700/50">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-slate-400">Total Customers</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-white">{customerAnalytics.total}</div>
                <div className="text-xs text-slate-500">Active profiles</div>
              </CardContent>
            </Card>
            
            <Card className="bg-slate-900/30 border-slate-700/50">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-slate-400">High Risk</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-red-400">{customerAnalytics.byRisk.high + customerAnalytics.byRisk.critical}</div>
                <div className="text-xs text-slate-500">Requiring attention</div>
              </CardContent>
            </Card>
            
            <Card className="bg-slate-900/30 border-slate-700/50">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-slate-400">Companies</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-green-400">{customerAnalytics.byType.company + customerAnalytics.byType.entity}</div>
                <div className="text-xs text-slate-500">Corporate clients</div>
              </CardContent>
            </Card>
            
            <Card className="bg-slate-900/30 border-slate-700/50">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-slate-400">Individuals</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-blue-400">{customerAnalytics.byType.individual}</div>
                <div className="text-xs text-slate-500">Personal accounts</div>
              </CardContent>
            </Card>
          </div>

          {/* Main Customer Management Tabs */}
          <Card className="bg-slate-900/30 border-slate-700/50">
            <CardContent className="p-6">
              <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
                <TabsList className="grid w-full grid-cols-5 bg-slate-800/50 border-slate-600/50">
                  <TabsTrigger value="profiles" className="data-[state=active]:bg-blue-600/50 text-white">
                    <Users className="h-4 w-4 mr-1" />
                    Customer Profiles
                  </TabsTrigger>
                  <TabsTrigger value="transactions" className="data-[state=active]:bg-green-600/50 text-white">
                    <CreditCard className="h-4 w-4 mr-2" />
                    Transactions
                  </TabsTrigger>
                  <TabsTrigger value="products" className="data-[state=active]:bg-purple-600/50 text-white">
                    <Package className="h-4 w-4 mr-2" />
                    Products
                  </TabsTrigger>
                  <TabsTrigger value="search" className="data-[state=active]:bg-orange-600/50 text-white">
                    <Search className="h-4 w-4 mr-2" />
                    Advanced Search
                  </TabsTrigger>
                  <TabsTrigger value="reports" className="data-[state=active]:bg-indigo-600/50 text-white">
                    <FileText className="h-4 w-4 mr-2" />
                    Reports
                  </TabsTrigger>
                </TabsList>

                {/* Customer Profiles Tab */}
                <TabsContent value="profiles" className="space-y-6">
                  <div className="flex justify-between items-center">
                    <div>
                      <h3 className="text-lg font-semibold text-white">Customer Database</h3>
                      <p className="text-slate-400">Manage and screen customer profiles</p>
                    </div>
                    <div className="flex space-x-3">
                      <div className="relative">
                        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 h-4 w-4" />
                        <Input
                          placeholder="Search customers..."
                          value={searchQuery}
                          onChange={(e) => setSearchQuery(e.target.value)}
                          className="pl-10 bg-slate-700/50 border-slate-600/50 text-white w-64"
                        />
                      </div>
                      <Button variant="outline" className="border-slate-600 text-white hover:bg-slate-700">
                        <Filter className="h-4 w-4 mr-2" />
                        Filter
                      </Button>
                    </div>
                  </div>
                  
                  {loading ? (
                    <div className="flex items-center justify-center h-32">
                      <div className="text-slate-400">Loading customer profiles...</div>
                    </div>
                  ) : (
                    <div className="rounded-lg border border-slate-700/50 overflow-hidden">
                      <Table>
                        <TableHeader>
                          <TableRow className="border-slate-700/50 hover:bg-slate-700/20">
                            <TableHead className="text-slate-300">Customer Information</TableHead>
                            <TableHead className="text-slate-300">Type</TableHead>
                            <TableHead className="text-slate-300">Location</TableHead>
                            <TableHead className="text-slate-300">Risk Level</TableHead>
                            <TableHead className="text-slate-300">Created</TableHead>
                            <TableHead className="text-slate-300">Actions</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {mainFilteredCustomers.map((customer) => (
                            <TableRow 
                              key={customer.id} 
                              className="border-slate-700/50 hover:bg-slate-700/30 cursor-pointer"
                              onClick={() => handleViewProfile(customer)}
                            >
                              <TableCell>
                                <div className="flex items-start space-x-3">
                                  <div className="flex-shrink-0 mt-1">
                                    {getCustomerTypeIcon(customer.customer_type || 'individual')}
                                  </div>
                                  <div>
                                    <div className="font-medium text-white">{customer.customer_name}</div>
                                    {customer.legal_name && customer.legal_name !== customer.customer_name && (
                                      <div className="text-sm text-slate-400">Legal: {customer.legal_name}</div>
                                    )}
                                    {customer.aliases && customer.aliases.length > 0 && (
                                      <div className="text-xs text-slate-500">
                                        Aliases: {customer.aliases.slice(0, 2).join(', ')}
                                        {customer.aliases.length > 2 && ` +${customer.aliases.length - 2} more`}
                                      </div>
                                    )}
                                  </div>
                                </div>
                              </TableCell>
                              <TableCell>
                                <Badge variant="outline" className="bg-slate-700/50 text-slate-300 border-slate-600/50">
                                  {customer.customer_type || 'individual'}
                                </Badge>
                              </TableCell>
                              <TableCell>
                                <div className="text-sm text-slate-300">
                                  <div className="flex items-center space-x-1">
                                    <MapPin className="h-3 w-3" />
                                    <span>{customer.city && customer.country ? `${customer.city}, ${customer.country}` : customer.country || 'Not provided'}</span>
                                  </div>
                                </div>
                              </TableCell>
                              <TableCell>
                                <Badge className={getRiskLevelColor(customer.risk_category || 'standard')}>
                                  {customer.risk_category || 'standard'}
                                </Badge>
                              </TableCell>
                              <TableCell className="text-slate-300">
                                {formatDate(customer.created_at)}
                              </TableCell>
                              <TableCell>
                                <div className="flex items-center space-x-2">
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    onClick={(e) => {
                                      e.stopPropagation(); // Prevent row click
                                      handleViewProfile(customer);
                                    }}
                                    className="text-blue-400 hover:text-blue-300 hover:bg-blue-500/20"
                                  >
                                    <FileText className="h-4 w-4" />
                                  </Button>
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    onClick={(e) => {
                                      e.stopPropagation(); // Prevent row click
                                      handleViewProfile(customer); // First select the customer
                                      handleEditProfile(customer); // Then enter edit mode
                                    }}
                                    className="text-green-400 hover:text-green-300 hover:bg-green-500/20"
                                  >
                                    <Edit className="h-4 w-4" />
                                  </Button>
                                </div>
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                      
                      {mainFilteredCustomers.length === 0 && (
                        <div className="text-center py-8 text-slate-400">
                          No customer profiles found matching your criteria.
                        </div>
                      )}
                    </div>
                  )}
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </>
      )}
      
      {/* Add Transaction Dialog */}
      <Dialog open={showAddTransaction} onOpenChange={setShowAddTransaction}>
        <DialogContent className="bg-slate-900 border-slate-700 text-white max-w-2xl">
          <DialogHeader>
            <DialogTitle className="text-white flex items-center">
              <CreditCard className="h-5 w-5 mr-2 text-blue-400" />
              Add Transaction for {selectedCustomer?.customer_name}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="text-slate-300">Transaction Date</Label>
                <Input
                  type="date"
                  className="bg-slate-700/50 border-slate-600 text-white"
                  defaultValue={new Date().toISOString().split('T')[0]}
                />
              </div>
              <div>
                <Label className="text-slate-300">Transaction Type</Label>
                <Select>
                  <SelectTrigger className="bg-slate-700/50 border-slate-600 text-white">
                    <SelectValue placeholder="Select type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="export">Export Transaction</SelectItem>
                    <SelectItem value="import">Import Transaction</SelectItem>
                    <SelectItem value="license">License Application</SelectItem>
                    <SelectItem value="payment">Payment</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="text-slate-300">Amount</Label>
                <Input
                  type="number"
                  placeholder="0.00"
                  className="bg-slate-700/50 border-slate-600 text-white"
                />
              </div>
              <div>
                <Label className="text-slate-300">Currency</Label>
                <Select>
                  <SelectTrigger className="bg-slate-700/50 border-slate-600 text-white">
                    <SelectValue placeholder="Select currency" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="USD">USD</SelectItem>
                    <SelectItem value="EUR">EUR</SelectItem>
                    <SelectItem value="GBP">GBP</SelectItem>
                    <SelectItem value="JPY">JPY</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div>
              <Label className="text-slate-300">Description</Label>
              <Textarea
                placeholder="Enter transaction description..."
                className="bg-slate-700/50 border-slate-600 text-white"
                rows={3}
              />
            </div>
            <div>
              <Label className="text-slate-300">Reference Number</Label>
              <Input
                placeholder="Optional reference number"
                className="bg-slate-700/50 border-slate-600 text-white"
              />
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="ghost"
              onClick={() => setShowAddTransaction(false)}
              className="text-slate-300 hover:text-white hover:bg-slate-700"
            >
              Cancel
            </Button>
            <Button
              onClick={() => {
                // Here you would normally save the transaction
                toast.success('Transaction added successfully!');
                setShowAddTransaction(false);
                // Refresh transactions
                if (selectedCustomer?.id) {
                  loadCustomerTransactions(selectedCustomer.id);
                }
              }}
              className="bg-blue-600 hover:bg-blue-700 text-white"
            >
              Add Transaction
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Add Product Dialog */}
      <Dialog open={showAddProduct} onOpenChange={setShowAddProduct}>
        <DialogContent className="bg-slate-900 border-slate-700 text-white max-w-2xl">
          <DialogHeader>
            <DialogTitle className="text-white flex items-center">
              <Package className="h-5 w-5 mr-2 text-purple-400" />
              Add Product for {selectedCustomer?.customer_name}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label className="text-slate-300">Product Name</Label>
              <Input
                placeholder="Enter product name"
                className="bg-slate-700/50 border-slate-600 text-white"
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="text-slate-300">Product Category</Label>
                <Select>
                  <SelectTrigger className="bg-slate-700/50 border-slate-600 text-white">
                    <SelectValue placeholder="Select category" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="dual-use">Dual-Use Technology</SelectItem>
                    <SelectItem value="military">Military Equipment</SelectItem>
                    <SelectItem value="software">Software</SelectItem>
                    <SelectItem value="chemicals">Chemicals</SelectItem>
                    <SelectItem value="electronics">Electronics</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-slate-300">ECCN Classification</Label>
                <Input
                  placeholder="e.g., 3A001.b.2"
                  className="bg-slate-700/50 border-slate-600 text-white"
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="text-slate-300">HS Code</Label>
                <Input
                  placeholder="i.e., 854232"
                  className="bg-slate-700/50 border-slate-600 text-white"
                />
              </div>
              <div>
                <Label className="text-slate-300">Technology Level</Label>
                <Select>
                  <SelectTrigger className="bg-slate-700/50 border-slate-600 text-white">
                    <SelectValue placeholder="Select level" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="low">Low Technology</SelectItem>
                    <SelectItem value="medium">Medium Technology</SelectItem>
                    <SelectItem value="high">High Technology</SelectItem>
                    <SelectItem value="critical">Critical Technology</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div>
              <Label className="text-slate-300">End Use</Label>
              <Input
                placeholder="Intended end use of the product"
                className="bg-slate-700/50 border-slate-600 text-white"
              />
            </div>
            <div className="grid grid-cols-3 gap-4">
              <div>
                <Label className="text-slate-300">Quantity</Label>
                <Input
                  type="number"
                  placeholder="1"
                  className="bg-slate-700/50 border-slate-600 text-white"
                />
              </div>
              <div>
                <Label className="text-slate-300">Unit Value</Label>
                <Input
                  type="number"
                  placeholder="0.00"
                  className="bg-slate-700/50 border-slate-600 text-white"
                />
              </div>
              <div>
                <Label className="text-slate-300">Currency</Label>
                <Select>
                  <SelectTrigger className="bg-slate-700/50 border-slate-600 text-white">
                    <SelectValue placeholder="Currency" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="USD">USD</SelectItem>
                    <SelectItem value="EUR">EUR</SelectItem>
                    <SelectItem value="GBP">GBP</SelectItem>
                    <SelectItem value="JPY">JPY</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div>
              <Label className="text-slate-300">Compliance Notes</Label>
              <Textarea
                placeholder="Enter compliance notes and considerations..."
                className="bg-slate-700/50 border-slate-600 text-white"
                rows={3}
              />
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="ghost"
              onClick={() => setShowAddProduct(false)}
              className="text-slate-300 hover:text-white hover:bg-slate-700"
            >
              Cancel
            </Button>
            <Button
              onClick={() => {
                // Here you would normally save the product
                toast.success('Product added successfully!');
                setShowAddProduct(false);
                // Refresh products
                if (selectedCustomer?.id) {
                  loadCustomerProducts(selectedCustomer.id);
                }
              }}
              className="bg-purple-600 hover:bg-purple-700 text-white"
            >
              Add Product
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default CustomerProfiles;
