import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from '@/components/ui/breadcrumb';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { 
  Home, 
  ChevronRight, 
  ChevronDown, 
  ArrowLeft,
  MoreHorizontal 
} from 'lucide-react';
import { BreadcrumbItem as NavBreadcrumbItem } from 'utils/navigationTypes';
import { getModuleById, getCrossReferences } from 'utils/navigationUtils';

interface NavigationBreadcrumbProps {
  items: NavBreadcrumbItem[];
  showHomeButton?: boolean;
  showBackButton?: boolean;
  showCrossReferences?: boolean;
  maxItems?: number;
  className?: string;
}

export default function NavigationBreadcrumb({
  items,
  showHomeButton = true,
  showBackButton = false,
  showCrossReferences = true,
  maxItems = 5,
  className = ''
}: NavigationBreadcrumbProps) {
  const navigate = useNavigate();
  
  // Get current module for cross-references
  const currentModule = items.length > 0 ? items[items.length - 1] : null;
  const crossReferences = currentModule && currentModule.type === 'module' 
    ? getCrossReferences(currentModule.id) 
    : [];
  
  // Handle item overflow
  const displayItems = items.length > maxItems 
    ? [
        items[0], // Always show first
        { id: 'overflow', name: '...', type: 'custom' as const },
        ...items.slice(-(maxItems - 2)) // Show last items
      ]
    : items;
  
  const handleItemClick = (item: NavBreadcrumbItem, index: number) => {
    if (item.path) {
      navigate(item.path);
    }
  };
  
  const handleBackClick = () => {
    if (items.length > 1) {
      const previousItem = items[items.length - 2];
      if (previousItem.path) {
        navigate(previousItem.path);
      }
    } else {
      navigate(-1);
    }
  };
  
  const getItemIcon = (item: NavBreadcrumbItem) => {
    if (item.type === 'module') {
      const module = getModuleById(item.id);
      if (module) {
        const IconComponent = module.icon;
        return <IconComponent className="w-3 h-3" />;
      }
    }
    return null;
  };
  
  const getItemBadge = (item: NavBreadcrumbItem) => {
    if (item.type === 'module') {
      const module = getModuleById(item.id);
      if (module && module.status === 'premium') {
        return (
          <Badge className="ml-1 text-xs bg-purple-500/20 text-purple-400 border-purple-500/30">
            PRO
          </Badge>
        );
      }
    }
    return null;
  };
  
  if (items.length === 0 && !showHomeButton) {
    return null;
  }
  
  return (
    <div className={`flex items-center space-x-4 ${className}`}>
      {/* Back Button */}
      {showBackButton && (
        <Button
          variant="ghost"
          size="sm"
          onClick={handleBackClick}
          className="text-gray-400 hover:text-white hover:bg-gray-800/50 p-2"
        >
          <ArrowLeft className="w-4 h-4" />
        </Button>
      )}
      
      {/* Breadcrumb Navigation */}
      <div className="flex items-center space-x-2 bg-gray-800/30 backdrop-blur-sm border border-gray-700/50 rounded-lg px-3 py-2">
        <Breadcrumb>
          <BreadcrumbList>
            {/* Home Button */}
            {showHomeButton && (
              <>
                <BreadcrumbItem>
                  <BreadcrumbLink 
                    onClick={() => navigate('/')}
                    className="flex items-center space-x-1 text-gray-400 hover:text-white cursor-pointer transition-colors"
                  >
                    <Home className="w-3 h-3" />
                    <span className="text-xs">Home</span>
                  </BreadcrumbLink>
                </BreadcrumbItem>
                {items.length > 0 && <BreadcrumbSeparator />}
              </>
            )}
            
            {/* Breadcrumb Items */}
            {displayItems.map((item, index) => {
              const isLast = index === displayItems.length - 1;
              const isOverflow = item.id === 'overflow';
              
              if (isOverflow) {
                // Overflow dropdown
                const hiddenItems = items.slice(1, -(maxItems - 2));
                return (
                  <React.Fragment key="overflow">
                    <BreadcrumbItem>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            className="h-auto p-1 text-gray-400 hover:text-white"
                          >
                            <MoreHorizontal className="w-3 h-3" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent className="bg-gray-900 border-gray-700">
                          {hiddenItems.map((hiddenItem, hiddenIndex) => (
                            <DropdownMenuItem
                              key={hiddenItem.id}
                              onClick={() => handleItemClick(hiddenItem, hiddenIndex + 1)}
                              className="text-gray-300 hover:text-white hover:bg-gray-800 cursor-pointer"
                            >
                              <div className="flex items-center space-x-2">
                                {getItemIcon(hiddenItem)}
                                <span className="text-sm">{hiddenItem.name}</span>
                                {getItemBadge(hiddenItem)}
                              </div>
                            </DropdownMenuItem>
                          ))}
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </BreadcrumbItem>
                    <BreadcrumbSeparator />
                  </React.Fragment>
                );
              }
              
              return (
                <React.Fragment key={item.id}>
                  <BreadcrumbItem>
                    {isLast ? (
                      <BreadcrumbPage className="flex items-center space-x-1 text-white font-medium">
                        {getItemIcon(item)}
                        <span className="text-sm">{item.name}</span>
                        {getItemBadge(item)}
                      </BreadcrumbPage>
                    ) : (
                      <BreadcrumbLink
                        onClick={() => handleItemClick(item, index)}
                        className="flex items-center space-x-1 text-gray-400 hover:text-white cursor-pointer transition-colors"
                      >
                        {getItemIcon(item)}
                        <span className="text-sm">{item.name}</span>
                        {getItemBadge(item)}
                      </BreadcrumbLink>
                    )}
                  </BreadcrumbItem>
                  {!isLast && <BreadcrumbSeparator />}
                </React.Fragment>
              );
            })}
          </BreadcrumbList>
        </Breadcrumb>
      </div>
      
      {/* Cross-References */}
      {showCrossReferences && crossReferences.length > 0 && (
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button 
              variant="outline" 
              size="sm"
              className="border-gray-600/50 text-gray-400 hover:text-white hover:bg-gray-800/50 backdrop-blur-sm"
            >
              <span className="text-xs">Related</span>
              <ChevronDown className="w-3 h-3 ml-1" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent 
            align="end" 
            className="bg-gray-900/95 backdrop-blur-sm border-gray-700 w-64"
          >
            <div className="p-2">
              <div className="text-xs text-gray-400 font-medium mb-2">Related Modules</div>
              {crossReferences.map((ref) => {
                const targetModule = getModuleById(ref.targetModule);
                if (!targetModule) return null;
                
                const IconComponent = targetModule.icon;
                return (
                  <DropdownMenuItem
                    key={ref.targetModule}
                    onClick={() => navigate(ref.path)}
                    className="text-gray-300 hover:text-white hover:bg-gray-800 cursor-pointer p-2 rounded"
                  >
                    <div className="flex items-start space-x-2">
                      <IconComponent className={`w-4 h-4 mt-0.5 ${targetModule.color}`} />
                      <div className="flex-1">
                        <div className="text-sm font-medium">{targetModule.title}</div>
                        <div className="text-xs text-gray-400">{ref.description}</div>
                      </div>
                    </div>
                  </DropdownMenuItem>
                );
              })}
            </div>
          </DropdownMenuContent>
        </DropdownMenu>
      )}
    </div>
  );
}
