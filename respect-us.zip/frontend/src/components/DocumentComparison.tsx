import React, { useState, useEffect } from 'react';
import { GitCompare, Search, RefreshCw, ChevronDown, ChevronRight, Eye, Download, History, Settings } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { useUserGuardContext } from 'app/auth';
import brain from 'brain';
import { DocumentResponse } from 'types';
import { toast } from 'sonner';

interface ComparisonDifference {
  type: 'added' | 'removed' | 'modified' | 'unchanged';
  content_1?: string;
  content_2?: string;
  line_number_1?: number;
  line_number_2?: number;
  section_1?: string;
  section_2?: string;
  confidence: number;
}

interface DocumentComparisonResult {
  comparison_id: string;
  document_1: any;
  document_2: any;
  overall_similarity: number;
  differences: ComparisonDifference[];
  sections_compared: number;
  total_changes: number;
  summary: {
    added: number;
    removed: number;
    modified: number;
    unchanged: number;
  };
  generated_at: string;
}

interface ComparisonSuggestion {
  suggestion_type: string;
  document_id: number;
  document_title: string;
  similarity_score: number;
  reason: string;
}

interface DocumentComparisonProps {
  preselectedDocuments?: { doc1?: DocumentResponse; doc2?: DocumentResponse };
}

export const DocumentComparison: React.FC<DocumentComparisonProps> = ({ preselectedDocuments }) => {
  const { user } = useUserGuardContext();
  const [documents, setDocuments] = useState<DocumentResponse[]>([]);
  const [selectedDoc1, setSelectedDoc1] = useState<DocumentResponse | null>(preselectedDocuments?.doc1 || null);
  const [selectedDoc2, setSelectedDoc2] = useState<DocumentResponse | null>(preselectedDocuments?.doc2 || null);
  const [comparisonResult, setComparisonResult] = useState<DocumentComparisonResult | null>(null);
  const [suggestions, setSuggestions] = useState<ComparisonSuggestion[]>([]);
  const [comparisonHistory, setComparisonHistory] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [loadingSuggestions, setLoadingSuggestions] = useState(false);
  const [searchQuery1, setSearchQuery1] = useState('');
  const [searchQuery2, setSearchQuery2] = useState('');
  const [comparisonType, setComparisonType] = useState('full');
  const [ignoreFormatting, setIgnoreFormatting] = useState(true);
  const [ignoreCase, setIgnoreCase] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [activeTab, setActiveTab] = useState('comparison');
  const [expandedDifferences, setExpandedDifferences] = useState<Set<number>>(new Set());

  const loadDocuments = async () => {
    try {
      const response = await brain.list_documents({ per_page: 100 });
      const data = await response.json();
      setDocuments(data.documents || []);
    } catch (error) {
      console.error('Error loading documents:', error);
      toast.error('Failed to load documents');
    }
  };

  const loadSuggestions = async (documentId: number) => {
    try {
      setLoadingSuggestions(true);
      const response = await brain.get_comparison_suggestions({ documentId });
      const data = await response.json();
      setSuggestions(data || []);
    } catch (error) {
      console.error('Error loading suggestions:', error);
      toast.error('Failed to load suggestions');
    } finally {
      setLoadingSuggestions(false);
    }
  };

  const loadComparisonHistory = async () => {
    try {
      const response = await brain.get_comparison_history();
      const data = await response.json();
      setComparisonHistory(data || []);
    } catch (error) {
      console.error('Error loading comparison history:', error);
      toast.error('Failed to load comparison history');
    }
  };

  const performComparison = async () => {
    if (!selectedDoc1 || !selectedDoc2) {
      toast.error('Please select two documents to compare');
      return;
    }

    if (selectedDoc1.id === selectedDoc2.id) {
      toast.error('Cannot compare a document with itself');
      return;
    }

    try {
      setLoading(true);
      const response = await brain.compare_documents({
        document_id_1: selectedDoc1.id,
        document_id_2: selectedDoc2.id,
        comparison_type: comparisonType,
        ignore_formatting: ignoreFormatting,
        ignore_case: ignoreCase
      });
      
      const result = await response.json();
      setComparisonResult(result);
      setActiveTab('comparison');
      toast.success('Documents compared successfully');
    } catch (error) {
      console.error('Error comparing documents:', error);
      toast.error('Failed to compare documents');
    } finally {
      setLoading(false);
    }
  };

  const filteredDocuments1 = documents.filter(doc => 
    doc.title.toLowerCase().includes(searchQuery1.toLowerCase()) ||
    (doc.description && doc.description.toLowerCase().includes(searchQuery1.toLowerCase()))
  );

  const filteredDocuments2 = documents.filter(doc => 
    doc.title.toLowerCase().includes(searchQuery2.toLowerCase()) ||
    (doc.description && doc.description.toLowerCase().includes(searchQuery2.toLowerCase()))
  );

  const getSimilarityColor = (similarity: number) => {
    if (similarity >= 0.8) return 'text-green-400';
    if (similarity >= 0.6) return 'text-yellow-400';
    if (similarity >= 0.4) return 'text-orange-400';
    return 'text-red-400';
  };

  const getDifferenceTypeColor = (type: string) => {
    switch (type) {
      case 'added': return 'bg-green-500/20 text-green-400 border-green-500/30';
      case 'removed': return 'bg-red-500/20 text-red-400 border-red-500/30';
      case 'modified': return 'bg-blue-500/20 text-blue-400 border-blue-500/30';
      default: return 'bg-gray-500/20 text-gray-400 border-gray-500/30';
    }
  };

  const toggleDifferenceExpansion = (index: number) => {
    setExpandedDifferences(prev => {
      const newSet = new Set(prev);
      if (newSet.has(index)) {
        newSet.delete(index);
      } else {
        newSet.add(index);
      }
      return newSet;
    });
  };

  useEffect(() => {
    loadDocuments();
    loadComparisonHistory();
  }, []);

  useEffect(() => {
    if (selectedDoc1) {
      loadSuggestions(selectedDoc1.id);
    }
  }, [selectedDoc1]);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold text-white">Document Comparison</h3>
          <p className="text-sm text-gray-400 mt-1">
            Compare documents side-by-side with advanced difference analysis
          </p>
        </div>
        
        <div className="flex items-center gap-2">
          <Dialog open={showSettings} onOpenChange={setShowSettings}>
            <DialogTrigger asChild>
              <Button variant="outline" className="border-gray-600 text-gray-300">
                <Settings className="h-4 w-4 mr-2" />
                Settings
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-gray-900 border-gray-700">
              <DialogHeader>
                <DialogTitle className="text-white">Comparison Settings</DialogTitle>
                <DialogDescription className="text-gray-400">
                  Configure how documents are compared
                </DialogDescription>
              </DialogHeader>
              
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label className="text-white">Comparison Type</Label>
                  <Select value={comparisonType} onValueChange={setComparisonType}>
                    <SelectTrigger className="bg-gray-800 border-gray-600 text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-gray-800 border-gray-600">
                      <SelectItem value="full">Full Document</SelectItem>
                      <SelectItem value="sections">Sections Only</SelectItem>
                      <SelectItem value="metadata">Metadata Only</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="flex items-center space-x-2">
                  <Switch
                    id="ignore-formatting"
                    checked={ignoreFormatting}
                    onCheckedChange={setIgnoreFormatting}
                  />
                  <Label htmlFor="ignore-formatting" className="text-white">
                    Ignore formatting differences
                  </Label>
                </div>
                
                <div className="flex items-center space-x-2">
                  <Switch
                    id="ignore-case"
                    checked={ignoreCase}
                    onCheckedChange={setIgnoreCase}
                  />
                  <Label htmlFor="ignore-case" className="text-white">
                    Case insensitive comparison
                  </Label>
                </div>
              </div>
            </DialogContent>
          </Dialog>
          
          <Button 
            onClick={performComparison}
            disabled={!selectedDoc1 || !selectedDoc2 || loading}
            className="bg-blue-600 hover:bg-blue-700"
          >
            {loading ? (
              <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
            ) : (
              <GitCompare className="h-4 w-4 mr-2" />
            )}
            Compare Documents
          </Button>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-4 bg-gray-800/50">
          <TabsTrigger value="selection" className="data-[state=active]:bg-gray-700">
            Document Selection
          </TabsTrigger>
          <TabsTrigger value="comparison" className="data-[state=active]:bg-gray-700">
            Comparison Results
          </TabsTrigger>
          <TabsTrigger value="suggestions" className="data-[state=active]:bg-gray-700">
            Suggestions
          </TabsTrigger>
          <TabsTrigger value="history" className="data-[state=active]:bg-gray-700">
            History
          </TabsTrigger>
        </TabsList>

        <TabsContent value="selection" className="mt-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Document 1 Selection */}
            <Card className="bg-gray-800/50 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
                  Document 1
                </CardTitle>
                <CardDescription className="text-gray-400">
                  Select the first document for comparison
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <Input
                  placeholder="Search documents..."
                  value={searchQuery1}
                  onChange={(e) => setSearchQuery1(e.target.value)}
                  className="bg-gray-800 border-gray-600 text-white"
                />
                
                {selectedDoc1 && (
                  <div className="p-3 bg-blue-900/30 border border-blue-700 rounded">
                    <h4 className="font-medium text-blue-300">{selectedDoc1.title}</h4>
                    <p className="text-sm text-blue-400 mt-1">
                      {selectedDoc1.jurisdiction} • {selectedDoc1.document_type}
                    </p>
                  </div>
                )}
                
                <ScrollArea className="h-48">
                  <div className="space-y-2">
                    {filteredDocuments1.map((doc) => (
                      <div
                        key={doc.id}
                        className={`p-3 rounded cursor-pointer transition-colors ${
                          selectedDoc1?.id === doc.id
                            ? 'bg-blue-900/50 border border-blue-700'
                            : 'bg-gray-800/30 hover:bg-gray-700/50 border border-gray-700'
                        }`}
                        onClick={() => setSelectedDoc1(doc)}
                      >
                        <h4 className="font-medium text-white text-sm">{doc.title}</h4>
                        <p className="text-xs text-gray-400 mt-1">
                          {doc.jurisdiction} • {doc.document_type}
                        </p>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>

            {/* Document 2 Selection */}
            <Card className="bg-gray-800/50 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                  Document 2
                </CardTitle>
                <CardDescription className="text-gray-400">
                  Select the second document for comparison
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <Input
                  placeholder="Search documents..."
                  value={searchQuery2}
                  onChange={(e) => setSearchQuery2(e.target.value)}
                  className="bg-gray-800 border-gray-600 text-white"
                />
                
                {selectedDoc2 && (
                  <div className="p-3 bg-green-900/30 border border-green-700 rounded">
                    <h4 className="font-medium text-green-300">{selectedDoc2.title}</h4>
                    <p className="text-sm text-green-400 mt-1">
                      {selectedDoc2.jurisdiction} • {selectedDoc2.document_type}
                    </p>
                  </div>
                )}
                
                <ScrollArea className="h-48">
                  <div className="space-y-2">
                    {filteredDocuments2.map((doc) => (
                      <div
                        key={doc.id}
                        className={`p-3 rounded cursor-pointer transition-colors ${
                          selectedDoc2?.id === doc.id
                            ? 'bg-green-900/50 border border-green-700'
                            : 'bg-gray-800/30 hover:bg-gray-700/50 border border-gray-700'
                        }`}
                        onClick={() => setSelectedDoc2(doc)}
                      >
                        <h4 className="font-medium text-white text-sm">{doc.title}</h4>
                        <p className="text-xs text-gray-400 mt-1">
                          {doc.jurisdiction} • {doc.document_type}
                        </p>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="comparison" className="mt-6">
          {comparisonResult ? (
            <div className="space-y-6">
              {/* Comparison Summary */}
              <Card className="bg-gray-800/50 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <GitCompare className="h-5 w-5" />
                    Comparison Summary
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
                    <div className="text-center">
                      <div className={`text-2xl font-bold ${getSimilarityColor(comparisonResult.overall_similarity)}`}>
                        {(comparisonResult.overall_similarity * 100).toFixed(1)}%
                      </div>
                      <div className="text-sm text-gray-400">Similarity</div>
                      <Progress 
                        value={comparisonResult.overall_similarity * 100} 
                        className="mt-2 h-2"
                      />
                    </div>
                    
                    <div className="text-center">
                      <div className="text-2xl font-bold text-white">{comparisonResult.total_changes}</div>
                      <div className="text-sm text-gray-400">Total Changes</div>
                    </div>
                    
                    <div className="text-center">
                      <div className="text-2xl font-bold text-white">{comparisonResult.sections_compared}</div>
                      <div className="text-sm text-gray-400">Sections Compared</div>
                    </div>
                    
                    <div className="text-center">
                      <div className="text-2xl font-bold text-white">{comparisonResult.differences.length}</div>
                      <div className="text-sm text-gray-400">Differences Found</div>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-4">
                    <div className="flex items-center gap-2">
                      <Badge className="bg-green-500/20 text-green-400">
                        +{comparisonResult.summary.added} Added
                      </Badge>
                      <Badge className="bg-red-500/20 text-red-400">
                        -{comparisonResult.summary.removed} Removed
                      </Badge>
                      <Badge className="bg-blue-500/20 text-blue-400">
                        ~{comparisonResult.summary.modified} Modified
                      </Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Document Headers */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                <Card className="bg-blue-900/20 border-blue-700">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-blue-300 text-sm">
                      {comparisonResult.document_1.title}
                    </CardTitle>
                    <CardDescription className="text-blue-400">
                      {comparisonResult.document_1.jurisdiction} • {comparisonResult.document_1.document_type}
                    </CardDescription>
                  </CardHeader>
                </Card>
                
                <Card className="bg-green-900/20 border-green-700">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-green-300 text-sm">
                      {comparisonResult.document_2.title}
                    </CardTitle>
                    <CardDescription className="text-green-400">
                      {comparisonResult.document_2.jurisdiction} • {comparisonResult.document_2.document_type}
                    </CardDescription>
                  </CardHeader>
                </Card>
              </div>

              {/* Differences */}
              <Card className="bg-gray-800/50 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white">Detailed Differences</CardTitle>
                  <CardDescription className="text-gray-400">
                    {comparisonResult.differences.length} differences found
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-96">
                    <div className="space-y-3">
                      {comparisonResult.differences.map((diff, index) => (
                        <Collapsible
                          key={index}
                          open={expandedDifferences.has(index)}
                          onOpenChange={() => toggleDifferenceExpansion(index)}
                        >
                          <CollapsibleTrigger asChild>
                            <div className={`p-3 border rounded cursor-pointer transition-colors hover:bg-gray-700/30 ${
                              getDifferenceTypeColor(diff.type)
                            }`}>
                              <div className="flex items-center justify-between">
                                <div className="flex items-center gap-2">
                                  <Badge className={getDifferenceTypeColor(diff.type)}>
                                    {diff.type.toUpperCase()}
                                  </Badge>
                                  <span className="text-sm text-gray-300">
                                    Line {diff.line_number_1 || diff.line_number_2 || 'Unknown'}
                                  </span>
                                  <span className="text-xs text-gray-500">
                                    Confidence: {(diff.confidence * 100).toFixed(0)}%
                                  </span>
                                </div>
                                {expandedDifferences.has(index) ? (
                                  <ChevronDown className="h-4 w-4" />
                                ) : (
                                  <ChevronRight className="h-4 w-4" />
                                )}
                              </div>
                            </div>
                          </CollapsibleTrigger>
                          
                          <CollapsibleContent className="mt-2">
                            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                              {diff.content_1 && (
                                <div className="bg-red-900/20 border border-red-700 rounded p-3">
                                  <div className="text-xs text-red-400 mb-2">Document 1 (Original)</div>
                                  <code className="text-sm text-red-300 whitespace-pre-wrap">
                                    {diff.content_1}
                                  </code>
                                </div>
                              )}
                              
                              {diff.content_2 && (
                                <div className="bg-green-900/20 border border-green-700 rounded p-3">
                                  <div className="text-xs text-green-400 mb-2">Document 2 (Comparison)</div>
                                  <code className="text-sm text-green-300 whitespace-pre-wrap">
                                    {diff.content_2}
                                  </code>
                                </div>
                              )}
                            </div>
                          </CollapsibleContent>
                        </Collapsible>
                      ))}
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>
            </div>
          ) : (
            <Card className="bg-gray-800/50 border-gray-700">
              <CardContent className="text-center py-12">
                <GitCompare className="h-12 w-12 mx-auto text-gray-500 mb-4" />
                <h3 className="text-lg font-medium text-white mb-2">No comparison results</h3>
                <p className="text-gray-400 mb-4">
                  Select two documents and click "Compare Documents" to see detailed analysis.
                </p>
                <Button 
                  onClick={() => setActiveTab('selection')}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  Select Documents
                </Button>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="suggestions" className="mt-6">
          <Card className="bg-gray-800/50 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white">Comparison Suggestions</CardTitle>
              <CardDescription className="text-gray-400">
                {selectedDoc1 ? 
                  `Suggested documents to compare with "${selectedDoc1.title}"` :
                  'Select a document to see comparison suggestions'
                }
              </CardDescription>
            </CardHeader>
            <CardContent>
              {!selectedDoc1 ? (
                <div className="text-center py-8">
                  <Search className="h-8 w-8 mx-auto text-gray-500 mb-3" />
                  <p className="text-gray-400">Select a document to get suggestions</p>
                </div>
              ) : loadingSuggestions ? (
                <div className="text-center py-8">
                  <RefreshCw className="h-8 w-8 mx-auto text-blue-500 animate-spin mb-3" />
                  <p className="text-gray-400">Loading suggestions...</p>
                </div>
              ) : suggestions.length === 0 ? (
                <div className="text-center py-8">
                  <Search className="h-8 w-8 mx-auto text-gray-500 mb-3" />
                  <p className="text-gray-400">No suggestions found</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {suggestions.map((suggestion, index) => (
                    <div
                      key={index}
                      className="p-4 bg-gray-800/30 border border-gray-700 rounded hover:bg-gray-700/30 transition-colors cursor-pointer"
                      onClick={() => {
                        const suggestedDoc = documents.find(d => d.id === suggestion.document_id);
                        if (suggestedDoc) {
                          setSelectedDoc2(suggestedDoc);
                          setActiveTab('selection');
                        }
                      }}
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <h4 className="font-medium text-white mb-1">{suggestion.document_title}</h4>
                          <p className="text-sm text-gray-400 mb-2">{suggestion.reason}</p>
                          <div className="flex items-center gap-2">
                            <Badge className="bg-blue-500/20 text-blue-400">
                              {suggestion.suggestion_type.replace('_', ' ')}
                            </Badge>
                            <span className="text-xs text-gray-500">
                              {(suggestion.similarity_score * 100).toFixed(1)}% match
                            </span>
                          </div>
                        </div>
                        <Button
                          size="sm"
                          variant="outline"
                          className="border-gray-600 text-gray-300 hover:bg-gray-700"
                        >
                          <Eye className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="history" className="mt-6">
          <Card className="bg-gray-800/50 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <History className="h-5 w-5" />
                Comparison History
              </CardTitle>
              <CardDescription className="text-gray-400">
                Your recent document comparisons
              </CardDescription>
            </CardHeader>
            <CardContent>
              {comparisonHistory.length === 0 ? (
                <div className="text-center py-8">
                  <History className="h-8 w-8 mx-auto text-gray-500 mb-3" />
                  <p className="text-gray-400">No comparison history</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {comparisonHistory.map((comparison) => (
                    <div
                      key={comparison.id}
                      className="p-4 bg-gray-800/30 border border-gray-700 rounded"
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-2">
                            <div>
                              <h4 className="font-medium text-blue-300 text-sm">
                                {comparison.document_1.title}
                              </h4>
                              <p className="text-xs text-blue-400">
                                {comparison.document_1.jurisdiction}
                              </p>
                            </div>
                            <div>
                              <h4 className="font-medium text-green-300 text-sm">
                                {comparison.document_2.title}
                              </h4>
                              <p className="text-xs text-green-400">
                                {comparison.document_2.jurisdiction}
                              </p>
                            </div>
                          </div>
                          
                          <div className="flex items-center gap-4 text-xs text-gray-400">
                            <span>
                              {(comparison.overall_similarity * 100).toFixed(1)}% similarity
                            </span>
                            <span>{comparison.total_changes} changes</span>
                            <span>{comparison.sections_compared} sections</span>
                            <span>{new Date(comparison.created_at).toLocaleDateString()}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};
