import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Eye, Calendar, Building, User, Loader2 } from 'lucide-react';
import { CustomerProfile, ScreeningResult } from '../brain/data-contracts';

export interface CustomerDialogsProps {
  // Add Customer Dialog
  showAddCustomer: boolean;
  setShowAddCustomer: (show: boolean) => void;
  customerForm: any;
  setCustomerForm: (form: any) => void;
  onAddCustomer: () => void;
  
  // Edit Customer Dialog
  showEditDialog: boolean;
  setShowEditDialog: (show: boolean) => void;
  selectedCustomer: CustomerProfile | null;
  setSelectedCustomer: (customer: CustomerProfile | null) => void;
  onUpdateCustomer: () => void;
  
  // History Dialog
  showHistoryDialog: boolean;
  setShowHistoryDialog: (show: boolean) => void;
  customerScreeningHistory: ScreeningResult[];
  onShowScreeningDetails: (result: ScreeningResult) => void;
  
  loading: boolean;
}

const CustomerDialogs: React.FC<CustomerDialogsProps> = ({
  showAddCustomer,
  setShowAddCustomer,
  customerForm,
  setCustomerForm,
  onAddCustomer,
  showEditDialog,
  setShowEditDialog,
  selectedCustomer,
  setSelectedCustomer,
  onUpdateCustomer,
  showHistoryDialog,
  setShowHistoryDialog,
  customerScreeningHistory,
  onShowScreeningDetails,
  loading
}) => {
  return (
    <>
      {/* Add Customer Dialog */}
      <Dialog open={showAddCustomer} onOpenChange={setShowAddCustomer}>
        <DialogContent className="max-w-2xl bg-gray-900 border-gray-800">
          <DialogHeader>
            <DialogTitle className="text-white">Add New Customer</DialogTitle>
          </DialogHeader>
          <div className="grid grid-cols-2 gap-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="customer_name" className="text-white">Customer Name *</Label>
              <Input
                id="customer_name"
                value={customerForm.customer_name}
                onChange={(e) => setCustomerForm(prev => ({ ...prev, customer_name: e.target.value }))}
                className="bg-slate-800 border-slate-700 text-white"
                placeholder="Enter customer name"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="customer_type" className="text-white">Customer Type *</Label>
              <Select
                value={customerForm.customer_type}
                onValueChange={(value) => setCustomerForm(prev => ({ ...prev, customer_type: value }))}
              >
                <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                  <SelectValue placeholder="Select type" />
                </SelectTrigger>
                <SelectContent className="bg-slate-800 border-slate-700">
                  <SelectItem value="individual">Individual</SelectItem>
                  <SelectItem value="company">Company</SelectItem>
                  <SelectItem value="organization">Organization</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="email" className="text-white">Email</Label>
              <Input
                id="email"
                type="email"
                value={customerForm.email || ''}
                onChange={(e) => setCustomerForm(prev => ({ ...prev, email: e.target.value }))}
                className="bg-slate-800 border-slate-700 text-white"
                placeholder="Enter email address"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="country" className="text-white">Country</Label>
              <Input
                id="country"
                value={customerForm.country}
                onChange={(e) => setCustomerForm(prev => ({ ...prev, country: e.target.value }))}
                className="bg-slate-800 border-slate-700 text-white"
                placeholder="Enter country"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="city" className="text-white">City</Label>
              <Input
                id="city"
                value={customerForm.city}
                onChange={(e) => setCustomerForm(prev => ({ ...prev, city: e.target.value }))}
                className="bg-slate-800 border-slate-700 text-white"
                placeholder="Enter city"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="risk_category" className="text-white">Risk Category</Label>
              <Select
                value={customerForm.risk_category}
                onValueChange={(value) => setCustomerForm(prev => ({ ...prev, risk_category: value }))}
              >
                <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                  <SelectValue placeholder="Select risk level" />
                </SelectTrigger>
                <SelectContent className="bg-slate-800 border-slate-700">
                  <SelectItem value="low">Low</SelectItem>
                  <SelectItem value="standard">Standard</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="notes" className="text-white">Notes</Label>
            <Textarea
              id="notes"
              value={customerForm.notes}
              onChange={(e) => setCustomerForm(prev => ({ ...prev, notes: e.target.value }))}
              className="bg-slate-800 border-slate-700 text-white"
              rows={3}
              placeholder="Enter any additional notes"
            />
          </div>
          
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setShowAddCustomer(false)}
              className="border-slate-600 text-gray-300 hover:bg-slate-800"
            >
              Cancel
            </Button>
            <Button
              onClick={onAddCustomer}
              disabled={loading || !customerForm.customer_name}
              className="bg-blue-500 hover:bg-blue-600 text-white"
            >
              {loading ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Adding...
                </>
              ) : (
                'Add Customer'
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Customer Dialog */}
      <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
        <DialogContent className="max-w-2xl bg-gray-900 border-gray-800">
          <DialogHeader>
            <DialogTitle className="text-white">Edit Customer</DialogTitle>
          </DialogHeader>
          {selectedCustomer && (
            <div className="grid grid-cols-2 gap-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="edit_customer_name" className="text-white">Customer Name</Label>
                <Input
                  id="edit_customer_name"
                  value={selectedCustomer.customer_name}
                  onChange={(e) => setSelectedCustomer(prev => ({ ...prev!, customer_name: e.target.value }))}
                  className="bg-slate-800 border-slate-700 text-white"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="edit_customer_type" className="text-white">Customer Type</Label>
                <Select
                  value={selectedCustomer.customer_type}
                  onValueChange={(value) => setSelectedCustomer(prev => ({ ...prev!, customer_type: value }))}
                >
                  <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-800 border-slate-700">
                    <SelectItem value="individual">Individual</SelectItem>
                    <SelectItem value="company">Company</SelectItem>
                    <SelectItem value="organization">Organization</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="edit_email" className="text-white">Email</Label>
                <Input
                  id="edit_email"
                  type="email"
                  value={selectedCustomer.email || ''}
                  onChange={(e) => setSelectedCustomer(prev => ({ ...prev!, email: e.target.value }))}
                  className="bg-slate-800 border-slate-700 text-white"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="edit_country" className="text-white">Country</Label>
                <Input
                  id="edit_country"
                  value={selectedCustomer.country || ''}
                  onChange={(e) => setSelectedCustomer(prev => ({ ...prev!, country: e.target.value }))}
                  className="bg-slate-800 border-slate-700 text-white"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="edit_notes" className="text-white">Notes</Label>
                <Textarea
                  id="edit_notes"
                  value={selectedCustomer.notes || ''}
                  onChange={(e) => setSelectedCustomer(prev => ({ ...prev!, notes: e.target.value }))}
                  className="bg-slate-800 border-slate-700 text-white"
                  rows={3}
                />
              </div>
            </div>
          )}
          
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setShowEditDialog(false)}
              className="border-slate-600 text-gray-300 hover:bg-slate-800"
            >
              Cancel
            </Button>
            <Button
              onClick={onUpdateCustomer}
              disabled={loading}
              className="bg-blue-500 hover:bg-blue-600 text-white"
            >
              {loading ? 'Updating...' : 'Update Customer'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Customer History Dialog */}
      <Dialog open={showHistoryDialog} onOpenChange={setShowHistoryDialog}>
        <DialogContent className="max-w-4xl bg-gray-900 border-gray-800">
          <DialogHeader>
            <DialogTitle className="text-white flex items-center gap-2">
              <Calendar className="h-5 w-5" />
              Customer Screening History
            </DialogTitle>
          </DialogHeader>
          <div className="py-4">
            {customerScreeningHistory.length === 0 ? (
              <div className="text-center py-8">
                <Calendar className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <div className="text-gray-400">No screening history found</div>
                <div className="text-sm text-gray-500 mt-2">
                  This customer has not been screened yet
                </div>
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow className="border-slate-700/50">
                    <TableHead className="text-gray-300">Date</TableHead>
                    <TableHead className="text-gray-300">Risk Level</TableHead>
                    <TableHead className="text-gray-300">Matches</TableHead>
                    <TableHead className="text-gray-300">Status</TableHead>
                    <TableHead className="text-gray-300">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {customerScreeningHistory.map((result) => (
                    <TableRow key={result.id} className="border-slate-700/50">
                      <TableCell className="text-gray-300">
                        <div>
                          <div>{new Date(result.screening_date).toLocaleDateString()}</div>
                          <div className="text-xs text-gray-500">
                            {new Date(result.screening_date).toLocaleTimeString()}
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge className={`${
                          result.risk_level === 'critical' ? 'bg-red-500/20 text-red-400 border-red-500/50' :
                          result.risk_level === 'high' ? 'bg-orange-500/20 text-orange-400 border-orange-500/50' :
                          result.risk_level === 'medium' ? 'bg-yellow-500/20 text-yellow-400 border-yellow-500/50' :
                          'bg-green-500/20 text-green-400 border-green-500/50'
                        }`}>
                          {result.risk_level}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-gray-300">{result.total_matches}</TableCell>
                      <TableCell>
                        <Badge variant="outline" className="border-slate-600 text-gray-300">
                          {result.status}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => onShowScreeningDetails(result)}
                          className="border-slate-600 text-gray-300 hover:bg-slate-700"
                        >
                          <Eye className="h-3 w-3 mr-1" />
                          View Details
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default CustomerDialogs;
