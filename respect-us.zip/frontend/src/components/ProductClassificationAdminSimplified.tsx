import React, { useState, useEffect } from 'react';
import brain from 'brain';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { TreePine, FileText, GitBranch, Settings, Plus, Target, Trash2, Download, Database, Info } from 'lucide-react';
import { AppApisClassificationClassificationTree as ClassificationTree, TreeNode, MultiQuestionItem, OutcomeRule } from '../brain/data-contracts';
import { toast } from 'sonner';
import IntroductionTreesTab from './IntroductionTreesTab';
import ClassificationTreesTab from './ClassificationTreesTab';
import OutcomesTab from './OutcomesTab';
import NotesTab from './NotesTab';
import ToolsTab from './ToolsTab';
import WorkflowsTab from './WorkflowsTab';

const ProductClassificationAdminSimplified: React.FC = () => {
  const [activeTab, setActiveTab] = useState('trees');
  const [classificationTrees, setClassificationTrees] = useState<ClassificationTree[]>([]);
  const [introductionTrees, setIntroductionTrees] = useState<ClassificationTree[]>([]);
  const [loading, setLoading] = useState(true);

  // Add state for Introduction Tree node creation
  const [selectedIntroTreeForNode, setSelectedIntroTreeForNode] = useState<ClassificationTree | null>(null);
  const [showCreateIntroNodeDialog, setShowCreateIntroNodeDialog] = useState(false);
  const [creatingIntroNode, setCreatingIntroNode] = useState(false);
  const [newIntroNodeData, setNewIntroNodeData] = useState({
    node_key: '',
    title: '',
    description: '',
    question_text: '',
    question_type: 'multiple_choice',
    parent_node_id: null as string | null,
    display_order: 0,
    is_root: false,
    notes: '',
    routing_rule: ''
  });

  // Add state for existing nodes (for parent node dropdown)
  const [existingNodes, setExistingNodes] = useState<TreeNode[]>([]);
  const [loadingNodes, setLoadingNodes] = useState(false);

  // Add state for Introduction Trees refresh callback
  const [introTreesRefreshCallback, setIntroTreesRefreshCallback] = useState<(() => void) | null>(null);

  // Add state for Classification Tree node creation
  const [selectedTreeForNode, setSelectedTreeForNode] = useState<ClassificationTree | null>(null);
  const [showCreateNodeDialog, setShowCreateNodeDialog] = useState(false);
  const [creatingNode, setCreatingNode] = useState(false);
  const [newNodeData, setNewNodeData] = useState({
    node_key: '',
    title: '',
    description: '',
    question_text: '',
    question_type: 'multiple_choice',
    parent_node_id: null as string | null,
    display_order: 0,
    is_root: false,
    notes: '',
    multi_questions: [] as MultiQuestionItem[],
    outcome_rules: [] as OutcomeRule[]
  });

  // Add state for existing classification nodes (for parent node dropdown)
  const [existingClassificationNodes, setExistingClassificationNodes] = useState<TreeNode[]>([]);
  const [loadingClassificationNodes, setLoadingClassificationNodes] = useState(false);

  // Add state for Introduction Tree editing
  const [showEditIntroTreeDialog, setShowEditIntroTreeDialog] = useState(false);
  const [editingIntroTree, setEditingIntroTree] = useState<ClassificationTree | null>(null);
  const [updatingIntroTree, setUpdatingIntroTree] = useState(false);
  const [editIntroTreeData, setEditIntroTreeData] = useState({
    name: '',
    description: '',
    jurisdiction: '',
    category: '',
    status: 'draft'
  });

  // Add state for editing Classification Trees
  const [showEditTreeDialog, setShowEditTreeDialog] = useState(false);
  const [editingTree, setEditingTree] = useState<ClassificationTree | null>(null);
  const [updatingTree, setUpdatingTree] = useState(false);
  const [editTreeData, setEditTreeData] = useState({
    name: '',
    description: '',
    jurisdiction: '',
    category: '',
    version: '',
    status: 'draft'
  });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      setLoading(true);
      
      // Load classification trees
      const classResponse = await brain.list_classification_trees();
      if (classResponse.ok) {
        const classData = await classResponse.json();
        setClassificationTrees(classData);
      }
      
      // Load introduction trees
      const introResponse = await brain.list_introduction_trees();
      if (introResponse.ok) {
        const introData = await introResponse.json();
        setIntroductionTrees(introData);
      }
    } catch (error) {
      console.error('Error loading data:', error);
      toast.error('Failed to load trees');
    } finally {
      setLoading(false);
    }
  };

  const handleCreateTree = () => {
    toast.info('Create tree functionality available');
  };

  const handleCreateNode = (tree: ClassificationTree) => {
    setSelectedTreeForNode(tree);
    setNewNodeData({
      node_key: '',
      title: '',
      description: '',
      question_text: '',
      question_type: 'multiple_choice',
      parent_node_id: null,
      display_order: 0,
      is_root: false,
      notes: '',
      multi_questions: [] as MultiQuestionItem[],
      outcome_rules: [] as OutcomeRule[]
    });
    setShowCreateNodeDialog(true);
    // Load existing nodes for parent selection
    loadExistingClassificationNodes(tree.id);
  };

  const handleEditNode = (node: TreeNode) => {
    toast.info(`Edit node ${node.title} functionality available`);
  };

  const handleCreateIntroTree = () => {
    toast.info('Create introduction tree functionality available');
  };

  const handleEditIntroTree = (tree: ClassificationTree) => {
    setEditingIntroTree(tree);
    setEditIntroTreeData({
      name: tree.name,
      description: tree.description || '',
      jurisdiction: tree.jurisdiction,
      category: tree.category,
      status: tree.status
    });
    setShowEditIntroTreeDialog(true);
  };

  const handleCreateIntroNode = (tree: ClassificationTree) => {
    setSelectedIntroTreeForNode(tree);
    setNewIntroNodeData({
      node_key: '',
      title: '',
      description: '',
      question_text: '',
      question_type: 'multiple_choice',
      parent_node_id: null,
      display_order: 0,
      is_root: false,
      notes: '',
      routing_rule: ''
    });
    setShowCreateIntroNodeDialog(true);
    // Load existing nodes for parent selection
    loadExistingNodes(tree.id);
  };

  const loadExistingNodes = async (treeId: string) => {
    try {
      setLoadingNodes(true);
      const response = await brain.list_tree_nodes({ treeId });
      if (response.ok) {
        const nodes = await response.json();
        setExistingNodes(nodes);
      }
    } catch (error) {
      console.error('Error loading existing nodes:', error);
    } finally {
      setLoadingNodes(false);
    }
  };

  const handleEditIntroNode = (node: TreeNode) => {
    toast.info(`Edit introduction node ${node.title} functionality available`);
  };

  const handleCreateIntroNodeSubmit = async () => {
    if (!selectedIntroTreeForNode) return;
    
    try {
      setCreatingIntroNode(true);
      const response = await brain.create_introduction_tree_node(
        { treeId: selectedIntroTreeForNode.id },
        newIntroNodeData
      );
      
      if (response.ok) {
        toast.success('Introduction tree node created successfully');
        setShowCreateIntroNodeDialog(false);
        setSelectedIntroTreeForNode(null);
        setNewIntroNodeData({
          node_key: '',
          title: '',
          description: '',
          question_text: '',
          question_type: 'multiple_choice',
          parent_node_id: null,
          display_order: 0,
          is_root: false,
          notes: '',
          routing_rule: ''
        });
        // Reload data to show the new node
        loadData();
        // Also refresh the Introduction Trees tab if callback is available
        if (introTreesRefreshCallback) {
          introTreesRefreshCallback();
        }
      } else {
        const errorData = await response.json().catch(() => null);
        toast.error(`Failed to create introduction node: ${errorData?.detail || 'Unknown error'}`);
      }
    } catch (error) {
      console.error('Error creating introduction node:', error);
      toast.error('Failed to create introduction tree node');
    } finally {
      setCreatingIntroNode(false);
    }
  };

  const handleEditIntroTreeSubmit = async () => {
    if (!editingIntroTree) return;
    
    try {
      setUpdatingIntroTree(true);
      const response = await brain.update_introduction_tree(
        { treeId: editingIntroTree.id },
        editIntroTreeData
      );
      
      if (response.ok) {
        toast.success('Introduction tree updated successfully');
        setShowEditIntroTreeDialog(false);
        setEditingIntroTree(null);
        setEditIntroTreeData({
          name: '',
          description: '',
          jurisdiction: '',
          category: '',
          status: 'draft'
        });
        // Reload data to show the updated tree
        loadData();
      } else {
        const errorData = await response.json().catch(() => null);
        toast.error(`Failed to update introduction tree: ${errorData?.detail || 'Unknown error'}`);
      }
    } catch (error) {
      console.error('Error updating introduction tree:', error);
      toast.error('Failed to update introduction tree');
    } finally {
      setUpdatingIntroTree(false);
    }
  };

  const handleEditTree = (tree: ClassificationTree) => {
    setEditingTree(tree);
    setEditTreeData({
      name: tree.name,
      description: tree.description || '',
      jurisdiction: tree.jurisdiction,
      category: tree.category,
      version: tree.version,
      status: tree.status
    });
    setShowEditTreeDialog(true);
  };

  const handleEditTreeSubmit = async () => {
    if (!editingTree) return;
    
    try {
      setUpdatingTree(true);
      const response = await brain.update_classification_tree(
        { treeId: editingTree.id },
        {
          ...editTreeData,
          version: editTreeData.version ? parseInt(editTreeData.version) : null
        }
      );
      
      if (response.ok) {
        toast.success('Classification tree updated successfully');
        setShowEditTreeDialog(false);
        setEditingTree(null);
        setEditTreeData({
          name: '',
          description: '',
          jurisdiction: '',
          category: '',
          version: '',
          status: 'draft'
        });
        // Reload data to show the updated tree
        loadData();
      } else {
        const errorData = await response.json().catch(() => null);
        toast.error(`Failed to update classification tree: ${errorData?.detail || 'Unknown error'}`);
      }
    } catch (error) {
      console.error('Error updating classification tree:', error);
      toast.error('Failed to update classification tree');
    } finally {
      setUpdatingTree(false);
    }
  };

  const handleCreateNodeSubmit = async () => {
    if (!selectedTreeForNode) return;
    
    try {
      setCreatingNode(true);
      const response = await brain.create_tree_node(
        { treeId: selectedTreeForNode.id },
        newNodeData
      );
      
      if (response.ok) {
        toast.success('Classification tree node created successfully');
        setShowCreateNodeDialog(false);
        setSelectedTreeForNode(null);
        setNewNodeData({
          node_key: '',
          title: '',
          description: '',
          question_text: '',
          question_type: 'multiple_choice',
          parent_node_id: null,
          display_order: 0,
          is_root: false,
          notes: '',
          multi_questions: [] as MultiQuestionItem[],
          outcome_rules: [] as OutcomeRule[]
        });
        // Reload data to show the new node
        loadData();
      } else {
        const errorData = await response.json().catch(() => null);
        toast.error(`Failed to create classification tree node: ${errorData?.detail || 'Unknown error'}`);
      }
    } catch (error) {
      console.error('Error creating classification tree node:', error);
      toast.error('Failed to create classification tree node');
    } finally {
      setCreatingNode(false);
    }
  };

  const loadExistingClassificationNodes = async (treeId: string) => {
    try {
      setLoadingClassificationNodes(true);
      const response = await brain.list_classification_tree_nodes({ treeId });
      if (response.ok) {
        const nodes = await response.json();
        setExistingClassificationNodes(nodes);
      }
    } catch (error) {
      console.error('Error loading existing classification nodes:', error);
    } finally {
      setLoadingClassificationNodes(false);
    }
  };

  const handleImportFile = async () => {
    const fileInput = document.getElementById('import-file') as HTMLInputElement;
    const file = fileInput.files[0];
    if (!file) return;
    
    try {
      setLoading(true);
      const response = await brain.import_critical_products({ file });
      if (response.ok) {
        toast.success('Critical products data imported successfully');
        loadData();
      } else {
        const errorData = await response.json().catch(() => null);
        toast.error(`Failed to import critical products data: ${errorData?.detail || 'Unknown error'}`);
      }
    } catch (error) {
      console.error('Error importing critical products data:', error);
      toast.error('Failed to import critical products data');
    } finally {
      setLoading(false);
    }
  };

  const downloadSampleFile = async () => {
    try {
      setLoading(true);
      const response = await brain.download_critical_products_excel_template();
      
      if (response.ok) {
        // Get the blob from the response
        const blob = await response.blob();
        
        // Create a download link
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'critical_products_template.xlsx';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        window.URL.revokeObjectURL(url);
        
        toast.success('Excel template downloaded successfully');
      } else {
        const errorData = await response.json().catch(() => null);
        toast.error(`Failed to download template: ${errorData?.detail || 'Unknown error'}`);
      }
    } catch (error) {
      console.error('Error downloading Excel template:', error);
      toast.error('Failed to download Excel template');
    } finally {
      setLoading(false);
    }
  };

  const exportCurrentData = () => {
    // Implement logic to export current data
    toast.info('Export current data functionality available');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 text-white p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-amber-400 mb-2">Product Classification Administration</h1>
          <p className="text-gray-300">Manage classification trees, introduction trees, and decision nodes</p>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid grid-cols-5 w-fit bg-gray-800 border border-gray-700">
            <TabsTrigger value="trees" className="data-[state=active]:bg-amber-600 data-[state=active]:text-white">
              <TreePine className="w-4 h-4 mr-2" />
              Classification Trees
            </TabsTrigger>
            <TabsTrigger value="introduction" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white">
              <FileText className="w-4 h-4 mr-2" />
              Introduction Trees
            </TabsTrigger>
            <TabsTrigger value="critical-products" className="data-[state=active]:bg-red-600 data-[state=active]:text-white">
              <Target className="w-4 h-4 mr-2" />
              Critical Products
            </TabsTrigger>
            <TabsTrigger value="workflows" className="data-[state=active]:bg-purple-600 data-[state=active]:text-white">
              <GitBranch className="w-4 h-4 mr-2" />
              Workflows
            </TabsTrigger>
            <TabsTrigger value="tools" className="data-[state=active]:bg-green-600 data-[state=active]:text-white">
              <Settings className="w-4 h-4 mr-2" />
              Tools
            </TabsTrigger>
          </TabsList>

          <TabsContent value="trees" className="space-y-6">
            <ClassificationTreesTab 
              onCreateTree={handleCreateTree}
              onCreateNode={handleCreateNode}
              onEditNode={handleEditNode}
              onEditTree={handleEditTree}
            />
          </TabsContent>

          <TabsContent value="introduction" className="space-y-6">
            <IntroductionTreesTab 
              onCreateTree={handleCreateIntroTree}
              onEditTree={handleEditIntroTree}
              onCreateNode={handleCreateIntroNode}
              onEditNode={handleEditIntroNode}
              onRefresh={setIntroTreesRefreshCallback}
            />
          </TabsContent>

          <TabsContent value="critical-products" className="space-y-6">
            <div className="bg-gray-800/30 backdrop-blur-sm border border-gray-700 rounded-lg p-6">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h2 className="text-xl font-semibold text-white mb-2">Critical Products Management</h2>
                  <p className="text-gray-400">Manage critical products database and classification rules</p>
                </div>
              </div>
              
              {/* Method B: Direct Database Import */}
              <Card className="bg-gray-800/30 backdrop-blur-sm border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white text-xl flex items-center gap-2">
                    <Download className="h-6 w-6 text-purple-400" />
                    Method B: Direct Database Import
                  </CardTitle>
                  <CardDescription className="text-gray-300">
                    Bulk import critical products data from Excel or CSV files to populate the database.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Alert className="bg-blue-900/20 border-blue-500/30">
                    <Info className="h-4 w-4 text-blue-400" />
                    <AlertDescription className="text-blue-300">
                      Upload structured data files (Excel/CSV) with trade codes, product descriptions, 
                      jurisdictions, restrictions, and measure types to rapidly populate the database.
                    </AlertDescription>
                  </Alert>
                  
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="space-y-3">
                      <Label className="text-sm font-medium text-gray-300">Expected File Format</Label>
                      <div className="text-sm text-gray-400 space-y-1">
                        <p>• <span className="text-white">HS Code:</span> Harmonized System codes</p>
                        <p>• <span className="text-white">CN Code:</span> Combined Nomenclature codes</p>
                        <p>• <span className="text-white">Description:</span> Product description</p>
                        <p>• <span className="text-white">Category/Subcategory:</span> Product classification</p>
                        <p>• <span className="text-white">Jurisdiction:</span> Applicable jurisdictions</p>
                        <p>• <span className="text-white">Restrictions:</span> Regulatory restrictions</p>
                        <p>• <span className="text-white">Risk Level:</span> Assessment level (low/medium/high)</p>
                      </div>
                    </div>
                    
                    <div className="space-y-3">
                      <Label className="text-sm font-medium text-gray-300">Import Actions</Label>
                      <div className="space-y-2">
                        <Input
                          type="file"
                          accept=".xlsx,.xls,.csv"
                          className="bg-gray-700/50 border-gray-600 text-white file:bg-purple-500/20 file:text-purple-300 file:border-purple-500/50"
                          id="import-file"
                        />
                        <Button 
                          className="w-full bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600"
                          onClick={() => handleImportFile()}
                          disabled={loading}
                        >
                          <Database className="h-4 w-4 mr-2" />
                          {loading ? 'Importing...' : 'Import Critical Products Data'}
                        </Button>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex gap-2 mt-4">
                    <Button 
                      variant="outline" 
                      size="sm"
                      className="border-green-500/50 text-green-400 hover:bg-green-500/10"
                      onClick={() => downloadSampleFile()}
                    >
                      <Download className="h-4 w-4 mr-2" />
                      Download Sample Template
                    </Button>
                    <Button 
                      variant="outline" 
                      size="sm"
                      className="border-blue-500/50 text-blue-400 hover:bg-blue-500/10"
                      onClick={() => exportCurrentData()}
                      disabled={loading}
                    >
                      <Download className="h-4 w-4 mr-2" />
                      Export Current Database
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="workflows" className="space-y-6">
            <WorkflowsTab />
          </TabsContent>
        </Tabs>
      </div>
      
      {/* Create Introduction Tree Node Dialog */}
      {showCreateIntroNodeDialog && selectedIntroTreeForNode && (
        <Dialog open={showCreateIntroNodeDialog} onOpenChange={setShowCreateIntroNodeDialog}>
          <DialogContent className="bg-gray-900 border-gray-700 text-white max-w-2xl">
            <DialogHeader>
              <DialogTitle className="text-blue-400">Add Introduction Node</DialogTitle>
              <DialogDescription className="text-gray-400">
                Add a new introduction node to tree: {selectedIntroTreeForNode.name}
              </DialogDescription>
            </DialogHeader>
            
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="node_key" className="text-sm font-medium text-gray-300">Node Key *</Label>
                  <Input
                    id="node_key"
                    value={newIntroNodeData.node_key}
                    onChange={(e) => setNewIntroNodeData({ ...newIntroNodeData, node_key: e.target.value })}
                    className="bg-gray-800 border-gray-600 text-white"
                    placeholder="e.g., INTRO_001"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="title" className="text-sm font-medium text-gray-300">Title *</Label>
                  <Input
                    id="title"
                    value={newIntroNodeData.title}
                    onChange={(e) => setNewIntroNodeData({ ...newIntroNodeData, title: e.target.value })}
                    className="bg-gray-800 border-gray-600 text-white"
                    placeholder="Node title"
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="description" className="text-sm font-medium text-gray-300">Description</Label>
                <Textarea
                  id="description"
                  value={newIntroNodeData.description}
                  onChange={(e) => setNewIntroNodeData({ ...newIntroNodeData, description: e.target.value })}
                  className="bg-gray-800 border-gray-600 text-white"
                  placeholder="Node description"
                  rows={2}
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="question_text" className="text-sm font-medium text-gray-300">Question Text *</Label>
                <Textarea
                  id="question_text"
                  value={newIntroNodeData.question_text}
                  onChange={(e) => setNewIntroNodeData({ ...newIntroNodeData, question_text: e.target.value })}
                  className="bg-gray-800 border-gray-600 text-white"
                  placeholder="What question should this node ask?"
                  rows={3}
                />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="question_type" className="text-sm font-medium text-gray-300">Question Type</Label>
                  <Select value={newIntroNodeData.question_type} onValueChange={(value) => setNewIntroNodeData({ ...newIntroNodeData, question_type: value })}>
                    <SelectTrigger className="bg-gray-800 border-gray-600 text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-gray-800 border-gray-600">
                      <SelectItem value="multiple_choice">Multiple Choice</SelectItem>
                      <SelectItem value="yes_no">Yes/No</SelectItem>
                      <SelectItem value="text_input">Text Input</SelectItem>
                      <SelectItem value="number_input">Number Input</SelectItem>
                      <SelectItem value="file_upload">File Upload</SelectItem>
                      <SelectItem value="multi_question_assessment">Multi-Question Assessment</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="parent_node_id" className="text-sm font-medium text-gray-300">Parent Node</Label>
                  <Select value={newIntroNodeData.parent_node_id || undefined} onValueChange={(value) => setNewIntroNodeData({ ...newIntroNodeData, parent_node_id: value === 'none' ? null : value })}>
                    <SelectTrigger className="bg-gray-800 border-gray-600 text-white">
                      <SelectValue placeholder="Select parent node" />
                    </SelectTrigger>
                    <SelectContent className="bg-gray-800 border-gray-600">
                      {loadingNodes ? (
                        <SelectItem value="loading" disabled>Loading...</SelectItem>
                      ) : (
                        <>
                          <SelectItem value="none">None (Root level)</SelectItem>
                          {existingNodes.filter(node => node.id && node.id.trim() !== '').map(node => (
                            <SelectItem key={node.id} value={node.id}>{node.title}</SelectItem>
                          ))}
                        </>
                      )}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="display_order" className="text-sm font-medium text-gray-300">Display Order</Label>
                  <Input
                    id="display_order"
                    type="number"
                    value={newIntroNodeData.display_order}
                    onChange={(e) => setNewIntroNodeData({ ...newIntroNodeData, display_order: parseInt(e.target.value) || 0 })}
                    className="bg-gray-800 border-gray-600 text-white"
                    placeholder="0"
                  />
                </div>
                <div className="flex items-center space-x-2 pt-6">
                  <Checkbox
                    id="is_root"
                    checked={newIntroNodeData.is_root}
                    onCheckedChange={(checked) => setNewIntroNodeData({ ...newIntroNodeData, is_root: !!checked })}
                    className="border-gray-600"
                  />
                  <Label htmlFor="is_root" className="text-sm text-gray-300">This is a root node</Label>
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="notes" className="text-sm font-medium text-gray-300">Notes</Label>
                <Textarea
                  id="notes"
                  value={newIntroNodeData.notes}
                  onChange={(e) => setNewIntroNodeData({ ...newIntroNodeData, notes: e.target.value })}
                  className="bg-gray-800 border-gray-600 text-white"
                  placeholder="Additional notes about this node"
                  rows={2}
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="routing_rule" className="text-sm font-medium text-gray-300">Routing Rule</Label>
                
                {/* Instructions for routing rule usage */}
                <div className="bg-blue-900/30 border border-blue-700/50 rounded-lg p-3 mb-3">
                  <div className="flex items-start gap-2">
                    <span className="text-blue-400 text-sm">💡</span>
                    <div className="text-sm text-blue-300">
                      <p className="font-medium mb-1">When to use Routing Rule:</p>
                      <ul className="text-xs space-y-1 text-blue-200">
                        <li>• <strong>Text/Number Input nodes:</strong> Specify where users go after submitting their answer</li>
                        <li>• <strong>Multiple Choice nodes:</strong> Leave empty - routing is handled by individual options</li>
                        <li>• <strong>Format:</strong> Use a Classification Tree ID to direct users to that tree</li>
                      </ul>
                    </div>
                  </div>
                </div>
                
                <Textarea
                  id="routing_rule"
                  value={newIntroNodeData.routing_rule}
                  onChange={(e) => setNewIntroNodeData({ ...newIntroNodeData, routing_rule: e.target.value })}
                  className="bg-gray-800 border-gray-600 text-white"
                  placeholder="Enter Classification Tree ID for routing (leave empty for multiple choice nodes)"
                  rows={2}
                />
              </div>
            </div>
            
            <DialogFooter>
              <Button
                variant="outline"
                onClick={() => setShowCreateIntroNodeDialog(false)}
                className="text-gray-300 border-gray-600 hover:bg-gray-700"
                disabled={creatingIntroNode}
              >
                Cancel
              </Button>
              <Button
                onClick={handleCreateIntroNodeSubmit}
                className="bg-blue-600 hover:bg-blue-700 text-white"
                disabled={creatingIntroNode || !newIntroNodeData.node_key.trim() || !newIntroNodeData.title.trim() || !newIntroNodeData.question_text.trim()}
              >
                {creatingIntroNode ? 'Creating...' : 'Create Node'}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
      
      {/* Edit Introduction Tree Dialog */}
      {showEditIntroTreeDialog && editingIntroTree && (
        <Dialog open={showEditIntroTreeDialog} onOpenChange={setShowEditIntroTreeDialog}>
          <DialogContent className="bg-gray-900 border-gray-700 text-white max-w-2xl">
            <DialogHeader>
              <DialogTitle className="text-blue-400">Edit Introduction Tree</DialogTitle>
              <DialogDescription className="text-gray-400">
                Edit the details of tree: {editingIntroTree.name}
              </DialogDescription>
            </DialogHeader>
            
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="name" className="text-sm font-medium text-gray-300">Name *</Label>
                  <Input
                    id="name"
                    value={editIntroTreeData.name}
                    onChange={(e) => setEditIntroTreeData({ ...editIntroTreeData, name: e.target.value })}
                    className="bg-gray-800 border-gray-600 text-white"
                    placeholder="Tree name"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="description" className="text-sm font-medium text-gray-300">Description</Label>
                  <Textarea
                    id="description"
                    value={editIntroTreeData.description}
                    onChange={(e) => setEditIntroTreeData({ ...editIntroTreeData, description: e.target.value })}
                    className="bg-gray-800 border-gray-600 text-white"
                    placeholder="Tree description"
                    rows={2}
                  />
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="jurisdiction" className="text-sm font-medium text-gray-300">Jurisdiction</Label>
                  <Input
                    id="jurisdiction"
                    value={editIntroTreeData.jurisdiction}
                    onChange={(e) => setEditIntroTreeData({ ...editIntroTreeData, jurisdiction: e.target.value })}
                    className="bg-gray-800 border-gray-600 text-white"
                    placeholder="Tree jurisdiction"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="category" className="text-sm font-medium text-gray-300">Category</Label>
                  <Input
                    id="category"
                    value={editIntroTreeData.category}
                    onChange={(e) => setEditIntroTreeData({ ...editIntroTreeData, category: e.target.value })}
                    className="bg-gray-800 border-gray-600 text-white"
                    placeholder="Tree category"
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="status" className="text-sm font-medium text-gray-300">Status</Label>
                <Select value={editIntroTreeData.status} onValueChange={(value) => setEditIntroTreeData({ ...editIntroTreeData, status: value })}>
                  <SelectTrigger className="bg-gray-800 border-gray-600 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-gray-800 border-gray-600">
                    <SelectItem value="draft">Draft</SelectItem>
                    <SelectItem value="published">Published</SelectItem>
                    <SelectItem value="archived">Archived</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <DialogFooter>
              <Button
                variant="outline"
                onClick={() => setShowEditIntroTreeDialog(false)}
                className="text-gray-300 border-gray-600 hover:bg-gray-700"
                disabled={updatingIntroTree}
              >
                Cancel
              </Button>
              <Button
                onClick={handleUpdateIntroTreeSubmit}
                className="bg-blue-600 hover:bg-blue-700 text-white"
                disabled={updatingIntroTree || !editIntroTreeData.name.trim()}
              >
                {updatingIntroTree ? 'Updating...' : 'Update Tree'}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
      
      {/* Edit Classification Tree Dialog */}
      {showEditTreeDialog && editingTree && (
        <Dialog open={showEditTreeDialog} onOpenChange={setShowEditTreeDialog}>
          <DialogContent className="bg-gray-900 border-gray-700 text-white max-w-2xl">
            <DialogHeader>
              <DialogTitle className="text-blue-400">Edit Classification Tree</DialogTitle>
              <DialogDescription className="text-gray-400">
                Edit the details of tree: {editingTree.name}
              </DialogDescription>
            </DialogHeader>
            
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="name" className="text-sm font-medium text-gray-300">Name *</Label>
                  <Input
                    id="name"
                    value={editTreeData.name}
                    onChange={(e) => setEditTreeData({ ...editTreeData, name: e.target.value })}
                    className="bg-gray-800 border-gray-600 text-white"
                    placeholder="Tree name"
                  />
                </div>
                <div className="space-y-1">
                  <Label htmlFor="node_key" className="text-sm font-medium text-gray-300">Node Key *</Label>
                  <Input
                    id="node_key"
                    value={newNodeData.node_key}
                    onChange={(e) => setNewNodeData({ ...newNodeData, node_key: e.target.value })}
                    className="bg-gray-800 border-gray-600 text-white"
                    placeholder="e.g., NODE_001"
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="title" className="text-sm font-medium text-gray-300">Title *</Label>
                <Input
                  id="title"
                  value={newNodeData.title}
                  onChange={(e) => setNewNodeData({ ...newNodeData, title: e.target.value })}
                  className="bg-gray-800 border-gray-600 text-white"
                  placeholder="Node title"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="description" className="text-sm font-medium text-gray-300">Description</Label>
                <Textarea
                  id="description"
                  value={newNodeData.description}
                  onChange={(e) => setNewNodeData({ ...newNodeData, description: e.target.value })}
                  className="bg-gray-800 border-gray-600 text-white"
                  placeholder="Node description"
                  rows={2}
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="question_text" className="text-sm font-medium text-gray-300">Question Text *</Label>
                <Textarea
                  id="question_text"
                  value={newNodeData.question_text}
                  onChange={(e) => setNewNodeData({ ...newNodeData, question_text: e.target.value })}
                  className="bg-gray-800 border-gray-600 text-white"
                  placeholder="What question should this node ask?"
                  rows={3}
                />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="question_type" className="text-sm font-medium text-gray-300">Question Type</Label>
                  <Select value={newNodeData.question_type} onValueChange={(value) => setNewNodeData({ ...newNodeData, question_type: value })}>
                    <SelectTrigger className="bg-gray-800 border-gray-600 text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-gray-800 border-gray-600">
                      <SelectItem value="multiple_choice">Multiple Choice</SelectItem>
                      <SelectItem value="yes_no">Yes/No</SelectItem>
                      <SelectItem value="text_input">Text Input</SelectItem>
                      <SelectItem value="number_input">Number Input</SelectItem>
                      <SelectItem value="file_upload">File Upload</SelectItem>
                      <SelectItem value="multi_question_assessment">Multi-Question Assessment</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="parent_node_id" className="text-sm font-medium text-gray-300">Parent Node</Label>
                  <Select value={newNodeData.parent_node_id || undefined} onValueChange={(value) => setNewNodeData({ ...newNodeData, parent_node_id: value || null })}>
                    <SelectTrigger className="bg-gray-800 border-gray-600 text-white">
                      <SelectValue placeholder="Select parent node" />
                    </SelectTrigger>
                    <SelectContent className="bg-gray-800 border-gray-600">
                      {loadingClassificationNodes ? (
                        <SelectItem value="loading" disabled>Loading...</SelectItem>
                      ) : (
                        existingClassificationNodes.filter(node => node.id && node.id.trim() !== '').map(node => (
                          <SelectItem key={node.id} value={node.id}>{node.title}</SelectItem>
                        ))
                      )}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="display_order" className="text-sm font-medium text-gray-300">Display Order</Label>
                  <Input
                    id="display_order"
                    type="number"
                    value={newNodeData.display_order}
                    onChange={(e) => setNewNodeData({ ...newNodeData, display_order: parseInt(e.target.value) || 0 })}
                    className="bg-gray-800 border-gray-600 text-white"
                    placeholder="0"
                  />
                </div>
                <div className="flex items-center space-x-2 pt-6">
                  <Checkbox
                    id="is_root"
                    checked={newNodeData.is_root}
                    onCheckedChange={(checked) => setNewNodeData({ ...newNodeData, is_root: !!checked })}
                    className="border-gray-600"
                  />
                  <Label htmlFor="is_root" className="text-sm text-gray-300">This is a root node</Label>
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="notes" className="text-sm font-medium text-gray-300">Notes</Label>
                <Textarea
                  id="notes"
                  value={newNodeData.notes}
                  onChange={(e) => setNewNodeData({ ...newNodeData, notes: e.target.value })}
                  className="bg-gray-800 border-gray-600 text-white"
                  placeholder="Additional notes about this node"
                  rows={2}
                />
              </div>
              
              {/* Multi-Question Assessment Configuration */}
              {newNodeData.question_type === 'multi_question_assessment' && (
                <div className="space-y-4 p-4 border border-purple-600 rounded-lg bg-purple-900/10">
                  <h3 className="text-lg font-semibold text-purple-400">Multi-Question Assessment Configuration</h3>
                  
                  {/* Questions Section */}
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <Label className="text-sm font-medium text-gray-300">Questions</Label>
                      <Button
                        type="button"
                        onClick={() => {
                          const newQuestion: MultiQuestionItem = {
                            key: `question_${newNodeData.multi_questions.length + 1}`,
                            text: '',
                            order: newNodeData.multi_questions.length + 1
                          };
                          setNewNodeData({
                            ...newNodeData,
                            multi_questions: [...newNodeData.multi_questions, newQuestion]
                          });
                        }}
                        size="sm"
                        className="bg-purple-600 hover:bg-purple-700 text-white"
                      >
                        <Plus className="w-4 h-4 mr-1" />Add Question
                      </Button>
                    </div>
                    
                    {newNodeData.multi_questions.map((question, index) => (
                      <div key={index} className="grid grid-cols-3 gap-2 items-end">
                        <div className="space-y-1">
                          <Label className="text-xs text-gray-400">Key</Label>
                          <Input
                            value={question.key}
                            onChange={(e) => {
                              const updated = [...newNodeData.multi_questions];
                              updated[index] = { ...updated[index], key: e.target.value };
                              setNewNodeData({ ...newNodeData, multi_questions: updated });
                            }}
                            className="bg-gray-800 border-gray-600 text-white text-sm"
                            placeholder="question_key"
                          />
                        </div>
                        <div className="space-y-1">
                          <Label className="text-xs text-gray-400">Question Text</Label>
                          <Input
                            value={question.text}
                            onChange={(e) => {
                              const updated = [...newNodeData.multi_questions];
                              updated[index] = { ...updated[index], text: e.target.value };
                              setNewNodeData({ ...newNodeData, multi_questions: updated });
                            }}
                            className="bg-gray-800 border-gray-600 text-white text-sm"
                            placeholder="Your YES/NO question"
                          />
                        </div>
                        <Button
                          type="button"
                          onClick={() => {
                            const updated = newNodeData.multi_questions.filter((_, i) => i !== index);
                            setNewNodeData({ ...newNodeData, multi_questions: updated });
                          }}
                          size="sm"
                          variant="destructive"
                          className="h-8"
                        >
                          <Trash2 className="w-3 h-3" />
                        </Button>
                      </div>
                    ))}
                  </div>
                  
                  {/* Outcome Rules Section */}
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <Label className="text-sm font-medium text-gray-300">Outcome Rules</Label>
                      <Button
                        type="button"
                        onClick={() => {
                          const newRule: OutcomeRule = {
                            name: `Rule ${newNodeData.outcome_rules.length + 1}`,
                            description: '',
                            logic: { yes_count: 0, no_count: 0 },
                            target_type: 'node_key',
                            target_value: ''
                          };
                          setNewNodeData({
                            ...newNodeData,
                            outcome_rules: [...newNodeData.outcome_rules, newRule]
                          });
                        }}
                        size="sm"
                        className="bg-purple-600 hover:bg-purple-700 text-white"
                      >
                        <Plus className="w-4 h-4 mr-1" />Add Rule
                      </Button>
                    </div>
                    
                    {newNodeData.outcome_rules.map((rule, index) => (
                      <div key={index} className="grid grid-cols-2 gap-2 p-3 border border-gray-600 rounded">
                        <div className="space-y-2">
                          <div className="space-y-1">
                            <Label className="text-xs text-gray-400">Rule Name</Label>
                            <Input
                              value={rule.name}
                              onChange={(e) => {
                                const updated = [...newNodeData.outcome_rules];
                                updated[index] = { ...updated[index], name: e.target.value };
                                setNewNodeData({ ...newNodeData, outcome_rules: updated });
                              }}
                              className="bg-gray-800 border-gray-600 text-white text-sm"
                            />
                          </div>
                          <div className="space-y-1">
                            <Label className="text-xs text-gray-400">Target</Label>
                            <Input
                              value={rule.target_value}
                              onChange={(e) => {
                                const updated = [...newNodeData.outcome_rules];
                                updated[index] = { ...updated[index], target_value: e.target.value };
                                setNewNodeData({ ...newNodeData, outcome_rules: updated });
                              }}
                              className="bg-gray-800 border-gray-600 text-white text-sm"
                              placeholder="node_key or outcome_code"
                            />
                          </div>
                        </div>
                        <div className="space-y-2">
                          <div className="grid grid-cols-2 gap-1">
                            <div className="space-y-1">
                              <Label className="text-xs text-gray-400">YES Count</Label>
                              <Input
                                type="number"
                                value={rule.logic.yes_count || 0}
                                onChange={(e) => {
                                  const updated = [...newNodeData.outcome_rules];
                                  updated[index] = {
                                    ...updated[index],
                                    logic: { ...updated[index].logic, yes_count: parseInt(e.target.value) || 0 }
                                  };
                                  setNewNodeData({ ...newNodeData, outcome_rules: updated });
                                }}
                                className="bg-gray-800 border-gray-600 text-white text-sm"
                              />
                            </div>
                            <div className="space-y-1">
                              <Label className="text-xs text-gray-400">NO Count</Label>
                              <Input
                                type="number"
                                value={rule.logic.no_count || 0}
                                onChange={(e) => {
                                  const updated = [...newNodeData.outcome_rules];
                                  updated[index] = {
                                    ...updated[index],
                                    logic: { ...updated[index].logic, no_count: parseInt(e.target.value) || 0 }
                                  };
                                  setNewNodeData({ ...newNodeData, outcome_rules: updated });
                                }}
                                className="bg-gray-800 border-gray-600 text-white text-sm"
                              />
                            </div>
                          </div>
                          <div className="space-y-1">
                            <Label className="text-xs text-gray-400">Description</Label>
                            <Input
                              value={rule.description || ''}
                              onChange={(e) => {
                                const updated = [...newNodeData.outcome_rules];
                                updated[index] = { ...updated[index], description: e.target.value };
                                setNewNodeData({ ...newNodeData, outcome_rules: updated });
                              }}
                              className="bg-gray-800 border-gray-600 text-white text-sm"
                              placeholder="Rule description"
                            />
                          </div>
                          <Button
                            type="button"
                            onClick={() => {
                              const updated = newNodeData.outcome_rules.filter((_, i) => i !== index);
                              setNewNodeData({ ...newNodeData, outcome_rules: updated });
                            }}
                            size="sm"
                            variant="destructive"
                            className="w-full h-6 text-xs"
                          >
                            <Trash2 className="w-3 h-3 mr-1" />Delete Rule
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
            
            <DialogFooter>
              <Button
                variant="outline"
                onClick={() => setShowCreateNodeDialog(false)}
                className="text-gray-300 border-gray-600 hover:bg-gray-700"
                disabled={creatingNode}
              >
                Cancel
              </Button>
              <Button
                onClick={handleCreateNodeSubmit}
                className="bg-blue-600 hover:bg-blue-700 text-white"
                disabled={creatingNode || !newNodeData.node_key.trim() || !newNodeData.title.trim() || !newNodeData.question_text.trim()}
              >
                {creatingNode ? 'Creating...' : 'Create Node'}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
};

export default ProductClassificationAdminSimplified;
