import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { 
  ArrowRight, 
  ExternalLink, 
  Search, 
  Link, 
  FileText, 
  Globe, 
  Tag,
  TrendingUp,
  RefreshCw,
  Info
} from 'lucide-react';
import brain from 'brain';
import { toast } from 'sonner';

interface CrossReference {
  id: number;
  title: string;
  description?: string;
  country_jurisdiction?: string[];
  regulation_type?: string[];
  reference_text: string;
  reference_type: string;
  relevance_score: number;
}

interface Props {
  documentId: number;
  onDocumentSelect?: (documentId: number) => void;
  className?: string;
}

const REFERENCE_TYPE_COLORS: { [key: string]: string } = {
  'cfr': 'bg-blue-500/20 text-blue-400 border-blue-500/30',
  'ear': 'bg-green-500/20 text-green-400 border-green-500/30', 
  'ccl': 'bg-purple-500/20 text-purple-400 border-purple-500/30',
  'eu_regulation': 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30',
  'eu_directive': 'bg-orange-500/20 text-orange-400 border-orange-500/30',
  'article': 'bg-indigo-500/20 text-indigo-400 border-indigo-500/30',
  'section': 'bg-cyan-500/20 text-cyan-400 border-cyan-500/30',
  'license_exception': 'bg-red-500/20 text-red-400 border-red-500/30',
  'general': 'bg-slate-500/20 text-slate-400 border-slate-500/30'
};

const REFERENCE_TYPE_LABELS: { [key: string]: string } = {
  'cfr': 'CFR',
  'ear': 'EAR',
  'ccl': 'CCL',
  'eu_regulation': 'EU Regulation',
  'eu_directive': 'EU Directive',
  'article': 'Article',
  'section': 'Section',
  'chapter': 'Chapter',
  'part': 'Part',
  'annex': 'Annex',
  'license_exception': 'License Exception',
  'general': 'Reference'
};

export default function CrossReferencesViewer({ documentId, onDocumentSelect, className }: Props) {
  const [crossReferences, setCrossReferences] = useState<CrossReference[]>([]);
  const [loading, setLoading] = useState(true);
  const [rebuilding, setRebuilding] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    loadCrossReferences();
  }, [documentId]);

  const loadCrossReferences = async () => {
    try {
      setLoading(true);
      setError(null);
      
      const response = await brain.get_document_cross_references({ document_id: documentId });
      if (response.ok) {
        const data = await response.json();
        setCrossReferences(data);
      } else {
        throw new Error('Failed to load cross-references');
      }
    } catch (err) {
      console.error('Error loading cross-references:', err);
      setError(err instanceof Error ? err.message : 'Failed to load cross-references');
      setCrossReferences([]);
    } finally {
      setLoading(false);
    }
  };

  const rebuildCrossReferences = async () => {
    try {
      setRebuilding(true);
      
      const response = await brain.rebuild_document_cross_references({ document_id: documentId });
      if (response.ok) {
        const data = await response.json();
        toast.success(`Cross-references rebuilt - ${data.related_documents_found} related documents found`);
        await loadCrossReferences();
      } else {
        throw new Error('Failed to rebuild cross-references');
      }
    } catch (err) {
      console.error('Error rebuilding cross-references:', err);
      toast.error('Failed to rebuild cross-references');
    } finally {
      setRebuilding(false);
    }
  };

  const handleDocumentClick = (docId: number) => {
    if (onDocumentSelect) {
      onDocumentSelect(docId);
    }
  };

  const getRelevanceColor = (score: number) => {
    if (score >= 1.5) return 'text-green-400';
    if (score >= 1.0) return 'text-yellow-400';
    return 'text-orange-400';
  };

  const formatRelevanceScore = (score: number) => {
    return (score * 100).toFixed(0) + '%';
  };

  if (loading) {
    return (
      <Card className={`bg-slate-800 border-slate-700 ${className}`}>
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Link className="h-5 w-5 text-blue-400" />
            Cross-References
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {[1, 2, 3].map((i) => (
            <div key={i} className="space-y-2">
              <Skeleton className="h-4 w-3/4 bg-slate-700" />
              <Skeleton className="h-3 w-1/2 bg-slate-700" />
            </div>
          ))}
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className={`bg-slate-800 border-slate-700 ${className}`}>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-white flex items-center gap-2">
            <Link className="h-5 w-5 text-blue-400" />
            Cross-References
            {crossReferences.length > 0 && (
              <Badge variant="secondary" className="bg-blue-500/20 text-blue-400">
                {crossReferences.length}
              </Badge>
            )}
          </CardTitle>
          <Button
            variant="outline"
            size="sm"
            onClick={rebuildCrossReferences}
            disabled={rebuilding}
            className="border-slate-600 text-slate-400 hover:bg-slate-700"
          >
            <RefreshCw className={`h-4 w-4 ${rebuilding ? 'animate-spin' : ''}`} />
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {error && (
          <div className="text-red-400 text-sm mb-4 p-3 bg-red-500/10 border border-red-500/20 rounded">
            <Info className="h-4 w-4 inline mr-2" />
            {error}
          </div>
        )}
        
        {crossReferences.length === 0 ? (
          <div className="text-center py-8 text-slate-400">
            <Link className="h-12 w-12 mx-auto mb-3 opacity-50" />
            <p className="text-sm">
              No cross-references found.
            </p>
            <Button
              variant="outline"
              size="sm"
              onClick={rebuildCrossReferences}
              disabled={rebuilding}
              className="mt-3 border-slate-600 text-slate-400 hover:bg-slate-700"
            >
              <Search className="h-4 w-4 mr-2" />
              {rebuilding ? 'Processing...' : 'Analyze Document'}
            </Button>
          </div>
        ) : (
          <div className="space-y-3">
            {crossReferences.map((ref) => (
              <div
                key={`${ref.id}-${ref.reference_text}`}
                className="p-4 bg-slate-700/50 border border-slate-600 rounded-lg hover:bg-slate-700/70 transition-colors cursor-pointer group"
                onClick={() => handleDocumentClick(ref.id)}
              >
                <div className="flex items-start justify-between mb-2">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <h4 className="font-medium text-white group-hover:text-blue-400 transition-colors line-clamp-1">
                        {ref.title}
                      </h4>
                      <ExternalLink className="h-3 w-3 text-slate-400 group-hover:text-blue-400" />
                    </div>
                    
                    {ref.description && (
                      <p className="text-sm text-slate-400 line-clamp-2 mb-2">
                        {ref.description}
                      </p>
                    )}
                  </div>
                  
                  <div className="flex items-center gap-2 ml-3">
                    <div className={`text-xs px-2 py-1 rounded ${getRelevanceColor(ref.relevance_score)}`}>
                      <TrendingUp className="h-3 w-3 inline mr-1" />
                      {formatRelevanceScore(ref.relevance_score)}
                    </div>
                  </div>
                </div>
                
                <div className="flex items-center gap-2 mb-2">
                  <Badge 
                    variant="outline" 
                    className={`text-xs ${REFERENCE_TYPE_COLORS[ref.reference_type] || REFERENCE_TYPE_COLORS.general}`}
                  >
                    <Tag className="h-3 w-3 mr-1" />
                    {REFERENCE_TYPE_LABELS[ref.reference_type] || ref.reference_type}
                  </Badge>
                  
                  <Badge variant="secondary" className="text-xs bg-slate-600/50 text-slate-300">
                    "{ref.reference_text}"
                  </Badge>
                </div>
                
                <div className="flex items-center gap-3 text-xs text-slate-400">
                  {ref.country_jurisdiction && ref.country_jurisdiction.length > 0 && (
                    <div className="flex items-center gap-1">
                      <Globe className="h-3 w-3" />
                      <span>{ref.country_jurisdiction.join(', ')}</span>
                    </div>
                  )}
                  
                  {ref.regulation_type && ref.regulation_type.length > 0 && (
                    <div className="flex items-center gap-1">
                      <FileText className="h-3 w-3" />
                      <span>{ref.regulation_type.join(', ')}</span>
                    </div>
                  )}
                </div>
                
                <div className="mt-3 pt-2 border-t border-slate-600/50">
                  <div className="flex items-center justify-between text-xs text-slate-400">
                    <span>Click to view related document</span>
                    <ArrowRight className="h-3 w-3 group-hover:translate-x-1 transition-transform" />
                  </div>
                </div>
              </div>
            ))}
            
            {crossReferences.length > 5 && (
              <div className="text-center pt-2">
                <Button
                  variant="outline"
                  size="sm"
                  className="border-slate-600 text-slate-400 hover:bg-slate-700"
                >
                  View All {crossReferences.length} References
                </Button>
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
